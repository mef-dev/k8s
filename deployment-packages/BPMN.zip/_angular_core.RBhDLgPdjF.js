import { $ as fi, $a as ue, $b as fe, $c as Si, $d as Eh, A as Gt, Aa as gi, Ab as Zt, Ac as g, Ad as B, B as bp, Ba as mi, Bb as k, Bc as w, Bd as Vc, C as ci, Ca as lt, Cb as te, Cc as Nc, Cd as Bc, D as li, Da as H, Db as Y, Dc as wc, Dd as en, E as vM, Ea as St, Eb as gc, Ec as N, Ed as $c, F as nc, Fa as dc, Fb as ve, Fc as rh, Fd as wM, G as W, Ga as Pp, Gb as xn, Gc as kn, Gd as SM, H as ui, Ha as Ao, Hb as Le, Hc as Ue, Hd as Uc, I as Ap, Ia as Be, Ib as $e, Ic as Sc, Id as gh, J as oc, Ja as Fp, Jb as mc, Jc as Mi, Jd as dt, K as ae, Ka as CM, Kb as Up, Kc as _c, Kd as Gc, L as Mo, La as fc, Lb as et, Lc as bc, Ld as _M, M as yM, Ma as jp, Mb as Gp, Mc as Ac, Md as bM, N as EM, Na as vi, Nb as Wp, Nc as pe, Nd as AM, O as rc, Oa as Hp, Ob as zp, Oc as nt, Od as RM, P as Sn, Pa as Vp, Pb as de, Pc as Rc, Pd as OM, Q as ic, Qa as yi, Qb as Ii, Qc as ge, Qd as mh, R as b, Ra as ut, Rb as vc, Rc as ot, Rd as tn, S as IM, Sa as qt, Sb as ko, Sc as ih, Sd as vh, T as DM, Ta as Bp, Tb as x, Tc as Oc, Td as xM, U as wt, Ua as Ro, Ub as Lo, Uc as sh, Ud as Ai, V as _n, Va as $p, Vb as Kt, Vc as ah, Vd as Ot, W as di, Wa as TM, Wb as Z, Wc as xc, Wd as Fn, X as sc, Xa as V, Xb as qp, Xc as Ni, Xd as kM, Y as Ye, Ya as m, Yb as Jt, Yc as wi, Yd as Ri, Z as Wt, Za as _, Zb as At, Zc as Bo, Zd as Wc, _ as No, _a as q, _b as Po, _c as kc, _d as yh, a as G, aa as z, ab as X, ac as Qp, ad as Lc, ae as zc, b as Re, ba as xe, bb as ce, bc as Yp, bd as _i, be as Oi, c as Tp, ca as Ze, cb as Qt, cc as Zp, cd as ch, ce as qc, d as Oe, da as wo, db as F, dc as ie, dd as ne, de as Qc, e as Ka, ea as S, eb as O, ec as yc, ed as rt, ee as LM, f as Qe, fa as Te, fb as Ke, fc as Fo, fd as Ce, fe as PM, g as R, ga as Rp, gb as C, gc as Kp, gd as Pc, ge as nn, h as Mp, ha as ac, hb as _t, hc as jo, hd as Fc, he as Ih, i as Ja, ia as zt, ib as Oo, ic as Di, id as jc, ie as FM, j as ri, ja as Op, jb as An, jc as Ci, jd as bi, je as jM, k as Co, ka as Me, kb as ee, kc as Ho, kd as $o, ke as Dh, l as ii, la as He, lb as bt, lc as Ec, ld as Ge, le as HM, m as si, ma as pi, mb as Rn, mc as tt, md as Ln, me as VM, n as To, na as D, nb as Je, nc as Jp, nd as MM, ne as BM, o as Np, oa as cc, ob as Ne, oc as Xp, od as lh, oe as Ch, p as wp, pa as bn, pb as pc, pc as eh, pd as uh, pe as $M, q as Xa, qa as hi, qb as hc, qc as th, qd as me, qe as Th, r as ec, ra as xp, rb as Ei, rc as nh, rd as Pn, re as Uo, s as hM, sa as Ve, sb as On, sc as Ic, sd as Xt, se as Mh, t as gM, ta as kp, tb as we, tc as Ti, td as dh, te as Yc, u as mM, ua as lc, ub as Yt, uc as Vo, ud as fh, v as Sp, va as So, vb as ke, vc as Dc, vd as Rt, w as tc, wa as _o, wb as E, wc as Cc, wd as NM, x as ai, xa as uc, xb as Se, xc as oh, xd as ph, y as M, ya as Lp, yb as Xe, yc as Tc, yd as hh, z as _p, za as bo, zb as xo, zc as Mc, zd as Hc } from "@nf-internal/chunk-XIJWSQGJ";
import { Subject as Wg, Subscription as UM } from "rxjs";
import { map as GM } from "rxjs/operators";
var jn = { JSACTION: "jsaction" };
function at(e) { return { toString: e }.toString(); }
var L = (function (e) { return e[e.TemplateCreateStart = 0] = "TemplateCreateStart", e[e.TemplateCreateEnd = 1] = "TemplateCreateEnd", e[e.TemplateUpdateStart = 2] = "TemplateUpdateStart", e[e.TemplateUpdateEnd = 3] = "TemplateUpdateEnd", e[e.LifecycleHookStart = 4] = "LifecycleHookStart", e[e.LifecycleHookEnd = 5] = "LifecycleHookEnd", e[e.OutputStart = 6] = "OutputStart", e[e.OutputEnd = 7] = "OutputEnd", e[e.BootstrapApplicationStart = 8] = "BootstrapApplicationStart", e[e.BootstrapApplicationEnd = 9] = "BootstrapApplicationEnd", e[e.BootstrapComponentStart = 10] = "BootstrapComponentStart", e[e.BootstrapComponentEnd = 11] = "BootstrapComponentEnd", e[e.ChangeDetectionStart = 12] = "ChangeDetectionStart", e[e.ChangeDetectionEnd = 13] = "ChangeDetectionEnd", e[e.ChangeDetectionSyncStart = 14] = "ChangeDetectionSyncStart", e[e.ChangeDetectionSyncEnd = 15] = "ChangeDetectionSyncEnd", e[e.AfterRenderHooksStart = 16] = "AfterRenderHooksStart", e[e.AfterRenderHooksEnd = 17] = "AfterRenderHooksEnd", e[e.ComponentStart = 18] = "ComponentStart", e[e.ComponentEnd = 19] = "ComponentEnd", e[e.DeferBlockStateStart = 20] = "DeferBlockStateStart", e[e.DeferBlockStateEnd = 21] = "DeferBlockStateEnd", e[e.DynamicComponentStart = 22] = "DynamicComponentStart", e[e.DynamicComponentEnd = 23] = "DynamicComponentEnd", e[e.HostBindingsUpdateStart = 24] = "HostBindingsUpdateStart", e[e.HostBindingsUpdateEnd = 25] = "HostBindingsUpdateEnd", e; })(L || {}), es = class {
    previousValue;
    currentValue;
    firstChange;
    constructor(t, n, o) { this.previousValue = t, this.currentValue = n, this.firstChange = o; }
    isFirstChange() { return this.firstChange; }
};
function zg(e, t, n, o) { t !== null ? t.applyValueToInputSignal(t, o) : e[n] = o; }
var qg = null, Qg = (() => { qg = Nh; let e = () => Nh; return e.ngInherit = !0, e; })();
function WM() { return qg; }
function Nh(e) { return e.type.prototype.ngOnChanges && (e.setInput = qM), zM; }
function zM() { let e = Yg(this), t = e?.current; if (t) {
    let n = e.previous;
    if (n === lt)
        e.previous = t;
    else
        for (let o in t)
            n[o] = t[o];
    e.current = null, this.ngOnChanges(t);
} }
function qM(e, t, n, o, r) { let i = this.declaredInputs[o], s = Yg(e) || QM(e, { previous: lt, current: null }), a = s.current || (s.current = {}), c = s.previous, l = c[i]; a[i] = new es(l && l.currentValue, n, c === lt), zg(e, t, r, n); }
var Il = "__ngSimpleChanges__";
function Yg(e) { return Object.hasOwn(e, Il) && e[Il] || null; }
function QM(e, t) { return e[Il] = t; }
var wh = [];
var P = function (e, t = null, n) { for (let o = 0; o < wh.length; o++) {
    let r = wh[o];
    r(e, t, n);
} };
function YM(e, t, n) { let { ngOnChanges: o, ngOnInit: r, ngDoCheck: i } = t.type.prototype; if (o) {
    let s = WM()(t);
    (n.preOrderHooks ??= []).push(e, s), (n.preOrderCheckHooks ??= []).push(e, s);
} r && (n.preOrderHooks ??= []).push(0 - e, r), i && ((n.preOrderHooks ??= []).push(e, i), (n.preOrderCheckHooks ??= []).push(e, i)); }
function Zg(e, t) { for (let n = t.directiveStart, o = t.directiveEnd; n < o; n++) {
    let i = e.data[n].type.prototype, { ngAfterContentInit: s, ngAfterContentChecked: a, ngAfterViewInit: c, ngAfterViewChecked: l, ngOnDestroy: u } = i;
    s && (e.contentHooks ??= []).push(-n, s), a && ((e.contentHooks ??= []).push(n, a), (e.contentCheckHooks ??= []).push(n, a)), c && (e.viewHooks ??= []).push(-n, c), l && ((e.viewHooks ??= []).push(n, l), (e.viewCheckHooks ??= []).push(n, l)), u != null && (e.destroyHooks ??= []).push(n, u);
} }
function Wi(e, t, n) { Kg(e, t, 3, n); }
function zi(e, t, n, o) { (e[_] & 3) === n && Kg(e, t, n, o); }
function Zc(e, t) { let n = e[_]; (n & 3) === t && (n &= 16383, n += 1, e[_] = n); }
function Kg(e, t, n, o) { let r = o !== void 0 ? e[Rn] & 65535 : 0, i = o ?? -1, s = t.length - 1, a = 0; for (let c = r; c < s; c++)
    if (typeof t[c + 1] == "number") {
        if (a = t[c], o != null && a >= o)
            break;
    }
    else
        t[c] < 0 && (e[Rn] += 65536), (a < i || i == -1) && (ZM(e, n, t, c), e[Rn] = (e[Rn] & 4294901760) + c + 2), c++; }
function Sh(e, t) { P(L.LifecycleHookStart, e, t); let n = R(null); try {
    t.call(e);
}
finally {
    R(n), P(L.LifecycleHookEnd, e, t);
} }
function ZM(e, t, n, o) { let r = n[o] < 0, i = n[o + 1], s = r ? -n[o] : n[o], a = e[s]; r ? e[_] >> 14 < e[Rn] >> 16 && (e[_] & 3) === t && (e[_] += 16384, Sh(a, i)) : Sh(a, i); }
var Wn = -1, un = class {
    factory;
    name;
    injectImpl;
    resolving = !1;
    canSeeViewProviders;
    multi;
    componentProviders;
    index;
    providerFactory;
    constructor(t, n, o, r) { this.factory = t, this.name = r, this.canSeeViewProviders = n, this.injectImpl = o; }
};
function As(e) { return e != null && typeof e == "object" && (e.insertBeforeIndex === null || typeof e.insertBeforeIndex == "number" || Array.isArray(e.insertBeforeIndex)); }
function Jg(e) { return !!(e.type & 128); }
function KM(e) { return (e.flags & 8) !== 0; }
function JM(e) { return (e.flags & 16) !== 0; }
function XM(e, t, n) { let o = 0; for (; o < n.length;) {
    let r = n[o];
    if (typeof r == "number") {
        if (r !== 0)
            break;
        o++;
        let i = n[o++], s = n[o++], a = n[o++];
        e.setAttribute(t, s, a, i);
    }
    else {
        let i = r, s = n[++o];
        eN(i) ? e.setProperty(t, i, s) : e.setAttribute(t, i, s), o++;
    }
} return o; }
function Xg(e) { return e === 3 || e === 4 || e === 6; }
function eN(e) { return e.charCodeAt(0) === 64; }
function Zn(e, t) { if (!(t === null || t.length === 0))
    if (e === null || e.length === 0)
        e = t.slice();
    else {
        let n = -1;
        for (let o = 0; o < t.length; o++) {
            let r = t[o];
            typeof r == "number" ? n = r : n === 0 || (n === -1 || n === 2 ? _h(e, n, r, null, t[++o]) : _h(e, n, r, null, null));
        }
    } return e; }
function _h(e, t, n, o, r) { let i = 0, s = e.length; if (t === -1)
    s = -1;
else
    for (; i < e.length;) {
        let a = e[i++];
        if (typeof a == "number") {
            if (a === t) {
                s = -1;
                break;
            }
            else if (a > t) {
                s = i - 1;
                break;
            }
        }
    } for (; i < e.length;) {
    let a = e[i];
    if (typeof a == "number")
        break;
    if (a === n) {
        r !== null && (e[i + 1] = r);
        return;
    }
    i++, r !== null && i++;
} s !== -1 && (e.splice(s, 0, t), i = s + 1), e.splice(i++, 0, n), r !== null && e.splice(i++, 0, r); }
function em(e) { return e !== Wn; }
function ts(e) { return e & 32767; }
function tN(e) { return e >> 16; }
function ns(e, t) { let n = tN(e), o = t; for (; n > 0;)
    o = o[An], n--; return o; }
var Dl = !0;
function os(e) { let t = Dl; return Dl = e, t; }
var nN = 256, tm = nN - 1, nm = 5, oN = 0, it = {};
function rN(e, t, n) { let o; typeof n == "string" ? o = n.charCodeAt(0) || 0 : Object.hasOwn(n, Wt) && (o = n[Wt]), o == null && (o = n[Wt] = oN++); let r = o & tm, i = 1 << r; t.data[e + (r >> nm)] |= i; }
function rs(e, t) { let n = om(e, t); if (n !== -1)
    return n; let o = t[m]; o.firstCreatePass && (e.injectorIndex = t.length, Kc(o.data, e), Kc(t, null), Kc(o.blueprint, null)); let r = Au(e, t), i = e.injectorIndex; if (em(r)) {
    let s = ts(r), a = ns(r, t), c = a[m].data;
    for (let l = 0; l < 8; l++)
        t[i + l] = a[s + l] | c[s + l];
} return t[i + 8] = r, i; }
function Kc(e, t) { e.push(0, 0, 0, 0, 0, 0, 0, 0, t); }
function om(e, t) { return e.injectorIndex === -1 || e.parent && e.parent.injectorIndex === e.injectorIndex || t[e.injectorIndex + 8] === null ? -1 : e.injectorIndex; }
function Au(e, t) { if (e.parent && e.parent.injectorIndex !== -1)
    return e.parent.injectorIndex; let n = 0, o = null, r = t; for (; r !== null;) {
    if (o = cm(r), o === null)
        return Wn;
    if (n++, r = r[An], o.injectorIndex !== -1)
        return o.injectorIndex | n << 16;
} return Wn; }
function Cl(e, t, n) { rN(e, t, n); }
function iN(e, t) { if (t === "class")
    return e.classes; if (t === "style")
    return e.styles; let n = e.attrs; if (n) {
    let o = n.length, r = 0;
    for (; r < o;) {
        let i = n[r];
        if (Xg(i))
            break;
        if (i === 0)
            r = r + 2;
        else if (typeof i == "number")
            for (r++; r < o && typeof n[r] == "string";)
                r++;
        else {
            if (i === t)
                return n[r + 1];
            r = r + 2;
        }
    }
} return null; }
function rm(e, t, n) { if (n & 8 || e !== void 0)
    return e; ac(t, "NodeInjector"); }
function im(e, t, n, o) { if (n & 8 && o === void 0 && (o = null), (n & 3) === 0) {
    let r = e[O], i = zt(void 0);
    try {
        return r ? r.get(t, o, n & 8) : Op(t, o, n & 8);
    }
    finally {
        zt(i);
    }
} return rm(o, t, n); }
function Ru(e, t, n, o = 0, r) { if (e !== null) {
    if (t[_] & 2048 && !(o & 2)) {
        let s = lN(e, t, n, o, it);
        if (s !== it)
            return s;
    }
    let i = sm(e, t, n, o, it);
    if (i !== it)
        return i;
} return im(t, n, o, r); }
function sm(e, t, n, o, r) { let i = aN(n); if (typeof i == "function") {
    if (!kc(t, e, o))
        return o & 1 ? rm(r, n, o) : im(t, n, o, r);
    try {
        let s;
        if (s = i(o), s == null && !(o & 8))
            ac(n);
        else
            return s;
    }
    finally {
        Lc();
    }
}
else if (typeof i == "number") {
    let s = null, a = om(e, t), c = Wn, l = o & 1 ? t[ee][X] : null;
    for ((a === -1 || o & 4) && (c = a === -1 ? Au(e, t) : t[a + 8], c === Wn || !Ah(o, !1) ? a = -1 : (s = t[m], a = ts(c), t = ns(c, t))); a !== -1;) {
        let u = t[m];
        if (bh(i, a, u.data)) {
            let d = sN(a, t, n, s, o, l);
            if (d !== it)
                return d;
        }
        c = t[a + 8], c !== Wn && Ah(o, t[m].data[a + 8] === l) && bh(i, a, t) ? (s = u, a = ts(c), t = ns(c, t)) : a = -1;
    }
} return r; }
function sN(e, t, n, o, r, i) { let s = t[m], a = s.data[e + 8], c = o == null ? ve(a) && Dl : o != s && (a.type & 3) !== 0, l = r & 1 && i === a, u = qi(a, s, n, c, l); return u !== null ? sr(t, s, u, a, r) : it; }
function qi(e, t, n, o, r) { let i = e.providerIndexes, s = t.data, a = i & 1048575, c = e.directiveStart, l = e.directiveEnd, u = i >> 20, d = o ? a : a + u, f = r ? a + u : l; for (let p = d; p < f; p++) {
    let h = s[p];
    if (p < c && n === h || p >= c && h.type === n)
        return p;
} if (r) {
    let p = s[c];
    if (p && Le(p) && p.type === n)
        return c;
} return null; }
function sr(e, t, n, o, r) { let i = e[n], s = t.data; if (i instanceof un) {
    let a = i;
    if (a.resolving)
        throw Rp("");
    let c = os(a.canSeeViewProviders);
    a.resolving = !0;
    let l = s[n].type || s[n], u, d = a.injectImpl ? zt(a.injectImpl) : null, f = kc(e, o, 0);
    try {
        i = e[n] = a.factory(void 0, r, s, e, o), t.firstCreatePass && n >= o.directiveStart && YM(n, s[n], t);
    }
    finally {
        d !== null && zt(d), os(c), a.resolving = !1, Lc();
    }
} return i; }
function aN(e) { if (typeof e == "string")
    return e.charCodeAt(0) || 0; let t = Object.hasOwn(e, Wt) ? e[Wt] : void 0; return typeof t == "number" ? t >= 0 ? t & tm : cN : t; }
function bh(e, t, n) { let o = 1 << e; return !!(n[t + (e >> nm)] & o); }
function Ah(e, t) { return !(e & 2) && !(e & 1 && t); }
function Ou(e) { return e._lView; }
function Sr(e) { return e._tNode; }
var ye = class {
    _tNode;
    _lView;
    constructor(t, n) { this._tNode = t, this._lView = n; }
    get(t, n, o) { return Ru(this._tNode, this._lView, t, cc(o), n); }
};
function cN() { return new ye(N(), g()); }
function am(e) { return at(() => { let t = e.prototype.constructor, n = t[Ye] || Tl(t), o = Object.prototype, r = Object.getPrototypeOf(e.prototype).constructor; for (; r && r !== o;) {
    let i = r[Ye] || Tl(r);
    if (i && i !== n)
        return i;
    r = Object.getPrototypeOf(r);
} return i => new i; }); }
function Tl(e) { return ui(e) ? () => { let t = Tl(W(e)); return t && t(); } : hi(e); }
function lN(e, t, n, o, r) { let i = e, s = t; for (; i !== null && s !== null && s[_] & 2048 && !$e(s);) {
    let a = sm(i, s, n, o | 2, it);
    if (a !== it)
        return a;
    let c = i.parent;
    if (!c) {
        let l = s[pc];
        if (l) {
            let u = l.get(n, it, o & -5);
            if (u !== it)
                return u;
        }
        c = cm(s), s = s[An];
    }
    i = c;
} return r; }
function cm(e) { let t = e[m], n = t.type; return n === 2 ? t.declTNode : n === 1 ? e[X] : null; }
function Rs(e) { return iN(N(), e); }
var uN = () => (typeof requestIdleCallback < "u" ? requestIdleCallback : e => setTimeout(e)).bind(globalThis), dN = () => (typeof requestIdleCallback < "u" ? cancelIdleCallback : clearTimeout).bind(globalThis), Os = new b("", { factory: () => new Ml });
function fN(e) { return Be([{ provide: Os, useExisting: e }]); }
var Ml = class {
    requestIdleCallback = uN();
    cancelIdleCallback = dN();
    requestOnIdle(t, n) { return this.requestIdleCallback(t, n); }
    cancelOnIdle(t) { return this.cancelIdleCallback(t); }
}, Vn = "__annotations__", Bn = "__parameters__", $n = "__prop__metadata__";
function oo(e, t, n, o, r) { return at(() => { let i = xu(t); function s(...a) { if (this instanceof s)
    return i.call(this, ...a), this; let c = new s(...a); return function (u) { return r && r(u, ...a), (Object.hasOwn(u, Vn) ? u[Vn] : Object.defineProperty(u, Vn, { value: [] })[Vn]).push(c), u; }; } return n && (s.prototype = Object.create(n.prototype)), s.prototype.ngMetadataName = e, s.annotationCls = s, s; }); }
function xu(e) { return function (...n) { if (e) {
    let o = e(...n);
    for (let r in o)
        this[r] = o[r];
} }; }
function ro(e, t, n) { return at(() => { let o = xu(t); function r(...i) { if (this instanceof r)
    return o.apply(this, i), this; let s = new r(...i); return a.annotation = s, a; function a(c, l, u) { let d = Object.hasOwn(c, Bn) ? c[Bn] : Object.defineProperty(c, Bn, { value: [] })[Bn]; for (; d.length <= u;)
    d.push(null); return (d[u] = d[u] || []).push(s), c; } } return r.prototype.ngMetadataName = e, r.annotationCls = r, r; }); }
function yt(e, t, n, o) { return at(() => { let r = xu(t); function i(...s) { if (this instanceof i)
    return r.apply(this, s), this; let a = new i(...s); function c(l, u) { if (l === void 0)
    throw new Error("Standard Angular field decorators are not supported in JIT mode."); let d = l.constructor, f = Object.hasOwn(d, $n) ? d[$n] : Object.defineProperty(d, $n, { value: {} })[$n]; f[u] = Object.hasOwn(f, u) && f[u] || [], f[u].unshift(a); } return c; } return n && (i.prototype = Object.create(n.prototype)), i.prototype.ngMetadataName = e, i.annotationCls = i, i; }); }
function Q(e) { let t = Me.ng; if (t && t.\u0275compilerFacade)
    return t.\u0275compilerFacade; throw new Error("JIT compiler unavailable"); }
function Et(e) { return { token: e.token, providedIn: e.autoProvided === !1 ? null : "root", factory: e.factory, value: void 0 }; }
var is = { \u0275\u0275defineInjectable: ae, \u0275\u0275defineInjector: Mo, \u0275\u0275defineService: Et, \u0275\u0275inject: He, \u0275\u0275invalidFactoryDep: pi, resolveForwardRef: W }, lm = Function;
function xi(e) { return typeof e == "function"; }
var pN = /^function\s+\S+\(\)\s*{[\s\S]+\.apply\(this,\s*(arguments|(?:[^()]+\(\[\],)?[^()]+\(arguments\).*)\)/, hN = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{/, gN = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{[\s\S]*constructor\s*\(/, mN = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{[\s\S]*constructor\s*\(\)\s*{[^}]*super\(\.\.\.arguments\)/;
function vN(e) { return pN.test(e) || mN.test(e) || hN.test(e) && !gN.test(e); }
var ss = class {
    _reflect;
    constructor(t) { this._reflect = t || Me.Reflect; }
    factory(t) { return (...n) => new t(...n); }
    _zipTypesAndAnnotations(t, n) { let o; typeof t > "u" ? o = _o(n.length) : o = _o(t.length); for (let r = 0; r < o.length; r++)
        typeof t > "u" ? o[r] = [] : t[r] && t[r] != Object ? o[r] = [t[r]] : o[r] = [], n && n[r] != null && (o[r] = o[r].concat(n[r])); return o; }
    _ownParameters(t, n) { let o = t.toString(); if (vN(o))
        return null; if (t.parameters && t.parameters !== n.parameters)
        return t.parameters; let r = t.ctorParameters; if (r && r !== n.ctorParameters) {
        let a = typeof r == "function" ? r() : r, c = a.map(u => u && u.type), l = a.map(u => u && Jc(u.decorators));
        return this._zipTypesAndAnnotations(c, l);
    } let i = Object.hasOwn(t, Bn) && t[Bn], s = this._reflect && this._reflect.getOwnMetadata && this._reflect.getOwnMetadata("design:paramtypes", t); return s || i ? this._zipTypesAndAnnotations(s, i) : _o(t.length); }
    parameters(t) { if (!xi(t))
        return []; let n = ki(t), o = this._ownParameters(t, n); return !o && n !== Object && (o = this.parameters(n)), o || []; }
    _ownAnnotations(t, n) { if (t.annotations && t.annotations !== n.annotations) {
        let o = t.annotations;
        return typeof o == "function" && o.annotations && (o = o.annotations), o;
    } return t.decorators && t.decorators !== n.decorators ? Jc(t.decorators) : Object.hasOwn(t, Vn) ? t[Vn] : null; }
    annotations(t) { if (!xi(t))
        return []; let n = ki(t), o = this._ownAnnotations(t, n) || []; return (n !== Object ? this.annotations(n) : []).concat(o); }
    _ownPropMetadata(t, n) { if (t.propMetadata && t.propMetadata !== n.propMetadata) {
        let o = t.propMetadata;
        return typeof o == "function" && o.propMetadata && (o = o.propMetadata), o;
    } if (t.propDecorators && t.propDecorators !== n.propDecorators) {
        let o = t.propDecorators, r = {};
        return Object.keys(o).forEach(i => { r[i] = Jc(o[i]); }), r;
    } return Object.hasOwn(t, $n) ? t[$n] : null; }
    propMetadata(t) { if (!xi(t))
        return {}; let n = ki(t), o = {}; if (n !== Object) {
        let i = this.propMetadata(n);
        Object.keys(i).forEach(s => { o[s] = i[s]; });
    } let r = this._ownPropMetadata(t, n); return r && Object.keys(r).forEach(i => { let s = []; Object.hasOwn(o, i) && s.push(...o[i]), s.push(...r[i]), o[i] = s; }), o; }
    ownPropMetadata(t) { return xi(t) ? this._ownPropMetadata(t, ki(t)) || {} : {}; }
    hasLifecycleHook(t, n) { return t instanceof lm && n in t.prototype; }
};
function Jc(e) { return e ? e.map(t => { let o = t.type.annotationCls, r = t.args ? t.args : []; return new o(...r); }) : []; }
function ki(e) { let t = e.prototype ? Object.getPrototypeOf(e.prototype) : null; return (t ? t.constructor : null) || Object; }
var um = bn(ro("Inject", e => ({ token: e })), -1), dm = bn(ro("Optional"), 8), fm = bn(ro("Self"), 2), pm = bn(ro("SkipSelf"), 4), hm = bn(ro("Host"), 1), gm = ro("Attribute", e => ({ attributeName: e, __NG_ELEMENT_ID__: () => Rs(e) })), Rh = null;
function ku() { return Rh = Rh || new ss; }
function _r(e) { return mm(ku().parameters(e)); }
function mm(e) { return e.map(t => yN(t)); }
function yN(e) { let t = { token: null, attribute: null, host: !1, optional: !1, self: !1, skipSelf: !1 }; if (Array.isArray(e) && e.length > 0)
    for (let n = 0; n < e.length; n++) {
        let o = e[n];
        if (o === void 0)
            continue;
        let r = Object.getPrototypeOf(o);
        if (o instanceof dm || r.ngMetadataName === "Optional")
            t.optional = !0;
        else if (o instanceof pm || r.ngMetadataName === "SkipSelf")
            t.skipSelf = !0;
        else if (o instanceof fm || r.ngMetadataName === "Self")
            t.self = !0;
        else if (o instanceof hm || r.ngMetadataName === "Host")
            t.host = !0;
        else if (o instanceof um)
            t.token = o.token;
        else if (o instanceof gm) {
            if (o.attributeName === void 0)
                throw new M(-204, !1);
            t.attribute = o.attributeName;
        }
        else
            t.token = o;
    }
else
    e === void 0 || Array.isArray(e) && e.length === 0 ? t.token = null : t.token = e; return t; }
function EN(e, t) { let n = null, o = null; Object.hasOwn(e, Sn) || Object.defineProperty(e, Sn, { get: () => (n === null && (n = Q({ usage: 0, kind: "injectable", type: e }).compileInjectable(is, `ng:///${e.name}/\u0275prov.js`, TN(e, t))), n) }), Object.hasOwn(e, Ye) || Object.defineProperty(e, Ye, { get: () => { if (o === null) {
        let r = Q({ usage: 0, kind: "injectable", type: e });
        o = r.compileFactory(is, `ng:///${e.name}/\u0275fac.js`, { name: e.name, type: e, typeArgumentCount: 0, deps: _r(e), target: r.FactoryTarget.Injectable });
    } return o; }, configurable: !0 }); }
var IN = Gt({ provide: String, useValue: Gt });
function Oh(e) { return e.useClass !== void 0; }
function DN(e) { return IN in e; }
function xh(e) { return e.useFactory !== void 0; }
function CN(e) { return e.useExisting !== void 0; }
function TN(e, t) { let n = t || { providedIn: null }, o = { name: e.name, type: e, typeArgumentCount: 0, providedIn: n.providedIn }; return (Oh(n) || xh(n)) && n.deps !== void 0 && (o.deps = mm(n.deps)), Oh(n) ? o.useClass = n.useClass : DN(n) ? o.useValue = n.useValue : xh(n) ? o.useFactory = n.useFactory : CN(n) && (o.useExisting = n.useExisting), o; }
var MN = oo("Injectable", void 0, void 0, void 0, (e, t) => EN(e, t));
function NN(e, t) { let n = null, o = null; Object.hasOwn(e, Sn) || Object.defineProperty(e, Sn, { get: () => (n === null && (n = Q({ usage: 0, kind: "service", type: e }).compileService(is, `ng:///${e.name}/\u0275prov.js`, wN(e, t))), n) }), Object.hasOwn(e, Ye) || Object.defineProperty(e, Ye, { get: () => { if (o === null) {
        let r = Q({ usage: 0, kind: "service", type: e });
        o = r.compileFactory(is, `ng:///${e.name}/\u0275fac.js`, { name: e.name, type: e, typeArgumentCount: 0, deps: _r(e), target: r.FactoryTarget.Service });
    } return o; }, configurable: !0 }); }
function wN(e, t) { return { name: e.name, type: e, typeArgumentCount: 0, autoProvided: t?.autoProvided, factory: t?.factory }; }
var SN = oo("Service", void 0, void 0, void 0, (e, t) => NN(e, t));
function _N() { return io(N(), g()); }
function io(e, t) { return new br(Z(e, t)); }
var br = (() => { class e {
    nativeElement;
    constructor(n) { this.nativeElement = n; }
    static __NG_ELEMENT_ID__ = _N;
} return e; })();
function vm(e) { return e instanceof br ? e.nativeElement : e; }
function bN() { return this._results[Symbol.iterator](); }
var as = class {
    _emitDistinctChangesOnly;
    dirty = !0;
    _onDirty = void 0;
    _results = [];
    _changesDetected = !1;
    _changes = void 0;
    length = 0;
    first = void 0;
    last = void 0;
    get changes() { return this._changes ??= new Wg; }
    constructor(t = !1) { this._emitDistinctChangesOnly = t; }
    get(t) { return this._results[t]; }
    map(t) { return this._results.map(t); }
    filter(t) { return this._results.filter(t); }
    find(t) { return this._results.find(t); }
    reduce(t, n) { return this._results.reduce(t, n); }
    forEach(t) { this._results.forEach(t); }
    some(t) { return this._results.some(t); }
    toArray() { return this._results.slice(); }
    toString() { return this._results.toString(); }
    reset(t, n) { this.dirty = !1; let o = Ve(t); (this._changesDetected = !xp(this._results, o, n)) && (this._results = o, this.length = o.length, this.last = o[this.length - 1], this.first = o[0]); }
    notifyOnChanges() { this._changes !== void 0 && (this._changesDetected || !this._emitDistinctChangesOnly) && this._changes.next(this); }
    onDirty(t) { this._onDirty = t; }
    setDirty() { this.dirty = !0, this._onDirty?.(); }
    destroy() { this._changes !== void 0 && (this._changes.complete(), this._changes.unsubscribe()); }
    [Symbol.iterator] = bN;
}, Dn = "ngSkipHydration", AN = "ngskiphydration";
function Lu(e) { let t = e.mergedAttrs; if (t === null)
    return !1; for (let n = 0; n < t.length; n += 2) {
    let o = t[n];
    if (typeof o == "number")
        return !1;
    if (typeof o == "string" && o.toLowerCase() === AN)
        return !0;
} return !1; }
function ym(e) { return e.hasAttribute(Dn); }
function ar(e) { return (e.flags & 128) === 128; }
function so(e) { if (ar(e))
    return !0; let t = e.parent; for (; t;) {
    if (ar(e) || Lu(t))
        return !0;
    t = t.parent;
} return !1; }
function Em(e) { return ar(e) || Lu(e) || so(e); }
var xs = (function (e) { return e[e.OnPush = 0] = "OnPush", e[e.Eager = 1] = "Eager", e[e.Default = 1] = "Default", e; })(xs || {}), ks = new Map, RN = 0;
function ON() { return RN++; }
function xN(e) { ks.set(e[Ne], e); }
function Im(e) { return ks.get(e) || null; }
function Nl(e) { ks.delete(e[Ne]); }
function kN() { return ks; }
var cs = class {
    lViewId;
    nodeIndex;
    native;
    component;
    directives;
    localRefs;
    get lView() { return Im(this.lViewId); }
    constructor(t, n, o) { this.lViewId = t, this.nodeIndex = n, this.native = o; }
};
function Ee(e) { let t = Qi(e); if (t) {
    if (te(t)) {
        let n = t, o, r, i;
        if (Dm(e)) {
            if (o = jN(n, e), o == -1)
                throw new Error("The provided component was not found in the application");
            r = e;
        }
        else if (PN(e)) {
            if (o = HN(n, e), o == -1)
                throw new Error("The provided directive was not found in the application");
            i = Cm(o, n);
        }
        else if (o = Lh(n, e), o == -1)
            return null;
        let s = x(n[o]), a = Qi(s), c = a && !Array.isArray(a) ? a : kh(n, o, s);
        if (r && c.component === void 0 && (c.component = r, _e(c.component, c)), i && c.directives === void 0) {
            c.directives = i;
            for (let l = 0; l < i.length; l++)
                _e(i[l], c);
        }
        _e(c.native, c), t = c;
    }
}
else {
    let n = e, o = n;
    for (; o = o.parentNode;) {
        let r = Qi(o);
        if (r) {
            let i = Array.isArray(r) ? r : r.lView;
            if (!i)
                return null;
            let s = Lh(i, n);
            if (s >= 0) {
                let a = x(i[s]), c = kh(i, s, a);
                _e(a, c), t = c;
                break;
            }
        }
    }
} return t || null; }
function kh(e, t, n) { return new cs(e[Ne], t, n); }
var wl = "__ngContext__";
function _e(e, t) { te(t) ? (e[wl] = t[Ne], xN(t)) : e[wl] = t; }
function Qi(e) { let t = e[wl]; return typeof t == "number" ? Im(t) : t || null; }
function LN(e) { let t = Qi(e); return t ? te(t) ? t : t.lView : null; }
function Dm(e) { return e && e.constructor && e.constructor.\u0275cmp; }
function PN(e) { return e && e.constructor && e.constructor.\u0275dir; }
function Lh(e, t) { let n = e[m]; for (let o = E; o < n.bindingStartIndex; o++)
    if (x(e[o]) === t)
        return o; return -1; }
function FN(e) { if (e.child)
    return e.child; if (e.next)
    return e.next; for (; e.parent && !e.parent.next;)
    e = e.parent; return e.parent && e.parent.next; }
function jN(e, t) { let n = e[m].components; if (n)
    for (let o = 0; o < n.length; o++) {
        let r = n[o];
        if (fe(r, e)[F] === t)
            return r;
    }
else if (fe(E, e)[F] === t)
    return E; return -1; }
function HN(e, t) { let n = e[m].firstChild; for (; n;) {
    let o = n.directiveStart, r = n.directiveEnd;
    for (let i = o; i < r; i++)
        if (e[i] === t)
            return n.index;
    n = FN(n);
} return -1; }
function Cm(e, t) { let n = t[m].data[e]; if (n.directiveStart === 0)
    return H; let o = []; for (let r = n.directiveStart; r < n.directiveEnd; r++) {
    let i = t[r];
    Dm(i) || o.push(i);
} return o; }
function VN(e, t) { let n = t[m].data[e]; return ve(n) ? t[n.directiveStart + n.componentOffset] : null; }
function BN(e, t) { let n = e[m].data[t]; if (n && n.localNames) {
    let o = {}, r = n.index + 1;
    for (let i = 0; i < n.localNames.length; i += 2)
        o[n.localNames[i]] = e[r], r++;
    return o;
} return null; }
function Tm(e) { return Nm(e[_t]); }
function Mm(e) { return Nm(e[ue]); }
function Nm(e) { for (; e !== null && !Y(e);)
    e = e[ue]; return e; }
function* $N(e, t) { let n = e.child; for (; n;)
    yield [n, t], n = n.next; if (e.componentOffset > -1) {
    let r = fe(e.index, t);
    if (te(r)) {
        let s = r[m].firstChild;
        for (; s;)
            yield [s, r], s = s.next;
    }
} let o = t[e.index]; if (Y(o))
    for (let r = k; r < o.length; r++) {
        let i = o[r], a = i[m].firstChild;
        for (; a;)
            yield [a, i], a = a.next;
    } }
function* UN(e) { let n = e[m].firstChild; for (; n;)
    yield* Ka(wm(n, e)), n = n.next; }
function* wm(e, t) { yield [e, t]; for (let [n, o] of $N(e, t))
    yield* Ka(wm(n, o)); }
function* Pu(e) { for (let [t, n] of UN(e))
    t.directiveEnd > t.directiveStart && (yield [t, n]); }
function Ph(e) { let t = Ee(e); if (t === null)
    return null; if (t.component === void 0) {
    let n = t.lView;
    if (n === null)
        return null;
    t.component = VN(t.nodeIndex, n);
} return t.component; }
function GN(e) { XN(e); let t = Ee(e), n = t ? t.lView : null; return n === null ? null : n[F]; }
function WN(e) { let t = Ee(e), n = t ? t.lView : null; if (n === null)
    return null; let o; for (; n[m].type === 2 && (o = tt(n));)
    n = o; return $e(n) ? null : n[F]; }
function Fu(e) { let t = Ee(e), n = t ? t.lView : null; if (n === null)
    return me.NULL; let o = n[m].data[t.nodeIndex]; return new ye(o, n); }
function zN(e) { let t = Ee(e), n = t ? t.lView : null; if (n === null)
    return []; let o = n[m], r = o.data[t.nodeIndex], i = [], s = r.providerIndexes & 1048575, a = r.directiveEnd; for (let c = s; c < a; c++) {
    let l = o.data[c];
    JN(l) && (l = l.type), i.push(l);
} return i; }
function qN(e) { if (e instanceof Text)
    return []; let t = Ee(e), n = t ? t.lView : null; if (n === null)
    return []; let o = n[m], r = t.nodeIndex; return o?.data[r] ? (t.directives === void 0 && (t.directives = Cm(r, n)), t.directives === null ? [] : [...t.directives]) : []; }
var Sm = (function (e) { return e[e.Default = 0] = "Default", e[e.OnPush = 1] = "OnPush", e; })(Sm || {}), _m = (function (e) { return e[e.Emulated = 0] = "Emulated", e[e.None = 1] = "None", e; })(_m || {});
function QN(e) { let t = Ee(e); if (t === null)
    return {}; if (t.localRefs === void 0) {
    let n = t.lView;
    if (n === null)
        return {};
    t.localRefs = BN(n, t.nodeIndex);
} return t.localRefs || {}; }
function YN(e) { return Ee(e).native; }
function ZN(e) { let t = Ee(e), n = t === null ? null : t.lView; if (n === null)
    return []; let o = n[m], r = n[Qt], i = o.cleanup, s = []; if (i && r)
    for (let a = 0; a < i.length;) {
        let c = i[a++], l = i[a++];
        if (typeof c == "string") {
            let u = c, d = x(n[l]), f = r[i[a++]], p = i[a++], h = typeof p == "boolean" || p >= 0 ? "dom" : "output", v = typeof p == "boolean" ? p : !1;
            e == d && s.push({ element: e, name: u, callback: f, useCapture: v, type: h });
        }
    } return s.sort(KN), s; }
function KN(e, t) { return e.name == t.name ? 0 : e.name < t.name ? -1 : 1; }
function JN(e) { return e.type !== void 0 && e.declaredInputs !== void 0 && e.resolveHostDirectives !== void 0; }
function XN(e) { if (typeof Element < "u" && !(e instanceof Element))
    throw new Error("Expecting instance of DOM Element"); }
var Sl;
function ew(e) { Sl = e; }
function Ar() { if (Sl !== void 0)
    return Sl; if (typeof document < "u")
    return document; throw new M(210, !1); }
var ju = "h", Hu = "b", bm = "f", Am = "n", Rr = "e", Ls = "t", ao = "c", Or = "x", gt = "r", Ps = "i", xr = "n", co = "d", Fs = "l", js = "di", kr = "s", Vu = "p", Lr = "t", Cn = new b(""), Rm = !1, Bu = new b("", { factory: () => Rm }), $u = new b(""), Hs = new b(""), Uu = !1, Om = new b("", { factory: () => [] }), Gu = new b(""), Pr = new b("", { factory: () => new Map }), tw = new b(""), ls = { passive: !0, capture: !0 }, Xc = new WeakMap, el = new WeakMap, kt = new WeakMap, us = ["click", "keydown"], ds = ["mouseenter", "mouseover", "focusin"], Li = new Map, cr = class {
    callbacks = new Set;
    listener = () => { for (let t of this.callbacks)
        t(); };
};
function xm(e, t) { let n = el.get(e); if (!n) {
    n = new cr, el.set(e, n);
    for (let o of us)
        e.addEventListener(o, n.listener, ls);
} return n.callbacks.add(t), () => { let { callbacks: o, listener: r } = n; if (o.delete(t), o.size === 0) {
    el.delete(e);
    for (let i of us)
        e.removeEventListener(i, r, ls);
} }; }
function km(e, t) { let n = Xc.get(e); if (!n) {
    n = new cr, Xc.set(e, n);
    for (let o of ds)
        e.addEventListener(o, n.listener, ls);
} return n.callbacks.add(t), () => { let { callbacks: o, listener: r } = n; if (o.delete(t), o.size === 0) {
    for (let i of ds)
        e.removeEventListener(i, r, ls);
    Xc.delete(e);
} }; }
function nw(e) { let t = Lm(e); return new IntersectionObserver(n => { for (let o of n)
    o.isIntersecting && kt.has(o.target) && kt.get(o.target)?.get(t)?.listener(); }, e); }
function ow(e, t, n, o) { let r = Lm(o), i = kt.get(e)?.get(r); Li.has(r) || Li.set(r, { observer: n(o), count: 0 }); let s = Li.get(r); if (!i) {
    i = new cr, s.observer.observe(e);
    let a = kt.get(e);
    a ? a.set(r, i) : (a = new Map, kt.set(e, a)), a.set(r, i), s.count++;
} return i.callbacks.add(t), () => { if (kt.get(e)?.has(r)) {
    if (i.callbacks.delete(t), i.callbacks.size === 0) {
        s.observer.unobserve(e), s.count--;
        let a = kt.get(e);
        a && (a.delete(r), a.size === 0 && kt.delete(e));
    }
    s.count === 0 && (s.observer.disconnect(), Li.delete(r));
} }; }
function Lm(e) {
    return e ? `${e.rootMargin}/${typeof e.threshold == "number" ? e.threshold : e.threshold?.join(`
`)}` : "";
}
var lo = "ngb";
function Wu(e, t, n = null) { if (t.length === 0 || e.nodeType !== Node.ELEMENT_NODE)
    return; let o = e.getAttribute(jn.JSACTION), r = t.reduce((s, a) => (o?.indexOf(a) ?? -1) === -1 ? s + a + ":;" : s, ""); e.setAttribute(jn.JSACTION, `${o ?? ""}${r}`); let i = n ?? ""; i !== "" && r.length > 0 && e.setAttribute(lo, i); }
var Pm = (e, t, n) => { let o = e, r = o.__jsaction_fns ?? new Map, i = r.get(t) ?? []; i.push(n), r.set(t, i), o.__jsaction_fns = r; }, zu = (e, t) => { let n = e, o = n.getAttribute(lo) ?? "", r = t.get(o) ?? new Set; r.has(n) || r.add(n), t.set(o, r); };
function rw(e, t) { if (e.length > 0) {
    let n = [];
    for (let r of e)
        t.has(r) && (n = [...n, ...t.get(r)]);
    new Set(n).forEach(qu);
} }
var qu = e => { e.removeAttribute(jn.JSACTION), e.removeAttribute(lo), e.__jsaction_fns = void 0; }, Qu = new b("", { factory: () => ({}) }), _l = new WeakMap;
function iw(e, t) { if (e == null || typeof e != "object")
    return; let n = _l.get(e); n || (n = new WeakSet, _l.set(e, n)), n.add(t); }
function Yu(e, t) { let n = t?.__jsaction_fns?.get(e.type); if (!(!n || !t?.isConnected) && !(t && _l.get(e)?.has(t)))
    for (let o of n)
        o(e); }
var bl = new Map;
function Fm(e, t) { return bl.set(e, t), () => bl.delete(e); }
var Fh = !1, jm = (e, t, n, o) => { };
function sw(e, t, n, o) { jm(e, t, n, o); }
function Hm() { Fh || (jm = (e, t, n, o) => { let r = e[O].get(dt); bl.get(r)?.(t, n, o); }, Fh = !0); }
var It = new b(""), aw = (() => { class e {
    registry = new Map;
    cleanupFns = new Map;
    jsActionMap = D(Pr);
    contract = D(Qu);
    add(n, o) { if (this.registry.set(n, o), this.awaitingCallbacks.has(n)) {
        let r = this.awaitingCallbacks.get(n);
        for (let i of r)
            i();
    } }
    get(n) { return this.registry.get(n) ?? null; }
    has(n) { return this.registry.has(n); }
    cleanup(n) { rw(n, this.jsActionMap); for (let o of n)
        this.registry.delete(o), this.jsActionMap.delete(o), this.invokeTriggerCleanupFns(o), this.hydrating.delete(o), this.awaitingCallbacks.delete(o); this.size === 0 && this.contract.instance?.cleanUp(); }
    get size() { return this.registry.size; }
    addCleanupFn(n, o) { let r = []; this.cleanupFns.has(n) && (r = this.cleanupFns.get(n)), r.push(o), this.cleanupFns.set(n, r); }
    invokeTriggerCleanupFns(n) { let o = this.cleanupFns.get(n) ?? []; for (let r of o)
        r(); this.cleanupFns.delete(n); }
    hydrating = new Map;
    awaitingCallbacks = new Map;
    awaitParentBlock(n, o) { let r = this.awaitingCallbacks.get(n) ?? []; r.push(o), this.awaitingCallbacks.set(n, r); }
    static \u0275prov = ae({ token: e, providedIn: null, factory: () => new e });
} return e; })();
function uo(e) { return (e.flags & 32) === 32; }
var Vm = "__nghData__", Vs = Vm, Bm = "__nghDeferData__", Bs = Bm;
function cw(e) { return e === Vm || e === Bm; }
var zn = "ngh", $m = "nghm", Um = () => null;
function lw(e, t, n = !1) { let o = e.getAttribute(zn); if (o == null)
    return null; let [r, i] = o.split("|"); if (o = n ? i : r, !o)
    return null; let s = i ? `|${i}` : "", a = n ? r : s, c = {}; if (o !== "") {
    let u = t.get(tn, null, { optional: !0 });
    u !== null && (c = u.get(Vs, [])[Number(o)]);
} let l = { data: c, firstChild: e.firstChild ?? null }; return n && (l.firstChild = e, $s(l, 0, e.nextSibling)), a ? e.setAttribute(zn, a) : e.removeAttribute(zn), l; }
function Gm() { Um = lw; }
function Wm(e, t, n = !1) { return Um(e, t, n); }
function Zu(e) { let t = e._lView; return t[m].type === 2 ? null : ($e(t) && (t = t[E]), t); }
function uw(e) { return e.textContent?.replace(/\s/gm, ""); }
function dw(e) { let t = Ar(), n = t.createNodeIterator(e, NodeFilter.SHOW_COMMENT, { acceptNode(i) { let s = uw(i); return s === "ngetn" || s === "ngtns" ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; } }), o, r = []; for (; o = n.nextNode();)
    r.push(o); for (let i of r)
    i.textContent === "ngetn" ? i.replaceWith(t.createTextNode("")) : i.remove(); }
var zm = (function (e) { return e.Hydrated = "hydrated", e.Skipped = "skipped", e.Mismatched = "mismatched", e; })(zm || {}), fw = "__ngDebugHydrationInfo__";
function pw(e) { return e[fw] ?? null; }
function $s(e, t, n) { e.segmentHeads ??= {}, e.segmentHeads[t] = n; }
function Al(e, t) { return e.segmentHeads?.[t] ?? null; }
function Fr(e) { return e.get(Gu, !1, { optional: !0 }); }
var hw = !1;
function gw() { hw = !1; }
function qm(e, t) { let n = e.data, o = n[Rr]?.[t] ?? null; return o === null && n[ao]?.[t] && (o = Ku(e, t)), o; }
function mw(e, t) { return e.data[Rr]?.[t] !== void 0; }
function Qm(e, t) { return e.data[ao]?.[t] ?? null; }
function Ku(e, t) { let n = Qm(e, t) ?? [], o = 0; for (let r of n)
    o += r[gt] * (r[Or] ?? 1); return o; }
function Ym(e) { if (typeof e.disconnectedNodes > "u") {
    let t = e.data[co];
    e.disconnectedNodes = t ? new Set(t) : null;
} return e.disconnectedNodes; }
function Us(e, t) { if (typeof e.disconnectedNodes > "u") {
    let n = e.data[co];
    e.disconnectedNodes = n ? new Set(n) : null;
} return !!Ym(e)?.has(t); }
function Gs(e, t) { let n = e[ce]; return n !== null && !Vo() && !uo(t) && !Us(n, t.index - E); }
function Ju(e, t) { let n = t, o = e.corruptedTextNodes; n.textContent === "" ? o.set(n, "ngetn") : n.nextSibling?.nodeType === Node.TEXT_NODE && o.set(n, "ngtns"); }
function Zm(e) { let t = []; return e !== null && (e.has(4) && t.push(...ds), e.has(3) && t.push(...us)), t; }
function vw(e, t) { let n = t.get(It), r = t.get(tn).get(Bs, {}), i = !1, s = e, a = null, c = []; for (; !i && s;) {
    i = n.has(s);
    let l = n.hydrating.get(s);
    if (a === null && l != null) {
        a = l.promise;
        break;
    }
    c.unshift(s), s = r[s][Vu];
} return { parentBlockPromise: a, hydrationQueue: c }; }
function yw(e) { let t = e.body.querySelectorAll("[jsaction]"), n = new Set, o = [ds.join(":;"), us.join(":;")].join("|"); for (let r of t) {
    let i = r.getAttribute("jsaction"), s = r.getAttribute("ngb");
    i?.match(o) && s !== null && n.add(r);
} return n; }
function Ew(e, t) { let n = yw(e), o = t.get(Pr); for (let r of n)
    zu(r, o); }
var Km = () => ({});
function Iw(e) { let t = e.get(tn, null, { optional: !0 }); return t !== null ? t.get(Bs, {}) : {}; }
function Dw() { Km = Iw; }
function Cw(e) { return Km(e); }
function Tw(e) { return typeof e == "object" && e.trigger === 5; }
function Mw(e) { return e[Lr]?.find(n => Tw(n))?.delay ?? null; }
function Nw(e) { let t = e[Lr]; if (t)
    for (let n of t) {
        if (n === 2)
            return !0;
        if (typeof n == "object" && n.trigger === 2)
            return n.intersectionObserverOptions || !0;
    } return null; }
function jh(e, t) { return e[Lr]?.includes(t) ?? !1; }
function ww(e) { return { data: e, hydrate: { idle: jh(e, 0), immediate: jh(e, 1), timer: Mw(e), viewport: Nw(e) } }; }
function Sw(e) { let t = Cw(e), n = new Map; for (let o in t)
    n.set(o, ww(t[o])); return n; }
function tl(e) { return !!e && e.nodeType === Node.COMMENT_NODE && e.textContent?.trim() === $m; }
function Hh(e) { for (; e && e.nodeType === Node.TEXT_NODE;)
    e = e.previousSibling; return e; }
function Jm(e) { for (let o of e.body.childNodes)
    if (tl(o))
        return; let t = Hh(e.body.previousSibling); if (tl(t))
    return; let n = Hh(e.head.lastChild); if (!tl(n))
    throw new M(-507, !1); }
function Xm(e, t) { let n = e.contentQueries; if (n !== null) {
    let o = R(null);
    try {
        for (let r = 0; r < n.length; r += 2) {
            let i = n[r], s = n[r + 1];
            if (s !== -1) {
                let a = e.data[s];
                Bo(i), a.contentQueries(2, t[s], s);
            }
        }
    }
    finally {
        R(o);
    }
} }
function Rl(e, t, n) { Bo(0); let o = R(null); try {
    t(e, n);
}
finally {
    R(o);
} }
function Xu(e, t, n) { if (gc(t)) {
    let o = R(null);
    try {
        let r = t.directiveStart, i = t.directiveEnd;
        for (let s = r; s < i; s++) {
            let a = e.data[s];
            if (a.contentQueries) {
                let c = n[s];
                a.contentQueries(1, c, s);
            }
        }
    }
    finally {
        R(o);
    }
} }
var Pe = (function (e) { return e[e.Emulated = 0] = "Emulated", e[e.None = 2] = "None", e[e.ShadowDom = 3] = "ShadowDom", e[e.ExperimentalIsolatedShadowDom = 4] = "ExperimentalIsolatedShadowDom", e; })(Pe || {}), _w = { name: "custom-elements" }, bw = { name: "no-errors-schema" }, ev = !1;
function Aw(e) { ev = e; }
function Rw() { return ev; }
var tv = !1;
function Ow(e) { tv = e; }
function xw() { return tv; }
var nv = { "http://www.w3.org/2000/svg": Ii, "http://www.w3.org/1998/Math/MathML": vc }, Pi;
function ov() { if (Pi === void 0 && (Pi = null, Me.trustedTypes))
    try {
        Pi = Me.trustedTypes.createPolicy("angular", { createHTML: e => e, createScript: e => e, createScriptURL: e => e });
    }
    catch { } return Pi; }
function fo(e) { return ov()?.createHTML(e) || e; }
function kw(e) { return ov()?.createScriptURL(e) || e; }
var Fi;
function ed() { if (Fi === void 0 && (Fi = null, Me.trustedTypes))
    try {
        Fi = Me.trustedTypes.createPolicy("angular#unsafe-bypass", { createHTML: e => e, createScript: e => e, createScriptURL: e => e });
    }
    catch { } return Fi; }
function Vh(e) { return ed()?.createHTML(e) || e; }
function Bh(e) { return ed()?.createScript(e) || e; }
function $h(e) { return ed()?.createScriptURL(e) || e; }
var mt = class {
    changingThisBreaksApplicationSecurity;
    constructor(t) { this.changingThisBreaksApplicationSecurity = t; }
    toString() { return `SafeValue must use [property]=binding: ${this.changingThisBreaksApplicationSecurity} (see ${ai})`; }
}, Ol = class extends mt {
    getTypeName() { return "HTML"; }
}, xl = class extends mt {
    getTypeName() { return "Style"; }
}, kl = class extends mt {
    getTypeName() { return "Script"; }
}, Ll = class extends mt {
    getTypeName() { return "URL"; }
}, Pl = class extends mt {
    getTypeName() { return "ResourceURL"; }
};
function st(e) { return e instanceof mt ? e.changingThisBreaksApplicationSecurity : e; }
function po(e, t) { let n = rv(e); if (n != null && n !== t) {
    if (n === "ResourceURL" && t === "URL")
        return !0;
    throw new Error(`Required a safe ${t}, got a ${n} (see ${ai})`);
} return n === t; }
function rv(e) { return e instanceof mt && e.getTypeName() || null; }
function Lw(e) { return new Ol(e); }
function Pw(e) { return new xl(e); }
function Fw(e) { return new kl(e); }
function jw(e) { return new Ll(e); }
function Hw(e) { return new Pl(e); }
function iv(e) { let t = new jl(e); return Vw() ? new Fl(t) : t; }
var Fl = class {
    inertDocumentHelper;
    constructor(t) { this.inertDocumentHelper = t; }
    getInertBodyElement(t) { t = "<body><remove></remove>" + t; try {
        let n = new window.DOMParser().parseFromString(fo(t), "text/html").body;
        return n === null ? this.inertDocumentHelper.getInertBodyElement(t) : (n.firstChild?.remove(), n);
    }
    catch {
        return null;
    } }
}, jl = class {
    defaultDoc;
    inertDocument;
    constructor(t) { this.defaultDoc = t, this.inertDocument = this.defaultDoc.implementation.createHTMLDocument("sanitization-inert"); }
    getInertBodyElement(t) { let n = this.inertDocument.createElement("template"); return n.innerHTML = fo(t), n; }
};
function Vw() { try {
    return !!new window.DOMParser().parseFromString(fo(""), "text/html");
}
catch {
    return !1;
} }
var Bw = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i;
function Ws(e) { return e = String(e), e.match(Bw) ? e : "unsafe:" + e; }
function Dt(e) { let t = Object.create(null); for (let n of e.split(","))
    t[n] = !0; return t; }
function jr(...e) { let t = Object.create(null); for (let n of e)
    for (let o in n)
        Object.hasOwn(n, o) && (t[o] = !0); return t; }
var sv = Dt("area,br,col,hr,img,wbr"), av = Dt("colgroup,dd,dt,li,p,tbody,td,tfoot,th,thead,tr"), cv = Dt("rp,rt"), $w = jr(cv, av), Uw = jr(av, Dt("address,article,aside,blockquote,caption,center,del,details,dialog,dir,div,dl,figure,figcaption,footer,h1,h2,h3,h4,h5,h6,header,hgroup,hr,ins,main,map,menu,nav,ol,pre,section,summary,table,ul")), Gw = jr(cv, Dt("a,abbr,acronym,audio,b,bdi,bdo,big,br,cite,code,del,dfn,em,font,i,img,ins,kbd,label,map,mark,picture,q,ruby,rp,rt,s,samp,small,source,span,strike,strong,sub,sup,time,track,tt,u,var,video")), Hl = jr(sv, Uw, Gw, $w), lv = Dt("background,cite,href,itemtype,longdesc,poster,src,xlink:href"), Ww = Dt("abbr,accesskey,align,alt,autoplay,axis,bgcolor,border,cellpadding,cellspacing,class,clear,color,cols,colspan,compact,controls,coords,datetime,default,dir,download,face,headers,height,hidden,hreflang,hspace,ismap,itemscope,itemprop,kind,label,lang,language,loop,media,muted,nohref,nowrap,open,preload,rel,rev,role,rows,rowspan,rules,scope,scrolling,shape,size,sizes,span,srclang,srcset,start,summary,tabindex,target,title,translate,type,usemap,valign,value,vspace,width"), zw = Dt("aria-activedescendant,aria-atomic,aria-autocomplete,aria-busy,aria-checked,aria-colcount,aria-colindex,aria-colspan,aria-controls,aria-current,aria-describedby,aria-details,aria-disabled,aria-dropeffect,aria-errormessage,aria-expanded,aria-flowto,aria-grabbed,aria-haspopup,aria-hidden,aria-invalid,aria-keyshortcuts,aria-label,aria-labelledby,aria-level,aria-live,aria-modal,aria-multiline,aria-multiselectable,aria-orientation,aria-owns,aria-placeholder,aria-posinset,aria-pressed,aria-readonly,aria-relevant,aria-required,aria-roledescription,aria-rowcount,aria-rowindex,aria-rowspan,aria-selected,aria-setsize,aria-sort,aria-valuemax,aria-valuemin,aria-valuenow,aria-valuetext"), Vl = jr(lv, Ww, zw), qw = Dt("script,style,template"), Bl = class {
    sanitizedSomething = !1;
    buf = [];
    sanitizeChildren(t) { let n = t.firstChild, o = !0, r = []; for (; n;) {
        if (n.nodeType === Node.ELEMENT_NODE ? o = this.startElement(n) : n.nodeType === Node.TEXT_NODE ? this.chars(n.nodeValue) : this.sanitizedSomething = !0, o && n.firstChild) {
            r.push(n), n = Zw(n);
            continue;
        }
        for (; n;) {
            n.nodeType === Node.ELEMENT_NODE && this.endElement(n);
            let i = Yw(n);
            if (i) {
                n = i;
                break;
            }
            n = r.pop();
        }
    } return this.buf.join(""); }
    startElement(t) { let n = Uh(t).toLowerCase(); if (!Object.hasOwn(Hl, n))
        return this.sanitizedSomething = !0, !Object.hasOwn(qw, n); this.buf.push("<"), this.buf.push(n); let o = t.attributes; for (let r = 0; r < o.length; r++) {
        let i = o.item(r), s = i.name, a = s.toLowerCase();
        if (!Object.hasOwn(Vl, a)) {
            this.sanitizedSomething = !0;
            continue;
        }
        let c = i.value;
        lv[a] && (c = Ws(c)), this.buf.push(" ", s, '="', Gh(c), '"');
    } return this.buf.push(">"), !0; }
    endElement(t) { let n = Uh(t).toLowerCase(); Object.hasOwn(Hl, n) && !Object.hasOwn(sv, n) && (this.buf.push("</"), this.buf.push(n), this.buf.push(">")); }
    chars(t) { this.buf.push(Gh(t)); }
};
function Qw(e, t) { return (e.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY) !== Node.DOCUMENT_POSITION_CONTAINED_BY; }
function Yw(e) { let t = e.nextSibling; if (t && e !== t.previousSibling)
    throw uv(t); return t; }
function Zw(e) { let t = e.firstChild; if (t && Qw(e, t))
    throw uv(t); return t; }
function Uh(e) { let t = e.nodeName; return typeof t == "string" ? t : "FORM"; }
function uv(e) { return new Error(`Failed to sanitize html because the element is clobbered: ${e.outerHTML}`); }
var Kw = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g, Jw = /([^\#-~ |!])/g;
function Gh(e) { return e.replace(/&/g, "&amp;").replace(Kw, function (t) { let n = t.charCodeAt(0), o = t.charCodeAt(1); return "&#" + ((n - 55296) * 1024 + (o - 56320) + 65536) + ";"; }).replace(Jw, function (t) { return "&#" + t.charCodeAt(0) + ";"; }).replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
var ji;
function dv(e, t) { let n = null; try {
    ji = ji || iv(e);
    let o = t ? String(t) : "";
    n = ji.getInertBodyElement(o);
    let r = 5, i = o;
    do {
        if (r === 0)
            throw new Error("Failed to sanitize html because the input is unstable");
        r--, o = i, i = n.innerHTML, n = ji.getInertBodyElement(o);
    } while (o !== i);
    let a = new Bl().sanitizeChildren($l(n) || n);
    return fo(a);
}
finally {
    if (n) {
        let o = $l(n) || n;
        for (; o.firstChild;)
            o.firstChild.remove();
    }
} }
function $l(e) { return "content" in e && Xw(e) ? e.content : null; }
function Xw(e) { return e.nodeType === Node.ELEMENT_NODE && e.nodeName === "TEMPLATE"; }
var eS = /^>|^->|<!--|-->|--!>|<!-$/g, tS = /(<|>)/g, nS = "\u200B$1\u200B";
function oS(e) { return e.replace(eS, t => t.replace(tS, nS)); }
function td(e, t) { return e.createText(t); }
function fv(e, t, n) { e.setValue(t, n); }
function nd(e, t) { return e.createComment(oS(t)); }
function zs(e, t, n) { return e.createElement(t, n); }
function ze(e, t, n, o, r) { e.insertBefore(t, n, o, r); }
function pv(e, t, n) { e.appendChild(t, n); }
function Wh(e, t, n, o, r) { o !== null ? ze(e, t, n, o, r) : pv(e, t, n); }
function Hr(e, t, n, o) { e.removeChild(null, t, n, o); }
function hv(e) { e.textContent = ""; }
function rS(e, t, n) { e.setAttribute(t, "style", n); }
function iS(e, t, n) { n === "" ? e.removeAttribute(t, "class") : e.setAttribute(t, "class", n); }
function gv(e, t, n) { let { mergedAttrs: o, classes: r, styles: i } = n; o !== null && XM(e, t, o), r !== null && iS(e, t, r), i !== null && rS(e, t, i); }
function sS(e) { let t = g(); e.src = "", e.srcdoc = fo(""), Hr(t[C], e); }
function mv(e, t = !0) { if (e[0] != ":")
    return [null, e]; let n = e.indexOf(":", 1); if (n === -1) {
    if (t)
        throw new Error(`Unsupported format "${e}" expecting ":namespace:name"`);
    return [null, e];
} return [e.slice(1, n), e.slice(n + 1)]; }
function od(e, t, n) { if (t !== void 0 && n !== void 0 && Iv(t, n) !== de.HTML)
    return e; let o = Vr(); return o ? Vh(o.sanitize(de.HTML, e) || "") : po(e, "HTML") ? Vh(st(e)) : dv(Ar(), S(e)); }
function rd(e) { let t = Vr(); return t ? t.sanitize(de.STYLE, e) || "" : po(e, "Style") ? st(e) : S(e); }
function id(e) { let t = Vr(); return t ? t.sanitize(de.URL, e) || "" : po(e, "URL") ? st(e) : Ws(S(e)); }
function qs(e) { let t = Vr(); if (t)
    return $h(t.sanitize(de.RESOURCE_URL, e) || ""); if (po(e, "ResourceURL"))
    return $h(st(e)); throw new M(904, !1); }
function sd(e) { let t = Vr(); if (t)
    return Bh(t.sanitize(de.SCRIPT, e) || ""); if (po(e, "Script"))
    return Bh(st(e)); throw new M(905, !1); }
function vv(e) { return fo(e[0]); }
function yv(e) { return kw(e[0]); }
function aS(e, t) { switch (Iv(e, t)) {
    case de.RESOURCE_URL: return qs;
    case de.URL: return id;
    default: return null;
} }
function Ev(e, t, n) { return aS(t, n)?.(e) ?? e; }
function Vr() { let e = g(); return e && e[Ke].sanitizer; }
function Iv(e, t) { let [n, o] = Dv(e); return ko(o, t, n); }
function Dv(e) { e = e.toLowerCase(); let t = mv(e, !1); if (t[0])
    return t; let o = ne() === -1 ? null : Ce(), r = o?.namespace; if (e === "#host" && o?.type === 2) {
    let i = Z(o, g());
    if (i.tagName && (e = i.tagName.toLowerCase()), r == null) {
        let s = i.namespaceURI;
        r = s && nv[s];
    }
} return [r, e]; }
var Hi = new Set(["href", "xlink:href"]), cS = { animate: { to: Hi, values: Hi, from: Hi }, set: { to: Hi } };
function ad(e, t, n) { let r = ne() === -1 ? null : Ce(); if (r && r.type !== 2)
    return e; let [i, s] = Dv(t); if (ko(s, n, i) !== de.ATTRIBUTE_NO_BINDING)
    return e; let c = g(); if (r) {
    if (s === "iframe") {
        let u = Z(r, c);
        sS(u);
    }
    else if (i === Ii) {
        let u = cS[s]?.[n.toLowerCase()];
        if (u) {
            let d = Z(r, c);
            if (lS(d, u))
                throw new M(-910, !1);
            return e;
        }
    }
} let l = !1; throw new M(-910, l); }
function lS(e, t) { for (let n of e.getAttributeNames()) {
    if (n.toLowerCase() !== "attributename")
        continue;
    let o = e.getAttribute(n);
    if (o !== null && t.has(o.toLowerCase()))
        return o;
} return null; }
function uS() { return Be([]); }
function Cv(e) { return e.ownerDocument.defaultView; }
function Tv(e) { return e.ownerDocument; }
function cd(e) { return e.ownerDocument.body; }
var dS = "\uFFFD";
function zo(e) { return e instanceof Function ? e() : e; }
function fS(e, t, n) { let o = e.length; for (;;) {
    let r = e.indexOf(t, n);
    if (r === -1)
        return r;
    if (r === 0 || e.charCodeAt(r - 1) <= 32) {
        let i = t.length;
        if (r + i === o || e.charCodeAt(r + i) <= 32)
            return r;
    }
    n = r + 1;
} }
var Mv = "ng-template";
function pS(e, t, n, o) { let r = 0; if (o) {
    for (; r < t.length && typeof t[r] == "string"; r += 2)
        if (t[r] === "class" && fS(t[r + 1].toLowerCase(), n, 0) !== -1)
            return !0;
}
else if (ld(e))
    return !1; if (r = t.indexOf(1, r), r > -1) {
    let i;
    for (; ++r < t.length && typeof (i = t[r]) == "string";)
        if (i.toLowerCase() === n)
            return !0;
} return !1; }
function ld(e) { return e.type === 4 && e.value !== Mv; }
function hS(e, t, n) { let o = e.type === 4 && !n ? Mv : e.value; return t === o; }
function gS(e, t, n) { let o = 4, r = e.attrs, i = r !== null ? yS(r) : 0, s = !1; for (let a = 0; a < t.length; a++) {
    let c = t[a];
    if (typeof c == "number") {
        if (!s && !We(o) && !We(c))
            return !1;
        if (s && We(c))
            continue;
        s = !1, o = c | o & 1;
        continue;
    }
    if (!s)
        if (o & 4) {
            if (o = 2 | o & 1, c !== "" && !hS(e, c, n) || c === "" && t.length === 1) {
                if (We(o))
                    return !1;
                s = !0;
            }
        }
        else if (o & 8) {
            if (r === null || !pS(e, r, c, n)) {
                if (We(o))
                    return !1;
                s = !0;
            }
        }
        else {
            let l = t[++a], u = mS(c, r, ld(e), n);
            if (u === -1) {
                if (We(o))
                    return !1;
                s = !0;
                continue;
            }
            if (l !== "") {
                let d;
                if (u > i ? d = "" : d = r[u + 1].toLowerCase(), o & 2 && l !== d) {
                    if (We(o))
                        return !1;
                    s = !0;
                }
            }
        }
} return We(o) || s; }
function We(e) { return (e & 1) === 0; }
function mS(e, t, n, o) { if (t === null)
    return -1; let r = 0; if (o || !n) {
    let i = !1;
    for (; r < t.length;) {
        let s = t[r];
        if (s === e)
            return r;
        if (s === 3 || s === 6)
            i = !0;
        else if (s === 1 || s === 2) {
            let a = t[++r];
            for (; typeof a == "string";)
                a = t[++r];
            continue;
        }
        else {
            if (s === 4)
                break;
            if (s === 0) {
                r += 4;
                continue;
            }
        }
        r += i ? 1 : 2;
    }
    return -1;
}
else
    return ES(t, e); }
function Nv(e, t, n = !1) { for (let o = 0; o < t.length; o++)
    if (gS(e, t[o], n))
        return !0; return !1; }
function vS(e) { let t = e.attrs; if (t != null) {
    let n = t.indexOf(5);
    if ((n & 1) === 0)
        return t[n + 1];
} return null; }
function yS(e) { for (let t = 0; t < e.length; t++) {
    let n = e[t];
    if (Xg(n))
        return t;
} return e.length; }
function ES(e, t) { let n = e.indexOf(4); if (n > -1)
    for (n++; n < e.length;) {
        let o = e[n];
        if (typeof o == "number")
            return -1;
        if (o === t)
            return n;
        n++;
    } return -1; }
function IS(e, t) { e: for (let n = 0; n < t.length; n++) {
    let o = t[n];
    if (e.length === o.length) {
        for (let r = 0; r < e.length; r++)
            if (e[r] !== o[r])
                continue e;
        return !0;
    }
} return !1; }
function zh(e, t) { return e ? ":not(" + t.trim() + ")" : t; }
function DS(e) { let t = e[0], n = 1, o = 2, r = "", i = !1; for (; n < e.length;) {
    let s = e[n];
    if (typeof s == "string")
        if (o & 2) {
            let a = e[++n];
            r += "[" + s + (a.length > 0 ? '="' + a + '"' : "") + "]";
        }
        else
            o & 8 ? r += "." + s : o & 4 && (r += " " + s);
    else
        r !== "" && !We(s) && (t += zh(i, r), r = ""), o = s, i = i || !We(o);
    n++;
} return r !== "" && (t += zh(i, r)), t; }
function CS(e) { return e.map(DS).join(","); }
function TS(e) { let t = [], n = [], o = 1, r = 2; for (; o < e.length;) {
    let i = e[o];
    if (typeof i == "string")
        r === 2 ? i !== "" && t.push(i, e[++o]) : r === 8 && n.push(i);
    else {
        if (!We(r))
            break;
        r = i;
    }
    o++;
} return n.length && t.push(1, ...n), t; }
var j = {}, fs = (function (e) { return e[e.Important = 1] = "Important", e[e.DashCase = 2] = "DashCase", e; })(fs || {}), Ul;
function ud(e, t) { return Ul(e, t); }
function MS(e) { Ul === void 0 && (Ul = e()); }
var wv = new b("", { factory: () => !1 }), Sv = new b("", { factory: () => NS }), NS = 4e3;
function ps(e) { if (!e)
    return 0; let t = e.toLowerCase().indexOf("ms") > -1 ? 1 : 1e3; return parseFloat(e) * t; }
function an(e, t) { return e.getPropertyValue(t).split(",").map(o => o.trim()); }
function wS(e) { let t = an(e, "transition-property"), n = an(e, "transition-duration"), o = an(e, "transition-delay"), r = { propertyName: "", duration: 0, animationName: void 0 }; for (let i = 0; i < t.length; i++) {
    let s = ps(o[i]) + ps(n[i]);
    s > r.duration && (r.propertyName = t[i], r.duration = s);
} return r; }
function SS(e) { let t = an(e, "animation-name"), n = an(e, "animation-delay"), o = an(e, "animation-duration"), r = an(e, "animation-iteration-count"), i = { animationName: "", propertyName: void 0, duration: 0 }; for (let s = 0; s < t.length; s++) {
    let a = ps(n[s]) + ps(o[s]), c = r[s];
    a > i.duration && c !== "infinite" && (i.animationName = t[s], i.duration = a);
} return i; }
function _v(e, t) { return e !== void 0 && e.duration > t.duration; }
function bv(e) { return (e.animationName != null || e.propertyName != null) && e.duration > 0; }
function Av(e) { let t = e.effect?.getTiming(); if (t === void 0)
    return; let n = typeof t.duration == "number" ? t.duration : 0, o = (t.delay ?? 0) + n, r = e.playbackRate; return r !== void 0 && r !== 0 && r !== 1 && (o /= Math.abs(r)), o; }
function _S(e, t) { let n = getComputedStyle(e), o = SS(n), r = wS(n), i = o.duration > r.duration ? o : r; _v(t.get(e), i) || bv(i) && t.set(e, i); }
function Rv(e, t, n) { if (!n)
    return; let o = e.getAnimations(); return o.length === 0 ? _S(e, t) : bS(e, t, o); }
function bS(e, t, n) { let o = { animationName: void 0, propertyName: void 0, duration: 0 }; for (let r of n) {
    if (r.effect?.getTiming()?.iterations === 1 / 0)
        continue;
    let s = Av(r) ?? 0, a, c;
    r.animationName ? c = r.animationName : a = r.transitionProperty, s >= o.duration && (o = { animationName: c, propertyName: a, duration: s });
} _v(t.get(e), o) || bv(o) && t.set(e, o); }
var Ft = new Set, AS = !1, RS = 1, Tn = (typeof ngServerMode > "u" || !ngServerMode) && typeof document < "u" && typeof document?.documentElement?.getAnimations == "function";
function Qs(e) { return e[O].get(wv, AS); }
function OS(e, t, n) { let o = Kn.get(e); if (o) {
    for (let r of t)
        o.classList.push(r);
    for (let r of n)
        o.cleanupFns.push(r);
}
else
    Kn.set(e, { classList: t, cleanupFns: n }); }
function dd(e) { let t = Kn.get(e); if (t) {
    for (let n of t.cleanupFns)
        n();
    Kn.delete(e);
} ln.delete(e); }
var xS = () => { }, Kn = new WeakMap, ln = new WeakMap, lr = new WeakMap;
function Ov(e) { return e ? e[An] ?? e : null; }
var qo = new WeakSet;
function Gl(e, t) { let n = lr.get(e); if (n && n.length > 0) {
    let o = n.findIndex(r => r.el === t);
    o > -1 && n.splice(o, 1);
} n?.length === 0 && lr.delete(e); }
function kS(e, t, n) { let o = lr.get(e); if (!o || o.length === 0)
    return; let r = t.parentNode, i = t.previousSibling, s = Ov(n); for (let a = o.length - 1; a >= 0; a--) {
    let { el: c, declarationView: l } = o[a], u = c.parentNode;
    c === t ? (o.splice(a, 1), qo.add(c), c.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: !0 } }))) : i && c === i ? (o.splice(a, 1), c.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: !0 } })), c.parentNode?.removeChild(c)) : u && r && u !== r && (s === null || l === null || s === l) && (o.splice(a, 1), c.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: !0 } })), c.parentNode?.removeChild(c));
} }
function fd(e, t, n) { let o = Ov(n), r = lr.get(e); r ? r.some(i => i.el === t) || r.push({ el: t, declarationView: o }) : lr.set(e, [{ el: t, declarationView: o }]); }
function hs(e) { let t = e[ke] ??= {}; return t.enter ??= new Map; }
function dn(e) { let t = e[ke] ??= {}; return t.leave ??= new Map; }
function xv(e) { let t = typeof e == "function" ? e() : e, n = Array.isArray(t) ? t : null; return typeof t == "string" && (n = t.trim().split(/\s+/).filter(o => o)), n; }
function LS(e, t) { if (!Tn)
    return; let n = Kn.get(e); if (n && n.classList.length > 0 && PS(e, n.classList))
    for (let o of n.classList)
        t.removeClass(e, o); dd(e); }
function PS(e, t) { for (let n of t)
    if (e.classList.contains(n))
        return !0; return !1; }
function ur(e) { return e.composedPath ? e.composedPath()[0] : e.target; }
function pd(e, t) { let n = ln.get(t); if (n === void 0)
    return !0; if (t !== ur(e))
    return !1; let o = e.animation; if (o) {
    let r = Av(o);
    if (r !== void 0 && r + RS < n.duration)
        return !1;
} return n.animationName !== void 0 ? e.animationName === n.animationName : n.propertyName !== void 0 ? n.propertyName === "all" || e.propertyName === n.propertyName : !1; }
function Ys(e, t, n) { let o = e.get(t.index) ?? { animateFns: [] }; o.animateFns.push(n), e.set(t.index, o); }
function Wl(e, t) { if (e)
    for (let n of e)
        n(); for (let n of t)
    n(); }
function zl(e, t) { let n = dn(e).get(t.index); n && (n.resolvers = void 0); }
function Vi(e, t, n, o, r) { Gl(t, n), Wl(o, r), zl(e, t); }
var Zs = (function (e) { return e[e.CHANGE_DETECTION = 0] = "CHANGE_DETECTION", e[e.AFTER_NEXT_RENDER = 1] = "AFTER_NEXT_RENDER", e; })(Zs || {}), Mn = new b(""), qh = new Set;
function K(e) { qh.has(e) || (qh.add(e), performance?.mark?.("mark_feature_usage", { detail: { feature: e } })); }
var Ks = (() => { class e {
    impl = null;
    execute() { this.impl?.execute(); }
    static \u0275prov = ae({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), hd = [0, 1, 2, 3], gd = (() => { class e {
    ngZone = D(B);
    scheduler = D(Ot);
    errorHandler = D(Bc, { optional: !0 });
    sequences = new Set;
    deferredRegistrations = new Set;
    executing = !1;
    constructor() { D(Mn, { optional: !0 }); }
    execute() { let n = this.sequences.size > 0; n && P(L.AfterRenderHooksStart), this.executing = !0; for (let o of hd)
        for (let r of this.sequences)
            if (!(r.erroredOrDestroyed || !r.hooks[o]))
                try {
                    r.pipelinedValue = this.ngZone.runOutsideAngular(() => this.maybeTrace(() => { let i = r.hooks[o]; return i(r.pipelinedValue); }, r.snapshot));
                }
                catch (i) {
                    r.erroredOrDestroyed = !0, this.errorHandler?.handleError(i);
                } this.executing = !1; for (let o of this.sequences)
        o.afterRun(), o.once && (this.sequences.delete(o), o.destroy()); for (let o of this.deferredRegistrations)
        this.sequences.add(o); this.deferredRegistrations.size > 0 && this.scheduler.notify(7), this.deferredRegistrations.clear(), n && P(L.AfterRenderHooksEnd); }
    register(n) { let { view: o } = n; o !== void 0 ? ((o[Yt] ??= []).push(n), Ci(o), o[_] |= 8192) : this.executing ? this.deferredRegistrations.add(n) : this.addSequence(n); }
    addSequence(n) { this.sequences.add(n), this.scheduler.notify(7); }
    unregister(n) { this.executing && this.sequences.has(n) ? (n.erroredOrDestroyed = !0, n.pipelinedValue = void 0, n.once = !0) : (this.sequences.delete(n), this.deferredRegistrations.delete(n)); }
    maybeTrace(n, o) { return o ? o.run(Zs.AFTER_NEXT_RENDER, n) : n(); }
    static \u0275prov = ae({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), dr = class {
    impl;
    hooks;
    view;
    once;
    snapshot;
    erroredOrDestroyed = !1;
    pipelinedValue = void 0;
    unregisterOnDestroy;
    constructor(t, n, o, r, i, s = null) { this.impl = t, this.hooks = n, this.view = o, this.once = r, this.snapshot = s, this.unregisterOnDestroy = i?.onDestroy(() => this.destroy()); }
    afterRun() { this.erroredOrDestroyed = !1, this.pipelinedValue = void 0, this.snapshot?.dispose(), this.snapshot = null; }
    destroy() { this.impl.unregister(this), this.unregisterOnDestroy?.(); let t = this.view?.[Yt]; t && (this.view[Yt] = t.filter(n => n !== this)); }
};
function kv(e, t) { let n = t?.injector ?? D(me); return typeof ngServerMode < "u" && ngServerMode ? Js : (K("NgAfterRender"), Lv(e, n, t, !1)); }
function md(e, t) { let n = t?.injector ?? D(me); return typeof ngServerMode < "u" && ngServerMode ? Js : (K("NgAfterNextRender"), Lv(e, n, t, !0)); }
function FS(e) { return e instanceof Function ? [void 0, void 0, e, void 0] : [e.earlyRead, e.write, e.mixedReadWrite, e.read]; }
function Lv(e, t, n, o) { let r = t.get(Ks); r.impl ??= t.get(gd); let i = t.get(Mn, null, { optional: !0 }), s = n?.manualCleanup !== !0 ? t.get(Xt) : null, a = t.get(Ai, null, { optional: !0 }), c = new dr(r.impl, FS(e), a?.view, o, s, i?.snapshot(null)); return r.impl.register(c), c; }
var Js = { destroy() { } }, Br = new b("", { factory: () => { let e = D(ut), t = new Set; return e.onDestroy(() => t.clear()), { queue: t, isScheduled: !1, scheduler: null, injector: e }; } });
function Pv(e, t, n) { let o = e.get(Br); if (Array.isArray(t))
    for (let r of t)
        o.queue.add(r), n?.detachedLeaveAnimationFns?.push(r);
else
    o.queue.add(t), n?.detachedLeaveAnimationFns?.push(t); o.scheduler && o.scheduler(e); }
function jS(e, t) { let n = e.get(Br); if (Array.isArray(t))
    for (let o of t)
        n.queue.delete(o);
else
    n.queue.delete(t); }
function HS(e, t) { let n = e.get(Br); if (t.detachedLeaveAnimationFns) {
    for (let o of t.detachedLeaveAnimationFns)
        n.queue.delete(o);
    t.detachedLeaveAnimationFns = void 0;
} }
function VS(e) { let t = e.get(Br); t.isScheduled || (md(() => { t.isScheduled = !1; for (let n of t.queue)
    n(); t.queue.clear(); }, { injector: t.injector }), t.isScheduled = !0); }
function Xs(e) { let t = e.get(Br); t.scheduler = VS, t.scheduler(e); }
function vd(e, t) { for (let [n, o] of t)
    Pv(e, o.animateFns); }
function Qh(e, t, n, o) { let r = e?.[ke]?.enter; t !== null && r && r.has(n.index) && vd(o, r); }
function Yh(e, t, n, o) { try {
    n.get(dc);
}
catch {
    return o(!1);
} let r = e?.[ke]; r?.enter?.has(t.index) && jS(n, r.enter.get(t.index).animateFns); let i = BS(e, t, r); if (i.size === 0) {
    let s = !1;
    if (e) {
        let a = [];
        ea(e, t, a), s = a.length > 0;
    }
    if (!s)
        return o(!1);
} e && Ft.add(e[Ne]), Pv(n, () => $S(e, t, r || void 0, i, o), r || void 0); }
function BS(e, t, n) { let o = new Map, r = n?.leave; if (r && r.has(t.index) && o.set(t.index, r.get(t.index)), e && r)
    for (let [i, s] of r) {
        if (o.has(i))
            continue;
        let c = e[m].data[i].parent;
        for (; c;) {
            if (c === t) {
                o.set(i, s);
                break;
            }
            c = c.parent;
        }
    } return o; }
function $S(e, t, n, o, r) { let i = []; if (n && n.leave)
    for (let [s] of o) {
        if (!n.leave.has(s))
            continue;
        let a = n.leave.get(s);
        for (let c of a.animateFns) {
            let { promise: l } = c();
            i.push(l);
        }
        n.detachedLeaveAnimationFns = void 0;
    } if (e && ea(e, t, i), i.length > 0) {
    let s = n || e?.[ke];
    if (s) {
        let a = s.running;
        a && i.push(a), s.running = Promise.allSettled(i), GS(e, s.running, r);
    }
    else
        Promise.allSettled(i).then(() => { e && Ft.delete(e[Ne]), r(!0); });
}
else
    e && Ft.delete(e[Ne]), r(!1); }
function ea(e, t, n) { if (t.type & 12) {
    let r = e[t.index];
    if (Y(r))
        for (let i = k; i < r.length; i++) {
            let s = r[i];
            s[m].type === 2 && US(s, n);
        }
} let o = t.child; for (; o;)
    ea(e, o, n), o = o.next; }
function US(e, t) { let n = e[ke]; if (n && n.leave)
    for (let r of n.leave.values())
        for (let i of r.animateFns) {
            let { promise: s } = i();
            t.push(s);
        } let o = e[m].firstChild; for (; o;)
    ea(e, o, t), o = o.next; }
function GS(e, t, n) { t.then(() => { e[ke]?.running === t && (e[ke].running = void 0, Ft.delete(e[Ne])), n(!0); }); }
function Un(e, t, n, o, r, i, s, a) { if (r != null) {
    let c, l = !1;
    Y(r) ? c = r : te(r) && (l = !0, r = r[V]);
    let u = x(r);
    e === 0 && o !== null ? (Qh(a, o, i, n), s == null ? pv(t, o, u) : ze(t, o, u, s || null, !0)) : e === 1 && o !== null ? (Qh(a, o, i, n), ze(t, o, u, s || null, !0), kS(i, u, a)) : e === 2 ? (a?.[ke]?.leave?.has(i.index) && fd(i, u, a), qo.delete(u), Yh(a, i, n, d => { if (qo.has(u)) {
        qo.delete(u);
        return;
    } Hr(t, u, l, d); })) : e === 3 && (qo.delete(u), Yh(a, i, n, () => { t.destroyNode(u); })), c != null && KS(t, e, n, c, i, o, s);
} }
function Fv(e, t) { jv(e, t), t[V] = null, t[X] = null; }
function WS(e, t, n, o, r, i) { o[V] = r, o[X] = t, na(e, o, n, 1, r, i); }
function jv(e, t) { t[Ke].changeDetectionScheduler?.notify(9), na(e, t, t[C], 2, null, null); }
function zS(e) { let t = e[_t]; if (!t)
    return nl(e[m], e); for (; t;) {
    let n = null;
    if (te(t))
        n = t[_t];
    else {
        let o = t[k];
        o && (n = o);
    }
    if (!n) {
        for (; t && !t[ue] && t !== e;)
            te(t) && nl(t[m], t), t = t[q];
        t === null && (t = e), te(t) && nl(t[m], t), n = t && t[ue];
    }
    t = n;
} }
function yd(e, t) { let n = e[Zt], o = n.indexOf(t); n.splice(o, 1); }
function $r(e, t) { if (et(t))
    return; let n = t[C]; n.destroyNode && na(e, t, n, 3, null, null), zS(t); }
function nl(e, t) { if (et(t))
    return; let n = R(null); try {
    t[_] &= -129, t[_] |= 256, t[we] && To(t[we]), QS(e, t), qS(e, t), t[m].type === 1 && t[C].destroy();
    let o = t[bt];
    if (o !== null && Y(t[q])) {
        o !== t[q] && yd(o, t);
        let r = t[Je];
        r !== null && r.detachView(e);
    }
    Nl(t);
}
finally {
    R(n);
} }
function qS(e, t) { let n = e.cleanup, o = t[Qt]; if (n !== null)
    for (let s = 0; s < n.length - 1; s += 2)
        if (typeof n[s] == "string") {
            let a = n[s + 3];
            a >= 0 ? o[a]() : o[-a].unsubscribe(), s += 2;
        }
        else {
            let a = o[n[s + 1]];
            n[s].call(a);
        } o !== null && (t[Qt] = null); let r = t[hc]; if (r !== null) {
    t[hc] = null;
    for (let s = 0; s < r.length; s++) {
        let a = r[s];
        a();
    }
} let i = t[On]; if (i !== null) {
    t[On] = null;
    for (let s of i)
        s.destroy();
} }
function QS(e, t) { let n; if (e != null && (n = e.destroyHooks) != null)
    for (let o = 0; o < n.length; o += 2) {
        let r = t[n[o]];
        if (!(r instanceof un)) {
            let i = n[o + 1];
            if (Array.isArray(i))
                for (let s = 0; s < i.length; s += 2) {
                    let a = r[i[s]], c = i[s + 1];
                    P(L.LifecycleHookStart, a, c);
                    try {
                        c.call(a);
                    }
                    finally {
                        P(L.LifecycleHookEnd, a, c);
                    }
                }
            else {
                P(L.LifecycleHookStart, r, i);
                try {
                    i.call(r);
                }
                finally {
                    P(L.LifecycleHookEnd, r, i);
                }
            }
        }
    } }
function Ed(e, t, n) { if (t === null)
    throw new M(510, !1); return Hv(e, t.parent, n); }
function Hv(e, t, n) { let o = t; for (; o !== null && o.type & 168;)
    t = o, o = t.parent; if (o === null)
    return n[V]; if (ve(o)) {
    let { encapsulation: r } = e.data[o.directiveStart + o.componentOffset];
    if (r === Pe.None || r === Pe.Emulated)
        return null;
} return Z(o, n); }
function Vv(e, t, n) { return $v(e, t, n); }
function Bv(e, t, n) { return e.type & 40 ? Z(e, n) : null; }
var $v = Bv, ql;
function Uv(e, t) { $v = e, ql = t; }
function ta(e, t, n, o) { let r = Ed(e, o, t), i = t[C], s = o.parent || t[X], a = Vv(s, o, t); if (r != null)
    if (Array.isArray(n))
        for (let c = 0; c < n.length; c++)
            Wh(i, r, n[c], a, !1);
    else
        Wh(i, r, n, a, !1); ql !== void 0 && ql(i, o, t, n, r); }
function cn(e, t) { if (t !== null) {
    let n = t.type;
    if (n & 3)
        return Z(t, e);
    if (n & 4)
        return Ql(-1, e[t.index]);
    if (n & 8) {
        let o = t.child;
        if (o !== null)
            return cn(e, o);
        {
            let r = e[t.index];
            return Y(r) ? Ql(-1, r) : x(r);
        }
    }
    else {
        if (n & 128)
            return cn(e, t.next);
        if (n & 32)
            return ud(t, e)() || x(e[t.index]);
        {
            let o = Gv(e, t);
            if (o !== null) {
                if (Array.isArray(o))
                    return o[0];
                let r = tt(e[ee]);
                return cn(r, o);
            }
            else
                return cn(e, t.next);
        }
    }
} return null; }
function Gv(e, t) { if (t !== null) {
    let o = e[ee][X], r = t.projection;
    return o.projection[r];
} return null; }
function Ql(e, t) { let n = k + e + 1; if (n < t.length) {
    let o = t[n], r = o[m].firstChild;
    if (r !== null)
        return cn(o, r);
} return t[Xe]; }
function Id(e, t, n, o, r, i, s) { for (; n != null;) {
    let a = o[O];
    if (n.type === 128) {
        n = n.next;
        continue;
    }
    let c = o[n.index], l = n.type;
    if (s && t === 0 && (c && _e(x(c), o), n.flags |= 2), !uo(n))
        if (l & 8)
            Id(e, t, n.child, o, r, i, !1), Un(t, e, a, r, c, n, i, o);
        else if (l & 32) {
            let u = ud(n, o), d;
            for (; d = u();)
                Un(t, e, a, r, d, n, i, o);
            Un(t, e, a, r, c, n, i, o);
        }
        else
            l & 16 ? Wv(e, t, o, n, r, i) : Un(t, e, a, r, c, n, i, o);
    n = s ? n.projectionNext : n.next;
} }
function na(e, t, n, o, r, i) { e.type === 3 ? YS(n, o, t, r, i) : Id(n, o, e.firstChild, t, r, i, !1); }
function YS(e, t, n, o, r) { let s = n[m].firstChild, a = s.next, c = x(n[s.index]), l = x(n[a.index]), u = a.index + 1, d = n[u]; if (t === 1 || t === 0)
    o !== null && (d && d.hasChildNodes() ? ze(e, o, d, r, !0) : (ze(e, o, c, r, !0), ze(e, o, l, r, !0)));
else if (t === 2) {
    if (d || (d = document.createDocumentFragment(), n[u] = d), c && c.parentNode === d)
        return;
    let f = c;
    for (; f !== null;) {
        let p = f.nextSibling;
        if (d.appendChild(f), f === l)
            break;
        f = p;
    }
} }
function ZS(e, t, n) { let o = t[C], r = Ed(e, n, t), i = n.parent || t[X], s = Vv(i, n, t); Wv(o, 0, t, n, r, s); }
function Wv(e, t, n, o, r, i) { let s = n[ee], c = s[X].projection[o.projection]; if (Array.isArray(c))
    for (let l = 0; l < c.length; l++) {
        let u = c[l];
        Un(t, e, n[O], r, u, o, i, n);
    }
else {
    let l = c, u = s[q];
    ar(o) && (l.flags |= 128), Id(e, t, l, u, r, i, !0);
} }
function KS(e, t, n, o, r, i, s) { let a = o[Xe], c = x(o); if (a !== c && Un(t, e, n, i, a, r, s), (o[_] & 4) === 0)
    for (let l = k; l < o.length; l++) {
        let u = o[l];
        na(u[m], u, e, t, i, a);
    } }
function JS(e, t, n, o, r) { if (t)
    r ? e.addClass(n, o) : e.removeClass(n, o);
else {
    let i = o.indexOf("-") === -1 ? void 0 : fs.DashCase;
    r == null ? e.removeStyle(n, o, i) : (typeof r == "string" && r.endsWith("!important") && (r = r.slice(0, -10), i |= fs.Important), e.setStyle(n, o, r, i));
} }
function oa(e, t, n, o, r, i, s, a, c, l, u) { let d = E + o, f = d + r, p = XS(d, f), h = typeof l == "function" ? l() : l; return p[m] = { type: e, blueprint: p, template: n, queries: null, viewQuery: a, declTNode: t, data: p.slice().fill(null, d), bindingStartIndex: d, expandoStartIndex: f, hostBindingOpCodes: null, firstCreatePass: !0, firstUpdatePass: !0, staticViewQueries: !1, staticContentQueries: !1, preOrderHooks: null, preOrderCheckHooks: null, contentHooks: null, contentCheckHooks: null, viewHooks: null, viewCheckHooks: null, destroyHooks: null, cleanup: null, contentQueries: null, components: null, directiveRegistry: typeof i == "function" ? i() : i, pipeRegistry: typeof s == "function" ? s() : s, firstChild: null, schemas: c, consts: h, incompleteFirstPass: !1, ssrId: u }; }
function XS(e, t) { let n = []; for (let o = 0; o < t; o++)
    n.push(o < e ? null : j); return n; }
function zv(e) { let t = e.tView; return t === null || t.incompleteFirstPass ? e.tView = oa(1, null, e.template, e.decls, e.vars, e.directiveDefs, e.pipeDefs, e.viewQuery, e.schemas, e.consts, e.id) : t; }
function Ur(e, t, n, o, r, i, s, a, c, l, u) { let d = t.blueprint.slice(); return d[V] = r, d[_] = o | 4 | 128 | 8 | 64 | 1024, (l !== null || e && e[_] & 2048) && (d[_] |= 2048), yc(d), d[q] = d[An] = e, d[F] = n, d[Ke] = s || e && e[Ke], d[C] = a || e && e[C], d[O] = c || e && e[O] || null, d[X] = i, d[Ne] = ON(), d[ce] = u, d[pc] = l, d[ee] = t.type == 2 ? e[ee] : d, d; }
function e_(e, t, n) { let o = Z(t, e), r = zv(n), i = e[Ke].rendererFactory, s = ra(e, Ur(e, r, null, Dd(n), o, t, null, i.createRenderer(o, n), null, null, null)); return e[t.index] = s; }
function Dd(e) { let t = 16; return e.signals ? t = 4096 : e.onPush && (t = 64), t; }
function Gr(e, t, n, o) { if (n === 0)
    return -1; let r = t.length; for (let i = 0; i < n; i++)
    t.push(o), e.blueprint.push(o), e.data.push(null); return r; }
function ra(e, t) { return e[_t] ? e[Oo][ue] = t : e[_t] = t, e[Oo] = t, t; }
function qv(e = 1) { Qv(w(), g(), ne() + e, !1); }
function Qv(e, t, n, o) { if (!o)
    if ((t[_] & 3) === 3) {
        let i = e.preOrderCheckHooks;
        i !== null && Wi(t, i, n);
    }
    else {
        let i = e.preOrderHooks;
        i !== null && zi(t, i, 0, n);
    } rt(n); }
var ia = (function (e) { return e[e.None = 0] = "None", e[e.SignalBased = 1] = "SignalBased", e[e.HasDecoratorInputTransform = 2] = "HasDecoratorInputTransform", e; })(ia || {});
function fn(e, t, n, o) { let r = R(null); try {
    let [i, s, a] = e.inputs[n], c = null;
    (s & ia.SignalBased) !== 0 && (c = t[i][Qe]), c !== null && c.transformFn !== void 0 ? o = c.transformFn(o) : a !== null && (o = a.call(t, o)), e.setInput !== null ? e.setInput(t, c, o, n, i) : zg(t, c, i, o);
}
finally {
    R(r);
} }
function Yv(e, t, n, o, r) { let i = ne(), s = o & 2; try {
    rt(-1), s && t.length > E && Qv(e, t, E, !1);
    let a = s ? L.TemplateUpdateStart : L.TemplateCreateStart;
    P(a, r, n), n(o, r);
}
finally {
    rt(i);
    let a = s ? L.TemplateUpdateEnd : L.TemplateCreateEnd;
    P(a, r, n);
} }
function sa(e, t, n) { i_(e, t, n), (n.flags & 64) === 64 && s_(e, t, n); }
function ho(e, t, n = Z) { let o = t.localNames; if (o !== null) {
    let r = t.index + 1;
    for (let i = 0; i < o.length; i += 2) {
        let s = o[i + 1], a = s === -1 ? n(t, e) : e[s];
        e[r++] = a;
    }
} }
function t_(e, t, n, o) { let i = o.get(Bu, Rm) || n === Pe.ShadowDom || n === Pe.ExperimentalIsolatedShadowDom, s = e.selectRootElement(t, i); return n_(s), s; }
function n_(e) { Zv(e); }
var Zv = () => null;
function o_(e) { ym(e) ? hv(e) : dw(e); }
function Kv() { Zv = o_; }
function r_(e) { return e === "class" ? "className" : e === "for" ? "htmlFor" : e === "formaction" ? "formAction" : e === "innerHtml" ? "innerHTML" : e === "readonly" ? "readOnly" : e === "tabindex" ? "tabIndex" : e; }
function Cd(e, t, n, o, r, i) { let s = t[m]; if (ua(e, s, t, n, o)) {
    ve(e) && Jv(t, e.index);
    return;
} e.type & 3 && (n = r_(n)), Td(e, t, n, o, r, i); }
function Td(e, t, n, o, r, i) { if (e.type & 3) {
    let s = Z(e, t);
    o = i != null ? i(o, e.value || "", n) : o, r.setProperty(s, n, o);
}
else
    e.type & 12; }
function Jv(e, t) { let n = fe(t, e); n[_] & 16 || (n[_] |= 64); }
function i_(e, t, n) { let o = n.directiveStart, r = n.directiveEnd; ve(n) && e_(t, n, e.data[o + n.componentOffset]), e.firstCreatePass || rs(n, t); let i = n.initialInputs; for (let s = o; s < r; s++) {
    let a = e.data[s], c = sr(t, e, s, n);
    if (_e(c, t), i !== null && l_(t, s - o, c, a, n, i), Le(a)) {
        let l = fe(n.index, t);
        l[F] = sr(t, e, s, n);
    }
} }
function s_(e, t, n) { let o = n.directiveStart, r = n.directiveEnd, i = n.index, s = ah(); try {
    rt(i);
    for (let a = o; a < r; a++) {
        let c = e.data[a], l = t[a];
        xc(a), (c.hostBindings !== null || c.hostVars !== 0 || c.hostAttrs !== null) && a_(c, l);
    }
}
finally {
    rt(-1), xc(s);
} }
function a_(e, t) { e.hostBindings !== null && e.hostBindings(1, t); }
function Md(e, t) { let n = e.directiveRegistry, o = null; if (n)
    for (let r = 0; r < n.length; r++) {
        let i = n[r];
        Nv(t, i.selectors, !1) && (o ??= [], Le(i) ? o.unshift(i) : o.push(i));
    } return o; }
function c_(e, t, n, o, r, i) { let s = Z(e, t); aa(t[C], s, i, e.value, n, o, r); }
function aa(e, t, n, o, r, i, s) { if (i == null)
    s?.(i, o || "", r), e.removeAttribute(t, r, n);
else {
    let a = s == null ? S(i) : s(i, o || "", r);
    e.setAttribute(t, r, a, n);
} }
function l_(e, t, n, o, r, i) { let s = i[t]; if (s !== null)
    for (let a = 0; a < s.length; a += 2) {
        let c = s[a], l = s[a + 1];
        fn(o, n, c, l);
    } }
function ca(e, t, n, o, r) { let i = E + n, s = t[m], a = r(s, t, e, o, n); t[i] = a, Ue(e, !0); let c = e.type === 2; return c ? (gv(t[C], a, e), (th() === 0 || xn(e)) && _e(a, t), nh()) : _e(a, t), $o() && (!c || !uo(e)) && ta(s, t, a, e), e; }
function la(e) { let t = e; return Sc() ? Mi() : (t = t.parent, Ue(t, !1)), t; }
function Xv(e, t, n) { return (e === null || Le(e)) && (n = Lo(n[t.index])), n[C]; }
function Nd(e, t) { let n = e[O]; if (!n)
    return; let o; try {
    o = n.get(en, null);
}
catch {
    o = null;
} o?.(t); }
function ua(e, t, n, o, r) { let i = e.inputs?.[o], s = e.hostDirectiveInputs?.[o], a = !1; if (s)
    for (let c = 0; c < s.length; c += 2) {
        let l = s[c], u = s[c + 1], d = t.data[l];
        fn(d, n[l], u, r), a = !0;
    } if (i)
    for (let c of i) {
        let l = n[c], u = t.data[c];
        fn(u, l, o, r), a = !0;
    } return a; }
function ey(e, t, n, o, r, i) { let s = null, a = null, c = null, l = !1, u = e.directiveToIndex.get(o.type); if (typeof u == "number" ? s = u : [s, a, c] = u, a !== null && c !== null && e.hostDirectiveInputs && Object.hasOwn(e.hostDirectiveInputs, r)) {
    let d = e.hostDirectiveInputs[r];
    for (let f = 0; f < d.length; f += 2) {
        let p = d[f];
        if (p >= a && p <= c) {
            let h = t.data[p], v = d[f + 1];
            fn(h, n[p], v, i), l = !0;
        }
        else if (p > c)
            break;
    }
} return s !== null && Object.hasOwn(o.inputs, r) && (fn(o, n[s], r, i), l = !0), l; }
function u_(e, t) { let n = fe(t, e), o = n[m]; d_(o, n); let r = n[V]; r !== null && n[ce] === null && (n[ce] = Wm(r, n[O])), P(L.ComponentStart); try {
    da(o, n, n[F]);
}
finally {
    P(L.ComponentEnd, n[F]);
} }
function d_(e, t) { for (let n = t.length; n < e.blueprint.length; n++)
    t.push(e.blueprint[n]); }
function da(e, t, n) { Si(t); try {
    let o = e.viewQuery;
    o !== null && Rl(1, o, n);
    let r = e.template;
    r !== null && Yv(e, t, r, 1, n), e.firstCreatePass && (e.firstCreatePass = !1), t[Je]?.finishViewCreation(e), e.staticContentQueries && Xm(e, t), e.staticViewQueries && Rl(2, e.viewQuery, n);
    let i = e.components;
    i !== null && f_(t, i);
}
catch (o) {
    throw e.firstCreatePass && (e.incompleteFirstPass = !0, e.firstCreatePass = !1), o;
}
finally {
    t[_] &= -5, _i();
} }
function f_(e, t) { for (let n = 0; n < t.length; n++)
    u_(e, t[n]); }
function Ht(e, t, n, o) { let r = R(null); try {
    let i = t.tView, a = e[_] & 4096 ? 4096 : 16, c = Ur(e, i, n, a, null, t, null, null, o?.injector ?? null, o?.embeddedViewInjector ?? null, o?.dehydratedView ?? null), l = e[t.index];
    c[bt] = l;
    let u = e[Je];
    return u !== null && (c[Je] = u.createEmbeddedView(i)), da(i, c, n), c;
}
finally {
    R(r);
} }
function pn(e, t) { return !t || t.firstChild === null || ar(e); }
function jt(e, t, n, o, r = !1) { if (e.type === 3) {
    let i = e.firstChild, s = i.next, a = x(t[i.index]), c = x(t[s.index]), l = a;
    for (; l !== null && (o.push(l), l !== c);)
        l = l.nextSibling;
    return o;
} for (; n !== null;) {
    if (n.type === 128) {
        n = r ? n.projectionNext : n.next;
        continue;
    }
    let i = t[n.index];
    if (i !== null)
        if (Y(i)) {
            let a = i[Xe];
            a !== i[V] && o.push(x(i)), i[_] & 4 || fa(i, o), o.push(a);
        }
        else
            o.push(x(i));
    let s = n.type;
    if (s & 8)
        jt(e, t, n.child, o);
    else if (s & 32) {
        let a = ud(n, t), c;
        for (; c = a();)
            o.push(c);
    }
    else if (s & 16) {
        let a = Gv(t, n);
        if (Array.isArray(a))
            o.push(...a);
        else {
            let c = tt(t[ee]);
            jt(c[m], c, a, o, !0);
        }
    }
    n = r ? n.projectionNext : n.next;
} return o; }
function fa(e, t) { for (let n = k; n < e.length; n++) {
    let o = e[n], r = o[m].firstChild;
    r !== null && jt(o[m], o, r, t);
} }
function ty(e) { if (e[Yt] !== null) {
    for (let t of e[Yt])
        t.impl.addSequence(t);
    e[Yt].length = 0;
} }
var ny = [];
function p_(e) { return e[we] ?? h_(e); }
function h_(e) { let t = ny.pop() ?? Object.create(m_); return t.lView = e, t; }
function g_(e) { e.lView[we] !== e && (e.lView = null, ny.push(e)); }
var m_ = Re(G({}, Ja), { consumerIsAlwaysLive: !0, kind: "template", consumerMarkedDirty: e => { Ci(e.lView); }, consumerOnSignalRead() { this.lView[we] = this; } });
function v_(e) { let t = e[we] ?? Object.create(y_); return t.lView = e, t; }
var y_ = Re(G({}, Ja), { consumerIsAlwaysLive: !0, kind: "template", consumerMarkedDirty: e => { let t = tt(e.lView); for (; t && !oy(t[m]);)
        t = tt(t); t && Fo(t); }, consumerOnSignalRead() { this.lView[we] = this; } });
function oy(e) { return e.type !== 2; }
function ry(e) { if (e[On] === null)
    return; let t = !0; for (; t;) {
    let n = !1;
    for (let o of e[On])
        if (o.dirty && (n = !0, o.zone === null || Zone.current === o.zone ? o.run() : o.zone.run(() => o.run()), e[On] === null))
            return;
    t = n && !!(e[_] & 8192);
} }
var E_ = 100;
function iy(e, t = 0) { let o = e[Ke].rendererFactory, r = !1; r || o.begin?.(); try {
    I_(e, t);
}
finally {
    r || o.end?.();
} }
function I_(e, t) { let n = bc(); try {
    Ac(!0), Yl(e, t);
    let o = 0;
    for (; jo(e);) {
        if (o === E_)
            throw new M(103, !1);
        o++, Yl(e, 1);
    }
}
finally {
    Ac(n);
} }
function sy(e, t, n, o) { if (et(t))
    return; let r = t[_], i = !1, s = !1; Si(t); let a = !0, c = null, l = null; i || (oy(e) ? (l = p_(t), c = Co(l)) : Mp() === null ? (a = !1, l = v_(t), c = Co(l)) : t[we] && (To(t[we]), t[we] = null)); try {
    yc(t), Rc(e.bindingStartIndex), n !== null && Yv(e, t, n, 2, o);
    let u = (r & 3) === 3;
    if (!i)
        if (u) {
            let p = e.preOrderCheckHooks;
            p !== null && Wi(t, p, null);
        }
        else {
            let p = e.preOrderHooks;
            p !== null && zi(t, p, 0, null), Zc(t, 0);
        }
    if (s || D_(t), ry(t), ay(t, 0), e.contentQueries !== null && Xm(e, t), !i)
        if (u) {
            let p = e.contentCheckHooks;
            p !== null && Wi(t, p);
        }
        else {
            let p = e.contentHooks;
            p !== null && zi(t, p, 1), Zc(t, 1);
        }
    T_(e, t);
    let d = e.components;
    d !== null && ly(t, d, 0);
    let f = e.viewQuery;
    if (f !== null && Rl(2, f, o), !i)
        if (u) {
            let p = e.viewCheckHooks;
            p !== null && Wi(t, p);
        }
        else {
            let p = e.viewHooks;
            p !== null && zi(t, p, 2), Zc(t, 2);
        }
    if (e.firstUpdatePass === !0 && (e.firstUpdatePass = !1), t[Ei]) {
        for (let p of t[Ei])
            p();
        t[Ei] = null;
    }
    i || (ty(t), t[_] &= -73);
}
catch (u) {
    throw i || Ci(t), u;
}
finally {
    l !== null && (ii(l, c), a && g_(l)), _i();
} }
function ay(e, t) { for (let n = Tm(e); n !== null; n = Mm(n))
    for (let o = k; o < n.length; o++) {
        let r = n[o];
        cy(r, t);
    } }
function D_(e) { for (let t = Tm(e); t !== null; t = Mm(t)) {
    if (!(t[_] & 2))
        continue;
    let n = t[Zt];
    for (let o = 0; o < n.length; o++) {
        let r = n[o];
        Fo(r);
    }
} }
function C_(e, t, n) { P(L.ComponentStart); let o = fe(t, e); try {
    cy(o, n);
}
finally {
    P(L.ComponentEnd, o[F]);
} }
function cy(e, t) { Yp(e) && Yl(e, t); }
function Yl(e, t) { let o = e[m], r = e[_], i = e[we], s = !!(t === 0 && r & 16); if (s ||= !!(r & 64 && t === 0), s ||= !!(r & 1024), s ||= !!(i?.dirty && si(i)), s ||= !1, i && (i.dirty = !1), e[_] &= -9217, s)
    sy(o, e, o.template, e[F]);
else if (r & 8192) {
    let a = R(null);
    try {
        ry(e), ay(e, 1);
        let c = o.components;
        c !== null && ly(e, c, 1), ty(e);
    }
    finally {
        R(a);
    }
} }
function ly(e, t, n) { for (let o = 0; o < t.length; o++)
    C_(e, t[o], n); }
function T_(e, t) { let n = e.hostBindingOpCodes; if (n !== null)
    try {
        for (let o = 0; o < n.length; o++) {
            let r = n[o];
            if (r < 0)
                rt(~r);
            else {
                let i = r, s = n[++o], a = n[++o];
                sh(s, i);
                let c = t[i];
                P(L.HostBindingsUpdateStart, c);
                try {
                    a(2, c);
                }
                finally {
                    P(L.HostBindingsUpdateEnd, c);
                }
            }
        }
    }
    finally {
        rt(-1);
    } }
function pa(e, t) { let n = bc() ? 64 : 1088; for (e[Ke].changeDetectionScheduler?.notify(t); e;) {
    e[_] |= n;
    let o = tt(e);
    if ($e(e) && !o)
        return e;
    e = o;
} return null; }
function wd(e, t, n, o) { return [e, !0, 0, t, null, o, null, n, null, null]; }
function uy(e, t) { let n = k + t; if (n < e.length)
    return e[n]; }
function Ct(e, t, n, o = !0) { let r = t[m]; if (M_(r, t, e, n), o) {
    let s = Ql(n, e), a = t[C], c = a.parentNode(e[Xe]);
    c !== null && WS(r, e[X], a, t, c, s);
} let i = t[ce]; i !== null && i.firstChild !== null && (i.firstChild = null); }
function Wr(e, t) { let n = fr(e, t); return n !== void 0 && $r(n[m], n), n; }
function fr(e, t) { if (e.length <= k)
    return; let n = k + t, o = e[n]; if (o) {
    let r = o[bt];
    r !== null && r !== e && yd(r, o), t > 0 && (e[n - 1][ue] = o[ue]);
    let i = So(e, k + t);
    Fv(o[m], o);
    let s = i[Je];
    s !== null && s.detachView(i[m]), o[q] = null, o[ue] = null, o[_] &= -129;
} return o; }
function M_(e, t, n, o) { let r = k + o, i = n.length; o > 0 && (n[r - 1][ue] = t), o < i - k ? (t[ue] = n[r], lc(n, k + o, t)) : (n.push(t), t[ue] = null), t[q] = n; let s = t[bt]; s !== null && n !== s && dy(s, t); let a = t[Je]; a !== null && a.insertView(e), Di(t), t[_] |= 128; }
function dy(e, t) { let n = e[Zt], o = t[q]; if (te(o))
    e[_] |= 2;
else {
    let r = o[q][ee];
    t[ee] !== r && (e[_] |= 2);
} n === null ? e[Zt] = [t] : n.push(t); }
var vt = class {
    _lView;
    _cdRefInjectingView;
    _appRef = null;
    _attachedToViewContainer = !1;
    exhaustive;
    get rootNodes() { let t = this._lView, n = t[m]; return jt(n, t, n.firstChild, []); }
    constructor(t, n) { this._lView = t, this._cdRefInjectingView = n; }
    get context() { return this._lView[F]; }
    set context(t) { this._lView[F] = t; }
    get destroyed() { return et(this._lView); }
    destroy() { if (this._appRef)
        this._appRef.detachView(this);
    else if (this._attachedToViewContainer) {
        let t = this._lView[q];
        if (Y(t)) {
            let n = t[xo], o = n ? n.indexOf(this) : -1;
            o > -1 && (fr(t, o), So(n, o));
        }
        this._attachedToViewContainer = !1;
    } $r(this._lView[m], this._lView); }
    onDestroy(t) { Ho(this._lView, t); }
    markForCheck() { pa(this._cdRefInjectingView || this._lView, 4); }
    detach() { this._lView[_] &= -129; }
    reattach() { Di(this._lView), this._lView[_] |= 128; }
    detectChanges() { this._lView[_] |= 1024, iy(this._lView); }
    checkNoChanges() { }
    attachToViewContainerRef() { if (this._appRef)
        throw new M(902, !1); this._attachedToViewContainer = !0; }
    detachFromAppRef() { this._appRef = null; let t = $e(this._lView), n = this._lView[bt]; n !== null && !t && yd(n, this._lView), jv(this._lView[m], this._lView); }
    attachToAppRef(t) { if (this._attachedToViewContainer)
        throw new M(902, !1); this._appRef = t; let n = $e(this._lView), o = this._lView[bt]; o !== null && !n && dy(o, this._lView), Di(this._lView); }
};
function N_(e) { return jo(e._lView) || !!(e._lView[_] & 64); }
function w_(e) { Fo(e._lView); }
var pr = (() => { class e {
    _declarationLView;
    _declarationTContainer;
    elementRef;
    static __NG_ELEMENT_ID__ = S_;
    constructor(n, o, r) { this._declarationLView = n, this._declarationTContainer = o, this.elementRef = r; }
    get ssrId() { return this._declarationTContainer.tView?.ssrId || null; }
    createEmbeddedView(n, o) { return this.createEmbeddedViewImpl(n, o); }
    createEmbeddedViewImpl(n, o, r) { let i = Ht(this._declarationLView, this._declarationTContainer, n, { embeddedViewInjector: o, dehydratedView: r }); return new vt(i); }
} return e; })();
function S_() { return ha(N(), g()); }
function ha(e, t) { return e.type & 4 ? new pr(t, e, io(e, t)) : null; }
var Zl = "<-- AT THIS LOCATION", __ = "/guide/hydration#third-party-scripts-with-dom-manipulation";
function b_(e) { switch (e) {
    case 4: return "view container";
    case 2: return "element";
    case 8: return "ng-container";
    case 32: return "icu";
    case 64: return "i18n";
    case 16: return "projection";
    case 1: return "text";
    case 128: return "@let";
    default: return "<unknown>";
} }
function A_(e, t) {
    let n = `During serialization, Angular was unable to find an element in the DOM:

`, o = `${k_(e, t, !1)}

`, r = P_();
    throw new M(-502, n + o + r);
}
function fy(e) {
    let t = "During serialization, Angular detected DOM nodes that were created outside of Angular context and provided as projectable nodes (likely via `ViewContainerRef.createComponent` or `createComponent` APIs). Hydration is not supported for such cases, consider refactoring the code to avoid this pattern or using `ngSkipHydration` on the host element of the component.\n\n", n = `${L_(e)}

`, o = t + n + F_();
    return new M(-503, o);
}
function R_(e) { let t = []; if (e.attrs)
    for (let n = 0; n < e.attrs.length;) {
        let o = e.attrs[n++];
        if (typeof o == "number")
            break;
        let r = e.attrs[n++];
        t.push(`${o}="${gs(r)}"`);
    } return t.join(" "); }
var O_ = new Set(["ngh", "ng-version", "ng-server-context"]);
function x_(e) { let t = []; for (let n = 0; n < e.attributes.length; n++) {
    let o = e.attributes[n];
    O_.has(o.name) || t.push(`${o.name}="${gs(o.value)}"`);
} return t.join(" "); }
function ol(e, t = "\u2026") { switch (e.type) {
    case 1: return `#text${e.value ? `(${e.value})` : ""}`;
    case 2:
        let o = R_(e), r = e.value.toLowerCase();
        return `<${r}${o ? " " + o : ""}>${t}</${r}>`;
    case 8: return "<!-- ng-container -->";
    case 4: return "<!-- container -->";
    default: return `#node(${b_(e.type)})`;
} }
function Yi(e, t = "\u2026") { let n = e; switch (n.nodeType) {
    case Node.ELEMENT_NODE:
        let o = n.tagName.toLowerCase(), r = x_(n);
        return `<${o}${r ? " " + r : ""}>${t}</${o}>`;
    case Node.TEXT_NODE:
        let i = n.textContent ? gs(n.textContent) : "";
        return `#text${i ? `(${i})` : ""}`;
    case Node.COMMENT_NODE: return `<!-- ${gs(n.textContent ?? "")} -->`;
    default: return `#node(${n.nodeType})`;
} }
function k_(e, t, n) {
    let r = "";
    t.prev ? (r += `  \u2026
`, r += "  " + ol(t.prev) + `
`) : t.type && t.type & 12 && (r += `  \u2026
`), n ? (r += "  " + ol(t) + `
`, r += `  <!-- container -->  ${Zl}
`) : r += "  " + ol(t) + `  ${Zl}
`, r += `  \u2026
`;
    let i = t.type ? Ed(e[m], t, e) : null;
    return i && (r = Yi(i, `
` + r)), r;
}
function L_(e) {
    let n = "", o = e;
    return o.previousSibling && (n += `  \u2026
`, n += "  " + Yi(o.previousSibling) + `
`), n += "  " + Yi(o) + `  ${Zl}
`, e.nextSibling && (n += `  \u2026
`), e.parentNode && (n = Yi(o.parentNode, `
` + n)), n;
}
function P_(e) {
    return `To fix this problem:
  * check ${e ? `the "${e}"` : "corresponding"} component for hydration-related issues
  * check to see if your template has valid HTML structure
  * check if there are any third-party scripts that manipulate the DOM. More info: ${tc}${__}
  * or skip hydration by adding the \`ngSkipHydration\` attribute to its host node in a template

`;
}
function F_() {
    return `Note: attributes are only displayed to better represent the DOM but have no effect on hydration mismatches.

`;
}
function j_(e) { return e.replace(/\s+/gm, ""); }
function gs(e, t = 50) { return e ? (e = j_(e), e.length > t ? `${e.substring(0, t - 1)}\u2026` : e) : ""; }
function H_(e) { let t = e.textContent?.slice(0, 50); return t ? `${e.nodeName} ("${t}")` : e.nodeName; }
function py(e, t, n) { let o = t.insertBeforeIndex, r = Array.isArray(o) ? o[0] : o; return r === null ? Bv(e, t, n) : x(n[r]); }
function hy(e, t, n, o, r) { let i = t.insertBeforeIndex; if (Array.isArray(i)) {
    let s = o, a = null;
    if (t.type & 3 || (a = s, s = r), s !== null && t.componentOffset === -1)
        for (let c = 1; c < i.length; c++) {
            let l = n[i[c]];
            ze(e, s, l, a, !1);
        }
} }
function Vt(e, t, n, o, r) { let i = e.data[t]; if (i === null)
    i = Sd(e, t, n, o, r), ih() && (i.flags |= 32);
else if (i.type & 64) {
    i.type = n, i.value = o, i.attrs = r;
    let s = kn();
    i.injectorIndex = s === null ? -1 : s.injectorIndex;
} return Ue(i, !0), i; }
function Sd(e, t, n, o, r) { let i = rh(), s = Sc(), a = s ? i : i && i.parent, c = e.data[t] = Kl(e, a, n, t, o, r); return V_(e, c, i, s), c; }
function V_(e, t, n, o) { e.firstChild === null && (e.firstChild = t), n !== null && (o ? n.child == null && t.parent !== null && (n.child = t) : n.next === null && (n.next = t, t.prev = n)); }
function Kl(e, t, n, o, r, i) { let s = t ? t.injectorIndex : -1, a = 0; return Vo() && (a |= 128), { type: n, index: o, insertBeforeIndex: null, injectorIndex: s, directiveStart: -1, directiveEnd: -1, directiveStylingLast: -1, componentOffset: -1, controlDirectiveIndex: -1, customControlIndex: -1, propertyBindings: null, flags: a, providerIndexes: 0, value: r, namespace: bi(), attrs: i, mergedAttrs: null, localNames: null, initialInputs: null, inputs: null, hostDirectiveInputs: null, outputs: null, hostDirectiveOutputs: null, directiveToIndex: null, tView: null, next: null, prev: null, projectionNext: null, child: null, parent: t, projection: null, styles: null, stylesWithoutHost: null, residualStyles: void 0, classes: null, classesWithoutHost: null, residualClasses: void 0, classBindings: 0, styleBindings: 0 }; }
function gy(e, t) { if (e.push(t), e.length > 1)
    for (let n = e.length - 2; n >= 0; n--) {
        let o = e[n];
        my(o) || B_(o, t) && $_(o) === null && U_(o, t.index);
    } }
function my(e) { return !(e.type & 64); }
function B_(e, t) { return my(t) || e.index > t.index; }
function $_(e) { let t = e.insertBeforeIndex; return Array.isArray(t) ? t[0] : t; }
function U_(e, t) { let n = e.insertBeforeIndex; Array.isArray(n) ? n[0] = t : (Uv(py, hy), e.insertBeforeIndex = t); }
var G_ = Gt({ currentCaseLViewIndex: Gt }), PP = Gt({ tView: Gt });
function Yo(e, t) { let n = e.data[t]; return n === null || typeof n == "string" ? null : Object.hasOwn(n, G_) ? n : n.value; }
function W_(e, t, n) { let o = e.data[t]; o === null ? e.data[t] = n : o.value = n; }
function z_(e, t) { let n = e.insertBeforeIndex; n === null ? (Uv(py, hy), n = e.insertBeforeIndex = [null, t]) : (Ap(Array.isArray(n), !0, "Expecting array here"), n.push(t)); }
function q_(e, t, n) { let o = Sd(e, n, 64, null, null); return gy(t, o), o; }
function ga(e, t) { let n = t[e.currentCaseLViewIndex]; return n === null ? n : n < 0 ? ~n : n; }
function Q_(e) { return e >>> 17; }
function Y_(e) { return (e & 131070) >>> 1; }
function Z_(e, t, n) { return e | t << 17 | n << 1; }
function vy(e) { return e === -1; }
function _d(e, t, n) { e.index = 0; let o = ga(t, n); o !== null ? e.removes = t.remove[o] : e.removes = H; }
function ms(e) { if (e.index < e.removes.length) {
    let t = e.removes[e.index++];
    if (t > 0)
        return e.lView[t];
    {
        e.stack.push(e.index, e.removes);
        let n = ~t, o = e.lView[m].data[n];
        return _d(e, o, e.lView), ms(e);
    }
}
else
    return e.stack.length === 0 ? (e.lView = void 0, null) : (e.removes = e.stack.pop(), e.index = e.stack.pop(), ms(e)); }
function K_() { let e = { stack: [], index: -1 }; function t(n, o) { for (e.lView = o; e.stack.length;)
    e.stack.pop(); return _d(e, n.value, o), ms.bind(null, e); } return t; }
function J_(e, t) { let n = { stack: [], index: -1, lView: t }; return _d(n, e, t), ms.bind(null, n); }
var X_ = new RegExp(`^(\\d+)*(${Hu}|${ju})*(.*)`);
function eb(e, t) { let n = [e]; for (let o of t) {
    let r = n.length - 1;
    if (r > 0 && n[r - 1] === o) {
        let i = n[r] || 1;
        n[r] = i + 1;
    }
    else
        n.push(o, "");
} return n.join(""); }
function tb(e) { let t = e.match(X_), [n, o, r, i] = t, s = o ? parseInt(o, 10) : r, a = []; for (let [c, l, u] of i.matchAll(/(f|n)(\d*)/g)) {
    let d = parseInt(u, 10) || 1;
    a.push(l, d);
} return [s, ...a]; }
function nb(e) { return !e.prev && e.parent?.type === 8; }
function rl(e) { return e.index - E; }
function go(e, t) { return !(e.type & 144) && !!t[e.index] && yy(x(t[e.index])); }
function yy(e) { return !!e && !e.isConnected; }
function Ey(e, t) { let n = e.i18nNodes; if (n)
    return n.get(t); }
function ob(e, t, n) { let r = e.data[xr]?.[n]; return r ? Iy(r, t) : null; }
function zr(e, t, n, o) { let r = rl(o), i = Ey(e, r); if (i === void 0) {
    let s = e.data[xr];
    if (s?.[r])
        i = Iy(s[r], n);
    else if (t.firstChild === o)
        i = e.firstChild;
    else {
        let a = o.prev === null, c = o.prev ?? o.parent;
        if (nb(o)) {
            let l = rl(o.parent);
            i = Al(e, l);
        }
        else {
            let l = Z(c, n);
            if (a)
                i = l.firstChild;
            else {
                let u = rl(c), d = Al(e, u);
                if (c.type === 2 && d) {
                    let p = Ku(e, u) + 1;
                    i = ma(p, d);
                }
                else
                    i = l.nextSibling;
            }
        }
    }
} return i; }
function ma(e, t) { let n = t; for (let o = 0; o < e; o++) {
    if (n == null)
        throw new M(-501, !1);
    n = n.nextSibling;
} return n; }
function rb(e, t) { let n = e; for (let o = 0; o < t.length; o += 2) {
    let r = t[o], i = t[o + 1];
    for (let s = 0; s < i; s++) {
        if (!n)
            throw new M(509, !1);
        switch (r) {
            case bm:
                n = n.firstChild;
                break;
            case Am:
                n = n.nextSibling;
                break;
        }
    }
} if (!n)
    throw new M(509, !1); return n; }
function Iy(e, t) { let [n, ...o] = tb(e), r; if (n === ju)
    r = t[ee][V];
else if (n === Hu)
    r = cd(t[ee][V]);
else {
    let i = Number(n);
    r = x(t[i + E]);
} return rb(r, o); }
function Jl(e, t) { if (e === t)
    return []; if (e.parentElement == null || t.parentElement == null)
    return null; if (e.parentElement === t.parentElement)
    return ib(e, t); {
    let n = t.parentElement, o = Jl(e, n), r = Jl(n.firstChild, t);
    return !o || !r ? null : [...o, bm, ...r];
} }
function ib(e, t) { let n = [], o = null; for (o = e; o != null && o !== t; o = o.nextSibling)
    n.push(Am); return o == null ? null : n; }
function Zh(e, t, n) { let o = Jl(e, t); return o === null ? null : eb(n, o); }
function Dy(e, t, n) { let o = e.parent, r, i, s; for (; o !== null && (go(o, t) || n?.has(o.index));)
    o = o.parent; o === null || !(o.type & 3) ? (r = s = ju, i = t[ee][V]) : (r = o.index, i = x(t[r]), s = S(r - E)); let a = x(t[e.index]); if (e.type & 44) {
    let l = cn(t, e);
    l && (a = l);
} let c = Zh(i, a, s); if (c === null && i !== a) {
    let l = i.ownerDocument.body;
    if (c = Zh(l, a, Hu), c === null)
        throw A_(t, e);
} return c; }
function sb(e, t) { let n = e.createNodeIterator(t, NodeFilter.SHOW_COMMENT, { acceptNode: ab }), o, r = new Map; for (; o = n.nextNode();) {
    let i = "ngh=", s = o?.textContent, a = s?.indexOf(i) ?? -1;
    if (a > -1) {
        let c = s.substring(a + i.length).trim();
        r.set(c, o);
    }
} return r; }
function ab(e) { return e.textContent?.trimStart().startsWith("ngh=") ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; }
var Cy = !1, Ty = () => { };
function bd(e) { Cy = e; }
function va() { return Cy; }
function cb(e, t, n, o) { Ty(e, t, n, o); }
function My() { Ty = pb; }
function Ny(e) { return e = e ?? D(me), e.get($u, !1); }
function wy(e, t) { let n = t.i18nChildren.get(e); return n === void 0 && (n = lb(e), t.i18nChildren.set(e, n)), n; }
function lb(e) { let t = new Set; function n(o) { switch (t.add(o.index), o.kind) {
    case 1:
    case 2: {
        for (let r of o.children)
            n(r);
        break;
    }
    case 3: {
        for (let r of o.cases)
            for (let i of r)
                n(i);
        break;
    }
} } for (let o = E; o < e.bindingStartIndex; o++) {
    let r = e.data[o];
    if (!(!r || !r.ast))
        for (let i of r.ast)
            n(i);
} return t.size === 0 ? null : t; }
function Sy(e, t, n) { if (!n.isI18nHydrationEnabled)
    return null; let o = e[m], r = o.data[t]; if (!r || !r.ast)
    return null; let i = o.data[r.parentTNodeIndex]; if (i && Em(i))
    return null; let s = { caseQueue: [], disconnectedNodes: new Set, disjointNodes: new Set }; return Xl(e, s, n, r.ast), s.caseQueue.length === 0 && s.disconnectedNodes.size === 0 && s.disjointNodes.size === 0 ? null : s; }
function Xl(e, t, n, o) { let r = null; for (let i of o) {
    let s = db(e, t, n, i);
    s && (ub(r, s) && t.disjointNodes.add(i.index - E), r = s);
} return r; }
function ub(e, t) { return e && e.nextSibling !== t; }
function db(e, t, n, o) { let r = x(e[o.index]); if (!r || yy(r))
    return t.disconnectedNodes.add(o.index - E), null; let i = r; switch (o.kind) {
    case 0: {
        Ju(n, i);
        break;
    }
    case 1:
    case 2: {
        Xl(e, t, n, o.children);
        break;
    }
    case 3: {
        let s = e[o.currentCaseLViewIndex];
        if (s != null) {
            let a = s < 0 ? ~s : s;
            t.caseQueue.push(a), Xl(e, t, n, o.cases[a]);
        }
        break;
    }
} return fb(e, o); }
function fb(e, t) { let o = e[m].data[t.index]; return As(o) ? cn(e, o) : t.kind === 3 ? J_(o, e)() ?? x(e[t.index]) : x(e[t.index]) ?? null; }
function on(e, t) { e.currentNode = t; }
function Go(e, t, n) { let o = n.index - E, { disconnectedNodes: r } = e, i = t.currentNode; return t.isConnected ? (e.i18nNodes.set(o, i), r.delete(o)) : r.add(o), i; }
function il(e, t) { let n = e.currentNode; for (let o = 0; o < t && n; o++)
    n = n?.nextSibling ?? null; return n; }
function sl(e, t) { return { currentNode: t, isConnected: e.isConnected }; }
function pb(e, t, n, o) { let r = e[ce]; if (!r || !va() || n && (Em(n) || Us(r, n.index - E)))
    return; let i = e[m], s = i.data[t]; function a() { if (vy(o)) {
    let p = zr(r, i, e, n);
    return n.type & 8 ? p : p.firstChild;
} return r?.firstChild; } let c = a(), l = Ym(r) ?? new Set, u = r.i18nNodes ??= new Map, d = r.data[Fs]?.[t - E] ?? [], f = r.dehydratedIcuData ??= new Map; Hn({ hydrationInfo: r, lView: e, i18nNodes: u, disconnectedNodes: l, caseQueue: d, dehydratedIcuData: f }, { currentNode: c, isConnected: !0 }, s.ast), r.disconnectedNodes = l.size === 0 ? null : l; }
function Hn(e, t, n) { if (Array.isArray(n)) {
    let o = t;
    for (let r of n) {
        let i = ob(e.hydrationInfo, e.lView, r.index - E);
        i && (o = sl(t, i)), Hn(e, o, r);
    }
}
else {
    if (e.disconnectedNodes.has(n.index - E))
        return;
    switch (n.kind) {
        case 0: {
            let o = Go(e, t, n);
            on(t, o?.nextSibling ?? null);
            break;
        }
        case 1: {
            Hn(e, sl(t, t.currentNode?.firstChild ?? null), n.children);
            let o = Go(e, t, n);
            on(t, o?.nextSibling ?? null);
            break;
        }
        case 2: {
            let o = n.index - E, { hydrationInfo: r } = e, i = qm(r, o);
            switch (n.type) {
                case 0: {
                    let s = Go(e, t, n);
                    if (mw(r, o)) {
                        Hn(e, t, n.children);
                        let a = il(t, 1);
                        on(t, a);
                    }
                    else if (Hn(e, sl(t, t.currentNode?.firstChild ?? null), n.children), on(t, s?.nextSibling ?? null), i !== null) {
                        let a = il(t, i + 1);
                        on(t, a);
                    }
                    break;
                }
                case 1: {
                    Go(e, t, n);
                    let s = il(t, i + 1);
                    on(t, s);
                    break;
                }
            }
            break;
        }
        case 3: {
            let o = t.isConnected ? e.caseQueue.shift() : null, r = { currentNode: null, isConnected: !1 };
            for (let s = 0; s < n.cases.length; s++)
                Hn(e, s === o ? t : r, n.cases[s]);
            o !== null && e.dehydratedIcuData.set(n.index, { case: o, node: n });
            let i = Go(e, t, n);
            on(t, i?.nextSibling ?? null);
            break;
        }
    }
} }
var _y = () => { };
function hb(e, t, n) { _y(e, t, n); }
function by() { _y = gb; }
function gb(e, t, n) { let o = e[ce]?.dehydratedIcuData; o && o.get(t)?.case === n && o.delete(t); }
function mb(e) { let t = e[ce]; if (t) {
    let { i18nNodes: n, dehydratedIcuData: o } = t;
    if (n && o) {
        let r = e[C];
        for (let i of o.values())
            vb(r, n, i);
    }
    t.i18nNodes = void 0, t.dehydratedIcuData = void 0;
} }
function vb(e, t, n) { for (let o of n.node.cases[n.case]) {
    let r = t.get(o.index - E);
    r && Hr(e, r, !1);
} }
function ya(e) { let t = e[Se] ?? [], o = e[q][C], r = []; for (let i of t)
    i.data[js] !== void 0 ? r.push(i) : Ay(i, o); e[Se] = r; }
function yb(e) { let { lContainer: t } = e, n = t[Se]; if (n === null)
    return; let r = t[q][C]; for (let i of n)
    Ay(i, r); }
function Ay(e, t) { let n = 0, o = e.firstChild; if (o) {
    let r = e.data[gt];
    for (; n < r;) {
        let i = o.nextSibling;
        Hr(t, o, !1), o = i, n++;
    }
} }
function Ea(e) { ya(e); let t = e[V]; te(t) && hr(t); for (let n = k; n < e.length; n++)
    hr(e[n]); }
function hr(e) { mb(e); let t = e[m]; for (let n = E; n < t.bindingStartIndex; n++)
    if (Y(e[n])) {
        let o = e[n];
        Ea(o);
    }
    else
        te(e[n]) && hr(e[n]); }
function Ad(e) { let t = e._views; for (let n of t) {
    let o = Zu(n);
    o !== null && o[V] !== null && (te(o) ? hr(o) : Ea(o));
} }
function Eb(e, t, n, o) { e !== null && (n.cleanup(t), Ea(e.lContainer), Ad(o)); }
function Ib(e, t) { let n = []; for (let o of t)
    for (let r = 0; r < (o[Or] ?? 1); r++) {
        let i = { data: o, firstChild: null };
        o[gt] > 0 && (i.firstChild = e, e = ma(o[gt], e)), n.push(i);
    } return [e, n]; }
var Ry = () => null, Oy = () => null;
function xy() { Ry = Db, Oy = Cb; }
function Db(e, t) { return Ly(e, t) ? e[Se].shift() : (ya(e), null); }
function gr(e, t) { return Ry(e, t); }
function Cb(e, t, n) { if (t.tView.ssrId === null)
    return null; let o = gr(e, t.tView.ssrId); return n[m].firstUpdatePass && o === null && Tb(n, t), o; }
function ky(e, t, n) { return Oy(e, t, n); }
function Tb(e, t) { let n = t; for (; n;) {
    if (Kh(e, n))
        return;
    if ((n.flags & 256) === 256)
        break;
    n = n.prev;
} for (n = t.next; n && (n.flags & 512) === 512;) {
    if (Kh(e, n))
        return;
    n = n.next;
} }
function Ly(e, t) { let n = e[Se]; return !t || n === null || n.length === 0 ? !1 : n[0].data[Ps] === t; }
function Kh(e, t) { let n = t.tView?.ssrId; if (n == null)
    return !1; let o = e[t.index]; return Y(o) && Ly(o, n) ? (ya(o), !0) : !1; }
var Py = class {
}, mr = class {
}, eu = class {
    destroyNode = null;
    static __NG_ELEMENT_ID__ = () => Mb();
};
function Mb() { let e = g(), t = N(), n = fe(t.index, e); return (te(n) ? n : e)[C]; }
var Fy = (() => { class e {
    static \u0275prov = ae({ token: e, providedIn: "root", factory: () => null });
} return e; })(), jy = Symbol("RENDER"), Hy = Symbol("ON_DESTROY"), Vy = Symbol("CONTENT_ADAPTER"), By = Symbol("GET_CONTEXT");
function Nb(e) { return typeof e == "object" && e !== null && jy in e; }
function Rd(e) { return e.ngModule !== void 0; }
function rn(e) { return !!No(e); }
function Bi(e) { return !!Ze(e); }
function Jh(e) { return !!xe(e); }
function Zo(e) { return !!z(e); }
function wb(e) { return z(e) ? "component" : xe(e) ? "directive" : Ze(e) ? "pipe" : "type"; }
function Sb(e, t) { if (ui(e) && (e = W(e), !e))
    throw new Error(`Expected forwardRef function, imported from "${Te(t)}", to return a standalone entity or NgModule but got "${Te(e) || e}".`); if (No(e) == null) {
    let n = z(e) || xe(e) || Ze(e);
    if (n != null) {
        if (!n.standalone) {
            let o = wb(e);
            throw new Error(`The "${Te(e)}" ${o}, imported from "${Te(t)}", is not standalone. Does the ${o} have the standalone: false flag?`);
        }
    }
    else
        throw Rd(e) ? new Error(`A module with providers was imported from "${Te(t)}". Modules with providers are not supported in standalone components imports.`) : Nb(e) ? new Error(`A foreign component, imported from "${Te(t)}", cannot be imported using 'imports'. Foreign components are only supported in AOT mode and must be registered in 'foreignImports'.`) : new Error(`The "${Te(e)}" type, imported from "${Te(t)}", must be a standalone component / directive / pipe or an NgModule. Did you forget to add the required @Component / @Directive / @Pipe or @NgModule annotation?`);
} }
var tu = class {
    ownerNgModule = new WeakMap;
    ngModulesWithSomeUnresolvedDecls = new Set;
    ngModulesScopeCache = new WeakMap;
    standaloneComponentsScopeCache = new WeakMap;
    resolveNgModulesDecls() { if (this.ngModulesWithSomeUnresolvedDecls.size !== 0) {
        for (let t of this.ngModulesWithSomeUnresolvedDecls) {
            let n = No(t);
            if (n?.declarations)
                for (let o of zo(n.declarations))
                    Zo(o) && this.ownerNgModule.set(o, t);
        }
        this.ngModulesWithSomeUnresolvedDecls.clear();
    } }
    getComponentDependencies(t, n) { this.resolveNgModulesDecls(); let o = z(t); if (o === null)
        throw new Error(`Attempting to get component dependencies for a type that is not a component: ${t}`); if (o.standalone) {
        let r = this.getStandaloneComponentScope(t, n);
        return r.compilation.isPoisoned ? { dependencies: [] } : { dependencies: [...r.compilation.directives, ...r.compilation.pipes, ...r.compilation.ngModules] };
    }
    else {
        if (!this.ownerNgModule.has(t))
            return { dependencies: [] };
        let r = this.getNgModuleScope(this.ownerNgModule.get(t));
        return r.compilation.isPoisoned ? { dependencies: [] } : { dependencies: [...r.compilation.directives, ...r.compilation.pipes] };
    } }
    registerNgModule(t, n) { if (!rn(t))
        throw new Error(`Attempting to register a Type which is not NgModule as NgModule: ${t}`); this.ngModulesWithSomeUnresolvedDecls.add(t); }
    clearScopeCacheFor(t) { this.ngModulesScopeCache.delete(t), this.standaloneComponentsScopeCache.delete(t); }
    getNgModuleScope(t) { if (this.ngModulesScopeCache.has(t))
        return this.ngModulesScopeCache.get(t); let n = this.computeNgModuleScope(t); return this.ngModulesScopeCache.set(t, n), n; }
    computeNgModuleScope(t) { let n = fi(t), o = { exported: { directives: new Set, pipes: new Set }, compilation: { directives: new Set, pipes: new Set } }; for (let r of zo(n.imports))
        if (rn(r)) {
            let i = this.getNgModuleScope(r);
            xt(i.exported.directives, o.compilation.directives), xt(i.exported.pipes, o.compilation.pipes);
        }
        else if (wo(r))
            if (Jh(r) || Zo(r))
                o.compilation.directives.add(r);
            else if (Bi(r))
                o.compilation.pipes.add(r);
            else
                throw new M(980, "The standalone imported type is neither a component nor a directive nor a pipe");
        else {
            o.compilation.isPoisoned = !0;
            break;
        } if (!o.compilation.isPoisoned)
        for (let r of zo(n.declarations)) {
            if (rn(r) || wo(r)) {
                o.compilation.isPoisoned = !0;
                break;
            }
            Bi(r) ? o.compilation.pipes.add(r) : o.compilation.directives.add(r);
        } for (let r of zo(n.exports))
        if (rn(r)) {
            let i = this.getNgModuleScope(r);
            xt(i.exported.directives, o.exported.directives), xt(i.exported.pipes, o.exported.pipes), xt(i.exported.directives, o.compilation.directives), xt(i.exported.pipes, o.compilation.pipes);
        }
        else
            Bi(r) ? o.exported.pipes.add(r) : o.exported.directives.add(r); return o; }
    getStandaloneComponentScope(t, n) { if (this.standaloneComponentsScopeCache.has(t))
        return this.standaloneComponentsScopeCache.get(t); let o = this.computeStandaloneComponentScope(t, n); return this.standaloneComponentsScopeCache.set(t, o), o; }
    computeStandaloneComponentScope(t, n) { let o = { compilation: { directives: new Set([t]), pipes: new Set, ngModules: new Set } }; for (let r of Ve(n ?? [])) {
        let i = W(r);
        try {
            Sb(i, t);
        }
        catch {
            return o.compilation.isPoisoned = !0, o;
        }
        if (rn(i)) {
            o.compilation.ngModules.add(i);
            let s = this.getNgModuleScope(i);
            if (s.exported.isPoisoned)
                return o.compilation.isPoisoned = !0, o;
            xt(s.exported.directives, o.compilation.directives), xt(s.exported.pipes, o.compilation.pipes);
        }
        else if (Bi(i))
            o.compilation.pipes.add(i);
        else if (Jh(i) || Zo(i))
            o.compilation.directives.add(i);
        else
            return o.compilation.isPoisoned = !0, o;
    } return o; }
    isOrphanComponent(t) { let n = z(t); return !n || n.standalone ? !1 : (this.resolveNgModulesDecls(), !this.ownerNgModule.has(t)); }
};
function xt(e, t) { for (let n of e)
    t.add(n); }
var Jn = new tu;
function _b(e, t) { let n = e; for (; n;) {
    let o = LN(n);
    if (o !== null)
        for (let r = E; r < o.length; r++) {
            let i = o[r];
            if (!te(i) && !Y(i) || i[V] !== n)
                continue;
            let s = o[m], a = Jt(s, r);
            if (ve(a)) {
                let c = s.data[a.directiveStart + a.componentOffset], l = Od(c);
                if (l !== null && (!t || t(n, l)))
                    return l;
                break;
            }
        }
    n = n.parentNode;
} return null; }
function Od(e) { return e.debugInfo?.className || e.type.name || null; }
var Zi = {}, Lt = class {
    injector;
    parentInjector;
    constructor(t, n) { this.injector = t, this.parentInjector = n; }
    get(t, n, o) { let r = this.injector.get(t, Zi, o); return r !== Zi || n === Zi ? r : this.parentInjector.get(t, n, o); }
};
function vr(e) { return Ia(e) ? Array.isArray(e) || !(e instanceof Map) && Symbol.iterator in e : !1; }
function bb(e, t, n) { let o = e[Symbol.iterator](), r = t[Symbol.iterator](); for (;;) {
    let i = o.next(), s = r.next();
    if (i.done && s.done)
        return !0;
    if (i.done || s.done || !n(i.value, s.value))
        return !1;
} }
function $y(e, t) { if (Array.isArray(e))
    for (let n = 0; n < e.length; n++)
        t(e[n]);
else {
    let n = e[Symbol.iterator](), o;
    for (; !(o = n.next()).done;)
        t(o.value);
} }
function Ia(e) { return e !== null && (typeof e == "function" || typeof e == "object"); }
function Uy(e, t) { let n = vr(e), o = vr(t); return n && o ? bb(e, t, Uy) : !n && (e && (typeof e == "object" || typeof e == "function")) && !o && (t && (typeof t == "object" || typeof t == "function")) ? !0 : Object.is(e, t); }
function qe(e, t, n) { return e[t] = n; }
function mo(e, t) { return e[t]; }
function U(e, t, n) { if (n === j)
    return !1; let o = e[t]; return Object.is(o, n) ? !1 : (e[t] = n, !0); }
function hn(e, t, n, o) { let r = U(e, t, n); return U(e, t + 1, o) || r; }
function Da(e, t, n, o, r) { let i = hn(e, t, n, o); return U(e, t + 2, r) || i; }
function Fe(e, t, n, o, r, i) { let s = hn(e, t, n, o); return hn(e, t + 2, r, i) || s; }
function Pt(e, t, n) { return function o(r) { let i = o.__ngNativeEl__; i !== void 0 && iw(r, i); let s = ve(e) ? fe(e.index, t) : t; pa(s, 5); let a = t[F], c = Xh(t, a, n, r), l = o.__ngNextListenerFn__; for (; l;)
    c = Xh(t, a, l, r) && c, l = l.__ngNextListenerFn__; return c; }; }
function Xh(e, t, n, o) { let r = R(null); try {
    return P(L.OutputStart, t, n), n(o) !== !1;
}
catch (i) {
    return Nd(e, i), !1;
}
finally {
    P(L.OutputEnd, t, n), R(r);
} }
function xd(e, t, n, o, r, i, s, a) { let c = xn(e), l = !1, u = null; if (!o && c && (u = Rb(t, n, i, e.index)), u !== null) {
    let d = u.__ngLastListenerFn__ || u;
    d.__ngNextListenerFn__ = s, u.__ngLastListenerFn__ = s, l = !0;
}
else {
    let d = Z(e, n), f = o ? o(d) : d;
    sw(n, f, i, a), o || (a.__ngNativeEl__ = d);
    let p = r.listen(f, i, a);
    if (!Ab(i)) {
        let h = o ? v => o(x(v[e.index])) : e.index;
        Gy(h, t, n, i, a, p, !1);
    }
} return l; }
function Ab(e) { return e.startsWith("animation") || e.startsWith("transition"); }
function Rb(e, t, n, o) { let r = e.cleanup; if (r != null)
    for (let i = 0; i < r.length - 1; i += 2) {
        let s = r[i];
        if (s === n && r[i + 1] === o) {
            let a = t[Qt], c = r[i + 2];
            return a && a.length > c ? a[c] : null;
        }
        typeof s == "string" && (i += 2);
    } return null; }
function Gy(e, t, n, o, r, i, s) { let a = t.firstCreatePass ? Xp(t) : null, c = Jp(n), l = c.length; c.push(r, i), a && a.push(o, e, l, (l + 1) * (s ? -1 : 1)); }
function Ob(e, t, n, o, r) { let i = Pt(e, t, n), s = nu(e, t, o, r, i); }
function nu(e, t, n, o, r) { let i = null, s = null, a = null, c = !1, l = e.directiveToIndex.get(n.type); if (typeof l == "number" ? i = l : [i, s, a] = l, s !== null && a !== null && e.hostDirectiveOutputs && Object.hasOwn(e.hostDirectiveOutputs, o)) {
    let u = e.hostDirectiveOutputs[o];
    for (let d = 0; d < u.length; d += 2) {
        let f = u[d];
        if (f >= s && f <= a)
            c = !0, vs(e, t, f, u[d + 1], o, r);
        else if (f > a)
            break;
    }
} return Object.hasOwn(n.outputs, o) && (c = !0, vs(e, t, i, o, o, r)), c; }
function vs(e, t, n, o, r, i) { let s = t[n], a = t[m], l = a.data[n].outputs[o], d = s[l].subscribe(i); Gy(e.index, a, t, r, i, d, !0); }
function Wy() { zy(); }
function zy() { let e = g(), t = w(), n = N(); if (t.firstCreatePass && xb(t, n), n.controlDirectiveIndex === -1)
    return; K("NgSignalForms"); let o = e[n.controlDirectiveIndex]; t.data[n.controlDirectiveIndex].controlDef.create(o, new ys(e, t, n)); }
function qy() { Qy(); }
function Qy() { let e = g(), t = w(), n = Ce(); if (n.controlDirectiveIndex === -1)
    return; let o = t.data[n.controlDirectiveIndex].controlDef, r = e[n.controlDirectiveIndex]; o.update(r, new ys(e, t, n)); }
var ys = class {
    lView;
    tView;
    tNode;
    hasPassThrough;
    constructor(t, n, o) { this.lView = t, this.tView = n, this.tNode = o, this.hasPassThrough = !!(o.flags & 4096); }
    get customControl() { return this.tNode.customControlIndex !== -1 ? this.lView[this.tNode.customControlIndex] : void 0; }
    get nativeElement() { return Z(this.tNode, this.lView); }
    get descriptor() { return `<${this.tNode.value}>`; }
    listenToCustomControlOutput(t, n) { let o = this.tView.data[this.tNode.customControlIndex]; nu(this.tNode, this.lView, o, t, Pt(this.tNode, this.lView, n)); }
    listenToCustomControlModel(t) { let n = this.tNode.flags & 1024 ? "valueChange" : "checkedChange", o = this.tView.data[this.tNode.customControlIndex]; nu(this.tNode, this.lView, o, n, Pt(this.tNode, this.lView, t)); }
    listenToDom(t, n) { xd(this.tNode, this.tView, this.lView, void 0, this.lView[C], t, n, Pt(this.tNode, this.lView, n)); }
    setInputOnDirectives(t, n) { let o = this.tNode.inputs?.[t], r = this.tNode.hostDirectiveInputs?.[t]; if (!o && !r)
        return !1; let i = !1; if (o)
        for (let s of o) {
            if (s === this.tNode.controlDirectiveIndex)
                continue;
            let a = this.tView.data[s], c = this.lView[s];
            fn(a, c, t, n), i = !0;
        } if (r)
        for (let s = 0; s < r.length; s += 2) {
            let a = r[s];
            if (a === this.tNode.controlDirectiveIndex)
                continue;
            let c = r[s + 1], l = this.tView.data[a], u = this.lView[a];
            fn(l, u, c, n), i = !0;
        } return i; }
    setCustomControlModelInput(t) { let n = this.tView.data[this.tNode.customControlIndex], o = this.tNode.flags & 1024 ? "value" : "checked"; ey(this.tNode, this.tView, this.lView, n, o, t); }
    customControlHasInput(t) { if (this.tNode.customControlIndex === -1)
        return !1; let n = this.tView.data[this.tNode.customControlIndex]; return (n.signalFormsInputPresence ??= this._buildCustomControlInputCache(n))[t] === !0; }
    _buildCustomControlInputCache(t) { let n = {}; for (let o in t.inputs)
        n[o] = !0; if (t.hostDirectives !== null) {
        let o = [...t.hostDirectives];
        for (; o.length > 0;) {
            let r = o.shift();
            if (typeof r != "function") {
                for (let s in r.inputs)
                    n[r.inputs[s]] = !0;
                let i = eg(r.directive);
                i !== null && o.push(...i);
                continue;
            }
            for (let i of r()) {
                if (typeof i == "function")
                    continue;
                if (i.inputs)
                    for (let a = 0; a < i.inputs.length; a += 2) {
                        let c = i.inputs[a + 1] || i.inputs[a];
                        n[c] = !0;
                    }
                let s = eg(i.directive);
                s !== null && o.push(...s);
            }
        }
    } return n; }
};
function eg(e) { return typeof e == "function" && "\u0275dir" in e ? e.\u0275dir.hostDirectives ?? null : null; }
function xb(e, t, n) { for (let r = t.directiveStart; r < t.directiveEnd; r++)
    if (e.data[r].controlDef) {
        t.controlDirectiveIndex = r;
        break;
    } if (t.controlDirectiveIndex === -1)
    return; let o = e.data[t.controlDirectiveIndex].controlDef; if (o.passThroughInput && (t.inputs?.[o.passThroughInput]?.length ?? 0) > 1) {
    t.flags |= 4096;
    return;
} kb(e, t); }
function kb(e, t) { for (let n = t.directiveStart; n < t.directiveEnd; n++) {
    let o = e.data[n];
    if (!(t.directiveToIndex && !t.directiveToIndex.has(o.type))) {
        if (tg(o, "value")) {
            t.flags |= 1024, t.customControlIndex = n;
            return;
        }
        if (tg(o, "checked")) {
            t.flags |= 2048, t.customControlIndex = n;
            return;
        }
    }
} if (t.hostDirectiveInputs !== null && t.hostDirectiveOutputs !== null && t.directiveToIndex !== null) {
    let n = (o, r) => { let i = t.hostDirectiveInputs[o], s = t.hostDirectiveOutputs[o + "Change"]; if (!i || !s)
        return !1; for (let a = 0; a < i.length; a += 2) {
        let c = i[a];
        for (let l = 0; l < s.length; l += 2) {
            let u = s[l];
            if (c === u)
                for (let d of t.directiveToIndex.values()) {
                    if (!Array.isArray(d))
                        continue;
                    let [f, p, h] = d;
                    if (c >= p && c <= h)
                        return t.flags |= r, t.customControlIndex = f, !0;
                }
        }
    } return !1; };
    if (n("value", 1024) || n("checked", 2048))
        return;
} }
function tg(e, t) { return Lb(e, t) && Pb(e, t + "Change"); }
function Lb(e, t) { return t in e.inputs; }
function Pb(e, t) { return t in e.outputs; }
var ht = Symbol("BINDING"), ng = { kind: "input", requiredVars: 1 }, Fb = { kind: "output", requiredVars: 0 };
function og(e, t, n) { let o = g(), r = ge(); if (U(o, r, n)) {
    let i = o[m], s = Ce(), a = fe(s.index, o);
    pa(a, 1);
    let c = i.directiveRegistry[e], l = ey(s, i, o, c, t, n);
} }
function Yy(e, t) { if (e === "formField") {
    let o = { [ht]: ng, create: () => { zy(); }, update: () => { og(o.targetIdx, e, t()), Qy(); } };
    return o;
} let n = { [ht]: ng, update: () => og(n.targetIdx, e, t()) }; return n; }
function Zy(e, t) { let n = { [ht]: Fb, create: () => { let o = g(), r = N(), s = o[m].directiveRegistry[n.targetIdx]; Ob(r, o, t, s, e); } }; return n; }
function jb(e, t) { let n = Yy(e, t), o = Zy(e + "Change", i => t.set(i)); return { [ht]: { kind: "twoWay", requiredVars: n[ht].requiredVars + o[ht].requiredVars }, set targetIdx(i) { n.targetIdx = i, o.targetIdx = i; }, create: o.create, update: n.update }; }
var Ky = new b("");
function Es(e, t, n) { let o = n ? e.styles : null, r = n ? e.classes : null, i = 0; if (t !== null)
    for (let s = 0; s < t.length; s++) {
        let a = t[s];
        if (typeof a == "number")
            i = a;
        else if (i == 1)
            r = li(r, a);
        else if (i == 2) {
            let c = a, l = t[++s];
            o = li(o, c + ": " + l + ";");
        }
    } n ? e.styles = o : e.stylesWithoutHost = o, n ? e.classes = r : e.classesWithoutHost = r; }
function vo(e, t = 0) { let n = g(); if (n === null)
    return He(e, t); let o = N(); return Ru(o, n, W(e), t); }
function Jy() { let e = "invalid"; throw new Error(e); }
function Xy(e, t, n, o, r) { let i = o === null ? null : { "": -1 }, s = r(e, n); if (s !== null) {
    let a = s, c = null, l = null;
    for (let u of s)
        if (u.resolveHostDirectives !== null) {
            [a, c, l] = u.resolveHostDirectives(s);
            break;
        }
    Bb(e, t, n, a, i, c, l);
} i !== null && o !== null && Hb(n, o, i); }
function Hb(e, t, n) { let o = e.localNames = []; for (let r = 0; r < t.length; r += 2) {
    let i = n[t[r + 1]];
    if (i == null)
        throw new M(-301, !1);
    o.push(t[r], i);
} }
function Vb(e, t, n) { t.componentOffset = n, (e.components ??= []).push(t.index); }
function Bb(e, t, n, o, r, i, s) { let a = o.length, c = null; for (let f = 0; f < a; f++) {
    let p = o[f];
    c === null && Le(p) && (c = p, Vb(e, n, f)), Cl(rs(n, t), e, p.type);
} qb(n, e.data.length, a), c?.viewProvidersResolver && c.viewProvidersResolver(c); for (let f = 0; f < a; f++) {
    let p = o[f];
    p.providersResolver && p.providersResolver(p);
} let l = !1, u = !1, d = Gr(e, t, a, null); a > 0 && (n.directiveToIndex = new Map); for (let f = 0; f < a; f++) {
    let p = o[f];
    if (n.mergedAttrs = Zn(n.mergedAttrs, p.hostAttrs), Ub(e, n, t, d, p), zb(d, p, r), s !== null && s.has(p)) {
        let [v, y] = s.get(p);
        n.directiveToIndex.set(p.type, [d, v + n.directiveStart, y + n.directiveStart]);
    }
    else
        (i === null || !i.has(p)) && n.directiveToIndex.set(p.type, d);
    p.contentQueries !== null && (n.flags |= 4), (p.hostBindings !== null || p.hostAttrs !== null || p.hostVars !== 0) && (n.flags |= 64);
    let h = p.type.prototype;
    !l && (h.ngOnChanges || h.ngOnInit || h.ngDoCheck) && ((e.preOrderHooks ??= []).push(n.index), l = !0), !u && (h.ngOnChanges || h.ngDoCheck) && ((e.preOrderCheckHooks ??= []).push(n.index), u = !0), d++;
} $b(e, n, i); }
function $b(e, t, n) { for (let o = t.directiveStart; o < t.directiveEnd; o++) {
    let r = e.data[o];
    if (n === null || !n.has(r))
        rg(0, t, r, o), rg(1, t, r, o), sg(t, o, !1);
    else {
        let i = n.get(r);
        ig(0, t, i, o), ig(1, t, i, o), sg(t, o, !0);
    }
} }
function rg(e, t, n, o) { let r = e === 0 ? n.inputs : n.outputs; for (let i in r)
    if (Object.hasOwn(r, i)) {
        let s;
        e === 0 ? s = t.inputs ??= {} : s = t.outputs ??= {}, s[i] ??= [], s[i].push(o), eE(t, i);
    } }
function ig(e, t, n, o) { let r = e === 0 ? n.inputs : n.outputs; for (let i in r)
    if (Object.hasOwn(r, i)) {
        let s = r[i], a;
        e === 0 ? a = t.hostDirectiveInputs ??= {} : a = t.hostDirectiveOutputs ??= {}, a[s] ??= [], a[s].push(o, i), eE(t, s);
    } }
function eE(e, t) { t === "class" ? e.flags |= 8 : t === "style" && (e.flags |= 16); }
function sg(e, t, n) { let { attrs: o, inputs: r, hostDirectiveInputs: i } = e; if (o === null || !n && r === null || n && i === null || ld(e)) {
    e.initialInputs ??= [], e.initialInputs.push(null);
    return;
} let s = null, a = 0; for (; a < o.length;) {
    let c = o[a];
    if (c === 0) {
        a += 4;
        continue;
    }
    else if (c === 5) {
        a += 2;
        continue;
    }
    else if (typeof c == "number")
        break;
    if (!n && Object.hasOwn(r, c)) {
        let l = r[c];
        for (let u of l)
            if (u === t) {
                s ??= [], s.push(c, o[a + 1]);
                break;
            }
    }
    else if (n && Object.hasOwn(i, c)) {
        let l = i[c];
        for (let u = 0; u < l.length; u += 2)
            if (l[u] === t) {
                s ??= [], s.push(l[u + 1], o[a + 1]);
                break;
            }
    }
    a += 2;
} e.initialInputs ??= [], e.initialInputs.push(s); }
function Ub(e, t, n, o, r) { e.data[o] = r; let i = r.factory || (r.factory = hi(r.type, !0)), s = new un(i, Le(r), vo, null); e.blueprint[o] = s, n[o] = s, Gb(e, t, o, Gr(e, n, r.hostVars, j), r); }
function Gb(e, t, n, o, r) { let i = r.hostBindings; if (i) {
    let s = e.hostBindingOpCodes;
    s === null && (s = e.hostBindingOpCodes = []);
    let a = ~t.index;
    Wb(s) != a && s.push(a), s.push(n, o, i);
} }
function Wb(e) { let t = e.length; for (; t > 0;) {
    let n = e[--t];
    if (typeof n == "number" && n < 0)
        return n;
} return 0; }
function zb(e, t, n) { if (n) {
    if (t.exportAs)
        for (let o = 0; o < t.exportAs.length; o++)
            n[t.exportAs[o]] = e;
    Le(t) && (n[""] = e);
} }
function qb(e, t, n) { e.flags |= 1, e.directiveStart = t, e.directiveEnd = t + n, e.providerIndexes = t; }
function kd(e, t, n, o, r, i, s, a) { let c = t[m], l = c.consts, u = ie(l, s), d = Vt(c, e, n, o, u); return i && Xy(c, t, d, ie(l, a), r), d.mergedAttrs = Zn(d.mergedAttrs, d.attrs), d.attrs !== null && Es(d, d.attrs, !1), d.mergedAttrs !== null && Es(d, d.mergedAttrs, !0), c.queries !== null && c.queries.elementStart(c, d), d; }
function Ld(e, t) { Zg(e, t), gc(t) && e.queries.elementEnd(t); }
function tE(e, t, n, o, r, i) { let s = t.consts, a = ie(s, r), c = Vt(t, e, n, o, a); if (c.mergedAttrs = Zn(c.mergedAttrs, c.attrs), i != null) {
    let l = ie(s, i);
    c.localNames = [];
    for (let u = 0; u < l.length; u += 2)
        c.localNames.push(l[u], -1);
} return c.attrs !== null && Es(c, c.attrs, !1), c.mergedAttrs !== null && Es(c, c.mergedAttrs, !0), t.queries !== null && t.queries.elementStart(t, c), c; }
var nE = typeof ShadowRoot < "u", Qb = typeof Document < "u";
function Yb(e) { return Object.keys(e).map(t => { let [n, o, r] = e[t], i = { propName: n, templateName: t, isSignal: (o & ia.SignalBased) !== 0 }; return r && (i.transform = r), i; }); }
function Zb(e) { return Object.keys(e).map(t => ({ propName: e[t], templateName: t })); }
function Kb(e, t, n) { let o = t instanceof ut ? t : t?.injector; return o && e.getStandaloneInjector !== null && (o = e.getStandaloneInjector(o) || o), o ? new Lt(n, o) : n; }
function Jb(e) { let t = e.get(mr, null); if (t === null)
    throw new M(407, !1); let n = e.get(Fy, null), o = e.get(Ot, null), r = e.get(Mn, null, { optional: !0 }); return { rendererFactory: t, sanitizer: n, changeDetectionScheduler: o, ngReflect: !1, tracingService: r }; }
function Xb(e, t, n) { let o = oE(e); return zs(t, o, o === "svg" ? Ii : o === "math" ? vc : n); }
function eA(e) { if ((e && "localName" in e && typeof e.localName == "string" ? e.localName : e?.tagName)?.toLowerCase() === "script")
    throw new M(905, !1); }
function oE(e) { return (e.selectors[0][0] || "div").toLowerCase(); }
var gn = class {
    componentDef;
    ngModule;
    selector;
    componentType;
    ngContentSelectors;
    isBoundToModule;
    cachedInputs = null;
    cachedOutputs = null;
    get inputs() { return this.cachedInputs ??= Yb(this.componentDef.inputs), this.cachedInputs; }
    get outputs() { return this.cachedOutputs ??= Zb(this.componentDef.outputs), this.cachedOutputs; }
    constructor(t, n) { this.componentDef = t, this.ngModule = n, this.componentType = t.type, this.selector = CS(t.selectors), this.ngContentSelectors = t.ngContentSelectors ?? [], this.isBoundToModule = !!n; }
    create(t, n, o, r, i, s, a) { P(L.DynamicComponentStart); let c = R(null); try {
        let l = this.componentDef, u = Kb(l, r || this.ngModule, t), d = Jb(u), f = d.tracingService;
        return f && f.componentCreate ? f.componentCreate(Od(l), () => this.createComponentRef(d, u, n, o, i, s, a)) : this.createComponentRef(d, u, n, o, i, s, a);
    }
    finally {
        R(c);
    } }
    createComponentRef(t, n, o, r, i, s, a) { let c = this.componentDef, l = tA(r, c, s, i), u = t.rendererFactory.createRenderer(null, c), d = r ? t_(u, r, c.encapsulation, n) : Xb(c, u, a ?? null); eA(d); let f = n.get(Ky, null), p = nA(d, () => n.get(Pn, null) ?? Ar()); f && f.addHost(p); let h = s?.some(ag) || i?.some(I => typeof I != "function" && I.bindings.some(ag)), v = Ur(null, l, null, 512 | Dd(c), null, null, t, u, n, null, Wm(d, n, !0)); f && nE && p instanceof ShadowRoot && Ho(v, () => { f.removeHost(p); }), v[E] = d, Si(v); let y = null; try {
        let I = kd(E, v, 2, "#host", () => l.directiveRegistry, !0, 0);
        gv(u, d, I), _e(d, v), sa(l, v, I), Xu(l, I, v), Ld(l, I), o !== void 0 && rA(I, this.ngContentSelectors, o), y = fe(I.index, v), v[F] = y[F], da(l, v, null);
    }
    catch (I) {
        throw y !== null && Nl(y), Nl(v), I;
    }
    finally {
        P(L.DynamicComponentEnd), _i();
    } return new Is(this.componentType, v, !!h); }
};
function tA(e, t, n, o) { let r = e ? ["ng-version", "22.1.4"] : TS(t.selectors[0]), i = null, s = null, a = 0; if (n)
    for (let u of n)
        a += u[ht].requiredVars, u.create && (u.targetIdx = 0, (i ??= []).push(u)), u.update && (u.targetIdx = 0, (s ??= []).push(u)); if (o)
    for (let u = 0; u < o.length; u++) {
        let d = o[u];
        if (typeof d != "function")
            for (let f of d.bindings) {
                a += f[ht].requiredVars;
                let p = u + 1;
                f.create && (f.targetIdx = p, (i ??= []).push(f)), f.update && (f.targetIdx = p, (s ??= []).push(f));
            }
    } let c = [t]; if (o)
    for (let u of o) {
        let d = typeof u == "function" ? u : u.type, f = xe(d);
        c.push(f);
    } return oa(0, null, oA(i, s), 1, a, c, null, null, null, [r], null); }
function nA(e, t) { let n = e.getRootNode?.(); return Qb && n instanceof Document ? n.head : n && nE && n instanceof ShadowRoot ? n : t().head; }
function oA(e, t) { return !e && !t ? null : n => { if (n & 1 && e)
    for (let o of e)
        o.create(); if (n & 2 && t)
    for (let o of t)
        o.update(); }; }
function ag(e) { let t = e[ht].kind; return t === "input" || t === "twoWay"; }
var Is = class extends Py {
    _rootLView;
    _hasInputBindings;
    instance;
    hostView;
    changeDetectorRef;
    componentType;
    location;
    previousInputValues = null;
    _tNode;
    constructor(t, n, o) { super(), this._rootLView = n, this._hasInputBindings = o, this._tNode = Jt(n[m], E), this.location = io(this._tNode, n), this.instance = fe(this._tNode.index, n)[F], this.hostView = this.changeDetectorRef = new vt(n, void 0), this.componentType = t; }
    setInput(t, n) { this._hasInputBindings; let o = this._tNode; if (this.previousInputValues ??= new Map, this.previousInputValues.has(t) && Object.is(this.previousInputValues.get(t), n))
        return; let r = this._rootLView, i = ua(o, r[m], r, t, n); this.previousInputValues.set(t, n); let s = fe(o.index, r); pa(s, 1); }
    get injector() { return new ye(this._tNode, this._rootLView); }
    destroy() { this.hostView.destroy(); }
    onDestroy(t) { this.hostView.onDestroy(t); }
};
function rA(e, t, n) { let o = e.projection = []; for (let r = 0; r < t.length; r++) {
    let i = n[r];
    o.push(i != null && i.length ? Array.from(i) : null);
} }
var Ca = (() => { class e {
    static __NG_ELEMENT_ID__ = iA;
} return e; })();
function iA() { let e = N(); return rE(e, g()); }
var ou = class e extends Ca {
    _lContainer;
    _hostTNode;
    _hostLView;
    constructor(t, n, o) { super(), this._lContainer = t, this._hostTNode = n, this._hostLView = o; }
    get element() { return io(this._hostTNode, this._hostLView); }
    get injector() { return new ye(this._hostTNode, this._hostLView); }
    get parentInjector() { let t = Au(this._hostTNode, this._hostLView); if (em(t)) {
        let n = ns(t, this._hostLView), o = ts(t), r = n[m].data[o + 8];
        return new ye(r, n);
    }
    else
        return new ye(null, this._hostLView); }
    clear() { for (; this.length > 0;)
        this.remove(this.length - 1); }
    get(t) { let n = cg(this._lContainer); return n !== null && n[t] || null; }
    get length() { return this._lContainer.length - k; }
    createEmbeddedView(t, n, o) { let r, i; typeof o == "number" ? r = o : o != null && (r = o.index, i = o.injector); let s = gr(this._lContainer, t.ssrId), a = t.createEmbeddedViewImpl(n || {}, i, s); return this.insertImpl(a, r, pn(this._hostTNode, s)), a; }
    createComponent(t, n, o, r, i, s, a) { let c, l = n || {}; c = l.index, o = l.injector, r = l.projectableNodes, i = l.environmentInjector || l.ngModuleRef, s = l.directives, a = l.bindings; let u = new gn(z(t)), d = o || this.parentInjector; if (!i && u.ngModule == null) {
        let I = this.parentInjector.get(ut, null);
        I && (i = I);
    } let f = z(u.componentType ?? {}), p = gr(this._lContainer, f?.id ?? null), h = p?.firstChild ?? null, v = u.create(d, r, h, i, s, a, this._getHostElementNamespace()); return this.insertImpl(v.hostView, c, pn(this._hostTNode, p)), v; }
    _getHostElementNamespace() { if (this._hostTNode.type & 2) {
        let t = this._hostTNode.parent ?? this._hostLView[X];
        return t !== null && t.type & 2 && typeof t.value == "string" && t.value.toLowerCase() === "foreignobject" ? null : t?.namespace ?? null;
    } return this._hostTNode.namespace; }
    insert(t, n) { return this.insertImpl(t, n, !0); }
    insertImpl(t, n, o) { let r = t._lView; if (Zp(r)) {
        let a = this.indexOf(t);
        if (a !== -1)
            this.detach(a);
        else {
            let c = r[q], l = new e(c, c[X], c[q]);
            l.detach(l.indexOf(t));
        }
    } let i = this._adjustIndex(n), s = this._lContainer; return Ct(s, r, i, o), t.attachToViewContainerRef(), lc(al(s), i, t), t; }
    move(t, n) { return this.insert(t, n); }
    indexOf(t) { let n = cg(this._lContainer); return n !== null ? n.indexOf(t) : -1; }
    remove(t) { let n = this._adjustIndex(t, -1), o = fr(this._lContainer, n); o && (So(al(this._lContainer), n), $r(o[m], o)); }
    detach(t) { let n = this._adjustIndex(t, -1), o = fr(this._lContainer, n); return o && So(al(this._lContainer), n) != null ? new vt(o) : null; }
    _adjustIndex(t, n = 0) { return t ?? this.length + n; }
};
function cg(e) { return e[xo]; }
function al(e) { return e[xo] || (e[xo] = []); }
function rE(e, t) { let n, o = t[e.index]; return Y(o) ? n = o : (n = wd(o, t, null, e), t[e.index] = n, ra(t, n)), iE(n, t, e, o), new ou(n, e, t); }
function sA(e, t) { let n = e[C], o = n.createComment(""), r = Z(t, e), i = n.parentNode(r); return ze(n, i, o, n.nextSibling(r), !1), o; }
var iE = aE, Pd = () => !1;
function sE(e, t, n) { return Pd(e, t, n); }
function aE(e, t, n, o) { if (e[Xe])
    return; let r; n.type & 8 ? r = x(o) : r = sA(t, n), e[Xe] = r; }
function aA(e, t, n) { if (e[Xe] && e[Se])
    return !0; let o = n[ce], r = t.index - E; if (!o || so(t) || Us(o, r))
    return !1; let s = Al(o, r), a = o.data[ao]?.[r]; if (a === void 0)
    return !1; let [c, l] = Ib(s, a); return e[Xe] = c, e[Se] = l, !0; }
function cA(e, t, n, o) { Pd(e, n, t) || aE(e, t, n, o); }
function cE() { iE = cA, Pd = aA; }
var ru = class e {
    queryList;
    matches = null;
    constructor(t) { this.queryList = t; }
    clone() { return new e(this.queryList); }
    setDirty() { this.queryList.setDirty(); }
}, iu = class e {
    queries;
    constructor(t = []) { this.queries = t; }
    createEmbeddedView(t) { let n = t.queries; if (n !== null) {
        let o = t.contentQueries !== null ? t.contentQueries[0] : n.length, r = [];
        for (let i = 0; i < o; i++) {
            let s = n.getByIndex(i), a = this.queries[s.indexInDeclarationView];
            r.push(a.clone());
        }
        return new e(r);
    } return null; }
    insertView(t) { this.dirtyQueriesWithMatches(t); }
    detachView(t) { this.dirtyQueriesWithMatches(t); }
    finishViewCreation(t) { this.dirtyQueriesWithMatches(t); }
    dirtyQueriesWithMatches(t) { for (let n = 0; n < this.queries.length; n++)
        jd(t, n).matches !== null && this.queries[n].setDirty(); }
}, Ds = class {
    flags;
    read;
    predicate;
    constructor(t, n, o = null) { this.flags = n, this.read = o, typeof t == "string" ? this.predicate = pA(t) : this.predicate = t; }
}, su = class e {
    queries;
    constructor(t = []) { this.queries = t; }
    elementStart(t, n) { for (let o = 0; o < this.queries.length; o++)
        this.queries[o].elementStart(t, n); }
    elementEnd(t) { for (let n = 0; n < this.queries.length; n++)
        this.queries[n].elementEnd(t); }
    embeddedTView(t) { let n = null; for (let o = 0; o < this.length; o++) {
        let r = n !== null ? n.length : 0, i = this.getByIndex(o).embeddedTView(t, r);
        i && (i.indexInDeclarationView = o, n !== null ? n.push(i) : n = [i]);
    } return n !== null ? new e(n) : null; }
    template(t, n) { for (let o = 0; o < this.queries.length; o++)
        this.queries[o].template(t, n); }
    getByIndex(t) { return this.queries[t]; }
    get length() { return this.queries.length; }
    track(t) { this.queries.push(t); }
}, au = class e {
    metadata;
    matches = null;
    indexInDeclarationView = -1;
    crossesNgTemplate = !1;
    _declarationNodeIndex;
    _appliesToNextNode = !0;
    constructor(t, n = -1) { this.metadata = t, this._declarationNodeIndex = n; }
    elementStart(t, n) { this.isApplyingToNode(n) && this.matchTNode(t, n); }
    elementEnd(t) { this._declarationNodeIndex === t.index && (this._appliesToNextNode = !1); }
    template(t, n) { this.elementStart(t, n); }
    embeddedTView(t, n) { return this.isApplyingToNode(t) ? (this.crossesNgTemplate = !0, this.addMatch(-t.index, n), new e(this.metadata)) : null; }
    isApplyingToNode(t) { if (this._appliesToNextNode && (this.metadata.flags & 1) !== 1) {
        let n = this._declarationNodeIndex, o = t.parent;
        for (; o !== null && o.type & 8 && o.index !== n;)
            o = o.parent;
        return n === (o !== null ? o.index : -1);
    } return this._appliesToNextNode; }
    matchTNode(t, n) { let o = this.metadata.predicate; if (Array.isArray(o))
        for (let r = 0; r < o.length; r++) {
            let i = o[r];
            this.matchTNodeWithReadOption(t, n, lA(n, i)), this.matchTNodeWithReadOption(t, n, qi(n, t, i, !1, !1));
        }
    else
        o === pr ? n.type & 4 && this.matchTNodeWithReadOption(t, n, -1) : this.matchTNodeWithReadOption(t, n, qi(n, t, o, !1, !1)); }
    matchTNodeWithReadOption(t, n, o) { if (o !== null) {
        let r = this.metadata.read;
        if (r !== null)
            if (r === br || r === Ca || r === pr && n.type & 4)
                this.addMatch(n.index, -2);
            else {
                let i = qi(n, t, r, !1, !1);
                i !== null && this.addMatch(n.index, i);
            }
        else
            this.addMatch(n.index, o);
    } }
    addMatch(t, n) { this.matches === null ? this.matches = [t, n] : this.matches.push(t, n); }
};
function lA(e, t) { let n = e.localNames; if (n !== null) {
    for (let o = 0; o < n.length; o += 2)
        if (n[o] === t)
            return n[o + 1];
} return null; }
function uA(e, t) { return e.type & 11 ? io(e, t) : e.type & 4 ? ha(e, t) : null; }
function dA(e, t, n, o) { return n === -1 ? uA(t, e) : n === -2 ? fA(e, t, o) : sr(e, e[m], n, t); }
function fA(e, t, n) { if (n === br)
    return io(t, e); if (n === pr)
    return ha(t, e); if (n === Ca)
    return rE(t, e); }
function lE(e, t, n, o) { let r = t[Je].queries[o]; if (r.matches === null) {
    let i = e.data, s = n.matches, a = [];
    for (let c = 0; s !== null && c < s.length; c += 2) {
        let l = s[c];
        if (l < 0)
            a.push(null);
        else {
            let u = i[l];
            a.push(dA(t, u, s[c + 1], n.metadata.read));
        }
    }
    r.matches = a;
} return r.matches; }
function cu(e, t, n, o) { let r = e.queries.getByIndex(n), i = r.matches; if (i !== null) {
    let s = lE(e, t, r, n);
    for (let a = 0; a < i.length; a += 2) {
        let c = i[a];
        if (c > 0)
            o.push(s[a / 2]);
        else {
            let l = i[a + 1], u = t[-c];
            for (let d = k; d < u.length; d++) {
                let f = u[d];
                f[bt] === f[q] && cu(f[m], f, l, o);
            }
            if (u[Zt] !== null) {
                let d = u[Zt];
                for (let f = 0; f < d.length; f++) {
                    let p = d[f];
                    cu(p[m], p, l, o);
                }
            }
        }
    }
} return o; }
function Fd(e, t) { return e[Je].queries[t].queryList; }
function uE(e, t, n) { let o = new as((n & 4) === 4); return eh(e, t, o, o.destroy), (t[Je] ??= new iu).queries.push(new ru(o)) - 1; }
function dE(e, t, n) { let o = w(); return o.firstCreatePass && (pE(o, new Ds(e, t, n), -1), (t & 2) === 2 && (o.staticViewQueries = !0)), uE(o, g(), t); }
function fE(e, t, n, o) { let r = w(); if (r.firstCreatePass) {
    let i = N();
    pE(r, new Ds(t, n, o), i.index), hA(r, e), (n & 2) === 2 && (r.staticContentQueries = !0);
} return uE(r, g(), n); }
function pA(e) { return e.split(",").map(t => t.trim()); }
function pE(e, t, n) { e.queries === null && (e.queries = new su), e.queries.track(new au(t, n)); }
function hA(e, t) { let n = e.contentQueries || (e.contentQueries = []), o = n.length ? n[n.length - 1] : -1; t !== o && n.push(e.queries.length - 1, t); }
function jd(e, t) { return e.queries.getByIndex(t); }
function hE(e, t) { let n = e[m], o = jd(n, t); return o.crossesNgTemplate ? cu(n, e, t, []) : lE(n, e, o, t); }
function Hd(e, t, n) { let o, r = Np(() => { o._dirtyCounter(); let i = gA(o, e); if (t && i === void 0)
    throw new M(-951, !1); return i; }); return o = r[Qe], o._dirtyCounter = Uc(0), o._flatValue = void 0, r; }
function Vd(e) { return Hd(!0, !1, e); }
function Bd(e) { return Hd(!0, !0, e); }
function $d(e) { return Hd(!1, !1, e); }
function gE(e, t) { let n = e[Qe]; n._lView = g(), n._queryIndex = t, n._queryList = Fd(n._lView, t), n._queryList.onDirty(() => n._dirtyCounter.update(o => o + 1)); }
function gA(e, t) { let n = e._lView, o = e._queryIndex; if (n === void 0 || o === void 0 || n[_] & 4)
    return t ? void 0 : H; let r = Fd(n, o), i = hE(n, o); return r.reset(i, vm), t ? r.first : r._changesDetected || e._flatValue === void 0 ? e._flatValue = r.toArray() : e._flatValue; }
function Ud(e) { return !!e && typeof e.then == "function"; }
function mE(e) { return !!e && typeof e.subscribe == "function"; }
var mn = class {
}, vE = class {
};
function mA(e, t) { return new Xn(e, t ?? null, []); }
var Xn = class extends mn {
    ngModuleType;
    _parent;
    _bootstrapComponents = [];
    _r3Injector;
    instance;
    destroyCbs = [];
    constructor(t, n, o, r = !0) { super(), this.ngModuleType = t, this._parent = n; let i = No(t); this._bootstrapComponents = zo(i.bootstrap), this._r3Injector = lh(t, n, [{ provide: mn, useValue: this }, ...o], ci(t), new Set(["environment"])), r && this.resolveInjectorInitializers(); }
    resolveInjectorInitializers() { this._r3Injector.resolveInjectorInitializers(), this.instance = this._r3Injector.get(this.ngModuleType); }
    get injector() { return this._r3Injector; }
    destroy() { let t = this._r3Injector; !t.destroyed && t.destroy(), this.destroyCbs.forEach(n => n()), this.destroyCbs = null; }
    onDestroy(t) { this.destroyCbs.push(t); }
}, eo = class extends vE {
    moduleType;
    constructor(t) { super(), this.moduleType = t; }
    create(t) { return new Xn(this.moduleType, t, []); }
};
function yE(e, t, n) { return new Xn(e, t, n, !1); }
var yr = class extends mn {
    injector;
    instance = null;
    constructor(t) { super(); let n = new qt([...t.providers, { provide: mn, useValue: this }], t.parent || yi(), t.debugName, new Set(["environment"])); this.injector = n, t.runEnvironmentInitializers && n.resolveInjectorInitializers(); }
    destroy() { this.injector.destroy(); }
    onDestroy(t) { this.injector.onDestroy(t); }
};
function Gd(e, t, n = null) { return new yr({ providers: e, parent: t, debugName: n, runEnvironmentInitializers: !0 }).injector; }
var vA = (() => { class e {
    _injector;
    cachedInjectors = new Map;
    constructor(n) { this._injector = n; }
    getOrCreateStandaloneInjector(n) { if (!n.standalone)
        return null; if (!this.cachedInjectors.has(n)) {
        let o = fc(!1, n.type), r = o.length > 0 ? Gd([o], this._injector, "") : null;
        this.cachedInjectors.set(n, r);
    } return this.cachedInjectors.get(n); }
    ngOnDestroy() { try {
        for (let n of this.cachedInjectors.values())
            n !== null && n.destroy();
    }
    finally {
        this.cachedInjectors.clear();
    } }
    static \u0275prov = ae({ token: e, providedIn: "environment", factory: () => new e(He(ut)) });
} return e; })();
function EE(e) { return at(() => { let t = TE(e), n = Re(G({}, t), { decls: e.decls, vars: e.vars, template: e.template, consts: e.consts || null, ngContentSelectors: e.ngContentSelectors, onPush: e.changeDetection !== xs.Eager, directiveDefs: null, pipeDefs: null, dependencies: t.standalone && e.dependencies || null, getStandaloneInjector: t.standalone ? r => r.get(vA).getOrCreateStandaloneInjector(n) : null, getExternalStyles: null, signals: e.signals ?? !1, data: e.data || {}, encapsulation: e.encapsulation || Pe.Emulated, styles: e.styles || H, _: null, schemas: e.schemas || null, tView: null, id: "" }); t.standalone && K("NgStandalone"), ME(n); let o = e.dependencies; return n.directiveDefs = Cs(o, IE), n.pipeDefs = Cs(o, Ze), n.id = DA(n), n; }); }
function IE(e) { return z(e) || xe(e); }
function Wd(e) { return at(() => ({ type: e.type, bootstrap: e.bootstrap || H, declarations: e.declarations || H, imports: e.imports || H, exports: e.exports || H, transitiveCompileScopes: null, schemas: e.schemas || null, id: e.id || null })); }
function yA(e, t) { if (e == null)
    return lt; let n = {}; for (let o in e)
    if (Object.hasOwn(e, o)) {
        let r = e[o], i, s, a, c;
        Array.isArray(r) ? (a = r[0], i = r[1], s = r[2] ?? i, c = r[3] || null) : (i = r, s = r, a = ia.None, c = null), n[i] = [o, a, c], t[i] = s;
    } return n; }
function EA(e) { if (e == null)
    return lt; let t = {}; for (let n in e)
    Object.hasOwn(e, n) && (t[e[n]] = n); return t; }
function DE(e) { return at(() => { let t = TE(e); return ME(t), t; }); }
function CE(e) { return { type: e.type, name: e.name, factory: null, pure: e.pure !== !1, standalone: e.standalone ?? !0, onDestroy: e.type.prototype.ngOnDestroy || null }; }
function TE(e) { let t = {}; return { type: e.type, providersResolver: null, viewProvidersResolver: null, factory: null, hostBindings: e.hostBindings || null, hostVars: e.hostVars || 0, hostAttrs: e.hostAttrs || null, contentQueries: e.contentQueries || null, declaredInputs: t, inputConfig: e.inputs || lt, exportAs: e.exportAs || null, standalone: e.standalone ?? !0, signals: e.signals === !0, selectors: e.selectors || H, viewQuery: e.viewQuery || null, features: e.features || null, setInput: null, resolveHostDirectives: null, hostDirectives: null, controlDef: null, signalFormsInputPresence: null, inputs: yA(e.inputs, t), outputs: EA(e.outputs), debugInfo: null }; }
function ME(e) { e.features?.forEach(t => t(e)); }
function Cs(e, t) { return e ? () => { let n = typeof e == "function" ? e() : e, o = []; for (let r of n) {
    let i = t(r);
    i !== null && o.push(i);
} return o; } : null; }
var IA = new Map;
function DA(e) { let t = 0, n = typeof e.consts == "function" ? "" : e.consts, o = [e.selectors, e.ngContentSelectors, e.hostVars, e.hostAttrs, n, e.vars, e.decls, e.encapsulation, e.standalone, e.signals, e.exportAs, JSON.stringify(e.inputs), JSON.stringify(e.outputs), Object.getOwnPropertyNames(e.type.prototype), !!e.contentQueries, !!e.viewQuery]; for (let i of o.join("|"))
    t = Math.imul(31, t) + i.charCodeAt(0) << 0; return t += 2147483648, "c" + t; }
var Ko = "__ngAsyncComponentMetadataFn__", NE = "__ngAsyncMetadataLoaded__";
function CA(e) { let t = e; return t[Ko] === NE ? null : t[Ko] ?? null; }
function wE(e, t, n) { let o = e; return o[Ko] = () => Promise.all(t()).then(r => (n(...r), o[Ko] = NE, r)), o[Ko]; }
function zd(e, t, n, o) { return at(() => { let r = e; t !== null && (Object.hasOwn(r, "decorators") && r.decorators !== void 0 ? r.decorators.push(...t) : r.decorators = t), n !== null && (r.ctorParameters = n), o !== null && (Object.hasOwn(r, "propDecorators") && r.propDecorators !== void 0 ? r.propDecorators = G(G({}, r.propDecorators), o) : r.propDecorators = o); }); }
var qd = new b("");
function SE(e) { return Be([{ provide: qd, multi: !0, useValue: e }]); }
var Qd = (() => { class e {
    resolve;
    reject;
    initialized = !1;
    done = !1;
    donePromise = new Promise((n, o) => { this.resolve = n, this.reject = o; });
    appInits = D(qd, { optional: !0 }) ?? [];
    injector = D(me);
    constructor() { }
    runInitializers() { if (this.initialized)
        return; let n = []; for (let r of this.appInits) {
        let i = Ro(this.injector, r);
        if (Ud(i))
            n.push(i);
        else if (mE(i)) {
            let s = new Promise((a, c) => { i.subscribe({ complete: a, error: c }); });
            n.push(s);
        }
    } let o = () => { this.done = !0, this.resolve(); }; Promise.all(n).then(() => { o(); }).catch(r => { this.reject(r); }), n.length === 0 && o(), this.initialized = !0; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = Et({ token: e, factory: e.\u0275fac });
} return e; })(), vn = new Map, Er = new Set;
function _E(e) { return Oe(this, null, function* () { let t = vn; vn = new Map; let n = new Map; function o(i) { let s = n.get(i); if (s)
    return s; let a = e(i).then(c => SA(i, c)); return n.set(i, a), a; } let r = Array.from(t).map(a => Oe(null, [a], function* ([i, s]) { if (s.styleUrl && s.styleUrls?.length)
    throw new Error("@Component cannot define both `styleUrl` and `styleUrls`. Use `styleUrl` if the component has one stylesheet, or `styleUrls` if it has multiple"); let c = []; s.templateUrl && c.push(o(s.templateUrl).then(f => { s.template = f; })); let l = typeof s.styles == "string" ? [s.styles] : s.styles ?? []; s.styles = l; let { styleUrl: u, styleUrls: d } = s; if (u && (d = [u], s.styleUrl = void 0), d?.length) {
    let f = Promise.all(d.map(p => o(p))).then(p => { l.push(...p), s.styleUrls = void 0; });
    c.push(f);
} yield Promise.all(c), Er.delete(i); })); yield Promise.all(r); }); }
function TA(e, t) { bE(t) && (vn.set(e, t), Er.add(e)); }
function MA(e) { return Er.has(e); }
function bE(e) { return !!(e.templateUrl && !Object.hasOwn(e, "template") || e.styleUrls?.length || e.styleUrl); }
function NA() { let e = vn; return vn = new Map, e; }
function wA(e) { Er.clear(); for (let t of e.keys())
    Er.add(t); vn = e; }
function AE() { return vn.size === 0; }
function SA(e, t) { return Oe(this, null, function* () { if (typeof t == "string")
    return t; if (t.status !== void 0 && t.status !== 200)
    throw new M(918, !1); return t.text(); }); }
var lu = new Map, RE = !0;
function _A(e, t, n) { if (t && t !== n && RE)
    throw new M(921, !1); }
function Yd(e, t) { let n = lu.get(t) || null; _A(t, n, e), lu.set(t, e); }
function Zd(e) { return lu.get(e); }
function bA(e) { RE = !e; }
function OE(e) { return t => { t.controlDef = { create: (n, o) => { n?.\u0275ngControlCreate(o); }, update: (n, o) => { n?.\u0275ngControlUpdate?.(o); }, passThroughInput: e }; }; }
function xE(e) { let t = n => { let o = Array.isArray(e); n.hostDirectives === null ? (n.resolveHostDirectives = AA, n.hostDirectives = o ? e.map(uu) : [e]) : o ? n.hostDirectives.unshift(...e.map(uu)) : n.hostDirectives.unshift(e); }; return t.ngInherit = !0, t; }
function AA(e) { let t = [], n = !1, o = null, r = null; for (let i = 0; i < e.length; i++) {
    let s = e[i];
    if (s.hostDirectives !== null) {
        let a = t.length;
        o ??= new Map, r ??= new Map, kE(s, t, o, e), r.set(s, [a, t.length - 1]);
    }
    i === 0 && Le(s) && (n = !0, t.push(s));
} for (let i = n ? 1 : 0; i < e.length; i++)
    t.push(e[i]); return o !== null && o.forEach((i, s) => { RA(s.declaredInputs, i.inputs); }), [t, o, r]; }
function kE(e, t, n, o) { if (e.hostDirectives !== null)
    for (let r of e.hostDirectives)
        if (typeof r == "function") {
            let i = r();
            for (let s of i)
                lg(uu(s), t, n, o);
        }
        else
            lg(r, t, n, o); }
function lg(e, t, n, o) { let r = xe(e.directive); if (kE(r, t, n, o), n.has(r)) {
    let i = n.get(r);
    ug(i, e.inputs, "input"), ug(i, e.outputs, "output");
}
else
    o.includes(r) || (n.set(r, e), t.push(r)); }
function ug(e, t, n) { let o = n === "input" ? e.inputs : e.outputs; Object.keys(t).forEach(r => { let i = t[r]; (!Object.hasOwn(o, r) || o[r] === i) && (o[r] = i); }); }
function uu(e) { return typeof e == "function" ? { directive: W(e), inputs: {}, outputs: {} } : { directive: W(e.directive), inputs: dg(e.inputs), outputs: dg(e.outputs) }; }
function dg(e) { let t = {}; if (e !== void 0 && e.length > 0)
    for (let n = 0; n < e.length; n += 2)
        t[e[n]] = e[n + 1]; return t; }
function RA(e, t) { for (let n in t)
    if (Object.hasOwn(t, n)) {
        let o = t[n], r = e[n];
        e[o] = r;
    } }
function OA(e) { return Object.getPrototypeOf(e.prototype).constructor; }
function Kd(e) { let t = OA(e.type), n = !0, o = [e]; for (; t && t !== Function.prototype && t !== Object.prototype;) {
    let r, i = Object.hasOwn(t, wt) ? t[wt] : void 0, s = Object.hasOwn(t, _n) ? t[_n] : void 0;
    if (Le(e))
        r = i ?? s;
    else {
        if (i)
            throw new M(903, !1);
        r = s;
    }
    if (r) {
        if (n) {
            o.push(r);
            let c = e;
            c.inputs = cl(e.inputs), c.declaredInputs = cl(e.declaredInputs), c.outputs = cl(e.outputs);
            let l = r.hostBindings;
            l && FA(e, l);
            let u = r.viewQuery, d = r.contentQueries;
            if (u && LA(e, u), d && PA(e, d), xA(e, r), bp(e.outputs, r.outputs), Le(r) && r.data.animation) {
                let f = e.data;
                f.animation = (f.animation || []).concat(r.data.animation);
            }
        }
        let a = r.features;
        if (a)
            for (let c = 0; c < a.length; c++) {
                let l = a[c];
                l && l.ngInherit && l(e), l === Kd && (n = !1);
            }
    }
    t = Object.getPrototypeOf(t);
} kA(o); }
function xA(e, t) { for (let n in t.inputs) {
    if (!Object.hasOwn(t.inputs, n) || Object.hasOwn(e.inputs, n))
        continue;
    let o = t.inputs[n];
    o !== void 0 && (e.inputs[n] = o, e.declaredInputs[n] = t.declaredInputs[n]);
} }
function kA(e) { let t = 0, n = null; for (let o = e.length - 1; o >= 0; o--) {
    let r = e[o];
    r.hostVars = t += r.hostVars, r.hostAttrs = Zn(r.hostAttrs, n = Zn(n, r.hostAttrs));
} }
function cl(e) { return e === lt ? {} : e === H ? [] : e; }
function LA(e, t) { let n = e.viewQuery; n ? e.viewQuery = (o, r) => { t(o, r), n(o, r); } : e.viewQuery = t; }
function PA(e, t) { let n = e.contentQueries; n ? e.contentQueries = (o, r, i) => { t(o, r, i), n(o, r, i); } : e.contentQueries = t; }
function FA(e, t) { let n = e.hostBindings; n ? e.hostBindings = (o, r) => { t(o, r), n(o, r); } : e.hostBindings = t; }
function LE(e, t, n, o, r, i, s, a) { if (n.firstCreatePass) {
    e.mergedAttrs = Zn(e.mergedAttrs, e.attrs);
    let u = e.tView = oa(2, e, r, i, s, n.directiveRegistry, n.pipeRegistry, null, n.schemas, n.consts, null);
    n.queries !== null && (n.queries.template(n, e), u.queries = n.queries.embeddedTView(e));
} a && (e.flags |= a), Ue(e, !1); let c = PE(n, t, e, o); $o() && ta(n, t, c, e), _e(c, t); let l = wd(c, t, c, e); t[o + E] = l, ra(t, l), sE(l, e, t); }
function jA(e, t, n, o, r, i, s, a, c, l, u) { let d = n + E, f; return t.firstCreatePass ? (f = Vt(t, d, 4, s || null, a || null), Ti() && Xy(t, e, f, ie(t.consts, l), Md), Zg(t, f)) : f = t.data[d], LE(f, e, t, n, o, r, i, c), xn(f) && sa(t, e, f), l != null && ho(e, f, u), f; }
function yn(e, t, n, o, r, i, s, a, c, l, u) { let d = n + E, f; if (t.firstCreatePass) {
    if (f = Vt(t, d, 4, s || null, a || null), l != null) {
        let p = ie(t.consts, l);
        f.localNames = [];
        for (let h = 0; h < p.length; h += 2)
            f.localNames.push(p[h], -1);
    }
}
else
    f = t.data[d]; return LE(f, e, t, n, o, r, i, c), l != null && ho(e, f, u), f; }
function Jd(e, t, n, o, r, i, s, a) { let c = g(), l = w(), u = ie(l.consts, i); return jA(c, l, e, t, n, o, r, u, void 0, s, a), Jd; }
function Xd(e, t, n, o, r, i, s, a) { let c = g(), l = w(), u = ie(l.consts, i); return yn(c, l, e, t, n, o, r, u, void 0, s, a), Xd; }
var PE = FE;
function FE(e, t, n, o) { return Ge(!0), t[C].createComment(""); }
function HA(e, t, n, o) { let r = !Gs(t, n); Ge(r); let i = t[ce]?.data[Ls]?.[o] ?? null; if (i !== null && n.tView !== null && n.tView.ssrId === null && (n.tView.ssrId = i), r)
    return FE(e, t); let s = t[ce], a = zr(s, e, t, n); $s(s, o, a); let c = Ku(s, o); return ma(c, a); }
function jE() { PE = HA; }
var re = (function (e) { return e[e.NOT_STARTED = 0] = "NOT_STARTED", e[e.IN_PROGRESS = 1] = "IN_PROGRESS", e[e.COMPLETE = 2] = "COMPLETE", e[e.FAILED = 3] = "FAILED", e; })(re || {}), fg = 0, VA = 1, $ = (function (e) { return e[e.Placeholder = 0] = "Placeholder", e[e.Loading = 1] = "Loading", e[e.Complete = 2] = "Complete", e[e.Error = 3] = "Error", e; })($ || {}), Ir = (function (e) { return e[e.Initial = -1] = "Initial", e; })(Ir || {}), qn = 0, Tt = 1, Qo = 2, $i = 3, BA = 4, $A = 5, Ta = 6, UA = 7, Qn = 8, GA = 9, ef = (function (e) { return e[e.Manual = 0] = "Manual", e[e.Playthrough = 1] = "Playthrough", e; })(ef || {});
function qr(e, t, n) { let o = VE(e); t[o] === null && (t[o] = []), t[o].push(n); }
function Ki(e, t) { let n = VE(e), o = t[n]; if (o !== null) {
    for (let r of o)
        r();
    t[n] = null;
} }
function HE(e) { Ki(1, e), Ki(0, e), Ki(2, e); }
function VE(e) { let t = BA; return e === 1 ? t = $A : e === 2 && (t = GA), t; }
function Qr(e) { return e + 1; }
function Ie(e, t) { let n = e[m], o = Qr(t.index); return e[o]; }
function WA(e, t, n) { let o = e[m], r = Qr(t); e[r] = n; }
function le(e, t) { let n = Qr(t.index); return e.data[n]; }
function zA(e, t, n) { let o = Qr(t); e.data[o] = n; }
function qA(e, t, n) { let o = t[m], r = le(o, n); switch (e) {
    case $.Complete: return r.primaryTmplIndex;
    case $.Loading: return r.loadingTmplIndex;
    case $.Error: return r.errorTmplIndex;
    case $.Placeholder: return r.placeholderTmplIndex;
    default: return null;
} }
function du(e, t) { return t === $.Placeholder ? e.placeholderBlockConfig?.[fg] ?? null : t === $.Loading ? e.loadingBlockConfig?.[fg] ?? null : null; }
function BE(e) { return e.loadingBlockConfig?.[VA] ?? null; }
function pg(e, t) { if (!e || e.length === 0)
    return t; let n = new Set(e); for (let o of t)
    n.add(o); return e.length === n.size ? e : Array.from(n); }
function QA(e, t) { let n = t.primaryTmplIndex + E; return Jt(e, n); }
function $E(e) { return e !== null && typeof e == "object" && typeof e.primaryTmplIndex == "number"; }
function UE(e, t) { let n = null, o = Qr(t.index); return E < o && o < e.bindingStartIndex && (n = le(e, t)), !!n && $E(n); }
var YA = (() => { class e {
    cachedInjectors = new Map;
    getOrCreateInjector(n, o, r, i) { if (!this.cachedInjectors.has(n)) {
        let s = r.length > 0 ? Gd(r, o, i) : null;
        this.cachedInjectors.set(n, s);
    } return this.cachedInjectors.get(n); }
    ngOnDestroy() { try {
        for (let n of this.cachedInjectors.values())
            n !== null && n.destroy();
    }
    finally {
        this.cachedInjectors.clear();
    } }
    static \u0275prov = ae({ token: e, providedIn: "environment", factory: () => new e });
} return e; })();
function Ma(e) { return (t, n) => GE(e, t, n); }
function GE(e, t, n) { let o = n.get(WE), r = n.get(B), i = () => o.remove(t); return o.add(e, t, r), i; }
var WE = (() => { class e {
    executingCallbacks = !1;
    timeoutId = null;
    invokeTimerAt = null;
    current = [];
    deferred = [];
    add(n, o, r) { let i = this.executingCallbacks ? this.deferred : this.current; this.addToQueue(i, Date.now() + n, o), this.scheduleTimer(r); }
    remove(n) { let { current: o, deferred: r } = this; this.removeFromQueue(o, n) === -1 && this.removeFromQueue(r, n), o.length === 0 && r.length === 0 && this.clearTimeout(); }
    addToQueue(n, o, r) { let i = n.length; for (let s = 0; s < n.length; s += 2)
        if (n[s] > o) {
            i = s;
            break;
        } Lp(n, i, o, r); }
    removeFromQueue(n, o) { let r = -1; for (let i = 0; i < n.length; i += 2)
        if (n[i + 1] === o) {
            r = i;
            break;
        } return r > -1 && uc(n, r, 2), r; }
    scheduleTimer(n) { let o = () => { this.clearTimeout(), this.executingCallbacks = !0; let i = [...this.current], s = Date.now(); for (let c = 0; c < i.length; c += 2) {
        let l = i[c], u = i[c + 1];
        if (l <= s)
            u();
        else
            break;
    } let a = -1; for (let c = 0; c < this.current.length && this.current[c] <= s; c += 2)
        a = c + 1; if (a >= 0 && uc(this.current, 0, a + 1), this.executingCallbacks = !1, this.deferred.length > 0) {
        for (let c = 0; c < this.deferred.length; c += 2) {
            let l = this.deferred[c], u = this.deferred[c + 1];
            this.addToQueue(this.current, l, u);
        }
        this.deferred.length = 0;
    } this.scheduleTimer(n); }; if (this.current.length > 0) {
        let i = Date.now(), s = this.current[0];
        if (this.timeoutId === null || this.invokeTimerAt && this.invokeTimerAt - s > 16) {
            this.clearTimeout();
            let a = Math.max(s - i, 16);
            this.invokeTimerAt = s, this.timeoutId = n.runOutsideAngular(() => setTimeout(() => n.run(o), a));
        }
    } }
    clearTimeout() { this.timeoutId !== null && (clearTimeout(this.timeoutId), this.timeoutId = null); }
    ngOnDestroy() { this.clearTimeout(), this.current.length = 0, this.deferred.length = 0; }
    static \u0275prov = ae({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), ZA = new b("DEFER_BLOCK_DEPENDENCY_INTERCEPTOR"), zE = new b("");
function ll(e, t, n) { return e.get(YA).getOrCreateInjector(t, e, n, ""); }
function KA(e, t, n) { if (e instanceof Lt) {
    let r = e.injector, i = e.parentInjector, s = ll(i, t, n);
    return new Lt(r, s);
} let o = e.get(ut); if (o !== e) {
    let r = ll(o, t, n);
    return new Lt(e, r);
} return ll(e, t, n); }
function pt(e, t, n, o = !1) { let r = n[q], i = r[m]; if (et(r))
    return; let s = Ie(r, t), a = s[Tt], c = s[UA]; if (!(c !== null && e < c) && gg(a, e) && gg(s[qn] ?? -1, e)) {
    let l = le(i, t), d = !o && (typeof ngServerMode > "u" || !ngServerMode) && (BE(l) !== null || du(l, $.Loading) !== null || du(l, $.Placeholder)) ? fu : qE;
    try {
        d(e, s, n, t, r);
    }
    catch (f) {
        Nd(r, f);
    }
} }
function JA(e, t) { let n = e[Se]?.findIndex(r => r.data[kr] === t[Tt]) ?? -1; return { dehydratedView: n > -1 ? e[Se][n] : null, dehydratedViewIx: n }; }
function qE(e, t, n, o, r) { P(L.DeferBlockStateStart); let i = qA(e, r, o); if (i !== null) {
    t[Tt] = e;
    let s = r[m], a = i + E, c = Jt(s, a), l = 0;
    Wr(n, l);
    let u;
    if (e === $.Complete) {
        let h = le(s, o), v = h.providers;
        v && v.length > 0 && (u = KA(r[O], h, v));
    }
    let { dehydratedView: d, dehydratedViewIx: f } = JA(n, t), p = Ht(r, c, null, { injector: u, dehydratedView: d });
    if (Ct(n, p, l, pn(c, d)), Fo(p), f > -1 && n[Se]?.splice(f, 1), (e === $.Complete || e === $.Error) && Array.isArray(t[Qn])) {
        for (let h of t[Qn])
            h();
        t[Qn] = null;
    }
} P(L.DeferBlockStateEnd); }
function XA(e, t, n, o, r) { let i = Date.now(), s = r[m], a = le(s, o); if (t[Qo] === null || t[Qo] <= i) {
    t[Qo] = null;
    let c = BE(a), l = t[$i] !== null;
    if (e === $.Loading && c !== null && !l) {
        t[qn] = e;
        let u = hg(c, t, o, n, r);
        t[$i] = u;
    }
    else {
        e > $.Loading && l && (t[$i](), t[$i] = null, t[qn] = null), qE(e, t, n, o, r);
        let u = du(a, e);
        u !== null && (t[Qo] = i + u, hg(u, t, o, n, r));
    }
}
else
    t[qn] = e; }
function hg(e, t, n, o, r) { return GE(e, () => { let s = t[qn]; t[Qo] = null, t[qn] = null, s !== null && pt(s, n, o); }, r[O]); }
function gg(e, t) { return e < t; }
function yo(e, t) { let n = e[t.index]; pt($.Placeholder, t, n); }
function mg(e, t, n) { e.loadingPromise.then(() => { e.loadingState === re.COMPLETE ? pt($.Complete, t, n) : e.loadingState === re.FAILED && pt($.Error, t, n); }); }
var fu = null;
function QE(e, t, n, o) { let r = e.consts; n != null && (t.placeholderBlockConfig = ie(r, n)), o != null && (t.loadingBlockConfig = ie(r, o)), fu === null && (fu = XA); }
function tf(e, t) { return !(e === 0 && typeof ngServerMode < "u" && ngServerMode || t[O].get(zE, null, { optional: !0 })?.behavior === ef.Manual); }
function nf(e, t, n, o) { let r = n.get(B); return ow(e, () => r.run(t), i => r.runOutsideAngular(() => nw(i)), o); }
function eR(e, t, n) { return n == null ? e : n >= 0 ? Kp(n, e) : e[t.index][k] ?? null; }
function tR(e, t) { return Kt(E + t, e); }
function Eo(e, t, n, o, r, i, s, a) { if (!tf(s, e))
    return; let c = e[O], l = c.get(B), u; function d() { if (et(e)) {
    u.destroy();
    return;
} let f = Ie(e, t), p = f[Tt]; if (p !== Ir.Initial && p !== $.Placeholder) {
    u.destroy();
    return;
} let h = eR(e, t, o); if (!h || (u.destroy(), et(h)))
    return; let v = tR(h, n), y = r(v, () => { l.run(() => { e !== h && Ec(h, y), i(); }); }, c, a); e !== h && Ho(h, y), qr(s, f, y); } u = kv({ read: d }, { injector: c }); }
var nR = (() => { class e {
    log(n) { console.log(n); }
    warn(n) { console.warn(n); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = ae({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })(), pu = class {
    resolverToTokenToDependencies = new WeakMap;
    resolverToProviders = new WeakMap;
    resolverToEffects = new WeakMap;
    standaloneInjectorToComponent = new WeakMap;
    reset() { this.resolverToTokenToDependencies = new WeakMap, this.resolverToProviders = new WeakMap, this.standaloneInjectorToComponent = new WeakMap; }
}, oR = new pu;
function Na() { return oR; }
var YE = (function (e) { return e[e.Defer = 0] = "Defer", e[e.For = 1] = "For", e; })(YE || {});
function rR(e) { let { standaloneInjectorToComponent: t } = Na(); if (t.has(e))
    return t.get(e); let n = e.get(mn, null, { self: !0, optional: !0 }); return n === null || n.instance === null ? null : n.instance.constructor; }
function iR(e) { let t = Sr(e), { resolverToProviders: n } = Na(), o = n.get(t) ?? [], r = Array.from(uh()).map(i => ({ token: i, isViewProvider: !1, provider: i })); return [...o, ...r]; }
function sR(e) { let t = new Map, o = aR(t, new Set); return jp(e, o, [], new Set), t; }
function aR(e, t) { return (n, o) => { if (e.has(n) || e.set(n, [o]), !t.has(o))
    for (let r of e.keys()) {
        let i = e.get(r), s = rc(o);
        if (!s) {
            let l = o.ngModule;
            s = rc(l);
        }
        if (!s)
            return;
        let a = i[0], c = !1;
        kp(s.imports, l => { c || (c = l.ngModule === a || l === a, c && e.get(r)?.unshift(o)); });
    } t.add(o); }; }
function cR(e) { let t = Na().resolverToProviders.get(e) ?? []; if (lR(e))
    return t; let n = rR(e); if (n === null)
    return t; let o = sR(n), r = []; for (let i of t) {
    let s = i.provider, a = s.provide;
    if (a === St || a === Pp)
        continue;
    let c = o.get(s) ?? [];
    z(n)?.standalone && (c = [n, ...c]), r.push(Re(G({}, i), { importPath: c }));
} return r; }
function lR(e) { return e instanceof qt && e.scopes.has("platform"); }
function ZE(e) { if (e instanceof ye)
    return iR(e); if (e instanceof ut)
    return cR(e); oc("getInjectorProviders only supports NodeInjector and EnvironmentInjector"); }
function KE(e) { if (e instanceof ye) {
    let t = Ou(e), n = Sr(e);
    return Gp(n, t), { type: "element", source: Z(n, t) };
} return e instanceof qt ? { type: "environment", source: e.source ?? null } : e instanceof Ao ? { type: "null", source: null } : null; }
function uR(e) { return e.kind === "computed"; }
function dR(e) { return e.kind === "template"; }
function fR(e) { return e.kind === "signal"; }
function pR(e) { let t = Sr(e); Wp(t); let n = Ou(e); zp(n); let o = n[t.index]; return te(o) ? o[we] ?? null : null; }
var vg = new WeakMap, yg = 0;
function hR(e) { let t = Array.from(e.keys()), n = [], o = []; for (let [r, i] of e.entries()) {
    let s = t.indexOf(r), a = vg.get(r);
    a || (yg++, a = yg.toString(), vg.set(r, a)), uR(r) ? n.push({ label: r.debugName, value: r.value, kind: r.kind, epoch: r.version, debuggableFn: r.computation, id: a }) : fR(r) ? n.push({ label: r.debugName, value: r.value, kind: r.kind, epoch: r.version, id: a }) : dR(r) ? n.push({ label: r.debugName ?? r.lView?.[V]?.tagName?.toLowerCase?.(), kind: r.kind, epoch: r.version, debuggableFn: r.lView?.[F]?.constructor, id: a }) : n.push({ label: r.debugName, kind: r.kind, epoch: r.version, id: a });
    for (let c of i)
        o.push({ consumer: s, producer: t.indexOf(c) });
} return { nodes: n, edges: o }; }
function gR(e) { let t = e; return e instanceof ye && (t = Ou(e)), (Na().resolverToEffects.get(t) ?? []).map(r => r instanceof yh ? r[Qe] : r.signal[Qe]); }
function JE(e, t = new Map) { for (let n of e) {
    if (t.has(n))
        continue;
    let o = [];
    for (let r = n.producers; r !== void 0; r = r.nextProducer) {
        let i = r.producer;
        o.push(i);
    }
    t.set(n, o), JE(o, t);
} return t; }
function XE(e) { let t = null; if (!(e instanceof ye) && !(e instanceof qt))
    return oc("getSignalGraph must be called with a NodeInjector or R3Injector"); e instanceof ye && (t = pR(e)); let n = gR(e), o = t ? [t, ...n] : n, r = JE(o); return hR(r); }
var mR = new WeakMap;
function vR(e) { return mR.get(e); }
function yR() { return K("Chrome DevTools profiling"), () => { }; }
function ER(e) { let t = e.get(Pn), n = e.get(dt), o = vh(t, n), r = {}; for (let [i, s] of Object.entries(o))
    cw(i) || (r[i] = s); return r; }
var Eg = "ng";
function IR(e, t) { DR(e, t); }
function DR(e, t) { if (typeof COMPILED > "u" || !COMPILED) {
    let n = Me;
    n[Eg] ??= {}, n[Eg][e] = t;
} }
var eI = new b(""), tI = new b(""), nI = new b("USE_PENDING_TASKS", { providedIn: "root", factory: () => typeof Zone > "u" }), CR = (() => { class e {
    _ngZone;
    registry;
    _isZoneStable = !0;
    _callbacks = [];
    _taskTrackingZone = null;
    _destroyRef;
    pendingTasksInternal = D(Rt);
    _usePendingTasks = D(nI);
    constructor(n, o, r) { this._ngZone = n, this.registry = o, $p() && (this._destroyRef = D(Xt, { optional: !0 }) ?? void 0), of || (rI(r), r.addToWindow(o)), this._watchAngularEvents(), n.run(() => { this._taskTrackingZone = typeof Zone > "u" ? null : Zone.current.get("TaskTrackingZone"); }); }
    _watchAngularEvents() { let n = this._ngZone.onUnstable.subscribe({ next: () => { this._isZoneStable = !1; } }), o, r; this._ngZone.runOutsideAngular(() => { this._usePendingTasks && (o = this.pendingTasksInternal.hasPendingTasksObservable.subscribe(() => { this.isStable() && this._ngZone.runOutsideAngular(() => { this._runCallbacksIfReady(); }); })), r = this._ngZone.onStable.subscribe({ next: () => { B.assertNotInAngularZone(), queueMicrotask(() => { this._isZoneStable = !0, this._runCallbacksIfReady(); }); } }); }), this._destroyRef?.onDestroy(() => { n.unsubscribe(), o?.unsubscribe(), r.unsubscribe(); }); }
    isStable() { return this._isZoneStable && !this._ngZone.hasPendingMacrotasks && (!this._usePendingTasks || !this.pendingTasksInternal.hasPendingTasks); }
    _runCallbacksIfReady() { if (this.isStable())
        queueMicrotask(() => { for (; this._callbacks.length !== 0;) {
            let n = this._callbacks.pop();
            clearTimeout(n.timeoutId), n.doneCb();
        } });
    else {
        let n = this.getPendingTasks();
        this._callbacks = this._callbacks.filter(o => o.updateCb && o.updateCb(n) ? (clearTimeout(o.timeoutId), !1) : !0);
    } }
    getPendingTasks() { return this._taskTrackingZone ? this._taskTrackingZone.macroTasks.map(n => ({ source: n.source, creationLocation: n.creationLocation, data: n.data })) : []; }
    addCallback(n, o, r) { let i = -1; o && o > 0 && (i = setTimeout(() => { this._callbacks = this._callbacks.filter(s => s.timeoutId !== i), n(); }, o)), this._callbacks.push({ doneCb: n, timeoutId: i, updateCb: r }); }
    whenStable(n, o, r) { if (r && !this._taskTrackingZone)
        throw new Error('Task tracking zone is required when passing an update callback to whenStable(). Is "zone.js/plugins/task-tracking" loaded?'); this.addCallback(n, o, r), this._runCallbacksIfReady(); }
    registerApplication(n) { this.registry.registerApplication(n, this); }
    unregisterApplication(n) { this.registry.unregisterApplication(n); }
    findProviders(n, o, r) { return []; }
    static \u0275fac = function (o) { return new (o || e)(He(B), He(oI), He(tI)); };
    static \u0275prov = ae({ token: e, factory: e.\u0275fac });
} return e; })(), oI = (() => { class e {
    _applications = new Map;
    registerApplication(n, o) { this._applications.set(n, o); }
    unregisterApplication(n) { this._applications.delete(n); }
    unregisterAllApplications() { this._applications.clear(); }
    getTestability(n) { return this._applications.get(n) || null; }
    getAllTestabilities() { return Array.from(this._applications.values()); }
    getAllRootElements() { return Array.from(this._applications.keys()); }
    findTestabilityInTree(n, o = !0) { return of?.findTestabilityInTree(this, n, o) ?? null; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = ae({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })();
function rI(e) { of = e; }
var of, Yr = new b("");
function rf() { wp(() => { let e = ""; throw new M(600, e); }); }
var TR = 10;
function sf(e, t) { return Array.isArray(t) ? t.reduce(sf, e) : G(G({}, e), t); }
var be = (() => { class e {
    _runningTick = !1;
    _destroyed = !1;
    _destroyListeners = [];
    _views = [];
    internalErrorHandler = D(en);
    afterRenderManager = D(Ks);
    zonelessEnabled = D(Fn);
    rootEffectScheduler = D(Wc);
    dirtyFlags = 0;
    tracingSnapshot = null;
    allTestViews = new Set;
    autoDetectTestViews = new Set;
    includeAllTestViews = !1;
    afterTick = new Wg;
    get allViews() { return [...(this.includeAllTestViews ? this.allTestViews : this.autoDetectTestViews).keys(), ...this._views]; }
    get destroyed() { return this._destroyed; }
    componentTypes = [];
    components = [];
    internalPendingTask = D(Rt);
    get isStable() { return this.internalPendingTask.hasPendingTasksObservable.pipe(GM(n => !n)); }
    constructor() { D(Mn, { optional: !0 }); }
    whenStable() { let n; return new Promise(o => { n = this.isStable.subscribe({ next: r => { r && o(); } }); }).finally(() => { n.unsubscribe(); }); }
    _injector = D(ut);
    _rendererFactory = null;
    get injector() { return this._injector; }
    bootstrap(n, o) { return this.bootstrapImpl(n, o); }
    bootstrapImpl(n, o, r = me.NULL) { return this._injector.get(B).run(() => { if (P(L.BootstrapComponentStart), !this._injector.get(Qd).done) {
        let I = "";
        throw new M(405, I);
    } let a = z(n), c = this._injector.get(mn), l = new gn(a, c); this.componentTypes.push(n); let { hostElement: u, directives: d, bindings: f } = MR(o), p = u || l.selector, h = l.create(r, [], p, c.injector, d, f), v = h.location.nativeElement, y = h.injector.get(eI, null); return y?.registerApplication(v), h.onDestroy(() => { this.detachView(h.hostView), Jo(this.components, h), y?.unregisterApplication(v); }), this._loadComponent(h), P(L.BootstrapComponentEnd, h), h; }); }
    tick() { this.zonelessEnabled || (this.dirtyFlags |= 1), this._tick(); }
    _tick() { P(L.ChangeDetectionStart), this.tracingSnapshot !== null ? this.tracingSnapshot.run(Zs.CHANGE_DETECTION, this.tickImpl) : this.tickImpl(); }
    tickImpl = () => { if (this._runningTick)
        throw P(L.ChangeDetectionEnd), new M(101, !1); let n = R(null); try {
        this._runningTick = !0, this.synchronize();
    }
    finally {
        this._runningTick = !1, this.tracingSnapshot?.dispose(), this.tracingSnapshot = null, R(n), this.afterTick.next(), P(L.ChangeDetectionEnd);
    } };
    synchronize() { this._rendererFactory === null && !this._injector.destroyed && (this._rendererFactory = this._injector.get(mr, null, { optional: !0 })); let n = 0; for (; this.dirtyFlags !== 0 && n++ < TR;) {
        P(L.ChangeDetectionSyncStart);
        try {
            this.synchronizeOnce();
        }
        finally {
            P(L.ChangeDetectionSyncEnd);
        }
    } }
    synchronizeOnce() { this.dirtyFlags & 16 && (this.dirtyFlags &= -17, this.rootEffectScheduler.flush()); let n = !1; if (this.dirtyFlags & 7) {
        let o = !!(this.dirtyFlags & 1);
        this.dirtyFlags &= -8, this.dirtyFlags |= 8;
        for (let { _lView: r } of this.allViews) {
            if (!o && !jo(r))
                continue;
            let i = o && !this.zonelessEnabled ? 0 : 1;
            iy(r, i), n = !0;
        }
        if (this.dirtyFlags &= -5, this.syncDirtyFlagsWithViews(), this.dirtyFlags & 23)
            return;
    } n || (this._rendererFactory?.begin?.(), this._rendererFactory?.end?.()), this.dirtyFlags & 8 && (this.dirtyFlags &= -9, this.afterRenderManager.execute()), this.syncDirtyFlagsWithViews(); }
    syncDirtyFlagsWithViews() { if (this.allViews.some(({ _lView: n }) => jo(n))) {
        this.dirtyFlags |= 2;
        return;
    }
    else
        this.dirtyFlags &= -8; }
    attachView(n) { let o = n; this._views.push(o), o.attachToAppRef(this); }
    detachView(n) { let o = n; Jo(this._views, o), o.detachFromAppRef(); }
    _loadComponent(n) { this.attachView(n.hostView); try {
        this.tick();
    }
    catch (r) {
        this.internalErrorHandler(r);
    } this.components.push(n), this._injector.get(Yr, []).forEach(r => r(n)); }
    ngOnDestroy() { if (!this._destroyed)
        try {
            this._destroyListeners.forEach(n => n()), this._views.slice().forEach(n => n.destroy());
        }
        finally {
            this._destroyed = !0, this._views = [], this._destroyListeners = [];
        } }
    onDestroy(n) { return this._destroyListeners.push(n), () => Jo(this._destroyListeners, n); }
    destroy() { if (this._destroyed)
        throw new M(406, !1); let n = this._injector; n.destroy && !n.destroyed && n.destroy(); }
    get viewCount() { return this._views.length; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = Et({ token: e, factory: e.\u0275fac });
} return e; })();
function MR(e) { return e === void 0 || typeof e == "string" || e instanceof Element ? { hostElement: e } : e; }
function Jo(e, t) { let n = e.indexOf(t); n > -1 && e.splice(n, 1); }
function iI(e, t, n) { let o = t.get(NR), r = () => o.remove(e); return o.add(e, n), r; }
function af(e) { return (t, n) => iI(t, n, e); }
var NR = (() => { class e {
    buckets = new Map;
    callbackBucket = new Map;
    applicationRef = D(be);
    ngZone = D(B);
    idleService = D(Os);
    add(n, o) { let r = Ig(o); this.callbackBucket.set(n, r); let i = this.buckets.get(r); i == null && (i = { idleId: null, queue: new Set }, this.buckets.set(r, i)), i.queue.add(n), this.scheduleBucket(i, o); }
    remove(n) { let o = this.callbackBucket.get(n); if (o === void 0)
        return; this.callbackBucket.delete(n); let r = this.buckets.get(o); r && (r.queue.delete(n), r.queue.size === 0 && (this.cancelBucket(r), this.buckets.delete(o))); }
    scheduleBucket(n, o) { if (n.idleId !== null)
        return; let r = Ig(o), i = s => { for (let a of n.queue)
        if (a(), this.applicationRef._tick(), n.queue.delete(a), this.callbackBucket.delete(a), s && s.timeRemaining() === 0 && !s.didTimeout)
            break; n.idleId = null, n.queue.size > 0 ? this.scheduleBucket(n, o) : this.buckets.delete(r); }; n.idleId = this.idleService.requestOnIdle(s => this.ngZone.run(() => i(s)), o); }
    cancelBucket(n) { n.idleId !== null && (this.idleService.cancelOnIdle(n.idleId), n.idleId = null); }
    ngOnDestroy() { for (let n of this.buckets.values())
        this.cancelBucket(n); this.buckets.clear(), this.callbackBucket.clear(); }
    static \u0275prov = ae({ token: e, providedIn: "root", factory: () => new e });
} return e; })();
function Ig(e) { return !e || e.timeout == null ? "" : `${e.timeout}`; }
function sI(e) { let t = g(), n = N(); if (yo(t, n), !tf(0, t))
    return; let o = t[O], r = Ie(t, n), i = e(() => De(0, t, n), o); qr(0, r, i); }
function aI(e) { if (typeof ngServerMode < "u" && ngServerMode)
    return; let t = g(), n = t[O], o = N(), r = t[m], i = le(r, o); if (i.loadingState === re.NOT_STARTED) {
    let s = Ie(t, o), c = e(() => Zr(i, t, o), n);
    qr(1, s, c);
} }
function cI(e, t, n) { if (typeof ngServerMode < "u" && ngServerMode)
    return; let o = t[O], r = Ie(t, n), i = r[Ta], s = e(() => Mt(o, i), o); qr(2, r, s); }
function Zr(e, t, n) { wa(e, t, n); }
function wa(e, t, n) { let o = t[O], r = t[m]; if (e.loadingState !== re.NOT_STARTED)
    return e.loadingPromise ?? Promise.resolve(); let i = Ie(t, n), s = QA(r, e); e.loadingState = re.IN_PROGRESS, Ki(1, i); let a = e.dependencyResolverFn, c = o.get(qc).add(); return a ? (e.loadingPromise = Promise.allSettled(a()).then(l => { let u = !1, d = null, f = [], p = []; for (let h = 0; h < l.length; h++) {
    let v = l[h];
    if (v.status === "fulfilled") {
        let y = v.value, I = z(y) || xe(y);
        if (I)
            f.push(I);
        else {
            let A = Ze(y);
            A && p.push(A);
        }
    }
    else {
        u = !0, d = v.reason instanceof Error ? v.reason : new Error(String(v.reason));
        break;
    }
} if (u) {
    if (e.loadingState = re.FAILED, e.errorTmplIndex === null) {
        let v = "", y = new M(-750, v);
        Nd(t, y);
    }
}
else {
    e.loadingState = re.COMPLETE;
    let h = s.tView;
    if (f.length > 0) {
        h.directiveRegistry = pg(h.directiveRegistry, f);
        let v = f.map(I => I.type), y = fc(!1, ...v);
        e.providers = y;
    }
    p.length > 0 && (h.pipeRegistry = pg(h.pipeRegistry, p));
} }), e.loadingPromise.finally(() => { e.loadingPromise = null, c(); })) : (e.loadingPromise = Promise.resolve().then(() => { e.loadingPromise = null, e.loadingState = re.COMPLETE, c(); }), e.loadingPromise); }
function De(e, t, n) { let o = t[m], r = t[n.index]; if (!tf(e, t))
    return; let i = Ie(t, n), s = le(o, n); switch (HE(i), s.loadingState) {
    case re.NOT_STARTED:
        pt($.Loading, n, r), wa(s, t, n), s.loadingState === re.IN_PROGRESS && mg(s, n, r);
        break;
    case re.IN_PROGRESS:
        pt($.Loading, n, r), mg(s, n, r);
        break;
    case re.COMPLETE:
        pt($.Complete, n, r);
        break;
    case re.FAILED:
        pt($.Error, n, r);
        break;
    default:
} }
function Mt(e, t, n) { return Oe(this, null, function* () { let o = e.get(It); if (o.hydrating.has(t))
    return; let { parentBlockPromise: i, hydrationQueue: s } = vw(t, e); if (s.length === 0)
    return; i !== null && s.shift(), _R(o, s), i !== null && (yield i); let a = s[0]; o.has(a) ? yield Dg(e, s, n) : o.awaitParentBlock(a, () => Oe(null, null, function* () { return yield Dg(e, s, n); })); }); }
function Dg(e, t, n) { return Oe(this, null, function* () { let o = e.get(It), r = o.hydrating, i = e.get(Rt), s = i.add(); for (let c = 0; c < t.length; c++) {
    let l = t[c], u = o.get(l);
    if (u != null) {
        if (yield AR(u), yield bR(e), wR(u)) {
            yb(u), Cg(t.slice(c), o);
            break;
        }
        r.get(l).resolve();
    }
    else {
        SR(c, t, o), Cg(t.slice(c), o);
        break;
    }
} let a = t[t.length - 1]; yield r.get(a)?.promise, i.remove(s), n && n(t), Eb(o.get(a), t, o, e.get(be)); }); }
function wR(e) { return Ie(e.lView, e.tNode)[Tt] === $.Error; }
function SR(e, t, n) { let o = e - 1, r = o > -1 ? n.get(t[o]) : null; r && Ea(r.lContainer); }
function Cg(e, t) { let n = t.hydrating; for (let o of e)
    n.get(o)?.reject(); t.cleanup(e); }
function _R(e, t) { for (let n of t)
    e.hydrating.set(n, Ln()); }
function bR(e) { return new Promise(t => md(t, { injector: e })); }
function AR(e) { return Oe(this, null, function* () { let { tNode: t, lView: n } = e, o = Ie(n, t); return new Promise(r => { RR(o, r), De(2, n, t); }); }); }
function RR(e, t) { Array.isArray(e[Qn]) || (e[Qn] = []), e[Qn].push(t); }
function J(e, t, n) { return e === 0 ? Tg(t, n) : e === 2 ? !Tg(t, n) : !(typeof ngServerMode < "u" && ngServerMode); }
function OR(e) { return e != null && (e & 1) === 1; }
function Tg(e, t) { let n = e[O], o = le(e[m], t), r = Fr(n), i = OR(o.flags); if (typeof ngServerMode < "u" && ngServerMode)
    return !r || !i; let a = Ie(e, t)[Ta] !== null; return !(i && a && r); }
function Bt(e, t) { let n = le(e, t); return n.hydrateTriggers ??= new Map; }
function xR(e, t, n) { let o = [], r = [], i = [], s = []; for (let [a, c] of t) {
    let l = n.get(a);
    if (l !== void 0) {
        let u = c.data[gt], d = l;
        for (let f = 0; f < u; f++) {
            if (d = d.previousSibling, d.nodeType !== Node.ELEMENT_NODE)
                continue;
            let p = { el: d, blockName: a };
            c.hydrate.idle && o.push(p), c.hydrate.immediate && s.push(p), c.hydrate.timer !== null && (p.delay = c.hydrate.timer, r.push(p)), c.hydrate.viewport && (typeof c.hydrate.viewport != "boolean" && (p.intersectionObserverOptions = c.hydrate.viewport), i.push(p));
        }
    }
} kR(e, o), FR(e, s), LR(e, i), PR(e, r); }
function kR(e, t) { for (let n of t) {
    let o = e.get(It), i = iI(() => Mt(e, n.blockName), e);
    o.addCleanupFn(n.blockName, i);
} }
function LR(e, t) { if (t.length > 0) {
    let n = e.get(It);
    for (let o of t) {
        let r = nf(o.el, () => Mt(e, o.blockName), e, o.intersectionObserverOptions);
        n.addCleanupFn(o.blockName, r);
    }
} }
function PR(e, t) { for (let n of t) {
    let o = e.get(It), r = () => Mt(e, n.blockName), s = Ma(n.delay)(r, e);
    o.addCleanupFn(n.blockName, s);
} }
function FR(e, t) { for (let n of t)
    Mt(e, n.blockName); }
function lI(e, t, n, o, r, i, s, a, c, l) { let u = g(), d = w(), f = e + E, p = yn(u, d, e, null, 0, 0), h = u[O], v = Fr(h); if (d.firstCreatePass) {
    K("NgDefer");
    let ct = { primaryTmplIndex: t, loadingTmplIndex: o ?? null, placeholderTmplIndex: r ?? null, errorTmplIndex: i ?? null, placeholderBlockConfig: null, loadingBlockConfig: null, dependencyResolverFn: n ?? null, loadingState: re.NOT_STARTED, loadingPromise: null, providers: null, hydrateTriggers: null, debug: null, flags: l ?? 0 };
    c?.(d, ct, a, s), zA(d, f, ct);
} let y = u[f]; sE(y, p, u); let I = null, A = null; if (y[Se]?.length > 0) {
    let ct = y[Se][0].data;
    A = ct[js] ?? null, I = ct[kr];
} let oe = [null, Ir.Initial, null, null, null, null, A, I, null, null]; WA(u, f, oe); let je = null; A !== null && v && (je = h.get(It), je.add(A, { lView: u, tNode: p, lContainer: y })); let Ae = () => { HE(oe), A !== null && je?.cleanup([A]); }; qr(0, oe, () => Ec(u, Ae)), Ho(u, Ae); }
function uI(e) { let t = g(), n = Ce(); if (!J(0, t, n))
    return; let o = ge(); if (U(t, o, e)) {
    let r = R(null);
    try {
        let i = !!e, a = Ie(t, n)[Tt];
        i === !1 && a === Ir.Initial ? yo(t, n) : i === !0 && (a === Ir.Initial || a === $.Placeholder) && De(0, t, n);
    }
    finally {
        R(r);
    }
} }
function dI(e) { let t = g(), n = Ce(); if (!J(1, t, n))
    return; let o = ge(); if (U(t, o, e)) {
    let r = R(null);
    try {
        let i = !!e, s = t[m], a = le(s, n);
        i === !0 && a.loadingState === re.NOT_STARTED && Zr(a, t, n);
    }
    finally {
        R(r);
    }
} }
function fI(e) { let t = g(), n = Ce(); if (!J(2, t, n))
    return; let o = ge(), r = w(); if (Bt(r, n).set(6, null), U(t, o, e))
    if (typeof ngServerMode < "u" && ngServerMode)
        De(2, t, n);
    else {
        let s = t[O], a = R(null);
        try {
            if (!!e === !0) {
                let u = Ie(t, n)[Ta];
                Mt(s, u);
            }
        }
        finally {
            R(a);
        }
    } }
function pI() { let e = g(), t = N(); if (!J(2, e, t))
    return; Bt(w(), t).set(7, null), typeof ngServerMode < "u" && ngServerMode && De(2, e, t); }
function hI(e) { let t = g(), n = N(); J(0, t, n) && sI(af({ timeout: e })); }
function gI(e) { let t = g(), n = N(); J(1, t, n) && aI(af({ timeout: e })); }
function mI(e) { let t = g(), n = N(); if (!J(2, t, n))
    return; Bt(w(), n).set(0, null), typeof ngServerMode < "u" && ngServerMode ? De(2, t, n) : cI(af({ timeout: e }), t, n); }
function vI() { let e = g(), t = N(); if (!J(0, e, t))
    return; le(e[m], t).loadingTmplIndex === null && yo(e, t), De(0, e, t); }
function yI() { let e = g(), t = N(); if (!J(1, e, t))
    return; let n = e[m], o = le(n, t); o.loadingState === re.NOT_STARTED && wa(o, e, t); }
function EI() { let e = g(), t = N(); if (!J(2, e, t))
    return; if (Bt(w(), t).set(1, null), typeof ngServerMode < "u" && ngServerMode)
    De(2, e, t);
else {
    let o = e[O], i = Ie(e, t)[Ta];
    Mt(o, i);
} }
function II(e) { let t = g(), n = N(); J(0, t, n) && sI(Ma(e)); }
function DI(e) { let t = g(), n = N(); J(1, t, n) && aI(Ma(e)); }
function CI(e) { let t = g(), n = N(); if (!J(2, t, n))
    return; Bt(w(), n).set(5, { type: 5, delay: e }), typeof ngServerMode < "u" && ngServerMode ? De(2, t, n) : cI(Ma(e), t, n); }
function TI(e, t) { let n = g(), o = N(); J(0, n, o) && (yo(n, o), typeof ngServerMode < "u" && ngServerMode || Eo(n, o, e, t, km, () => De(0, n, o), 0)); }
function MI(e, t) { let n = g(), o = N(); if (!J(1, n, o))
    return; let r = n[m], i = le(r, o); i.loadingState === re.NOT_STARTED && Eo(n, o, e, t, km, () => Zr(i, n, o), 1); }
function NI() { let e = g(), t = N(); if (!J(2, e, t))
    return; Bt(w(), t).set(4, null), typeof ngServerMode < "u" && ngServerMode && De(2, e, t); }
function wI(e, t) { let n = g(), o = N(); J(0, n, o) && (yo(n, o), typeof ngServerMode < "u" && ngServerMode || Eo(n, o, e, t, xm, () => De(0, n, o), 0)); }
function SI(e, t) { let n = g(), o = N(); if (!J(1, n, o))
    return; let r = n[m], i = le(r, o); i.loadingState === re.NOT_STARTED && Eo(n, o, e, t, xm, () => Zr(i, n, o), 1); }
function _I() { let e = g(), t = N(); if (!J(2, e, t))
    return; Bt(w(), t).set(3, null), typeof ngServerMode < "u" && ngServerMode && De(2, e, t); }
function bI(e, t, n) { let o = g(), r = N(); J(0, o, r) && (yo(o, r), typeof ngServerMode < "u" && ngServerMode || Eo(o, r, e, t, nf, () => De(0, o, r), 0, n)); }
function AI(e, t, n) { let o = g(), r = N(); if (!J(1, o, r))
    return; let i = o[m], s = le(i, r); s.loadingState === re.NOT_STARTED && Eo(o, r, e, t, nf, () => Zr(s, o, r), 1, n); }
function RI(e) { let t = g(), n = N(); if (!J(2, t, n))
    return; Bt(w(), n).set(2, e ? { type: 2, intersectionObserverOptions: e } : null), typeof ngServerMode < "u" && ngServerMode && De(2, t, n); }
function cf(e, t) { let n = g(), o = ge(); if (U(n, o, t)) {
    let r = w(), i = Ce();
    if (ua(i, r, n, e, t))
        ve(i) && Jv(n, i.index);
    else {
        let a = Z(i, n);
        aa(n[C], a, null, i.value, e, t, null);
    }
} return cf; }
function lf(e, t, n, o) { let r = g(), i = ge(); if (U(r, i, t)) {
    let s = w(), a = Ce();
    c_(a, r, e, t, n, o);
} return lf; }
function Xo(e) { if (K("NgAnimateEnter"), typeof ngServerMode < "u" && ngServerMode || !Tn)
    return Xo; let t = g(); if (Qs(t))
    return Xo; let n = N(), o = t[O].get(B); return Ys(hs(t), n, () => jR(t, n, e, o)), Xs(t[O]), vd(t[O], hs(t)), Xo; }
function jR(e, t, n, o) { let r = Z(t, e), i = e[C], s = xv(n), a = [], c = !1, l = d => { if (ur(d) !== r)
    return; let f = d instanceof AnimationEvent ? "animationend" : "transitionend"; o.runOutsideAngular(() => { i.listen(r, f, u); }); }, u = d => { ur(d) === r && (pd(d, r) && (c = !0), HR(d, r, i)); }; if (s && s.length > 0) {
    o.runOutsideAngular(() => { a.push(i.listen(r, "animationstart", l)), a.push(i.listen(r, "transitionstart", l)); }), OS(r, s, a);
    for (let d of s)
        i.addClass(r, d);
    o.runOutsideAngular(() => { requestAnimationFrame(() => { if (!c && (Rv(r, ln, Tn), !ln.has(r))) {
        for (let d of s)
            i.removeClass(r, d);
        dd(r);
    } }); });
} }
function HR(e, t, n) { let o = Kn.get(t); if (!(ur(e) !== t || !o) && pd(e, t)) {
    e.stopPropagation();
    for (let r of o.classList)
        n.removeClass(t, r);
    dd(t);
} }
function er(e) { if (K("NgAnimateEnter"), typeof ngServerMode < "u" && ngServerMode || !Tn)
    return er; let t = g(); if (Qs(t))
    return er; let n = N(); return Ys(hs(t), n, () => VR(t, n, e)), Xs(t[O]), vd(t[O], hs(t)), er; }
function VR(e, t, n) { let o = Z(t, e); n.call(e[F], { target: o, animationComplete: xS }); }
function tr(e) { if (K("NgAnimateLeave"), typeof ngServerMode < "u" && ngServerMode || !Tn)
    return tr; let t = g(); if (Qs(t))
    return tr; let o = N(), r = t[O].get(B); return Ys(dn(t), o, () => BR(t, o, e, r)), Xs(t[O]), tr; }
function BR(e, t, n, o) { let { promise: r, resolve: i } = Ln(), s = Z(t, e), a = e[C]; Ft.add(e[Ne]), (dn(e).get(t.index).resolvers ??= []).push(i); let c = xv(n); return c && c.length > 0 ? $R(s, t, e, c, a, o) : i(), { promise: r, resolve: i }; }
function $R(e, t, n, o, r, i) { LS(e, r); let s = [], a = dn(n).get(t.index)?.resolvers, c, l = !1, u = d => { if (!(ur(d) !== e && d.type !== "animation-fallback") && (d.type === "animation-fallback" || pd(d, e))) {
    if (l = !0, c && clearTimeout(c), d.type !== "animation-fallback" && d.stopPropagation(), ln.delete(e), Gl(t, e), Array.isArray(t.projection))
        for (let p of o)
            r.removeClass(e, p);
    Wl(a, s), zl(n, t);
} }; i.runOutsideAngular(() => { s.push(r.listen(e, "animationend", u)), s.push(r.listen(e, "transitionend", u)); }), fd(t, e); for (let d of o)
    r.addClass(e, d); i.runOutsideAngular(() => { requestAnimationFrame(() => { if (l)
    return; Rv(e, ln, Tn); let d = ln.get(e); d ? (c = setTimeout(() => { u(new CustomEvent("animation-fallback")); }, d.duration + 50), s.push(() => clearTimeout(c))) : (Gl(t, e), Wl(a, s), zl(n, t)); }); }); }
function Ts(e) { if (K("NgAnimateLeave"), typeof ngServerMode < "u" && ngServerMode || !Tn)
    return Ts; let t = g(), n = N(); Ft.add(t[Ne]); let o = t[O].get(B), r = t[O].get(Sv); return Ys(dn(t), n, () => UR(t, n, e, o, r)), Xs(t[O]), Ts; }
function UR(e, t, n, o, r) { let { promise: i, resolve: s } = Ln(), a = Z(t, e), c = [], l = e[C], u = Qs(e); (dn(e).get(t.index).resolvers ??= []).push(s); let d = dn(e).get(t.index)?.resolvers; if (u)
    Vi(e, t, a, d, c);
else {
    let f = setTimeout(() => Vi(e, t, a, d, c), r), p = { target: a, animationComplete: () => { Vi(e, t, a, d, c), clearTimeout(f); } };
    fd(t, a), o.runOutsideAngular(() => { c.push(l.listen(a, "animationend", () => { Vi(e, t, a, d, c), clearTimeout(f); }, { once: !0 })); }), n.call(e[F], p);
} return { promise: i, resolve: s }; }
function OI() { return g()[ee][F]; }
var hu = class {
    destroy(t) { }
    updateValue(t, n) { }
    swap(t, n) { let o = Math.min(t, n), r = Math.max(t, n), i = this.detach(r); if (r - o > 1) {
        let s = this.detach(o);
        this.attach(o, i), this.attach(r, s);
    }
    else
        this.attach(o, i); }
    move(t, n) { this.attach(n, this.detach(t)); }
};
function ul(e, t, n, o, r) { return e === n && Object.is(t, o) ? 1 : Object.is(r(e, t), r(n, o)) ? -1 : 0; }
function GR(e, t, n, o) { let r, i, s = 0, a = e.length - 1, c = void 0; if (Array.isArray(t)) {
    R(o);
    let l = t.length - 1;
    for (R(null); s <= a && s <= l;) {
        let u = e.at(s), d = t[s], f = ul(s, u, s, d, n);
        if (f !== 0) {
            f < 0 && e.updateValue(s, d), s++;
            continue;
        }
        let p = e.at(a), h = t[l], v = ul(a, p, l, h, n);
        if (v !== 0) {
            v < 0 && e.updateValue(a, h), a--, l--;
            continue;
        }
        let y = n(s, u), I = n(a, p), A = n(s, d);
        if (Object.is(A, I)) {
            let oe = n(l, h);
            Object.is(oe, y) ? (e.swap(s, a), e.updateValue(a, h), l--, a--) : e.move(a, s), e.updateValue(s, d), s++;
            continue;
        }
        if (r ??= new Ms, i ??= Ng(e, s, a, n), gu(e, r, s, A))
            e.updateValue(s, d), s++, a++;
        else if (i.has(A))
            r.set(y, e.detach(s)), a--;
        else {
            let oe = e.create(s, t[s]);
            e.attach(s, oe), s++, a++;
        }
    }
    for (; s <= l;)
        Mg(e, r, n, s, t[s]), s++;
}
else if (t != null) {
    R(o);
    let l = t[Symbol.iterator]();
    R(null);
    let u = l.next();
    for (; !u.done && s <= a;) {
        let d = e.at(s), f = u.value, p = ul(s, d, s, f, n);
        if (p !== 0)
            p < 0 && e.updateValue(s, f), s++, u = l.next();
        else {
            r ??= new Ms, i ??= Ng(e, s, a, n);
            let h = n(s, f);
            if (gu(e, r, s, h))
                e.updateValue(s, f), s++, a++, u = l.next();
            else if (!i.has(h))
                e.attach(s, e.create(s, f)), s++, a++, u = l.next();
            else {
                let v = n(s, d);
                r.set(v, e.detach(s)), a--;
            }
        }
    }
    for (; !u.done;)
        Mg(e, r, n, e.length, u.value), u = l.next();
} for (; s <= a;)
    e.destroy(e.detach(a--)); r?.forEach(l => { e.destroy(l); }); }
function gu(e, t, n, o) { return t !== void 0 && t.has(o) ? (e.attach(n, t.get(o)), t.delete(o), !0) : !1; }
function Mg(e, t, n, o, r) { if (gu(e, t, o, n(o, r)))
    e.updateValue(o, r);
else {
    let i = e.create(o, r);
    e.attach(o, i);
} }
function Ng(e, t, n, o) { let r = new Set; for (let i = t; i <= n; i++)
    r.add(o(i, e.at(i))); return r; }
var Ms = class {
    kvMap = new Map;
    _vMap = void 0;
    has(t) { return this.kvMap.has(t); }
    delete(t) { if (!this.has(t))
        return !1; let n = this.kvMap.get(t); return this._vMap !== void 0 && this._vMap.has(n) ? (this.kvMap.set(t, this._vMap.get(n)), this._vMap.delete(n)) : this.kvMap.delete(t), !0; }
    get(t) { return this.kvMap.get(t); }
    set(t, n) { if (this.kvMap.has(t)) {
        let o = this.kvMap.get(t);
        this._vMap === void 0 && (this._vMap = new Map);
        let r = this._vMap;
        for (; r.has(o);)
            o = r.get(o);
        r.set(o, n);
    }
    else
        this.kvMap.set(t, n); }
    forEach(t) { for (let [n, o] of this.kvMap)
        if (t(o, n), this._vMap !== void 0) {
            let r = this._vMap;
            for (; r.has(o);)
                o = r.get(o), t(o, n);
        } }
};
function xI(e, t, n, o, r, i, s, a) { K("NgControlFlow"); let c = g(), l = w(), u = ie(l.consts, i); return yn(c, l, e, t, n, o, r, u, 256, s, a), Sa; }
function Sa(e, t, n, o, r, i, s, a) { K("NgControlFlow"); let c = g(), l = w(), u = ie(l.consts, i); return yn(c, l, e, t, n, o, r, u, 512, s, a), Sa; }
function kI(e, t) { K("NgControlFlow"); let n = g(), o = ge(), r = n[o] !== j ? n[o] : -1, i = r !== -1 ? Ns(n, E + r) : void 0, s = 0; if (U(n, o, e)) {
    let a = R(null);
    try {
        if (i !== void 0 && Wr(i, s), e !== -1) {
            let c = E + e, l = Ns(n, c), u = Eu(n[m], c), d = ky(l, u, n), f = Ht(n, u, t, { dehydratedView: d });
            Ct(l, f, s, pn(u, d));
        }
    }
    finally {
        R(a);
    }
}
else if (i !== void 0) {
    let a = uy(i, s);
    a !== void 0 && (a[F] = t);
} }
var mu = class {
    lContainer;
    $implicit;
    $index;
    constructor(t, n, o) { this.lContainer = t, this.$implicit = n, this.$index = o; }
    get $count() { return this.lContainer.length - k; }
};
function LI(e) { return e; }
function PI(e, t) { return t; }
var vu = class {
    hasEmptyBlock;
    trackByFn;
    liveCollection;
    constructor(t, n, o) { this.hasEmptyBlock = t, this.trackByFn = n, this.liveCollection = o; }
};
function FI(e, t, n, o, r, i, s, a, c, l, u, d, f) { K("NgControlFlow"); let p = g(), h = w(), v = c !== void 0, y = g(), I = a ? s.bind(y[ee][F]) : s, A = new vu(v, I); y[E + e] = A, yn(p, h, e + 1, t, n, o, r, ie(h.consts, i), 256), v && yn(p, h, e + 2, c, l, u, d, ie(h.consts, f), 512); }
var yu = class extends hu {
    lContainer;
    hostLView;
    templateTNode;
    operationsCounter = void 0;
    needsIndexUpdate = !1;
    constructor(t, n, o) { super(), this.lContainer = t, this.hostLView = n, this.templateTNode = o; }
    get length() { return this.lContainer.length - k; }
    at(t) { return this.getLView(t)[F].$implicit; }
    attach(t, n) { let o = n[ce]; this.needsIndexUpdate ||= t !== this.length, Ct(this.lContainer, n, t, pn(this.templateTNode, o)), WR(this.lContainer, t); }
    detach(t) { return this.needsIndexUpdate ||= t !== this.length - 1, zR(this.lContainer, t), qR(this.lContainer, t); }
    create(t, n) { let o = gr(this.lContainer, this.templateTNode.tView.ssrId); return Ht(this.hostLView, this.templateTNode, new mu(this.lContainer, n, t), { dehydratedView: o }); }
    destroy(t) { $r(t[m], t); }
    updateValue(t, n) { this.getLView(t)[F].$implicit = n; }
    reset() { this.needsIndexUpdate = !1; }
    updateIndexes() { if (this.needsIndexUpdate)
        for (let t = 0; t < this.length; t++)
            this.getLView(t)[F].$index = t; }
    getLView(t) { return QR(this.lContainer, t); }
};
function jI(e) { let t = R(null), n = ne(); try {
    let o = g(), r = o[m], i = o[n], s = n + 1, a = Ns(o, s);
    if (i.liveCollection === void 0) {
        let l = Eu(r, s);
        i.liveCollection = new yu(a, o, l);
    }
    else
        i.liveCollection.reset();
    let c = i.liveCollection;
    if (GR(c, e, i.trackByFn, t), c.updateIndexes(), i.hasEmptyBlock) {
        let l = ge(), u = c.length === 0;
        if (U(o, l, u)) {
            let d = n + 2, f = Ns(o, d);
            if (u) {
                let p = Eu(r, d), h = ky(f, p, o), v = Ht(o, p, void 0, { dehydratedView: h });
                Ct(f, v, 0, pn(p, h));
            }
            else
                r.firstUpdatePass && ya(f), Wr(f, 0);
        }
    }
}
finally {
    R(t);
} }
function Ns(e, t) { return e[t]; }
function WR(e, t) { if (e.length <= k)
    return; let n = k + t, o = e[n], r = o ? o[ke] : void 0; if (o && r && r.detachedLeaveAnimationFns && r.detachedLeaveAnimationFns.length > 0) {
    let i = o[O];
    HS(i, r), Ft.delete(o[Ne]), r.detachedLeaveAnimationFns = void 0;
} }
function zR(e, t) { if (e.length <= k)
    return; let n = k + t, o = e[n], r = o ? o[ke] : void 0; r && r.leave && r.leave.size > 0 && (r.detachedLeaveAnimationFns = []); }
function qR(e, t) { return fr(e, t); }
function QR(e, t) { return uy(e, t); }
function Eu(e, t) { return Jt(e, t); }
function uf(e, t, n) { let o = g(), r = ge(); if (U(o, r, t)) {
    let i = w(), s = Ce();
    Cd(s, o, e, t, o[C], n);
} return uf; }
function Iu(e, t, n, o, r) { ua(t, e, n, r ? "class" : "style", o); }
function Dr(e, t, n, o) { let r = g(), i = r[m], s = e + E, a = i.firstCreatePass ? kd(s, r, 2, t, Md, Ti(), n, o) : i.data[s]; if (ve(a)) {
    let c = r[Ke].tracingService;
    if (c && c.componentCreate) {
        let l = i.data[a.directiveStart + a.componentOffset];
        return c.componentCreate(Od(l), () => (wg(e, t, r, a, o), Dr));
    }
} return wg(e, t, r, a, o), Dr; }
function wg(e, t, n, o, r) { if (ca(o, n, e, t, pf), xn(o)) {
    let i = n[m];
    sa(i, n, o), Xu(i, o, n);
} r != null && ho(n, o); }
function _a() { let e = w(), t = N(), n = la(t); return e.firstCreatePass && Ld(e, n), Dc(n) && Mc(), Ic(), n.classesWithoutHost != null && KM(n) && Iu(e, n, g(), n.classesWithoutHost, !0), n.stylesWithoutHost != null && JM(n) && Iu(e, n, g(), n.stylesWithoutHost, !1), _a; }
function df(e, t, n, o) { return Dr(e, t, n, o), _a(), df; }
function ba(e, t, n, o) { let r = g(), i = r[m], s = e + E, a = i.firstCreatePass ? tE(s, i, 2, t, n, o) : i.data[s]; return ca(a, r, e, t, pf), o != null && ho(r, a), ba; }
function Aa() { let e = N(), t = la(e); return Dc(t) && Mc(), Ic(), Aa; }
function ff(e, t, n, o) { return ba(e, t, n, o), Aa(), ff; }
var pf = (e, t, n, o, r) => (Ge(!0), zs(t[C], o, bi()));
function YR(e, t, n, o, r) { let i = !Gs(t, n); if (Ge(i), i)
    return zs(t[C], o, bi()); let s = t[ce], a = zr(s, e, t, n); if (Qm(s, r) && $s(s, r, a.nextSibling), s) {
    if (a == null)
        throw new M(-502, `<${o}>`);
    if (a.nodeType !== Node.ELEMENT_NODE)
        throw new M(-500, !1);
    (Lu(n) || ym(a)) && ve(n) && (oh(n), hv(a));
} return a; }
function HI() { pf = YR; }
function Ra(e, t, n) { let o = g(), r = o[m], i = e + E, s = r.firstCreatePass ? kd(i, o, 8, "ng-container", Md, Ti(), t, n) : r.data[i]; if (ca(s, o, e, "ng-container", vf), xn(s)) {
    let a = o[m];
    sa(a, o, s), Xu(a, s, o);
} return n != null && ho(o, s), Ra; }
function Kr() { let e = w(), t = N(), n = la(t); return e.firstCreatePass && Ld(e, n), Kr; }
function hf(e, t, n) { return Ra(e, t, n), Kr(), hf; }
function Oa(e, t, n) { let o = g(), r = o[m], i = e + E, s = r.firstCreatePass ? tE(i, r, 8, "ng-container", t, n) : r.data[i]; return ca(s, o, e, "ng-container", vf), n != null && ho(o, s), Oa; }
function gf() { let e = N(), t = la(e); return Kr; }
function mf(e, t, n) { return Oa(e, t, n), gf(), mf; }
var vf = (e, t, n, o, r) => (Ge(!0), nd(t[C], ""));
function ZR(e, t, n, o, r) { let i, s = !Gs(t, n); if (Ge(s), s)
    return nd(t[C], ""); let a = t[ce], c = zr(a, e, t, n), l = qm(a, r); return $s(a, r, c), i = ma(l, c), i; }
function VI() { vf = ZR; }
var BI = new b("FOREIGN_CONTEXT"), Du = class extends vt {
    get head() { let t = this._lView, n = t[m]; return t[n.firstChild.index]; }
    get tail() { let t = this._lView, n = t[m]; return t[n.firstChild.next.index]; }
};
function KR(e, t) { let n = e[q], o = e[X], r = n[C], i = oa(3, o, null, 3, 0, null, null, null, null, null, null), s = i.data[E] = Kl(i, null, 2, E, "", null), a = i.data[E + 1] = Kl(i, null, 2, E + 1, "", null); i.firstChild = s, s.next = a, a.prev = s; let c = Ur(n, i, null, 0, null, null, null, r, null, null, null), l = c[s.index] = r.createComment(""), u = c[a.index] = r.createComment(""); c[_] &= -5; let d = new Du(c); if (Ct(e, c, t), !l.parentNode) {
    let f = document.createDocumentFragment();
    f.appendChild(l), f.appendChild(u);
    let p = a.index + 1;
    c[p] = f;
} return d; }
function $I(e, t, n) { let o = g(), r = w(), i = e + E, s = ie(r.consts, t), a; r.firstCreatePass ? (a = Vt(r, i, 4, null, null), Mi()) : (a = r.data[i], Ue(a, !1)); let c = o[C], l = c.createComment(""); ta(r, o, l, a), _e(l, o); let u = wd(l, o, l, a); o[i] = u, ra(o, u); let d = KR(u, 0), f = Ru(a, o, BI, 8), [p, h] = s[jy](n, f ?? void 0), v = d.tail, y = v.parentNode; if (y)
    for (let I = 0; I < p.length; I++)
        ze(c, y, p[I], v, !1); h && d.onDestroy(h); }
var ws = class {
    context;
    constructor(t) { this.context = t; }
    get(t, n) { return t === BI ? this.context : n; }
};
function UI(e, t) { let n = g(), o = e + E, r = n[o]; r[_] |= 4; let i = w(), s = i.data[o], a = ie(i.consts, t); return [n, r, s, a]; }
function GI(e, t) { let [n, o, r, i] = UI(e, t), s = i[Vy], a = i[Hy], c = i[By]; return s(() => { let u = c ? { embeddedViewInjector: new ws(c()) } : void 0, d = Ht(n, r, null, u); Ct(o, d, o.length - k, !1), a(() => { if (!et(d)) {
    let p = o.indexOf(d, k);
    Wr(o, p - k);
} }); let f = d[m]; return jt(f, d, f.firstChild, []); }); }
function WI(e, t) { let [n, o, r, i] = UI(e, t), s = i[Vy], a = i[Hy], c = i[By]; return (...l) => s(() => { let d = c ? { embeddedViewInjector: new ws(c()) } : void 0, f = Ht(n, r, l, d); Ct(o, f, o.length - k, !1), a(() => { if (!et(f)) {
    let h = o.indexOf(f, k);
    Wr(o, h - k);
} }); let p = f[m]; return jt(p, f, p.firstChild, []); }); }
function zI() { return g(); }
function yf(e, t, n) { let o = g(), r = ge(); if (U(o, r, t)) {
    let i = w(), s = Ce();
    Td(s, o, e, t, o[C], n);
} return yf; }
function Ef(e, t, n) { let o = g(), r = ge(); if (U(o, r, t)) {
    let i = w(), s = Ce(), a = Ni(i.data), c = Xv(a, s, o);
    Td(s, o, e, t, c, n);
} return Ef; }
var Wo = void 0;
function JR(e) { let t = Math.floor(Math.abs(e)), n = e.toString().replace(/^[^.]*\.?/, "").length; return t === 1 && n === 0 ? 1 : 5; }
var XR = ["en", [["a", "p"], ["AM", "PM"]], [["AM", "PM"]], [["S", "M", "T", "W", "T", "F", "S"], ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]], Wo, [["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"], ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]], Wo, [["B", "A"], ["BC", "AD"], ["Before Christ", "Anno Domini"]], 0, [6, 0], ["M/d/yy", "MMM d, y", "MMMM d, y", "EEEE, MMMM d, y"], ["h:mm\u202Fa", "h:mm:ss\u202Fa", "h:mm:ss\u202Fa z", "h:mm:ss\u202Fa zzzz"], ["{1}, {0}", Wo, Wo, Wo], [".", ",", ";", "%", "+", "-", "E", "\xD7", "\u2030", "\u221E", "NaN", ":"], ["#,##0.###", "#,##0%", "\xA4#,##0.00", "#E0"], "USD", "$", "US Dollar", {}, "ltr", JR], Yn = Object.create(null);
function eO(e, t, n) { typeof t != "string" && (n = t, t = e[Cr.LocaleId]), t = t.toLowerCase().replace(/_/g, "-"), Yn[t] = e, n && (Yn[t][Cr.ExtraData] = n); }
function If(e) { let t = oO(e), n = Sg(t); if (n)
    return n; let o = t.split("-")[0]; if (n = Sg(o), n)
    return n; if (o === "en")
    return XR; throw new M(701, !1); }
function tO(e) { return If(e)[Cr.CurrencyCode] || null; }
function qI(e) { return If(e)[Cr.PluralCase]; }
function Sg(e) { if (!(e in Yn)) {
    let t = Me.ng && Me.ng.common && Me.ng.common.locales && Me.ng.common.locales[e];
    return t !== void 0 && (Yn[e] = t), t;
} return Yn[e]; }
function nO() { Yn = Object.create(null); }
var Cr = { LocaleId: 0, DayPeriodsFormat: 1, DayPeriodsStandalone: 2, DaysFormat: 3, DaysStandalone: 4, MonthsFormat: 5, MonthsStandalone: 6, Eras: 7, FirstDayOfWeek: 8, WeekendRange: 9, DateFormat: 10, TimeFormat: 11, DateTimeFormat: 12, NumberSymbols: 13, NumberFormats: 14, CurrencyCode: 15, CurrencySymbol: 16, CurrencyName: 17, Currencies: 18, Directionality: 19, PluralCase: 20, ExtraData: 21 };
function oO(e) { return e.toLowerCase().replace(/_/g, "-"); }
var rO = ["zero", "one", "two", "few", "many"];
function iO(e, t) { let n = qI(t)(parseInt(e, 10)), o = rO[n]; return o !== void 0 ? o : "other"; }
var Jr = "en-US", sO = "USD", QI = { marker: "element" }, YI = { marker: "ICU" }, ft = (function (e) { return e[e.SHIFT = 2] = "SHIFT", e[e.APPEND_EAGERLY = 1] = "APPEND_EAGERLY", e[e.COMMENT = 2] = "COMMENT", e; })(ft || {}), ZI = Jr;
function KI(e) { typeof e == "string" && (ZI = e.toLowerCase().replace(/_/g, "-")); }
function aO() { return ZI; }
var Tr = 0, nr = 0;
function cO(e) { e && (Tr = Tr | 1 << Math.min(nr, 31)), nr++; }
function lO(e, t, n) { try {
    if (nr > 0) {
        let o = e.data[n], r = Array.isArray(o) ? o : o.update, i = nt() - nr - 1;
        tD(e, t, r, i, Tr);
    }
}
finally {
    Tr = 0, nr = 0;
} }
function JI(e, t, n) { let o = e[C]; switch (n) {
    case Node.COMMENT_NODE: return nd(o, t);
    case Node.TEXT_NODE: return td(o, t);
    case Node.ELEMENT_NODE: return zs(o, t, null);
} }
var or = (e, t, n, o) => (Ge(!0), JI(e, n, o));
function uO(e, t, n, o) { let r = e[ce], i = t - E, s = !va() || !r || Vo() || Us(r, i); return Ge(s), s ? JI(e, n, o) : Ey(r, i); }
function XI() { or = uO; }
function dO(e, t, n, o) { let r = e[C]; for (let i = 0; i < t.length; i++) {
    let s = t[i++], a = t[i], c = (s & ft.COMMENT) === ft.COMMENT, l = (s & ft.APPEND_EAGERLY) === ft.APPEND_EAGERLY, u = s >>> ft.SHIFT, d = e[u], f = !1;
    d === null && (d = e[u] = or(e, u, a, c ? Node.COMMENT_NODE : Node.TEXT_NODE), f = $o()), l && n !== null && f && ze(r, n, d, o, !1);
} }
function eD(e, t, n, o) { let r = n[C], i = null, s; for (let a = 0; a < t.length; a++) {
    let c = t[a];
    if (typeof c == "string") {
        let l = t[++a];
        n[l] === null && (n[l] = or(n, l, c, Node.TEXT_NODE));
    }
    else if (typeof c == "number")
        switch (c & 1) {
            case 0:
                let l = Q_(c);
                i === null && (i = l, s = r.parentNode(o));
                let u, d;
                if (l === i ? (u = o, d = s) : (u = null, d = x(n[l])), d !== null) {
                    let v = Y_(c), y = n[v];
                    ze(r, d, y, u, !1);
                    let I = Yo(e, v);
                    if (I !== null && typeof I == "object") {
                        let A = ga(I, n);
                        A !== null && eD(e, I.create[A], n, n[I.anchorIdx]);
                    }
                }
                break;
            case 1:
                let f = c >>> 1, p = t[++a], h = t[++a];
                aa(r, Kt(f, n), null, null, p, h, null);
                break;
            default:
        }
    else
        switch (c) {
            case YI:
                let l = t[++a], u = t[++a];
                if (n[u] === null) {
                    let p = n[u] = or(n, u, l, Node.COMMENT_NODE);
                    _e(p, n);
                }
                break;
            case QI:
                let d = t[++a], f = t[++a];
                if (n[f] === null) {
                    let p = n[f] = or(n, f, d, Node.ELEMENT_NODE);
                    _e(p, n);
                }
                break;
            default:
        }
} }
function tD(e, t, n, o, r) { for (let i = 0; i < n.length; i++) {
    let s = n[i], a = n[++i];
    if (s & r) {
        let c = "";
        for (let l = i + 1; l <= i + a; l++) {
            let u = n[l];
            if (typeof u == "string")
                c += u;
            else if (typeof u == "number")
                if (u < 0)
                    c += S(t[o - u]);
                else {
                    let d = u >>> 2;
                    switch (u & 3) {
                        case 1:
                            let f = n[++l], p = n[++l], h = e.data[d];
                            if (typeof h == "string")
                                aa(t[C], t[d], null, h, f, c, p);
                            else {
                                let y = ne();
                                rt(d);
                                try {
                                    Cd(h, t, f, c, t[C], p);
                                }
                                finally {
                                    rt(y);
                                }
                            }
                            break;
                        case 0:
                            let v = t[d];
                            v !== null && fv(t[C], v, c);
                            break;
                        case 2:
                            fO(e, Yo(e, d), t, c);
                            break;
                        case 3:
                            _g(e, Yo(e, d), o, t);
                            break;
                    }
                }
        }
    }
    else {
        let c = n[i + 1];
        if (c > 0 && (c & 3) === 3) {
            let l = c >>> 2, u = Yo(e, l);
            t[u.currentCaseLViewIndex] < 0 && _g(e, u, o, t);
        }
    }
    i += a;
} }
function _g(e, t, n, o) { let r = o[t.currentCaseLViewIndex]; if (r !== null) {
    let i = Tr;
    r < 0 && (r = o[t.currentCaseLViewIndex] = ~r, i = -1), tD(e, o, t.update[r], n, i);
} }
function fO(e, t, n, o) { let r = pO(t, o); if (ga(t, n) !== r && (nD(e, t, n), n[t.currentCaseLViewIndex] = r === null ? null : ~r, r !== null)) {
    let s = n[t.anchorIdx];
    s && eD(e, t.create[r], n, s), hb(n, t.anchorIdx, r);
} }
function nD(e, t, n) { let o = ga(t, n); if (o !== null) {
    let r = t.remove[o];
    for (let i = 0; i < r.length; i++) {
        let s = r[i];
        if (s > 0) {
            let a = Kt(s, n);
            a !== null && Hr(n[C], a);
        }
        else
            nD(e, Yo(e, ~s), n);
    }
} }
function pO(e, t) { let n = e.cases.indexOf(t); if (n === -1)
    switch (e.type) {
        case 1: {
            let o = iO(t, aO());
            n = e.cases.indexOf(o), n === -1 && o !== "other" && (n = e.cases.indexOf("other"));
            break;
        }
        case 0: {
            n = e.cases.indexOf("other");
            break;
        }
    } return n === -1 ? null : n; }
var Ss = /�(\d+):?\d*�/gi, hO = /({\s*�\d+:?\d*�\s*,\s*\S{6}\s*,[\s\S]*})/gi, gO = /�(\d+)�/, oD = /^\s*(�\d+:?\d*�)\s*,\s*(select|plural)\s*,/, rr = "\uFFFD", mO = /�\/?\*(\d+:\d+)�/gi, vO = /�(\/?[#*]\d+):?\d*�/gi, yO = /\uE500/g;
function EO(e) { return e.replace(yO, " "); }
function IO(e, t, n, o, r, i) { let s = kn(), a = [], c = [], l = [[]], u = [[]]; r = MO(r, i); let d = EO(r).split(vO); for (let f = 0; f < d.length; f++) {
    let p = d[f];
    if ((f & 1) === 0) {
        let h = Cu(p);
        for (let v = 0; v < h.length; v++) {
            let y = h[v];
            if ((v & 1) === 0) {
                let I = y;
                I !== "" && DO(u[0], e, s, l[0], a, c, n, I);
            }
            else {
                let I = y;
                if (typeof I != "object")
                    throw new Error(`Unable to parse ICU expression in "${r}" message.`);
                let oe = rD(e, s, l[0], n, a, "", !0).index;
                sD(u[0], e, n, c, t, I, oe);
            }
        }
    }
    else {
        let h = p.charCodeAt(0) === 47, v = p.charCodeAt(h ? 1 : 0), y = E + Number.parseInt(p.substring(h ? 2 : 1));
        if (h)
            l.shift(), u.shift(), Ue(kn(), !1);
        else {
            let I = q_(e, l[0], y);
            l.unshift([]), Ue(I, !0);
            let A = { kind: 2, index: y, children: [], type: v === 35 ? 0 : 1 };
            u[0].push(A), u.unshift(A.children);
        }
    }
} e.data[o] = { create: a, update: c, ast: u[0], parentTNodeIndex: t }; }
function rD(e, t, n, o, r, i, s) { let a = Gr(e, o, 1, null), c = a << ft.SHIFT, l = kn(); t === l && (l = null), l === null && (c |= ft.APPEND_EAGERLY), s && (c |= ft.COMMENT, MS(K_)), r.push(c, i === null ? "" : i); let u = Sd(e, a, s ? 32 : 1, i === null ? "" : i, null); gy(n, u); let d = u.index; return Ue(u, !1), l !== null && t !== l && z_(l, d), u; }
function DO(e, t, n, o, r, i, s, a) { let c = a.match(Ss), u = rD(t, n, o, s, r, c ? null : a, !1).index; c && _s(i, a, u, null, 0, null), e.push({ kind: 0, index: u }); }
function CO(e, t, n) { let o = N(), r = o.index, i = []; if (e.firstCreatePass && e.data[t] === null) {
    for (let s = 0; s < n.length; s += 2) {
        let a = n[s], c = n[s + 1];
        if (c !== "") {
            if (hO.test(c))
                throw new Error(`ICU expressions are not supported in attributes. Message: "${c}".`);
            let l = o.namespace ? `:${o.namespace}:${o.value}` : o.value;
            _s(i, c, r, a, TO(i), Tu(a, l));
        }
    }
    e.data[t] = i;
} }
function _s(e, t, n, o, r, i) { let s = e.length, a = s + 1; e.push(null, null); let c = s + 2, l = t.split(Ss), u = 0; for (let d = 0; d < l.length; d++) {
    let f = l[d];
    if (d & 1) {
        let p = r + parseInt(f, 10);
        e.push(-1 - p), u = u | iD(p);
    }
    else
        f !== "" && e.push(f);
} return e.push(n << 2 | (o ? 1 : 0)), o && e.push(o, i), e[s] = u, e[a] = e.length - c, u; }
function TO(e) { let t = 0; for (let n = 0; n < e.length; n++) {
    let o = e[n];
    typeof o == "number" && o < 0 && t++;
} return t; }
function iD(e) { return 1 << Math.min(e, 31); }
function bg(e) { let t, n = "", o = 0, r = !1, i; for (; (t = mO.exec(e)) !== null;)
    r ? t[0] === `${rr}/*${i}${rr}` && (o = t.index, r = !1) : (n += e.substring(o, t.index + t[0].length), i = t[1], r = !0); return n += e.slice(o), n; }
function MO(e, t) { if (vy(t))
    return bg(e); {
    let n = e.indexOf(`:${t}${rr}`) + 2 + t.toString().length, o = e.search(new RegExp(`${rr}\\/\\*\\d+:${t}${rr}`));
    return bg(e.substring(n, o));
} }
function sD(e, t, n, o, r, i, s) { let a = 0, c = { type: i.type, currentCaseLViewIndex: Gr(t, n, 1, null), anchorIdx: s, cases: [], create: [], remove: [], update: [] }; _O(o, i, s), W_(t, s, c); let l = i.values, u = []; for (let d = 0; d < l.length; d++) {
    let f = l[d], p = [];
    for (let v = 0; v < f.length; v++) {
        let y = f[v];
        if (typeof y != "string") {
            let I = p.push(y) - 1;
            f[v] = `<!--\uFFFD${I}\uFFFD-->`;
        }
    }
    let h = [];
    u.push(h), a = wO(h, t, c, n, o, r, i.cases[d], f.join(""), p) | a;
} a && bO(o, a, s), e.push({ kind: 3, index: s, cases: u, currentCaseLViewIndex: c.currentCaseLViewIndex }); }
function NO(e) { let t = [], n = [], o = 1, r = 0; e = e.replace(oD, function (s, a, c) { return c === "select" ? o = 0 : o = 1, r = parseInt(a.slice(1), 10), ""; }); let i = Cu(e); for (let s = 0; s < i.length;) {
    let a = i[s++].trim();
    o === 1 && (a = a.replace(/\s*(?:=)?(\w+)\s*/, "$1")), a.length && t.push(a);
    let c = Cu(i[s++]);
    t.length > n.length && n.push(c);
} return { type: o, mainBinding: r, cases: t, values: n }; }
function Cu(e) { if (!e)
    return []; let t = 0, n = [], o = [], r = /[{}]/g; r.lastIndex = 0; let i; for (; i = r.exec(e);) {
    let a = i.index;
    if (i[0] == "}") {
        if (n.pop(), n.length == 0) {
            let c = e.substring(t, a);
            oD.test(c) ? o.push(NO(c)) : o.push(c), t = a + 1;
        }
    }
    else {
        if (n.length == 0) {
            let c = e.substring(t, a);
            o.push(c), t = a + 1;
        }
        n.push("{");
    }
} let s = e.substring(t); return o.push(s), o; }
function wO(e, t, n, o, r, i, s, a, c) { let l = [], u = [], d = []; n.cases.push(s), n.create.push(l), n.remove.push(u), n.update.push(d); let p = iv(Ar()).getInertBodyElement(a), h = $l(p) || p; return h ? aD(e, t, n, o, r, l, u, d, h, i, c, 0) : 0; }
function aD(e, t, n, o, r, i, s, a, c, l, u, d) { let f = 0, p = c.firstChild; for (; p;) {
    let h = Gr(t, o, 1, null);
    switch (p.nodeType) {
        case Node.ELEMENT_NODE:
            let v = p, y = v.tagName.toLowerCase();
            if (Object.hasOwn(Hl, y)) {
                dl(i, QI, y, l, h), t.data[h] = y;
                let je = v.attributes;
                for (let ct = 0; ct < je.length; ct++) {
                    let Ut = je.item(ct), oi = Ut.name.toLowerCase(), fM = !!Ut.value.match(Ss), Ip = v.namespaceURI, Dp = Ip && nv[Ip], Cp = Dp ? `:${Dp}:${y}` : y;
                    if (fM)
                        Object.hasOwn(Vl, oi) && _s(a, Ut.value, h, Ut.name, 0, Tu(oi, Cp));
                    else if (Vl[oi]) {
                        let pM = Ut.value;
                        Tu(oi, Cp) ? Rg(i, h, Ut.name, "unsafe:blocked") : Rg(i, h, Ut.name, pM);
                    }
                }
                let Ae = { kind: 1, index: h, children: [] };
                e.push(Ae), f = aD(Ae.children, t, n, o, r, i, s, a, p, h, u, d + 1) | f, Ag(s, h, d);
            }
            break;
        case Node.TEXT_NODE:
            let I = p.textContent || "", A = I.match(Ss);
            dl(i, null, A ? "" : I, l, h), Ag(s, h, d), A && (f = _s(a, I, h, null, 0, null) | f), e.push({ kind: 0, index: h });
            break;
        case Node.COMMENT_NODE:
            let oe = gO.exec(p.textContent || "");
            if (oe) {
                let je = parseInt(oe[1], 10), Ae = u[je];
                dl(i, YI, "", l, h), sD(e, t, o, r, l, Ae, h), SO(s, h, d);
            }
            break;
    }
    p = p.nextSibling;
} return f; }
function Ag(e, t, n) { n === 0 && e.push(t); }
function SO(e, t, n) { n === 0 && (e.push(~t), e.push(t)); }
function _O(e, t, n) { e.push(iD(t.mainBinding), 2, -1 - t.mainBinding, n << 2 | 2); }
function bO(e, t, n) { e.push(t, 1, n << 2 | 3); }
function dl(e, t, n, o, r) { t !== null && e.push(t), e.push(n, r, Z_(0, o, r)); }
function Rg(e, t, n, o) { e.push(t << 1 | 1, n, o); }
function Tu(e, t) { let n; if (t) {
    let [o, r] = mv(t, !1);
    n = ko(r, e, o);
}
else
    n = ko("*", e); switch (n) {
    case de.HTML: return od;
    case de.STYLE: return rd;
    case de.SCRIPT: return sd;
    case de.URL: return Ws;
    case de.RESOURCE_URL: return qs;
    case de.ATTRIBUTE_NO_BINDING: return ad;
    default: return null;
} }
var Og = 0, AO = /\[(�.+?�?)\]/, RO = /\[(�.+?�?)\]|(�\/?\*\d+:\d+�)/g, OO = /({\s*)(VAR_(PLURAL|SELECT)(_\d+)?)(\s*,)/g, xO = /{([A-Z0-9_]+)}/g, kO = /�I18N_EXP_(ICU(_\d+)?)�/g, LO = /\/\*/, PO = /\d+\:(\d+)/;
function FO(e, t = {}) { let n = e; if (AO.test(e)) {
    let o = {}, r = [Og];
    n = n.replace(RO, (i, s, a) => { let c = s || a, l = o[c] || []; if (l.length || (c.split("|").forEach(v => { let y = v.match(PO), I = y ? parseInt(y[1], 10) : Og, A = LO.test(v); l.push([I, A, v]); }), o[c] = l), !l.length)
        throw new Error(`i18n postprocess: unmatched placeholder - ${c}`); let u = r[r.length - 1], d = 0; for (let v = 0; v < l.length; v++)
        if (l[v][0] === u) {
            d = v;
            break;
        } let [f, p, h] = l[d]; return p ? r.pop() : u !== f && r.push(f), l.splice(d, 1), h; });
} return Object.keys(t).length && (n = n.replace(OO, (o, r, i, s, a, c) => Object.hasOwn(t, i) ? `${r}${t[i]}${c}` : o), n = n.replace(xO, (o, r) => Object.hasOwn(t, r) ? t[r] : o), n = n.replace(kO, (o, r) => { if (Object.hasOwn(t, r)) {
    let i = t[r];
    if (!i.length)
        throw new Error(`i18n postprocess: unmatched ICU - ${o} with key: ${r}`);
    return i.shift();
} return o; })), n; }
function Df(e, t, n = -1) { let o = w(), r = g(), i = E + e, s = ie(o.consts, t), a = kn(); if (o.firstCreatePass && IO(o, a === null ? 0 : a.index, r, i, s, n), o.type === 2) {
    let f = r[ee];
    f[_] |= 32;
}
else
    r[_] |= 32; let c = o.data[i], l = a === r[X] ? null : a, u = Hv(o, l, r), d = a && a.type & 8 ? r[a.index] : null; cb(r, i, a, n), dO(r, c.create, u, d), Oc(!0); }
function Cf() { Oc(!1); }
function cD(e, t, n) { Df(e, t, n), Cf(); }
function lD(e, t) { let n = w(), o = ie(n.consts, t); CO(n, e + E, o); }
function Tf(e) { let t = g(); return cO(U(t, ge(), e)), Tf; }
function uD(e) { lO(w(), g(), e + E); }
function dD(e, t = {}) { return FO(e, t); }
function Mf(e, t, n) { let o = g(), r = w(), i = N(); return Sf(r, o, o[C], i, e, t, n), Mf; }
function Nf(e, t) { let n = N(), o = g(), r = w(), i = Ni(r.data), s = Xv(i, n, o); return Sf(r, o, s, n, e, t), Nf; }
function wf(e, t, n) { let o = g(), r = w(), i = N(); return (i.type & 3 || n) && xd(i, r, o, n, o[C], e, t, Pt(i, o, t)), wf; }
function Sf(e, t, n, o, r, i, s) { let a = !0, c = null; if ((o.type & 3 || s) && (c ??= Pt(o, t, i), xd(o, e, t, s, n, r, i, c) && (a = !1)), a) {
    let l = o.outputs?.[r], u = o.hostDirectiveOutputs?.[r];
    if (u && u.length)
        for (let d = 0; d < u.length; d += 2) {
            let f = u[d], p = u[d + 1];
            c ??= Pt(o, t, i), vs(o, t, f, p, r, c);
        }
    if (l && l.length)
        for (let d of l)
            c ??= Pt(o, t, i), vs(o, t, d, r, r, c);
} }
function fD(e = 1) { return ch(e); }
function jO(e, t) { let n = null, o = vS(e); for (let r = 0; r < t.length; r++) {
    let i = t[r];
    if (i === "*") {
        n = r;
        continue;
    }
    if (o === null ? Nv(e, i, !0) : IS(o, i))
        return r;
} return n; }
function pD(e) { let t = g()[ee][X]; if (!t.projection) {
    let n = e ? e.length : 1, o = t.projection = _o(n, null), r = o.slice(), i = t.child;
    for (; i !== null;) {
        if (i.type !== 128) {
            let s = e ? jO(i, e) : 0;
            s !== null && (r[s] ? r[s].projectionNext = i : o[s] = i, r[s] = i);
        }
        i = i.next;
    }
} }
function hD(e, t = 0, n, o, r, i) { let s = g(), a = w(), c = o ? e + 1 : null; c !== null && yn(s, a, c, o, r, i, null, n); let l = Vt(a, E + e, 16, null, n || null); l.projection === null && (l.projection = t), Mi(); let d = !s[ce] || Vo(); s[ee][X].projection[l.projection] === null && c !== null ? HO(s, a, c) : d && !uo(l) && ZS(a, s, l); }
function HO(e, t, n) { let o = E + n, r = t.data[o], i = e[o], s = gr(i, r.tView.ssrId), a = Ht(e, r, void 0, { dehydratedView: s }); Ct(i, a, 0, pn(r, s)); }
function _f(e, t, n, o) { return fE(e, t, n, o), _f; }
function bf(e, t, n) { return dE(e, t, n), bf; }
function gD(e) { let t = g(), n = w(), o = wi(); Bo(o + 1); let r = jd(n, o); if (e.dirty && Qp(t) === ((r.metadata.flags & 2) === 2)) {
    if (r.matches === null)
        e.reset([]);
    else {
        let i = hE(t, o);
        e.reset(i, vm), e.notifyOnChanges();
    }
    return !0;
} return !1; }
function mD() { return Fd(g(), wi()); }
function Af(e, t, n, o, r) { return gE(t, fE(e, n, o, r)), Af; }
function Rf(e, t, n, o) { return gE(e, dE(t, n, o)), Rf; }
function vD(e = 1) { Bo(wi() + e); }
function yD(e) { let t = _c(); return At(t, E + e); }
function Ui(e, t) { return e << 17 | t << 2; }
function En(e) { return e >> 17 & 32767; }
function VO(e) { return (e & 2) == 2; }
function BO(e, t) { return e & 131071 | t << 17; }
function Mu(e) { return e | 2; }
function to(e) { return (e & 131068) >> 2; }
function fl(e, t) { return e & -131069 | t << 2; }
function $O(e) { return (e & 1) === 1; }
function Nu(e) { return e | 1; }
function UO(e, t, n, o, r, i) { let s = i ? t.classBindings : t.styleBindings, a = En(s), c = to(s); e[o] = n; let l = !1, u; if (Array.isArray(n)) {
    let d = n;
    u = d[1], (u === null || mi(d, u) > 0) && (l = !0);
}
else
    u = n; if (r)
    if (c !== 0) {
        let f = En(e[a + 1]);
        e[o + 1] = Ui(f, a), f !== 0 && (e[f + 1] = fl(e[f + 1], o)), e[a + 1] = BO(e[a + 1], o);
    }
    else
        e[o + 1] = Ui(a, 0), a !== 0 && (e[a + 1] = fl(e[a + 1], o)), a = o;
else
    e[o + 1] = Ui(c, 0), a === 0 ? a = o : e[c + 1] = fl(e[c + 1], o), c = o; l && (e[o + 1] = Mu(e[o + 1])), xg(e, u, o, !0), xg(e, u, o, !1), GO(t, u, e, o, i), s = Ui(a, c), i ? t.classBindings = s : t.styleBindings = s; }
function GO(e, t, n, o, r) { let i = r ? e.residualClasses : e.residualStyles; i != null && typeof t == "string" && mi(i, t) >= 0 && (n[o + 1] = Nu(n[o + 1])); }
function xg(e, t, n, o) { let r = e[n + 1], i = t === null, s = o ? En(r) : to(r), a = !1; for (; s !== 0 && (a === !1 || i);) {
    let c = e[s], l = e[s + 1];
    WO(c, t) && (a = !0, e[s + 1] = o ? Nu(l) : Mu(l)), s = o ? En(l) : to(l);
} a && (e[n + 1] = o ? Mu(r) : Nu(r)); }
function WO(e, t) { return e === null || t == null || (Array.isArray(e) ? e[1] : e) === t ? !0 : Array.isArray(e) && typeof t == "string" ? mi(e, t) >= 0 : !1; }
var se = { textEnd: 0, key: 0, keyEnd: 0, value: 0, valueEnd: 0 };
function ED(e) { return e.substring(se.key, se.keyEnd); }
function zO(e) { return e.substring(se.value, se.valueEnd); }
function qO(e) { return CD(e), ID(e, no(e, 0, se.textEnd)); }
function ID(e, t) { let n = se.textEnd; return n === t ? -1 : (t = se.keyEnd = YO(e, se.key = t, n), no(e, t, n)); }
function QO(e) { return CD(e), DD(e, no(e, 0, se.textEnd)); }
function DD(e, t) { let n = se.textEnd, o = se.key = no(e, t, n); return n === o ? -1 : (o = se.keyEnd = ZO(e, o, n), o = kg(e, o, n, 58), o = se.value = no(e, o, n), o = se.valueEnd = KO(e, o, n), kg(e, o, n, 59)); }
function CD(e) { se.key = 0, se.keyEnd = 0, se.value = 0, se.valueEnd = 0, se.textEnd = e.length; }
function no(e, t, n) { for (; t < n && e.charCodeAt(t) <= 32;)
    t++; return t; }
function YO(e, t, n) { for (; t < n && e.charCodeAt(t) > 32;)
    t++; return t; }
function ZO(e, t, n) { let o; for (; t < n && ((o = e.charCodeAt(t)) === 45 || o === 95 || (o & -33) >= 65 && (o & -33) <= 90 || o >= 48 && o <= 57);)
    t++; return t; }
function kg(e, t, n, o) { return t = no(e, t, n), t < n && t++, t; }
function KO(e, t, n) { let o = -1, r = -1, i = -1, s = t, a = s; for (; s < n;) {
    let c = e.charCodeAt(s++);
    if (c === 59)
        return a;
    c === 34 || c === 39 ? a = s = Lg(e, c, s, n) : t === s - 4 && i === 85 && r === 82 && o === 76 && c === 40 ? a = s = Lg(e, 41, s, n) : c > 32 && (a = s), i = r, r = o, o = c & -33;
} return a; }
function Lg(e, t, n, o) { let r = -1, i = n; for (; i < o;) {
    let s = e.charCodeAt(i++);
    if (s == t && r !== 92)
        return i;
    s == 92 && r === 92 ? r = 0 : r = s;
} throw new Error; }
function Of(e, t, n) { return ND(e, t, n, !1), Of; }
function xf(e, t) { return ND(e, t, null, !0), xf; }
function TD(e) { wD(bD, JO, e, !1); }
function JO(e, t) { for (let n = QO(t); n >= 0; n = DD(t, n))
    bD(e, ED(t), zO(t)); }
function MD(e) { wD(ix, XO, e, !0); }
function XO(e, t) { for (let n = qO(t); n >= 0; n = ID(t, n))
    bo(e, ED(t), !0); }
function ND(e, t, n, o) { let r = g(), i = w(), s = ot(2); if (i.firstUpdatePass && _D(i, e, s, o), t !== j && U(r, s, t)) {
    let a = i.data[ne()];
    AD(i, a, r, r[C], e, r[s + 1] = ax(t, n), o, s);
} }
function wD(e, t, n, o) { let r = w(), i = ot(2); r.firstUpdatePass && _D(r, null, i, o); let s = g(); if (n !== j && U(s, i, n)) {
    let a = r.data[ne()];
    if (RD(a, o) && !SD(r, i)) {
        let c = o ? a.classesWithoutHost : a.stylesWithoutHost;
        c !== null && (n = li(c, n || "")), Iu(r, a, s, n, o);
    }
    else
        sx(r, a, s, s[C], s[i + 1], s[i + 1] = rx(e, t, n), o, i);
} }
function SD(e, t) { return t >= e.expandoStartIndex; }
function _D(e, t, n, o) { let r = e.data; if (r[n + 1] === null) {
    let i = r[ne()], s = SD(e, n);
    RD(i, o) && t === null && !s && (t = !1), t = ex(r, i, t, o), UO(r, i, t, n, s, o);
} }
function ex(e, t, n, o) { let r = Ni(e), i = o ? t.residualClasses : t.residualStyles; if (r === null)
    (o ? t.classBindings : t.styleBindings) === 0 && (n = pl(null, e, t, n, o), n = Mr(n, t.attrs, o), i = null);
else {
    let s = t.directiveStylingLast;
    if (s === -1 || e[s] !== r)
        if (n = pl(r, e, t, n, o), i === null) {
            let c = tx(e, t, o);
            c !== void 0 && Array.isArray(c) && (c = pl(null, e, t, c[1], o), c = Mr(c, t.attrs, o), nx(e, t, o, c));
        }
        else
            i = ox(e, t, o);
} return i !== void 0 && (o ? t.residualClasses = i : t.residualStyles = i), n; }
function tx(e, t, n) { let o = n ? t.classBindings : t.styleBindings; if (to(o) !== 0)
    return e[En(o)]; }
function nx(e, t, n, o) { let r = n ? t.classBindings : t.styleBindings; e[En(r)] = o; }
function ox(e, t, n) { let o, r = t.directiveEnd; for (let i = 1 + t.directiveStylingLast; i < r; i++) {
    let s = e[i].hostAttrs;
    o = Mr(o, s, n);
} return Mr(o, t.attrs, n); }
function pl(e, t, n, o, r) { let i = null, s = n.directiveEnd, a = n.directiveStylingLast; for (a === -1 ? a = n.directiveStart : a++; a < s && (i = t[a], o = Mr(o, i.hostAttrs, r), i !== e);)
    a++; return e !== null && (n.directiveStylingLast = a), o; }
function Mr(e, t, n) { let o = n ? 1 : 2, r = -1; if (t !== null)
    for (let i = 0; i < t.length; i++) {
        let s = t[i];
        typeof s == "number" ? r = s : r === o && (Array.isArray(e) || (e = e === void 0 ? [] : ["", e]), bo(e, s, n ? !0 : t[++i]));
    } return e === void 0 ? null : e; }
function rx(e, t, n) { if (n == null || n === "")
    return H; let o = [], r = st(n); if (Array.isArray(r))
    for (let i = 0; i < r.length; i++)
        e(o, r[i], !0);
else if (r instanceof Set)
    for (let i of r)
        e(o, i, !0);
else if (typeof r == "object")
    for (let i in r)
        Object.hasOwn(r, i) && e(o, i, r[i]);
else
    typeof r == "string" && t(o, r); return o; }
function bD(e, t, n) { bo(e, t, st(n)); }
function ix(e, t, n) { let o = String(t); o !== "" && !o.includes(" ") && bo(e, o, n); }
function sx(e, t, n, o, r, i, s, a) { r === j && (r = H); let c = 0, l = 0, u = 0 < r.length ? r[0] : null, d = 0 < i.length ? i[0] : null; for (; u !== null || d !== null;) {
    let f = c < r.length ? r[c + 1] : void 0, p = l < i.length ? i[l + 1] : void 0, h = null, v;
    u === d ? (c += 2, l += 2, f !== p && (h = d, v = p)) : d === null || u !== null && u < d ? (c += 2, h = u) : (l += 2, h = d, v = p), h !== null && AD(e, t, n, o, h, v, s, a), u = c < r.length ? r[c] : null, d = l < i.length ? i[l] : null;
} }
function AD(e, t, n, o, r, i, s, a) { if (!(t.type & 3))
    return; let c = e.data, l = c[a + 1], u = $O(l) ? Pg(c, t, n, r, to(l), s) : void 0; if (!bs(u)) {
    bs(i) || VO(l) && (i = Pg(c, null, n, r, a, s));
    let d = Kt(ne(), n);
    JS(o, s, d, r, i);
} }
function Pg(e, t, n, o, r, i) { let s = t === null, a; for (; r > 0;) {
    let c = e[r], l = Array.isArray(c), u = l ? c[1] : c, d = u === null, f = n[r + 1];
    f === j && (f = d ? H : void 0);
    let p = d ? gi(f, o) : u === o ? f : void 0;
    if (l && !bs(p) && (p = gi(c, o)), bs(p) && (a = p, s))
        return a;
    let h = e[r + 1];
    r = s ? En(h) : to(h);
} if (t !== null) {
    let c = i ? t.residualClasses : t.residualStyles;
    c != null && (a = gi(c, o));
} return a; }
function bs(e) { return e !== void 0; }
function ax(e, t) { return e == null || e === "" || (typeof t == "string" ? e = st(e) + t : typeof e == "object" && (e = ci(st(e)))), e; }
function RD(e, t) { return (e.flags & (t ? 8 : 16)) !== 0; }
function OD(e, t = "") { let n = g(), o = w(), r = e + E, i = o.firstCreatePass ? Vt(o, r, 1, t, null) : o.data[r], s = xD(o, n, i, t); n[r] = s, $o() && ta(o, n, s, i), Ue(i, !1); }
var xD = (e, t, n, o) => (Ge(!0), td(t[C], o));
function cx(e, t, n, o) { let r = !Gs(t, n); if (Ge(r), r)
    return td(t[C], o); let i = t[ce]; return zr(i, e, t, n); }
function kD() { xD = cx; }
function LD(e, t) { let n = !1, o = nt(); for (let i = 1; i < t.length; i += 2)
    n = U(e, o++, t[i]) || n; if (Rc(o), !n)
    return j; let r = t[0]; for (let i = 1; i < t.length; i += 2)
    r += S(t[i]) + (i + 1 !== t.length ? t[i + 1] : ""); return r; }
function PD(e, t, n, o = "") { return U(e, ge(), n) ? t + S(n) + o : j; }
function FD(e, t, n, o, r, i = "") { let s = nt(), a = hn(e, s, n, r); return ot(2), a ? t + S(n) + o + S(r) + i : j; }
function jD(e, t, n, o, r, i, s, a = "") { let c = nt(), l = Da(e, c, n, r, s); return ot(3), l ? t + S(n) + o + S(r) + i + S(s) + a : j; }
function HD(e, t, n, o, r, i, s, a, c, l = "") { let u = nt(), d = Fe(e, u, n, r, s, c); return ot(4), d ? t + S(n) + o + S(r) + i + S(s) + a + S(c) + l : j; }
function VD(e, t, n, o, r, i, s, a, c, l, u, d = "") { let f = nt(), p = Fe(e, f, n, r, s, c); return p = U(e, f + 4, u) || p, ot(5), p ? t + S(n) + o + S(r) + i + S(s) + a + S(c) + l + S(u) + d : j; }
function BD(e, t, n, o, r, i, s, a, c, l, u, d, f, p = "") { let h = nt(), v = Fe(e, h, n, r, s, c); return v = hn(e, h + 4, u, f) || v, ot(6), v ? t + S(n) + o + S(r) + i + S(s) + a + S(c) + l + S(u) + d + S(f) + p : j; }
function $D(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, v = "") { let y = nt(), I = Fe(e, y, n, r, s, c); return I = Da(e, y + 4, u, f, h) || I, ot(7), I ? t + S(n) + o + S(r) + i + S(s) + a + S(c) + l + S(u) + d + S(f) + p + S(h) + v : j; }
function UD(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, v, y, I = "") { let A = nt(), oe = Fe(e, A, n, r, s, c); return oe = Fe(e, A + 4, u, f, h, y) || oe, ot(8), oe ? t + S(n) + o + S(r) + i + S(s) + a + S(c) + l + S(u) + d + S(f) + p + S(h) + v + S(y) + I : j; }
function kf(e) { return xa("", e), kf; }
function xa(e, t, n) { let o = g(), r = PD(o, e, t, n); return r !== j && Nt(o, ne(), r), xa; }
function Lf(e, t, n, o, r) { let i = g(), s = FD(i, e, t, n, o, r); return s !== j && Nt(i, ne(), s), Lf; }
function Pf(e, t, n, o, r, i, s) { let a = g(), c = jD(a, e, t, n, o, r, i, s); return c !== j && Nt(a, ne(), c), Pf; }
function Ff(e, t, n, o, r, i, s, a, c) { let l = g(), u = HD(l, e, t, n, o, r, i, s, a, c); return u !== j && Nt(l, ne(), u), Ff; }
function jf(e, t, n, o, r, i, s, a, c, l, u) { let d = g(), f = VD(d, e, t, n, o, r, i, s, a, c, l, u); return f !== j && Nt(d, ne(), f), jf; }
function Hf(e, t, n, o, r, i, s, a, c, l, u, d, f) { let p = g(), h = BD(p, e, t, n, o, r, i, s, a, c, l, u, d, f); return h !== j && Nt(p, ne(), h), Hf; }
function Vf(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h) { let v = g(), y = $D(v, e, t, n, o, r, i, s, a, c, l, u, d, f, p, h); return y !== j && Nt(v, ne(), y), Vf; }
function Bf(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, v, y) { let I = g(), A = UD(I, e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, v, y); return A !== j && Nt(I, ne(), A), Bf; }
function $f(e) { let t = g(), n = LD(t, e); return n !== j && Nt(t, ne(), n), $f; }
function Nt(e, t, n) { let o = Kt(t, e); fv(e[C], o, n); }
function Uf(e, t, n) { Oi(t) && (t = t()); let o = g(), r = ge(); if (U(o, r, t)) {
    let i = w(), s = Ce();
    Cd(s, o, e, t, o[C], n);
} return Uf; }
function GD(e, t) { let n = Oi(e); return n && e.set(t), n; }
function Gf(e, t) { let n = g(), o = w(), r = N(); return Sf(o, n, n[C], r, e, t), Gf; }
var WD = {};
function Wf(e) { K("NgLet"); let t = w(), n = g(), o = e + E, r = Vt(t, o, 128, null, null); return Ue(r, !1), Po(t, n, o, WD), Wf; }
function zD(e) { let t = w(), n = g(), o = ne(); return Po(t, n, o, e), e; }
function qD(e) { let t = _c(), n = At(t, E + e); if (n === WD)
    throw new M(314, !1); return n; }
function QD(e, t) { let n = w(), o = g(), r = o[C], i = "data-ng-source-location"; for (let [s, a, c, l] of t) {
    let u = Jt(n, s + E), d = Kt(s + E, o);
    if (!d.hasAttribute(i)) {
        let f = `${e}@o:${a},l:${c},c:${l}`;
        r.setAttribute(d, i, f);
    }
} }
function YD(e) { return U(g(), ge(), e) ? S(e) : j; }
function ZD(e, t, n = "") { return PD(g(), e, t, n); }
function KD(e, t, n, o, r = "") { return FD(g(), e, t, n, o, r); }
function JD(e, t, n, o, r, i, s = "") { return jD(g(), e, t, n, o, r, i, s); }
function XD(e, t, n, o, r, i, s, a, c = "") { return HD(g(), e, t, n, o, r, i, s, a, c); }
function eC(e, t, n, o, r, i, s, a, c, l, u = "") { return VD(g(), e, t, n, o, r, i, s, a, c, l, u); }
function tC(e, t, n, o, r, i, s, a, c, l, u, d, f = "") { return BD(g(), e, t, n, o, r, i, s, a, c, l, u, d, f); }
function nC(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h = "") { return $D(g(), e, t, n, o, r, i, s, a, c, l, u, d, f, p, h); }
function oC(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, v, y = "") { return UD(g(), e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, v, y); }
function rC(e) { return LD(g(), e); }
function iC(e, t, n) { let o = pe() + e, r = g(); return r[o] === j ? qe(r, o, t(n, r)) : mo(r, o); }
function Fg(e, t, n) { let o = w(); o.firstCreatePass && sC(t, o.data, o.blueprint, Le(e), n); }
function sC(e, t, n, o, r) { if (e = W(e), Array.isArray(e))
    for (let i = 0; i < e.length; i++)
        sC(e[i], t, n, o, r);
else {
    let i = w(), s = g(), a = N(), c = vi(e) ? e : W(e.provide), l = Bp(e), u = a.providerIndexes & 1048575, d = a.directiveStart, f = a.providerIndexes >> 20;
    if (vi(e) || !e.multi) {
        let p = new un(l, r, vo, null), h = gl(c, t, r ? u : u + f, d);
        h === -1 ? (Cl(rs(a, s), i, c), hl(i, e, t.length), t.push(c), a.directiveStart++, a.directiveEnd++, r && (a.providerIndexes += 1048576), n.push(p), s.push(p)) : (n[h] = p, s[h] = p);
    }
    else {
        let p = gl(c, t, u + f, d), h = gl(c, t, u, u + f), v = p >= 0 && n[p], y = h >= 0 && n[h];
        if (r && !y || !r && !v) {
            Cl(rs(a, s), i, c);
            let I = dx(r ? ux : lx, n.length, r, o, l, e);
            !r && y && (n[h].providerFactory = I), hl(i, e, t.length, 0), t.push(c), a.directiveStart++, a.directiveEnd++, r && (a.providerIndexes += 1048576), n.push(I), s.push(I);
        }
        else {
            let I = aC(n[r ? h : p], l, !r && o);
            hl(i, e, p > -1 ? p : h, I);
        }
        !r && o && y && n[h].componentProviders++;
    }
} }
function hl(e, t, n, o) { let r = vi(t), i = Hp(t); if (r || i) {
    let c = (i ? W(t.useClass) : t).prototype.ngOnDestroy;
    if (c) {
        let l = e.destroyHooks || (e.destroyHooks = []);
        if (!r && t.multi) {
            let u = l.indexOf(n);
            u === -1 ? l.push(n, [o, c]) : l[u + 1].push(o, c);
        }
        else
            l.push(n, c);
    }
} }
function aC(e, t, n) { return n && e.componentProviders++, e.multi.push(t) - 1; }
function gl(e, t, n, o) { for (let r = n; r < o; r++)
    if (t[r] === e)
        return r; return -1; }
function lx(e, t, n, o, r) { return wu(this.multi, []); }
function ux(e, t, n, o, r) { let i = this.multi, s; if (this.providerFactory) {
    let a = this.providerFactory.componentProviders, c = sr(o, o[m], this.providerFactory.index, r);
    s = c.slice(0, a), wu(i, s);
    for (let l = a; l < c.length; l++)
        s.push(c[l]);
}
else
    s = [], wu(i, s); return s; }
function wu(e, t) { for (let n = 0; n < e.length; n++) {
    let o = e[n];
    t.push(o());
} return t; }
function dx(e, t, n, o, r, i) { let s = new un(e, n, vo, null); return s.multi = [], s.index = t, s.componentProviders = 0, aC(s, r, o && !n), s; }
function cC(e, t) { return n => { n.providersResolver = (o, r) => Fg(o, r ? r(e) : e, !1), t && (n.viewProvidersResolver = (o, r) => Fg(o, r ? r(t) : t, !0)); }; }
function lC(e) { return t => { e.length < 1 || (t.getExternalStyles = n => e.map(r => r + "?ngcomp" + (n ? "=" + encodeURIComponent(n) : "") + "&e=" + t.encapsulation)); }; }
function uC(e, t, n) { let o = e.\u0275cmp; o.directiveDefs = Cs(t, IE), o.pipeDefs = Cs(n, Ze); }
function dC(e, t) { return at(() => { let n = fi(e); n.declarations = Gi(t.declarations || H), n.imports = Gi(t.imports || H), n.exports = Gi(t.exports || H), t.bootstrap && (n.bootstrap = Gi(t.bootstrap)), Jn.registerNgModule(e, t); }); }
function Gi(e) { if (typeof e == "function")
    return e; let t = Ve(e); return t.some(ui) ? () => t.map(W).map(jg) : t.map(jg); }
function jg(e) { return Rd(e) ? e.ngModule : e; }
var zf = () => null, qf = () => { }, Su = !1, ka = new b("");
function fC() { return zf(); }
function Qf(e) { e.requested && e.activated && qf(e.injector, e.document); }
function pC() { if (Su || (Su = !0, Dw(), K("NgIncrementalHydration"), zf = () => new aw, qf = (e, t) => { let n = Sw(e), o = sb(t, t.body); xR(e, n, o), Ew(t, e); }), typeof ngServerMode > "u" || !ngServerMode) {
    let t = g()[O].get(ka, null, { optional: !0 });
    t !== null && !t.activated && (t.activated = !0, Qf(t));
} }
function fx() { Su = !1, zf = () => null, qf = () => { }; }
function hC(e, t) { let n = pe() + e, o = g(); return o[n] === j ? qe(o, n, t()) : mo(o, n); }
function gC(e, t, n) { return MC(g(), pe(), e, t, n); }
function mC(e, t, n, o) { return NC(g(), pe(), e, t, n, o); }
function vC(e, t, n, o, r) { return wC(g(), pe(), e, t, n, o, r); }
function yC(e, t, n, o, r, i, s) { return SC(g(), pe(), e, t, n, o, r, i); }
function EC(e, t, n, o, r, i, s) { let a = pe() + e, c = g(), l = Fe(c, a, n, o, r, i); return U(c, a + 4, s) || l ? qe(c, a + 5, t(n, o, r, i, s)) : mo(c, a + 5); }
function IC(e, t, n, o, r, i, s, a) { let c = pe() + e, l = g(), u = Fe(l, c, n, o, r, i); return hn(l, c + 4, s, a) || u ? qe(l, c + 6, t(n, o, r, i, s, a)) : mo(l, c + 6); }
function DC(e, t, n, o, r, i, s, a, c) { let l = pe() + e, u = g(), d = Fe(u, l, n, o, r, i); return Da(u, l + 4, s, a, c) || d ? qe(u, l + 7, t(n, o, r, i, s, a, c)) : mo(u, l + 7); }
function CC(e, t, n, o, r, i, s, a, c, l) { let u = pe() + e, d = g(), f = Fe(d, u, n, o, r, i); return Fe(d, u + 4, s, a, c, l) || f ? qe(d, u + 8, t(n, o, r, i, s, a, c, l)) : mo(d, u + 8); }
function TC(e, t, n) { return _C(g(), pe(), e, t, n); }
function Xr(e, t) { let n = e[t]; return n === j ? void 0 : n; }
function MC(e, t, n, o, r, i) { let s = t + n; return U(e, s, r) ? qe(e, s + 1, i ? o.call(i, r) : o(r)) : Xr(e, s + 1); }
function NC(e, t, n, o, r, i, s) { let a = t + n; return hn(e, a, r, i) ? qe(e, a + 2, s ? o.call(s, r, i) : o(r, i)) : Xr(e, a + 2); }
function wC(e, t, n, o, r, i, s, a) { let c = t + n; return Da(e, c, r, i, s) ? qe(e, c + 3, a ? o.call(a, r, i, s) : o(r, i, s)) : Xr(e, c + 3); }
function SC(e, t, n, o, r, i, s, a, c) { let l = t + n; return Fe(e, l, r, i, s, a) ? qe(e, l + 4, c ? o.call(c, r, i, s, a) : o(r, i, s, a)) : Xr(e, l + 4); }
function _C(e, t, n, o, r, i) { let s = t + n, a = !1; for (let c = 0; c < r.length; c++)
    U(e, s++, r[c]) && (a = !0); return a ? qe(e, s, o.apply(i, r)) : Xr(e, s); }
function bC(e, t) { let n = w(), o, r = e + E; n.firstCreatePass ? (o = px(t, n.pipeRegistry), n.data[r] = o, o.onDestroy && (n.destroyHooks ??= []).push(r, o.onDestroy)) : o = n.data[r]; let i = o.factory || (o.factory = hi(o.type, !0)), s, a = zt(vo); try {
    let c = os(!1), l = i();
    return os(c), Po(n, g(), r, l), l;
}
finally {
    zt(a);
} }
function px(e, t) { if (t)
    for (let n = t.length - 1; n >= 0; n--) {
        let o = t[n];
        if (e === o.name)
            return o;
    } }
function AC(e, t, n) { let o = e + E, r = g(), i = At(r, o); return ei(r, o) ? MC(r, pe(), t, i.transform, n, i) : i.transform(n); }
function RC(e, t, n, o) { let r = e + E, i = g(), s = At(i, r); return ei(i, r) ? NC(i, pe(), t, s.transform, n, o, s) : s.transform(n, o); }
function OC(e, t, n, o, r) { let i = e + E, s = g(), a = At(s, i); return ei(s, i) ? wC(s, pe(), t, a.transform, n, o, r, a) : a.transform(n, o, r); }
function xC(e, t, n, o, r, i) { let s = e + E, a = g(), c = At(a, s); return ei(a, s) ? SC(a, pe(), t, c.transform, n, o, r, i, c) : c.transform(n, o, r, i); }
function kC(e, t, n) { let o = e + E, r = g(), i = At(r, o); return ei(r, o) ? _C(r, pe(), t, i.transform, n, i) : i.transform.apply(i, n); }
function ei(e, t) { return e[m].data[t].pure; }
function LC(e, t) { return ha(e, t); }
function PC(e, t) { return () => { try {
    return Jn.getComponentDependencies(e, t).dependencies;
}
catch (n) {
    throw console.error(`Computing dependencies in local compilation mode for the component "${e.name}" failed with the exception:`, n), n;
} }; }
function FC(e, t) { let n = z(e); n !== null && (n.debugInfo = t); }
function jC(e, t, n) { let o = `./@ng/component?c=${e}&t=${encodeURIComponent(t)}`; return new URL(o, n).href; }
function HC(e, t, n, o, r = null, i = null) { let s = z(e); t.apply(null, [e, n, ...o]); let { newDef: a, oldDef: c } = hx(s, z(e)); if (e[wt] = a, c.tView) {
    let l = kN().values();
    for (let u of l)
        $e(u) && u[q] === null && Ji(r, i, a, c, u);
} }
function hx(e, t) { let n = G({}, e); return { newDef: Object.assign(e, t, { directiveDefs: n.directiveDefs, pipeDefs: n.pipeDefs, setInput: n.setInput, type: n.type }), oldDef: n }; }
function Ji(e, t, n, o, r) { let i = r[m]; if (i === o.tView) {
    mx(e, t, n, o, r);
    return;
} for (let s = E; s < i.bindingStartIndex; s++) {
    let a = r[s];
    if (Y(a)) {
        te(a[V]) && Ji(e, t, n, o, a[V]);
        for (let c = k; c < a.length; c++)
            Ji(e, t, n, o, a[c]);
    }
    else
        te(a) && Ji(e, t, n, o, a);
} }
function gx(e, t) { e.componentReplaced?.(t.id); }
function mx(e, t, n, o, r) { let i = r[F], s = r[V], a = r[q], c = r[X], l = r[O].get(B, null), u = () => { if (o.encapsulation === Pe.ShadowDom || o.encapsulation === Pe.ExperimentalIsolatedShadowDom) {
    let h = s.cloneNode(!1);
    s.replaceWith(h), s = h;
} let d = zv(n), f = Ur(a, d, i, Dd(n), s, c, null, null, null, null, null); vx(a, r, f, c.index), $r(r[m], r), hr(r); let p = r[Ke].rendererFactory; gx(p, o), f[C] = p.createRenderer(s, n), Fv(r[m], r), yx(c), da(d, f, i), sy(d, f, d.template, i); }; l === null ? Hg(e, t, u) : l.run(() => Hg(e, t, u)); }
function Hg(e, t, n) {
    try {
        n();
    }
    catch (o) {
        let r = o;
        if (t !== null && r.message) {
            let i = r.message + (r.stack ? `
` + r.stack : "");
            e?.hot?.send?.("angular:invalidate", { id: t, message: i, error: !0 });
        }
        throw o;
    }
}
function vx(e, t, n, o) { for (let r = E; r < e[m].bindingStartIndex; r++) {
    let i = e[r];
    if ((te(i) || Y(i)) && i[ue] === t) {
        i[ue] = n;
        break;
    }
} e[_t] === t && (e[_t] = n), e[Oo] === t && (e[Oo] = n), n[ue] = t[ue], t[ue] = null, e[o] = n; }
function yx(e) { if (e.projection !== null) {
    for (let t of e.projection)
        As(t) && (t.projectionNext = null, t.flags &= -3);
    e.projection = null;
} }
var he = { \u0275\u0275animateEnter: Xo, \u0275\u0275animateEnterListener: er, \u0275\u0275animateLeave: tr, \u0275\u0275animateLeaveListener: Ts, \u0275\u0275attribute: lf, \u0275\u0275defineComponent: EE, \u0275\u0275defineDirective: DE, \u0275\u0275defineInjectable: ae, \u0275\u0275defineInjector: Mo, \u0275\u0275defineNgModule: Wd, \u0275\u0275defineService: Et, \u0275\u0275definePipe: CE, \u0275\u0275directiveInject: vo, \u0275\u0275getInheritedFactory: am, \u0275\u0275inject: He, \u0275\u0275injectAttribute: Rs, \u0275\u0275invalidFactory: Jy, \u0275\u0275invalidFactoryDep: pi, \u0275\u0275templateRefExtractor: LC, \u0275\u0275resetView: wc, \u0275\u0275HostDirectivesFeature: xE, \u0275\u0275NgOnChangesFeature: Qg, \u0275\u0275ControlFeature: OE, \u0275\u0275ProvidersFeature: cC, \u0275\u0275InheritDefinitionFeature: Kd, \u0275\u0275ExternalStylesFeature: lC, \u0275\u0275nextContext: fD, \u0275\u0275namespaceHTML: jc, \u0275\u0275namespaceMathML: Fc, \u0275\u0275namespaceSVG: Pc, \u0275\u0275enableBindings: Cc, \u0275\u0275disableBindings: Tc, \u0275\u0275elementStart: Dr, \u0275\u0275elementEnd: _a, \u0275\u0275element: df, \u0275\u0275foreignComponent: $I, \u0275\u0275foreignContent: GI, \u0275\u0275foreignContentFn: WI, \u0275\u0275elementContainerStart: Ra, \u0275\u0275elementContainerEnd: Kr, \u0275\u0275domElement: ff, \u0275\u0275domElementStart: ba, \u0275\u0275domElementEnd: Aa, \u0275\u0275domElementContainer: mf, \u0275\u0275domElementContainerStart: Oa, \u0275\u0275domElementContainerEnd: gf, \u0275\u0275domTemplate: Xd, \u0275\u0275domListener: wf, \u0275\u0275elementContainer: hf, \u0275\u0275pureFunction0: hC, \u0275\u0275pureFunction1: gC, \u0275\u0275pureFunction2: mC, \u0275\u0275pureFunction3: vC, \u0275\u0275pureFunction4: yC, \u0275\u0275pureFunction5: EC, \u0275\u0275pureFunction6: IC, \u0275\u0275pureFunction7: DC, \u0275\u0275pureFunction8: CC, \u0275\u0275pureFunctionV: TC, \u0275\u0275getCurrentView: zI, \u0275\u0275restoreView: Nc, \u0275\u0275listener: Mf, \u0275\u0275projection: hD, \u0275\u0275syntheticHostProperty: Ef, \u0275\u0275syntheticHostListener: Nf, \u0275\u0275pipeBind1: AC, \u0275\u0275pipeBind2: RC, \u0275\u0275pipeBind3: OC, \u0275\u0275pipeBind4: xC, \u0275\u0275pipeBindV: kC, \u0275\u0275projectionDef: pD, \u0275\u0275domProperty: yf, \u0275\u0275ariaProperty: cf, \u0275\u0275property: uf, \u0275\u0275control: qy, \u0275\u0275controlCreate: Wy, \u0275\u0275pipe: bC, \u0275\u0275queryRefresh: gD, \u0275\u0275queryAdvance: vD, \u0275\u0275viewQuery: bf, \u0275\u0275viewQuerySignal: Rf, \u0275\u0275loadQuery: mD, \u0275\u0275contentQuery: _f, \u0275\u0275contentQuerySignal: Af, \u0275\u0275reference: yD, \u0275\u0275classMap: MD, \u0275\u0275styleMap: TD, \u0275\u0275styleProp: Of, \u0275\u0275classProp: xf, \u0275\u0275advance: qv, \u0275\u0275template: Jd, \u0275\u0275conditional: kI, \u0275\u0275conditionalCreate: xI, \u0275\u0275conditionalBranchCreate: Sa, \u0275\u0275defer: lI, \u0275\u0275deferWhen: uI, \u0275\u0275deferOnIdle: hI, \u0275\u0275deferOnImmediate: vI, \u0275\u0275deferOnTimer: II, \u0275\u0275deferOnHover: TI, \u0275\u0275deferOnInteraction: wI, \u0275\u0275deferOnViewport: bI, \u0275\u0275deferPrefetchWhen: dI, \u0275\u0275deferPrefetchOnIdle: gI, \u0275\u0275deferPrefetchOnImmediate: yI, \u0275\u0275deferPrefetchOnTimer: DI, \u0275\u0275deferPrefetchOnHover: MI, \u0275\u0275deferPrefetchOnInteraction: SI, \u0275\u0275deferPrefetchOnViewport: AI, \u0275\u0275deferHydrateWhen: fI, \u0275\u0275deferHydrateNever: pI, \u0275\u0275deferHydrateOnIdle: mI, \u0275\u0275deferHydrateOnImmediate: EI, \u0275\u0275deferHydrateOnTimer: CI, \u0275\u0275deferHydrateOnHover: NI, \u0275\u0275deferHydrateOnInteraction: _I, \u0275\u0275deferHydrateOnViewport: RI, \u0275\u0275deferEnableTimerScheduling: QE, \u0275\u0275enableIncrementalHydrationRuntime: pC, \u0275\u0275repeater: jI, \u0275\u0275repeaterCreate: FI, \u0275\u0275repeaterTrackByIndex: LI, \u0275\u0275repeaterTrackByIdentity: PI, \u0275\u0275componentInstance: OI, \u0275\u0275text: OD, \u0275\u0275textInterpolate: kf, \u0275\u0275textInterpolate1: xa, \u0275\u0275textInterpolate2: Lf, \u0275\u0275textInterpolate3: Pf, \u0275\u0275textInterpolate4: Ff, \u0275\u0275textInterpolate5: jf, \u0275\u0275textInterpolate6: Hf, \u0275\u0275textInterpolate7: Vf, \u0275\u0275textInterpolate8: Bf, \u0275\u0275textInterpolateV: $f, \u0275\u0275i18n: cD, \u0275\u0275i18nAttributes: lD, \u0275\u0275i18nExp: Tf, \u0275\u0275i18nStart: Df, \u0275\u0275i18nEnd: Cf, \u0275\u0275i18nApply: uD, \u0275\u0275i18nPostprocess: dD, \u0275\u0275resolveWindow: Cv, \u0275\u0275resolveDocument: Tv, \u0275\u0275resolveBody: cd, \u0275\u0275setComponentScope: uC, \u0275\u0275setNgModuleScope: dC, \u0275\u0275registerNgModuleType: Yd, \u0275\u0275getComponentDepsFactory: PC, \u0275setClassDebugInfo: FC, \u0275\u0275declareLet: Wf, \u0275\u0275storeLet: zD, \u0275\u0275arrowFunction: iC, \u0275\u0275readContextLet: qD, \u0275\u0275attachSourceLocations: QD, \u0275\u0275interpolate: YD, \u0275\u0275interpolate1: ZD, \u0275\u0275interpolate2: KD, \u0275\u0275interpolate3: JD, \u0275\u0275interpolate4: XD, \u0275\u0275interpolate5: eC, \u0275\u0275interpolate6: tC, \u0275\u0275interpolate7: nC, \u0275\u0275interpolate8: oC, \u0275\u0275interpolateV: rC, \u0275\u0275sanitizeHtml: od, \u0275\u0275sanitizeStyle: rd, \u0275\u0275sanitizeResourceUrl: qs, \u0275\u0275sanitizeScript: sd, \u0275\u0275validateAttribute: ad, \u0275\u0275sanitizeUrl: id, \u0275\u0275sanitizeUrlOrResourceUrl: Ev, \u0275\u0275trustConstantHtml: vv, \u0275\u0275trustConstantResourceUrl: yv, forwardRef: nc, resolveForwardRef: W, \u0275\u0275twoWayProperty: Uf, \u0275\u0275twoWayBindingSet: GD, \u0275\u0275twoWayListener: Gf, \u0275\u0275replaceMetadata: HC, \u0275\u0275getReplaceMetadataURL: jC }, Gn = null;
function VC(e) { Gn !== null && (e.defaultEncapsulation !== Gn.defaultEncapsulation || e.preserveWhitespaces !== Gn.preserveWhitespaces) || (Gn = e); }
function Ex() { return Gn; }
function Ix() { Gn = null; }
var ir = [];
function Dx(e, t) { ir.push({ moduleType: e, ngModule: t }); }
var ml = !1;
function BC() { if (!ml) {
    ml = !0;
    try {
        for (let e = ir.length - 1; e >= 0; e--) {
            let { moduleType: t, ngModule: n } = ir[e];
            n.declarations && n.declarations.every($C) && (ir.splice(e, 1), wx(t, n));
        }
    }
    finally {
        ml = !1;
    }
} }
function $C(e) { return Array.isArray(e) ? e.every($C) : !!W(e); }
function UC(e, t = {}) { GC(e, t), t.id !== void 0 && Yd(e, t.id), Dx(e, t); }
function GC(e, t, n = !1) { let o = Ve(t.declarations || H), r = null; Object.defineProperty(e, sc, { configurable: !0, get: () => (r === null && (r = Q({ usage: 0, kind: "NgModule", type: e }).compileNgModule(he, `ng:///${e.name}/\u0275mod.js`, { type: e, bootstrap: Ve(t.bootstrap || H).map(W), declarations: o.map(W), imports: Ve(t.imports || H).map(W).map(Vg), exports: Ve(t.exports || H).map(W).map(Vg), schemas: t.schemas ? Ve(t.schemas) : null, id: t.id || null }), r.schemas || (r.schemas = [])), r) }); let i = null; Object.defineProperty(e, Ye, { get: () => { if (i === null) {
        let a = Q({ usage: 0, kind: "NgModule", type: e });
        i = a.compileFactory(he, `ng:///${e.name}/\u0275fac.js`, { name: e.name, type: e, deps: _r(e), target: a.FactoryTarget.NgModule, typeArgumentCount: 0 });
    } return i; }, configurable: !1 }); let s = null; Object.defineProperty(e, ic, { get: () => { if (s === null) {
        let a = { name: e.name, type: e, providers: t.providers || H, imports: [(t.imports || H).map(W), (t.exports || H).map(W)] };
        s = Q({ usage: 0, kind: "NgModule", type: e }).compileInjector(he, `ng:///${e.name}/\u0275inj.js`, a);
    } return s; }, configurable: !1 }); }
function Cx(e, t) { let n = `Unexpected "${Te(e)}" found in the "declarations" array of the`, o = `"${Te(e)}" is marked as standalone and can't be declared in any NgModule - did you intend to import it instead (by adding it to the "imports" array)?`; return `${n} ${t}, ${o}`; }
var Tx = new WeakMap, Mx = new WeakMap;
function Nx() { Tx = new WeakMap, Mx = new WeakMap, ir.length = 0, IA.clear(); }
function wx(e, t) { let n = Ve(t.declarations || H), o = Zf(e); n.forEach(r => { if (r = W(r), Object.hasOwn(r, wt)) {
    let s = z(r);
    Yf(s, o);
}
else
    !Object.hasOwn(r, _n) && !Object.hasOwn(r, di) && (r.ngSelectorScope = e); }); }
function Yf(e, t) { e.directiveDefs = () => Array.from(t.compilation.directives).map(n => Object.hasOwn(n, wt) ? z(n) : xe(n)).filter(n => !!n), e.pipeDefs = () => Array.from(t.compilation.pipes).map(n => Ze(n)), e.schemas = t.schemas, e.tView = null; }
function Zf(e) { if (rn(e)) {
    let t = Jn.getNgModuleScope(e), n = fi(e);
    return G({ schemas: n.schemas || null }, t);
}
else if (wo(e)) {
    if ((z(e) || xe(e)) !== null)
        return { schemas: null, compilation: { directives: new Set, pipes: new Set }, exported: { directives: new Set([e]), pipes: new Set } };
    if (Ze(e) !== null)
        return { schemas: null, compilation: { directives: new Set, pipes: new Set }, exported: { directives: new Set, pipes: new Set([e]) } };
} throw new Error(`${e.name} does not have a module def (\u0275mod property)`); }
function Vg(e) { return Rd(e) ? e.ngModule : e; }
var vl = 0;
function WC(e, t) {
    let n = null;
    TA(e, t), qC(e, t), Object.defineProperty(e, wt, { get: () => {
            if (n === null) {
                let o = Q({ usage: 0, kind: "component", type: e });
                if (t.foreignImports !== void 0)
                    throw new Error(`Foreign components are not supported in JIT mode. Component '${e.name}' cannot specify 'foreignImports'.`);
                if (bE(t)) {
                    let u = [`Component '${e.name}' is not resolved:`];
                    throw t.templateUrl && u.push(` - templateUrl: ${t.templateUrl}`), t.styleUrls && t.styleUrls.length && u.push(` - styleUrls: ${JSON.stringify(t.styleUrls)}`), t.styleUrl && u.push(` - styleUrl: ${t.styleUrl}`), u.push("Did you run and wait for 'resolveComponentResources()'?"), new Error(u.join(`
`));
                }
                let r = Ex(), i = t.preserveWhitespaces;
                i === void 0 && (r !== null && r.preserveWhitespaces !== void 0 ? i = r.preserveWhitespaces : i = !1);
                let s = t.encapsulation;
                s === void 0 && (r !== null && r.defaultEncapsulation !== void 0 ? s = r.defaultEncapsulation : s = Pe.Emulated);
                let a = t.templateUrl || `ng:///${e.name}/template.html`, c = QC(e, t), l = Re(G({}, c), { typeSourceSpan: o.createParseSourceSpan("Component", e.name, a), template: t.template || "", preserveWhitespaces: i, styles: typeof t.styles == "string" ? [t.styles] : t.styles || H, animations: t.animations, declarations: [], changeDetection: t.changeDetection, encapsulation: s, viewProviders: t.viewProviders || null, hasDirectiveDependencies: !c.isStandalone || t.imports != null && t.imports.length > 0 });
                vl++;
                try {
                    if (l.usesInheritance && YC(e), n = o.compileComponent(he, a, l), l.isStandalone) {
                        let u = Ve(t.imports || H), { directiveDefs: d, pipeDefs: f } = Sx(e, u);
                        n.directiveDefs = d, n.pipeDefs = f, n.dependencies = () => u.map(W);
                    }
                }
                finally {
                    vl--;
                }
                if (vl === 0 && BC(), _x(e)) {
                    let u = Zf(e.ngSelectorScope);
                    Yf(n, u);
                }
                if (t.schemas)
                    if (l.isStandalone)
                        n.schemas = t.schemas;
                    else
                        throw new Error(`The 'schemas' was specified for the ${Te(e)} but is only valid on a component that is standalone.`);
                else
                    l.isStandalone && (n.schemas = []);
            }
            return n;
        }, set: o => { n = o; }, configurable: !1 });
}
function Sx(e, t) { return { directiveDefs: () => Zo(e) ? [...Jn.getStandaloneComponentScope(e, t).compilation.directives].map(i => z(i) || xe(i)).filter(i => i !== null) : [], pipeDefs: () => Zo(e) ? [...Jn.getStandaloneComponentScope(e, t).compilation.pipes].map(i => Ze(i)).filter(i => i !== null) : [] }; }
function _x(e) { return e.ngSelectorScope !== void 0; }
function Kf(e, t) { let n = null; qC(e, t || {}), Object.defineProperty(e, _n, { get: () => { if (n === null) {
        let o = zC(e, t || {});
        n = Q({ usage: 0, kind: "directive", type: e }).compileDirective(he, o.sourceMapUrl, o.metadata);
    } return n; }, configurable: !1 }); }
function zC(e, t) { let n = e && e.name, o = `ng:///${n}/\u0275dir.js`, r = Q({ usage: 0, kind: "directive", type: e }), i = QC(e, t); return i.typeSourceSpan = r.createParseSourceSpan("Directive", n, o), i.usesInheritance && YC(e), { metadata: i, sourceMapUrl: o }; }
function qC(e, t) { let n = null; Object.defineProperty(e, Ye, { get: () => { if (n === null) {
        let o = zC(e, t), r = Q({ usage: 0, kind: "directive", type: e });
        n = r.compileFactory(he, `ng:///${e.name}/\u0275fac.js`, { name: o.metadata.name, type: o.metadata.type, typeArgumentCount: 0, deps: _r(e), target: r.FactoryTarget.Directive });
    } return n; }, configurable: !1 }); }
function bx(e) { return Object.getPrototypeOf(e.prototype) === Object.prototype; }
function QC(e, t) { let n = ku(), o = n.ownPropMetadata(e); return { name: e.name, legacyOptionalChaining: !1, type: e, selector: t.selector !== void 0 ? t.selector : null, host: t.host || lt, propMetadata: o, inputs: t.inputs || H, outputs: t.outputs || H, queries: Bg(e, o, ZC), lifecycle: { usesOnChanges: n.hasLifecycleHook(e, "ngOnChanges") }, controlCreate: n.hasLifecycleHook(e, "\u0275ngControlCreate") ? { passThroughInput: null } : null, typeSourceSpan: null, usesInheritance: !bx(e), exportAs: Ox(t.exportAs), providers: t.providers || null, viewQueries: Bg(e, o, KC), isStandalone: t.standalone === void 0 ? !0 : !!t.standalone, isSignal: !!t.signals, hostDirectives: t.hostDirectives?.map(r => typeof r == "function" ? { directive: r } : r) || null }; }
function YC(e) { let t = Object.prototype, n = Object.getPrototypeOf(e.prototype).constructor; for (; n && n !== t;)
    !xe(n) && !z(n) && kx(n) && Kf(n, null), n = Object.getPrototypeOf(n); }
function Ax(e) { return typeof e == "string" ? XC(e) : W(e); }
function Rx(e, t) { return { propertyName: e, predicate: Ax(t.selector), descendants: t.descendants, first: t.first, read: t.read ? t.read : null, static: !!t.static, emitDistinctChangesOnly: !!t.emitDistinctChangesOnly, isSignal: !!t.isSignal }; }
function Bg(e, t, n) { let o = [], r = []; for (let i in t)
    if (Object.hasOwn(t, i)) {
        let s = t[i];
        s.forEach(a => { if (n(a)) {
            if (!a.selector)
                throw new Error(`Can't construct a query for the property "${i}" of "${Te(e)}" since the query selector wasn't defined.`);
            if (s.some(JC))
                throw new Error("Cannot combine @Input decorators with query decorators");
            let c = Rx(i, a);
            c.isSignal ? o.push(c) : r.push(c);
        } });
    } return [...o, ...r]; }
function Ox(e) { return e === void 0 ? null : XC(e); }
function ZC(e) { let t = e.ngMetadataName; return t === "ContentChild" || t === "ContentChildren"; }
function KC(e) { let t = e.ngMetadataName; return t === "ViewChild" || t === "ViewChildren"; }
function JC(e) { return e.ngMetadataName === "Input"; }
function XC(e) { return e.split(",").map(t => t.trim()); }
var xx = ["ngOnChanges", "ngOnInit", "ngOnDestroy", "ngDoCheck", "ngAfterViewInit", "ngAfterViewChecked", "ngAfterContentInit", "ngAfterContentChecked"];
function kx(e) { let t = ku(); if (xx.some(o => t.hasLifecycleHook(e, o)))
    return !0; let n = t.propMetadata(e); for (let o in n) {
    let r = n[o];
    for (let i = 0; i < r.length; i++) {
        let s = r[i], a = s.ngMetadataName;
        if (JC(s) || ZC(s) || KC(s) || a === "Output" || a === "HostBinding" || a === "HostListener")
            return !0;
    }
} return !1; }
function eT(e, t) { let n = null, o = null; Object.defineProperty(e, Ye, { get: () => { if (o === null) {
        let r = $g(e, t), i = Q({ usage: 0, kind: "pipe", type: r.type });
        o = i.compileFactory(he, `ng:///${r.name}/\u0275fac.js`, { name: r.name, type: r.type, typeArgumentCount: 0, deps: _r(e), target: i.FactoryTarget.Pipe });
    } return o; }, configurable: !1 }), Object.defineProperty(e, di, { get: () => { if (n === null) {
        let r = $g(e, t);
        n = Q({ usage: 0, kind: "pipe", type: r.type }).compilePipe(he, `ng:///${r.name}/\u0275pipe.js`, r);
    } return n; }, configurable: !1 }); }
function $g(e, t) { return { type: e, name: e.name, pipeName: t.name, pure: t.pure !== void 0 ? t.pure : !0, isStandalone: t.standalone === void 0 ? !0 : !!t.standalone }; }
var tT = oo("Directive", (e = {}) => e, void 0, void 0, (e, t) => Kf(e, t)), Lx = oo("Component", (e = {}) => G({ changeDetection: xs.Eager }, e), tT, void 0, (e, t) => WC(e, t)), Px = oo("Pipe", e => G({ pure: !0 }, e), void 0, void 0, (e, t) => eT(e, t)), Fx = yt("Input", e => e ? typeof e == "string" ? { alias: e } : e : {}), jx = yt("Output", e => ({ alias: e })), Hx = yt("HostBinding", e => ({ hostPropertyName: e })), Vx = yt("HostListener", (e, t) => ({ eventName: e, args: t })), Bx = oo("NgModule", e => e, void 0, void 0, (e, t) => UC(e, t));
var nT = (() => { class e {
    applicationErrorHandler = D(en);
    appRef = D(be);
    taskService = D(Rt);
    ngZone = D(B);
    zonelessEnabled = D(Fn);
    tracing = D(Mn, { optional: !0 });
    zoneIsDefined = typeof Zone < "u" && !!Zone.root.run;
    schedulerTickApplyArgs = [{ data: { __scheduler_tick__: !0 } }];
    subscriptions = new UM;
    angularZoneId = this.zoneIsDefined ? this.ngZone._inner?.get(Hc) : null;
    scheduleInRootZone = !this.zonelessEnabled && this.zoneIsDefined && (D(Ri, { optional: !0 }) ?? !1);
    cancelScheduledCallback = null;
    useMicrotaskScheduler = !1;
    runningTick = !1;
    pendingRenderTaskId = null;
    constructor() { this.subscriptions.add(this.appRef.afterTick.subscribe(() => { let n = this.taskService.add(); if (!this.runningTick && (this.cleanup(), !this.zonelessEnabled || this.appRef.includeAllTestViews)) {
        this.taskService.remove(n);
        return;
    } this.switchToMicrotaskScheduler(), this.taskService.remove(n); })), this.subscriptions.add(this.ngZone.onUnstable.subscribe(() => { this.runningTick || this.cleanup(); })); }
    switchToMicrotaskScheduler() { this.ngZone.runOutsideAngular(() => { let n = this.taskService.add(); this.useMicrotaskScheduler = !0, queueMicrotask(() => { this.useMicrotaskScheduler = !1, this.taskService.remove(n); }); }); }
    notify(n) { if (!this.zonelessEnabled && n === 5)
        return; switch (n) {
        case 0:
        case 2: {
            this.appRef.dirtyFlags |= 2;
            break;
        }
        case 3:
        case 4:
        case 5:
        case 1: {
            this.appRef.dirtyFlags |= 4;
            break;
        }
        case 6: {
            this.appRef.dirtyFlags |= 2;
            break;
        }
        case 12: {
            this.appRef.dirtyFlags |= 16;
            break;
        }
        case 13: {
            this.appRef.dirtyFlags |= 2;
            break;
        }
        case 11: break;
        default: this.appRef.dirtyFlags |= 8;
    } if (this.appRef.tracingSnapshot = this.tracing?.snapshot(this.appRef.tracingSnapshot) ?? null, !this.shouldScheduleTick())
        return; let o = this.useMicrotaskScheduler ? hh : ph; this.pendingRenderTaskId = this.taskService.add(), this.scheduleInRootZone ? this.cancelScheduledCallback = Zone.root.run(() => o(() => this.tick())) : this.cancelScheduledCallback = this.ngZone.runOutsideAngular(() => o(() => this.tick())); }
    shouldScheduleTick() { return !(this.appRef.destroyed || this.pendingRenderTaskId !== null || this.runningTick || this.appRef._runningTick || !this.zonelessEnabled && this.zoneIsDefined && Zone.current.get(Hc + this.angularZoneId)); }
    tick() { if (this.runningTick || this.appRef.destroyed)
        return; if (this.appRef.dirtyFlags === 0) {
        this.cleanup();
        return;
    } !this.zonelessEnabled && this.appRef.dirtyFlags & 7 && (this.appRef.dirtyFlags |= 1); let n = this.taskService.add(); try {
        this.ngZone.run(() => { this.runningTick = !0, this.appRef._tick(); }, void 0, this.schedulerTickApplyArgs);
    }
    catch (o) {
        this.applicationErrorHandler(o);
    }
    finally {
        this.taskService.remove(n), this.cleanup();
    } }
    ngOnDestroy() { this.subscriptions.unsubscribe(), this.cleanup(); }
    cleanup() { if (this.runningTick = !1, this.cancelScheduledCallback?.(), this.cancelScheduledCallback = null, this.pendingRenderTaskId !== null) {
        let n = this.pendingRenderTaskId;
        this.pendingRenderTaskId = null, this.taskService.remove(n);
    } }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = Et({ token: e, factory: e.\u0275fac });
} return e; })();
function $x() { return K("NgZoneless"), Be([...La(), []]); }
function La() { return [{ provide: Ot, useExisting: nT }, { provide: B, useClass: Vc }, { provide: Fn, useValue: !0 }]; }
var Ux = (() => { class e {
    compileModuleSync(n) { return new eo(n); }
    compileModuleAsync(n) { return Promise.resolve(this.compileModuleSync(n)); }
    clearCache() { }
    clearCacheFor(n) { }
    getModuleId(n) { }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = Et({ token: e, factory: e.\u0275fac });
} return e; })(), oT = new b(""), _u = class {
};
function Gx() { return typeof ngI18nClosureMode < "u" && ngI18nClosureMode && typeof goog < "u" && goog.LOCALE !== "en" ? goog.LOCALE : typeof $localize < "u" && $localize.locale || Jr; }
var Jf = new b("", { factory: () => D(Jf, { optional: !0, skipSelf: !0 }) || Gx() }), Wx = new b("", { factory: () => sO }), zx = new b(""), qx = new b(""), rT = (function (e) { return e[e.Error = 0] = "Error", e[e.Warning = 1] = "Warning", e[e.Ignore = 2] = "Ignore", e; })(rT || {});
function Xi(e, t) { let n = e[m]; for (let o = E; o < n.bindingStartIndex; o++)
    if (Y(e[o])) {
        let r = e[o];
        if (!(o === n.bindingStartIndex - 1)) {
            let s = n.data[o], a = le(n, s);
            if ($E(a)) {
                t.push({ lContainer: r, lView: e, tNode: s, tDetails: a });
                continue;
            }
        }
        te(r[V]) && Xi(r[V], t);
        for (let s = k; s < r.length; s++)
            Xi(r[s], t);
    }
    else
        te(e[o]) && Xi(e[o], t); }
var bu = class {
    name;
    callback;
    constructor(t, n) { this.name = t, this.callback = n; }
};
function Qx(e) { return e.map(t => t.nativeElement); }
var Nr = class {
    nativeNode;
    constructor(t) { this.nativeNode = t; }
    get parent() { let t = this.nativeNode.parentNode; return t ? new In(t) : null; }
    get injector() { return Fu(this.nativeNode); }
    get componentInstance() { let t = this.nativeNode; return t && (Ph(t) || WN(t)); }
    get context() { return Ph(this.nativeNode) || GN(this.nativeNode); }
    get listeners() { return ZN(this.nativeNode).filter(t => t.type === "dom"); }
    get references() { return QN(this.nativeNode); }
    get providerTokens() { return zN(this.nativeNode); }
}, In = class extends Nr {
    constructor(t) { super(t); }
    get nativeElement() { return this.nativeNode.nodeType == Node.ELEMENT_NODE ? this.nativeNode : null; }
    get name() { let t = Ee(this.nativeNode), n = t ? t.lView : null; return n !== null ? n[m].data[t.nodeIndex].value : this.nativeNode.nodeName; }
    get properties() { let t = Ee(this.nativeNode), n = t ? t.lView : null; if (n === null)
        return {}; let o = n[m].data, r = o[t.nodeIndex], i = {}; return Yx(this.nativeElement, i), Kx(i, r, n, o), i; }
    get attributes() { let t = {}, n = this.nativeElement; if (!n)
        return t; let o = Ee(n), r = o ? o.lView : null; if (r === null)
        return {}; let i = r[m].data[o.nodeIndex].attrs, s = []; if (i) {
        let a = 0;
        for (; a < i.length;) {
            let c = i[a];
            if (typeof c != "string")
                break;
            let l = i[a + 1];
            t[c] = l, s.push(c.toLowerCase()), a += 2;
        }
    } for (let a of n.attributes)
        s.includes(a.name) || (t[a.name] = a.value); return t; }
    get styles() { return this.nativeElement?.style ?? {}; }
    get classes() { let t = {}, o = this.nativeElement.className; return (typeof o != "string" ? o.baseVal.split(" ") : o.split(" ")).forEach(i => t[i] = !0), t; }
    get childNodes() { let t = this.nativeNode.childNodes, n = []; for (let o = 0; o < t.length; o++) {
        let r = t[o];
        n.push(wr(r));
    } return n; }
    get children() { let t = this.nativeElement; if (!t)
        return []; let n = t.children, o = []; for (let r = 0; r < n.length; r++) {
        let i = n[r];
        o.push(wr(i));
    } return o; }
    query(t) { return this.queryAll(t)[0] || null; }
    queryAll(t) { let n = []; return Ug(this, t, n, !0), n; }
    queryAllNodes(t) { let n = []; return Ug(this, t, n, !1), n; }
    triggerEventHandler(t, n) { let o = this.nativeNode, r = []; this.listeners.forEach(i => { if (i.name === t) {
        let s = i.callback;
        s.call(o, n), r.push(s);
    } }), typeof o.eventListeners == "function" && o.eventListeners(t).forEach(i => { if (i.toString().indexOf("__ngUnwrap__") !== -1) {
        let s = i("__ngUnwrap__");
        return r.indexOf(s) === -1 && s.call(o, n);
    } }); }
};
function Yx(e, t) { if (e) {
    let n = Object.getPrototypeOf(e), o = Node.prototype;
    for (; n !== null && n !== o;) {
        let r = Object.getOwnPropertyDescriptors(n);
        for (let i in r)
            if (!i.startsWith("__") && !i.startsWith("on")) {
                let s = e[i];
                Zx(s) && (t[i] = s);
            }
        n = Object.getPrototypeOf(n);
    }
} }
function Zx(e) { return typeof e == "string" || typeof e == "boolean" || typeof e == "number" || e === null; }
function Ug(e, t, n, o) { let r = Ee(e.nativeNode), i = r ? r.lView : null; if (i !== null) {
    let s = i[m].data[r.nodeIndex];
    sn(s, i, t, n, o, e.nativeNode);
}
else
    Xf(e.nativeNode, t, n, o); }
function sn(e, t, n, o, r, i) { let s = qp(e, t); if (e.type & 11) {
    if (yl(s, n, o, r, i), ve(e)) {
        let c = fe(e.index, t);
        c && c[m].firstChild && sn(c[m].firstChild, c, n, o, r, i);
    }
    else
        e.child && sn(e.child, t, n, o, r, i), s && Xf(s, n, o, r);
    let a = t[e.index];
    Y(a) && Gg(a, n, o, r, i);
}
else if (e.type & 4) {
    let a = t[e.index];
    yl(a[Xe], n, o, r, i), Gg(a, n, o, r, i);
}
else if (e.type & 16) {
    let a = t[ee], l = a[X].projection[e.projection];
    if (Array.isArray(l))
        for (let u of l)
            yl(u, n, o, r, i);
    else if (l) {
        let u = a[q], d = u[m].data[l.index];
        sn(d, u, n, o, r, i);
    }
}
else
    e.child && sn(e.child, t, n, o, r, i); if (i !== s) {
    let a = e.flags & 2 ? e.projectionNext : e.next;
    a && sn(a, t, n, o, r, i);
} }
function Gg(e, t, n, o, r) { for (let i = k; i < e.length; i++) {
    let s = e[i], a = s[m].firstChild;
    a && sn(a, s, t, n, o, r);
} }
function yl(e, t, n, o, r) { if (r !== e) {
    let i = wr(e);
    if (!i)
        return;
    (o && i instanceof In && t(i) && n.indexOf(i) === -1 || !o && t(i) && n.indexOf(i) === -1) && n.push(i);
} }
function Xf(e, t, n, o) { let r = e.childNodes, i = r.length; for (let s = 0; s < i; s++) {
    let a = r[s], c = wr(a);
    c && ((o && c instanceof In && t(c) && n.indexOf(c) === -1 || !o && t(c) && n.indexOf(c) === -1) && n.push(c), Xf(a, t, n, o));
} }
function Kx(e, t, n, o) { let r = t.propertyBindings; if (r !== null)
    for (let i = 0; i < r.length; i++) {
        let s = r[i], c = o[s].split(dS), l = c[0];
        if (c.length > 1) {
            let u = c[1];
            for (let d = 1; d < c.length - 1; d++)
                u += S(n[s + d - 1]) + c[d + 1];
            e[l] = u;
        }
        else
            e[l] = n[s];
    } }
var El = "__ng_debug__";
function wr(e) { return e instanceof Node ? (Object.hasOwn(e, El) || (e[El] = e.nodeType == Node.ELEMENT_NODE ? new In(e) : new Nr(e)), e[El]) : null; }
import { Subscription as Rk } from "rxjs";
var rp = { JSACTION: "__jsaction", OWNER: "__owner" }, cT = {};
function Jx(e) { return e[rp.JSACTION]; }
function iT(e, t) { e[rp.JSACTION] = t; }
function Xx(e) { return cT[e]; }
function ek(e, t) { cT[e] = t; }
var T = { CLICK: "click", CLICKMOD: "clickmod", DBLCLICK: "dblclick", FOCUS: "focus", FOCUSIN: "focusin", BLUR: "blur", FOCUSOUT: "focusout", SUBMIT: "submit", KEYDOWN: "keydown", KEYPRESS: "keypress", KEYUP: "keyup", MOUSEOVER: "mouseover", MOUSEOUT: "mouseout", MOUSEENTER: "mouseenter", MOUSELEAVE: "mouseleave", POINTEROVER: "pointerover", POINTEROUT: "pointerout", POINTERENTER: "pointerenter", POINTERLEAVE: "pointerleave", ERROR: "error", LOAD: "load", TOUCHSTART: "touchstart", TOUCHEND: "touchend", TOUCHMOVE: "touchmove", TOGGLE: "toggle" }, tk = [T.MOUSEENTER, T.MOUSELEAVE, "pointerenter", "pointerleave"], nk = [T.CLICK, T.DBLCLICK, T.FOCUSIN, T.FOCUSOUT, T.KEYDOWN, T.KEYUP, T.KEYPRESS, T.MOUSEOVER, T.MOUSEOUT, T.SUBMIT, T.TOUCHSTART, T.TOUCHEND, T.TOUCHMOVE, "touchcancel", "auxclick", "change", "compositionstart", "compositionupdate", "compositionend", "beforeinput", "input", "select", "copy", "cut", "paste", "mousedown", "mouseup", "wheel", "contextmenu", "dragover", "dragenter", "dragleave", "drop", "dragstart", "dragend", "pointerdown", "pointermove", "pointerup", "pointercancel", "pointerover", "pointerout", "gotpointercapture", "lostpointercapture", "ended", "loadedmetadata", "pagehide", "pageshow", "visibilitychange", "beforematch"], lT = [T.FOCUS, T.BLUR, T.ERROR, T.LOAD, T.TOGGLE], Ba = e => lT.indexOf(e) >= 0, ok = nk.concat(lT), uT = e => ok.indexOf(e) >= 0;
function rk(e) { return e === T.MOUSEENTER ? T.MOUSEOVER : e === T.MOUSELEAVE ? T.MOUSEOUT : e === T.POINTERENTER ? T.POINTEROVER : e === T.POINTERLEAVE ? T.POINTEROUT : e; }
function ik(e, t, n, o) { let r = !1; Ba(t) && (r = !0); let i = typeof o == "boolean" ? { capture: r, passive: o } : r; return e.addEventListener(t, n, i), { eventType: t, handler: n, capture: r, passive: o }; }
function sk(e, t) { if (e.removeEventListener) {
    let n = typeof t.passive == "boolean" ? { capture: t.capture } : t.capture;
    e.removeEventListener(t.eventType, t.handler, n);
}
else
    e.detachEvent && e.detachEvent(`on${t.eventType}`, t.handler); }
function ak(e) { e.preventDefault ? e.preventDefault() : e.returnValue = !1; }
var sT = typeof navigator < "u" && /Macintosh/.test(navigator.userAgent);
function ck(e) { return e.which === 2 || e.which == null && e.button === 4; }
function lk(e) { return sT && e.metaKey || !sT && e.ctrlKey || ck(e) || e.shiftKey; }
function uk(e, t, n) { let o = e.relatedTarget; return (e.type === T.MOUSEOVER && t === T.MOUSEENTER || e.type === T.MOUSEOUT && t === T.MOUSELEAVE || e.type === T.POINTEROVER && t === T.POINTERENTER || e.type === T.POINTEROUT && t === T.POINTERLEAVE) && (!o || o !== n && !n.contains(o)); }
function dk(e, t) { let n = {}; for (let o in e) {
    if (o === "srcElement" || o === "target")
        continue;
    let r = o, i = e[r];
    typeof i != "function" && (n[r] = i);
} return e.type === T.MOUSEOVER ? n.type = T.MOUSEENTER : e.type === T.MOUSEOUT ? n.type = T.MOUSELEAVE : e.type === T.POINTEROVER ? n.type = T.POINTERENTER : n.type = T.POINTERLEAVE, n.target = n.srcElement = t, n.bubbles = !1, n._originalEvent = e, n; }
var Ha = class {
    element;
    handlerInfos = [];
    constructor(t) { this.element = t; }
    addEventListener(t, n, o) { this.handlerInfos.push(ik(this.element, t, n(this.element), o)); }
    cleanUp() { for (let t = 0; t < this.handlerInfos.length; t++)
        sk(this.element, this.handlerInfos[t]); this.handlerInfos = []; }
}, fk = { EVENT_ACTION_SEPARATOR: ":" };
function $t(e) { return e.eventType; }
function ip(e, t) { e.eventType = t; }
function Fa(e) { return e.event; }
function dT(e, t) { e.event = t; }
function fT(e) { return e.targetElement; }
function pT(e, t) { e.targetElement = t; }
function hT(e) { return e.eic; }
function pk(e, t) { e.eic = t; }
function hk(e) { return e.timeStamp; }
function gk(e, t) { e.timeStamp = t; }
function ja(e) { return e.eia; }
function gT(e, t, n) { e.eia = [t, n]; }
function ep(e) { e.eia = void 0; }
function Pa(e) { return e[1]; }
function mk(e) { return e.eirp; }
function mT(e, t) { e.eirp = t; }
function vT(e) { return e.eir; }
function yT(e, t) { e.eir = t; }
function ET(e) { return { eventType: e.eventType, event: e.event, targetElement: e.targetElement, eic: e.eic, eia: e.eia, timeStamp: e.timeStamp, eirp: e.eirp, eiack: e.eiack, eir: e.eir }; }
function vk(e, t, n, o, r, i, s, a) { return { eventType: e, event: t, targetElement: n, eic: o, timeStamp: r, eia: i, eirp: s, eiack: a }; }
var tp = class e {
    eventInfo;
    constructor(t) { this.eventInfo = t; }
    getEventType() { return $t(this.eventInfo); }
    setEventType(t) { ip(this.eventInfo, t); }
    getEvent() { return Fa(this.eventInfo); }
    setEvent(t) { dT(this.eventInfo, t); }
    getTargetElement() { return fT(this.eventInfo); }
    setTargetElement(t) { pT(this.eventInfo, t); }
    getContainer() { return hT(this.eventInfo); }
    setContainer(t) { pk(this.eventInfo, t); }
    getTimestamp() { return hk(this.eventInfo); }
    setTimestamp(t) { gk(this.eventInfo, t); }
    getAction() { let t = ja(this.eventInfo); if (t)
        return { name: t[0], element: t[1] }; }
    setAction(t) { if (!t) {
        ep(this.eventInfo);
        return;
    } gT(this.eventInfo, t.name, t.element); }
    getIsReplay() { return mk(this.eventInfo); }
    setIsReplay(t) { mT(this.eventInfo, t); }
    getResolved() { return vT(this.eventInfo); }
    setResolved(t) { yT(this.eventInfo, t); }
    clone() { return new e(ET(this.eventInfo)); }
}, yk = {}, Ek = /\s*;\s*/, Ik = T.CLICK, np = class {
    a11yClickSupport = !1;
    clickModSupport = !0;
    syntheticMouseEventSupport;
    updateEventInfoForA11yClick = void 0;
    preventDefaultForA11yClick = void 0;
    populateClickOnlyAction = void 0;
    constructor({ syntheticMouseEventSupport: t = !1, clickModSupport: n = !0 } = {}) { this.syntheticMouseEventSupport = t, this.clickModSupport = n; }
    resolveEventType(t) { this.clickModSupport && $t(t) === T.CLICK && lk(Fa(t)) ? ip(t, T.CLICKMOD) : this.a11yClickSupport && this.updateEventInfoForA11yClick(t); }
    resolveAction(t) { vT(t) || (this.populateAction(t, fT(t)), yT(t, !0)); }
    resolveParentAction(t) { let n = ja(t), o = n && Pa(n); ep(t); let r = o && this.getParentNode(o); r && this.populateAction(t, r); }
    populateAction(t, n) { let o = n; for (; o && o !== hT(t) && (o.nodeType === Node.ELEMENT_NODE && this.populateActionOnElement(o, t), !ja(t));)
        o = this.getParentNode(o); let r = ja(t); if (r && (this.a11yClickSupport && this.preventDefaultForA11yClick(t), this.syntheticMouseEventSupport && ($t(t) === T.MOUSEENTER || $t(t) === T.MOUSELEAVE || $t(t) === T.POINTERENTER || $t(t) === T.POINTERLEAVE)))
        if (uk(Fa(t), $t(t), Pa(r))) {
            let i = dk(Fa(t), Pa(r));
            dT(t, i), pT(t, Pa(r));
        }
        else
            ep(t); }
    getParentNode(t) { let n = t[rp.OWNER]; if (n)
        return n; let o = t.parentNode; return o?.nodeName === "#document-fragment" ? o?.host ?? null : o; }
    populateActionOnElement(t, n) { let o = this.parseActions(t), r = o[$t(n)]; r !== void 0 && gT(n, r, t), this.a11yClickSupport && this.populateClickOnlyAction(t, n, o); }
    parseActions(t) { let n = Jx(t); if (!n) {
        let o = t.getAttribute(jn.JSACTION);
        if (!o)
            n = yk, iT(t, n);
        else {
            if (n = Xx(o), !n) {
                n = {};
                let r = o.split(Ek);
                for (let i = 0; i < r.length; i++) {
                    let s = r[i];
                    if (!s)
                        continue;
                    let a = s.indexOf(fk.EVENT_ACTION_SEPARATOR), c = a !== -1, l = c ? s.substr(0, a).trim() : Ik, u = c ? s.substr(a + 1).trim() : s;
                    n[l] = u;
                }
                ek(o, n);
            }
            iT(t, n);
        }
    } return n; }
    addA11yClickSupport(t, n, o) { this.a11yClickSupport = !0, this.updateEventInfoForA11yClick = t, this.preventDefaultForA11yClick = n, this.populateClickOnlyAction = o; }
}, IT = (function (e) { return e[e.I_AM_THE_JSACTION_FRAMEWORK = 0] = "I_AM_THE_JSACTION_FRAMEWORK", e; })(IT || {}), op = class {
    dispatchDelegate;
    actionResolver;
    eventReplayer;
    eventReplayScheduled = !1;
    replayEventInfoWrappers = [];
    constructor(t, { actionResolver: n, eventReplayer: o } = {}) { this.dispatchDelegate = t, this.actionResolver = n, this.eventReplayer = o; }
    dispatch(t) { let n = new tp(t); this.actionResolver?.resolveEventType(t), this.actionResolver?.resolveAction(t); let o = n.getAction(); if (o && Dk(o.element, n) && ak(n.getEvent()), this.eventReplayer && n.getIsReplay()) {
        this.scheduleEventInfoWrapperReplay(n);
        return;
    } this.dispatchDelegate(n); }
    scheduleEventInfoWrapperReplay(t) { this.replayEventInfoWrappers.push(t), !this.eventReplayScheduled && (this.eventReplayScheduled = !0, Promise.resolve().then(() => { this.eventReplayScheduled = !1, this.eventReplayer(this.replayEventInfoWrappers); })); }
};
function Dk(e, t) { return e.tagName === "A" && (t.getEventType() === T.CLICK || t.getEventType() === T.CLICKMOD); }
var DT = Symbol.for("propagationStopped"), sp = { REPLAY: 101 };
var Ck = "`preventDefault` called during event replay.";
var Tk = "`composedPath` called during event replay.", Va = class {
    dispatchDelegate;
    clickModSupport;
    actionResolver;
    dispatcher;
    constructor(t, n = !0) { this.dispatchDelegate = t, this.clickModSupport = n, this.actionResolver = new np({ clickModSupport: n }), this.dispatcher = new op(o => { this.dispatchToDelegate(o); }, { actionResolver: this.actionResolver }); }
    dispatch(t) { this.dispatcher.dispatch(t); }
    dispatchToDelegate(t) { for (t.getIsReplay() && wk(t), Mk(t); t.getAction();) {
        if (Sk(t), Ba(t.getEventType()) && t.getAction().element !== t.getTargetElement() || (this.dispatchDelegate(t.getEvent(), t.getAction().name), Nk(t)))
            return;
        this.actionResolver.resolveParentAction(t.eventInfo);
    } }
};
function Mk(e) { let t = e.getEvent(), n = e.getEvent().stopPropagation.bind(t), o = () => { t[DT] = !0, n(); }; Nn(t, "stopPropagation", o), Nn(t, "stopImmediatePropagation", o); }
function Nk(e) { return !!e.getEvent()[DT]; }
function wk(e) { let t = e.getEvent(), n = e.getTargetElement(), o = t.preventDefault.bind(t); Nn(t, "target", n), Nn(t, "eventPhase", sp.REPLAY), Nn(t, "preventDefault", () => { throw o(), new Error(Ck + ""); }), Nn(t, "composedPath", () => { throw new Error(Tk + ""); }); }
function Sk(e) { let t = e.getEvent(), n = e.getAction()?.element; n && Nn(t, "currentTarget", n, { configurable: !0 }); }
function Nn(e, t, n, { configurable: o = !1 } = {}) { Object.defineProperty(e, t, { value: n, configurable: o }); }
function CT(e, t) { e.ecrd(n => { t.dispatch(n); }, IT.I_AM_THE_JSACTION_FRAMEWORK); }
function _k(e) { return e?.q ?? []; }
function bk(e) { e && (aT(e.c, e.et, e.h), aT(e.c, e.etc, e.h, !0)); }
function aT(e, t, n, o) { for (let r = 0; r < t.length; r++)
    e.removeEventListener(t[r], n, o); }
var Ak = !1, TT = (() => { class e {
    static MOUSE_SPECIAL_SUPPORT = Ak;
    containerManager;
    eventHandlers = {};
    browserEventTypeToExtraEventTypes = {};
    dispatcher = null;
    queuedEventInfos = [];
    constructor(n) { this.containerManager = n; }
    handleEvent(n, o, r) { let i = vk(n, o, o.target, r, Date.now()); this.handleEventInfo(i); }
    handleEventInfo(n) { if (!this.dispatcher) {
        mT(n, !0), this.queuedEventInfos?.push(n);
        return;
    } this.dispatcher(n); }
    addEvent(n, o, r) { if (n in this.eventHandlers || !this.containerManager || !e.MOUSE_SPECIAL_SUPPORT && tk.indexOf(n) >= 0)
        return; let i = (a, c, l) => { this.handleEvent(a, c, l); }; this.eventHandlers[n] = i; let s = rk(o || n); if (s !== n) {
        let a = this.browserEventTypeToExtraEventTypes[s] || [];
        a.push(n), this.browserEventTypeToExtraEventTypes[s] = a;
    } this.containerManager.addEventListener(s, a => c => { i(n, c, a); }, r); }
    replayEarlyEvents(n = window._ejsa) { n && (this.replayEarlyEventInfos(n.q), bk(n), delete window._ejsa); }
    replayEarlyEventInfos(n) { for (let o = 0; o < n.length; o++) {
        let r = n[o], i = this.getEventTypesForBrowserEventType(r.eventType);
        for (let s = 0; s < i.length; s++) {
            let a = ET(r);
            ip(a, i[s]), this.handleEventInfo(a);
        }
    } }
    getEventTypesForBrowserEventType(n) { let o = []; return this.eventHandlers[n] && o.push(n), this.browserEventTypeToExtraEventTypes[n] && o.push(...this.browserEventTypeToExtraEventTypes[n]), o; }
    handler(n) { return this.eventHandlers[n]; }
    cleanUp() { this.containerManager?.cleanUp(), this.containerManager = null, this.eventHandlers = {}, this.browserEventTypeToExtraEventTypes = {}, this.dispatcher = null, this.queuedEventInfos = []; }
    registerDispatcher(n, o) { this.ecrd(n, o); }
    ecrd(n, o) { if (this.dispatcher = n, this.queuedEventInfos?.length) {
        for (let r = 0; r < this.queuedEventInfos.length; r++)
            this.handleEventInfo(this.queuedEventInfos[r]);
        this.queuedEventInfos = null;
    } }
} return e; })();
function MT(e, t = window) { return _k(t._ejsas?.[e]); }
function ap(e, t = window) { t._ejsas && (t._ejsas[e] = void 0); }
import "rxjs/operators";
typeof globalThis.ngServerMode > "u" && (globalThis.ngServerMode = typeof window > "u");
var Qa = Symbol("InputSignalNode#UNSET"), GT = Re(G({}, ec), { transformFn: void 0, applyValueToInputSignal(e, t) { Xa(e, t); } }), d1 = Symbol();
function WT(e, t) { let n = Object.create(GT); n.value = e, n.transformFn = t?.transform; function o() { if (ri(n), n.value === Qa) {
    let r = null;
    throw new M(-950, r);
} return n.value; } return o[Qe] = n, o; }
var Ok = (function (e) { return e.Angular = "angular", e.ACX = "acx", e.Wiz = "wiz", e; })(Ok || {}), NT = class {
    attributeName;
    constructor(t) { this.attributeName = t; }
    __NG_ELEMENT_ID__ = () => Rs(this.attributeName);
    toString() { return `HostAttributeToken ${this.attributeName}`; }
}, f1 = (() => { let e = new b(""); return e.__NG_ELEMENT_ID__ = t => { let n = N(); if (n === null)
    throw new M(-204, !1); if (n.type & 2)
    return n.value; if (t & 8)
    return null; throw new M(-204, !1); }, e; })();
function xk(e) { return kk(e) ? e.default : e; }
function kk(e) { return e && typeof e == "object" && "default" in e; }
function p1(e, t) { let n = D(me), o = null, r = () => (o || (o = e()), o); return t?.prefetch && t.prefetch().then(() => r()).catch(() => { }), () => r().then(i => n.get(xk(i))); }
function h1(e) { let t = D(Os), { promise: n, resolve: o } = Ln(); return t.requestOnIdle(() => o(), e), n; }
var wn = (function (e) { return e[e.Directive = 0] = "Directive", e[e.Component = 1] = "Component", e[e.Injectable = 2] = "Injectable", e[e.Pipe = 3] = "Pipe", e[e.NgModule = 4] = "NgModule", e[e.Service = 5] = "Service", e; })(wn || {});
function g1(e) { return new Qc; }
function wT(e, t) { return WT(e, t); }
function Lk(e) { return WT(Qa, e); }
var m1 = (wT.required = Lk, wT);
function zT(e, t) { let n = Object.create(GT), o = new Qc; n.value = e; function r() { return ri(n), ST(n.value), n.value; } return r[Qe] = n, r.asReadonly = gh.bind(r), r.set = i => { n.equal(n.value, i) || (Xa(n, i), o.emit(i)); }, r.update = i => { ST(n.value), r.set(i(n.value)); }, r.subscribe = o.subscribe.bind(o), r.destroyRef = o.destroyRef, r; }
function ST(e) { if (e === Qa)
    throw new M(952, !1); }
function _T(e, t) { return zT(e, t); }
function Pk(e) { return zT(Qa, e); }
var v1 = (_T.required = Pk, _T);
function bT(e, t) { return Vd(t); }
function Fk(e, t) { return Bd(t); }
var y1 = (bT.required = Fk, bT);
function E1(e, t) { return $d(t); }
function AT(e, t) { return Vd(t); }
function jk(e, t) { return Bd(t); }
var I1 = (AT.required = jk, AT);
function D1(e, t) { return $d(t); }
function C1(...e) { return e.reduce((t, n) => Object.assign(t, n, { providers: [...t.providers, ...n.providers] }), { providers: [] }); }
var qT = !0, Do = class {
}, T1 = yt("ContentChildren", (e, t = {}) => G({ selector: e, first: !1, isViewQuery: !1, descendants: !1, emitDistinctChangesOnly: qT }, t), Do), M1 = yt("ContentChild", (e, t = {}) => G({ selector: e, first: !0, isViewQuery: !1, descendants: !0 }, t), Do), N1 = yt("ViewChildren", (e, t = {}) => G({ selector: e, first: !1, isViewQuery: !0, descendants: !0, emitDistinctChangesOnly: qT }, t), Do), w1 = yt("ViewChild", (e, t) => G({ selector: e, first: !0, isViewQuery: !0, descendants: !0 }, t), Do), S1 = (() => { class e {
    constructor(n) { }
    static \u0275fac = function (o) { return new (o || e)(He(be)); };
    static \u0275mod = Wd({ type: e });
    static \u0275inj = Mo({});
} return e; })(), _1 = new b("", { providedIn: "platform", factory: () => null }), b1 = new b("", { providedIn: "platform", factory: () => null }), A1 = new b("", { providedIn: "platform", factory: () => null }), $a = new WeakSet, RT = "";
function OT(e) { return e.get(Hs, Uu); }
function Hk() { let e = [{ provide: Hs, useFactory: () => { let t = !0; if (typeof ngServerMode > "u" || !ngServerMode) {
            let n = D(dt);
            t = !!window._ejsas?.[n];
        } return t && K("NgEventReplay"), t; } }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: St, useValue: () => { let t = D(be), { injector: n } = t; if (!$a.has(t)) {
        let o = D(Pr);
        if (OT(n)) {
            Hm();
            let r = n.get(dt), i = Fm(r, (s, a, c) => { s.nodeType === Node.ELEMENT_NODE && (Pm(s, a, c), zu(s, o)); });
            t.onDestroy(i);
        }
    } }, multi: !0 }, { provide: Yr, useFactory: () => { let t = D(be), { injector: n } = t; return () => { if (!OT(n) || $a.has(t))
        return; $a.add(t); let o = n.get(dt); t.onDestroy(() => { $a.delete(t), typeof ngServerMode < "u" && !ngServerMode && ap(o); }), t.whenStable().then(() => { if (t.destroyed)
        return; let r = n.get(Qu); Vk(r, n); let i = n.get(Pr); i.get(RT)?.forEach(qu), i.delete(RT); let s = r.instance; Fr(n) ? t.onDestroy(() => s.cleanUp()) : s.cleanUp(); }); }; }, multi: !0 }), e; }
var Vk = (e, t) => { let n = t.get(dt), o = window._ejsas[n], r = e.instance = new TT(new Ha(o.c)); for (let a of o.et)
    r.addEvent(a); for (let a of o.etc)
    r.addEvent(a); let i = MT(n); r.replayEarlyEventInfos(i), ap(n); let s = new Va(a => { $k(t, a, a.currentTarget); }); CT(r, s); };
function Bk(e, t, n) { let o = new Map, r = t[Qt], i = e.cleanup; if (!i || !r)
    return o; for (let s = 0; s < i.length;) {
    let a = i[s++], c = i[s++];
    if (typeof a != "string")
        continue;
    let l = a;
    if (!uT(l))
        continue;
    Ba(l) ? n.capture.add(l) : n.regular.add(l);
    let u = x(t[c]);
    s++;
    let d = i[s++];
    (typeof d == "boolean" || d >= 0) && (o.has(u) ? o.get(u).push(l) : o.set(u, [l]));
} return o; }
function $k(e, t, n) { let o = (n && n.getAttribute(lo)) ?? ""; /d\d+/.test(o) ? Uk(o, e, t, n) : t.eventPhase === sp.REPLAY && Yu(t, n); }
function Uk(e, t, n, o) { let r = t.get(Om); r.push({ event: n, currentTarget: o }), Mt(t, e, Gk(r)); }
function Gk(e) { return t => { let n = new Set(t), o = []; for (let { event: r, currentTarget: i } of e) {
    let s = i.getAttribute(lo);
    n.has(s) ? Yu(r, i) : o.push({ event: r, currentTarget: i });
} e.length = 0, e.push(...o); }; }
var xT = !1, kT = !1, Wk = 1e4;
function zk() { xT || (xT = !0, Gm(), HI(), kD(), VI(), jE(), cE(), xy(), Kv()); }
function qk() { kT || (kT = !0, XI(), My(), by()); }
function Qk(e) { return e.whenStable(); }
var R1 = "ngcm";
function O1() { let e = [{ provide: Cn, useFactory: () => { let t = !0; return (typeof ngServerMode > "u" || !ngServerMode) && (t = !!D(tn, { optional: !0 })?.get(Vs, null)), t && K("NgHydration"), t; } }, { provide: St, useValue: () => { if (bd(!1), typeof ngServerMode < "u" && ngServerMode)
            return; let t = D(Pn); D(Cn) && (Jm(t), zk()); }, multi: !0 }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: Bu, useFactory: () => D(Cn) }, { provide: Yr, useFactory: () => { let t = D(Ot); if (D(Cn)) {
        let n = D(be);
        return () => { Qk(n).then(() => { n.destroyed || (Ad(n), t.notify(7)); }); };
    } return () => { }; }, multi: !0 }), Be(e); }
function x1() { return [{ provide: $u, useFactory: () => D(Cn) }, { provide: St, useValue: () => { D(Cn) && (qk(), bd(!0), K("NgI18nHydration")); }, multi: !0 }]; }
function k1() { let e = [Hk(), { provide: Gu, useValue: !0 }, { provide: It, useFactory: fC }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: ka, useFactory: () => ({ requested: !1, activated: !1, injector: D(me), document: D(Pn) }) }, { provide: Yr, useFactory: () => { let t = D(ka); return () => { t.requested || (t.requested = !0, Qf(t)); }; }, multi: !0 }), e; }
var LT = Wk - 1e3, up = class {
    openTasks = new Map;
    add(t) { this.openTasks.set(t, new Error("Task stack tracking error")); }
    remove(t) { this.openTasks.delete(t); }
};
function L1() { let e = new up, { openTasks: t } = e; return Be([{ provide: fh, useValue: e }, SE(() => { console.warn("Stability debugging utility was provided in production mode. This will cause debug code to be included in production bundles. If this is intentional because you are debugging stability issues in a production environment, you can ignore this warning."); let n = D(B), o = D(be), r = null; typeof Zone < "u" && n.run(() => { r = Zone.current.get("TaskTrackingZone"); }), n.runOutsideAngular(() => { let i = setTimeout(() => { if (console.debug(`---- Application did not stabilize within ${LT / 1e3} seconds ----`), typeof Zone < "u" && !r && console.info('Zone.js is present but no TaskTrackingZone found. To enable better debugging of tasks in the Angular Zone, import "zone.js/plugins/task-tracking" in your application.'), r?.macroTasks?.length) {
        console.group("Macrotasks keeping Angular Zone unstable:");
        for (let s of r?.macroTasks ?? [])
            console.debug(s.creationLocation.stack);
        console.groupEnd();
    } console.group("PendingTasks keeping application unstable:"); for (let s of t.values())
        console.debug(s.stack); console.groupEnd(); }, LT); o.whenStable().then(() => { clearTimeout(i); }); }); })]); }
var Ua = class {
    supports(t) { return vr(t); }
    create(t) { return new dp(t); }
}, Yk = (e, t) => t, dp = class {
    length = 0;
    collection;
    _linkedRecords = null;
    _unlinkedRecords = null;
    _previousItHead = null;
    _itHead = null;
    _itTail = null;
    _additionsHead = null;
    _additionsTail = null;
    _movesHead = null;
    _movesTail = null;
    _removalsHead = null;
    _removalsTail = null;
    _identityChangesHead = null;
    _identityChangesTail = null;
    _trackByFn;
    constructor(t) { this._trackByFn = t || Yk; }
    forEachItem(t) { let n; for (n = this._itHead; n !== null; n = n._next)
        t(n); }
    forEachOperation(t) { let n = this._itHead, o = this._removalsHead, r = 0, i = null; for (; n || o;) {
        let s = !o || n && n.currentIndex < PT(o, r, i) ? n : o, a = PT(s, r, i), c = s.currentIndex;
        if (s === o)
            r--, o = o._nextRemoved;
        else if (n = n._next, s.previousIndex == null)
            r++;
        else {
            i || (i = []);
            let l = a - r, u = c - r;
            if (l != u) {
                for (let f = 0; f < l; f++) {
                    let p = f < i.length ? i[f] : i[f] = 0, h = p + f;
                    u <= h && h < l && (i[f] = p + 1);
                }
                let d = s.previousIndex;
                i[d] = u - l;
            }
        }
        a !== c && t(s, a, c);
    } }
    forEachPreviousItem(t) { let n; for (n = this._previousItHead; n !== null; n = n._nextPrevious)
        t(n); }
    forEachAddedItem(t) { let n; for (n = this._additionsHead; n !== null; n = n._nextAdded)
        t(n); }
    forEachMovedItem(t) { let n; for (n = this._movesHead; n !== null; n = n._nextMoved)
        t(n); }
    forEachRemovedItem(t) { let n; for (n = this._removalsHead; n !== null; n = n._nextRemoved)
        t(n); }
    forEachIdentityChange(t) { let n; for (n = this._identityChangesHead; n !== null; n = n._nextIdentityChange)
        t(n); }
    diff(t) { if (t == null && (t = []), !vr(t))
        throw new M(900, !1); return this.check(t) ? this : null; }
    onDestroy() { }
    check(t) { this._reset(); let n = this._itHead, o = !1, r, i, s; if (Array.isArray(t)) {
        this.length = t.length;
        for (let a = 0; a < this.length; a++)
            i = t[a], s = this._trackByFn(a, i), n === null || !Object.is(n.trackById, s) ? (n = this._mismatch(n, i, s, a), o = !0) : (o && (n = this._verifyReinsertion(n, i, s, a)), Object.is(n.item, i) || this._addIdentityChange(n, i)), n = n._next;
    }
    else
        r = 0, $y(t, a => { s = this._trackByFn(r, a), n === null || !Object.is(n.trackById, s) ? (n = this._mismatch(n, a, s, r), o = !0) : (o && (n = this._verifyReinsertion(n, a, s, r)), Object.is(n.item, a) || this._addIdentityChange(n, a)), n = n._next, r++; }), this.length = r; return this._truncate(n), this.collection = t, this.isDirty; }
    get isDirty() { return this._additionsHead !== null || this._movesHead !== null || this._removalsHead !== null || this._identityChangesHead !== null; }
    _reset() { if (this.isDirty) {
        let t;
        for (t = this._previousItHead = this._itHead; t !== null; t = t._next)
            t._nextPrevious = t._next;
        for (t = this._additionsHead; t !== null; t = t._nextAdded)
            t.previousIndex = t.currentIndex;
        for (this._additionsHead = this._additionsTail = null, t = this._movesHead; t !== null; t = t._nextMoved)
            t.previousIndex = t.currentIndex;
        this._movesHead = this._movesTail = null, this._removalsHead = this._removalsTail = null, this._identityChangesHead = this._identityChangesTail = null;
    } }
    _mismatch(t, n, o, r) { let i; return t === null ? i = this._itTail : (i = t._prev, this._remove(t)), t = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(o, null), t !== null ? (Object.is(t.item, n) || this._addIdentityChange(t, n), this._reinsertAfter(t, i, r)) : (t = this._linkedRecords === null ? null : this._linkedRecords.get(o, r), t !== null ? (Object.is(t.item, n) || this._addIdentityChange(t, n), this._moveAfter(t, i, r)) : t = this._addAfter(new fp(n, o), i, r)), t; }
    _verifyReinsertion(t, n, o, r) { let i = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(o, null); return i !== null ? t = this._reinsertAfter(i, t._prev, r) : t.currentIndex != r && (t.currentIndex = r, this._addToMoves(t, r)), t; }
    _truncate(t) { for (; t !== null;) {
        let n = t._next;
        this._addToRemovals(this._unlink(t)), t = n;
    } this._unlinkedRecords !== null && this._unlinkedRecords.clear(), this._additionsTail !== null && (this._additionsTail._nextAdded = null), this._movesTail !== null && (this._movesTail._nextMoved = null), this._itTail !== null && (this._itTail._next = null), this._removalsTail !== null && (this._removalsTail._nextRemoved = null), this._identityChangesTail !== null && (this._identityChangesTail._nextIdentityChange = null); }
    _reinsertAfter(t, n, o) { this._unlinkedRecords !== null && this._unlinkedRecords.remove(t); let r = t._prevRemoved, i = t._nextRemoved; return r === null ? this._removalsHead = i : r._nextRemoved = i, i === null ? this._removalsTail = r : i._prevRemoved = r, this._insertAfter(t, n, o), this._addToMoves(t, o), t; }
    _moveAfter(t, n, o) { return this._unlink(t), this._insertAfter(t, n, o), this._addToMoves(t, o), t; }
    _addAfter(t, n, o) { return this._insertAfter(t, n, o), this._additionsTail === null ? this._additionsTail = this._additionsHead = t : this._additionsTail = this._additionsTail._nextAdded = t, t; }
    _insertAfter(t, n, o) { let r = n === null ? this._itHead : n._next; return t._next = r, t._prev = n, r === null ? this._itTail = t : r._prev = t, n === null ? this._itHead = t : n._next = t, this._linkedRecords === null && (this._linkedRecords = new Ga), this._linkedRecords.put(t), t.currentIndex = o, t; }
    _remove(t) { return this._addToRemovals(this._unlink(t)); }
    _unlink(t) { this._linkedRecords !== null && this._linkedRecords.remove(t); let n = t._prev, o = t._next; return n === null ? this._itHead = o : n._next = o, o === null ? this._itTail = n : o._prev = n, t; }
    _addToMoves(t, n) { return t.previousIndex === n || (this._movesTail === null ? this._movesTail = this._movesHead = t : this._movesTail = this._movesTail._nextMoved = t), t; }
    _addToRemovals(t) { return this._unlinkedRecords === null && (this._unlinkedRecords = new Ga), this._unlinkedRecords.put(t), t.currentIndex = null, t._nextRemoved = null, this._removalsTail === null ? (this._removalsTail = this._removalsHead = t, t._prevRemoved = null) : (t._prevRemoved = this._removalsTail, this._removalsTail = this._removalsTail._nextRemoved = t), t; }
    _addIdentityChange(t, n) { return t.item = n, this._identityChangesTail === null ? this._identityChangesTail = this._identityChangesHead = t : this._identityChangesTail = this._identityChangesTail._nextIdentityChange = t, t; }
}, fp = class {
    item;
    trackById;
    currentIndex = null;
    previousIndex = null;
    _nextPrevious = null;
    _prev = null;
    _next = null;
    _prevDup = null;
    _nextDup = null;
    _prevRemoved = null;
    _nextRemoved = null;
    _nextAdded = null;
    _nextMoved = null;
    _nextIdentityChange = null;
    constructor(t, n) { this.item = t, this.trackById = n; }
}, pp = class {
    _head = null;
    _tail = null;
    add(t) { this._head === null ? (this._head = this._tail = t, t._nextDup = null, t._prevDup = null) : (this._tail._nextDup = t, t._prevDup = this._tail, t._nextDup = null, this._tail = t); }
    get(t, n) { let o; for (o = this._head; o !== null; o = o._nextDup)
        if ((n === null || n <= o.currentIndex) && Object.is(o.trackById, t))
            return o; return null; }
    remove(t) { let n = t._prevDup, o = t._nextDup; return n === null ? this._head = o : n._nextDup = o, o === null ? this._tail = n : o._prevDup = n, this._head === null; }
}, Ga = class {
    map = new Map;
    put(t) { let n = t.trackById, o = this.map.get(n); o || (o = new pp, this.map.set(n, o)), o.add(t); }
    get(t, n) { let o = t, r = this.map.get(o); return r ? r.get(t, n) : null; }
    remove(t) { let n = t.trackById; return this.map.get(n).remove(t) && this.map.delete(n), t; }
    get isEmpty() { return this.map.size === 0; }
    clear() { this.map.clear(); }
};
function PT(e, t, n) { let o = e.previousIndex; if (o === null)
    return o; let r = 0; return n && o < n.length && (r = n[o]), o + t + r; }
var Wa = class {
    supports(t) { return t instanceof Map || Ia(t); }
    create() { return new hp; }
}, hp = class {
    _records = new Map;
    _mapHead = null;
    _appendAfter = null;
    _previousMapHead = null;
    _changesHead = null;
    _changesTail = null;
    _additionsHead = null;
    _additionsTail = null;
    _removalsHead = null;
    get isDirty() { return this._additionsHead !== null || this._changesHead !== null || this._removalsHead !== null; }
    forEachItem(t) { let n; for (n = this._mapHead; n !== null; n = n._next)
        t(n); }
    forEachPreviousItem(t) { let n; for (n = this._previousMapHead; n !== null; n = n._nextPrevious)
        t(n); }
    forEachChangedItem(t) { let n; for (n = this._changesHead; n !== null; n = n._nextChanged)
        t(n); }
    forEachAddedItem(t) { let n; for (n = this._additionsHead; n !== null; n = n._nextAdded)
        t(n); }
    forEachRemovedItem(t) { let n; for (n = this._removalsHead; n !== null; n = n._nextRemoved)
        t(n); }
    diff(t) { if (!t)
        t = new Map;
    else if (!(t instanceof Map || Ia(t)))
        throw new M(900, !1); return this.check(t) ? this : null; }
    check(t) { this._reset(); let n = this._mapHead; if (this._appendAfter = null, this._forEach(t, (o, r) => { if (n && n.key === r)
        this._maybeAddToChanges(n, o), this._appendAfter = n, n = n._next;
    else {
        let i = this._getOrCreateRecordForKey(r, o);
        n = this._insertBeforeOrAppend(n, i);
    } }), n) {
        n._prev && (n._prev._next = null), this._removalsHead = n;
        for (let o = n; o !== null; o = o._nextRemoved)
            o === this._mapHead && (this._mapHead = null), this._records.delete(o.key), o._nextRemoved = o._next, o.previousValue = o.currentValue, o.currentValue = null, o._prev = null, o._next = null;
    } return this._changesTail && (this._changesTail._nextChanged = null), this._additionsTail && (this._additionsTail._nextAdded = null), this.isDirty; }
    _insertBeforeOrAppend(t, n) { if (t) {
        let o = t._prev;
        return n._next = t, n._prev = o, t._prev = n, o && (o._next = n), t === this._mapHead && (this._mapHead = n), this._appendAfter = t, t;
    } return this._appendAfter ? (this._appendAfter._next = n, n._prev = this._appendAfter) : this._mapHead = n, this._appendAfter = n, null; }
    _getOrCreateRecordForKey(t, n) { if (this._records.has(t)) {
        let r = this._records.get(t);
        this._maybeAddToChanges(r, n);
        let i = r._prev, s = r._next;
        return i && (i._next = s), s && (s._prev = i), r._next = null, r._prev = null, r;
    } let o = new gp(t); return this._records.set(t, o), o.currentValue = n, this._addToAdditions(o), o; }
    _reset() { if (this.isDirty) {
        let t;
        for (this._previousMapHead = this._mapHead, t = this._previousMapHead; t !== null; t = t._next)
            t._nextPrevious = t._next;
        for (t = this._changesHead; t !== null; t = t._nextChanged)
            t.previousValue = t.currentValue;
        for (t = this._additionsHead; t != null; t = t._nextAdded)
            t.previousValue = t.currentValue;
        this._changesHead = this._changesTail = null, this._additionsHead = this._additionsTail = null, this._removalsHead = null;
    } }
    _maybeAddToChanges(t, n) { Object.is(n, t.currentValue) || (t.previousValue = t.currentValue, t.currentValue = n, this._addToChanges(t)); }
    _addToAdditions(t) { this._additionsHead === null ? this._additionsHead = this._additionsTail = t : (this._additionsTail._nextAdded = t, this._additionsTail = t); }
    _addToChanges(t) { this._changesHead === null ? this._changesHead = this._changesTail = t : (this._changesTail._nextChanged = t, this._changesTail = t); }
    _forEach(t, n) { t instanceof Map ? t.forEach(n) : Object.keys(t).forEach(o => n(t[o], o)); }
}, gp = class {
    key;
    previousValue = null;
    currentValue = null;
    _nextPrevious = null;
    _next = null;
    _prev = null;
    _nextAdded = null;
    _nextRemoved = null;
    _nextChanged = null;
    constructor(t) { this.key = t; }
};
function FT() { return new QT([new Ua]); }
var QT = (() => { class e {
    factories;
    static \u0275prov = ae({ token: e, providedIn: "root", factory: FT });
    constructor(n) { this.factories = n; }
    static create(n, o) { if (o != null) {
        let r = o.factories.slice();
        n = n.concat(r);
    } return new e(n); }
    static extend(n) { return { provide: e, useFactory: () => { let o = D(e, { optional: !0, skipSelf: !0 }); return e.create(n, o || FT()); } }; }
    find(n) { let o = this.factories.find(r => r.supports(n)); if (o != null)
        return o; throw new M(901, !1); }
} return e; })();
function jT() { return new YT([new Wa]); }
var YT = (() => { class e {
    static \u0275prov = ae({ token: e, providedIn: "root", factory: jT });
    factories;
    constructor(n) { this.factories = n; }
    static create(n, o) { if (o) {
        let r = o.factories.slice();
        n = n.concat(r);
    } return new e(n); }
    static extend(n) { return { provide: e, useFactory: () => { let o = D(e, { optional: !0, skipSelf: !0 }); return e.create(n, o || jT()); } }; }
    find(n) { let o = this.factories.find(r => r.supports(n)); if (o)
        return o; throw new M(901, !1); }
} return e; })(), Zk = (() => { class e {
    static __NG_ELEMENT_ID__ = Kk;
} return e; })();
function Kk(e) { return Jk(N(), g(), (e & 16) === 16); }
function Jk(e, t, n) { if (ve(e) && !n) {
    let o = fe(e.index, t);
    return new vt(o, o);
}
else if (e.type & 175) {
    let o = t[ee];
    return new vt(o, t);
} return null; }
var Xk = [new Wa], eL = [new Ua], P1 = new QT(eL), F1 = new YT(Xk);
function j1(e) { return Be([]); }
var tL = (() => { class e {
    zone = D(B);
    changeDetectionScheduler = D(Ot);
    applicationRef = D(be);
    applicationErrorHandler = D(en);
    _onMicrotaskEmptySubscription;
    initialize() { this._onMicrotaskEmptySubscription || (this._onMicrotaskEmptySubscription = this.zone.onMicrotaskEmpty.subscribe({ next: () => { this.changeDetectionScheduler.runningTick || this.zone.run(() => { try {
            this.applicationRef.dirtyFlags |= 1, this.applicationRef._tick();
        }
        catch (n) {
            this.applicationErrorHandler(n);
        } }); } })); }
    ngOnDestroy() { this._onMicrotaskEmptySubscription?.unsubscribe(); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = Et({ token: e, factory: e.\u0275fac });
} return e; })(), nL = new b("", { factory: () => !1 });
function oL({ ngZoneFactory: e, scheduleInRootZone: t }) { return e ??= () => new B(Re(G({}, ZT()), { scheduleInRootZone: t })), [{ provide: Fn, useValue: !1 }, { provide: B, useFactory: e }, { provide: St, multi: !0, useFactory: () => { let n = D(tL, { optional: !0 }); return () => n.initialize(); } }, { provide: St, multi: !0, useFactory: () => { let n = D(rL); return () => { n.initialize(); }; } }, { provide: Ri, useValue: t ?? dh }]; }
function H1(e) { let t = e?.scheduleInRootZone, n = oL({ ngZoneFactory: () => { let o = ZT(e); return o.scheduleInRootZone = t, o.shouldCoalesceEventChangeDetection && K("NgZone_CoalesceEvent"), new B(o); }, scheduleInRootZone: t }); return Be([{ provide: nL, useValue: !0 }, n]); }
function ZT(e) { return { enableLongStackTrace: !1, shouldCoalesceEventChangeDetection: e?.eventCoalescing ?? !1, shouldCoalesceRunChangeDetection: e?.runCoalescing ?? !1 }; }
var rL = (() => { class e {
    subscription = new Rk;
    initialized = !1;
    zone = D(B);
    pendingTasks = D(Rt);
    initialize() { if (this.initialized)
        return; this.initialized = !0; let n = null; !this.zone.isStable && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (n = this.pendingTasks.add()), this.zone.runOutsideAngular(() => { this.subscription.add(this.zone.onStable.subscribe(() => { B.assertNotInAngularZone(), queueMicrotask(() => { n !== null && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (this.pendingTasks.remove(n), n = null); }); })); }), this.subscription.add(this.zone.onUnstable.subscribe(() => { B.assertInAngularZone(), n ??= this.pendingTasks.add(); })); }
    ngOnDestroy() { this.subscription.unsubscribe(); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = Et({ token: e, factory: e.\u0275fac });
} return e; })();
function iL(e, t, n) { let o = new eo(n); return Promise.resolve(o); }
function HT(e) { for (let t = e.length - 1; t >= 0; t--)
    if (e[t] !== void 0)
        return e[t]; }
var za = new b(""), sL = new b("");
function ti(e) { return !e.moduleRef; }
function KT(e) { let t = ti(e) ? e.r3Injector : e.moduleRef.injector, n = t.get(B); return n.run(() => { ti(e) ? e.r3Injector.resolveInjectorInitializers() : e.moduleRef.resolveInjectorInitializers(); let o = t.get(en), r; if (n.runOutsideAngular(() => { r = n.onError.subscribe({ next: o }); }), ti(e)) {
    let i = () => t.destroy(), s = e.platformInjector.get(za);
    s.add(i), t.onDestroy(() => { r.unsubscribe(), s.delete(i); });
}
else {
    let i = () => e.moduleRef.destroy(), s = e.platformInjector.get(za);
    s.add(i), e.moduleRef.onDestroy(() => { Jo(e.allPlatformModules, e.moduleRef), r.unsubscribe(), s.delete(i); });
} return cL(o, n, () => { let i = t.get(Rt), s = i.add(), a = t.get(Qd); return a.runInitializers(), a.donePromise.then(() => { let c = t.get(Jf, Jr); if (KI(c || Jr), !t.get(sL, !0))
    return ti(e) ? t.get(be) : (e.allPlatformModules.push(e.moduleRef), e.moduleRef); if (ti(e)) {
    let u = t.get(be);
    return e.rootComponent !== void 0 && u.bootstrap(e.rootComponent), u;
}
else
    return JT?.(e.moduleRef, e.allPlatformModules), e.moduleRef; }).finally(() => { i.remove(s); }); }); }); }
var JT;
function VT() { JT = aL; }
function aL(e, t) { let n = e.injector.get(be); if (e._bootstrapComponents.length > 0)
    e._bootstrapComponents.forEach(o => n.bootstrap(o));
else if (e.instance.ngDoBootstrap)
    e.instance.ngDoBootstrap(n);
else
    throw new M(-403, !1); t.push(e); }
function cL(e, t, n) { try {
    let o = n();
    return Ud(o) ? o.catch(r => { throw t.runOutsideAngular(() => e(r)), r; }) : o;
}
catch (o) {
    throw t.runOutsideAngular(() => e(o)), o;
} }
var XT = (() => { class e {
    _injector;
    _modules = [];
    _destroyListeners = [];
    _destroyed = !1;
    constructor(n) { this._injector = n; }
    bootstrapModuleFactory(n, o) { let r = [La(), ...o?.applicationProviders ?? [], $c], i = yE(n.moduleType, this.injector, r); return VT(), KT({ moduleRef: i, allPlatformModules: this._modules, platformInjector: this.injector }); }
    bootstrapModule(n, o = []) { let r = sf({}, o); return VT(), iL(this.injector, r, n).then(i => this.bootstrapModuleFactory(i, r)); }
    onDestroy(n) { this._destroyListeners.push(n); }
    get injector() { return this._injector; }
    destroy() { if (this._destroyed)
        throw new M(404, !1); this._modules.slice().forEach(o => o.destroy()), this._destroyListeners.forEach(o => o()); let n = this._injector.get(za, null); n && (n.forEach(o => o()), n.clear()), this._destroyed = !0; }
    get destroyed() { return this._destroyed; }
    static \u0275fac = function (o) { return new (o || e)(He(me)); };
    static \u0275prov = ae({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })();
function eM(e) { let t = KE(e); if (t?.type === "null")
    return { name: "Null Injector", type: "null", providers: [], children: [] }; let n = []; if ((t?.type === "element" || t?.type === "environment") && (n = ZE(e).map(o => ({ token: o.token, value: e.get(o.token, null, { optional: !0, self: !0 }) }))), t?.type === "element") {
    let o = Sr(e), r = o ? o.providerIndexes >> 20 : 0, i = n.slice(0, r), s = n.slice(r);
    return { name: e.constructor.name, type: "element", providers: s, viewProviders: i, children: [], hostElement: t.source };
} return { name: t?.source ?? e.constructor.name ?? "Unknown Injector", type: "environment", providers: n, children: [] }; }
var V1 = { name: "angular:di_graph", description: "\nExposes the Angular Dependency Injection (DI) graph of the application.\n\nThis tool extracts both the element injector tree (associated with DOM elements and components)\nand the environment injector tree (associated with modules and standalone application roots).\nIt captures the relationship structure and the providers resolved at each level.\n\nReturns:\n- `elementInjectorRoots`: An array of root element injectors (one for each Angular application\n  root found). Each node forms a tree hierarchy:\n  - `name`: The constructor name of this injector.\n  - `type`: 'element'.\n  - `providers`: Array of providers configured on this injector.\n    - `token`: The DI token.\n    - `value`: The resolved value of that provider if it was instantiated.\n  - `hostElement`: The DOM element that this injector is associated with.\n  - `children`: Array of child element injectors.\n- `environmentInjectorRoot`: The root environment injector. It forms a tree hierarchy of nodes\n  representing all environment injectors:\n  - `name`: The identifier for the environment injector.\n  - `type`: 'environment' or 'null'.\n  - `providers`: Array of providers configured on this injector.\n    - `token`: The DI token.\n    - `value`: The resolved value of that provider if it was instantiated.\n  - `children`: Array of child environment injectors.\n  ".trim(), inputSchema: { type: "object", properties: {} }, execute: () => Oe(null, null, function* () { let e = Array.from(document.querySelectorAll("[ng-version]")); if (e.length === 0)
        throw new Error("Could not find Angular root element ([ng-version]) on the page."); return lL(e); }) };
function lL(e) { let t = e.map(n => { let o = Ee(n); if (!o?.lView)
    throw new Error(`Could not find an \`LView\` for root \`<${n.tagName.toLowerCase()}>\`, is it an Angular component?`); return o.lView; }); return { elementInjectorRoots: t.map(n => uL(n)), environmentInjectorRoot: dL(t) }; }
function uL(e) { if (e[m].type !== 0)
    throw new Error(`Expected a root LView but got type: \`${e[m].type}\`.`); let t = []; for (let [o, r] of Pu(e)) {
    let i = new ye(o, r), s = eM(i);
    for (; t.length > 0;) {
        let [a, c, l] = t[t.length - 1], u = tM(o, a), d = fL(r, c, a);
        if (u || d) {
            l.children.push(s);
            break;
        }
        else
            t.pop();
    }
    t.push([o, r, s]);
} if (t.length === 0)
    throw new Error("Expected at least one component/directive in the root `LView`."); let [, , n] = t[0]; return n; }
function dL(e) { let t = new Map, n; function o(r) { let i = t.get(r); if (i)
    return i; let s = eM(r); t.set(r, s); let a = pL(r); if (a)
    o(a).children.push(s);
else if (!n)
    n = s;
else if (n !== s)
    throw new Error("Expected only one root environment injector, but found multiple.", { cause: { firstRoot: n, secondRoot: s } }); return s; } for (let r of e)
    for (let [, i] of Pu(r))
        o(i[O]); if (!n)
    throw new Error("Expected a root environment injector but did not find one."); return n; }
function tM(e, t) { let n = e; for (; n;) {
    if (n === t)
        return !0;
    n = n.parent;
} return !1; }
function fL(e, t, n) { let o = e, r = null; for (; o && o !== t;)
    r = o[X], o = tt(o); return o === t && r !== null && tM(r, n); }
function pL(e) { if (e instanceof Lt)
    return e.parentInjector; if (e instanceof qt)
    return e.parent; if (e instanceof Ao)
    return; throw new Error(`Unknown injector type: "${e.constructor.name}".`); }
var B1 = { name: "angular:signal_graph", description: "\nExposes the Angular signal dependency graph for a given DOM element.\n\nThis tool extracts the reactive dependency graph (signals, computeds, and effects) that\nare transitive dependencies of the effects of that element. It will include signals\nauthored in other components/services and depended upon by the target component, but\nwill *not* include signals only used in descendant components effects.\n\nParams:\n- `target`: The element to get the signal graph for. Must be the host element of an\n  Angular component.\n\nReturns:\n- `nodes`: An array of reactive nodes discovered in the context. Each node contains:\n  - `kind`: The type of reactive node ('signal', 'computed', 'effect', or 'template'\n    for component template effects).\n  - `value`: The current evaluated value of the node (if applicable).\n  - `label`: The symbol name of the associated signal if available (ex.\n    `const foo = signal(0);` has `label: 'foo'`).\n  - `epoch`: The internal version number of the node's value.\n- `edges`: An array of dependency links representing which nodes read from which other\n  nodes.\n  - `consumer`: The index in the `nodes` array of the node that depends on the value.\n  - `producer`: The index in the `nodes` array of the node that provides the value.\n\nExample: An edge with `{consumer: 2, producer: 0}` means that `nodes[2]` (e.g. an\n`effect`) reads the value of `nodes[0]` (e.g. a `signal`).\n  ".trim(), inputSchema: { type: "object", properties: { target: { type: "object", description: "The element to get the signal graph for.", "x-mcp-type": "HTMLElement" } }, required: ["target"] }, execute: t => Oe(null, [t], function* ({ target: e }) { if (!(e instanceof HTMLElement))
        throw new Error('Invalid input: "target" must be an HTMLElement.'); let n = Fu(e); if (n instanceof Ao)
        throw new Error('Invalid input: "target" is not the host element of an Angular component.'); let o = XE(n); return { nodes: o.nodes.map(a => { var c = a, { id: r, debuggableFn: i } = c, s = Tp(c, ["id", "debuggableFn"]); return s; }), edges: o.edges }; }) };
var Io = null;
function hL(e) { if (Ya())
    throw new M(400, !1); rf(), Io = typeof ngServerMode > "u" || !ngServerMode ? e : null; let t = e.get(XT); return oM(e), t; }
function gL(e, t, n = []) { let o = `Platform: ${t}`, r = new b(o); return (i = []) => { let s = Ya(); if (!s) {
    let a = [...n, ...i, { provide: r, useValue: !0 }];
    s = e?.(a) ?? hL(nM(a, o));
} return typeof ngServerMode < "u" && ngServerMode ? s : mL(r); }; }
function nM(e = [], t) { return me.create({ name: t, providers: [{ provide: Vp, useValue: "platform" }, { provide: za, useValue: new Set([() => Io = null]) }, ...e] }); }
function mL(e) { let t = Ya(); if (!t)
    throw new M(-401, !1); return t; }
function Ya() { return typeof ngServerMode < "u" && ngServerMode ? null : Io?.get(XT) ?? null; }
function $1() { Ya()?.destroy(); }
function vL(e = []) { if (Io)
    return Io; let t = nM(e); return (typeof ngServerMode > "u" || !ngServerMode) && (Io = t), rf(), oM(t), t; }
function U1(e) { return { provide: Gc, useValue: e, multi: !0 }; }
function oM(e) { let t = e.get(Gc, null); Ro(e, () => { t?.forEach(n => n()); }); }
function G1(e) { let { rootComponent: t, appProviders: n, platformProviders: o, platformRef: r } = e; if (P(L.BootstrapApplicationStart), typeof ngServerMode < "u" && ngServerMode && !r)
    throw new M(-401, !1); try {
    let i = r?.injector ?? vL(o), s = [La(), $c, ...n || []], a = new yr({ providers: s, parent: i, debugName: "", runEnvironmentInitializers: !1 });
    return KT({ r3Injector: a.injector, platformInjector: i, rootComponent: t });
}
catch (i) {
    return Promise.reject(i);
}
finally {
    P(L.BootstrapApplicationEnd);
} }
var mp = class {
    views = [];
    indexByContent = new Map;
    add(t) { let n = JSON.stringify(t); if (!this.indexByContent.has(n)) {
        let o = this.views.length;
        return this.views.push(t), this.indexByContent.set(n, o), o;
    } return this.indexByContent.get(n); }
    getAll() { return this.views; }
}, yL = 0;
function rM(e) { return e.ssrId || (e.ssrId = `t${yL++}`), e.ssrId; }
function iM(e, t, n) { let o = []; return jt(e, t, n, o), o.length; }
function EL(e) { let t = []; return fa(e, t), t.length; }
function sM(e, t) { let n = e[V]; return n && !n.hasAttribute(Dn) ? qa(n, e, null, t) : null; }
function aM(e, t) { let n = Lo(e[V]), o = sM(n, t); if (o === null)
    return; let r = x(n[V]), i = e[q], s = qa(r, i, null, t), a = n[C], c = `${o}|${s}`; a.setAttribute(r, zn, c); }
function W1(e, t) { let n = e.injector, o = Ny(n), r = Fr(n), i = new mp, s = new Map, a = e._views, c = n.get(Hs, Uu), l = { regular: new Set, capture: new Set }, u = new Map; e.injector.get(dt); for (let p of a) {
    let h = Zu(p);
    if (h !== null) {
        let v = { serializedViewCollection: i, corruptedTextNodes: s, isI18nHydrationEnabled: o, isIncrementalHydrationEnabled: r, i18nChildren: new Map, eventTypesToReplay: l, shouldReplayEvents: c, deferBlocks: u };
        Y(h) ? aM(h, v) : sM(h, v), ML(s, t);
    }
} let d = i.getAll(), f = n.get(tn); if (f.set(Vs, d), u.size > 0) {
    let p = {};
    for (let [h, v] of u.entries())
        p[h] = v;
    f.set(Bs, p);
} return l; }
function IL(e, t, n, o, r) { let i = [], s = ""; for (let a = k; a < e.length; a++) {
    let c = e[a], l, u, d;
    if ($e(c) && (c = c[E], Y(c))) {
        u = EL(c) + 2, aM(c, r);
        let p = Lo(c[V]);
        d = { [Ps]: p[m].ssrId, [gt]: u };
    }
    if (!d) {
        let p = c[m];
        p.type === 1 ? (l = p.ssrId, u = 1) : (l = rM(p), u = iM(p, c, p.firstChild)), d = { [Ps]: l, [gt]: u };
        let h = !1;
        if (UE(n[m], t)) {
            let v = Ie(n, t), y = le(n[m], t);
            if (r.isIncrementalHydrationEnabled && y.hydrateTriggers !== null) {
                let I = `d${r.deferBlocks.size}`;
                y.hydrateTriggers.has(7) && (h = !0);
                let A = [];
                fa(e, A);
                let oe = { [gt]: A.length, [kr]: v[Tt] }, je = DL(y.hydrateTriggers);
                je.length > 0 && (oe[Lr] = je), o !== null && (oe[Vu] = o), r.deferBlocks.set(I, oe);
                let Ae = x(e);
                Ae !== void 0 ? Ae.nodeType === Node.COMMENT_NODE && BT(Ae, I) : BT(Ae, I), h || wL(y, A, I, r), o = I, d[js] = I;
            }
            d[kr] = v[Tt];
        }
        if (!h) {
            let v = x(c[V]);
            (c[m].type !== 1 || v === null || !v.hasAttribute(Dn)) && Object.assign(d, cM(e[a], o, r));
        }
    }
    let f = JSON.stringify(d);
    if (i.length > 0 && f === s) {
        let p = i[i.length - 1];
        p[Or] ??= 1, p[Or]++;
    }
    else
        s = f, i.push(d);
} return i; }
function DL(e) { let t = new Set([0, 1, 2, 5]), n = []; for (let [o, r] of e)
    t.has(o) && (r === null ? n.push(o) : r.type === 5 ? n.push({ trigger: o, delay: r.delay }) : n.push({ trigger: o, intersectionObserverOptions: r.intersectionObserverOptions })); return n; }
function ni(e, t, n, o) { let r = t.index - E; e[xr] ??= {}, e[xr][r] ??= Dy(t, n, o); }
function cp(e, t) { let n = typeof t == "number" ? t : t.index - E; e[co] ??= [], e[co].includes(n) || e[co].push(n); }
function cM(e, t = null, n) { let o = {}, r = e[m], i = wy(r, n), s = n.shouldReplayEvents ? Bk(r, e, n.eventTypesToReplay) : null; for (let a = E; a < r.bindingStartIndex; a++) {
    let c = r.data[a], l = a - E, u = Sy(e, a, n);
    if (u) {
        o[Fs] ??= {}, o[Fs][l] = u.caseQueue;
        for (let d of u.disconnectedNodes)
            cp(o, d);
        for (let d of u.disjointNodes) {
            let f = r.data[d + E];
            ni(o, f, e, i);
        }
        continue;
    }
    if (As(c) && !uo(c)) {
        if (Y(e[a]) && c.tView && (o[Ls] ??= {}, o[Ls][l] = rM(c.tView)), go(c, e) && NL(c)) {
            cp(o, c);
            continue;
        }
        if (Array.isArray(c.projection)) {
            for (let d of c.projection)
                if (d)
                    if (!Array.isArray(d))
                        !mc(d) && !so(d) && (go(d, e) ? cp(o, d) : ni(o, d, e, i));
                    else
                        throw fy(x(e[a]));
        }
        if (CL(o, c, e, i), Y(e[a])) {
            let d = e[a][V];
            if (Array.isArray(d)) {
                let f = x(d);
                f.hasAttribute(Dn) || qa(f, d, t, n);
            }
            o[ao] ??= {}, o[ao][l] = IL(e[a], c, e, t, n);
        }
        else if (Array.isArray(e[a]) && !Jg(c)) {
            let d = x(e[a][V]);
            d.hasAttribute(Dn) || qa(d, e[a], t, n);
        }
        else if (c.type & 8)
            o[Rr] ??= {}, o[Rr][l] = iM(r, e, c.child);
        else if (c.type & 144) {
            let d = c.next;
            for (; d !== null && d.type & 144;)
                d = d.next;
            d && !so(d) && ni(o, d, e, i);
        }
        else if (c.type & 1) {
            let d = x(e[a]);
            Ju(n, d);
        }
        if (s && c.type & 2) {
            let d = x(e[a]);
            s.has(d) && Wu(d, s.get(d), t);
        }
    }
} return o; }
function CL(e, t, n, o) { mc(t) || (t.projectionNext && t.projectionNext !== t.next && !so(t.projectionNext) && ni(e, t.projectionNext, n, o), t.prev === null && t.parent !== null && go(t.parent, n) && !go(t, n) && ni(e, t, n, o)); }
function TL(e) { let t = e[F]; if (!t?.constructor)
    return !1; let n = z(t.constructor); return n?.encapsulation === Pe.ShadowDom || n?.encapsulation === Pe.ExperimentalIsolatedShadowDom; }
function qa(e, t, n, o) { let r = t[C]; if (Up(t) && !va() || TL(t))
    return r.setAttribute(e, Dn, ""), null; {
    let i = cM(t, n, o), s = o.serializedViewCollection.add(i);
    return r.setAttribute(e, zn, s.toString()), s;
} }
function BT(e, t) { e.textContent = `ngh=${t}`; }
function ML(e, t) { for (let [n, o] of e)
    n.after(t.createComment(o)); }
function NL(e) { let t = e; for (; t != null;) {
    if (ve(t))
        return !0;
    t = t.parent;
} return !1; }
function wL(e, t, n, o) { let r = Zm(e.hydrateTriggers); for (let i of r)
    o.eventTypesToReplay.regular.add(i); if (r.length > 0) {
    let i = t.filter(s => s.nodeType === Node.ELEMENT_NODE);
    for (let s of i)
        Wu(s, r, n);
} }
function z1(e) { let t = g(); for (; t;) {
    if (t[m].type === 1 && e(t[F]))
        return t[F];
    if ($e(t))
        break;
    t = tt(t);
} return null; }
var SL = "\u{1F170}\uFE0F", Za = !1;
function q1(e) { if (!Za)
    return; let { startLabel: t } = lM(e); performance.mark(t); }
function Q1(e) { if (!Za)
    return; let { startLabel: t, labelName: n, endLabel: o } = lM(e); performance.mark(o), performance.measure(n, t, o), performance.clearMarks(t), performance.clearMarks(o); }
function lM(e) { let t = `${SL}:${e}`; return { labelName: t, startLabel: `start:${t}`, endLabel: `end:${t}` }; }
var $T = !1;
function Y1() { if (!$T && (typeof performance > "u" || !performance.mark || !performance.measure)) {
    $T = !0, console.warn("Performance API is not supported on this platform");
    return;
} Za = !0; }
function Z1() { Za = !1; }
function K1(e) { }
function J1(e) { return typeof e == "boolean" ? e : e != null && e !== "false"; }
function X1(e, t = NaN) { return !isNaN(parseFloat(e)) && !isNaN(Number(e)) ? Number(e) : t; }
var lp = Symbol("NOT_SET"), uM = new Set, _L = Re(G({}, ec), { kind: "afterRenderEffectPhase", consumerIsAlwaysLive: !0, consumerAllowSignalWrites: !0, value: lp, cleanup: null, consumerMarkedDirty() { if (this.sequence.impl.executing) {
        if (this.sequence.lastPhase === null || this.sequence.lastPhase < this.phase)
            return;
        this.sequence.erroredOrDestroyed = !0;
    } this.sequence.scheduler.notify(7); }, phaseFn(e) { if (this.sequence.lastPhase = this.phase, !this.dirty)
        return this.signal; if (this.dirty = !1, this.value !== lp && !si(this))
        return this.signal; try {
        for (let r of this.cleanup ?? uM)
            r();
    }
    finally {
        this.cleanup?.clear();
    } let t = []; e !== void 0 && t.push(e), t.push(this.registerCleanupFn); let n = Co(this), o; try {
        o = this.userFn.apply(null, t);
    }
    finally {
        ii(this, n);
    } return (this.value === lp || !this.equal(this.value, o)) && (this.value = o, this.version++), this.signal; } }), vp = class extends dr {
    scheduler;
    lastPhase = null;
    nodes = [void 0, void 0, void 0, void 0];
    onDestroyFns = null;
    constructor(t, n, o, r, i, s = null) { super(t, [void 0, void 0, void 0, void 0], o, !1, i.get(Xt), s), this.scheduler = r; for (let a of hd) {
        let c = n[a];
        if (c === void 0)
            continue;
        let l = Object.create(_L);
        l.sequence = this, l.phase = a, l.userFn = c, l.dirty = !0, l.signal = () => (ri(l), l.value), l.signal[Qe] = l, l.registerCleanupFn = u => (l.cleanup ??= new Set).add(u), this.nodes[a] = l, this.hooks[a] = u => l.phaseFn(u);
    } }
    afterRun() { super.afterRun(), this.lastPhase = null; }
    destroy() { if (this.onDestroyFns !== null)
        for (let t of this.onDestroyFns)
            t(); super.destroy(); for (let t of this.nodes)
        if (t)
            try {
                for (let n of t.cleanup ?? uM)
                    n();
            }
            finally {
                To(t);
            } }
};
function eF(e, t) { if (typeof ngServerMode < "u" && ngServerMode)
    return Js; let n = t?.injector ?? D(me), o = n.get(Ot), r = n.get(Ks), i = n.get(Mn, null, { optional: !0 }); r.impl ??= n.get(gd); let s = e; typeof s == "function" && (s = { mixedReadWrite: e }); let a = n.get(Ai, null, { optional: !0 }), c = new vp(r.impl, [s.earlyRead, s.write, s.mixedReadWrite, s.read], a?.view, o, n, i?.snapshot(null)); return r.impl.register(c), c; }
function tF(e) { return Q({ usage: 1, kind: "directive", type: e.type }).compileDirectiveDeclaration(he, `ng:///${e.type.name}/\u0275fac.js`, e); }
function nF(e) { zd(e.type, e.decorators, e.ctorParameters ?? null, e.propDecorators ?? null); }
function oF(e) { wE(e.type, e.resolveDeferredDeps, (...t) => { let n = e.resolveMetadata(...t); zd(e.type, n.decorators, n.ctorParameters, n.propDecorators); }); }
function rF(e) { return Q({ usage: 1, kind: "component", type: e.type }).compileComponentDeclaration(he, `ng:///${e.type.name}/\u0275cmp.js`, e); }
function iF(e) { return Q({ usage: 1, kind: bL(e.target), type: e.type }).compileFactoryDeclaration(he, `ng:///${e.type.name}/\u0275fac.js`, e); }
function bL(e) { switch (e) {
    case wn.Directive: return "directive";
    case wn.Component: return "component";
    case wn.Injectable: return "injectable";
    case wn.Pipe: return "pipe";
    case wn.NgModule: return "NgModule";
    case wn.Service: return "service";
} }
function sF(e) { return Q({ usage: 1, kind: "injectable", type: e.type }).compileInjectableDeclaration(he, `ng:///${e.type.name}/\u0275prov.js`, e); }
function aF(e) { return Q({ usage: 1, kind: "NgModule", type: e.type }).compileInjectorDeclaration(he, `ng:///${e.type.name}/\u0275inj.js`, e); }
function cF(e) { return Q({ usage: 1, kind: "NgModule", type: e.type }).compileNgModuleDeclaration(he, `ng:///${e.type.name}/\u0275mod.js`, e); }
function lF(e) { return Q({ usage: 1, kind: "pipe", type: e.type }).compilePipeDeclaration(he, `ng:///${e.type.name}/\u0275pipe.js`, e); }
function uF(e) { return Q({ usage: 1, kind: "service", type: e.type }).compileServiceDeclaration(he, `ng:///${e.type.name}/\u0275prov.js`, e); }
function dF(e) { let t = Zd(e); if (!t)
    throw dM(e); return new eo(t); }
function fF(e) { let t = Zd(e); if (!t)
    throw dM(e); return t; }
function dM(e) { return new M(920, !1); }
var yp = class extends Zk {
}, UT = class extends yp {
}, pF = gL(null, "core", []);
function hF(e, t) { let n = z(e), o = t.elementInjector || yi(); return new gn(n).create(o, t.projectableNodes, t.hostElement, t.environmentInjector, t.directives, t.bindings); }
function gF(e) { let t = z(e); if (!t)
    return null; let n = new gn(t); return { get selector() { return n.selector; }, get type() { return n.componentType; }, get inputs() { return n.inputs; }, get outputs() { return n.outputs; }, get ngContentSelectors() { return n.ngContentSelectors; }, get isStandalone() { return t.standalone; }, get isSignal() { return t.signals; } }; }
function AL(e) { return new Ep(zc(e) ? e : nn(e)); }
var Ep = class {
    snapshot;
    constructor(t) { this.snapshot = t; }
    get state() { return this.snapshot(); }
    value = nn(() => { if (this.state.status === "error")
        throw new Ch(this.state.error); return this.state.value; });
    status = nn(() => this.state.status);
    error = nn(() => this.state.status === "error" ? this.state.error : void 0);
    isLoading = nn(() => this.state.status === "loading" || this.state.status === "reloading");
    isValueDefined = nn(() => this.state.status !== "error" && this.state.value !== void 0);
    hasValue() { return this.isValueDefined(); }
};
function mF(e, t, n) { if (Th())
    throw Mh(); let o = n?.injector ?? D(me), r, i; o.get(Xt).onDestroy(() => { r = void 0; }); let s = Dh({ source: () => { try {
        return Uo(!0), { value: e(), thrown: !1 };
    }
    catch (a) {
        return Yc(a), { error: a, thrown: !0 };
    }
    finally {
        Uo(!1);
    } }, computation: (a, c) => c !== void 0 ? c.value : a.thrown ? { status: "error", error: a.error } : { status: "resolved", value: a.value } }); return Eh(() => { let a; try {
    Uo(!0), a = e();
}
catch (f) {
    Yc(f), s.set({ status: "error", error: f }), r = i = void 0;
    return;
}
finally {
    Uo(!1);
} let c = Ih(s), l = n?.equal ?? Object.is; if (c.status === "reloading" || c.status === "loading") {
    if (l(a, i))
        return;
}
else if (c.status === "resolved" && l(a, c.value))
    return; let d = (typeof t == "number" ? () => new Promise(f => setTimeout(f, t)) : t)(a, c); d === void 0 ? (s.set({ status: "resolved", value: a }), r = i = void 0) : (c.status !== "loading" && c.status !== "error" && s.set({ status: "loading", value: c.value }), r = d, i = a, d.then(() => { r === d && (s.set({ status: "resolved", value: a }), r = i = void 0); })); }, { injector: o }), AL(s); }
function vF() { return !1; }
function yF() { }
function RL(e, t) { return Oe(this, null, function* () { if (typeof ngServerMode < "u" && ngServerMode)
    return; let n = globalThis.document.modelContext ?? globalThis.navigator.modelContext; if (!n || typeof n.registerTool != "function")
    return; let o = t ?? D(me), r = o.get(Xt), i = new AbortController, s = Re(G({}, e), { execute: (a, c) => { let l = c?.signal ? AbortSignal.any([i.signal, c.signal]) : i.signal; return Ro(o, () => e.execute(a, Re(G({}, c), { signal: l }))); } }); r.onDestroy(() => { i.abort(); }), yield n.registerTool(s, { signal: i.signal }); }); }
function EF(e) { return Be([Fp(() => { for (let t of e)
        RL(t); })]); }
export { bM as ANIMATION_MODULE_TYPE, Yr as APP_BOOTSTRAP_LISTENER, dt as APP_ID, qd as APP_INITIALIZER, Qd as ApplicationInitStatus, S1 as ApplicationModule, be as ApplicationRef, gm as Attribute, oT as COMPILER_OPTIONS, AM as CSP_NONCE, _w as CUSTOM_ELEMENTS_SCHEMA, xs as ChangeDetectionStrategy, Zk as ChangeDetectorRef, Ux as Compiler, _u as CompilerFactory, Lx as Component, Py as ComponentRef, M1 as ContentChild, T1 as ContentChildren, Wx as DEFAULT_CURRENCY_CODE, Pn as DOCUMENT, In as DebugElement, bu as DebugEventListener, Nr as DebugNode, dp as DefaultIterableDiffer, Xt as DestroyRef, tT as Directive, St as ENVIRONMENT_INITIALIZER, br as ElementRef, UT as EmbeddedViewRef, ut as EnvironmentInjector, Bc as ErrorHandler, NM as EventEmitter, f1 as HOST_TAG_NAME, hm as Host, NT as HostAttributeToken, Hx as HostBinding, Vx as HostListener, dc as INJECTOR, um as Inject, MN as Injectable, b as InjectionToken, me as Injector, Fx as Input, QT as IterableDiffers, YT as KeyValueDiffers, Jf as LOCALE_ID, Sv as MAX_ANIMATION_TIMEOUT, rT as MissingTranslationStrategy, bw as NO_ERRORS_SCHEMA, Bx as NgModule, vE as NgModuleFactory, mn as NgModuleRef, B as NgZone, dm as Optional, jx as Output, Qc as OutputEmitterRef, _M as PLATFORM_ID, Gc as PLATFORM_INITIALIZER, qc as PendingTasks, Px as Pipe, XT as PlatformRef, Do as Query, as as QueryList, _1 as REQUEST, A1 as REQUEST_CONTEXT, b1 as RESPONSE_INIT, eu as Renderer2, mr as RendererFactory2, fs as RendererStyleFlags2, FM as ResourceDependencyError, jM as ResourceParamsStatus, Fy as Sanitizer, de as SecurityContext, fm as Self, SN as Service, es as SimpleChange, pm as SkipSelf, zx as TRANSLATIONS, qx as TRANSLATIONS_FORMAT, pr as TemplateRef, CR as Testability, oI as TestabilityRegistry, tn as TransferState, lm as Type, Sp as VERSION, mM as Version, w1 as ViewChild, N1 as ViewChildren, Ca as ViewContainerRef, Pe as ViewEncapsulation, yp as ViewRef, kv as afterEveryRender, md as afterNextRender, eF as afterRenderEffect, Qx as asNativeElements, TM as assertInInjectionContext, xM as assertNotInReactiveContext, mL as assertPlatform, J1 as booleanAttribute, nn as computed, I1 as contentChild, D1 as contentChildren, hF as createComponent, Gd as createEnvironmentInjector, mA as createNgModule, hL as createPlatform, gL as createPlatformFactory, mF as debounced, RL as declareExperimentalWebMcpTool, $1 as destroyPlatform, Eh as effect, yF as enableProdMode, yR as enableProfiling, nc as forwardRef, wr as getDebugNode, dF as getModuleFactory, fF as getNgModuleById, Ya as getPlatform, CM as importProvidersFrom, D as inject, p1 as injectAsync, m1 as input, Yy as inputBinding, vF as isDevMode, zc as isSignal, wo as isStandalone, Oi as isWritableSignal, Dh as linkedSignal, Be as makeEnvironmentProviders, mh as makeStateKey, C1 as mergeApplicationConfig, v1 as model, X1 as numberAttribute, h1 as onIdle, g1 as output, Zy as outputBinding, pF as platformCore, SE as provideAppInitializer, wM as provideBrowserGlobalErrorListeners, j1 as provideCheckNoChangesConfig, Fp as provideEnvironmentInitializer, EF as provideExperimentalWebMcpTools, fN as provideIdleServiceWith, uS as provideNgReflectAttributes, U1 as providePlatformInitializer, L1 as provideStabilityDebugging, H1 as provideZoneChangeDetection, $x as provideZonelessChangeDetection, gF as reflectComponentType, W as resolveForwardRef, HM as resource, AL as resourceFromSnapshots, Ro as runInInjectionContext, rI as setTestabilityGetter, Uc as signal, jb as twoWayBinding, Ih as untracked, y1 as viewChild, E1 as viewChildren, wv as \u0275ANIMATIONS_DISABLED, Sm as \u0275AcxChangeDetectionStrategy, _m as \u0275AcxViewEncapsulation, Ks as \u0275AfterRenderManager, PM as \u0275CACHE_ACTIVE, R1 as \u0275CLIENT_RENDER_MODE_FLAG, k as \u0275CONTAINER_HEADER_OFFSET, Ot as \u0275ChangeDetectionScheduler, nR as \u0275Console, YE as \u0275ControlFlowBlockType, Jr as \u0275DEFAULT_LOCALE_ID, zE as \u0275DEFER_BLOCK_CONFIG, ZA as \u0275DEFER_BLOCK_DEPENDENCY_INTERCEPTOR, It as \u0275DEHYDRATED_BLOCK_REGISTRY, ef as \u0275DeferBlockBehavior, $ as \u0275DeferBlockState, sL as \u0275ENABLE_ROOT_COMPONENT_BOOTSTRAP, Om as \u0275EVENT_REPLAY_QUEUE, Wc as \u0275EffectScheduler, Ok as \u0275Framework, zm as \u0275HydrationStatus, OM as \u0275IMAGE_CONFIG, RM as \u0275IMAGE_CONFIG_DEFAULTS, Vp as \u0275INJECTOR_SCOPE, d1 as \u0275INPUT_SIGNAL_BRAND_WRITE_TYPE, en as \u0275INTERNAL_APPLICATION_ERROR_HANDLER, tw as \u0275IS_ENABLED_BLOCKING_INITIAL_NAVIGATION, Cn as \u0275IS_HYDRATION_DOM_REUSE_ENABLED, Gu as \u0275IS_INCREMENTAL_HYDRATION_ENABLED, Pr as \u0275JSACTION_BLOCK_ELEMENT_MAP, Qu as \u0275JSACTION_EVENT_CONTRACT, cs as \u0275LContext, Cr as \u0275LocaleDataIndex, wt as \u0275NG_COMP_DEF, _n as \u0275NG_DIR_DEF, Wt as \u0275NG_ELEMENT_ID, ic as \u0275NG_INJ_DEF, sc as \u0275NG_MOD_DEF, di as \u0275NG_PIPE_DEF, Sn as \u0275NG_PROV_DEF, Zi as \u0275NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR, j as \u0275NO_CHANGE, eo as \u0275NgModuleFactory, Vc as \u0275NoopNgZone, SL as \u0275PERFORMANCE_MARK_PREFIX, nL as \u0275PROVIDED_NG_ZONE, kM as \u0275PROVIDED_ZONELESS, Rt as \u0275PendingTasksInternal, L as \u0275ProfilerEvent, qt as \u0275R3Injector, ss as \u0275ReflectionCapabilities, gn as \u0275Render3ComponentFactory, Is as \u0275Render3ComponentRef, Xn as \u0275Render3NgModuleRef, VM as \u0275ResourceImpl, M as \u0275RuntimeError, Ky as \u0275SHARED_STYLES_HOST, Qe as \u0275SIGNAL, $m as \u0275SSR_CONTENT_INTEGRITY_MARKER, eI as \u0275TESTABILITY, tI as \u0275TESTABILITY_GETTER, WE as \u0275TimerScheduler, Zs as \u0275TracingAction, Mn as \u0275TracingService, nI as \u0275USE_PENDING_TASKS, vt as \u0275ViewRef, ai as \u0275XSS_SECURITY_URL, Fn as \u0275ZONELESS_ENABLED, dv as \u0275_sanitizeHtml, Ws as \u0275_sanitizeUrl, Ft as \u0275allLeavingAnimations, po as \u0275allowSanitizationBypassAndThrow, W1 as \u0275annotateForHydration, K1 as \u0275assertType, Lw as \u0275bypassSanitizationTrustHtml, Hw as \u0275bypassSanitizationTrustResourceUrl, Fw as \u0275bypassSanitizationTrustScript, Pw as \u0275bypassSanitizationTrustStyle, jw as \u0275bypassSanitizationTrustUrl, $M as \u0275chain, NA as \u0275clearResolutionOfComponentResourcesQueue, WC as \u0275compileComponent, Kf as \u0275compileDirective, UC as \u0275compileNgModule, GC as \u0275compileNgModuleDefs, iL as \u0275compileNgModuleFactory, eT as \u0275compilePipe, cc as \u0275convertToBitFlags, MM as \u0275createInjector, vL as \u0275createOrReusePlatformInjector, P1 as \u0275defaultIterableDiffers, F1 as \u0275defaultKeyValueDiffers, Jn as \u0275depsTracker, H_ as \u0275describeDomNode, Uy as \u0275devModeEqual, Z1 as \u0275disableProfiling, Y1 as \u0275enableProfiling, BM as \u0275encapsulateResourceError, If as \u0275findLocaleData, BC as \u0275flushModuleScopingQueueAsMuchAsPossible, _p as \u0275formatRuntimeError, Cx as \u0275generateStandaloneInDeclarationsError, CA as \u0275getAsyncClassMetadataFn, _b as \u0275getClosestComponentName, z as \u0275getComponentDef, vR as \u0275getComponentInstanceDeepLinkId, z1 as \u0275getCurrentClosestComponentInstance, Xi as \u0275getDeferBlocks, qN as \u0275getDirectives, Ar as \u0275getDocument, YN as \u0275getHostElement, yM as \u0275getInjectableDef, Ee as \u0275getLContext, tO as \u0275getLocaleCurrencyCode, qI as \u0275getLocalePluralCase, LM as \u0275getOutputDestroyRef, rv as \u0275getSanitizationBypassType, ER as \u0275getTransferState, Rw as \u0275getUnknownElementStrictMode, xw as \u0275getUnknownPropertyStrictMode, Me as \u0275global, oE as \u0275inferTagNameFromDefinition, Kk as \u0275injectChangeDetectorRef, G1 as \u0275internalCreateApplication, oL as \u0275internalProvideZoneChangeDetection, MA as \u0275isComponentDefPendingResolution, DM as \u0275isEnvironmentProviders, Th as \u0275isInParamsFunction, EM as \u0275isInjectable, rn as \u0275isNgModule, Ud as \u0275isPromise, mE as \u0275isSubscribable, N_ as \u0275isViewDirty, w_ as \u0275markForRefresh, xk as \u0275maybeUnwrapDefaultExport, at as \u0275noSideEffects, Yf as \u0275patchComponentDefWithScope, K as \u0275performanceMarkFeature, Ln as \u0275promiseWithResolvers, La as \u0275provideZonelessChangeDetectionInternal, IR as \u0275publishNonCoreGlobalUtil, pw as \u0275readHydrationInfo, eO as \u0275registerLocaleData, pt as \u0275renderDeferBlockState, Nx as \u0275resetCompiledComponents, gw as \u0275resetIncrementalHydrationEnabledWarnedForTests, fx as \u0275resetIncrementalHydrationRuntimeForTests, Ix as \u0275resetJitOptions, _E as \u0275resolveComponentResources, wA as \u0275restoreComponentResolutionQueue, bA as \u0275setAllowDuplicateNgModuleIdsForTest, gM as \u0275setAlternateWeakRefImpl, FC as \u0275setClassDebugInfo, zd as \u0275setClassMetadata, wE as \u0275setClassMetadataAsync, hM as \u0275setCurrentInjector, ew as \u0275setDocument, Uo as \u0275setInParamsFunction, IM as \u0275setInjectorProfilerContext, KI as \u0275setLocaleId, Aw as \u0275setUnknownElementStrictMode, Ow as \u0275setUnknownPropertyStrictMode, q1 as \u0275startMeasuring, Q1 as \u0275stopMeasuring, Po as \u0275store, ci as \u0275stringify, Zf as \u0275transitiveScopesFor, wa as \u0275triggerResourceLoading, vM as \u0275truncateMiddle, nO as \u0275unregisterLocaleData, st as \u0275unwrapSafeValue, SM as \u0275unwrapWritableSignal, O1 as \u0275withDomHydration, Hk as \u0275withEventReplay, x1 as \u0275withI18nSupport, k1 as \u0275withIncrementalHydration, OE as \u0275\u0275ControlFeature, lC as \u0275\u0275ExternalStylesFeature, wn as \u0275\u0275FactoryTarget, xE as \u0275\u0275HostDirectivesFeature, Kd as \u0275\u0275InheritDefinitionFeature, Qg as \u0275\u0275NgOnChangesFeature, cC as \u0275\u0275ProvidersFeature, qv as \u0275\u0275advance, Xo as \u0275\u0275animateEnter, er as \u0275\u0275animateEnterListener, tr as \u0275\u0275animateLeave, Ts as \u0275\u0275animateLeaveListener, cf as \u0275\u0275ariaProperty, iC as \u0275\u0275arrowFunction, QD as \u0275\u0275attachSourceLocations, lf as \u0275\u0275attribute, MD as \u0275\u0275classMap, xf as \u0275\u0275classProp, OI as \u0275\u0275componentInstance, kI as \u0275\u0275conditional, Sa as \u0275\u0275conditionalBranchCreate, xI as \u0275\u0275conditionalCreate, _f as \u0275\u0275contentQuery, Af as \u0275\u0275contentQuerySignal, qy as \u0275\u0275control, Wy as \u0275\u0275controlCreate, Wf as \u0275\u0275declareLet, lI as \u0275\u0275defer, QE as \u0275\u0275deferEnableTimerScheduling, pI as \u0275\u0275deferHydrateNever, NI as \u0275\u0275deferHydrateOnHover, mI as \u0275\u0275deferHydrateOnIdle, EI as \u0275\u0275deferHydrateOnImmediate, _I as \u0275\u0275deferHydrateOnInteraction, CI as \u0275\u0275deferHydrateOnTimer, RI as \u0275\u0275deferHydrateOnViewport, fI as \u0275\u0275deferHydrateWhen, TI as \u0275\u0275deferOnHover, hI as \u0275\u0275deferOnIdle, vI as \u0275\u0275deferOnImmediate, wI as \u0275\u0275deferOnInteraction, II as \u0275\u0275deferOnTimer, bI as \u0275\u0275deferOnViewport, MI as \u0275\u0275deferPrefetchOnHover, gI as \u0275\u0275deferPrefetchOnIdle, yI as \u0275\u0275deferPrefetchOnImmediate, SI as \u0275\u0275deferPrefetchOnInteraction, DI as \u0275\u0275deferPrefetchOnTimer, AI as \u0275\u0275deferPrefetchOnViewport, dI as \u0275\u0275deferPrefetchWhen, uI as \u0275\u0275deferWhen, EE as \u0275\u0275defineComponent, DE as \u0275\u0275defineDirective, ae as \u0275\u0275defineInjectable, Mo as \u0275\u0275defineInjector, Wd as \u0275\u0275defineNgModule, CE as \u0275\u0275definePipe, Et as \u0275\u0275defineService, vo as \u0275\u0275directiveInject, Tc as \u0275\u0275disableBindings, ff as \u0275\u0275domElement, mf as \u0275\u0275domElementContainer, gf as \u0275\u0275domElementContainerEnd, Oa as \u0275\u0275domElementContainerStart, Aa as \u0275\u0275domElementEnd, ba as \u0275\u0275domElementStart, wf as \u0275\u0275domListener, yf as \u0275\u0275domProperty, Xd as \u0275\u0275domTemplate, df as \u0275\u0275element, hf as \u0275\u0275elementContainer, Kr as \u0275\u0275elementContainerEnd, Ra as \u0275\u0275elementContainerStart, _a as \u0275\u0275elementEnd, Dr as \u0275\u0275elementStart, Cc as \u0275\u0275enableBindings, pC as \u0275\u0275enableIncrementalHydrationRuntime, $I as \u0275\u0275foreignComponent, GI as \u0275\u0275foreignContent, WI as \u0275\u0275foreignContentFn, PC as \u0275\u0275getComponentDepsFactory, zI as \u0275\u0275getCurrentView, am as \u0275\u0275getInheritedFactory, jC as \u0275\u0275getReplaceMetadataURL, cD as \u0275\u0275i18n, uD as \u0275\u0275i18nApply, lD as \u0275\u0275i18nAttributes, Cf as \u0275\u0275i18nEnd, Tf as \u0275\u0275i18nExp, dD as \u0275\u0275i18nPostprocess, Df as \u0275\u0275i18nStart, He as \u0275\u0275inject, Rs as \u0275\u0275injectAttribute, YD as \u0275\u0275interpolate, ZD as \u0275\u0275interpolate1, KD as \u0275\u0275interpolate2, JD as \u0275\u0275interpolate3, XD as \u0275\u0275interpolate4, eC as \u0275\u0275interpolate5, tC as \u0275\u0275interpolate6, nC as \u0275\u0275interpolate7, oC as \u0275\u0275interpolate8, rC as \u0275\u0275interpolateV, Jy as \u0275\u0275invalidFactory, pi as \u0275\u0275invalidFactoryDep, Mf as \u0275\u0275listener, mD as \u0275\u0275loadQuery, jc as \u0275\u0275namespaceHTML, Fc as \u0275\u0275namespaceMathML, Pc as \u0275\u0275namespaceSVG, fD as \u0275\u0275nextContext, nF as \u0275\u0275ngDeclareClassMetadata, oF as \u0275\u0275ngDeclareClassMetadataAsync, rF as \u0275\u0275ngDeclareComponent, tF as \u0275\u0275ngDeclareDirective, iF as \u0275\u0275ngDeclareFactory, sF as \u0275\u0275ngDeclareInjectable, aF as \u0275\u0275ngDeclareInjector, cF as \u0275\u0275ngDeclareNgModule, lF as \u0275\u0275ngDeclarePipe, uF as \u0275\u0275ngDeclareService, bC as \u0275\u0275pipe, AC as \u0275\u0275pipeBind1, RC as \u0275\u0275pipeBind2, OC as \u0275\u0275pipeBind3, xC as \u0275\u0275pipeBind4, kC as \u0275\u0275pipeBindV, hD as \u0275\u0275projection, pD as \u0275\u0275projectionDef, uf as \u0275\u0275property, hC as \u0275\u0275pureFunction0, gC as \u0275\u0275pureFunction1, mC as \u0275\u0275pureFunction2, vC as \u0275\u0275pureFunction3, yC as \u0275\u0275pureFunction4, EC as \u0275\u0275pureFunction5, IC as \u0275\u0275pureFunction6, DC as \u0275\u0275pureFunction7, CC as \u0275\u0275pureFunction8, TC as \u0275\u0275pureFunctionV, vD as \u0275\u0275queryAdvance, gD as \u0275\u0275queryRefresh, qD as \u0275\u0275readContextLet, yD as \u0275\u0275reference, Yd as \u0275\u0275registerNgModuleType, jI as \u0275\u0275repeater, FI as \u0275\u0275repeaterCreate, PI as \u0275\u0275repeaterTrackByIdentity, LI as \u0275\u0275repeaterTrackByIndex, HC as \u0275\u0275replaceMetadata, wc as \u0275\u0275resetView, cd as \u0275\u0275resolveBody, Tv as \u0275\u0275resolveDocument, Cv as \u0275\u0275resolveWindow, Nc as \u0275\u0275restoreView, od as \u0275\u0275sanitizeHtml, qs as \u0275\u0275sanitizeResourceUrl, sd as \u0275\u0275sanitizeScript, rd as \u0275\u0275sanitizeStyle, id as \u0275\u0275sanitizeUrl, Ev as \u0275\u0275sanitizeUrlOrResourceUrl, uC as \u0275\u0275setComponentScope, dC as \u0275\u0275setNgModuleScope, zD as \u0275\u0275storeLet, TD as \u0275\u0275styleMap, Of as \u0275\u0275styleProp, Nf as \u0275\u0275syntheticHostListener, Ef as \u0275\u0275syntheticHostProperty, Jd as \u0275\u0275template, LC as \u0275\u0275templateRefExtractor, OD as \u0275\u0275text, kf as \u0275\u0275textInterpolate, xa as \u0275\u0275textInterpolate1, Lf as \u0275\u0275textInterpolate2, Pf as \u0275\u0275textInterpolate3, Ff as \u0275\u0275textInterpolate4, jf as \u0275\u0275textInterpolate5, Hf as \u0275\u0275textInterpolate6, Vf as \u0275\u0275textInterpolate7, Bf as \u0275\u0275textInterpolate8, $f as \u0275\u0275textInterpolateV, vv as \u0275\u0275trustConstantHtml, yv as \u0275\u0275trustConstantResourceUrl, GD as \u0275\u0275twoWayBindingSet, Gf as \u0275\u0275twoWayListener, Uf as \u0275\u0275twoWayProperty, ad as \u0275\u0275validateAttribute, bf as \u0275\u0275viewQuery, Rf as \u0275\u0275viewQuerySignal };
/*! Bundled license information:

@angular/core/fesm2022/_attribute-chunk.mjs:
@angular/core/fesm2022/_debug_node-chunk.mjs:
@angular/core/fesm2022/primitives-event-dispatch.mjs:
@angular/core/fesm2022/core.mjs:
  (**
   * @license Angular v22.1.4
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
