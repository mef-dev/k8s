import { a } from "@nf-internal/chunk-J7MGAFUJ";
import { a as n } from "@nf-internal/chunk-FTMITMCZ";
import { a as l, b as c, c as o, d as _, e as d } from "@nf-internal/chunk-BZLND6O7";
import "@nf-internal/chunk-2NFLSA4Y";
import { Subject as m } from "rxjs";
var r = class {
    _multiple;
    _emitChanges;
    compareWith;
    _selection = new Set;
    _deselectedToEmit = [];
    _selectedToEmit = [];
    _selected = null;
    get selected() { return this._selected || (this._selected = Array.from(this._selection.values())), this._selected; }
    changed = new m;
    bulk = { select: e => this._select(e), deselect: e => this._deselect(e), setSelection: e => this._setSelection(e) };
    constructor(e = !1, t, s = !0, h) { this._multiple = e, this._emitChanges = s, this.compareWith = h, t && t.length && (e ? t.forEach(i => this._markSelected(i)) : this._markSelected(t[0]), this._selectedToEmit.length = 0); }
    select(...e) { return this._select(e); }
    deselect(...e) { return this._deselect(e); }
    setSelection(...e) { return this._setSelection(e); }
    toggle(e) { return this.isSelected(e) ? this.deselect(e) : this.select(e); }
    clear(e = !0) { this._unmarkAll(); let t = this._hasQueuedChanges(); return e && this._emitChangeEvent(), t; }
    isSelected(e) { return this._selection.has(this._getConcreteValue(e)); }
    isEmpty() { return this._selection.size === 0; }
    hasValue() { return !this.isEmpty(); }
    sort(e) { this._multiple && this.selected && this._selected.sort(e); }
    isMultipleSelection() { return this._multiple; }
    _select(e) { this._verifyValueAssignment(e), e.forEach(s => this._markSelected(s)); let t = this._hasQueuedChanges(); return this._emitChangeEvent(), t; }
    _deselect(e) { this._verifyValueAssignment(e), e.forEach(s => this._unmarkSelected(s)); let t = this._hasQueuedChanges(); return this._emitChangeEvent(), t; }
    _setSelection(e) { this._verifyValueAssignment(e); let t = this.selected, s = new Set(e.map(i => this._getConcreteValue(i))); e.forEach(i => this._markSelected(i)), t.filter(i => !s.has(this._getConcreteValue(i, s))).forEach(i => this._unmarkSelected(i)); let h = this._hasQueuedChanges(); return this._emitChangeEvent(), h; }
    _emitChangeEvent() { this._selected = null, (this._selectedToEmit.length || this._deselectedToEmit.length) && (this.changed.next({ source: this, added: this._selectedToEmit, removed: this._deselectedToEmit }), this._deselectedToEmit = [], this._selectedToEmit = []); }
    _markSelected(e) { e = this._getConcreteValue(e), this.isSelected(e) || (this._multiple || this._unmarkAll(), this.isSelected(e) || this._selection.add(e), this._emitChanges && this._selectedToEmit.push(e)); }
    _unmarkSelected(e) { e = this._getConcreteValue(e), this.isSelected(e) && (this._selection.delete(e), this._emitChanges && this._deselectedToEmit.push(e)); }
    _unmarkAll() { this.isEmpty() || this._selection.forEach(e => this._unmarkSelected(e)); }
    _verifyValueAssignment(e) { e.length > 1 && this._multiple; }
    _hasQueuedChanges() { return !!(this._deselectedToEmit.length || this._selectedToEmit.length); }
    _getConcreteValue(e, t) { if (this.compareWith) {
        t = t ?? this._selection;
        for (let s of t)
            if (this.compareWith(e, s))
                return s;
        return e;
    }
    else
        return e; }
};
function u() { return Error("Cannot pass multiple values into SelectionModel with single-value mode."); }
import "rxjs";
import "@angular/core";
export { o as ArrayDataSource, l as DataSource, r as SelectionModel, n as UniqueSelectionDispatcher, a as _DisposeViewRepeaterStrategy, d as _RecycleViewRepeaterStrategy, _ as _ViewRepeaterOperation, u as getMultipleValuesInSingleSelectionError, c as isDataSource };
