import { a as P, b as z, c as B, d as V, e as x, f as $, g as v, h as j, i as G, j as Y, k as q, l as F, m as X, n as K, o as W, p as Z, q as J } from "@nf-internal/chunk-2EQKKAX7";
import { DOCUMENT as S, \u0275getDOM as R } from "@angular/common";
import { \u0275getDOM as Fe } from "@angular/common";
import * as s from "@angular/core";
import { inject as p, \u0275RuntimeError as h, \u0275global as E, ApplicationRef as H, makeEnvironmentProviders as Q, \u0275CACHE_ACTIVE as w, APP_BOOTSTRAP_LISTENER as ee, \u0275withDomHydration as te, \u0275withIncrementalHydration as O, \u0275withEventReplay as ne, \u0275withI18nSupport as re, ENVIRONMENT_INITIALIZER as _e, \u0275IS_ENABLED_BLOCKING_INITIAL_NAVIGATION as Ie, \u0275Console as Ce, \u0275formatRuntimeError as Me, SecurityContext as c, \u0275allowSanitizationBypassAndThrow as f, \u0275unwrapSafeValue as d, \u0275_sanitizeUrl as ie, \u0275_sanitizeHtml as oe, \u0275bypassSanitizationTrustHtml as ae, \u0275bypassSanitizationTrustStyle as se, \u0275bypassSanitizationTrustScript as ce, \u0275bypassSanitizationTrustUrl as ue, \u0275bypassSanitizationTrustResourceUrl as le, Version as fe } from "@angular/core";
import { \u0275withHttpTransferCache as A } from "@angular/common/http";
var He = (() => { class e {
    _doc = p(S);
    _dom = R();
    _cachedHead;
    addTag(t, n = !1) { return t ? this._getOrCreateElement(t, n) : null; }
    addTags(t, n = !1) { return t.filter(i => !!i).map(i => this._getOrCreateElement(i, n)); }
    getTag(t) { if (!t)
        return null; let n = this._doc.querySelector(_(t)); return b(n) ? n : null; }
    getTags(t) { if (!t)
        return []; let n = this._doc.querySelectorAll(_(t)); return n ? Array.from(n).filter(i => b(i)) : []; }
    updateTag(t, n) { C(t), n ??= M(t); let i = this.getTag(n); return i ? (I(t, i), i) : this._getOrCreateElement(t, !0); }
    removeTag(t) { this.removeTagElement(this.getTag(t)); }
    removeTagElement(t) { t && this._dom.remove(t); }
    _getOrCreateElement(t, n = !1) { if (C(t), !n) {
        let m = M(t), l = this.getTags(m).filter(U => pe(t, U))[0];
        if (l !== void 0)
            return l;
    } let i = this._dom.createElement("meta"); return I(t, i), this._doc.getElementsByTagName("head")[0].appendChild(i), i; }
    static \u0275fac = function (n) { return new (n || e); };
    static \u0275prov = s.\u0275\u0275defineService({ token: e, factory: e.\u0275fac });
} return e; })();
function _(e) { return `meta[${e}]`; }
function I(e, r) { Object.keys(e).forEach(t => r.setAttribute(T(t), e[t])); }
function C(e) { for (let r of Object.keys(e))
    if (T(r).toLowerCase().startsWith("on"))
        throw new h(5203, !1); }
function M(e) { let r = e.name ? "name" : "property"; return `${r}=${de(String(e[r]))}`; }
function de(e) { return `"${e.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`; }
function pe(e, r) { return Object.keys(e).every(t => r.getAttribute(T(t)) === e[t]); }
function T(e) { return Object.hasOwn(N, e) ? N[e] : e; }
function b(e) { return e?.nodeName.toLowerCase() === "meta"; }
var N = { httpEquiv: "http-equiv" }, Oe = (() => { class e {
    _doc;
    constructor(t) { this._doc = t; }
    getTitle() { return this._doc.title; }
    setTitle(t) { this._doc.title = t || ""; }
    static \u0275fac = function (n) { return new (n || e)(s.\u0275\u0275inject(S)); };
    static \u0275prov = s.\u0275\u0275defineInjectable({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
function L(e, r) { if (typeof COMPILED > "u" || !COMPILED) {
    let t = E.ng = E.ng || {};
    t[e] = r;
} }
var g = class {
    msPerTick;
    numTicks;
    constructor(r, t) { this.msPerTick = r, this.numTicks = t; }
}, y = class {
    appRef;
    constructor(r) { this.appRef = r.injector.get(H); }
    timeChangeDetection(r) { let t = r && r.record, n = "Change Detection"; t && "profile" in console && typeof console.profile == "function" && console.profile(n); let i = performance.now(), o = 0; for (; o < 5 || performance.now() - i < 500;)
        this.appRef.tick(), o++; let m = performance.now(); t && "profileEnd" in console && typeof console.profileEnd == "function" && console.profileEnd(n); let l = (m - i) / o; return console.log(`ran ${o} change detection cycles`), console.log(`${l.toFixed(2)} ms per check`), new g(l, o); }
}, k = "profiler";
function Ae(e) { return L(k, new y(e)), e; }
function Le() { L(k, null); }
var D = class {
    static all() { return () => !0; }
    static css(r) { return t => t.nativeElement != null ? he(t.nativeElement, r) : !1; }
    static directive(r) { return t => t.providerTokens.indexOf(r) !== -1; }
};
function he(e, r) { return R().isElementNode(e) ? e.matches && e.matches(r) || e.msMatchesSelector && e.msMatchesSelector(r) || e.webkitMatchesSelector && e.webkitMatchesSelector(r) : !1; }
var ke = (() => { class e {
    namespacePrefix = p(v, { optional: !0 }) ?? "";
    namespace(t) { return this.namespacePrefix ? `--${this.namespacePrefix}${t.substring(2)}` : t; }
    static \u0275fac = function (n) { return new (n || e); };
    static \u0275prov = s.\u0275\u0275defineService({ token: e, factory: e.\u0275fac });
} return e; })(), a = (function (e) { return e[e.NoHttpTransferCache = 0] = "NoHttpTransferCache", e[e.HttpTransferCacheOptions = 1] = "HttpTransferCacheOptions", e[e.I18nSupport = 2] = "I18nSupport", e[e.EventReplay = 3] = "EventReplay", e[e.IncrementalHydration = 4] = "IncrementalHydration", e[e.NoIncrementalHydration = 5] = "NoIncrementalHydration", e; })(a || {});
function u(e, r = [], t = {}) { return { \u0275kind: e, \u0275providers: r }; }
function Ue() { return u(a.NoHttpTransferCache); }
function Pe(e) { return u(a.HttpTransferCacheOptions, A(e)); }
function ze() { return u(a.I18nSupport, re()); }
function Be() { return u(a.EventReplay, ne()); }
function Ve() { return u(a.IncrementalHydration, O()); }
function xe() { return u(a.NoIncrementalHydration); }
function $e(...e) { let r = [], t = new Set; for (let { \u0275providers: i, \u0275kind: o } of e)
    t.add(o), i.length && r.push(i); let n = t.has(a.HttpTransferCacheOptions); return Q([[], [], te(), t.has(a.NoHttpTransferCache) || n ? [] : A({}), t.has(a.NoIncrementalHydration) ? [] : O(), r, { provide: w, useValue: { isActive: !0 } }, { provide: ee, multi: !0, useFactory: () => { let i = p(H), o = p(w); return () => { i.whenStable().then(() => { o.isActive = !1; }); }; } }]); }
var me = (() => { class e {
    static \u0275fac = function (n) { return new (n || e); };
    static \u0275prov = s.\u0275\u0275defineInjectable({ token: e, factory: function (n) { let i = null; return n ? i = new (n || e) : i = s.\u0275\u0275inject(ge), i; }, providedIn: "root" });
} return e; })(), ge = (() => { class e extends me {
    _doc = p(S);
    sanitize(t, n) { if (n == null)
        return null; switch (t) {
        case c.NONE: return n;
        case c.HTML: return f(n, "HTML") ? d(n) : oe(this._doc, String(n)).toString();
        case c.STYLE: return f(n, "Style") ? d(n) : n;
        case c.SCRIPT:
            if (f(n, "Script"))
                return d(n);
            throw new h(5200, !1);
        case c.URL: return f(n, "URL") ? d(n) : ie(String(n));
        case c.RESOURCE_URL:
            if (f(n, "ResourceURL"))
                return d(n);
            throw new h(-5201, !1);
        default: throw new h(5202, !1);
    } }
    bypassSecurityTrustHtml(t) { return ae(t); }
    bypassSecurityTrustStyle(t) { return se(t); }
    bypassSecurityTrustScript(t) { return ce(t); }
    bypassSecurityTrustUrl(t) { return ue(t); }
    bypassSecurityTrustResourceUrl(t) { return le(t); }
    static \u0275fac = function (n) { return new (n || e); };
    static \u0275prov = s.\u0275\u0275defineService({ token: e, factory: e.\u0275fac });
} return e; })(), je = new fe("22.1.4");
export { J as BrowserModule, D as By, ke as CssVarNamespacer, me as DomSanitizer, B as EVENT_MANAGER_PLUGINS, V as EventManager, P as EventManagerPlugin, a as HydrationFeatureKind, He as Meta, $ as REMOVE_STYLES_ON_COMPONENT_DESTROY, Oe as Title, je as VERSION, X as bootstrapApplication, K as createApplication, Le as disableDebugTools, Ae as enableDebugTools, Z as platformBrowser, $e as provideClientHydration, j as provideCssVarNamespacing, W as provideProtractorTestingSupport, Be as withEventReplay, Pe as withHttpTransferCacheOptions, ze as withI18nSupport, Ve as withIncrementalHydration, Ue as withNoHttpTransferCache, xe as withNoIncrementalHydration, Y as \u0275BrowserDomAdapter, q as \u0275BrowserGetTestability, z as \u0275DomEventsPlugin, G as \u0275DomRendererFactory2, ge as \u0275DomSanitizerImpl, F as \u0275KeyEventsPlugin, x as \u0275SharedStylesHost, Fe as \u0275getDOM };
/*! Bundled license information:

@angular/platform-browser/fesm2022/platform-browser.mjs:
  (**
   * @license Angular v22.1.4
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
