var Ya = Object.defineProperty, qa = Object.defineProperties;
var Qa = Object.getOwnPropertyDescriptors;
var no = Object.getOwnPropertySymbols;
var Ka = Object.prototype.hasOwnProperty, Ua = Object.prototype.propertyIsEnumerable;
var oo = (n, a, e) => a in n ? Ya(n, a, { enumerable: !0, configurable: !0, writable: !0, value: e }) : n[a] = e, _ = (n, a) => { for (var e in a ||= {})
    Ka.call(a, e) && oo(n, e, a[e]); if (no)
    for (var e of no(a))
        Ua.call(a, e) && oo(n, e, a[e]); return n; }, G = (n, a) => qa(n, Qa(a));
var oi = (n, a, e) => new Promise((i, o) => { var r = c => { try {
    l(e.next(c));
}
catch (h) {
    o(h);
} }, s = c => { try {
    l(e.throw(c));
}
catch (h) {
    o(h);
} }, l = c => c.done ? i(c.value) : Promise.resolve(c.value).then(r, s); l((e = e.apply(n, a)).next()); });
import * as Re from "@angular/common";
import { CommonModule as ae, NgTemplateOutlet as bt, NgClass as kn, DOCUMENT as Ut, isPlatformBrowser as _d, NgComponentOutlet as vd } from "@angular/common";
import * as t from "@angular/core";
import { InjectionToken as k, inject as d, TemplateRef as H, ViewContainerRef as ge, DOCUMENT as ve, NgZone as K, ElementRef as x, Renderer2 as ye, EventEmitter as p, booleanAttribute as m, ChangeDetectorRef as E, HostAttributeToken as Cn, numberAttribute as S, QueryList as _t, Injector as j, Optional as yd, SkipSelf as xd, signal as B, ApplicationRef as wn, afterNextRender as Oe, input as I, computed as re, forwardRef as A, EnvironmentInjector as kd, HOST_TAG_NAME as Cd, DestroyRef as Or, PLATFORM_ID as wd, contentChildren as Sn, viewChildren as Sd, ANIMATION_MODULE_TYPE as Fr, output as rt, effect as Dd, createComponent as Md, SecurityContext as Td, linkedSignal as Ed, makeEnvironmentProviders as Id, viewChild as Nd, model as Rr } from "@angular/core";
import { CdkAccordionItem as Pd, CdkAccordion as Od } from "@angular/cdk/accordion";
import { _IdGenerator as W, FocusMonitor as Ae, FocusKeyManager as Xt, isFakeTouchstartFromScreenReader as Fd, isFakeMousedownFromScreenReader as Rd, ActiveDescendantKeyManager as Ar, CdkMonitorFocus as Ad, removeAriaReferencedId as Ne, addAriaReferencedId as Ht, CdkTrapFocus as Lr, AriaDescriber as Ld, InteractivityChecker as Bd, LiveAnnouncer as zd } from "@angular/cdk/a11y";
import { startWith as z, filter as V, take as pe, switchMap as ue, map as Br, takeUntil as O, debounceTime as zr, skip as Vr, skipWhile as Vd, tap as Hd, delay as jd } from "rxjs/operators";
import { ENTER as Q, hasModifierKey as q, SPACE as se, ESCAPE as qe, UP_ARROW as Fe, DOWN_ARROW as dt, RIGHT_ARROW as Dn, LEFT_ARROW as Mn, A as Wd, TAB as Tn, BACKSPACE as Hr, DELETE as Gd } from "@angular/cdk/keycodes";
import { Subject as D, Subscription as F, EMPTY as En, merge as R, defer as In, timer as jr, Observable as jt, of as lt, filter as ar, map as sr, startWith as Ki, switchMap as Ui, takeUntil as Ie, take as $d, BehaviorSubject as Yd, ReplaySubject as dr } from "rxjs";
import { UniqueSelectionDispatcher as Wr, SelectionModel as qd } from "@angular/cdk/collections";
import { TemplatePortal as xe, CdkPortalOutlet as Le, PortalModule as Nn, DomPortalOutlet as Qd, CdkPortal as Kd, ComponentPortal as Gr } from "@angular/cdk/portal";
import { createBlockScrollStrategy as Pn, createGlobalPositionStrategy as Zt, OverlayModule as vt, createRepositionScrollStrategy as $r, createOverlayRef as On, OverlayConfig as Yr, createFlexibleConnectedPositionStrategy as qr, ViewportRuler as Qr, ScrollDispatcher as Ud, Overlay as yt, CdkConnectedOverlay as ct, createNoopScrollStrategy as Xd, CdkOverlayOrigin as Zd } from "@angular/cdk/overlay";
import { CdkDialogContainer as Fn, Dialog as Rn, DialogConfig as Kr, DialogModule as An, DialogRef as Jd } from "@angular/cdk/dialog";
import { coerceNumberProperty as Pe, coerceArray as el } from "@angular/cdk/coercion";
import * as Ur from "@angular/cdk/scrolling";
import { CdkScrollable as tl, CdkScrollableModule as Xr, ViewportRuler as Zr } from "@angular/cdk/scrolling";
import { CdkStepLabel as il, CdkStepHeader as nl, CdkStep as lr, CdkStepper as cr, CdkStepperNext as ol, CdkStepperPrevious as rl, CdkStepperModule as al } from "@angular/cdk/stepper";
import { Platform as mt, _getEventTarget as Jr, _getShadowRoot as sl, _getFocusedElementPierceShadowDom as dl } from "@angular/cdk/platform";
import { SharedResizeObserver as ea } from "@angular/cdk/observers/private";
import { Directionality as ke, BidiModule as Qe } from "@angular/cdk/bidi";
import { NgControl as Ln, Validators as Bn, FormsModule as ll, NG_VALUE_ACCESSOR as J, NG_VALIDATORS as xt, NgForm as ta, FormGroupDirective as ia } from "@angular/forms";
import { CdkObserveContent as na } from "@angular/cdk/observers";
import { BreakpointObserver as oa, Breakpoints as Me } from "@angular/cdk/layout";
import { toObservable as mr, takeUntilDestroyed as ot } from "@angular/core/rxjs-interop";
import { DomSanitizer as cl } from "@angular/platform-browser";
import * as b from "@angular/core";
import { InjectionToken as it, inject as C, Injector as Rt, ViewContainerRef as td, EventEmitter as At, NgZone as Ei, RendererFactory2 as F0, ElementRef as Ii, ChangeDetectorRef as id, Renderer2 as Ni, booleanAttribute as Zo, QueryList as nd, signal as od, computed as rd } from "@angular/core";
import { Subject as be, merge as Jo, partition as V0 } from "rxjs";
import { startWith as Lt, debounceTime as ad, distinctUntilChanged as sd, takeUntil as ne, mergeMap as dd, mapTo as ld, mergeAll as cd, switchMap as md, skipWhile as j0, skip as W0 } from "rxjs/operators";
import * as ao from "@angular/core";
import { inject as Xa, APP_ID as Za } from "@angular/core";
var ro = new Map, fe = class n {
    _appId = Xa(Za);
    static _infix = `a${Math.floor(Math.random() * 1e5).toString()}`;
    getId(a, e = !1) { this._appId !== "ng" && (a += this._appId); let i = ro.get(a); return i === void 0 ? i = 0 : i++, ro.set(a, i), `${a}${e ? n._infix + "-" : ""}${i}`; }
    static \u0275fac = function (e) { return new (e || n); };
    static \u0275prov = ao.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
};
import * as ie from "@angular/core";
import { DOCUMENT as St, NgZone as Dt, inject as ce, Injector as c_, RendererFactory2 as xi, afterNextRender as yo, ElementRef as xo, InjectionToken as Ds, ApplicationRef as Ms, Renderer2 as Ts, ANIMATION_MODULE_TYPE as Es, EnvironmentInjector as Is, EventEmitter as u_, TemplateRef as g_, ViewContainerRef as f_, booleanAttribute as b_ } from "@angular/core";
import { Location as Ns } from "@angular/common";
import * as so from "@angular/core";
import { inject as Ja, PLATFORM_ID as es } from "@angular/core";
import { isPlatformBrowser as ts } from "@angular/common";
var ri;
try {
    ri = typeof Intl < "u" && Intl.v8BreakIterator;
}
catch {
    ri = !1;
}
var de = (() => { class n {
    _platformId = Ja(es);
    isBrowser = this._platformId ? ts(this._platformId) : typeof document == "object" && !!document;
    EDGE = this.isBrowser && /(edge)/i.test(navigator.userAgent);
    TRIDENT = this.isBrowser && /(msie|trident)/i.test(navigator.userAgent);
    BLINK = this.isBrowser && !!(window.chrome || ri) && typeof CSS < "u" && !this.EDGE && !this.TRIDENT;
    WEBKIT = this.isBrowser && /AppleWebKit/i.test(navigator.userAgent) && !this.BLINK && !this.EDGE && !this.TRIDENT;
    IOS = this.isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent) && !("MSStream" in window);
    FIREFOX = this.isBrowser && /(firefox|minefield)/i.test(navigator.userAgent);
    ANDROID = this.isBrowser && /android/i.test(navigator.userAgent) && !this.TRIDENT;
    SAFARI = this.isBrowser && /safari/i.test(navigator.userAgent) && this.WEBKIT;
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = so.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })();
var ai;
function is() { if (ai == null) {
    let n = typeof document < "u" ? document.head : null;
    ai = !!(n && (n.createShadowRoot || n.attachShadow));
} return ai; }
function lo(n) { if (is()) {
    let a = n.getRootNode ? n.getRootNode() : null;
    if (typeof ShadowRoot < "u" && ShadowRoot && a instanceof ShadowRoot)
        return a;
} return null; }
function te(n) { if (n.composedPath)
    try {
        return n.composedPath()[0];
    }
    catch { } return n.target; }
function si() { return typeof __karma__ < "u" && !!__karma__ || typeof jasmine < "u" && !!jasmine || typeof jest < "u" && !!jest || typeof Mocha < "u" && !!Mocha; }
import * as mo from "@angular/core";
import { inject as co, Injector as ns, EnvironmentInjector as os, ApplicationRef as rs, createComponent as as } from "@angular/core";
var Ct = new WeakMap, di = (() => { class n {
    _appRef;
    _injector = co(ns);
    _environmentInjector = co(os);
    load(e) { let i = this._appRef = this._appRef || this._injector.get(rs), o = Ct.get(i); o || (o = { loaders: new Set, refs: [] }, Ct.set(i, o), i.onDestroy(() => { Ct.get(i)?.refs.forEach(r => r.destroy()), Ct.delete(i); })), o.loaders.has(e) || (o.loaders.add(e), o.refs.push(as(e, { environmentInjector: this._environmentInjector }))); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = mo.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })();
import { Subject as He, Subscription as Mo } from "rxjs";
function L(n) { return n == null ? "" : typeof n == "string" ? n : `${n}px`; }
function li(n) { return Array.isArray(n) ? n : [n]; }
import * as P from "@angular/core";
import { InjectionToken as lb, forwardRef as cb, inject as we, NgZone as go, RendererFactory2 as fo, ElementRef as ub, Renderer2 as gb, DOCUMENT as gs, ChangeDetectorRef as fb, signal as bb, Injector as _b, effect as vb, ApplicationRef as yb, DestroyRef as xb, untracked as kb, afterNextRender as Cb, booleanAttribute as wb, ViewContainerRef as Eb, TemplateRef as Ib, IterableDiffers as Nb } from "@angular/core";
import { Subject as bo, of as fs, Observable as bs, Subscription as Fb, animationFrameScheduler as Rb, asapScheduler as Ab, isObservable as Lb } from "rxjs";
import { distinctUntilChanged as zb, auditTime as _o, filter as _s, startWith as Vb, takeUntil as Hb, pairwise as jb, switchMap as Wb, shareReplay as Gb } from "rxjs/operators";
import { ElementRef as ss } from "@angular/core";
function Be(n) { return n instanceof ss ? n.nativeElement : n; }
import * as ho from "@angular/core";
import { InjectionToken as ds, inject as po, DOCUMENT as ls, signal as cs, EventEmitter as ms } from "@angular/core";
var hs = new ds("cdk-dir-doc", { providedIn: "root", factory: () => po(ls) }), ps = /^(ar|ckb|dv|he|iw|fa|nqo|ps|sd|ug|ur|yi|.*[-_](Adlm|Arab|Hebr|Nkoo|Rohg|Thaa))(?!.*[-_](Latn|Cyrl)($|-|_))($|-|_)/i;
function us(n) { let a = n?.toLowerCase() || ""; return a === "auto" && typeof navigator < "u" && navigator?.language ? ps.test(navigator.language) ? "rtl" : "ltr" : a === "rtl" ? "rtl" : "ltr"; }
var ze = (() => { class n {
    get value() { return this.valueSignal(); }
    valueSignal = cs("ltr");
    change = new ms;
    constructor() { let e = po(hs, { optional: !0 }); if (e) {
        let i = e.body ? e.body.dir : null, o = e.documentElement ? e.documentElement.dir : null;
        this.valueSignal.set(us(i || o || "ltr"));
    } }
    ngOnDestroy() { this.change.complete(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = ho.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })();
var Ce;
function uo() { if (Ce == null) {
    if (typeof document != "object" || !document || typeof Element != "function" || !Element)
        return Ce = !1, Ce;
    if (document.documentElement?.style && "scrollBehavior" in document.documentElement.style)
        Ce = !0;
    else {
        let n = Element.prototype.scrollTo;
        n ? Ce = !/\{\s*\[native code\]\s*\}/.test(n.toString()) : Ce = !1;
    }
} return Ce; }
import "@angular/common";
var vs = 20, vo = (() => { class n {
    _ngZone = we(go);
    _platform = we(de);
    _renderer = we(fo).createRenderer(null, null);
    _cleanupGlobalListener;
    _scrolled = new bo;
    _scrolledCount = 0;
    scrollContainers = new Map;
    register(e) { this.scrollContainers.has(e) || this.scrollContainers.set(e, e.elementScrolled().subscribe(() => this._scrolled.next(e))); }
    deregister(e) { let i = this.scrollContainers.get(e); i && (i.unsubscribe(), this.scrollContainers.delete(e)); }
    scrolled(e = vs) { return this._platform.isBrowser ? new bs(i => { this._cleanupGlobalListener || (this._cleanupGlobalListener = this._ngZone.runOutsideAngular(() => this._renderer.listen("document", "scroll", () => this._scrolled.next()))); let o = e > 0 ? this._scrolled.pipe(_o(e)).subscribe(i) : this._scrolled.subscribe(i); return this._scrolledCount++, () => { o.unsubscribe(), this._scrolledCount--, this._scrolledCount || (this._cleanupGlobalListener?.(), this._cleanupGlobalListener = void 0); }; }) : fs(); }
    ngOnDestroy() { this._cleanupGlobalListener?.(), this._cleanupGlobalListener = void 0, this.scrollContainers.forEach((e, i) => this.deregister(i)), this._scrolled.complete(); }
    ancestorScrolled(e, i) { let o = this.getAncestorScrollContainers(e); return this.scrolled(i).pipe(_s(r => !r || o.indexOf(r) > -1)); }
    getAncestorScrollContainers(e) { let i = []; return this.scrollContainers.forEach((o, r) => { this._targetContainsElement(r, e) && i.push(r); }), i; }
    _targetContainsElement(e, i) { let o = Be(i), r = e.getElementRef().nativeElement; do
        if (o == r)
            return !0;
    while (o = o.parentElement); return !1; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = P.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })();
var ys = 20, ci = (() => { class n {
    _platform = we(de);
    _listeners;
    _viewportSize = null;
    _change = new bo;
    _document = we(gs);
    constructor() { let e = we(go), i = we(fo).createRenderer(null, null); e.runOutsideAngular(() => { if (this._platform.isBrowser) {
        let o = r => this._change.next(r);
        this._listeners = [i.listen("window", "resize", o), i.listen("window", "orientationchange", o)];
    } this.change().subscribe(() => this._viewportSize = null); }); }
    ngOnDestroy() { this._listeners?.forEach(e => e()), this._change.complete(); }
    getViewportSize() { this._viewportSize || this._updateViewportSize(); let e = { width: this._viewportSize.width, height: this._viewportSize.height }; return this._platform.isBrowser || (this._viewportSize = null), e; }
    getViewportRect() { let e = this.getViewportScrollPosition(), { width: i, height: o } = this.getViewportSize(); return { top: e.top, left: e.left, bottom: e.top + o, right: e.left + i, height: o, width: i }; }
    getViewportScrollPosition() { if (!this._platform.isBrowser)
        return { top: 0, left: 0 }; let e = this._document, i = this._getWindow(), o = e.documentElement, r = o.getBoundingClientRect(), s = -r.top || e.body?.scrollTop || i.scrollY || o.scrollTop || 0, l = -r.left || e.body?.scrollLeft || i.scrollX || o.scrollLeft || 0; return { top: s, left: l }; }
    change(e = ys) { return e > 0 ? this._change.pipe(_o(e)) : this._change; }
    _getWindow() { return this._document.defaultView || window; }
    _updateViewportSize() { let e = this._getWindow(); this._viewportSize = this._platform.isBrowser ? { width: e.innerWidth, height: e.innerHeight } : { width: 0, height: 0 }; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = P.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })();
import { filter as O_, takeWhile as F_ } from "rxjs/operators";
import * as Xe from "@angular/core";
import { ElementRef as xs, NgModuleRef as ks, Injector as Cs, EnvironmentInjector as ws, createComponent as Ss, inject as Ub, TemplateRef as Xb, ViewContainerRef as Zb, DOCUMENT as Jb, EventEmitter as e_ } from "@angular/core";
var Ue = class {
    _attachedHost = null;
    attach(a) { return this._attachedHost = a, a.attach(this); }
    detach() { let a = this._attachedHost; a != null && (this._attachedHost = null, a.detach()); }
    get isAttached() { return this._attachedHost != null; }
    setAttachedHost(a) { this._attachedHost = a; }
}, mi = class extends Ue {
    component;
    viewContainerRef;
    injector;
    projectableNodes;
    bindings;
    directives;
    constructor(a, e, i, o, r, s) { super(), this.component = a, this.viewContainerRef = e, this.injector = i, this.projectableNodes = o, this.bindings = r || null, this.directives = s || null; }
}, Ve = class extends Ue {
    templateRef;
    viewContainerRef;
    context;
    injector;
    constructor(a, e, i, o) { super(), this.templateRef = a, this.viewContainerRef = e, this.context = i, this.injector = o; }
    get origin() { return this.templateRef.elementRef; }
    attach(a, e = this.context) { return this.context = e, super.attach(a); }
    detach() { return this.context = void 0, super.detach(); }
}, hi = class extends Ue {
    element;
    constructor(a) { super(), this.element = a instanceof xs ? a.nativeElement : a; }
}, pi = class {
    _attachedPortal = null;
    _disposeFn = null;
    _isDisposed = !1;
    hasAttached() { return !!this._attachedPortal; }
    attach(a) { if (a instanceof mi)
        return this._attachedPortal = a, this.attachComponentPortal(a); if (a instanceof Ve)
        return this._attachedPortal = a, this.attachTemplatePortal(a); if (this.attachDomPortal && a instanceof hi)
        return this._attachedPortal = a, this.attachDomPortal(a); }
    attachDomPortal = null;
    detach() { this._attachedPortal && (this._attachedPortal.setAttachedHost(null), this._attachedPortal = null), this._invokeDisposeFn(); }
    dispose() { this.hasAttached() && this.detach(), this._invokeDisposeFn(), this._isDisposed = !0; }
    setDisposeFn(a) { this._disposeFn = a; }
    _invokeDisposeFn() { this._disposeFn && (this._disposeFn(), this._disposeFn = null); }
}, wt = class extends pi {
    outletElement;
    _appRef;
    _defaultInjector;
    constructor(a, e, i) { super(), this.outletElement = a, this._appRef = e, this._defaultInjector = i; }
    attachComponentPortal(a) { let e; if (a.viewContainerRef) {
        let i = a.injector || a.viewContainerRef.injector, o = i.get(ks, null, { optional: !0 }) || void 0;
        e = a.viewContainerRef.createComponent(a.component, { index: a.viewContainerRef.length, injector: i, ngModuleRef: o, projectableNodes: a.projectableNodes || void 0, bindings: a.bindings || void 0, directives: a.directives || void 0 }), this.setDisposeFn(() => e.destroy());
    }
    else {
        let i = this._appRef, o = a.injector || this._defaultInjector || Cs.NULL, r = o.get(ws, i.injector);
        e = Ss(a.component, { elementInjector: o, environmentInjector: r, projectableNodes: a.projectableNodes || void 0, bindings: a.bindings || void 0, directives: a.directives || void 0 }), i.attachView(e.hostView), this.setDisposeFn(() => { i.viewCount > 0 && i.detachView(e.hostView), e.destroy(); });
    } return this.outletElement.appendChild(this._getComponentRootNode(e)), this._attachedPortal = a, e; }
    attachTemplatePortal(a) { let e = a.viewContainerRef, i = e.createEmbeddedView(a.templateRef, a.context, { injector: a.injector }); return i.rootNodes.forEach(o => this.outletElement.appendChild(o)), i.detectChanges(), this.setDisposeFn(() => { let o = e.indexOf(i); o !== -1 && e.remove(o); }), this._attachedPortal = a, i; }
    attachDomPortal = a => { let e = a.element; e.parentNode; let i = this.outletElement.ownerDocument.createComment("dom-portal"); e.parentNode.insertBefore(i, e), this.outletElement.appendChild(e), this._attachedPortal = a, super.setDisposeFn(() => { i.parentNode && i.parentNode.replaceChild(e, i); }); };
    dispose() { super.dispose(), this.outletElement.remove(); }
    _getComponentRootNode(a) { return a.hostView.rootNodes[0]; }
};
function $(n, ...a) { return a.length ? a.some(e => n[e]) : n.altKey || n.shiftKey || n.ctrlKey || n.metaKey; }
var B_ = uo();
var ui = class {
    enable() { }
    disable() { }
    attach() { }
};
function gi(n, a) { return a.some(e => { let i = n.bottom < e.top, o = n.top > e.bottom, r = n.right < e.left, s = n.left > e.right; return i || o || r || s; }); }
function ko(n, a) { return a.some(e => { let i = n.top < e.top, o = n.bottom > e.bottom, r = n.left < e.left, s = n.right > e.right; return i || o || r || s; }); }
function To(n, a) { return new fi(n.get(vo), n.get(ci), n.get(Dt), a); }
var fi = class {
    _scrollDispatcher;
    _viewportRuler;
    _ngZone;
    _config;
    _scrollSubscription = null;
    _overlayRef;
    constructor(a, e, i, o) { this._scrollDispatcher = a, this._viewportRuler = e, this._ngZone = i, this._config = o; }
    attach(a) { this._overlayRef, this._overlayRef = a; }
    enable() { if (!this._scrollSubscription) {
        let a = this._config ? this._config.scrollThrottle : 0;
        this._scrollSubscription = this._scrollDispatcher.scrolled(a).subscribe(() => { if (this._overlayRef.updatePosition(), this._config && this._config.autoClose) {
            let e = this._overlayRef.overlayElement.getBoundingClientRect(), { width: i, height: o } = this._viewportRuler.getViewportSize();
            gi(e, [{ width: i, height: o, bottom: o, right: i, top: 0, left: 0 }]) && (this.disable(), this._ngZone.run(() => this._overlayRef.detach()));
        } });
    } }
    disable() { this._scrollSubscription && (this._scrollSubscription.unsubscribe(), this._scrollSubscription = null); }
    detach() { this.disable(), this._overlayRef = null; }
};
var Ze = class {
    positionStrategy;
    scrollStrategy = new ui;
    panelClass = "";
    hasBackdrop = !1;
    backdropClass = "cdk-overlay-dark-backdrop";
    disableAnimations;
    width;
    height;
    minWidth;
    minHeight;
    maxWidth;
    maxHeight;
    direction;
    disposeOnNavigation = !1;
    usePopover;
    eventPredicate;
    constructor(a) { if (a) {
        let e = Object.keys(a);
        for (let i of e)
            a[i] !== void 0 && (this[i] = a[i]);
    } }
};
var bi = class {
    connectionPair;
    scrollableViewProperties;
    constructor(a, e) { this.connectionPair = a, this.scrollableViewProperties = e; }
};
var Eo = (() => { class n {
    _attachedOverlays = [];
    _document = ce(St);
    _isAttached = !1;
    ngOnDestroy() { this.detach(); }
    add(e) { this.remove(e), this._attachedOverlays.push(e); }
    remove(e) { let i = this._attachedOverlays.indexOf(e); i > -1 && this._attachedOverlays.splice(i, 1), this._attachedOverlays.length === 0 && this.detach(); }
    canReceiveEvent(e, i, o) { return o.observers.length < 1 ? !1 : e.eventPredicate ? e.eventPredicate(i) : !0; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = ie.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })(), Ps = (() => { class n extends Eo {
    _ngZone = ce(Dt);
    _renderer = ce(xi).createRenderer(null, null);
    _cleanupKeydown;
    add(e) { super.add(e), this._isAttached || (this._ngZone.runOutsideAngular(() => { this._cleanupKeydown = this._renderer.listen("body", "keydown", this._keydownListener); }), this._isAttached = !0); }
    detach() { this._isAttached && (this._cleanupKeydown?.(), this._isAttached = !1); }
    _keydownListener = e => { let i = this._attachedOverlays; for (let o = i.length - 1; o > -1; o--) {
        let r = i[o];
        if (this.canReceiveEvent(r, e, r._keydownEvents)) {
            this._ngZone.run(() => r._keydownEvents.next(e));
            break;
        }
    } };
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = ie.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })(), Os = (() => { class n extends Eo {
    _platform = ce(de);
    _ngZone = ce(Dt);
    _renderer = ce(xi).createRenderer(null, null);
    _cursorOriginalValue;
    _cursorStyleIsSet = !1;
    _pointerDownEventTarget = null;
    _cleanups;
    add(e) { if (super.add(e), !this._isAttached) {
        let i = this._document.body, o = { capture: !0 }, r = this._renderer;
        this._cleanups = this._ngZone.runOutsideAngular(() => [r.listen(i, "pointerdown", this._pointerDownListener, o), r.listen(i, "click", this._clickListener, o), r.listen(i, "auxclick", this._clickListener, o), r.listen(i, "contextmenu", this._clickListener, o)]), this._platform.IOS && !this._cursorStyleIsSet && (this._cursorOriginalValue = i.style.cursor, i.style.cursor = "pointer", this._cursorStyleIsSet = !0), this._isAttached = !0;
    } }
    detach() { this._isAttached && (this._cleanups?.forEach(e => e()), this._cleanups = void 0, this._platform.IOS && this._cursorStyleIsSet && (this._document.body.style.cursor = this._cursorOriginalValue, this._cursorStyleIsSet = !1), this._isAttached = !1); }
    _pointerDownListener = e => { this._pointerDownEventTarget = te(e); };
    _clickListener = e => { let i = te(e), o = e.type === "click" && this._pointerDownEventTarget ? this._pointerDownEventTarget : i; this._pointerDownEventTarget = null; let r = this._attachedOverlays.slice(); for (let s = r.length - 1; s > -1; s--) {
        let l = r[s], c = l._outsidePointerEvents;
        if (!(!l.hasAttached() || !this.canReceiveEvent(l, e, c))) {
            if (Co(l.overlayElement, i) || Co(l.overlayElement, o))
                break;
            this._ngZone ? this._ngZone.run(() => c.next(e)) : c.next(e);
        }
    } };
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = ie.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })();
function Co(n, a) { let e = typeof ShadowRoot < "u" && ShadowRoot, i = a; for (; i;) {
    if (i === n)
        return !0;
    i = e && i instanceof ShadowRoot ? i.host : i.parentNode;
} return !1; }
var Io = (() => {
    class n {
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = ie.\u0275\u0275defineComponent({ type: n, selectors: [["ng-component"]], hostAttrs: ["cdk-overlay-style-loader", ""], decls: 0, vars: 0, template: function (i, o) { }, styles: [`.cdk-overlay-container, .cdk-global-overlay-wrapper {
  pointer-events: none;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
}

.cdk-overlay-container {
  position: fixed;
}
@layer cdk-overlay {
  .cdk-overlay-container {
    z-index: 1000;
  }
}
.cdk-overlay-container:empty {
  display: none;
}

.cdk-global-overlay-wrapper {
  display: flex;
  position: absolute;
}
@layer cdk-overlay {
  .cdk-global-overlay-wrapper {
    z-index: 1000;
  }
}

.cdk-overlay-pane {
  position: absolute;
  pointer-events: auto;
  box-sizing: border-box;
  display: flex;
  max-width: 100%;
  max-height: 100%;
}
@layer cdk-overlay {
  .cdk-overlay-pane {
    z-index: 1000;
  }
}

.cdk-overlay-backdrop {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  pointer-events: auto;
  -webkit-tap-highlight-color: transparent;
  opacity: 0;
  touch-action: manipulation;
}
@layer cdk-overlay {
  .cdk-overlay-backdrop {
    z-index: 1000;
    transition: opacity 400ms cubic-bezier(0.25, 0.8, 0.25, 1);
  }
}
@media (prefers-reduced-motion) {
  .cdk-overlay-backdrop {
    transition-duration: 1ms;
  }
}

.cdk-overlay-backdrop-showing {
  opacity: 1;
}
@media (forced-colors: active) {
  .cdk-overlay-backdrop-showing {
    opacity: 0.6;
  }
}

@layer cdk-overlay {
  .cdk-overlay-dark-backdrop {
    background: rgba(0, 0, 0, 0.32);
  }
}

.cdk-overlay-transparent-backdrop {
  transition: visibility 1ms linear, opacity 1ms linear;
  visibility: hidden;
  opacity: 1;
}
.cdk-overlay-transparent-backdrop.cdk-overlay-backdrop-showing, .cdk-high-contrast-active .cdk-overlay-transparent-backdrop {
  opacity: 0;
  visibility: visible;
}

.cdk-overlay-backdrop-noop-animation {
  transition: none;
}

.cdk-overlay-connected-position-bounding-box {
  position: absolute;
  display: flex;
  flex-direction: column;
  min-width: 1px;
  min-height: 1px;
}
@layer cdk-overlay {
  .cdk-overlay-connected-position-bounding-box {
    z-index: 1000;
  }
}

.cdk-global-scrollblock {
  position: fixed;
  width: 100%;
  overflow-y: scroll;
}

.cdk-overlay-popover {
  background: none;
  border: none;
  padding: 0;
  outline: 0;
  overflow: visible;
  position: fixed;
  pointer-events: none;
  white-space: normal;
  color: inherit;
  text-decoration: none;
  width: 100%;
  height: 100%;
  inset: auto;
  top: 0;
  left: 0;
}
.cdk-overlay-popover::backdrop {
  display: none;
}
.cdk-overlay-popover .cdk-overlay-backdrop {
  position: fixed;
  z-index: auto;
}
`], encapsulation: 2 });
    }
    return n;
})(), No = (() => { class n {
    _platform = ce(de);
    _containerElement;
    _document = ce(St);
    _styleLoader = ce(di);
    ngOnDestroy() { this._containerElement?.remove(); }
    getContainerElement() { return this._loadStyles(), this._containerElement || this._createContainer(), this._containerElement; }
    _createContainer() { let e = "cdk-overlay-container"; if (this._platform.isBrowser || si()) {
        let o = this._document.querySelectorAll(`.${e}[platform="server"], .${e}[platform="test"]`);
        for (let r = 0; r < o.length; r++)
            o[r].remove();
    } let i = this._document.createElement("div"); i.classList.add(e), si() ? i.setAttribute("platform", "test") : this._platform.isBrowser || i.setAttribute("platform", "server"), this._document.body.appendChild(i), this._containerElement = i; }
    _loadStyles() { this._styleLoader.load(Io); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = ie.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })(), _i = class {
    _renderer;
    _ngZone;
    element;
    _cleanupClick;
    _cleanupTransitionEnd;
    _fallbackTimeout;
    constructor(a, e, i, o) { this._renderer = e, this._ngZone = i, this.element = a.createElement("div"), this.element.classList.add("cdk-overlay-backdrop"), this._cleanupClick = e.listen(this.element, "click", o); }
    detach() { this._ngZone.runOutsideAngular(() => { let a = this.element; clearTimeout(this._fallbackTimeout), this._cleanupTransitionEnd?.(), this._cleanupTransitionEnd = this._renderer.listen(a, "transitionend", this.dispose), this._fallbackTimeout = setTimeout(this.dispose, 500), a.style.pointerEvents = "none", a.classList.remove("cdk-overlay-backdrop-showing"); }); }
    dispose = () => { clearTimeout(this._fallbackTimeout), this._cleanupClick?.(), this._cleanupTransitionEnd?.(), this._cleanupClick = this._cleanupTransitionEnd = this._fallbackTimeout = void 0, this.element.remove(); };
};
function ki(n) { return n && n.nodeType === 1; }
var vi = class {
    _portalOutlet;
    _host;
    _pane;
    _config;
    _ngZone;
    _keyboardDispatcher;
    _document;
    _location;
    _outsideClickDispatcher;
    _animationsDisabled;
    _injector;
    _renderer;
    _backdropClick = new He;
    _attachments = new He;
    _detachments = new He;
    _positionStrategy;
    _scrollStrategy;
    _locationChanges = Mo.EMPTY;
    _backdropRef = null;
    _detachContentMutationObserver;
    _detachContentAfterRenderRef;
    _disposed = !1;
    _previousHostParent;
    _keydownEvents = new He;
    _outsidePointerEvents = new He;
    _afterNextRenderRef;
    constructor(a, e, i, o, r, s, l, c, h, g = !1, u, f) { this._portalOutlet = a, this._host = e, this._pane = i, this._config = o, this._ngZone = r, this._keyboardDispatcher = s, this._document = l, this._location = c, this._outsideClickDispatcher = h, this._animationsDisabled = g, this._injector = u, this._renderer = f, o.scrollStrategy && (this._scrollStrategy = o.scrollStrategy, this._scrollStrategy.attach(this)), this._positionStrategy = o.positionStrategy; }
    get overlayElement() { return this._pane; }
    get backdropElement() { return this._backdropRef?.element || null; }
    get hostElement() { return this._host; }
    get eventPredicate() { return this._config?.eventPredicate || null; }
    attach(a) { if (this._disposed)
        return null; this._attachHost(); let e = this._portalOutlet.attach(a); return this._positionStrategy?.attach(this), this._updateStackingOrder(), this._updateElementSize(), this._updateElementDirection(), this._scrollStrategy && this._scrollStrategy.enable(), this._afterNextRenderRef?.destroy(), this._afterNextRenderRef = yo(() => { this.hasAttached() && this.updatePosition(); }, { injector: this._injector }), this._togglePointerEvents(!0), this._config.hasBackdrop && this._attachBackdrop(), this._config.panelClass && this._toggleClasses(this._pane, this._config.panelClass, !0), this._attachments.next(), this._completeDetachContent(), this._keyboardDispatcher.add(this), this._config.disposeOnNavigation && (this._locationChanges = this._location.subscribe(() => this.dispose())), this._outsideClickDispatcher.add(this), typeof e?.onDestroy == "function" && e.onDestroy(() => { this.hasAttached() && this._ngZone.runOutsideAngular(() => Promise.resolve().then(() => this.detach())); }), e; }
    detach() { if (!this.hasAttached())
        return; this.detachBackdrop(), this._togglePointerEvents(!1), this._positionStrategy && this._positionStrategy.detach && this._positionStrategy.detach(), this._scrollStrategy && this._scrollStrategy.disable(); let a = this._portalOutlet.detach(); return this._detachments.next(), this._completeDetachContent(), this._keyboardDispatcher.remove(this), this._detachContentWhenEmpty(), this._locationChanges.unsubscribe(), this._outsideClickDispatcher.remove(this), a; }
    dispose() { if (this._disposed)
        return; let a = this.hasAttached(); this._positionStrategy && this._positionStrategy.dispose(), this._disposeScrollStrategy(), this._backdropRef?.dispose(), this._locationChanges.unsubscribe(), this._keyboardDispatcher.remove(this), this._portalOutlet.dispose(), this._attachments.complete(), this._backdropClick.complete(), this._keydownEvents.complete(), this._outsidePointerEvents.complete(), this._outsideClickDispatcher.remove(this), this._host?.remove(), this._afterNextRenderRef?.destroy(), this._previousHostParent = this._pane = this._host = this._backdropRef = null, a && this._detachments.next(), this._detachments.complete(), this._completeDetachContent(), this._disposed = !0; }
    hasAttached() { return this._portalOutlet.hasAttached(); }
    backdropClick() { return this._backdropClick; }
    attachments() { return this._attachments; }
    detachments() { return this._detachments; }
    keydownEvents() { return this._keydownEvents; }
    outsidePointerEvents() { return this._outsidePointerEvents; }
    getConfig() { return this._config; }
    updatePosition() { this._positionStrategy && this._positionStrategy.apply(); }
    updatePositionStrategy(a) { a !== this._positionStrategy && (this._positionStrategy && this._positionStrategy.dispose(), this._positionStrategy = a, this.hasAttached() && (a.attach(this), this.updatePosition())); }
    updateSize(a) { this._config = _(_({}, this._config), a), this._updateElementSize(); }
    setDirection(a) { this._config = G(_({}, this._config), { direction: a }), this._updateElementDirection(); }
    addPanelClass(a) { this._pane && this._toggleClasses(this._pane, a, !0); }
    removePanelClass(a) { this._pane && this._toggleClasses(this._pane, a, !1); }
    getDirection() { let a = this._config.direction; return a ? typeof a == "string" ? a : a.value : "ltr"; }
    updateScrollStrategy(a) { a !== this._scrollStrategy && (this._disposeScrollStrategy(), this._scrollStrategy = a, this.hasAttached() && (a.attach(this), a.enable())); }
    _updateElementDirection() { this._host.setAttribute("dir", this.getDirection()); }
    _updateElementSize() { if (!this._pane)
        return; let a = this._pane.style; a.width = L(this._config.width), a.height = L(this._config.height), a.minWidth = L(this._config.minWidth), a.minHeight = L(this._config.minHeight), a.maxWidth = L(this._config.maxWidth), a.maxHeight = L(this._config.maxHeight); }
    _togglePointerEvents(a) { this._pane.style.pointerEvents = a ? "" : "none"; }
    _attachHost() { if (!this._host.parentElement) {
        let a = this._config.usePopover ? this._positionStrategy?.getPopoverInsertionPoint?.() : null;
        ki(a) ? a.after(this._host) : a?.type === "parent" ? a.element.appendChild(this._host) : this._previousHostParent?.appendChild(this._host);
    } if (this._config.usePopover)
        try {
            this._host.showPopover();
        }
        catch { } }
    _attachBackdrop() { let a = "cdk-overlay-backdrop-showing"; this._backdropRef?.dispose(), this._backdropRef = new _i(this._document, this._renderer, this._ngZone, e => { this._backdropClick.next(e); }), this._animationsDisabled && this._backdropRef.element.classList.add("cdk-overlay-backdrop-noop-animation"), this._config.backdropClass && this._toggleClasses(this._backdropRef.element, this._config.backdropClass, !0), this._config.usePopover ? this._host.prepend(this._backdropRef.element) : this._host.parentElement.insertBefore(this._backdropRef.element, this._host), !this._animationsDisabled && typeof requestAnimationFrame < "u" ? this._ngZone.runOutsideAngular(() => { requestAnimationFrame(() => this._backdropRef?.element.classList.add(a)); }) : this._backdropRef.element.classList.add(a); }
    _updateStackingOrder() { !this._config.usePopover && this._host.nextSibling && this._host.parentNode.appendChild(this._host); }
    detachBackdrop() { this._animationsDisabled ? (this._backdropRef?.dispose(), this._backdropRef = null) : this._backdropRef?.detach(); }
    _toggleClasses(a, e, i) { let o = li(e || []).filter(r => !!r); o.length && (i ? a.classList.add(...o) : a.classList.remove(...o)); }
    _detachContentWhenEmpty() { let a = !1; try {
        this._detachContentAfterRenderRef = yo(() => { a = !0, this._detachContent(); }, { injector: this._injector });
    }
    catch (e) {
        if (a)
            throw e;
        this._detachContent();
    } globalThis.MutationObserver && this._pane && (this._detachContentMutationObserver ||= new globalThis.MutationObserver(() => { this._detachContent(); }), this._detachContentMutationObserver.observe(this._pane, { childList: !0 })); }
    _detachContent() { (!this._pane || !this._host || this._pane.children.length === 0) && (this._pane && this._config.panelClass && this._toggleClasses(this._pane, this._config.panelClass, !1), this._host && this._host.parentElement && (this._previousHostParent = this._host.parentElement, this._host.remove()), this._completeDetachContent()); }
    _completeDetachContent() { this._detachContentAfterRenderRef?.destroy(), this._detachContentAfterRenderRef = void 0, this._detachContentMutationObserver?.disconnect(); }
    _disposeScrollStrategy() { let a = this._scrollStrategy; a?.disable(), a?.detach?.(); }
}, wo = "cdk-overlay-connected-position-bounding-box", Fs = /([A-Za-z%]+)$/;
function Po(n, a) { return new yi(a, n.get(ci), n.get(St), n.get(de), n.get(No)); }
var yi = class {
    _viewportRuler;
    _document;
    _platform;
    _overlayContainer;
    _overlayRef;
    _isInitialRender = !1;
    _lastBoundingBoxSize = { width: 0, height: 0 };
    _isPushed = !1;
    _canPush = !0;
    _growAfterOpen = !1;
    _hasFlexibleDimensions = !0;
    _positionLocked = !1;
    _originRect;
    _overlayRect;
    _viewportRect;
    _containerRect;
    _viewportMargin = 0;
    _scrollables = [];
    _preferredPositions = [];
    _origin;
    _pane;
    _isDisposed = !1;
    _boundingBox = null;
    _lastPosition = null;
    _lastScrollVisibility = null;
    _positionChanges = new He;
    _resizeSubscription = Mo.EMPTY;
    _offsetX = 0;
    _offsetY = 0;
    _transformOriginSelector;
    _appliedPanelClasses = [];
    _previousPushAmount = null;
    _popoverLocation = "global";
    positionChanges = this._positionChanges;
    get positions() { return this._preferredPositions; }
    constructor(a, e, i, o, r) { this._viewportRuler = e, this._document = i, this._platform = o, this._overlayContainer = r, this.setOrigin(a); }
    attach(a) { this._overlayRef && this._overlayRef, this._validatePositions(), a.hostElement.classList.add(wo), this._overlayRef = a, this._boundingBox = a.hostElement, this._pane = a.overlayElement, this._isDisposed = !1, this._isInitialRender = !0, this._lastPosition = null, this._resizeSubscription.unsubscribe(), this._resizeSubscription = this._viewportRuler.change().subscribe(() => { this._isInitialRender = !0, this.apply(); }); }
    apply() { if (this._isDisposed || !this._platform.isBrowser)
        return; if (!this._isInitialRender && this._positionLocked && this._lastPosition) {
        this.reapplyLastPosition();
        return;
    } this._clearPanelClasses(), this._resetOverlayElementStyles(), this._resetBoundingBoxStyles(), this._viewportRect = this._getNarrowedViewportRect(), this._originRect = this._getOriginRect(), this._overlayRect = this._pane.getBoundingClientRect(), this._containerRect = this._getContainerRect(); let a = this._originRect, e = this._overlayRect, i = this._viewportRect, o = this._containerRect, r = [], s; for (let l of this._preferredPositions) {
        let c = this._getOriginPoint(a, o, l), h = this._getOverlayPoint(c, e, l), g = this._getOverlayFit(h, e, i, l);
        if (g.isCompletelyWithinViewport) {
            this._isPushed = !1, this._applyPosition(l, c);
            return;
        }
        if (this._canFitWithFlexibleDimensions(g, h, i)) {
            r.push({ position: l, origin: c, overlayRect: e, boundingBoxRect: this._calculateBoundingBoxRect(c, l) });
            continue;
        }
        (!s || s.overlayFit.visibleArea < g.visibleArea) && (s = { overlayFit: g, overlayPoint: h, originPoint: c, position: l, overlayRect: e });
    } if (r.length) {
        let l = null, c = -1;
        for (let h of r) {
            let g = h.boundingBoxRect.width * h.boundingBoxRect.height * (h.position.weight || 1);
            g > c && (c = g, l = h);
        }
        this._isPushed = !1, this._applyPosition(l.position, l.origin);
        return;
    } if (this._canPush) {
        this._isPushed = !0, this._applyPosition(s.position, s.originPoint);
        return;
    } this._applyPosition(s.position, s.originPoint); }
    detach() { this._clearPanelClasses(), this._lastPosition = null, this._previousPushAmount = null, this._resizeSubscription.unsubscribe(); }
    dispose() { this._isDisposed || (this._boundingBox && Se(this._boundingBox.style, { top: "", left: "", right: "", bottom: "", height: "", width: "", alignItems: "", justifyContent: "" }), this._pane && this._resetOverlayElementStyles(), this._overlayRef && this._overlayRef.hostElement.classList.remove(wo), this.detach(), this._positionChanges.complete(), this._overlayRef = this._boundingBox = null, this._isDisposed = !0); }
    reapplyLastPosition() { if (this._isDisposed || !this._platform.isBrowser)
        return; let a = this._lastPosition; a ? (this._originRect = this._getOriginRect(), this._overlayRect = this._pane.getBoundingClientRect(), this._viewportRect = this._getNarrowedViewportRect(), this._containerRect = this._getContainerRect(), this._applyPosition(a, this._getOriginPoint(this._originRect, this._containerRect, a))) : this.apply(); }
    withScrollableContainers(a) { return this._scrollables = a, this; }
    withPositions(a) { return this._preferredPositions = a, a.indexOf(this._lastPosition) === -1 && (this._lastPosition = null), this._validatePositions(), this; }
    withViewportMargin(a) { return this._viewportMargin = a, this; }
    withFlexibleDimensions(a = !0) { return this._hasFlexibleDimensions = a, this; }
    withGrowAfterOpen(a = !0) { return this._growAfterOpen = a, this; }
    withPush(a = !0) { return this._canPush = a, this; }
    withLockedPosition(a = !0) { return this._positionLocked = a, this; }
    setOrigin(a) { return this._origin = a, this; }
    withDefaultOffsetX(a) { return this._offsetX = a, this; }
    withDefaultOffsetY(a) { return this._offsetY = a, this; }
    withTransformOriginOn(a) { return this._transformOriginSelector = a, this; }
    withPopoverLocation(a) { return this._popoverLocation = a, this; }
    getPopoverInsertionPoint() { return this._popoverLocation === "global" ? null : this._popoverLocation !== "inline" ? this._popoverLocation : this._origin instanceof xo ? this._origin.nativeElement : ki(this._origin) ? this._origin : null; }
    _getOriginPoint(a, e, i) { let o; if (i.originX == "center")
        o = a.left + a.width / 2;
    else {
        let s = this._isRtl() ? a.right : a.left, l = this._isRtl() ? a.left : a.right;
        o = i.originX == "start" ? s : l;
    } e.left < 0 && (o -= e.left); let r; return i.originY == "center" ? r = a.top + a.height / 2 : r = i.originY == "top" ? a.top : a.bottom, e.top < 0 && (r -= e.top), { x: o, y: r }; }
    _getOverlayPoint(a, e, i) { let o; i.overlayX == "center" ? o = -e.width / 2 : i.overlayX === "start" ? o = this._isRtl() ? -e.width : 0 : o = this._isRtl() ? 0 : -e.width; let r; return i.overlayY == "center" ? r = -e.height / 2 : r = i.overlayY == "top" ? 0 : -e.height, { x: a.x + o, y: a.y + r }; }
    _getOverlayFit(a, e, i, o) { let r = Do(e), { x: s, y: l } = a, c = this._getOffset(o, "x"), h = this._getOffset(o, "y"); c && (s += c), h && (l += h); let g = 0 - s, u = s + r.width - i.width, f = 0 - l, v = l + r.height - i.height, w = this._subtractOverflows(r.width, g, u), N = this._subtractOverflows(r.height, f, v), M = w * N; return { visibleArea: M, isCompletelyWithinViewport: r.width * r.height === M, fitsInViewportVertically: N === r.height, fitsInViewportHorizontally: w == r.width }; }
    _canFitWithFlexibleDimensions(a, e, i) { if (this._hasFlexibleDimensions) {
        let o = i.bottom - e.y, r = i.right - e.x, s = So(this._overlayRef.getConfig().minHeight), l = So(this._overlayRef.getConfig().minWidth), c = a.fitsInViewportVertically || s != null && s <= o, h = a.fitsInViewportHorizontally || l != null && l <= r;
        return c && h;
    } return !1; }
    _pushOverlayOnScreen(a, e, i) { if (this._previousPushAmount && this._positionLocked)
        return { x: a.x + this._previousPushAmount.x, y: a.y + this._previousPushAmount.y }; let o = Do(e), r = this._viewportRect, s = Math.max(a.x + o.width - r.width, 0), l = Math.max(a.y + o.height - r.height, 0), c = Math.max(r.top - i.top - a.y, 0), h = Math.max(r.left - i.left - a.x, 0), g = 0, u = 0; return o.width <= r.width ? g = h || -s : g = a.x < this._getViewportMarginStart() ? r.left - i.left - a.x : 0, o.height <= r.height ? u = c || -l : u = a.y < this._getViewportMarginTop() ? r.top - i.top - a.y : 0, this._previousPushAmount = { x: g, y: u }, { x: a.x + g, y: a.y + u }; }
    _applyPosition(a, e) { if (this._setTransformOrigin(a), this._setOverlayElementStyles(e, a), this._setBoundingBoxStyles(e, a), a.panelClass && this._addPanelClasses(a.panelClass), this._positionChanges.observers.length) {
        let i = this._getScrollVisibility();
        if (a !== this._lastPosition || !this._lastScrollVisibility || !Rs(this._lastScrollVisibility, i)) {
            let o = new bi(a, i);
            this._positionChanges.next(o);
        }
        this._lastScrollVisibility = i;
    } this._lastPosition = a, this._isInitialRender = !1; }
    _setTransformOrigin(a) { if (!this._transformOriginSelector)
        return; let e = this._boundingBox.querySelectorAll(this._transformOriginSelector), i, o = a.overlayY; a.overlayX === "center" ? i = "center" : this._isRtl() ? i = a.overlayX === "start" ? "right" : "left" : i = a.overlayX === "start" ? "left" : "right"; for (let r = 0; r < e.length; r++)
        e[r].style.transformOrigin = `${i} ${o}`; }
    _calculateBoundingBoxRect(a, e) { let i = this._viewportRect, o = this._isRtl(), r, s, l; if (e.overlayY === "top")
        s = a.y, r = i.height - s + this._getViewportMarginBottom();
    else if (e.overlayY === "bottom")
        l = i.height - a.y + this._getViewportMarginTop() + this._getViewportMarginBottom(), r = i.height - l + this._getViewportMarginTop();
    else {
        let v = Math.min(i.bottom - a.y + i.top, a.y), w = this._lastBoundingBoxSize.height;
        r = v * 2, s = a.y - v, r > w && !this._isInitialRender && !this._growAfterOpen && (s = a.y - w / 2);
    } let c = e.overlayX === "start" && !o || e.overlayX === "end" && o, h = e.overlayX === "end" && !o || e.overlayX === "start" && o, g, u, f; if (h)
        f = i.width - a.x + this._getViewportMarginStart() + this._getViewportMarginEnd(), g = a.x - this._getViewportMarginStart();
    else if (c)
        u = a.x, g = i.right - a.x - this._getViewportMarginEnd();
    else {
        let v = Math.min(i.right - a.x + i.left, a.x), w = this._lastBoundingBoxSize.width;
        g = v * 2, u = a.x - v, g > w && !this._isInitialRender && !this._growAfterOpen && (u = a.x - w / 2);
    } return { top: s, left: u, bottom: l, right: f, width: g, height: r }; }
    _setBoundingBoxStyles(a, e) { let i = this._calculateBoundingBoxRect(a, e); !this._isInitialRender && !this._growAfterOpen && (i.height = Math.min(i.height, this._lastBoundingBoxSize.height), i.width = Math.min(i.width, this._lastBoundingBoxSize.width)); let o = {}; if (this._hasExactPosition())
        o.top = o.left = "0", o.bottom = o.right = "auto", o.maxHeight = o.maxWidth = "", o.width = o.height = "100%";
    else {
        let r = this._overlayRef.getConfig().maxHeight, s = this._overlayRef.getConfig().maxWidth;
        o.width = L(i.width), o.height = L(i.height), o.top = L(i.top) || "auto", o.bottom = L(i.bottom) || "auto", o.left = L(i.left) || "auto", o.right = L(i.right) || "auto", e.overlayX === "center" ? o.alignItems = "center" : o.alignItems = e.overlayX === "end" ? "flex-end" : "flex-start", e.overlayY === "center" ? o.justifyContent = "center" : o.justifyContent = e.overlayY === "bottom" ? "flex-end" : "flex-start", r && (o.maxHeight = L(r)), s && (o.maxWidth = L(s));
    } this._lastBoundingBoxSize = i, Se(this._boundingBox.style, o); }
    _resetBoundingBoxStyles() { Se(this._boundingBox.style, { top: "0", left: "0", right: "0", bottom: "0", height: "", width: "", alignItems: "", justifyContent: "" }); }
    _resetOverlayElementStyles() { Se(this._pane.style, { top: "", left: "", bottom: "", right: "", position: "", transform: "" }); }
    _setOverlayElementStyles(a, e) { let i = {}, o = this._hasExactPosition(), r = this._hasFlexibleDimensions, s = this._overlayRef.getConfig(); if (o) {
        let g = this._viewportRuler.getViewportScrollPosition();
        Se(i, this._getExactOverlayY(e, a, g)), Se(i, this._getExactOverlayX(e, a, g));
    }
    else
        i.position = "static"; let l = "", c = this._getOffset(e, "x"), h = this._getOffset(e, "y"); c && (l += `translateX(${c}px) `), h && (l += `translateY(${h}px)`), i.transform = l.trim(), s.maxHeight && (o ? i.maxHeight = L(s.maxHeight) : r && (i.maxHeight = "")), s.maxWidth && (o ? i.maxWidth = L(s.maxWidth) : r && (i.maxWidth = "")), Se(this._pane.style, i); }
    _getExactOverlayY(a, e, i) { let o = { top: "", bottom: "" }, r = this._getOverlayPoint(e, this._overlayRect, a); if (this._isPushed && (r = this._pushOverlayOnScreen(r, this._overlayRect, i)), a.overlayY === "bottom") {
        let s = this._document.documentElement.clientHeight;
        o.bottom = `${s - (r.y + this._overlayRect.height)}px`;
    }
    else
        o.top = L(r.y); return o; }
    _getExactOverlayX(a, e, i) { let o = { left: "", right: "" }, r = this._getOverlayPoint(e, this._overlayRect, a); this._isPushed && (r = this._pushOverlayOnScreen(r, this._overlayRect, i)); let s; if (this._isRtl() ? s = a.overlayX === "end" ? "left" : "right" : s = a.overlayX === "end" ? "right" : "left", s === "right") {
        let l = this._document.documentElement.clientWidth;
        o.right = `${l - (r.x + this._overlayRect.width)}px`;
    }
    else
        o.left = L(r.x); return o; }
    _getScrollVisibility() { let a = this._getOriginRect(), e = this._pane.getBoundingClientRect(), i = this._scrollables.map(o => o.getElementRef().nativeElement.getBoundingClientRect()); return { isOriginClipped: ko(a, i), isOriginOutsideView: gi(a, i), isOverlayClipped: ko(e, i), isOverlayOutsideView: gi(e, i) }; }
    _subtractOverflows(a, ...e) { return e.reduce((i, o) => i - Math.max(o, 0), a); }
    _getNarrowedViewportRect() { let a = this._document.documentElement.clientWidth, e = this._document.documentElement.clientHeight, i = this._viewportRuler.getViewportScrollPosition(); return { top: i.top + this._getViewportMarginTop(), left: i.left + this._getViewportMarginStart(), right: i.left + a - this._getViewportMarginEnd(), bottom: i.top + e - this._getViewportMarginBottom(), width: a - this._getViewportMarginStart() - this._getViewportMarginEnd(), height: e - this._getViewportMarginTop() - this._getViewportMarginBottom() }; }
    _isRtl() { return this._overlayRef.getDirection() === "rtl"; }
    _hasExactPosition() { return !this._hasFlexibleDimensions || this._isPushed; }
    _getOffset(a, e) { return e === "x" ? a.offsetX == null ? this._offsetX : a.offsetX : a.offsetY == null ? this._offsetY : a.offsetY; }
    _validatePositions() { }
    _addPanelClasses(a) { this._pane && li(a).forEach(e => { e !== "" && this._appliedPanelClasses.indexOf(e) === -1 && (this._appliedPanelClasses.push(e), this._pane.classList.add(e)); }); }
    _clearPanelClasses() { this._pane && (this._appliedPanelClasses.forEach(a => { this._pane.classList.remove(a); }), this._appliedPanelClasses = []); }
    _getViewportMarginStart() { return typeof this._viewportMargin == "number" ? this._viewportMargin : this._viewportMargin?.start ?? 0; }
    _getViewportMarginEnd() { return typeof this._viewportMargin == "number" ? this._viewportMargin : this._viewportMargin?.end ?? 0; }
    _getViewportMarginTop() { return typeof this._viewportMargin == "number" ? this._viewportMargin : this._viewportMargin?.top ?? 0; }
    _getViewportMarginBottom() { return typeof this._viewportMargin == "number" ? this._viewportMargin : this._viewportMargin?.bottom ?? 0; }
    _getOriginRect() { let a = this._origin; if (a instanceof xo)
        return a.nativeElement.getBoundingClientRect(); if (a instanceof Element)
        return a.getBoundingClientRect(); let e = a.width || 0, i = a.height || 0; return { top: a.y, bottom: a.y + i, left: a.x, right: a.x + e, height: i, width: e }; }
    _getContainerRect() { let a = this._overlayRef.getConfig().usePopover && this._popoverLocation !== "global", e = this._overlayContainer.getContainerElement(); a && (e.style.display = "block"); let i = e.getBoundingClientRect(); return a && (e.style.display = ""), i; }
};
function Se(n, a) { for (let e in a)
    a.hasOwnProperty(e) && (n[e] = a[e]); return n; }
function So(n) { if (typeof n != "number" && n != null) {
    let [a, e] = n.split(Fs);
    return !e || e === "px" ? parseFloat(a) : null;
} return n || null; }
function Do(n) { return { top: Math.floor(n.top), right: Math.floor(n.right), bottom: Math.floor(n.bottom), left: Math.floor(n.left), width: Math.floor(n.width), height: Math.floor(n.height) }; }
function Rs(n, a) { return n === a ? !0 : n.isOriginClipped === a.isOriginClipped && n.isOriginOutsideView === a.isOriginOutsideView && n.isOverlayClipped === a.isOverlayClipped && n.isOverlayOutsideView === a.isOverlayOutsideView; }
var Ci = [{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top" }, { originX: "start", originY: "top", overlayX: "start", overlayY: "bottom" }, { originX: "end", originY: "bottom", overlayX: "end", overlayY: "top" }, { originX: "end", originY: "top", overlayX: "end", overlayY: "bottom" }], Oo = [{ originX: "end", originY: "top", overlayX: "start", overlayY: "top" }, { originX: "end", originY: "bottom", overlayX: "start", overlayY: "bottom" }, { originX: "start", originY: "top", overlayX: "end", overlayY: "top" }, { originX: "start", originY: "bottom", overlayX: "end", overlayY: "bottom" }];
var As = new Ds("OVERLAY_DEFAULT_CONFIG");
function Fo(n, a) { n.get(di).load(Io); let e = n.get(No), i = n.get(St), o = n.get(fe), r = n.get(Ms), s = n.get(ze), l = n.get(Ts, null, { optional: !0 }) || n.get(xi).createRenderer(null, null), c = new Ze(a), h = n.get(As, null, { optional: !0 })?.usePopover ?? !0; c.direction = c.direction || s.value, !i.body || !("showPopover" in i.body) ? c.usePopover = !1 : c.usePopover = a?.usePopover ?? h; let g = i.createElement("div"), u = i.createElement("div"); g.id = o.getId("cdk-overlay-"), g.classList.add("cdk-overlay-pane"), u.appendChild(g), c.usePopover && (u.setAttribute("popover", "manual"), u.classList.add("cdk-overlay-popover")); let f = c.usePopover ? c.positionStrategy?.getPopoverInsertionPoint?.() : null; return ki(f) ? f.after(u) : f?.type === "parent" ? f.element.appendChild(u) : e.getContainerElement().appendChild(u), new vi(new wt(g, r, n), u, g, c, n.get(Dt), n.get(Ps), i, n.get(Ns), n.get(Os), a?.disableAnimations ?? n.get(Es, null, { optional: !0 }) === "NoopAnimations", n.get(Is), l); }
import * as Ro from "@angular/core";
import "@angular/core";
var Mt = (() => { class n {
    _listeners = [];
    notify(e, i) { for (let o of this._listeners)
        o(e, i); }
    listen(e) { return this._listeners.push(e), () => { this._listeners = this._listeners.filter(i => e !== i); }; }
    ngOnDestroy() { this._listeners = []; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = Ro.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })();
import * as It from "@angular/core";
import { InjectionToken as Vo, inject as le, NgZone as Ho, DOCUMENT as jo, RendererFactory2 as Bs, ElementRef as J_, EventEmitter as e0 } from "@angular/core";
import { BehaviorSubject as zs, Subject as zo, of as Vs } from "rxjs";
import { skip as Hs, distinctUntilChanged as js, takeUntil as Ws } from "rxjs/operators";
function Ao(n) { return n.buttons === 0 || n.detail === 0; }
function Lo(n) { let a = n.touches && n.touches[0] || n.changedTouches && n.changedTouches[0]; return !!a && a.identifier === -1 && (a.radiusX == null || a.radiusX === 1) && (a.radiusY == null || a.radiusY === 1); }
var Je;
function Ls() { if (Je == null && typeof window < "u")
    try {
        window.addEventListener("test", null, Object.defineProperty({}, "passive", { get: () => Je = !0 }));
    }
    finally {
        Je = Je || !1;
    } return Je; }
function Bo(n) { return Ls() ? n : !!n.capture; }
var Gs = new Vo("cdk-input-modality-detector-options"), $s = { ignoreKeys: [18, 17, 224, 91, 16] }, Wo = 650, wi = { passive: !0, capture: !0 }, Nt = (() => { class n {
    _platform = le(de);
    _listenerCleanups;
    modalityDetected;
    modalityChanged;
    get mostRecentModality() { return this._modality.value; }
    _mostRecentTarget = null;
    _modality = new zs(null);
    _options;
    _lastTouchMs = 0;
    _onKeydown = e => { this._options?.ignoreKeys?.some(i => i === e.keyCode) || (this._modality.next("keyboard"), this._mostRecentTarget = te(e)); };
    _onMousedown = e => { Date.now() - this._lastTouchMs < Wo || (this._modality.next(Ao(e) ? "keyboard" : "mouse"), this._mostRecentTarget = te(e)); };
    _onTouchstart = e => { if (Lo(e)) {
        this._modality.next("keyboard");
        return;
    } this._lastTouchMs = Date.now(), this._modality.next("touch"), this._mostRecentTarget = te(e); };
    constructor() { let e = le(Ho), i = le(jo), o = le(Gs, { optional: !0 }); if (this._options = _(_({}, $s), o), this.modalityDetected = this._modality.pipe(Hs(1)), this.modalityChanged = this.modalityDetected.pipe(js()), this._platform.isBrowser) {
        let r = le(Bs).createRenderer(null, null);
        this._listenerCleanups = e.runOutsideAngular(() => [r.listen(i, "keydown", this._onKeydown, wi), r.listen(i, "mousedown", this._onMousedown, wi), r.listen(i, "touchstart", this._onTouchstart, wi)]);
    } }
    ngOnDestroy() { this._modality.complete(), this._listenerCleanups?.forEach(e => e()); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = It.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })(), Et = (function (n) { return n[n.IMMEDIATE = 0] = "IMMEDIATE", n[n.EVENTUAL = 1] = "EVENTUAL", n; })(Et || {}), Ys = new Vo("cdk-focus-monitor-default-options"), Tt = Bo({ passive: !0, capture: !0 }), Go = (() => { class n {
    _ngZone = le(Ho);
    _platform = le(de);
    _inputModalityDetector = le(Nt);
    _origin = null;
    _lastFocusOrigin = null;
    _windowFocused = !1;
    _windowFocusTimeoutId;
    _originTimeoutId;
    _originFromTouchInteraction = !1;
    _elementInfo = new Map;
    _monitoredElementCount = 0;
    _rootNodeFocusListenerCount = new Map;
    _detectionMode;
    _windowFocusListener = () => { this._windowFocused = !0, this._windowFocusTimeoutId = setTimeout(() => this._windowFocused = !1); };
    _document = le(jo);
    _stopInputModalityDetector = new zo;
    constructor() { let e = le(Ys, { optional: !0 }); this._detectionMode = e?.detectionMode || Et.IMMEDIATE; }
    _rootNodeFocusAndBlurListener = e => { let i = te(e); for (let o = i; o; o = o.parentElement)
        e.type === "focus" ? this._onFocus(e, o) : this._onBlur(e, o); };
    monitor(e, i = !1) { let o = Be(e); if (!this._platform.isBrowser || o.nodeType !== 1)
        return Vs(); let r = lo(o) || this._document, s = this._elementInfo.get(o); if (s)
        return i && (s.checkChildren = !0), s.subject; let l = { checkChildren: i, subject: new zo, rootNode: r }; return this._elementInfo.set(o, l), this._registerGlobalListeners(l), l.subject; }
    stopMonitoring(e) { let i = Be(e), o = this._elementInfo.get(i); o && (o.subject.complete(), this._setClasses(i), this._elementInfo.delete(i), this._removeGlobalListeners(o)); }
    focusVia(e, i, o) { let r = Be(e), s = this._document.activeElement; r === s ? this._getClosestElementsInfo(r).forEach(([l, c]) => this._originChanged(l, i, c)) : (this._setOrigin(i), typeof r.focus == "function" && r.focus(o)); }
    ngOnDestroy() { this._elementInfo.forEach((e, i) => this.stopMonitoring(i)); }
    _getWindow() { return this._document.defaultView || window; }
    _getFocusOrigin(e) { return this._origin ? this._originFromTouchInteraction ? this._shouldBeAttributedToTouch(e) ? "touch" : "program" : this._origin : this._windowFocused && this._lastFocusOrigin ? this._lastFocusOrigin : e && this._isLastInteractionFromInputLabel(e) ? "mouse" : "program"; }
    _shouldBeAttributedToTouch(e) { return this._detectionMode === Et.EVENTUAL || !!e?.contains(this._inputModalityDetector._mostRecentTarget); }
    _setClasses(e, i) { e.classList.toggle("cdk-focused", !!i), e.classList.toggle("cdk-touch-focused", i === "touch"), e.classList.toggle("cdk-keyboard-focused", i === "keyboard"), e.classList.toggle("cdk-mouse-focused", i === "mouse"), e.classList.toggle("cdk-program-focused", i === "program"); }
    _setOrigin(e, i = !1) { this._ngZone.runOutsideAngular(() => { if (this._origin = e, this._originFromTouchInteraction = e === "touch" && i, this._detectionMode === Et.IMMEDIATE) {
        clearTimeout(this._originTimeoutId);
        let o = this._originFromTouchInteraction ? Wo : 1;
        this._originTimeoutId = setTimeout(() => this._origin = null, o);
    } }); }
    _onFocus(e, i) { let o = this._elementInfo.get(i), r = te(e); !o || !o.checkChildren && i !== r || this._originChanged(i, this._getFocusOrigin(r), o); }
    _onBlur(e, i) { let o = this._elementInfo.get(i); !o || o.checkChildren && e.relatedTarget instanceof Node && i.contains(e.relatedTarget) || (this._setClasses(i), this._emitOrigin(o, null)); }
    _emitOrigin(e, i) { e.subject.observers.length && this._ngZone.run(() => e.subject.next(i)); }
    _registerGlobalListeners(e) { if (!this._platform.isBrowser)
        return; let i = e.rootNode, o = this._rootNodeFocusListenerCount.get(i) || 0; o || this._ngZone.runOutsideAngular(() => { i.addEventListener("focus", this._rootNodeFocusAndBlurListener, Tt), i.addEventListener("blur", this._rootNodeFocusAndBlurListener, Tt); }), this._rootNodeFocusListenerCount.set(i, o + 1), ++this._monitoredElementCount === 1 && (this._ngZone.runOutsideAngular(() => { this._getWindow().addEventListener("focus", this._windowFocusListener); }), this._inputModalityDetector.modalityDetected.pipe(Ws(this._stopInputModalityDetector)).subscribe(r => { this._setOrigin(r, !0); })); }
    _removeGlobalListeners(e) { let i = e.rootNode; if (this._rootNodeFocusListenerCount.has(i)) {
        let o = this._rootNodeFocusListenerCount.get(i);
        o > 1 ? this._rootNodeFocusListenerCount.set(i, o - 1) : (i.removeEventListener("focus", this._rootNodeFocusAndBlurListener, Tt), i.removeEventListener("blur", this._rootNodeFocusAndBlurListener, Tt), this._rootNodeFocusListenerCount.delete(i));
    } --this._monitoredElementCount || (this._getWindow().removeEventListener("focus", this._windowFocusListener), this._stopInputModalityDetector.next(), clearTimeout(this._windowFocusTimeoutId), clearTimeout(this._originTimeoutId)); }
    _originChanged(e, i, o) { this._setClasses(e, i), this._emitOrigin(o, i), this._lastFocusOrigin = i; }
    _getClosestElementsInfo(e) { let i = []; return this._elementInfo.forEach((o, r) => { (r === e || o.checkChildren && r.contains(e)) && i.push([r, o]); }), i; }
    _isLastInteractionFromInputLabel(e) { let { _mostRecentTarget: i, mostRecentModality: o } = this._inputModalityDetector; if (o !== "mouse" || !i || i === e || e.nodeName !== "INPUT" && e.nodeName !== "TEXTAREA" || e.disabled)
        return !1; let r = e.labels; if (r) {
        for (let s = 0; s < r.length; s++)
            if (r[s].contains(i))
                return !0;
    } return !1; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = It.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })();
import { signal as Yo, QueryList as qo, isSignal as Qo, effect as Zs } from "@angular/core";
import { Subscription as Js, Subject as Ko } from "rxjs";
import { Subject as $o } from "rxjs";
import { tap as qs, debounceTime as Qs, filter as Ks, map as Us } from "rxjs/operators";
var Xs = 200, Pt = class {
    _letterKeyStream = new $o;
    _items = [];
    _selectedItemIndex = -1;
    _pressedLetters = [];
    _skipPredicateFn;
    _selectedItem = new $o;
    selectedItem = this._selectedItem;
    constructor(a, e) { let i = typeof e?.debounceInterval == "number" ? e.debounceInterval : Xs; e?.skipPredicate && (this._skipPredicateFn = e.skipPredicate), this.setItems(a), this._setupKeyHandler(i); }
    destroy() { this._pressedLetters = [], this._letterKeyStream.complete(), this._selectedItem.complete(); }
    setCurrentSelectedItemIndex(a) { this._selectedItemIndex = a; }
    setItems(a) { this._items = a; }
    handleKey(a) { let e = a.keyCode; a.key && a.key.length === 1 ? this._letterKeyStream.next(a.key.toLocaleUpperCase()) : (e >= 65 && e <= 90 || e >= 48 && e <= 57) && this._letterKeyStream.next(String.fromCharCode(e)); }
    isTyping() { return this._pressedLetters.length > 0; }
    reset() { this._pressedLetters = []; }
    _setupKeyHandler(a) { this._letterKeyStream.pipe(qs(e => this._pressedLetters.push(e)), Qs(a), Ks(() => this._pressedLetters.length > 0), Us(() => this._pressedLetters.join("").toLocaleUpperCase())).subscribe(e => { for (let i = 1; i < this._items.length + 1; i++) {
        let o = (this._selectedItemIndex + i) % this._items.length, r = this._items[o];
        if (!this._skipPredicateFn?.(r) && r.getLabel?.().toLocaleUpperCase().trim().indexOf(e) === 0) {
            this._selectedItem.next(r);
            break;
        }
    } this._pressedLetters = []; }); }
};
var Ot = class {
    _items;
    _activeItemIndex = Yo(-1);
    _activeItem = Yo(null);
    _wrap = !1;
    _typeaheadSubscription = Js.EMPTY;
    _itemChangesSubscription;
    _vertical = !0;
    _horizontal = null;
    _allowedModifierKeys = [];
    _homeAndEnd = !1;
    _pageUpAndDown = { enabled: !1, delta: 10 };
    _effectRef;
    _typeahead;
    _skipPredicateFn = a => a.disabled;
    constructor(a, e) { this._items = a, a instanceof qo ? this._itemChangesSubscription = a.changes.subscribe(i => this._itemsChanged(i.toArray())) : Qo(a) && (this._effectRef = Zs(() => this._itemsChanged(a()), { injector: e })); }
    tabOut = new Ko;
    change = new Ko;
    skipPredicate(a) { return this._skipPredicateFn = a, this; }
    withWrap(a = !0) { return this._wrap = a, this; }
    withVerticalOrientation(a = !0) { return this._vertical = a, this; }
    withHorizontalOrientation(a) { return this._horizontal = a, this; }
    withAllowedModifierKeys(a) { return this._allowedModifierKeys = a, this; }
    withTypeAhead(a = 200) { this._typeaheadSubscription.unsubscribe(); let e = this._getItemsArray(); return this._typeahead = new Pt(e, { debounceInterval: typeof a == "number" ? a : void 0, skipPredicate: i => this._skipPredicateFn(i) }), this._typeaheadSubscription = this._typeahead.selectedItem.subscribe(i => { this.setActiveItem(i); }), this; }
    cancelTypeahead() { return this._typeahead?.reset(), this; }
    withHomeAndEnd(a = !0) { return this._homeAndEnd = a, this; }
    withPageUpDown(a = !0, e = 10) { return this._pageUpAndDown = { enabled: a, delta: e }, this; }
    setActiveItem(a) { let e = this._activeItem(); this.updateActiveItem(a), this._activeItem() !== e && this.change.next(this._activeItemIndex()); }
    onKeydown(a) { let e = a.keyCode, o = ["altKey", "ctrlKey", "metaKey", "shiftKey"].every(r => !a[r] || this._allowedModifierKeys.indexOf(r) > -1); switch (e) {
        case 9:
            this.tabOut.next();
            return;
        case 40: if (this._vertical && o) {
            this.setNextItemActive();
            break;
        }
        else
            return;
        case 38: if (this._vertical && o) {
            this.setPreviousItemActive();
            break;
        }
        else
            return;
        case 39: if (this._horizontal && o) {
            this._horizontal === "rtl" ? this.setPreviousItemActive() : this.setNextItemActive();
            break;
        }
        else
            return;
        case 37: if (this._horizontal && o) {
            this._horizontal === "rtl" ? this.setNextItemActive() : this.setPreviousItemActive();
            break;
        }
        else
            return;
        case 36: if (this._homeAndEnd && o) {
            this.setFirstItemActive();
            break;
        }
        else
            return;
        case 35: if (this._homeAndEnd && o) {
            this.setLastItemActive();
            break;
        }
        else
            return;
        case 33: if (this._pageUpAndDown.enabled && o) {
            let r = this._activeItemIndex() - this._pageUpAndDown.delta;
            this._setActiveItemByIndex(r > 0 ? r : 0, 1);
            break;
        }
        else
            return;
        case 34: if (this._pageUpAndDown.enabled && o) {
            let r = this._activeItemIndex() + this._pageUpAndDown.delta, s = this._getItemsArray().length;
            this._setActiveItemByIndex(r < s ? r : s - 1, -1);
            break;
        }
        else
            return;
        default:
            (o || $(a, "shiftKey")) && this._typeahead?.handleKey(a);
            return;
    } this._typeahead?.reset(), a.preventDefault(); }
    get activeItemIndex() { return this._activeItemIndex(); }
    get activeItem() { return this._activeItem(); }
    isTyping() { return !!this._typeahead && this._typeahead.isTyping(); }
    setFirstItemActive() { this._setActiveItemByIndex(0, 1); }
    setLastItemActive() { this._setActiveItemByIndex(this._getItemsArray().length - 1, -1); }
    setNextItemActive() { this._activeItemIndex() < 0 ? this.setFirstItemActive() : this._setActiveItemByDelta(1); }
    setPreviousItemActive() { this._activeItemIndex() < 0 && this._wrap ? this.setLastItemActive() : this._setActiveItemByDelta(-1); }
    updateActiveItem(a) { let e = this._getItemsArray(), i = typeof a == "number" ? a : e.indexOf(a), o = e[i]; this._activeItem.set(o ?? null), this._activeItemIndex.set(i), this._typeahead?.setCurrentSelectedItemIndex(i); }
    destroy() { this._typeaheadSubscription.unsubscribe(), this._itemChangesSubscription?.unsubscribe(), this._effectRef?.destroy(), this._typeahead?.destroy(), this.tabOut.complete(), this.change.complete(); }
    _setActiveItemByDelta(a) { this._wrap ? this._setActiveInWrapMode(a) : this._setActiveInDefaultMode(a); }
    _setActiveInWrapMode(a) { let e = this._getItemsArray(); for (let i = 1; i <= e.length; i++) {
        let o = (this._activeItemIndex() + a * i + e.length) % e.length, r = e[o];
        if (!this._skipPredicateFn(r)) {
            this.setActiveItem(o);
            return;
        }
    } }
    _setActiveInDefaultMode(a) { this._setActiveItemByIndex(this._activeItemIndex() + a, a); }
    _setActiveItemByIndex(a, e) { let i = this._getItemsArray(); if (i[a]) {
        for (; this._skipPredicateFn(i[a]);)
            if (a += e, !i[a])
                return;
        this.setActiveItem(a);
    } }
    _getItemsArray() { return Qo(this._items) ? this._items() : this._items instanceof qo ? this._items.toArray() : this._items; }
    _itemsChanged(a) { this._typeahead?.setItems(a); let e = this._activeItem(); if (e) {
        let i = a.indexOf(e);
        i > -1 && i !== this._activeItemIndex() && (this._activeItemIndex.set(i), this._typeahead?.setCurrentSelectedItemIndex(i));
    } }
};
var Ft = class extends Ot {
    _origin = "program";
    setFocusOrigin(a) { return this._origin = a, this; }
    setActiveItem(a) { super.setActiveItem(a), this.activeItem && this.activeItem.focus(this._origin); }
};
import "@angular/common";
var nt = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = b.\u0275\u0275defineDirective({ type: n, selectors: [["", "cdkMenuGroup", ""]], hostAttrs: ["role", "group", 1, "cdk-menu-group"], exportAs: ["cdkMenuGroup"], features: [b.\u0275\u0275ProvidersFeature([{ provide: Mt, useClass: Mt }])] });
} return n; })(), Bt = new it("cdk-menu"), oe = (function (n) { return n[n.nextItem = 0] = "nextItem", n[n.previousItem = 1] = "previousItem", n[n.currentItem = 2] = "currentItem", n; })(oe || {}), me = new it("cdk-menu-stack"), hd = { provide: me, useFactory: () => C(me, { optional: !0, skipSelf: !0 }) || new Pi }, pd = n => ({ provide: me, useFactory: () => C(me, { optional: !0, skipSelf: !0 }) || Pi.inline(n) }), Pi = (() => { class n {
    id = C(fe).getId("cdk-menu-stack-");
    _elements = [];
    _close = new be;
    _empty = new be;
    _hasFocus = new be;
    closed = this._close;
    hasFocus = this._hasFocus.pipe(Lt(!1), ad(0), sd());
    emptied = this._empty;
    _inlineMenuOrientation = null;
    static inline(e) { let i = new n; return i._inlineMenuOrientation = e, i; }
    push(e) { this._elements.push(e); }
    close(e, i) { let { focusNextOnEmpty: o, focusParentTrigger: r } = _({}, i); if (this._elements.indexOf(e) >= 0) {
        let s;
        do
            s = this._elements.pop(), this._close.next({ item: s, focusParentTrigger: r });
        while (s !== e);
        this.isEmpty() && this._empty.next(o);
    } }
    closeSubMenuOf(e) { let i = !1; if (this._elements.indexOf(e) >= 0)
        for (i = this.peek() !== e; this.peek() !== e;)
            this._close.next({ item: this._elements.pop() }); return i; }
    closeAll(e) { let { focusNextOnEmpty: i, focusParentTrigger: o } = _({}, e); if (!this.isEmpty()) {
        for (; !this.isEmpty();) {
            let r = this._elements.pop();
            r && this._close.next({ item: r, focusParentTrigger: o });
        }
        this._empty.next(i);
    } }
    isEmpty() { return !this._elements.length; }
    length() { return this._elements.length; }
    peek() { return this._elements[this._elements.length - 1]; }
    hasInlineMenu() { return this._inlineMenuOrientation != null; }
    inlineMenuOrientation() { return this._inlineMenuOrientation; }
    setHasFocus(e) { this._hasFocus.next(e); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = b.\u0275\u0275defineService({ token: n, factory: n.\u0275fac, autoProvided: !1 });
} return n; })(), Oi = new it("cdk-menu-trigger"), ud = new it("cdk-menu-scroll-strategy", { providedIn: "root", factory: () => { let n = C(Rt); return () => To(n); } }), gd = (() => { class n {
    static _openMenuTrigger;
    update(e) { n._openMenuTrigger !== e && (n._openMenuTrigger?.close(), n._openMenuTrigger = e); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = b.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })(), fd = (() => { class n {
    injector = C(Rt);
    viewContainerRef = C(td);
    menuStack = C(me);
    menuScrollStrategy = C(ud);
    menuPosition;
    opened = new At;
    closed = new At;
    menuTemplateRef = null;
    menuData;
    transformOriginSelector = null;
    overlayRef = null;
    destroyed = new be;
    stopOutsideClicksListener = Jo(this.closed, this.destroyed);
    childMenu;
    _menuPortal;
    _childMenuInjector;
    ngOnDestroy() { this._destroyOverlay(), this.destroyed.next(), this.destroyed.complete(); }
    isOpen() { return !!this.overlayRef?.hasAttached(); }
    registerChildMenu(e) { this.childMenu = e; }
    getMenuContentPortal() { let e = this.menuTemplateRef !== this._menuPortal?.templateRef; return this.menuTemplateRef && (!this._menuPortal || e) && (this._menuPortal = new Ve(this.menuTemplateRef, this.viewContainerRef, this.menuData, this._getChildMenuInjector())), this._menuPortal; }
    isElementInsideMenuStack(e) { for (let i = e; i; i = i?.parentElement ?? null)
        if (i.getAttribute("data-cdk-menu-stack-id") === this.menuStack.id)
            return !0; return !1; }
    _destroyOverlay() { this.overlayRef && (this.overlayRef.dispose(), this.overlayRef = null); }
    _getChildMenuInjector() { return this._childMenuInjector = this._childMenuInjector || Rt.create({ providers: [{ provide: Oi, useValue: this }, { provide: me, useValue: this.menuStack }], parent: this.injector }), this._childMenuInjector; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = b.\u0275\u0275defineDirective({ type: n, hostVars: 2, hostBindings: function (i, o) { i & 2 && b.\u0275\u0275attribute("aria-controls", o.childMenu?.id)("data-cdk-menu-stack-id", o.menuStack.id); } });
} return n; })();
var Fi = new it("cdk-menu-aim");
function er(n, a) { if (!a.isTrusted)
    return !1; let e = n.nativeElement, i = a.keyCode; return e.nodeName === "BUTTON" && !e.disabled ? i === 13 || i === 32 : e.nodeName === "A" ? i === 13 : !1; }
var Ri = (() => { class n extends fd {
    _elementRef = C(Ii);
    _ngZone = C(Ei);
    _changeDetectorRef = C(id);
    _inputModalityDetector = C(Nt);
    _directionality = C(ze, { optional: !0 });
    _renderer = C(Ni);
    _injector = C(Rt);
    _cleanupMouseenter;
    _menuTracker = C(gd);
    _parentMenu = C(Bt, { optional: !0 });
    _menuAim = C(Fi, { optional: !0 });
    constructor() { super(), this._setRole(), this._registerCloseHandler(), this._subscribeToMenuStackClosed(), this._subscribeToMouseEnter(), this._subscribeToMenuStackHasFocus(), this._setType(); }
    toggle() { this.isOpen() ? this.close() : this.open(); }
    open() { this._parentMenu || this._menuTracker.update(this), !this.isOpen() && this.menuTemplateRef != null && (this.opened.next(), this.overlayRef = this.overlayRef || Fo(this._injector, this._getOverlayConfig()), this.overlayRef.attach(this.getMenuContentPortal()), this._changeDetectorRef.markForCheck(), this._subscribeToOutsideClicks()); }
    close() { this.isOpen() && (this.closed.next(), this.overlayRef.detach(), this._changeDetectorRef.markForCheck()), this._closeSiblingTriggers(); }
    getMenu() { return this.childMenu; }
    ngOnChanges(e) { e.menuPosition && this.overlayRef && this.overlayRef.updatePositionStrategy(this._getOverlayPositionStrategy()); }
    ngOnDestroy() { this._cleanupMouseenter(), super.ngOnDestroy(); }
    _toggleOnKeydown(e) { let i = this._parentMenu?.orientation === "vertical"; switch (e.keyCode) {
        case 32:
        case 13:
            !$(e) && !er(this._elementRef, e) && (this.toggle(), this.childMenu?.focusFirstItem("keyboard"));
            break;
        case 39:
            $(e) || this._parentMenu && i && this._directionality?.value !== "rtl" && (e.preventDefault(), this.open(), this.childMenu?.focusFirstItem("keyboard"));
            break;
        case 37:
            $(e) || this._parentMenu && i && this._directionality?.value === "rtl" && (e.preventDefault(), this.open(), this.childMenu?.focusFirstItem("keyboard"));
            break;
        case 40:
        case 38:
            $(e) || i || (e.preventDefault(), this.open(), e.keyCode === 40 ? this.childMenu?.focusFirstItem("keyboard") : this.childMenu?.focusLastItem("keyboard"));
            break;
    } }
    _handleClick() { this.toggle(), this.childMenu?.focusFirstItem("mouse"); }
    _setHasFocus(e) { this._parentMenu || this.menuStack.setHasFocus(e); }
    _subscribeToMouseEnter() { this._cleanupMouseenter = this._ngZone.runOutsideAngular(() => this._renderer.listen(this._elementRef.nativeElement, "mouseenter", () => { if (this._inputModalityDetector.mostRecentModality !== "touch" && !this.menuStack.isEmpty() && !this.isOpen()) {
        let e = () => this._ngZone.run(() => { this._closeSiblingTriggers(), this.open(); });
        this._menuAim ? this._menuAim.toggle(e) : e();
    } })); }
    _closeSiblingTriggers() { this._parentMenu ? !this.menuStack.closeSubMenuOf(this._parentMenu) && this.menuStack.peek() !== this._parentMenu && this.menuStack.closeAll() : this.menuStack.closeAll(); }
    _getOverlayConfig() { return new Ze({ positionStrategy: this._getOverlayPositionStrategy(), scrollStrategy: this.menuScrollStrategy(), direction: this._directionality || void 0 }); }
    _getOverlayPositionStrategy() { let e = Po(this._injector, this._elementRef).withLockedPosition().withFlexibleDimensions(!1).withPositions(this._getOverlayPositions()); return this.transformOriginSelector && e.withTransformOriginOn(this.transformOriginSelector), e; }
    _getOverlayPositions() { return this.menuPosition ?? (!this._parentMenu || this._parentMenu.orientation === "horizontal" ? Ci : Oo); }
    _registerCloseHandler() { this._parentMenu || this.menuStack.closed.pipe(ne(this.destroyed)).subscribe(({ item: e }) => { e === this.childMenu && this.close(); }); }
    _subscribeToOutsideClicks() { this.overlayRef && this.overlayRef.outsidePointerEvents().pipe(ne(this.stopOutsideClicksListener)).subscribe(e => { let i = te(e), o = this._elementRef.nativeElement; i !== o && !o.contains(i) && (this.isElementInsideMenuStack(i) ? this._closeSiblingTriggers() : this.menuStack.closeAll()); }); }
    _subscribeToMenuStackHasFocus() { this._parentMenu || this.menuStack.hasFocus.pipe(ne(this.destroyed)).subscribe(e => { e || this.menuStack.closeAll(); }); }
    _subscribeToMenuStackClosed() { this._parentMenu || this.menuStack.closed.subscribe(({ focusParentTrigger: e }) => { e && !this.menuStack.length() && this._elementRef.nativeElement.focus(); }); }
    _setRole() { this._parentMenu || this._elementRef.nativeElement.setAttribute("role", "button"); }
    _setType() { let e = this._elementRef.nativeElement; e.nodeName === "BUTTON" && !e.getAttribute("type") && e.setAttribute("type", "button"); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = b.\u0275\u0275defineDirective({ type: n, selectors: [["", "cdkMenuTriggerFor", ""]], hostAttrs: [1, "cdk-menu-trigger"], hostVars: 2, hostBindings: function (i, o) { i & 1 && b.\u0275\u0275listener("focusin", function () { return o._setHasFocus(!0); })("focusout", function () { return o._setHasFocus(!1); })("keydown", function (s) { return o._toggleOnKeydown(s); })("click", function () { return o._handleClick(); }), i & 2 && b.\u0275\u0275attribute("aria-haspopup", o.menuTemplateRef ? "menu" : null)("aria-expanded", o.menuTemplateRef == null ? null : o.isOpen()); }, inputs: { menuTemplateRef: [0, "cdkMenuTriggerFor", "menuTemplateRef"], menuPosition: [0, "cdkMenuPosition", "menuPosition"], menuData: [0, "cdkMenuTriggerData", "menuData"], transformOriginSelector: [0, "cdkMenuTriggerTransformOriginOn", "transformOriginSelector"] }, outputs: { opened: "cdkMenuOpened", closed: "cdkMenuClosed" }, exportAs: ["cdkMenuTriggerFor"], features: [b.\u0275\u0275ProvidersFeature([{ provide: Oi, useExisting: n }, hd]), b.\u0275\u0275InheritDefinitionFeature, b.\u0275\u0275NgOnChangesFeature] });
} return n; })(), We = (() => { class n {
    _dir = C(ze, { optional: !0 });
    _elementRef = C(Ii);
    _ngZone = C(Ei);
    _inputModalityDetector = C(Nt);
    _renderer = C(Ni);
    _cleanupMouseEnter;
    _menuAim = C(Fi, { optional: !0 });
    _menuStack = C(me);
    _parentMenu = C(Bt, { optional: !0 });
    _menuTrigger = C(Ri, { optional: !0, self: !0 });
    disabled = !1;
    typeaheadLabel = null;
    triggered = new At;
    get hasMenu() { return this._menuTrigger?.menuTemplateRef != null; }
    _tabindex = -1;
    closeOnSpacebarTrigger = !0;
    destroyed = new be;
    constructor() { this._setupMouseEnter(), this._setType(), this._isStandaloneItem() && (this._tabindex = 0); }
    ngOnDestroy() { this._cleanupMouseEnter?.(), this.destroyed.next(), this.destroyed.complete(); }
    focus() { this._elementRef.nativeElement.focus(); }
    trigger(e) { let { keepOpen: i } = _({}, e); !this.disabled && !this.hasMenu && (this.triggered.next(), i || this._menuStack.closeAll({ focusParentTrigger: !0 })); }
    isMenuOpen() { return !!this._menuTrigger?.isOpen(); }
    getMenu() { return this._menuTrigger?.getMenu(); }
    getMenuTrigger() { return this._menuTrigger; }
    getLabel() { return this.typeaheadLabel || this._elementRef.nativeElement.textContent?.trim() || ""; }
    _resetTabIndex() { this._isStandaloneItem() || (this._tabindex = -1); }
    _setTabIndex(e) { this.disabled || (!e || !this._menuStack.isEmpty()) && (this._tabindex = 0); }
    _handleClick(e) { this.disabled ? (e.preventDefault(), e.stopPropagation()) : this.trigger(); }
    _onKeydown(e) { switch (e.keyCode) {
        case 32:
        case 13:
            if (!$(e) && !er(this._elementRef, e)) {
                let i = this._elementRef.nativeElement.nodeName;
                i !== "A" && i !== "BUTTON" && e.preventDefault(), this.trigger({ keepOpen: e.keyCode === 32 && !this.closeOnSpacebarTrigger });
            }
            break;
        case 39:
            $(e) || this._parentMenu && this._isParentVertical() && (this._dir?.value !== "rtl" ? this._forwardArrowPressed(e) : this._backArrowPressed(e));
            break;
        case 37:
            $(e) || this._parentMenu && this._isParentVertical() && (this._dir?.value !== "rtl" ? this._backArrowPressed(e) : this._forwardArrowPressed(e));
            break;
    } }
    _isStandaloneItem() { return !this._parentMenu; }
    _backArrowPressed(e) { let i = this._parentMenu; (this._menuStack.hasInlineMenu() || this._menuStack.length() > 1) && (e.preventDefault(), this._menuStack.close(i, { focusNextOnEmpty: this._menuStack.inlineMenuOrientation() === "horizontal" ? oe.previousItem : oe.currentItem, focusParentTrigger: !0 })); }
    _forwardArrowPressed(e) { !this.hasMenu && this._menuStack.inlineMenuOrientation() === "horizontal" && (e.preventDefault(), this._menuStack.closeAll({ focusNextOnEmpty: oe.nextItem, focusParentTrigger: !0 })); }
    _setupMouseEnter() { if (!this._isStandaloneItem()) {
        let e = () => this._ngZone.run(() => this._menuStack.closeSubMenuOf(this._parentMenu));
        this._cleanupMouseEnter = this._ngZone.runOutsideAngular(() => this._renderer.listen(this._elementRef.nativeElement, "mouseenter", () => { this._inputModalityDetector.mostRecentModality !== "touch" && !this._menuStack.isEmpty() && !this.hasMenu && (this._menuAim ? this._menuAim.toggle(e) : e()); }));
    } }
    _isParentVertical() { return this._parentMenu?.orientation === "vertical"; }
    _setType() { let e = this._elementRef.nativeElement; e.nodeName === "BUTTON" && !e.getAttribute("type") && e.setAttribute("type", "button"); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = b.\u0275\u0275defineDirective({ type: n, selectors: [["", "cdkMenuItem", ""]], hostAttrs: ["role", "menuitem", 1, "cdk-menu-item"], hostVars: 4, hostBindings: function (i, o) { i & 1 && b.\u0275\u0275listener("blur", function () { return o._resetTabIndex(); })("focus", function () { return o._setTabIndex(); })("click", function (s) { return o._handleClick(s); })("keydown", function (s) { return o._onKeydown(s); }), i & 2 && (b.\u0275\u0275domProperty("tabIndex", o._tabindex), b.\u0275\u0275attribute("aria-disabled", o.disabled || null), b.\u0275\u0275classProp("cdk-menu-item-disabled", o.disabled)); }, inputs: { disabled: [2, "cdkMenuItemDisabled", "disabled", Zo], typeaheadLabel: [0, "cdkMenuitemTypeaheadLabel", "typeaheadLabel"] }, outputs: { triggered: "cdkMenuItemTriggered" }, exportAs: ["cdkMenuItem"] });
} return n; })(), Ti = class {
    _renderer;
    _items;
    _eventCleanups;
    _itemsSubscription;
    entered = new be;
    exited = new be;
    activeElement;
    previousElement;
    constructor(a, e) { this._renderer = a, this._items = e, this._bindEvents(), this.entered.subscribe(i => this.activeElement = i), this.exited.subscribe(() => { this.previousElement = this.activeElement, this.activeElement = void 0; }); }
    destroy() { this._cleanupEvents(), this._itemsSubscription?.unsubscribe(); }
    _bindEvents() { this._itemsSubscription = this._items.changes.pipe(Lt(this._items)).subscribe(() => { this._cleanupEvents(), this._eventCleanups = [], this._items.forEach(a => { let e = a._elementRef.nativeElement; this._eventCleanups.push(this._renderer.listen(e, "mouseenter", () => { this.entered.next(a); }), this._renderer.listen(e, "mouseout", () => { this.exited.next(a); })); }); }); }
    _cleanupEvents() { this._eventCleanups?.forEach(a => a()), this._eventCleanups = void 0; }
}, tr = (() => { class n extends nt {
    _focusMonitor = C(Go);
    ngZone = C(Ei);
    _renderer = C(Ni);
    nativeElement = C(Ii).nativeElement;
    menuStack = C(me);
    menuAim = C(Fi, { optional: !0, self: !0 });
    dir = C(ze, { optional: !0 });
    _allItems;
    id = C(fe).getId("cdk-menu-");
    items = new nd;
    orientation = "vertical";
    isInline = !1;
    keyManager;
    destroyed = new be;
    triggerItem;
    pointerTracker;
    _menuStackHasFocus = od(!1);
    _tabIndexSignal = rd(() => { let e = this._menuStackHasFocus() ? -1 : 0; return this.isInline ? e : null; });
    ngAfterContentInit() { this.isInline || this.menuStack.push(this), this._setItems(), this._setKeyManager(), this._handleFocus(), this._subscribeToMenuStackHasFocus(), this._subscribeToMenuOpen(), this._subscribeToMenuStackClosed(), this._setUpPointerTracker(); }
    ngOnDestroy() { this._focusMonitor.stopMonitoring(this.nativeElement), this.keyManager?.destroy(), this.destroyed.next(), this.destroyed.complete(), this.pointerTracker?.destroy(); }
    focusFirstItem(e = "program") { this.keyManager.setFocusOrigin(e), this.keyManager.setFirstItemActive(); }
    focusLastItem(e = "program") { this.keyManager.setFocusOrigin(e), this.keyManager.setLastItemActive(); }
    setActiveMenuItem(e) { this.keyManager?.setActiveItem(e); }
    _getTabIndex() { return this._tabIndexSignal(); }
    closeOpenMenu(e, i) { let { focusParentTrigger: o } = _({}, i), r = this.keyManager, s = this.triggerItem; e === s?.getMenuTrigger()?.getMenu() && (s?.getMenuTrigger()?.close(), o && (s ? r.setActiveItem(s) : r.setFirstItemActive())); }
    _setItems() { this._allItems.changes.pipe(Lt(this._allItems), ne(this.destroyed)).subscribe(e => { this.items.reset(e.filter(i => i._parentMenu === this)), this.items.notifyOnChanges(); }); }
    _setKeyManager() { this.keyManager = new Ft(this.items).withWrap().withTypeAhead().withHomeAndEnd().skipPredicate(() => !1), this.orientation === "horizontal" ? this.keyManager.withHorizontalOrientation(this.dir?.value || "ltr") : this.keyManager.withVerticalOrientation(); }
    _subscribeToMenuOpen() { let e = Jo(this.items.changes, this.destroyed); this.items.changes.pipe(Lt(this.items), dd(i => i.filter(o => o.hasMenu).map(o => o.getMenuTrigger().opened.pipe(ld(o), ne(e)))), cd(), md(i => (this.triggerItem = i, i.getMenuTrigger().closed)), ne(this.destroyed)).subscribe(() => this.triggerItem = void 0); }
    _subscribeToMenuStackClosed() { this.menuStack.closed.pipe(ne(this.destroyed)).subscribe(({ item: e, focusParentTrigger: i }) => this.closeOpenMenu(e, { focusParentTrigger: i })); }
    _subscribeToMenuStackHasFocus() { this.isInline && this.menuStack.hasFocus.pipe(ne(this.destroyed)).subscribe(e => { this._menuStackHasFocus.set(e); }); }
    _setUpPointerTracker() { this.menuAim && (this.ngZone.runOutsideAngular(() => { this.pointerTracker = new Ti(this._renderer, this.items); }), this.menuAim.initialize(this, this.pointerTracker)); }
    _handleFocus() { this._focusMonitor.monitor(this.nativeElement, !1).pipe(ne(this.destroyed)).subscribe(e => { e !== null && e !== "mouse" && this.focusFirstItem(e); }); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = b.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = b.\u0275\u0275defineDirective({ type: n, contentQueries: function (i, o, r) { if (i & 1 && b.\u0275\u0275contentQuery(r, We, 5), i & 2) {
            let s;
            b.\u0275\u0275queryRefresh(s = b.\u0275\u0275loadQuery()) && (o._allItems = s);
        } }, hostAttrs: ["role", "menu"], hostVars: 4, hostBindings: function (i, o) { i & 1 && b.\u0275\u0275listener("focusin", function () { return o.menuStack.setHasFocus(!0); })("focusout", function () { return o.menuStack.setHasFocus(!1); }), i & 2 && (b.\u0275\u0275domProperty("tabIndex", o._getTabIndex())("id", o.id), b.\u0275\u0275attribute("aria-orientation", o.orientation)("data-cdk-menu-stack-id", o.menuStack.id)); }, inputs: { id: "id" }, features: [b.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), ir = (() => { class n extends tr {
    _parentTrigger = C(Oi, { optional: !0 });
    closed = new At;
    orientation = "vertical";
    isInline = !this._parentTrigger;
    constructor() { super(), this.destroyed.subscribe(this.closed), this._parentTrigger?.registerChildMenu(this); }
    ngAfterContentInit() { super.ngAfterContentInit(), this._subscribeToMenuStackEmptied(); }
    ngOnDestroy() { super.ngOnDestroy(), this.closed.complete(); }
    _handleKeyEvent(e) { let i = this.keyManager; switch (e.keyCode) {
        case 37:
        case 39:
            $(e) || (e.preventDefault(), i.setFocusOrigin("keyboard"), i.onKeydown(e));
            break;
        case 27:
            $(e) || (e.preventDefault(), this.menuStack.close(this, { focusNextOnEmpty: oe.currentItem, focusParentTrigger: !0 }));
            break;
        case 9:
            $(e, "altKey", "metaKey", "ctrlKey") || this.menuStack.closeAll({ focusParentTrigger: !0 });
            break;
        default: i.onKeydown(e);
    } }
    _toggleMenuFocus(e) { let i = this.keyManager; switch (e) {
        case oe.nextItem:
            i.setFocusOrigin("keyboard"), i.setNextItemActive();
            break;
        case oe.previousItem:
            i.setFocusOrigin("keyboard"), i.setPreviousItemActive();
            break;
        case oe.currentItem:
            i.activeItem && (i.setFocusOrigin("keyboard"), i.setActiveItem(i.activeItem));
            break;
    } }
    _subscribeToMenuStackEmptied() { this.menuStack.emptied.pipe(ne(this.destroyed)).subscribe(e => this._toggleMenuFocus(e)); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = b.\u0275\u0275defineDirective({ type: n, selectors: [["", "cdkMenu", ""]], hostAttrs: ["role", "menu", 1, "cdk-menu"], hostVars: 2, hostBindings: function (i, o) { i & 1 && b.\u0275\u0275listener("keydown", function (s) { return o._handleKeyEvent(s); }), i & 2 && b.\u0275\u0275classProp("cdk-menu-inline", o.isInline); }, outputs: { closed: "closed" }, exportAs: ["cdkMenu"], features: [b.\u0275\u0275ProvidersFeature([{ provide: nt, useExisting: n }, { provide: Bt, useExisting: n }, pd("vertical")]), b.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), nr = (() => { class n extends tr {
    orientation = "horizontal";
    isInline = !0;
    ngAfterContentInit() { super.ngAfterContentInit(), this._subscribeToMenuStackEmptied(); }
    _handleKeyEvent(e) { let i = this.keyManager; switch (e.keyCode) {
        case 38:
        case 40:
        case 37:
        case 39:
            if (!$(e) && (e.keyCode === 37 || e.keyCode === 39)) {
                e.preventDefault();
                let r = i.activeItem?.isMenuOpen();
                i.activeItem?.getMenuTrigger()?.close(), i.setFocusOrigin("keyboard"), i.onKeydown(e), r && i.activeItem?.getMenuTrigger()?.open();
            }
            break;
        case 27:
            $(e) || (e.preventDefault(), i.activeItem?.getMenuTrigger()?.close());
            break;
        case 9:
            $(e, "altKey", "metaKey", "ctrlKey") || i.activeItem?.getMenuTrigger()?.close();
            break;
        default: i.onKeydown(e);
    } }
    _toggleOpenMenu(e) { let i = this.keyManager; switch (e) {
        case oe.nextItem:
            i.setFocusOrigin("keyboard"), i.setNextItemActive(), i.activeItem?.getMenuTrigger()?.open();
            break;
        case oe.previousItem:
            i.setFocusOrigin("keyboard"), i.setPreviousItemActive(), i.activeItem?.getMenuTrigger()?.open();
            break;
        case oe.currentItem:
            i.activeItem && (i.setFocusOrigin("keyboard"), i.setActiveItem(i.activeItem));
            break;
    } }
    _subscribeToMenuStackEmptied() { this.menuStack?.emptied.pipe(ne(this.destroyed)).subscribe(e => this._toggleOpenMenu(e)); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = b.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = b.\u0275\u0275defineDirective({ type: n, selectors: [["", "cdkMenuBar", ""]], hostAttrs: ["role", "menubar", 1, "cdk-menu-bar"], hostBindings: function (i, o) { i & 1 && b.\u0275\u0275listener("keydown", function (s) { return o._handleKeyEvent(s); }); }, exportAs: ["cdkMenuBar"], features: [b.\u0275\u0275ProvidersFeature([{ provide: nt, useExisting: n }, { provide: Bt, useExisting: n }, { provide: me, useFactory: () => Pi.inline("horizontal") }]), b.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), je = (() => { class n extends We {
    checked = !1;
    closeOnSpacebarTrigger = !1;
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = b.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = b.\u0275\u0275defineDirective({ type: n, hostVars: 2, hostBindings: function (i, o) { i & 2 && b.\u0275\u0275attribute("aria-checked", !!o.checked)("aria-disabled", o.disabled || null); }, inputs: { checked: [2, "cdkMenuItemChecked", "checked", Zo] }, features: [b.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), or = (() => { class n extends je {
    _selectionDispatcher = C(Mt);
    _id = C(fe).getId("cdk-menu-item-radio-");
    _removeDispatcherListener;
    constructor() { super(), this._removeDispatcherListener = this._selectionDispatcher.listen(e => { this.checked = this._id === e; }); }
    ngOnDestroy() { super.ngOnDestroy(), this._removeDispatcherListener(); }
    trigger(e) { super.trigger(e), this.disabled || this._selectionDispatcher.notify(this._id, ""); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = b.\u0275\u0275defineDirective({ type: n, selectors: [["", "cdkMenuItemRadio", ""]], hostAttrs: ["role", "menuitemradio"], hostVars: 2, hostBindings: function (i, o) { i & 2 && b.\u0275\u0275classProp("cdk-menu-item-radio", !0); }, exportAs: ["cdkMenuItemRadio"], features: [b.\u0275\u0275ProvidersFeature([{ provide: je, useExisting: n }, { provide: We, useExisting: je }]), b.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), rr = (() => { class n extends je {
    trigger(e) { super.trigger(e), this.disabled || (this.checked = !this.checked); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = b.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = b.\u0275\u0275defineDirective({ type: n, selectors: [["", "cdkMenuItemCheckbox", ""]], hostAttrs: ["role", "menuitemcheckbox"], hostVars: 2, hostBindings: function (i, o) { i & 2 && b.\u0275\u0275classProp("cdk-menu-item-checkbox", !0); }, exportAs: ["cdkMenuItemCheckbox"], features: [b.\u0275\u0275ProvidersFeature([{ provide: je, useExisting: n }, { provide: We, useExisting: je }]), b.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), ev = Ci.map(n => { let a = n.overlayX === "start" ? 2 : -2, e = n.overlayY === "top" ? 2 : -2; return G(_({}, n), { offsetX: a, offsetY: e }); });
import { RouterLink as ml } from "@angular/router";
var hl = ["body"], pl = ["bodyWrapper"], ul = [[["md-expansion-panel-header"]], "*", [["action-row"]]], gl = ["md-expansion-panel-header", "*", "action-row"];
function fl(n, a) { }
var bl = [[["md-panel-title"]], [["md-panel-description"]], "*"], _l = ["md-panel-title", "md-panel-description", "*"];
function vl(n, a) { n & 1 && (t.\u0275\u0275domElementStart(0, "span", 1), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(1, "svg", 2), t.\u0275\u0275domElement(2, "path", 3), t.\u0275\u0275domElementEnd()()); }
var T = ["*"], yl = [[["md-card-title"], ["md-card-subtitle"], ["", "md-card-title", ""], ["", "md-card-subtitle", ""], ["", "mdCardTitle", ""], ["", "mdCardSubtitle", ""]], [["", "card-image", ""], ["", "cardImage", ""], ["", "card-sm-image", ""], ["", "cardImageSmall", ""], ["", "card-md-image", ""], ["", "cardImageMedium", ""], ["", "card-lg-image", ""], ["", "cardImageLarge", ""], ["", "card-xl-image", ""], ["", "cardImageXLarge", ""]], "*"], xl = [`md-card-title, md-card-subtitle,
      [md-card-title], [md-card-subtitle],
      [mdCardTitle], [mdCardSubtitle]`, `[card-image], [cardImage],
                    [card-sm-image], [cardImageSmall],
                    [card-md-image], [cardImageMedium],
                    [card-lg-image], [cardImageLarge],
                    [card-xl-image], [cardImageXLarge]`, "*"], kl = [[["", "md-card-avatar", ""], ["", "mdCardAvatar", ""]], [["md-card-title"], ["md-card-subtitle"], ["", "md-card-title", ""], ["", "md-card-subtitle", ""], ["", "mdCardTitle", ""], ["", "mdCardSubtitle", ""]], "*"], Cl = ["[md-card-avatar], [mdCardAvatar]", `md-card-title, md-card-subtitle,
      [md-card-title], [md-card-subtitle],
      [mdCardTitle], [mdCardSubtitle]`, "*"];
function wl(n, a) { }
var Sl = (n, a, e) => ({ index: n, active: a, optional: e });
function Dl(n, a) { if (n & 1 && t.\u0275\u0275elementContainer(0, 1), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("ngTemplateOutlet", e.iconOverrides[e.state])("ngTemplateOutletContext", t.\u0275\u0275pureFunction3(2, Sl, e.index, e.active, e.optional));
} }
function Ml(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 2), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.index + 1);
} }
function Tl(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 2), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e._getDefaultTextForState(e.state));
} }
function El(n, a) { n & 1 && (t.\u0275\u0275elementStart(0, "div", 7), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(1, "svg", 8), t.\u0275\u0275element(2, "rect", 9)(3, "path", 10), t.\u0275\u0275elementEnd()()); }
function Il(n, a) { if (n & 1 && t.\u0275\u0275conditionalCreate(0, Tl, 2, 1, "span", 2)(1, El, 4, 0, "div", 7), n & 2) {
    let e, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275conditional((e = i.state) === "number" ? 0 : 1);
} }
function Nl(n, a) { n & 1 && (t.\u0275\u0275elementStart(0, "div", 4), t.\u0275\u0275elementContainer(1, 11), t.\u0275\u0275elementEnd()), n & 2 && (t.\u0275\u0275advance(), t.\u0275\u0275property("ngTemplateOutlet", a.template)); }
function Pl(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 4), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.label);
} }
function Ol(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 5), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e._intl.optionalLabel);
} }
function Fl(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 6), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.errorMessage);
} }
function Rl(n, a) { }
function Al(n, a) { if (n & 1 && (t.\u0275\u0275projection(0), t.\u0275\u0275template(1, Rl, 0, 0, "ng-template", 0)), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275property("cdkPortalOutlet", e._portal);
} }
var Ll = ["stepHeader"], Bl = ["stepListContainer"], zl = ["stepList"], Vl = ["stepListInner"], zn = ["nextPaginator"], Vn = ["previousPaginator"], Hl = ["animatedContainer"], ra = n => ({ step: n });
function jl(n, a) { n & 1 && t.\u0275\u0275projection(0); }
function Wl(n, a) { n & 1 && t.\u0275\u0275element(0, "div", 20); }
function Gl(n, a) { if (n & 1 && (t.\u0275\u0275elementContainer(0, 19), t.\u0275\u0275conditionalCreate(1, Wl, 1, 0, "div", 20)), n & 2) {
    let e = a.$implicit, i = a.$index, o = a.$count;
    t.\u0275\u0275nextContext(2);
    let r = t.\u0275\u0275reference(4);
    t.\u0275\u0275property("ngTemplateOutlet", r)("ngTemplateOutletContext", t.\u0275\u0275pureFunction1(3, ra, e)), t.\u0275\u0275advance(), t.\u0275\u0275conditional(i !== o - 1 ? 1 : -1);
} }
function $l(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 21, 7), t.\u0275\u0275elementContainer(2, 9), t.\u0275\u0275elementEnd()), n & 2) {
    let e = a.$implicit, i = a.$index, o = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275classMap("horizontal-stepper-content-" + o._getAnimationDirection(i)), t.\u0275\u0275property("id", o._getStepContentId(i)), t.\u0275\u0275attribute("aria-labelledby", o._getStepLabelId(i))("inert", o.selectedIndex === i ? null : ""), t.\u0275\u0275advance(2), t.\u0275\u0275property("ngTemplateOutlet", e.content);
} }
function Yl(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "div", 8)(1, "div", 10, 1)(3, "div", 11, 2), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o._handlePaginatorClick("before")); })("mousedown", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r._handlePaginatorPress("before", o)); })("touchend", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o._stopInterval()); }), t.\u0275\u0275element(5, "div", 12), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(6, "div", 13, 3)(8, "div", 14, 4)(10, "div", 15, 5), t.\u0275\u0275repeaterCreate(12, Gl, 2, 5, null, null, t.\u0275\u0275repeaterTrackByIndex), t.\u0275\u0275elementEnd()()(), t.\u0275\u0275elementStart(14, "div", 16, 6), t.\u0275\u0275listener("mousedown", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r._handlePaginatorPress("after", o)); })("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o._handlePaginatorClick("after")); })("touchend", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o._stopInterval()); }), t.\u0275\u0275element(16, "div", 12), t.\u0275\u0275elementEnd()(), t.\u0275\u0275elementStart(17, "div", 17), t.\u0275\u0275repeaterCreate(18, $l, 3, 6, "div", 18, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275elementEnd()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(3), t.\u0275\u0275classProp("mdc-step-header-pagination-disabled", e._disableScrollBefore), t.\u0275\u0275advance(9), t.\u0275\u0275repeater(e.steps), t.\u0275\u0275advance(2), t.\u0275\u0275classProp("mdc-step-header-pagination-disabled", e._disableScrollAfter), t.\u0275\u0275advance(4), t.\u0275\u0275repeater(e.steps);
} }
function ql(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 22), t.\u0275\u0275elementContainer(1, 19), t.\u0275\u0275elementStart(2, "div", 23, 7)(4, "div", 24)(5, "div", 25), t.\u0275\u0275elementContainer(6, 9), t.\u0275\u0275elementEnd()()()()), n & 2) {
    let e = a.$implicit, i = a.$index, o = a.$index, r = a.$count, s = t.\u0275\u0275nextContext(2), l = t.\u0275\u0275reference(4);
    t.\u0275\u0275advance(), t.\u0275\u0275property("ngTemplateOutlet", l)("ngTemplateOutletContext", t.\u0275\u0275pureFunction1(10, ra, e)), t.\u0275\u0275advance(), t.\u0275\u0275classProp("stepper-vertical-line", o !== r - 1)("vertical-content-container-active", s.selectedIndex === i), t.\u0275\u0275attribute("inert", s.selectedIndex === i ? null : ""), t.\u0275\u0275advance(2), t.\u0275\u0275property("id", s._getStepContentId(i)), t.\u0275\u0275attribute("aria-labelledby", s._getStepLabelId(i)), t.\u0275\u0275advance(2), t.\u0275\u0275property("ngTemplateOutlet", e.content);
} }
function Ql(n, a) { if (n & 1 && t.\u0275\u0275repeaterCreate(0, ql, 7, 12, "div", 22, t.\u0275\u0275repeaterTrackByIdentity), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275repeater(e.steps);
} }
function Kl(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "md-step-header", 26), t.\u0275\u0275listener("click", function () { let o = t.\u0275\u0275restoreView(e).step; return t.\u0275\u0275resetView(o.select()); })("keydown", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r._onKeydown(o)); }), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = a.step, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275classProp("horizontal-stepper-header", i.orientation === "horizontal")("vertical-stepper-header", i.orientation === "vertical"), t.\u0275\u0275property("tabIndex", i._getFocusIndex() === e.index() ? 0 : -1)("id", i._getStepLabelId(e.index()))("index", e.index())("state", e.indicatorType())("label", e.stepLabel || e.label)("selected", e.isSelected())("active", e.isNavigable())("optional", e.optional)("errorMessage", e.errorMessage)("iconOverrides", i._iconOverrides)("disableRipple", i.disableRipple || !e.isNavigable())("color", e.color || i.color), t.\u0275\u0275attribute("aria-posinset", e.index() + 1)("aria-setsize", i.steps.length)("aria-controls", i._getStepContentId(e.index()))("aria-selected", e.isSelected())("aria-label", e.ariaLabel || null)("aria-labelledby", !e.ariaLabel && e.ariaLabelledby ? e.ariaLabelledby : null)("aria-disabled", e.isNavigable() ? null : !0);
} }
function Ul(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(0, "svg", 1), t.\u0275\u0275domElement(1, "polygon", 2), t.\u0275\u0275domElementEnd()); }
function Xl(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "div", 0), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.closed.emit("click")); })("animationstart", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r._onAnimationStart(o.animationName)); })("animationend", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r._onAnimationDone(o.animationName)); })("animationcancel", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r._onAnimationDone(o.animationName)); }), t.\u0275\u0275domElementStart(1, "div", 1), t.\u0275\u0275projection(2), t.\u0275\u0275domElementEnd()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275classMap(e._classList), t.\u0275\u0275classProp("md-menu-panel-animations-disabled", e._animationsDisabled)("md-menu-panel-exit-animation", e._panelAnimationState === "void")("md-menu-panel-animating", e._isAnimating()), t.\u0275\u0275domProperty("id", e.panelId), t.\u0275\u0275attribute("aria-label", e.ariaLabel || null)("aria-labelledby", e.ariaLabelledby || null)("aria-describedby", e.ariaDescribedby || null);
} }
var Zl = ["text"], Jl = [[["icon"]], "*"], ec = ["icon", "*"];
function tc(n, a) { if (n & 1 && t.\u0275\u0275element(0, "pseudo-checkbox", 1), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("disabled", e.disabled)("state", e.selected ? "checked" : "unchecked");
} }
function ic(n, a) { if (n & 1 && t.\u0275\u0275element(0, "pseudo-checkbox", 3), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("disabled", e.disabled);
} }
var nc = ["trigger"], Hn = ["panel"], oc = [[["md-select-trigger"]], "*"], rc = ["md-select-trigger", "*"];
function ac(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 4), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.placeholder);
} }
function sc(n, a) { n & 1 && t.\u0275\u0275projection(0); }
function dc(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 9), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.triggerValue);
} }
function lc(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 5), t.\u0275\u0275conditionalCreate(1, sc, 1, 0)(2, dc, 2, 1, "span", 9), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.customTrigger ? 1 : 2);
} }
function cc(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "div", 10, 1), t.\u0275\u0275listener("keydown", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r._handleKeydown(o)); }), t.\u0275\u0275projection(2, 1), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("ngClass", e.panelClass), t.\u0275\u0275attribute("id", e.id + "-panel")("aria-multiselectable", e.multiple)("aria-label", e.ariaLabel || null);
} }
var mc = ["*", [["md-option"], ["ng-container"]]], hc = ["*", "md-option, ng-container"], jn = ["input"], pc = ["content"];
function uc(n, a) { }
function gc(n, a) { n & 1 && t.\u0275\u0275projection(0); }
var fc = ["overflowTrigger"], bc = ["moreButton"], aa = ["tabListContainer"], sa = ["tabList"], da = ["tabListInner"];
function _c(n, a) { n & 1 && t.\u0275\u0275elementContainer(0, 19), n & 2 && t.\u0275\u0275property("ngTemplateOutlet", a); }
function vc(n, a) { if (n & 1 && t.\u0275\u0275text(0), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275textInterpolate1(" ", e.overflowLabel, " ");
} }
function yc(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 18), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext().$implicit, r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.selectOverflow(o)); }), t.\u0275\u0275conditionalCreate(1, _c, 1, 1, "ng-container", 19)(2, vc, 1, 1), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e, i = a, o = t.\u0275\u0275nextContext().$implicit, r = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("disabled", i.disabled), t.\u0275\u0275attribute("aria-checked", r.selectedIndex === o), t.\u0275\u0275advance(), t.\u0275\u0275conditional((e = i.overflowTemplate) ? 1 : 2, e);
} }
function xc(n, a) { if (n & 1 && t.\u0275\u0275conditionalCreate(0, yc, 3, 3, "button", 17), n & 2) {
    let e, i = a.$implicit, o = t.\u0275\u0275nextContext();
    t.\u0275\u0275conditional((e = o._items.get(i)) ? 0 : -1, e);
} }
var kc = ["tabBodyWrapper"], Cc = ["tabHeader"], wc = n => ({ "tabs-legacy": n }), Sc = (n, a) => ({ "mdc-tab": n, "mdc-tab-legacy": a });
function Dc(n, a) { }
function Mc(n, a) { if (n & 1 && t.\u0275\u0275template(0, Dc, 0, 0, "ng-template", 11), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275property("cdkPortalOutlet", e.templateLabel);
} }
function Tc(n, a) { if (n & 1 && t.\u0275\u0275text(0), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275textInterpolate(e.textLabel);
} }
function Ec(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "div", 7, 2), t.\u0275\u0275listener("click", function () { let o = t.\u0275\u0275restoreView(e), r = o.$implicit, s = o.$index, l = t.\u0275\u0275nextContext(), c = t.\u0275\u0275reference(1); return t.\u0275\u0275resetView(l._handleClick(r, c, s)); })("cdkFocusChange", function (o) { let r = t.\u0275\u0275restoreView(e).$index, s = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(s._tabFocusChanged(o, r)); }), t.\u0275\u0275element(2, "span", 8), t.\u0275\u0275elementStart(3, "span", 9)(4, "span", 10), t.\u0275\u0275conditionalCreate(5, Mc, 1, 1, null, 11)(6, Tc, 1, 1), t.\u0275\u0275elementEnd()()();
} if (n & 2) {
    let e = a.$implicit, i = a.$index, o = t.\u0275\u0275nextContext(), r = t.\u0275\u0275reference(1);
    t.\u0275\u0275classMap(e.labelClass), t.\u0275\u0275classProp("md-tab-overflow-hidden", r.isOverflowHidden(i))("mdc-tab--active", o.selectedIndex === i), t.\u0275\u0275property("ngClass", t.\u0275\u0275pureFunction2(20, Sc, !o.isLegacyMode, o.isLegacyMode))("id", o._getTabLabelId(e, i))("overflowLabel", e.templateLabel?.templateRef || e.textLabel)("disabled", e.disabled)("fitInkBarToContent", o.fitInkBarToContent), t.\u0275\u0275attribute("tabIndex", r.isOverflowHidden(i) ? -1 : o._getTabIndex(i))("aria-hidden", r.isOverflowHidden(i) ? !0 : null)("aria-posinset", i + 1)("aria-setsize", o._tabs.length)("aria-controls", o._getTabContentId(i))("aria-selected", o.selectedIndex === i)("aria-label", e.ariaLabel || null)("aria-labelledby", !e.ariaLabel && e.ariaLabelledby ? e.ariaLabelledby : null), t.\u0275\u0275advance(5), t.\u0275\u0275conditional(e.templateLabel ? 5 : 6);
} }
function Ic(n, a) { n & 1 && t.\u0275\u0275projection(0); }
function Nc(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "md-tab-body", 12), t.\u0275\u0275listener("_onCentered", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o._removeTabBodyWrapperHeight()); })("_onCentering", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r._setTabBodyWrapperHeight(o)); })("_beforeCentering", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r._bodyCentered(o)); }), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = a.$implicit, i = a.$index, o = t.\u0275\u0275nextContext();
    t.\u0275\u0275classMap(e.bodyClass), t.\u0275\u0275property("id", o._getTabContentId(i))("content", e.content)("position", e.position)("animationDuration", o.animationDuration)("preserveContent", o.preserveContent)("tabBackgroundColor", o.tabBackgroundColor)("tabPadding", o.tabPadding), t.\u0275\u0275attribute("tabindex", o.contentTabIndex != null && o.selectedIndex === i ? o.contentTabIndex : null)("aria-labelledby", o._getTabLabelId(e, i))("aria-hidden", o.selectedIndex !== i);
} }
var Pc = `.mdc-tab-header{display:flex;overflow:hidden;position:relative;flex-shrink:0}.mdc-tab-indicator .mdc-tab-indicator__content{transition-duration:.25s}.mdc-tab-header-pagination{position:relative;display:none;justify-content:center;align-items:center;min-width:32px;cursor:pointer;z-index:2;-webkit-tap-highlight-color:transparent;touch-action:none;box-sizing:content-box;outline:0}.mdc-tab-header-pagination::-moz-focus-inner{border:0}.mdc-tab-header-pagination-controls-enabled .mdc-tab-header-pagination{display:flex}.mdc-tab-header-pagination-before,.mdc-tab-header-rtl .mdc-tab-header-pagination-after{padding-left:4px}.mdc-tab-header-pagination-before .mdc-tab-header-pagination-chevron,.mdc-tab-header-rtl .mdc-tab-header-pagination-after .mdc-tab-header-pagination-chevron{transform:rotate(-135deg)}.mdc-tab-header-rtl .mdc-tab-header-pagination-before,.mdc-tab-header-pagination-after{padding-right:4px}.mdc-tab-header-rtl .mdc-tab-header-pagination-before .mdc-tab-header-pagination-chevron,.mdc-tab-header-pagination-after .mdc-tab-header-pagination-chevron{transform:rotate(45deg)}.mdc-tab-header-pagination-chevron{border-style:solid;border-width:2px 2px 0 0;height:8px;width:8px;border-color:var(--%NS%md-tabs-pagination-chevron-color, var(--%NS%md-tabs-label-color, #201a1b))}.mdc-tab-header-pagination-disabled{box-shadow:none;cursor:default;pointer-events:none}.mdc-tab-header-pagination-disabled .mdc-tab-header-pagination-chevron{opacity:.4}.mdc-tab-list{flex-grow:1;position:relative;transition:transform .5s cubic-bezier(.35,0,.25,1)}.animation-noopable .mdc-tab-list{transition:none}.mdc-tab-label-container{display:flex;flex-grow:1;overflow:hidden;z-index:1;border-bottom-style:solid;border-bottom-width:1px;border-bottom-color:var(--%NS%md-tabs-header-border-color, #f3dde1)}.mdc-tab-group-inverted-header .mdc-tab-label-container{border-bottom:none;border-top-style:solid;border-top-width:1px;border-top-color:var(--%NS%md-tabs-header-border-color, #f3dde1)}.mdc-tab-labels{display:flex;flex:1 0 auto}[align-tabs=center]>.mdc-tab-header .mdc-tab-labels{justify-content:center}[align-tabs=end]>.mdc-tab-header .mdc-tab-labels{justify-content:flex-end}.cdk-drop-list .mdc-tab-labels,.mdc-tab-labels.cdk-drop-list{min-height:48px}.mdc-tab:before{margin:5px}@media(forced-colors:active){.mdc-tab[aria-disabled=true]{color:GrayText}}.md-tab-overflow-trigger,.md-tab-header-menu .mdc-tab-header-pagination{display:none}.md-tab-header-menu .mdc-tab-label-container{min-width:0}.md-tab-header-menu .mdc-tab-list{transition:none}.md-tab-header-menu .mdc-tab-labels{justify-content:flex-start}.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy){flex:0 0 auto;min-width:min(90px,var(--%NS%md-tab-label-max-width, 90px));max-width:var(--%NS%md-tab-label-max-width, none)}.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy) .mdc-tab__content{min-width:0}.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy) .mdc-tab__text-label{overflow:hidden;text-overflow:ellipsis}.md-tab-header-menu .mdc-tab-labels>.md-tab-overflow-hidden{position:absolute;inset-inline-start:-100000px;width:max-content;visibility:hidden;pointer-events:none}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger{display:inline-flex;flex:0 0 44px;align-items:center;justify-content:center;align-self:stretch;border:0;border-bottom:1px solid var(--%NS%md-tabs-header-border-color, var(--%NS%md-color-border));background:var(--%NS%md-tabs-overflow-background, var(--%NS%md-color-surface));color:var(--%NS%md-tabs-label-color, var(--%NS%md-color-text));font:inherit;font-size:24px;line-height:1;padding:0;cursor:pointer}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger:hover{background:var(--%NS%md-color-surface-hover)}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger:focus-visible{outline:2px solid var(--%NS%md-color-focus);outline-offset:-3px}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger.md-tab-overflow-active{color:var(--%NS%md-color-primary)}.mdc-tab-group.mdc-tab-group-stretch-tabs>.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy){flex-grow:0}.mdc-tab-group-inverted-header>.md-tab-header-menu .md-tab-overflow-trigger{border-bottom:0;border-top:1px solid var(--%NS%md-tabs-header-border-color, var(--%NS%md-color-border))}.mdc-tab{min-width:90px;padding:0 24px;display:flex;flex:1 0 auto;font-family:var(--%NS%md-tabs-font-family, var(--%NS%md-font-heading, "Montserrat"));justify-content:center;box-sizing:border-box;border:none;outline:none;text-align:center;white-space:nowrap;cursor:pointer;z-index:1;touch-action:manipulation}.mdc-tab__content{display:flex;align-items:center;justify-content:center;height:inherit;pointer-events:none}.mdc-tab__text-label{transition:.15s color linear;display:inline-block;line-height:1;z-index:2}.mdc-tab--active .mdc-tab__text-label{transition-delay:.1s}._animation-noopable .mdc-tab__text-label{transition:none}.mdc-tab-indicator{display:flex;position:absolute;top:0;left:0;justify-content:center;width:100%;height:100%;pointer-events:none;z-index:1}.mdc-tab-indicator__content{transition:.25s transform cubic-bezier(.4,0,.2,1);transform-origin:left;opacity:0}.no-animations .mdc-tab-indicator__content{transition:none!important;animation:none!important}.mdc-tab-indicator__content--underline{align-self:flex-end;box-sizing:border-box;width:100%;border-top-style:solid}.mdc-tab-indicator--active .mdc-tab-indicator__content{opacity:1}._animation-noopable .mdc-tab-indicator__content,.mdc-tab-indicator--no-transition .mdc-tab-indicator__content{transition:none}.mdc-tab{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-decoration:none;background:none;height:40px;font-family:var(--%NS%md-tabs-font-family, var(--%NS%md-font-heading, "Montserrat"));font-size:1rem;letter-spacing:.006rem;line-height:1.25rem;font-weight:500}.mdc-tab-group.mdc-tab-group-stretch-tabs>.mdc-tab-header .mdc-tab{flex-grow:1}.mdc-tab.mdc-tab{flex-grow:0}.mdc-tab .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106);border-top-width:2px;border-radius:0}.mdc-tab:focus .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--active .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--active .mdc-tab__ripple:before{background-color:var(--%NS%md-tabs-ripple-color, #201a1b)}.mdc-tab.mdc-tab--%NS%active:hover .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--%NS%active:hover .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106)}.mdc-tab.mdc-tab--%NS%active:focus .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--%NS%active:focus .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106)}.mdc-tab.mdc-tab-disabled{opacity:.4;pointer-events:none}.mdc-tab.mdc-tab-disabled .mdc-tab__content{pointer-events:none}.mdc-tab .mdc-tab__ripple:before{content:"";display:block;position:absolute;inset:0;opacity:0;pointer-events:none;background-color:var(--%NS%md-tabs-ripple-color, #201a1b)}.mdc-tab .mdc-tab__text-label{color:var(--%NS%md-tabs-label-color, #201a1b);display:inline-flex;align-items:center}.mdc-tab .mdc-tab__content{position:relative;pointer-events:auto}.mdc-tab:hover .mdc-tab__ripple:before{opacity:.04}.mdc-tab.cdk-program-focused .mdc-tab__ripple:before,.mdc-tab.cdk-keyboard-focused .mdc-tab__ripple:before{opacity:.12}.mdc-tab-group{display:flex;flex-direction:column;max-width:100%;flex:1}.mdc-tab-group.tabs-with-background>.mdc-tab-header .mdc-tab-header-pagination-chevron,.mdc-tab-group.tabs-with-background>.mdc-tab-header .focus-indicator:before,.mdc-tab-group.tabs-with-background>.mdc-tab-header-pagination .mdc-tab-header-pagination-chevron,.mdc-tab-group.tabs-with-background>.mdc-tab-header-pagination .focus-indicator:before{border-color:var(--%NS%md-tabs-pagination-chevron-color, var(--%NS%md-tabs-label-color, #201a1b))}.mdc-tab-group.tabs-with-background>.mdc-tab-header .mdc-tab-header-pagination-chevron,.mdc-tab-group.tabs-with-background>.mdc-tab-header-pagination .mdc-tab-header-pagination-chevron{color:transparent}.mdc-tab-group.mdc-tab-group-inverted-header{flex-direction:column-reverse}.mdc-tab-group.mdc-tab-group-inverted-header .mdc-tab-indicator__content--underline{align-self:flex-start}.mdc-tab-body-wrapper{position:relative;overflow:hidden;display:flex;height:100%}.mdc-tab-body-wrapper.no-animations .mdc-tab-body-content{transition:none!important;animation:none!important}.focus-indicator{position:relative}.tabs-legacy .mdc-tab-labels{gap:2px}.tabs-legacy .mdc-tab-label-container{border:0px}.mdc-tab-legacy{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-decoration:none;height:28px;padding:0 24px;font-size:12px;letter-spacing:.02rem;font-weight:500;font-family:var(--%NS%md-tabs-font-family, var(--%NS%md-font-heading, "Montserrat"));background-color:var(--%NS%md-tabs-legacy-background, #4D4D4D);border-top-left-radius:5px;border-top-right-radius:5px;cursor:pointer}.legacy-small .mdc-tab-legacy{height:28px;font-size:12px}.legacy-medium .mdc-tab-legacy{height:32px;font-size:14px}.legacy-large .mdc-tab-legacy{height:36px;font-size:16px;font-weight:600}.mdc-tab-group.mdc-tab-group-stretch-tabs>.mdc-tab-header .mdc-tab-legacy{flex-grow:1}.mdc-tab-legacy.mdc-tab{flex-grow:0}.mdc-tab-legacy .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106);border-top-width:2px;border-radius:0}.mdc-tab-legacy:hover:not(.mdc-tab--active){background-color:var(--%NS%md-tabs-legacy-hover-background, #373737)}.mdc-tab-legacy:focus .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-color, #FFFFFF)}.mdc-tab-legacy.mdc-tab--active{background-color:var(--%NS%md-tabs-legacy-active-background, #F3F3F3)}.mdc-tab-legacy.mdc-tab--active .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-active-color, #373737)}.mdc-tab-legacy.mdc-tab--active .mdc-tab__ripple:before{background-color:var(--%NS%md-tabs-ripple-color, #373737)}.mdc-tab-legacy.mdc-tab-disabled{pointer-events:none}.mdc-tab-legacy.mdc-tab-disabled .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-disabled-color, #BDBDBD)}.mdc-tab-legacy.mdc-tab-disabled .mdc-tab__content{pointer-events:none}.mdc-tab-legacy .mdc-tab__ripple:before{content:"";display:block;position:absolute;inset:0;opacity:0;pointer-events:none;background-color:var(--%NS%md-tabs-legacy-color, #FFFFFF)}.mdc-tab-legacy .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-color, #FFFFFF);display:inline-flex;align-items:center;transition:none}.mdc-tab-legacy .mdc-tab__content{position:relative;pointer-events:auto}.mdc-tab-legacy:hover .mdc-tab__ripple:before{opacity:.04}.mdc-tab-legacy.cdk-program-focused .mdc-tab__ripple:before,.mdc-tab-legacy.cdk-keyboard-focused .mdc-tab__ripple:before{opacity:.12}.mdc-tab-nav-bar{max-width:100%}.mdc-tab-nav-bar-stretch-tabs .mdc-tab{flex-grow:1}.md-tab-link{position:relative}.mdc-tab-nav-bar.tabs-legacy .mdc-tab-labels{gap:2px}.mdc-tab-nav-bar.tabs-legacy .mdc-tab-label-container{border:0}.mdc-tab-nav-bar.tabs-legacy .mdc-tab-legacy:hover:not(.mdc-tab--active){background-color:var(--%NS%md-tabs-legacy-hover-background, #373737)}.md-tab-nav-panel{display:block}
`, Oc = ["label"];
function Fc(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "div", 1, 0), t.\u0275\u0275projection(2), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275classMap(e._classList), t.\u0275\u0275classProp("md-mdc-autocomplete-visible", e.showPanel)("md-mdc-autocomplete-hidden", !e.showPanel)("md-autocomplete-panel-animations-enabled", !e._animationsDisabled)("md-primary", e._color === "primary")("md-accent", e._color === "accent")("md-warn", e._color === "warn"), t.\u0275\u0275domProperty("id", e.id), t.\u0275\u0275attribute("aria-label", e.ariaLabel || null);
} }
var Rc = ["formField"], la = ["*", [["md-chip-avatar"], ["", "mdChipAvatar", ""]], [["md-chip-trailing-icon"], ["", "mdChipRemove", ""], ["", "mdChipTrailingIcon", ""]]], ca = ["*", "md-chip-avatar, [mdChipAvatar]", "md-chip-trailing-icon,[mdChipRemove],[mdChipTrailingIcon]"];
function Ac(n, a) { n & 1 && (t.\u0275\u0275elementStart(0, "span", 3), t.\u0275\u0275projection(1, 1), t.\u0275\u0275elementEnd()); }
function Lc(n, a) { n & 1 && (t.\u0275\u0275elementStart(0, "span", 6), t.\u0275\u0275projection(1, 2), t.\u0275\u0275elementEnd()); }
function Bc(n, a) { n & 1 && (t.\u0275\u0275elementStart(0, "span", 3), t.\u0275\u0275projection(1, 1), t.\u0275\u0275elementStart(2, "span", 7), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(3, "svg", 8), t.\u0275\u0275element(4, "path", 9), t.\u0275\u0275elementEnd()()()); }
function zc(n, a) { n & 1 && (t.\u0275\u0275elementStart(0, "span", 6), t.\u0275\u0275projection(1, 2), t.\u0275\u0275elementEnd()); }
var ma = `.mdc-evolution-chip,.mdc-evolution-chip__cell,.mdc-evolution-chip__action{display:inline-flex;align-items:center}.mdc-evolution-chip{position:relative;max-width:100%}.mdc-evolution-chip__cell,.mdc-evolution-chip__action{height:100%}.mdc-evolution-chip__cell--primary{flex-basis:100%;overflow-x:hidden}.mdc-evolution-chip__cell--trailing{flex:1 0 auto}.mdc-evolution-chip__action{align-items:center;background:none;border:none;box-sizing:content-box;cursor:pointer;display:inline-flex;justify-content:center;outline:none;padding:0;text-decoration:none;color:inherit}.mdc-evolution-chip__action--presentational{cursor:auto}.mdc-evolution-chip--disabled,.mdc-evolution-chip__action:disabled{pointer-events:none}.mdc-evolution-chip__action--primary{font:inherit;letter-spacing:inherit;white-space:inherit;overflow-x:hidden}.md-mdc-standard-chip .mdc-evolution-chip__action--%NS%primary:before{border-width:1px;border-radius:8px;box-sizing:border-box;content:"";height:100%;left:0;position:absolute;pointer-events:none;top:0;width:100%;z-index:1;border-style:solid}.md-mdc-standard-chip .mdc-evolution-chip__action--primary{padding-left:12px;padding-right:12px}.md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary{padding-left:0;padding-right:12px}[dir=rtl] .md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary{padding-left:12px;padding-right:0}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__action--%NS%primary:before{border-color:var(--%NS%md-chip-border-color, #74777f)}.mdc-evolution-chip__action--%NS%primary:not(.mdc-evolution-chip__action--presentational):focus:before{border-color:var(--%NS%md-chip-border-color, #74777f)}.md-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__action--%NS%primary:before{border-color:color-mix(in srgb,var(--%NS%md-color-text, #1a1b1f) 12%,transparent)}.md-mdc-standard-chip.mdc-evolution-chip--selected .mdc-evolution-chip__action--%NS%primary:before{border-width:0}.md-mdc-basic-chip .mdc-evolution-chip__action--primary{font:inherit}.md-mdc-standard-chip.mdc-evolution-chip--with-leading-action .mdc-evolution-chip__action--primary{padding-left:0;padding-right:12px}[dir=rtl] .md-mdc-standard-chip.mdc-evolution-chip--with-leading-action .mdc-evolution-chip__action--primary,.md-mdc-standard-chip.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary{padding-left:12px;padding-right:0}[dir=rtl] .md-mdc-standard-chip.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary{padding-left:0;padding-right:12px}.md-mdc-standard-chip.mdc-evolution-chip--with-leading-action.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary,.md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary,[dir=rtl] .md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary{padding-left:0;padding-right:0}.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary{padding-left:0;padding-right:12px}[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary{padding-left:12px;padding-right:0}.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary,[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary{padding-left:0;padding-right:0}.mdc-evolution-chip__action--secondary{position:relative;overflow:visible}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__action--secondary{color:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__action--secondary{color:var(--%NS%md-chip-disabled-color, #1a1b1f)}.md-mdc-standard-chip.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary,.md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary,.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary,[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary{padding-left:8px;padding-right:8px}.mdc-evolution-chip__text-label{-webkit-user-select:none;user-select:none;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.md-mdc-standard-chip .mdc-evolution-chip__text-label{font-family:Montserrat;line-height:1.25rem;font-size:.875rem;font-weight:500;letter-spacing:.006rem}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__text-label{color:var(--%NS%md-chip-label-color, #44474e)}.md-mdc-standard-chip.mdc-evolution-chip--%NS%selected:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__text-label{color:var(--%NS%md-chip-selected-label-color, #3e4759)}.md-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__text-label,.md-mdc-standard-chip.mdc-evolution-chip--selected.mdc-evolution-chip--disabled .mdc-evolution-chip__text-label{color:var(--%NS%md-chip-disabled-color, color-mix(in srgb, #1a1b1f 38%, transparent))}.mdc-evolution-chip__graphic{align-items:center;display:inline-flex;justify-content:center;overflow:hidden;pointer-events:none;position:relative;flex:1 0 auto}.md-mdc-standard-chip .mdc-evolution-chip__graphic{width:24px;height:24px;font-size:24px}.mdc-evolution-chip--selecting .mdc-evolution-chip__graphic{transition:width .15s 0ms cubic-bezier(.4,0,.2,1)}.mdc-evolution-chip--%NS%selectable:not(.mdc-evolution-chip--selected):not(.mdc-evolution-chip--with-primary-icon) .mdc-evolution-chip__graphic{width:0}.md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__graphic{padding-left:6px;padding-right:6px}.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__graphic{padding-left:4px;padding-right:8px}[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__graphic{padding-left:8px;padding-right:4px}.md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__graphic{padding-left:6px;padding-right:6px}.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__graphic{padding-left:4px;padding-right:8px}[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__graphic{padding-left:8px;padding-right:4px}.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-leading-action .mdc-evolution-chip__graphic{padding-left:0}.mdc-evolution-chip__checkmark{position:absolute;opacity:0;top:50%;left:50%;height:20px;width:20px}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__checkmark{color:var(--%NS%md-chip-selected-label-color, #3e4759)}.md-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__checkmark{color:var(--%NS%md-chip-disabled-color, #1a1b1f)}.mdc-evolution-chip--selecting .mdc-evolution-chip__checkmark{transition:transform .15s 0ms cubic-bezier(.4,0,.2,1);transform:translate(-75%,-50%)}.mdc-evolution-chip--selected .mdc-evolution-chip__checkmark{transform:translate(-50%,-50%);opacity:1}.mdc-evolution-chip__checkmark-svg{display:block}.mdc-evolution-chip__checkmark-path{stroke-width:2px;stroke-dasharray:29.7833385;stroke-dashoffset:29.7833385;stroke:currentColor}.mdc-evolution-chip--selecting .mdc-evolution-chip__checkmark-path{transition:stroke-dashoffset .15s 45ms cubic-bezier(.4,0,.2,1)}.mdc-evolution-chip--selected .mdc-evolution-chip__checkmark-path{stroke-dashoffset:0}.md-mdc-standard-chip .mdc-evolution-chip__icon--trailing{height:18px;width:18px;font-size:18px}.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing.md-mdc-chip-remove{opacity:.38}.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing.md-mdc-chip-remove:focus{opacity:.38}.md-mdc-standard-chip{border-radius:8px;height:32px}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled){background-color:transparent}.md-mdc-standard-chip.mdc-evolution-chip--disabled{background-color:var(--%NS%md-chip-disabled-background, color-mix(in srgb, #1a1b1f 38%, transparent))}.md-mdc-standard-chip.mdc-evolution-chip--%NS%selected:not(.mdc-evolution-chip--disabled){background-color:var(--%NS%md-chip-selected-background, #3e4759)}.md-mdc-standard-chip.mdc-evolution-chip--selected.mdc-evolution-chip--disabled{background-color:var(--%NS%md-chip-disabled-background, color-mix(in srgb, #1a1b1f 38%, transparent))}.md-mdc-standard-chip .mdc-evolution-chip__icon--primary{border-radius:24px;width:18px;height:18px;font-size:18px}.mdc-evolution-chip--selected .mdc-evolution-chip__icon--primary{opacity:0}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__icon--primary{color:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--primary{color:var(--%NS%md-chip-disabled-color, #1a1b1f)}.md-mdc-chip-highlighted{--%NS%md-chip-with-icon-icon-color: var(--%NS%md-chip-selected-label-color, #3e4759);--%NS%md-chip-elevated-container-color: var(--%NS%md-chip-selected-background, #3e4759);--%NS%md-chip-label-text-color: var(--%NS%md-chip-selected-label-color, #3e4759);--%NS%md-chip-outline-width: 0}.md-mdc-chip-focus-overlay{background:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-chip-selected .md-mdc-chip-focus-overlay,.md-mdc-chip-highlighted .md-mdc-chip-focus-overlay{background:var(--%NS%md-chip-selected-background, #3e4759)}.md-mdc-chip:hover .md-mdc-chip-focus-overlay,.md-mdc-chip-focus-overlay .md-mdc-chip-selected:hover,.md-mdc-chip-highlighted:hover .md-mdc-chip-focus-overlay{background:var(--%NS%md-chip-icon-color, #44474e);opacity:.08}.md-mdc-chip.cdk-focused .md-mdc-chip-focus-overlay,.md-mdc-chip-selected.cdk-focused .md-mdc-chip-focus-overlay,.md-mdc-chip-highlighted.cdk-focused .md-mdc-chip-focus-overlay{background:var(--%NS%md-chip-icon-color, #44474e);opacity:.12}.mdc-evolution-chip--%NS%disabled:not(.mdc-evolution-chip--selected) .md-mdc-chip-avatar{opacity:.38}.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing,.mdc-evolution-chip--disabled.mdc-evolution-chip--selected .mdc-evolution-chip__checkmark{opacity:.38}.md-mdc-standard-chip.mdc-evolution-chip--disabled{opacity:1}.md-mdc-standard-chip.mdc-evolution-chip--selected .mdc-evolution-chip__icon--trailing,.md-mdc-standard-chip.md-mdc-chip-highlighted .mdc-evolution-chip__icon--trailing{color:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-standard-chip.mdc-evolution-chip--selected.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing,.md-mdc-standard-chip.md-mdc-chip-highlighted.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing{color:var(--%NS%md-chip-disabled-color, #1a1b1f)}.md-mdc-chip-edit:focus,.md-mdc-chip-remove:focus{opacity:1}.md-mdc-chip-edit:after,.md-mdc-chip-remove:after{background-color:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-chip-edit:hover:after,.md-mdc-chip-remove:hover:after{opacity:.2}.md-mdc-chip-edit:focus:after,.md-mdc-chip-remove:focus:after{opacity:.12}.md-mdc-chip-selected .md-mdc-chip-remove:after,.md-mdc-chip-highlighted .md-mdc-chip-remove:after{background-color:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-chip.cdk-focused .md-mdc-chip-edit:focus:after,.md-mdc-chip.cdk-focused .md-mdc-chip-remove:focus:after{opacity:.12}.md-mdc-chip.cdk-focused .md-mdc-chip-edit:hover:after,.md-mdc-chip.cdk-focused .md-mdc-chip-remove:hover:after{opacity:.08}.md-mdc-standard-chip{-webkit-tap-highlight-color:transparent}.md-mdc-standard-chip .md-mdc-chip-graphic,.md-mdc-standard-chip .md-mdc-chip-trailing-icon{box-sizing:content-box}.md-mdc-standard-chip._md-animation-noopable,.md-mdc-standard-chip._md-animation-noopable .mdc-evolution-chip__graphic,.md-mdc-standard-chip._md-animation-noopable .mdc-evolution-chip__checkmark,.md-mdc-standard-chip._md-animation-noopable .mdc-evolution-chip__checkmark-path{transition-duration:1ms;animation-duration:1ms}.md-mdc-chip-focus-overlay{inset:0;position:absolute;pointer-events:none;opacity:0;border-radius:inherit;transition:opacity .15s linear}._md-animation-noopable .md-mdc-chip-focus-overlay{transition:none}.md-mdc-basic-chip .md-mdc-chip-focus-overlay{display:none}.md-mdc-chip-avatar{text-align:center;line-height:1;color:var(--%NS%md-chip-with-icon-icon-color, currentColor)}.md-mdc-chip{position:relative;z-index:0}.md-mdc-chip-action-label{text-align:left;z-index:1}[dir=rtl] .md-mdc-chip-action-label{text-align:right}.md-mdc-chip.mdc-evolution-chip--with-trailing-action .md-mdc-chip-action-label{position:relative}.md-mdc-chip-action-label .md-mdc-chip-primary-focus-indicator{position:absolute;inset:0;pointer-events:none}.md-mdc-chip-action-label .md-focus-indicator:before{margin:calc(calc(var(--%NS%md-focus-indicator-border-width, 3px) + 2px) * -1)}.md-mdc-chip-edit:before,.md-mdc-chip-remove:before{margin:calc(var(--%NS%md-focus-indicator-border-width, 3px) * -1);left:8px;right:8px}.md-mdc-chip-edit:after,.md-mdc-chip-remove:after{content:"";display:block;opacity:0;position:absolute;inset:-3px 5px;border-radius:50%;box-sizing:border-box;padding:12px;margin:-12px;background-clip:content-box}.md-mdc-chip-edit .md-icon,.md-mdc-chip-remove .md-icon{width:18px;height:18px;font-size:18px;box-sizing:content-box}.md-chip-edit-input{cursor:text;display:inline-block;color:inherit;outline:0}.md-mdc-chip-action:focus .md-focus-indicator:before{content:""}.mdc-evolution-chip__icon,.md-mdc-chip-edit .md-icon,.md-mdc-chip-remove .md-icon{min-height:fit-content}
`, Vc = [[["", "mdChipEdit", ""]], [["md-chip-avatar"], ["", "mdChipAvatar", ""]], [["", "mdChipEditInput", ""]], "*", [["md-chip-trailing-icon"], ["", "mdChipRemove", ""], ["", "mdChipTrailingIcon", ""]]], Hc = ["[mdChipEdit]", "md-chip-avatar, [mdChipAvatar]", "[mdChipEditInput]", "*", "md-chip-trailing-icon,[mdChipRemove],[mdChipTrailingIcon]"];
function jc(n, a) { n & 1 && t.\u0275\u0275element(0, "span", 0); }
function Wc(n, a) { n & 1 && (t.\u0275\u0275elementStart(0, "span", 1), t.\u0275\u0275projection(1), t.\u0275\u0275elementEnd()); }
function Gc(n, a) { n & 1 && (t.\u0275\u0275elementStart(0, "span", 3), t.\u0275\u0275projection(1, 1), t.\u0275\u0275elementEnd()); }
function $c(n, a) { n & 1 && t.\u0275\u0275projection(0, 2); }
function Yc(n, a) { n & 1 && t.\u0275\u0275element(0, "span", 7); }
function qc(n, a) { if (n & 1 && t.\u0275\u0275conditionalCreate(0, $c, 1, 0)(1, Yc, 1, 0, "span", 7), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275conditional(e.contentEditInput ? 0 : 1);
} }
function Qc(n, a) { n & 1 && t.\u0275\u0275projection(0, 3); }
function Kc(n, a) { n & 1 && (t.\u0275\u0275elementStart(0, "span", 6), t.\u0275\u0275projection(1, 4), t.\u0275\u0275elementEnd()); }
var ha = `.md-mdc-chip-set{display:flex}.md-mdc-chip-set:focus{outline:none}.md-mdc-chip-set .mdc-evolution-chip-set__chips{min-width:100%;margin-left:-8px;margin-right:0}.md-mdc-chip-set .mdc-evolution-chip{margin:4px 0 4px 8px}[dir=rtl] .md-mdc-chip-set .mdc-evolution-chip-set__chips{margin-left:0;margin-right:-8px}[dir=rtl] .md-mdc-chip-set .mdc-evolution-chip{margin-left:0;margin-right:8px}.mdc-evolution-chip-set__chips{display:flex;flex-flow:wrap;min-width:0}.md-mdc-chip-set-stacked{flex-direction:column;align-items:flex-start}.md-mdc-chip-set-stacked .md-mdc-chip{width:100%}.md-mdc-chip-set-stacked .mdc-evolution-chip__graphic{flex-grow:0}.md-mdc-chip-set-stacked .mdc-evolution-chip__action--primary{flex-basis:100%;justify-content:start}input.md-mdc-chip-input{flex:1 0 150px;margin-left:8px}[dir=rtl] input.md-mdc-chip-input{margin-left:0;margin-right:8px}.md-mdc-form-field input.md-mdc-chip-input::placeholder{opacity:1}.md-mdc-form-field input.md-mdc-chip-input::-moz-placeholder{opacity:1}.md-mdc-form-field input.md-mdc-chip-input::-webkit-input-placeholder{opacity:1}.md-mdc-form-field input.md-mdc-chip-input:-ms-input-placeholder{opacity:1}.md-mdc-chip-set+input.md-mdc-chip-input{margin-left:0;margin-right:0}
`;
function Uc(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "option", 13), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275domProperty("value", e)("selected", e === i.limit), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e);
} }
function Xc(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "div", 2)(1, "span", 11), t.\u0275\u0275text(2, "Items per page:"), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(3, "select", 12), t.\u0275\u0275domListener("change", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(r.onPageSizeChange(o)); }), t.\u0275\u0275repeaterCreate(4, Uc, 2, 3, "option", 13, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275domElementEnd()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(3), t.\u0275\u0275domProperty("value", e.limit), t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.pageSizeOptions);
} }
function Zc(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "button", 14), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(o.firstPage()); }), t.\u0275\u0275domElement(1, "span", 15), t.\u0275\u0275domElementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275domProperty("disabled", e.offset === 0);
} }
function Jc(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "button", 16), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(o.lastPage()); }), t.\u0275\u0275domElement(1, "span", 17), t.\u0275\u0275domElementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275domProperty("disabled", e.offset >= e.totalPages - 1);
} }
function em(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "div", 1), t.\u0275\u0275conditionalCreate(1, Xc, 6, 1, "div", 2), t.\u0275\u0275domElementStart(2, "div", 3), t.\u0275\u0275conditionalCreate(3, Zc, 2, 1, "button", 4), t.\u0275\u0275domElementStart(4, "button", 5), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.prevPage()); }), t.\u0275\u0275domElement(5, "span", 6), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(6, "span", 7), t.\u0275\u0275text(7), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(8, "button", 8), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.nextPage()); }), t.\u0275\u0275domElement(9, "span", 9), t.\u0275\u0275domElementEnd(), t.\u0275\u0275conditionalCreate(10, Jc, 2, 1, "button", 10), t.\u0275\u0275domElementEnd()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275styleProp("height", e.height, "px"), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.pageSizeOptions.length > 0 ? 1 : -1), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(e.showFirstLast ? 3 : -1), t.\u0275\u0275advance(), t.\u0275\u0275domProperty("disabled", e.offset === 0), t.\u0275\u0275advance(3), t.\u0275\u0275textInterpolate2(" ", e.currentPage, " / ", e.totalPages, " "), t.\u0275\u0275advance(), t.\u0275\u0275domProperty("disabled", e.offset >= e.totalPages - 1), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(e.showFirstLast ? 10 : -1);
} }
var tm = ["cell"], im = ["headerScroll"], nm = ["bodyScroll"], om = (n, a) => ({ $implicit: n, retry: a }), rm = (n, a, e) => ({ column: n, sortDir: a, sortFn: e }), am = n => ({ group: n }), sm = (n, a, e) => ({ row: n, rowIndex: a, group: e }), dm = (n, a) => ({ row: n, rowIndex: a, group: null }), lm = (n, a, e, i, o, r, s) => ({ row: n, originalRow: a, value: e, column: i, rowIndex: o, saveFn: r, cancelFn: s }), cm = (n, a, e, i, o, r) => ({ row: n, value: a, column: e, rowIndex: i, isEditing: o, group: r }), mm = (n, a, e, i, o, r) => ({ row: n, rowIndex: a, isEditing: e, editFn: i, saveFn: o, cancelFn: r });
function hm(n, a) { return this.columnId(a); }
function pm(n, a) { n & 1 && t.\u0275\u0275elementContainer(0); }
function um(n, a) { if (n & 1 && t.\u0275\u0275template(0, pm, 1, 0, "ng-container", 15), n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275property("ngTemplateOutlet", e.loadingTemplate);
} }
function gm(n, a) { if (n & 1 && (t.\u0275\u0275element(0, "span", 16), t.\u0275\u0275text(1)), n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1("", e.loadingMessage, " ");
} }
function fm(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 4), t.\u0275\u0275conditionalCreate(1, um, 1, 1, "ng-container")(2, gm, 2, 1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.loadingTemplate ? 1 : 2);
} }
function bm(n, a) { n & 1 && t.\u0275\u0275elementContainer(0); }
function _m(n, a) { if (n & 1 && t.\u0275\u0275template(0, bm, 1, 0, "ng-container", 17), n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275property("ngTemplateOutlet", e.errorTemplate)("ngTemplateOutletContext", t.\u0275\u0275pureFunction2(2, om, e.error, e.retryLoad));
} }
function vm(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "span"), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(2, "button", 18), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(o.retry.emit()); }), t.\u0275\u0275text(3), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.error), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(e.retryLabel);
} }
function ym(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 5), t.\u0275\u0275conditionalCreate(1, _m, 1, 5, "ng-container")(2, vm, 4, 2), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.errorTemplate ? 1 : 2);
} }
function xm(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "label")(1, "input", 20), t.\u0275\u0275listener("change", function (o) { let r = t.\u0275\u0275restoreView(e).$implicit, s = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(s.setColumnVisible(r, o.target.checked)); }), t.\u0275\u0275elementEnd(), t.\u0275\u0275text(2), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275advance(), t.\u0275\u0275property("checked", !i.isColumnHidden(e))("disabled", !i.isColumnHidden(e) && i.columns.length <= 1), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.name || e.prop);
} }
function km(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "details", 6)(1, "summary"), t.\u0275\u0275text(2), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(3, "div", 19), t.\u0275\u0275repeaterCreate(4, xm, 3, 3, "label", null, hm, !0), t.\u0275\u0275elementEnd()()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(e.columnsLabel), t.\u0275\u0275advance(2), t.\u0275\u0275repeater(e.allColumns);
} }
function Cm(n, a) { }
function wm(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 7), t.\u0275\u0275template(1, Cm, 0, 0, "ng-template", 21), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275property("ngTemplateOutlet", e.toolbarTemplate.templateRef)("ngTemplateOutletContext", e.toolbarContext);
} }
function Sm(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 24), t.\u0275\u0275listener("click", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(r.onColumnSort(o)); }), t.\u0275\u0275text(1), t.\u0275\u0275elementStart(2, "span", 25), t.\u0275\u0275text(3), t.\u0275\u0275elementEnd()();
} if (n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275classProp("is-active", !!i.getSortDir(e)), t.\u0275\u0275attribute("aria-pressed", !!i.getSortDir(e))("aria-label", (e.name || e.prop) + ": " + i.getAriaSort(e))("aria-description", i.getSortDescription(e)), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1(" ", e.name || e.prop, " "), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(i.getSortDir(e) === "asc" ? "\u2191" : i.getSortDir(e) === "desc" ? "\u2193" : "\u2195");
} }
function Dm(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 8)(1, "span", 22), t.\u0275\u0275text(2), t.\u0275\u0275elementEnd(), t.\u0275\u0275repeaterCreate(3, Sm, 4, 7, "button", 23, t.\u0275\u0275componentInstance().trackByColumn, !0), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275attribute("aria-label", e.sortLabel), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(e.sortLabel), t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.mobileSortColumns);
} }
function Mm(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "input", 33), t.\u0275\u0275listener("change", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(4); return t.\u0275\u0275resetView(r.togglePage(o.target.checked)); }), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(4);
    t.\u0275\u0275property("checked", e.pageSelected)("indeterminate", e.pagePartiallySelected)("disabled", !e.selectablePageRows.length), t.\u0275\u0275attribute("aria-label", e.selectPageLabel);
} }
function Tm(n, a) { }
function Em(n, a) { if (n & 1 && t.\u0275\u0275template(0, Tm, 0, 0, "ng-template", 21), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275property("ngTemplateOutlet", e.resolvedHeaderTemplate)("ngTemplateOutletContext", t.\u0275\u0275pureFunction3(2, rm, e, i.getSortDir(e), i.onColumnSort.bind(i, e)));
} }
function Im(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 37)(1, "span", 38), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(2, "svg", 39), t.\u0275\u0275element(3, "path", 40), t.\u0275\u0275elementEnd()()()), n & 2) {
    let e = t.\u0275\u0275nextContext(3).$implicit, i = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275advance(), t.\u0275\u0275property("ngClass", i.getSortClass(e));
} }
function Nm(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 36), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2).$implicit, r = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(r.onColumnSort(o)); }), t.\u0275\u0275elementStart(1, "span", 35), t.\u0275\u0275text(2), t.\u0275\u0275elementEnd(), t.\u0275\u0275conditionalCreate(3, Im, 4, 1, "span", 37), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(2).$implicit, i = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275classProp("has-sort", !!i.getSortDir(e)), t.\u0275\u0275attribute("title", e.name), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(e.name), t.\u0275\u0275advance(), t.\u0275\u0275conditional(i.getSortDir(e) ? 3 : -1);
} }
function Pm(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 35), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2).$implicit;
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.name);
} }
function Om(n, a) { if (n & 1 && t.\u0275\u0275conditionalCreate(0, Nm, 4, 5, "button", 34)(1, Pm, 2, 1, "span", 35), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275conditional(e.sortable ? 0 : 1);
} }
function Fm(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "span", 41), t.\u0275\u0275listener("pointerdown", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext().$implicit, s = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(s.onResizeStart(o, r)); })("keydown", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext().$implicit, s = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(s.onResizeKeydown(o, r)); }), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275attribute("aria-label", i.resizeLabel + ": " + (e.name || e.prop || ""))("aria-valuenow", e.actualWidth)("aria-valuemin", e.minWidth)("aria-valuemax", e.maxWidth < 9007199254740991 ? e.maxWidth : null);
} }
function Rm(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 30, 3), t.\u0275\u0275conditionalCreate(2, Mm, 1, 4, "input", 31), t.\u0275\u0275conditionalCreate(3, Em, 1, 6, null, 21)(4, Om, 2, 1), t.\u0275\u0275conditionalCreate(5, Fm, 1, 4, "span", 32), t.\u0275\u0275elementEnd()), n & 2) {
    let e = a.$implicit, i = a.$index, o = a.$index, r = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275styleProp("left", e.pinned === "left" ? r.getPinnedOffset(e) : null, "px")("right", e.pinned === "right" ? r.getPinnedOffset(e) : null, "px")("width", e.actualWidth, "px"), t.\u0275\u0275classProp("md-grid-pinned", !!e.pinned)("md-grid-id-cell", e.mobileRole === "id")("md-grid-data-cell", e.mobileRole === "data")("md-grid-column-actions-cell", e.mobileRole === "actions")("md-grid-first-action-cell", r.isFirstActionColumn(e))("md-grid-last-action-cell", r.isLastActionColumn(e))("resizeable", r.isColumnResizeable(e))("sortable", e.sortable)("sort-active", r.getSortDir(e))("sort-asc", r.getSortDir(e) === "asc")("sort-desc", r.getSortDir(e) === "desc"), t.\u0275\u0275property("ngClass", r.getHeaderClass(e)), t.\u0275\u0275attribute("aria-colindex", i + 1)("aria-sort", r.getAriaSort(e))("aria-description", r.getSortDescription(e))("title", r.isColumnResizeable(e) ? null : e.name), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o === 0 && r.selectionEnabled ? 2 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.resolvedHeaderTemplate ? 3 : 4), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(r.isColumnResizeable(e) ? 5 : -1);
} }
function Am(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 42), t.\u0275\u0275element(1, "span", 35), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275styleProp("right", e.hasRightPinnedColumns ? 0 : null, "px")("--%NS%md-grid-actions-width", e.rowActionsWidth + "px"), t.\u0275\u0275classProp("md-grid-pinned", e.hasRightPinnedColumns);
} }
function Lm(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 26, 2)(2, "div", 27), t.\u0275\u0275repeaterCreate(3, Rm, 6, 36, "div", 28, t.\u0275\u0275componentInstance().trackByColumn, !0), t.\u0275\u0275conditionalCreate(5, Am, 2, 6, "div", 29), t.\u0275\u0275elementEnd()()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275styleProp("height", e.headerHeight, "px")("padding-right", e.scrollbarWidth, "px"), t.\u0275\u0275classProp("has-vertical-scroll", e.hasVerticalScroll), t.\u0275\u0275advance(2), t.\u0275\u0275styleProp("width", e.actualWidthSum, "px"), t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.columns), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(e.showRowActions ? 5 : -1);
} }
function Bm(n, a) { }
function zm(n, a) { if (n & 1 && t.\u0275\u0275template(0, Bm, 0, 0, "ng-template", 43), n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275property("ngTemplateOutlet", e.emptyTemplate);
} }
function Vm(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 44), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.emptyMessage);
} }
function Hm(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 13), t.\u0275\u0275conditionalCreate(1, zm, 1, 1, null, 43)(2, Vm, 2, 1, "span", 44), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.emptyTemplate ? 1 : 2);
} }
function jm(n, a) { }
function Wm(n, a) { if (n & 1 && t.\u0275\u0275template(0, jm, 0, 0, "ng-template", 21), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275property("ngTemplateOutlet", i.groupHeaderTemplate)("ngTemplateOutletContext", t.\u0275\u0275pureFunction1(2, am, e));
} }
function Gm(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 48), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.key);
} }
function $m(n, a) { n & 1 && t.\u0275\u0275elementContainer(0); }
function Ym(n, a) { if (n & 1 && t.\u0275\u0275template(0, $m, 1, 0, "ng-container", 17), n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext().$implicit, o = t.\u0275\u0275nextContext(3), r = t.\u0275\u0275reference(2);
    t.\u0275\u0275property("ngTemplateOutlet", r)("ngTemplateOutletContext", t.\u0275\u0275pureFunction3(2, sm, e, o._displayRows.indexOf(e), i.key));
} }
function qm(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 45)(1, "div", 46)(2, "div", 47), t.\u0275\u0275conditionalCreate(3, Wm, 1, 4, null, 21)(4, Gm, 2, 1, "span", 48), t.\u0275\u0275elementEnd()(), t.\u0275\u0275elementStart(5, "div", 49), t.\u0275\u0275repeaterCreate(6, Ym, 1, 6, "ng-container", null, t.\u0275\u0275componentInstance().trackByRow, !0), t.\u0275\u0275elementEnd()()), n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275advance(2), t.\u0275\u0275attribute("aria-colspan", i.columns.length + (i.showRowActions ? 1 : 0)), t.\u0275\u0275advance(), t.\u0275\u0275conditional(i.groupHeaderTemplate ? 3 : 4), t.\u0275\u0275advance(2), t.\u0275\u0275styleProp("gap", i.gap, "px"), t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.value);
} }
function Qm(n, a) { if (n & 1 && t.\u0275\u0275repeaterCreate(0, qm, 8, 4, "div", 45, t.\u0275\u0275componentInstance().trackByGroup, !0), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275repeater(e._groupedRows);
} }
function Km(n, a) { n & 1 && t.\u0275\u0275elementContainer(0); }
function Um(n, a) { if (n & 1 && t.\u0275\u0275template(0, Km, 1, 0, "ng-container", 17), n & 2) {
    let e = a.$implicit, i = a.$index;
    t.\u0275\u0275nextContext(3);
    let o = t.\u0275\u0275reference(2);
    t.\u0275\u0275property("ngTemplateOutlet", o)("ngTemplateOutletContext", t.\u0275\u0275pureFunction2(2, dm, e, i));
} }
function Xm(n, a) { if (n & 1 && t.\u0275\u0275repeaterCreate(0, Um, 1, 5, "ng-container", null, t.\u0275\u0275componentInstance().trackByRow, !0), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275repeater(e._displayRows);
} }
function Zm(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "md-paginator", 50), t.\u0275\u0275listener("page", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(r.onPaginatorPage(o)); })("pageSizeChange", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(r.onPaginatorPageSizeChange(o)); }), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275property("offset", e.offset)("limit", e.limit)("count", e._paginatorCount)("height", e.footerHeight)("pageSizeOptions", e.pageSizeOptions);
} }
function Jm(n, a) { if (n & 1 && (t.\u0275\u0275conditionalCreate(0, fm, 3, 1, "div", 4)(1, ym, 3, 1, "div", 5), t.\u0275\u0275conditionalCreate(2, km, 6, 1, "details", 6), t.\u0275\u0275conditionalCreate(3, wm, 2, 2, "div", 7), t.\u0275\u0275conditionalCreate(4, Dm, 5, 2, "div", 8), t.\u0275\u0275elementStart(5, "div", 9), t.\u0275\u0275conditionalCreate(6, Lm, 6, 9, "div", 10), t.\u0275\u0275elementStart(7, "div", 11, 1)(9, "div", 12), t.\u0275\u0275conditionalCreate(10, Hm, 3, 1, "div", 13), t.\u0275\u0275conditionalCreate(11, Qm, 2, 0)(12, Xm, 2, 0), t.\u0275\u0275elementEnd()()(), t.\u0275\u0275conditionalCreate(13, Zm, 1, 5, "md-paginator", 14)), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275conditional(e.loading ? 0 : e.error ? 1 : -1), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(e.showColumnChooser && !e.loading && !e.error ? 2 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.toolbarTemplate && !e.loading && !e.error ? 3 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(!e.loading && !e.error && e.mobileSortColumns.length ? 4 : -1), t.\u0275\u0275advance(), t.\u0275\u0275property("hidden", e.loading || !!e.error), t.\u0275\u0275attribute("aria-busy", e.loading)("aria-label", e.ariaLabel)("aria-colcount", e.columns.length + (e.showRowActions ? 1 : 0)), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.headerHeight > 0 ? 6 : -1), t.\u0275\u0275advance(), t.\u0275\u0275styleProp("gap", e.gap, "px"), t.\u0275\u0275advance(2), t.\u0275\u0275styleProp("width", e.actualWidthSum, "px"), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e._displayRows.length === 0 ? 10 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e._groupedRows ? 11 : 12), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(e.showFooter && !e.loading && !e.error ? 13 : -1);
} }
function eh(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "input", 60), t.\u0275\u0275listener("change", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(2).row, s = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(s.toggleRow(r, o.target.checked)); }), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(2).row, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("checked", i.isRowSelected(e))("disabled", !i.rowSelectable(e)), t.\u0275\u0275attribute("aria-label", i.selectRowLabel + ": " + e[i.trackByKey]);
} }
function th(n, a) { }
function ih(n, a) { if (n & 1 && t.\u0275\u0275template(0, th, 0, 0, "ng-template", 21), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext(), o = i.row, r = i.rowIndex, s = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("ngTemplateOutlet", e.resolvedEditTemplate)("ngTemplateOutletContext", t.\u0275\u0275pureFunction7(2, lm, s.getTemplateRow(o), o, s.getCellValue(s.getTemplateRow(o), e), e, r, s.saveRow.bind(s), s.cancelEdit.bind(s)));
} }
function nh(n, a) { }
function oh(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 58), t.\u0275\u0275template(1, nh, 0, 0, "ng-template", 21), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext(), o = i.row, r = i.rowIndex, s = i.group, l = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275property("ngTemplateOutlet", e.resolvedCellTemplate)("ngTemplateOutletContext", t.\u0275\u0275pureFunction6(2, cm, o, l.getCellValue(o, e), e, r, l.isEditing(o), s));
} }
function rh(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 59), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext().row, o = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(o.getCellValue(i, e));
} }
function ah(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 54, 3), t.\u0275\u0275conditionalCreate(2, eh, 1, 3, "input", 55), t.\u0275\u0275elementStart(3, "span", 56), t.\u0275\u0275text(4), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(5, "span", 57), t.\u0275\u0275conditionalCreate(6, ih, 1, 10, null, 21)(7, oh, 2, 9, "span", 58)(8, rh, 2, 1, "span", 59), t.\u0275\u0275elementEnd()()), n & 2) {
    let e = a.$implicit, i = a.$index, o = a.$index, r = t.\u0275\u0275nextContext().row, s = t.\u0275\u0275nextContext();
    t.\u0275\u0275styleProp("width", e.actualWidth, "px")("left", e.pinned === "left" ? s.getPinnedOffset(e) : null, "px")("right", e.pinned === "right" ? s.getPinnedOffset(e) : null, "px"), t.\u0275\u0275classProp("md-grid-id-cell", e.mobileRole === "id")("md-grid-data-cell", e.mobileRole === "data")("md-grid-column-actions-cell", e.mobileRole === "actions")("md-grid-first-action-cell", s.isFirstActionColumn(e))("md-grid-last-action-cell", s.isLastActionColumn(e))("md-grid-pinned", !!e.pinned), t.\u0275\u0275property("ngClass", s.getCellClass(r, e)), t.\u0275\u0275attribute("tabindex", s.cellTabNavigation ? 0 : null)("aria-colindex", i + 1), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o === 0 && s.selectionEnabled ? 2 : -1), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(e.name), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(s.isEditing(r) && e.resolvedEditTemplate ? 6 : e.resolvedCellTemplate ? 7 : 8);
} }
function sh(n, a) { }
function dh(n, a) { if (n & 1 && t.\u0275\u0275template(0, sh, 0, 0, "ng-template", 21), n & 2) {
    let e = t.\u0275\u0275nextContext(2), i = e.row, o = e.rowIndex, r = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("ngTemplateOutlet", r.rowActionsTemplate)("ngTemplateOutletContext", t.\u0275\u0275pureFunction6(2, mm, i, o, r.isEditing(i), r.editRow.bind(r, i), r.saveRow.bind(r), r.cancelEdit.bind(r)));
} }
function lh(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 63), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(4); return t.\u0275\u0275resetView(o.saveRow()); }), t.\u0275\u0275element(1, "span", 64), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(2, "button", 65), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(4); return t.\u0275\u0275resetView(o.cancelEdit()); }), t.\u0275\u0275element(3, "span", 66), t.\u0275\u0275elementEnd();
} }
function ch(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 67), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(3).row, r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.editRow(o)); }), t.\u0275\u0275element(1, "span", 68), t.\u0275\u0275elementEnd();
} }
function mh(n, a) { if (n & 1 && t.\u0275\u0275conditionalCreate(0, lh, 4, 0)(1, ch, 2, 0, "button", 62), n & 2) {
    let e = t.\u0275\u0275nextContext(2).row, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275conditional(i.isEditing(e) ? 0 : 1);
} }
function hh(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 61), t.\u0275\u0275conditionalCreate(1, dh, 1, 9, null, 21)(2, mh, 2, 1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275styleProp("right", e.hasRightPinnedColumns ? 0 : null, "px")("--%NS%md-grid-actions-width", e.rowActionsWidth + "px"), t.\u0275\u0275classProp("md-grid-pinned", e.hasRightPinnedColumns), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.rowActionsTemplate ? 1 : 2);
} }
function ph(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 51), t.\u0275\u0275repeaterCreate(1, ah, 9, 24, "div", 52, t.\u0275\u0275componentInstance().trackByColumn, !0), t.\u0275\u0275conditionalCreate(3, hh, 3, 7, "div", 53), t.\u0275\u0275elementEnd()), n & 2) {
    let e = a.row, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275styleProp("height", i.cardHeight === "auto" ? null : i.cardHeight + "px"), t.\u0275\u0275classProp("md-grid-card-editing", i.isEditing(e))("md-grid-card-fixed-height", i.cardHeight !== "auto"), t.\u0275\u0275advance(), t.\u0275\u0275repeater(i.columns), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(i.showRowActions ? 3 : -1);
} }
function uh(n, a) { }
var gh = [[["md-datepicker-actions"]]], fh = ["md-datepicker-actions"], Wn = (n, a) => a.date.getTime(), Gn = (n, a) => a.value;
function bh(n, a) { n & 1 && t.\u0275\u0275elementContainer(0); }
function _h(n, a) { if (n & 1 && t.\u0275\u0275template(0, bh, 1, 0, "ng-container", 6), n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275property("ngComponentOutlet", e.calendarHeaderComponent);
} }
function vh(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "header", 4)(1, "button", 7), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(o.previousPeriod()); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(2, "svg", 8), t.\u0275\u0275element(3, "path", 9), t.\u0275\u0275elementEnd()(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275elementStart(4, "button", 10), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(o.openHigherView()); }), t.\u0275\u0275text(5), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(6, "button", 11), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(o.nextPeriod()); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(7, "svg", 8), t.\u0275\u0275element(8, "path", 12), t.\u0275\u0275elementEnd()()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275advance(), t.\u0275\u0275property("disabled", !e.canNavigate(-1)), t.\u0275\u0275advance(4), t.\u0275\u0275textInterpolate(e.periodLabel), t.\u0275\u0275advance(), t.\u0275\u0275property("disabled", !e.canNavigate(1));
} }
function yh(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span"), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = a.$implicit;
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e);
} }
function xh(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 16), t.\u0275\u0275listener("click", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(4); return t.\u0275\u0275resetView(r.select(o)); }), t.\u0275\u0275elementStart(1, "span", 17), t.\u0275\u0275text(2), t.\u0275\u0275elementEnd()();
} if (n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(4);
    t.\u0275\u0275classProp("md-datepicker-day--outside", e.outside)("md-datepicker-day--selected", e.selected)("md-datepicker-day--today", e.today), t.\u0275\u0275property("ngClass", e.cssClass)("disabled", e.disabled), t.\u0275\u0275attribute("tabindex", i.isActiveDay(e) ? 0 : -1)("aria-selected", e.selected)("aria-label", i.formatAccessibleDate(e.date)), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(e.label);
} }
function kh(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 13), t.\u0275\u0275repeaterCreate(1, yh, 2, 1, "span", null, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(3, "div", 14), t.\u0275\u0275repeaterCreate(4, xh, 3, 12, "button", 15, Wn), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.weekdays), t.\u0275\u0275advance(3), t.\u0275\u0275repeater(e.days);
} }
function Ch(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 20), t.\u0275\u0275listener("click", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(4); return t.\u0275\u0275resetView(r.selectPeriod(o)); }), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = a.$implicit;
    t.\u0275\u0275classProp("md-datepicker-period--selected", e.selected), t.\u0275\u0275property("disabled", e.disabled), t.\u0275\u0275attribute("aria-disabled", e.disabled), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.label);
} }
function wh(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 18), t.\u0275\u0275repeaterCreate(1, Ch, 2, 5, "button", 19, Gn), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275classProp("md-datepicker-period-grid--years", e.currentView === "multi-year"), t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.periods);
} }
function Sh(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 3, 0), t.\u0275\u0275conditionalCreate(2, _h, 1, 1, "ng-container")(3, vh, 9, 3, "header", 4), t.\u0275\u0275conditionalCreate(4, kh, 6, 0)(5, wh, 3, 2, "div", 5), t.\u0275\u0275projection(6), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275classProp("md-datepicker-panel--touch", e.touchUi), t.\u0275\u0275property("cdkTrapFocus", e.touchUi)("cdkTrapFocusAutoCapture", e.touchUi)("ngClass", e.panelClass), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(e.calendarHeaderComponent ? 2 : 3), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(e.currentView === "month" ? 4 : 5);
} }
function Dh(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275template(0, Sh, 7, 7, "ng-template", 2), t.\u0275\u0275listener("backdropClick", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.close()); })("detach", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.close()); })("overlayKeydown", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.handleKeydown(o)); });
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("cdkConnectedOverlayBackdropClass", e.touchUi ? "cdk-overlay-dark-backdrop" : "cdk-overlay-transparent-backdrop")("cdkConnectedOverlayOrigin", e.origin)("cdkConnectedOverlayPositions", e.positions)("cdkConnectedOverlayOpen", e.opened)("cdkConnectedOverlayPush", !e.touchUi)("cdkConnectedOverlayScrollStrategy", e.overlayScrollStrategy);
} }
var Mh = [[["", "mdDatepickerToggleIcon", ""]]], Th = ["[mdDatepickerToggleIcon]"];
function Eh(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(0, "svg", 1), t.\u0275\u0275domElement(1, "path", 2), t.\u0275\u0275domElementEnd()); }
var Ih = [[["input", "mdStartDate", ""]], [["input", "mdEndDate", ""]]], Nh = ["input[mdStartDate]", "input[mdEndDate]"], Ph = [[["md-date-range-picker-actions"]]], Oh = ["md-date-range-picker-actions"];
function Fh(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span"), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = a.$implicit;
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e);
} }
function Rh(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 12), t.\u0275\u0275listener("mouseenter", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(r.preview(o)); })("focus", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(r.preview(o)); })("click", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(r.select(o)); }), t.\u0275\u0275elementStart(1, "span", 13), t.\u0275\u0275text(2), t.\u0275\u0275elementEnd(), t.\u0275\u0275element(3, "span", 14), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275classProp("md-datepicker-day--outside", e.outside)("md-datepicker-day--selected", e.selected)("md-datepicker-day--range-start", e.rangeStart)("md-datepicker-day--range-end", e.rangeEnd)("md-datepicker-day--in-range", e.inRange)("md-datepicker-day--preview-start", e.previewStart)("md-datepicker-day--preview-end", e.previewEnd)("md-datepicker-day--in-preview", e.inPreview)("md-datepicker-day--comparison-start", e.comparisonStart)("md-datepicker-day--comparison-end", e.comparisonEnd)("md-datepicker-day--comparison-bridge-start", e.comparisonBridgeStart)("md-datepicker-day--comparison-bridge-end", e.comparisonBridgeEnd)("md-datepicker-day--comparison-identical", e.comparisonIdentical)("md-datepicker-day--in-comparison", e.inComparison)("md-datepicker-day--in-overlap", e.inOverlap)("md-datepicker-day--today", e.today), t.\u0275\u0275property("disabled", e.disabled), t.\u0275\u0275attribute("aria-selected", e.selected)("aria-label", i.formatAccessibleDate(e.date)), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(e.label);
} }
function Ah(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "div", 2), t.\u0275\u0275listener("mouseleave", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(o.clearPreview()); }), t.\u0275\u0275elementStart(1, "header", 3)(2, "button", 4), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(o.previousMonth()); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(3, "svg", 5), t.\u0275\u0275element(4, "path", 6), t.\u0275\u0275elementEnd()(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275elementStart(5, "strong"), t.\u0275\u0275text(6), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(7, "button", 7), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(o.nextMonth()); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(8, "svg", 5), t.\u0275\u0275element(9, "path", 8), t.\u0275\u0275elementEnd()()(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275elementStart(10, "div", 9), t.\u0275\u0275repeaterCreate(11, Fh, 2, 1, "span", null, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(13, "div", 10), t.\u0275\u0275repeaterCreate(14, Rh, 4, 36, "button", 11, Wn), t.\u0275\u0275elementEnd(), t.\u0275\u0275projection(16), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(6), t.\u0275\u0275textInterpolate(e.monthLabel), t.\u0275\u0275advance(5), t.\u0275\u0275repeater(e.weekdays), t.\u0275\u0275advance(3), t.\u0275\u0275repeater(e.days);
} }
function Lh(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275template(0, Ah, 17, 1, "ng-template", 1), t.\u0275\u0275listener("backdropClick", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.close()); })("detach", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.close()); })("overlayKeydown", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.handleKeydown(o)); });
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("cdkConnectedOverlayOrigin", e.origin)("cdkConnectedOverlayPositions", e.positions)("cdkConnectedOverlayOpen", e.opened)("cdkConnectedOverlayPush", !0);
} }
var pa = `@keyframes md-datepicker-content-enter{0%{opacity:0;transform:scaleY(.8)}to{opacity:1;transform:none}}@keyframes md-datepicker-dialog-enter{0%{opacity:0;transform:scale(.8)}to{opacity:1;transform:none}}.md-datepicker-panel{display:block;width:min(296px,100vw - 32px);overflow:hidden;border:0;border-radius:var(--%NS%md-radius-lg);background:var(--%NS%md-datepicker-container-background);color:var(--%NS%md-datepicker-container-text);box-shadow:var(--%NS%md-shadow-md);font-family:var(--%NS%md-font-body);font-size:13px;line-height:normal;animation:md-datepicker-content-enter .12s cubic-bezier(0,0,.2,1)}.md-datepicker-panel--touch{position:relative;width:64vh;height:80vh;min-width:250px;max-width:750px;min-height:fit-content;max-height:788px;overflow:visible;pointer-events:auto;animation:md-datepicker-dialog-enter .15s cubic-bezier(0,0,.2,1)}.cdk-overlay-pane:has(.md-datepicker-panel--touch){position:fixed!important;inset:0!important;display:flex;align-items:center;justify-content:center;transform:none!important;pointer-events:none}.md-datepicker-panel--touch .md-datepicker-weekdays,.md-datepicker-panel--touch .md-datepicker-grid{grid-template-columns:repeat(7,minmax(0,1fr))}.md-datepicker-panel--touch .md-datepicker-grid button{width:100%;height:auto;aspect-ratio:1}.md-datepicker-header{display:grid;grid-template-columns:40px minmax(0,1fr) 40px;align-items:center;padding:8px 8px 0;color:var(--%NS%md-datepicker-header-text);text-align:center}.md-datepicker-header button,.md-datepicker-period-grid button,.md-datepicker-grid button{margin:0;padding:0;border:0;background:transparent;color:inherit;font:inherit;text-align:center;outline:none;cursor:pointer}.md-datepicker-header button{display:inline-grid;width:40px;height:40px;place-items:center;border-radius:50%}.md-datepicker-header button:hover:not(:disabled){background:var(--%NS%md-datepicker-hover-background)}.md-datepicker-header button:disabled{color:color-mix(in srgb,var(--%NS%md-datepicker-header-text) 38%,transparent);cursor:default}.md-datepicker-header button:focus-visible{background:var(--%NS%md-datepicker-focus-background);outline:2px solid var(--%NS%md-color-focus);outline-offset:-2px}.md-datepicker-header button svg{display:block;width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:2.25;stroke-linecap:round;stroke-linejoin:round}.md-datepicker-header .md-datepicker-period{width:auto;min-width:0;margin:0 8px;border-radius:20px;font-weight:600}.md-datepicker-weekdays,.md-datepicker-grid{display:grid;grid-template-columns:repeat(7,minmax(0,40px));padding-inline:8px}.md-datepicker-weekdays span{display:grid;height:32px;place-items:center;color:var(--%NS%md-datepicker-header-text);font-size:12px;font-weight:600}.md-datepicker-grid{padding-bottom:8px}.md-datepicker-grid button{position:relative;display:block;width:40px;height:40px;color:var(--%NS%md-datepicker-date-text)}:where(.md-datepicker-grid) button:before,:where(.md-datepicker-grid) button:after,.md-datepicker-cell-preview{position:absolute;top:5%;left:0;z-index:0;display:block;box-sizing:border-box;width:100%;height:90%;content:"";pointer-events:none}.md-datepicker-cell-content{position:absolute;top:5%;left:5%;z-index:1;display:flex;box-sizing:border-box;width:90%;height:90%;align-items:center;justify-content:center;border:1px solid transparent;border-radius:999px;color:inherit;line-height:1}.md-datepicker-day--outside{visibility:hidden;pointer-events:none}.md-datepicker-day--today>.md-datepicker-cell-content{border-color:var(--%NS%md-datepicker-today-outline)}.md-datepicker-day--selected>.md-datepicker-cell-content,.md-datepicker-day--range-start>.md-datepicker-cell-content,.md-datepicker-day--range-end>.md-datepicker-cell-content{border-color:transparent;background:var(--%NS%md-datepicker-selected-background);color:var(--%NS%md-datepicker-selected-text)}.md-datepicker-day--selected.md-datepicker-day--today>.md-datepicker-cell-content,.md-datepicker-day--range-start.md-datepicker-day--today>.md-datepicker-cell-content,.md-datepicker-day--range-end.md-datepicker-day--today>.md-datepicker-cell-content{box-shadow:inset 0 0 0 1px var(--%NS%md-datepicker-today-outline)}.md-datepicker-grid button:focus-visible:not(.md-datepicker-day--selected):not(.md-datepicker-day--range-start):not(.md-datepicker-day--range-end)>.md-datepicker-cell-content{background:var(--%NS%md-datepicker-focus-background)}@media(hover:hover){.md-datepicker-grid button:hover:not(:disabled):not(.md-datepicker-day--selected):not(.md-datepicker-day--range-start):not(.md-datepicker-day--range-end)>.md-datepicker-cell-content{background:var(--%NS%md-datepicker-hover-background)}}.md-datepicker-grid button:disabled{cursor:default}.md-datepicker-grid button:disabled>.md-datepicker-cell-content{color:color-mix(in srgb,var(--%NS%md-datepicker-date-text) 38%,transparent)}.md-datepicker-day--%NS%in-range:before,.md-datepicker-day--%NS%range-start:before,.md-datepicker-day--%NS%range-end:before{background:var(--%NS%md-datepicker-range-background)}.md-datepicker-day--%NS%range-start:not(.md-datepicker-day--in-comparison):before,.md-datepicker-day--%NS%range-start:after,.md-datepicker-day--preview-start>.md-datepicker-cell-preview,.md-datepicker-day--%NS%comparison-start:not(.md-datepicker-day--comparison-bridge-start):before,.md-datepicker-day--%NS%comparison-start:after{left:5%;width:95%;border-radius:999px 0 0 999px}.md-datepicker-day--%NS%range-end:not(.md-datepicker-day--in-comparison):before,.md-datepicker-day--%NS%range-end:after,.md-datepicker-day--preview-end>.md-datepicker-cell-preview,.md-datepicker-day--%NS%comparison-end:not(.md-datepicker-day--comparison-bridge-end):before,.md-datepicker-day--%NS%comparison-end:after{width:95%;border-radius:0 999px 999px 0}.md-datepicker-day--range-start.md-datepicker-day--%NS%range-end:before,.md-datepicker-day--range-start.md-datepicker-day--%NS%range-end:after,.md-datepicker-day--preview-start.md-datepicker-day--preview-end>.md-datepicker-cell-preview,.md-datepicker-day--comparison-start.md-datepicker-day--%NS%comparison-end:after{left:5%;width:90%;border-radius:999px}.md-datepicker-day--in-preview{color:var(--%NS%md-datepicker-preview-outline)}.md-datepicker-day--in-preview>.md-datepicker-cell-preview{border-block:1px dashed currentColor}.md-datepicker-day--preview-start>.md-datepicker-cell-preview{border-left:1px dashed currentColor}.md-datepicker-day--preview-end>.md-datepicker-cell-preview{border-right:1px dashed currentColor}.md-datepicker-day--comparison-identical>.md-datepicker-cell-content,.md-datepicker-day--%NS%in-comparison:before{background:var(--%NS%md-datepicker-comparison-background)}.md-datepicker-day--%NS%comparison-bridge-start:before{background:linear-gradient(to right,var(--%NS%md-datepicker-range-background) 50%,var(--%NS%md-datepicker-comparison-background) 50%)}.md-datepicker-day--%NS%comparison-bridge-end:before{background:linear-gradient(to left,var(--%NS%md-datepicker-range-background) 50%,var(--%NS%md-datepicker-comparison-background) 50%)}.md-datepicker-day--in-comparison.md-datepicker-day--%NS%in-range:after,.md-datepicker-day--in-range.md-datepicker-day--comparison-identical>.md-datepicker-cell-content{background:var(--%NS%md-datepicker-overlap-background)}.md-datepicker-day--comparison-identical.md-datepicker-day--selected>.md-datepicker-cell-content,.md-datepicker-day--in-comparison.md-datepicker-day--selected>.md-datepicker-cell-content{background:var(--%NS%md-datepicker-overlap-selected-background)}.md-datepicker-day--comparison-start.md-datepicker-day--%NS%range-end:after,.md-datepicker-day--comparison-end.md-datepicker-day--%NS%range-start:after{width:90%}[dir=rtl] .md-datepicker-day--%NS%range-start:before,[dir=rtl] .md-datepicker-day--preview-start>.md-datepicker-cell-preview,[dir=rtl] .md-datepicker-day--%NS%comparison-start:before,[dir=rtl] .md-datepicker-day--%NS%comparison-start:after{right:5%;left:0;border-radius:0 999px 999px 0}[dir=rtl] .md-datepicker-day--%NS%range-end:before,[dir=rtl] .md-datepicker-day--preview-end>.md-datepicker-cell-preview,[dir=rtl] .md-datepicker-day--%NS%comparison-end:before,[dir=rtl] .md-datepicker-day--%NS%comparison-end:after{right:0;left:5%;border-radius:999px 0 0 999px}[dir=rtl] .md-datepicker-day--%NS%comparison-bridge-start:before{background:linear-gradient(to left,var(--%NS%md-datepicker-range-background) 50%,var(--%NS%md-datepicker-comparison-background) 50%)}[dir=rtl] .md-datepicker-day--%NS%comparison-bridge-end:before{background:linear-gradient(to right,var(--%NS%md-datepicker-range-background) 50%,var(--%NS%md-datepicker-comparison-background) 50%)}.md-datepicker-period-grid{display:grid;min-height:280px;grid-template-columns:repeat(3,1fr);gap:8px;align-content:center;padding:8px}.md-datepicker-period-grid--years{grid-template-columns:repeat(4,1fr)}.md-datepicker-period-grid button{min-height:40px;border-radius:20px}.md-datepicker-period-grid button:hover:not(:disabled){background:var(--%NS%md-datepicker-hover-background)}.md-datepicker-period-grid button:focus-visible{background:var(--%NS%md-datepicker-focus-background)}.md-datepicker-period-grid .md-datepicker-period--selected{background:var(--%NS%md-datepicker-selected-background);color:var(--%NS%md-datepicker-selected-text)}.md-datepicker-period-grid button:disabled{color:color-mix(in srgb,var(--%NS%md-datepicker-date-text) 38%,transparent);cursor:default}.md-datepicker-action{display:inline-flex;min-width:60px;height:32px;box-sizing:border-box;align-items:center;justify-content:center;padding:0 12px;border:0;border-radius:var(--%NS%md-radius-md);font:inherit;font-size:12px;font-weight:600;line-height:1;cursor:pointer;transition:background-color .12s ease,color .12s ease}.md-datepicker-action--cancel{background:transparent;color:var(--%NS%md-datepicker-container-text)}.md-datepicker-action--%NS%cancel:hover{background:var(--%NS%md-datepicker-hover-background)}.md-datepicker-action--apply{background:var(--%NS%md-datepicker-selected-background);color:var(--%NS%md-datepicker-selected-text)}.md-datepicker-action--%NS%apply:hover{background:color-mix(in srgb,var(--%NS%md-datepicker-selected-background) 86%,white)}.md-datepicker-action:focus-visible{outline:2px solid var(--%NS%md-color-focus);outline-offset:1px}.md-calendar-inline{box-shadow:none;animation:none}@media(forced-colors:active){.md-datepicker-panel{border:1px solid CanvasText}.md-datepicker-day--%NS%in-range:before{border-block:1px solid CanvasText;background:none}.md-datepicker-day--%NS%in-comparison:before{border-block:1px dashed CanvasText;background:none}}@media all and (orientation:portrait){.md-datepicker-panel--touch{width:80vw;height:100vw}}
`;
function Bh(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span"), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = a.$implicit;
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e);
} }
function zh(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 11), t.\u0275\u0275listener("click", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.select(o)); }), t.\u0275\u0275elementStart(1, "span", 12), t.\u0275\u0275text(2), t.\u0275\u0275elementEnd()();
} if (n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275classProp("md-datepicker-day--outside", e.outside)("md-datepicker-day--selected", e.selected)("md-datepicker-day--today", e.today), t.\u0275\u0275property("ngClass", e.cssClass)("disabled", e.disabled), t.\u0275\u0275attribute("aria-selected", e.selected)("aria-label", i.formatAccessibleDate(e.date)), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(e.label);
} }
var Vh = [[["input", "mdSliderThumb", ""], ["input", "mdSliderStartThumb", ""], ["input", "mdSliderEndThumb", ""]]], Hh = ["input[mdSliderThumb], input[mdSliderStartThumb], input[mdSliderEndThumb]"];
function jh(n, a) { n & 1 && t.\u0275\u0275domElement(0, "div", 3); }
function Wh(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "span", 5), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275styleProp("left", i.thumbPercent(e), "%"), t.\u0275\u0275classProp("md-slider-value-indicator--active", i.activeThumb === e), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1(" ", i.displayWith(e.value), " ");
} }
function Gh(n, a) { if (n & 1 && t.\u0275\u0275repeaterCreate(0, Wh, 2, 5, "span", 4, t.\u0275\u0275repeaterTrackByIdentity), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275repeater(e.thumbs);
} }
function $h(n, a) { if (n & 1 && t.\u0275\u0275elementContainer(0, 0), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("ngTemplateOutlet", a)("ngTemplateOutletContext", e.context());
} }
function Yh(n, a) { if (n & 1 && t.\u0275\u0275text(0), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275textInterpolate1(" ", e.text(), " ");
} }
function qh(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "button", 2), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.remove()); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(1, "svg", 3), t.\u0275\u0275domElement(2, "path", 4), t.\u0275\u0275domElementEnd()();
} }
function Qh(n, a) { if (n & 1 && (t.\u0275\u0275domElementContainerStart(0), t.\u0275\u0275text(1), t.\u0275\u0275domElementContainerEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1("[", e.duplicatesCount + 1, "]");
} }
function Kh(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "div"), t.\u0275\u0275text(1), t.\u0275\u0275conditionalCreate(2, Qh, 2, 1, "ng-container"), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(), i = t.\u0275\u0275readContextLet(0);
    t.\u0275\u0275classMap(i.titleClass), t.\u0275\u0275attribute("aria-label", e.title()), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1(" ", e.title(), " "), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.duplicatesCount ? 2 : -1);
} }
function Uh(n, a) { if (n & 1 && t.\u0275\u0275domElement(0, "div", 7), n & 2) {
    let e = t.\u0275\u0275nextContext(2), i = t.\u0275\u0275readContextLet(0);
    t.\u0275\u0275classMap(i.messageClass), t.\u0275\u0275domProperty("innerHTML", e.message(), t.\u0275\u0275sanitizeHtml);
} }
function Xh(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "div", 8), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2), i = t.\u0275\u0275readContextLet(0);
    t.\u0275\u0275classMap(i.messageClass), t.\u0275\u0275attribute("aria-label", e.message()), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1(" ", e.message(), " ");
} }
function Zh(n, a) { if (n & 1 && t.\u0275\u0275conditionalCreate(0, Uh, 1, 3, "div", 5)(1, Xh, 2, 4, "div", 6), n & 2) {
    t.\u0275\u0275nextContext();
    let e = t.\u0275\u0275readContextLet(0);
    t.\u0275\u0275conditional(e.enableHtml ? 0 : 1);
} }
function Jh(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "div"), t.\u0275\u0275domElement(1, "div", 9), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275styleProp("width", e.width() + "%");
} }
function ep(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "button", 2), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.remove()); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(1, "svg", 3), t.\u0275\u0275domElement(2, "path", 4), t.\u0275\u0275domElementEnd()();
} }
function tp(n, a) { if (n & 1 && (t.\u0275\u0275domElementContainerStart(0), t.\u0275\u0275text(1), t.\u0275\u0275domElementContainerEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1("[", e.duplicatesCount + 1, "]");
} }
function ip(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "div"), t.\u0275\u0275text(1), t.\u0275\u0275conditionalCreate(2, tp, 2, 1, "ng-container"), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(), i = t.\u0275\u0275readContextLet(0);
    t.\u0275\u0275classMap(i.titleClass), t.\u0275\u0275attribute("aria-label", e.title()), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1(" ", e.title(), " "), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.duplicatesCount ? 2 : -1);
} }
function np(n, a) { if (n & 1 && t.\u0275\u0275domElement(0, "div", 7), n & 2) {
    let e = t.\u0275\u0275nextContext(2), i = t.\u0275\u0275readContextLet(0);
    t.\u0275\u0275classMap(i.messageClass), t.\u0275\u0275domProperty("innerHTML", e.message(), t.\u0275\u0275sanitizeHtml);
} }
function op(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "div", 8), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2), i = t.\u0275\u0275readContextLet(0);
    t.\u0275\u0275classMap(i.messageClass), t.\u0275\u0275attribute("aria-label", e.message()), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1(" ", e.message(), " ");
} }
function rp(n, a) { if (n & 1 && t.\u0275\u0275conditionalCreate(0, np, 1, 3, "div", 5)(1, op, 2, 4, "div", 6), n & 2) {
    t.\u0275\u0275nextContext();
    let e = t.\u0275\u0275readContextLet(0);
    t.\u0275\u0275conditional(e.enableHtml ? 0 : 1);
} }
function ap(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "div"), t.\u0275\u0275domElement(1, "div", 9), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275styleProp("width", e.width() + "%");
} }
var sp = ["button"], dp = `.md-button-toggle-group{display:inline-flex;border:1px solid var(--%NS%md-color-border, #b8bcc2);border-radius:var(--%NS%md-button-toggle-radius, 6px);isolation:isolate;vertical-align:middle}.md-button-toggle-group>.md-button-toggle{border:0;border-radius:0}.md-button-toggle-group>.md-button-toggle:first-child{border-start-start-radius:inherit;border-end-start-radius:inherit}.md-button-toggle-group>.md-button-toggle:last-child{border-start-end-radius:inherit;border-end-end-radius:inherit}.md-button-toggle-group>.md-button-toggle+.md-button-toggle{border-inline-start:1px solid var(--%NS%md-color-border, #b8bcc2)}.md-button-toggle-group.md-button-toggle-vertical{flex-direction:column}.md-button-toggle-group.md-button-toggle-vertical>.md-button-toggle{border-radius:0}.md-button-toggle-group.md-button-toggle-vertical>.md-button-toggle:first-child{border-start-start-radius:inherit;border-start-end-radius:inherit}.md-button-toggle-group.md-button-toggle-vertical>.md-button-toggle:last-child{border-end-start-radius:inherit;border-end-end-radius:inherit}.md-button-toggle-group.md-button-toggle-vertical>.md-button-toggle+.md-button-toggle{border-inline-start:0;border-block-start:1px solid var(--%NS%md-color-border, #b8bcc2)}.md-button-toggle{display:inline-flex;position:relative;border:1px solid var(--%NS%md-color-border, #b8bcc2);border-radius:var(--%NS%md-button-toggle-radius, 6px);color:var(--%NS%md-button-toggle-color, var(--%NS%md-color-text, #30343b));background:var(--%NS%md-button-toggle-bg, var(--%NS%md-color-surface, #fff))}.md-button-toggle.md-button-toggle-checked{color:var(--%NS%md-button-toggle-selected-color, #174ea6);background:var(--%NS%md-button-toggle-selected-bg, #d3e3fd)}.md-button-toggle.md-button-toggle-disabled{opacity:.45}.md-button-toggle-button{display:inline-flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:var(--%NS%md-button-toggle-height, 40px);padding:0 20px;border:0;border-radius:inherit;background:transparent;color:inherit;font-family:var(--%NS%md-button-font-family, Montserrat, sans-serif);font-size:14px;font-weight:600;line-height:24px;cursor:pointer}.md-button-toggle-button:hover:not(:disabled){background:var(--%NS%md-button-toggle-hover-bg, rgba(0, 0, 0, .06))}.md-button-toggle-button:focus-visible{outline:2px solid var(--%NS%md-color-link, #1967d2);outline-offset:-3px}.md-button-toggle-button:disabled{cursor:not-allowed}
`;
function lp(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "button", 2), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.ref.dismissWithAction()); }), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.content.action);
} }
var cp = [[["", "mdPrefix", ""]], "*", [["", "mdSuffix", ""]]], mp = ["[mdPrefix]", "*", "[mdSuffix]"];
function hp(n, a) { n & 1 && (t.\u0275\u0275domElementStart(0, "span", 10), t.\u0275\u0275text(1, "*"), t.\u0275\u0275domElementEnd()); }
function pp(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "label", 9), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.focusControl()); }), t.\u0275\u0275text(1), t.\u0275\u0275conditionalCreate(2, hp, 2, 0, "span", 10), t.\u0275\u0275domElementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275domProperty("id", e.labelId), t.\u0275\u0275attribute("for", e.control?.id), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1(" ", e.label, " "), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.control?.required && !e.hideRequiredMarker ? 2 : -1);
} }
function up(n, a) { n & 1 && (t.\u0275\u0275domElementStart(0, "span", 10), t.\u0275\u0275text(1, "*"), t.\u0275\u0275domElementEnd()); }
function gp(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "label", 9), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.focusControl()); }), t.\u0275\u0275text(1), t.\u0275\u0275conditionalCreate(2, up, 2, 0, "span", 10), t.\u0275\u0275domElementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275domProperty("id", e.labelId), t.\u0275\u0275attribute("for", e.control?.id), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1(" ", e.label, " "), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.control?.required && !e.hideRequiredMarker ? 2 : -1);
} }
function fp(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "span", 7), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275domProperty("id", e.errorId), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.error);
} }
function bp(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "span", 8), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275domProperty("id", e.hintId), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.hint);
} }
function _p(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "h2", 1), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("id", e.titleId), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.options.title);
} }
function vp(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 5), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.close()); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(1, "svg", 6), t.\u0275\u0275element(2, "path", 7), t.\u0275\u0275elementEnd()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275attribute("aria-label", e.options.closeLabel);
} }
function yp(n, a) { }
var xp = ["breadcrumb"], kp = (n, a) => a.index;
function Cp(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "a", 9), t.\u0275\u0275listener("click", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext().$implicit, s = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(s.navigateHiddenItem(o, r)); }), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275property("href", e.href, t.\u0275\u0275sanitizeUrl), t.\u0275\u0275attribute("target", e.target)("rel", e.target === "_blank" ? "noopener noreferrer" : null), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1(" ", e.label, " ");
} }
function wp(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 8), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.label);
} }
function Sp(n, a) { if (n & 1 && t.\u0275\u0275conditionalCreate(0, Cp, 2, 4, "a", 7)(1, wp, 2, 1, "span", 8), n & 2) {
    let e = a.$implicit;
    t.\u0275\u0275conditional(e.href ? 0 : 1);
} }
function Dp(n, a) { if (n & 1 && t.\u0275\u0275repeaterCreate(0, Sp, 2, 1, null, null, kp), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275repeater(e.hiddenItems());
} }
var Mp = ["picker"];
function Tp(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "span", 6), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.hint);
} }
function Ep(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "li")(1, "span", 10), t.\u0275\u0275text(2), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(3, "span", 11), t.\u0275\u0275text(4), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(5, "button", 12), t.\u0275\u0275domListener("click", function () { let o = t.\u0275\u0275restoreView(e).$index, r = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(r.remove(o)); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(6, "svg", 13), t.\u0275\u0275domElement(7, "path", 14), t.\u0275\u0275domElementEnd()()();
} if (n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275domProperty("title", e.name), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.name), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(i.formatSize(e.size)), t.\u0275\u0275advance(), t.\u0275\u0275domProperty("disabled", i.disabled), t.\u0275\u0275attribute("aria-label", i.removeLabel + ": " + e.name);
} }
function Ip(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "ul", 7), t.\u0275\u0275repeaterCreate(1, Ep, 8, 5, "li", null, t.\u0275\u0275repeaterTrackByIndex), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.files);
} }
function Np(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "li"), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(i.errorText(e));
} }
function Pp(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "ul", 9), t.\u0275\u0275repeaterCreate(1, Np, 2, 1, "li", null, t.\u0275\u0275repeaterTrackByIndex), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.errors);
} }
var Op = `md-menubar.md-menubar{display:flex;flex-wrap:wrap;gap:var(--%NS%md-spacing-1, 4px);padding:var(--%NS%md-spacing-1, 4px);border:1px solid var(--%NS%md-color-border, #ddd);border-radius:var(--%NS%md-radius-lg, 8px);background:var(--%NS%md-color-surface, #fff);color:var(--%NS%md-color-text, #222)}md-menubar-menu.md-menubar-menu{display:flex;flex-direction:column;min-width:220px;max-width:min(360px,100vw - 24px);max-height:calc(100vh - 32px);overflow-y:auto;padding:6px;border:1px solid var(--%NS%md-color-border, #ddd);border-radius:var(--%NS%md-radius-lg, 8px);background:var(--%NS%md-overlay-surface, var(--%NS%md-color-surface, #fff));color:var(--%NS%md-color-text, #222);box-shadow:var(--%NS%md-overlay-shadow, 0 6px 24px rgba(0, 0, 0, .1333333333))}.md-menubar,.md-menubar-menu{font-family:var(--%NS%md-font-body, inherit);font-size:var(--%NS%md-text-md, 14px)}.md-menubar .md-menubar-item,.md-menubar-menu .md-menubar-item{display:flex;align-items:center;gap:var(--%NS%md-spacing-3, 12px);position:relative;border:0;border-radius:var(--%NS%md-radius-sm, 4px);padding:var(--%NS%md-spacing-2, 8px) var(--%NS%md-spacing-3, 12px);min-height:36px;background:transparent;color:inherit;font:inherit;text-align:start;cursor:pointer}.md-menubar .md-menubar-item:hover,.md-menubar .md-menubar-item:focus-visible,.md-menubar .md-menubar-item[aria-expanded=true],.md-menubar-menu .md-menubar-item:hover,.md-menubar-menu .md-menubar-item:focus-visible,.md-menubar-menu .md-menubar-item[aria-expanded=true]{background:var(--%NS%md-color-surface-hover, #f0f0f0)}.md-menubar .md-menubar-item:focus-visible,.md-menubar-menu .md-menubar-item:focus-visible{outline:2px solid var(--%NS%md-color-link, #5265df);outline-offset:-2px}.md-menubar .md-menubar-item[aria-disabled=true],.md-menubar-menu .md-menubar-item[aria-disabled=true]{opacity:.4;cursor:default}.md-menubar .md-menubar-selectable,.md-menubar-menu .md-menubar-selectable{padding-inline-start:40px}.md-menubar .md-menubar-selectable[aria-checked=true]:before,.md-menubar-menu .md-menubar-selectable[aria-checked=true]:before{content:"";position:absolute;inset-inline-start:8px;top:50%;transform:translateY(-50%);width:24px;height:24px;background:currentColor;mask:url(data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22none%22%20stroke%3D%22black%22%20stroke-width%3D%222%22%20d%3D%22m5%2012%204%204L19%206%22/%3E%3C/svg%3E) center/contain no-repeat}.md-menubar [role=menuitemradio][aria-checked=true]:before,.md-menubar-menu [role=menuitemradio][aria-checked=true]:before{mask-image:url(data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2024%2024%22%3E%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%225%22/%3E%3C/svg%3E)}.md-menubar .md-menubar-hint,.md-menubar-menu .md-menubar-hint{margin-inline-start:auto;padding-inline-start:20px;opacity:.6;font-size:var(--%NS%md-text-sm, 12px)}.md-menubar .md-menubar-label,.md-menubar-menu .md-menubar-label{display:block;padding:var(--%NS%md-spacing-2, 8px) var(--%NS%md-spacing-3, 12px) var(--%NS%md-spacing-1, 4px);font-size:var(--%NS%md-text-sm, 12px);opacity:.65}.md-menubar [role=separator],.md-menubar-menu [role=separator]{border:0;border-top:1px solid var(--%NS%md-color-border, #ddd);margin:5px 0}
`;
function Fp(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "md-option", 9), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = a.$implicit;
    t.\u0275\u0275property("value", e), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e);
} }
function Rp(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "label", 0), t.\u0275\u0275text(1), t.\u0275\u0275elementStart(2, "md-select", 8), t.\u0275\u0275listener("valueChange", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.resize(o)); }), t.\u0275\u0275repeaterCreate(3, Fp, 2, 2, "md-option", 9, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275elementEnd()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1("", e.pageSizeLabel, " "), t.\u0275\u0275advance(), t.\u0275\u0275property("value", e.size)("disabled", e.disabled), t.\u0275\u0275attribute("aria-label", e.pageSizeLabel), t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.sizes);
} }
function Ap(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 4), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.go(1)); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(1, "svg", 5), t.\u0275\u0275element(2, "path", 10), t.\u0275\u0275elementEnd()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("disabled", e.disabled || e.current === 1), t.\u0275\u0275attribute("aria-label", e.firstLabel);
} }
function Lp(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 4), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext().$implicit, r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.go(o)); }), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275classProp("active", e === i.current), t.\u0275\u0275property("disabled", i.disabled || i.count === 0), t.\u0275\u0275attribute("aria-current", e === i.current ? "page" : null)("aria-label", i.pageLabel(e)), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e);
} }
function Bp(n, a) { n & 1 && (t.\u0275\u0275elementStart(0, "span", 12), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(1, "svg", 5), t.\u0275\u0275element(2, "path", 13), t.\u0275\u0275elementEnd()()); }
function zp(n, a) { if (n & 1 && t.\u0275\u0275conditionalCreate(0, Lp, 2, 6, "button", 11)(1, Bp, 3, 0, "span", 12), n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275conditional(i.isPage(e) ? 0 : 1);
} }
function Vp(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 4), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.go(o.pageCount)); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(1, "svg", 5), t.\u0275\u0275element(2, "path", 14), t.\u0275\u0275elementEnd()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("disabled", e.disabled || e.current === e.pageCount), t.\u0275\u0275attribute("aria-label", e.lastLabel);
} }
var ua = (n, a) => a.id;
function Hp(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "span", 7), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(i.formatSize(e.size));
} }
function jp(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "span", 14), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2).$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1("", i.progress(e), "%");
} }
function Wp(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "div", 9), t.\u0275\u0275domElement(1, "progress", 13), t.\u0275\u0275conditionalCreate(2, jp, 2, 1, "span", 14), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275attribute("value", i.progress(e))("aria-label", i.statusLabel(e) + ": " + e.name), t.\u0275\u0275advance(), t.\u0275\u0275conditional(i.progress(e) !== null ? 2 : -1);
} }
function Gp(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "span", 10), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.error);
} }
function $p(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "button", 15), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext().$implicit, r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.action("cancel", o)); }), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275domProperty("disabled", i.disabled), t.\u0275\u0275attribute("aria-label", i.cancelLabel + ": " + e.name), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(i.cancelLabel);
} }
function Yp(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "button", 15), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2).$implicit, r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.action("retry", o)); }), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(2).$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275domProperty("disabled", i.disabled), t.\u0275\u0275attribute("aria-label", i.retryLabel + ": " + e.name), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(i.retryLabel);
} }
function qp(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275conditionalCreate(0, Yp, 2, 3, "button", 12), t.\u0275\u0275domElementStart(1, "button", 15), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext().$implicit, r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.action("remove", o)); }), t.\u0275\u0275text(2), t.\u0275\u0275domElementEnd();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275conditional(e.status === "error" || e.status === "cancelled" ? 0 : -1), t.\u0275\u0275advance(), t.\u0275\u0275domProperty("disabled", i.disabled), t.\u0275\u0275attribute("aria-label", i.removeLabel + ": " + e.name), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(i.removeLabel);
} }
function Qp(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "li"), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(1, "svg", 2), t.\u0275\u0275domElement(2, "path", 3), t.\u0275\u0275domElementEnd(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275domElementStart(3, "div", 4)(4, "div", 5)(5, "span", 6), t.\u0275\u0275text(6), t.\u0275\u0275domElementEnd(), t.\u0275\u0275conditionalCreate(7, Hp, 2, 1, "span", 7), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(8, "span", 8), t.\u0275\u0275text(9), t.\u0275\u0275domElementEnd(), t.\u0275\u0275conditionalCreate(10, Wp, 3, 3, "div", 9), t.\u0275\u0275conditionalCreate(11, Gp, 2, 1, "span", 10), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(12, "div", 11), t.\u0275\u0275conditionalCreate(13, $p, 2, 3, "button", 12)(14, qp, 3, 4), t.\u0275\u0275domElementEnd()()), n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275classProp("error", e.status === "error"), t.\u0275\u0275advance(5), t.\u0275\u0275domProperty("title", e.name), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.name), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.size !== void 0 ? 7 : -1), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(i.statusLabel(e)), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.status === "uploading" ? 10 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(e.status === "error" && e.error ? 11 : -1), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(e.status === "uploading" || e.status === "queued" ? 13 : 14);
} }
function Kp(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "li", 1), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.emptyLabel);
} }
var Up = [[["", "mdEmptyStateIllustration", ""]], "*"], Xp = ["[mdEmptyStateIllustration]", "*"];
function Zp(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElement(0, "circle", 5)(1, "path", 6)); }
function Jp(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElement(0, "circle", 7)(1, "path", 8)); }
function eu(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElement(0, "path", 4)); }
function tu(n, a) { if (n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(0, "svg", 3), t.\u0275\u0275conditionalCreate(1, Zp, 2, 0)(2, Jp, 2, 0)(3, eu, 1, 0, ":svg:path", 4), t.\u0275\u0275domElementEnd()), n & 2) {
    let e, i = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275conditional((e = i.icon) === "search" ? 1 : e === "error" ? 2 : 3);
} }
function iu(n, a) { if (n & 1 && t.\u0275\u0275conditionalCreate(0, tu, 4, 1, ":svg:svg", 3), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275conditional(e.icon !== "none" ? 0 : -1);
} }
function nu(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "p"), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.description);
} }
function ou(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "section", 0), t.\u0275\u0275projection(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275attribute("aria-label", e.label);
} }
var ru = [[["", "mdSplitPrimary", ""]], [["", "mdSplitSecondary", ""]]], au = ["[mdSplitPrimary]", "[mdSplitSecondary]"];
function su(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "span", 4), t.\u0275\u0275text(1), t.\u0275\u0275elementStart(2, "button", 8), t.\u0275\u0275listener("click", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.remove(o)); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(3, "svg", 9), t.\u0275\u0275element(4, "path", 10), t.\u0275\u0275elementEnd()()();
} if (n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(i.labelFor(e)), t.\u0275\u0275advance(), t.\u0275\u0275property("disabled", i.disabled), t.\u0275\u0275attribute("aria-label", i.removeLabel + ": " + i.labelFor(e));
} }
function du(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 11), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.change([])); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(1, "svg", 9), t.\u0275\u0275element(2, "path", 10), t.\u0275\u0275elementEnd()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("disabled", e.disabled), t.\u0275\u0275attribute("aria-label", e.clearLabel);
} }
function lu(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275element(0, "path", 18)); }
function cu(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "div", 15), t.\u0275\u0275listener("click", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(r.toggle(o)); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(1, "svg", 16), t.\u0275\u0275element(2, "rect", 17), t.\u0275\u0275conditionalCreate(3, lu, 1, 0, ":svg:path", 18), t.\u0275\u0275elementEnd(), t.\u0275\u0275text(4), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = a.$implicit, i = a.$index, o = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275classProp("active", i === o.active), t.\u0275\u0275property("id", o.id + "-option-" + i), t.\u0275\u0275attribute("aria-selected", o.value.includes(e.value))("aria-disabled", !!e.disabled), t.\u0275\u0275advance(3), t.\u0275\u0275conditional(o.value.includes(e.value) ? 3 : -1), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.label);
} }
function mu(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "p", 14), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.emptyLabel);
} }
function hu(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "div", 12), t.\u0275\u0275listener("pointerdown", function (i) { return i.preventDefault(); }), t.\u0275\u0275repeaterCreate(1, cu, 5, 7, "div", 13, Gn, !1, mu, 2, 1, "p", 14), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275property("id", e.id + "-list"), t.\u0275\u0275attribute("aria-label", e.label), t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.filtered);
} }
function pu(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "div", 2)(1, "button", 9), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(o.move(!1)); }), t.\u0275\u0275text(2), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(3, "svg", 10), t.\u0275\u0275domElement(4, "path", 11), t.\u0275\u0275domElementEnd()(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275domElementStart(5, "button", 9), t.\u0275\u0275domListener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(o.move(!0)); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(6, "svg", 10), t.\u0275\u0275domElement(7, "path", 12), t.\u0275\u0275domElementEnd(), t.\u0275\u0275text(8), t.\u0275\u0275domElementEnd()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275domProperty("disabled", e.disabled || !e.marked(!1).length), t.\u0275\u0275attribute("aria-label", e.addLabel), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1("", e.addLabel, " "), t.\u0275\u0275advance(3), t.\u0275\u0275domProperty("disabled", e.disabled || !e.marked(!0).length), t.\u0275\u0275attribute("aria-label", e.removeLabel), t.\u0275\u0275advance(3), t.\u0275\u0275textInterpolate1(" ", e.removeLabel);
} }
function uu(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "li")(1, "label")(2, "input", 13), t.\u0275\u0275domListener("change", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(r.check(o)); }), t.\u0275\u0275domElementEnd(), t.\u0275\u0275text(3), t.\u0275\u0275domElementEnd()();
} if (n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275classProp("disabled", e.disabled), t.\u0275\u0275advance(), t.\u0275\u0275domProperty("checked", i.checked.has(e.value))("disabled", i.disabled || e.disabled), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.label);
} }
function gu(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "li", 8), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.emptyLabel);
} }
function fu(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275conditionalCreate(0, pu, 9, 6, "div", 2), t.\u0275\u0275domElementStart(1, "fieldset", 3)(2, "legend"), t.\u0275\u0275text(3), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(4, "label", 4), t.\u0275\u0275text(5), t.\u0275\u0275domElementStart(6, "input", 5), t.\u0275\u0275domListener("input", function (o) { let r = t.\u0275\u0275restoreView(e).$implicit, s = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(s.search(r, o)); }), t.\u0275\u0275domElementEnd()(), t.\u0275\u0275domElementStart(7, "label", 6)(8, "input", 7), t.\u0275\u0275domListener("change", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.checkAll(o)); }), t.\u0275\u0275domElementEnd(), t.\u0275\u0275text(9), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(10, "ul"), t.\u0275\u0275repeaterCreate(11, uu, 4, 5, "li", null, Gn, !1, gu, 2, 1, "li", 8), t.\u0275\u0275domElementEnd()();
} if (n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275conditional(e ? 0 : -1), t.\u0275\u0275advance(), t.\u0275\u0275domProperty("disabled", i.disabled), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(i.title(e)), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(i.searchLabel), t.\u0275\u0275advance(), t.\u0275\u0275domProperty("value", i.queries[+e]), t.\u0275\u0275attribute("aria-label", i.searchLabel + ": " + i.title(e)), t.\u0275\u0275advance(2), t.\u0275\u0275domProperty("checked", i.all(e))("indeterminate", i.partial(e))("disabled", i.disabled || !i.eligible(e).length), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate2("", i.selectAllLabel, " (", i.list(e).length, ")"), t.\u0275\u0275advance(2), t.\u0275\u0275repeater(i.list(e));
} }
function bu(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "section", 0)(1, "header")(2, "span"), t.\u0275\u0275text(3), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(4, "button", 1), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.close()); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(5, "svg", 2), t.\u0275\u0275element(6, "path", 3), t.\u0275\u0275elementEnd()()(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275elementStart(7, "h2", 4), t.\u0275\u0275text(8), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(9, "p", 4), t.\u0275\u0275text(10), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(11, "footer")(12, "button", 5), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.back()); }), t.\u0275\u0275text(13), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(14, "button", 6), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(o.next()); }), t.\u0275\u0275text(15), t.\u0275\u0275elementEnd()()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275attribute("aria-labelledby", e.id + "-title")("aria-describedby", e.id + "-description"), t.\u0275\u0275advance(3), t.\u0275\u0275textInterpolate(e.progressLabel(e.index + 1, e.total)), t.\u0275\u0275advance(), t.\u0275\u0275attribute("aria-label", e.closeLabel), t.\u0275\u0275advance(3), t.\u0275\u0275property("id", e.id + "-title"), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.current?.title), t.\u0275\u0275advance(), t.\u0275\u0275property("id", e.id + "-description"), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.current?.description), t.\u0275\u0275advance(2), t.\u0275\u0275property("disabled", e.index === 0), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.backLabel), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(e.index === e.total - 1 ? e.finishLabel : e.nextLabel);
} }
function _u(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "button", 11), t.\u0275\u0275listener("click", function () { let o = t.\u0275\u0275restoreView(e).$index, r = t.\u0275\u0275nextContext(3); return t.\u0275\u0275resetView(r.goTo(o)); }), t.\u0275\u0275element(1, "span"), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = a.$implicit, i = a.$index, o = t.\u0275\u0275nextContext(3);
    t.\u0275\u0275classProp("active", o.current() === i), t.\u0275\u0275attribute("aria-current", o.current() === i ? "true" : null)("aria-label", "Go to slide " + (i + 1) + (e.label() ? ": " + e.label() : ""));
} }
function vu(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "div", 2)(1, "button", 4), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(o.goTo(o.current() - 1)); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(2, "svg", 5), t.\u0275\u0275element(3, "polyline", 6), t.\u0275\u0275elementEnd()(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275elementStart(4, "div", 7), t.\u0275\u0275repeaterCreate(5, _u, 2, 4, "button", 8, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(7, "button", 9), t.\u0275\u0275listener("click", function () { t.\u0275\u0275restoreView(e); let o = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(o.goTo(o.current() + 1)); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(8, "svg", 5), t.\u0275\u0275element(9, "polyline", 10), t.\u0275\u0275elementEnd()()();
} if (n & 2) {
    let e = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275property("disabled", e.previousDisabled()), t.\u0275\u0275advance(4), t.\u0275\u0275repeater(e.slides()), t.\u0275\u0275advance(2), t.\u0275\u0275property("disabled", e.nextDisabled());
} }
function yu(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275elementStart(0, "div", 0), t.\u0275\u0275listener("keydown", function (o) { t.\u0275\u0275restoreView(e); let r = t.\u0275\u0275nextContext(); return t.\u0275\u0275resetView(r.onKeydown(o)); }), t.\u0275\u0275elementContainer(1, 1), t.\u0275\u0275elementEnd(), t.\u0275\u0275conditionalCreate(2, vu, 10, 2, "div", 2), t.\u0275\u0275elementStart(3, "span", 3), t.\u0275\u0275text(4), t.\u0275\u0275elementEnd();
} if (n & 2) {
    let e = a, i = t.\u0275\u0275nextContext();
    t.\u0275\u0275attribute("aria-label", i.current() + 1 + " of " + i.slides().length + (e.label() ? ": " + e.label() : "")), t.\u0275\u0275advance(), t.\u0275\u0275property("ngTemplateOutlet", e.template), t.\u0275\u0275advance(), t.\u0275\u0275conditional(i.slides().length > 1 ? 2 : -1), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate3("Slide ", i.current() + 1, " of ", i.slides().length, "", e.label() ? ": " + e.label() : "");
} }
function xu(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(0, "svg", 0), t.\u0275\u0275element(1, "path", 4), t.\u0275\u0275elementEnd()); }
function ku(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span", 1), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.label);
} }
function Cu(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "a", 2), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275property("routerLink", e.routerLink), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.label);
} }
function wu(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "a", 3), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275property("href", e.href, t.\u0275\u0275sanitizeUrl), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.label);
} }
function Su(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "span"), t.\u0275\u0275text(1), t.\u0275\u0275elementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext().$implicit;
    t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.label);
} }
function Du(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "li"), t.\u0275\u0275conditionalCreate(1, xu, 2, 0, ":svg:svg", 0), t.\u0275\u0275conditionalCreate(2, ku, 2, 1, "span", 1)(3, Cu, 2, 2, "a", 2)(4, wu, 2, 2, "a", 3)(5, Su, 2, 1, "span"), t.\u0275\u0275elementEnd()), n & 2) {
    let e = a.$implicit, i = a.$index, o = a.$count;
    t.\u0275\u0275advance(), t.\u0275\u0275conditional(i !== 0 ? 1 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(i === o - 1 ? 2 : e.routerLink ? 3 : e.href ? 4 : 5);
} }
function Mu(n, a) { if (n & 1 && (t.\u0275\u0275elementStart(0, "nav")(1, "ol"), t.\u0275\u0275repeaterCreate(2, Du, 6, 2, "li", null, t.\u0275\u0275repeaterTrackByIndex), t.\u0275\u0275elementEnd()()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275attribute("aria-label", e.label()), t.\u0275\u0275advance(2), t.\u0275\u0275repeater(e.items());
} }
function Tu(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElement(0, "circle", 7)(1, "path", 8)); }
function Eu(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElement(0, "path", 2)); }
function Iu(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElement(0, "path", 3)); }
function Nu(n, a) { n & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElement(0, "circle", 9)(1, "path", 10)); }
function Pu(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "span", 0), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275domProperty("id", e.controlId() + "-message"), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.error());
} }
function Ou(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "span", 1), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275domProperty("id", e.controlId() + "-message"), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(e.hint());
} }
function Fu(n, a) { if (n & 1) {
    let e = t.\u0275\u0275getCurrentView();
    t.\u0275\u0275domElementStart(0, "div", 5)(1, "button", 6), t.\u0275\u0275domListener("click", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(r.selectFilter.emit(o.id)); }), t.\u0275\u0275text(2), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(3, "button", 7), t.\u0275\u0275domListener("click", function () { let o = t.\u0275\u0275restoreView(e).$implicit, r = t.\u0275\u0275nextContext(2); return t.\u0275\u0275resetView(r.removeFilter.emit(o.id)); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(4, "svg", 3), t.\u0275\u0275domElement(5, "path", 8), t.\u0275\u0275domElementEnd()()();
} if (n & 2) {
    let e = a.$implicit, i = t.\u0275\u0275nextContext(2);
    t.\u0275\u0275advance(), t.\u0275\u0275domProperty("disabled", i.disabled()), t.\u0275\u0275attribute("aria-label", i.selectLabel() + ": " + e.label), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate1(" ", e.label, " "), t.\u0275\u0275advance(), t.\u0275\u0275domProperty("disabled", i.disabled()), t.\u0275\u0275attribute("aria-label", i.removeLabel() + ": " + e.label);
} }
function Ru(n, a) { if (n & 1 && (t.\u0275\u0275domElementStart(0, "div", 1), t.\u0275\u0275repeaterCreate(1, Fu, 6, 5, "div", 5, ua), t.\u0275\u0275domElementEnd()), n & 2) {
    let e = t.\u0275\u0275nextContext();
    t.\u0275\u0275advance(), t.\u0275\u0275repeater(e.filters());
} }
var Xi = new k("ACCORDION"), ga = new k("MD_EXPANSION_PANEL"), fa = (() => { class n {
    _template = d(H);
    _expansionPanel = d(ga, { optional: !0 });
    constructor() { }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["ng-template", "mdExpansionPanelContent", ""]] });
} return n; })(), ba = new k("EXPANSION_PANEL_DEFAULT_OPTIONS"), _a = (() => {
    class n extends Pd {
        _viewContainerRef = d(ge);
        _animationsDisabled = !1;
        _document = d(ve);
        _ngZone = d(K);
        _elementRef = d(x);
        _renderer = d(ye);
        _cleanupTransitionEnd;
        get hideToggle() { return this._hideToggle || this.accordion && this.accordion.hideToggle; }
        set hideToggle(e) { this._hideToggle = e; }
        _hideToggle = !1;
        get togglePosition() { return this._togglePosition || this.accordion && this.accordion.togglePosition; }
        set togglePosition(e) { this._togglePosition = e; }
        _togglePosition;
        afterExpand = new p;
        afterCollapse = new p;
        _inputChanges = new D;
        accordion = d(Xi, { optional: !0, skipSelf: !0 });
        _lazyContent;
        _body;
        _bodyWrapper;
        _portal;
        _headerId = d(W).getId("expansion-panel-header-");
        constructor() { super(); let e = d(ba, { optional: !0 }); this._expansionDispatcher = d(Wr), e && (this.hideToggle = e.hideToggle); }
        _hasSpacing() { return this.accordion ? this.expanded && this.accordion.displayMode === "default" : !1; }
        _getExpandedState() { return this.expanded ? "expanded" : "collapsed"; }
        toggle() { this.expanded = !this.expanded; }
        close() { this.expanded = !1; }
        open() { this.expanded = !0; }
        ngAfterContentInit() { this._lazyContent && this._lazyContent._expansionPanel === this && this.opened.pipe(z(null), V(() => this.expanded && !this._portal), pe(1)).subscribe(() => { this._portal = new xe(this._lazyContent._template, this._viewContainerRef); }), this._setupAnimationEvents(); }
        ngOnChanges(e) { this._inputChanges.next(e); }
        ngOnDestroy() { super.ngOnDestroy(), this._cleanupTransitionEnd?.(), this._inputChanges.complete(); }
        _containsFocus() { if (this._body) {
            let e = this._document.activeElement, i = this._body.nativeElement;
            return e === i || i.contains(e);
        } return !1; }
        _transitionEndListener = ({ target: e, propertyName: i }) => { e === this._bodyWrapper?.nativeElement && i === "grid-template-rows" && this._ngZone.run(() => { this.expanded ? this.afterExpand.emit() : this.afterCollapse.emit(); }); };
        _setupAnimationEvents() { this._ngZone.runOutsideAngular(() => { this._animationsDisabled ? (this.opened.subscribe(() => this._ngZone.run(() => this.afterExpand.emit())), this.closed.subscribe(() => this._ngZone.run(() => this.afterCollapse.emit()))) : setTimeout(() => { let e = this._elementRef.nativeElement; this._cleanupTransitionEnd = this._renderer.listen(e, "transitionend", this._transitionEndListener), e.classList.add("expansion-panel-animations-enabled"); }, 200); }); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-expansion-panel"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, fa, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._lazyContent = s.first);
            } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(hl, 5)(pl, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._body = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._bodyWrapper = r.first);
            } }, hostAttrs: [1, "expansion-panel"], hostVars: 2, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("expanded", o.expanded); }, inputs: { hideToggle: [2, "hideToggle", "hideToggle", m], togglePosition: "togglePosition" }, outputs: { afterExpand: "afterExpand", afterCollapse: "afterCollapse" }, exportAs: ["expansionPanel"], features: [t.\u0275\u0275ProvidersFeature([{ provide: Xi, useValue: void 0 }, { provide: ga, useExisting: n }]), t.\u0275\u0275InheritDefinitionFeature, t.\u0275\u0275NgOnChangesFeature], ngContentSelectors: gl, decls: 9, vars: 4, consts: [["bodyWrapper", ""], ["body", ""], [1, "expansion-panel-content-wrapper"], ["role", "region", 1, "expansion-panel-content", 3, "id"], [1, "expansion-panel-body"], [3, "cdkPortalOutlet"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(ul), t.\u0275\u0275projection(0), t.\u0275\u0275elementStart(1, "div", 2, 0)(3, "div", 3, 1)(5, "div", 4), t.\u0275\u0275projection(6, 1), t.\u0275\u0275template(7, fl, 0, 0, "ng-template", 5), t.\u0275\u0275elementEnd(), t.\u0275\u0275projection(8, 2), t.\u0275\u0275elementEnd()()), i & 2 && (t.\u0275\u0275advance(), t.\u0275\u0275attribute("inert", o.expanded ? null : ""), t.\u0275\u0275advance(2), t.\u0275\u0275property("id", o.id), t.\u0275\u0275attribute("aria-labelledby", o._headerId), t.\u0275\u0275advance(4), t.\u0275\u0275property("cdkPortalOutlet", o._portal)); }, dependencies: [Le], styles: [`.expansion-panel{box-sizing:content-box;display:block;margin:0;overflow:hidden}.expansion-panel.expansion-panel-animations-enabled{transition:margin 225ms cubic-bezier(.4,0,.2,1)}.expansion-panel{position:relative;background:var(--%NS%md-expansion-panel-background, #F3F3F3);color:var(--%NS%md-expansion-panel-color, #000000)}.expansion-panel-content-wrapper{display:grid;grid-template-rows:0fr;grid-template-columns:100%}.expansion-panel-animations-enabled .expansion-panel-content-wrapper{transition:grid-template-rows 225ms cubic-bezier(.4,0,.2,1)}.expansion-panel.expanded>.expansion-panel-content-wrapper{grid-template-rows:1fr}@supports not (grid-template-rows: 0fr){.expansion-panel-content-wrapper{height:0}.expansion-panel.expanded>.expansion-panel-content-wrapper{height:auto}}.expansion-panel-content{display:flex;flex-direction:column;overflow:visible;min-height:0;visibility:hidden}.expansion-panel-animations-enabled .expansion-panel-content{transition:visibility .19s linear}.expansion-panel.expanded>.expansion-panel-content-wrapper>.expansion-panel-content{visibility:visible}.expansion-panel-body{padding:0 24px 16px}.accordion>.expansion-panel:not(:last-child){margin-bottom:8px}.action-row{border-top-style:solid;border-top-width:1px;display:flex;flex-direction:row;justify-content:flex-end;padding:12px 16px;border-top-color:var(--%NS%md-expansion-panel-border-color, #EAEAEA)}.action-row .button-base,.action-row .mdc-button-base{margin-left:8px}[dir=rtl] .action-row .button-base,[dir=rtl] .action-row .mdc-button-base{margin-left:0;margin-right:8px}
`], encapsulation: 2 });
    }
    return n;
})(), Au = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["action-row"]], hostAttrs: [1, "action-row"] });
} return n; })(), va = (() => {
    class n {
        panel = d(_a, { host: !0 });
        _element = d(x);
        _focusMonitor = d(Ae);
        _changeDetectorRef = d(E);
        _parentChangeSubscription = F.EMPTY;
        constructor() { let e = this.panel, i = d(ba, { optional: !0 }), o = d(new Cn("tabindex"), { optional: !0 }); this.tabIndex = parseInt(o || "") || 0; let r = e.accordion ? e.accordion._stateChanges.pipe(V(s => !!(s.hideToggle || s.togglePosition))) : En; this._parentChangeSubscription = R(e.opened, e.closed, r, e._inputChanges.pipe(V(s => !!(s.hideToggle || s.disabled || s.togglePosition)))).subscribe(() => this._changeDetectorRef.markForCheck()), e.closed.pipe(V(() => e._containsFocus())).subscribe(() => this._focusMonitor.focusVia(this._element, "program")), i && (this.expandedHeight = i.expandedHeight, this.collapsedHeight = i.collapsedHeight); }
        expandedHeight;
        collapsedHeight;
        tabIndex = 0;
        get disabled() { return this.panel.disabled; }
        _toggle() { this.disabled || this.panel.toggle(); }
        _isExpanded() { return this.panel.expanded; }
        _getExpandedState() { return this.panel._getExpandedState(); }
        _getPanelId() { return this.panel.id; }
        _getTogglePosition() { return this.panel.togglePosition; }
        _showToggle() { return !this.panel.hideToggle && !this.panel.disabled; }
        _getHeaderHeight() { let e = this._isExpanded(); return e && this.expandedHeight ? this.expandedHeight : !e && this.collapsedHeight ? this.collapsedHeight : null; }
        _keydown(e) { switch (e.keyCode) {
            case se:
            case Q:
                q(e) || (e.preventDefault(), this._toggle());
                break;
            default:
                this.panel.accordion && this.panel.accordion._handleHeaderKeydown(e);
                return;
        } }
        focus(e, i) { e ? this._focusMonitor.focusVia(this._element, e, i) : this._element.nativeElement.focus(i); }
        ngAfterViewInit() { this._focusMonitor.monitor(this._element).subscribe(e => { e && this.panel.accordion && this.panel.accordion._handleHeaderFocus(this); }); }
        ngOnDestroy() { this._parentChangeSubscription.unsubscribe(), this._focusMonitor.stopMonitoring(this._element); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-expansion-panel-header"]], hostAttrs: ["role", "button", 1, "expansion-panel-header", "focus-indicator"], hostVars: 13, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function () { return o._toggle(); })("keydown", function (s) { return o._keydown(s); }), i & 2 && (t.\u0275\u0275attribute("id", o.panel._headerId)("tabindex", o.disabled ? -1 : o.tabIndex)("aria-controls", o._getPanelId())("aria-expanded", o._isExpanded())("aria-disabled", o.panel.disabled), t.\u0275\u0275styleProp("height", o._getHeaderHeight()), t.\u0275\u0275classProp("expanded", o._isExpanded())("expansion-toggle-indicator-after", o._getTogglePosition() === "after")("expansion-toggle-indicator-before", o._getTogglePosition() === "before")); }, inputs: { expandedHeight: "expandedHeight", collapsedHeight: "collapsedHeight", tabIndex: [2, "tabIndex", "tabIndex", e => e == null ? 0 : S(e)] }, ngContentSelectors: _l, decls: 5, vars: 3, consts: [[1, "content"], [1, "expansion-indicator"], ["xmlns", "http://www.w3.org/2000/svg", "viewBox", "0 -960 960 960", "aria-hidden", "true", "focusable", "false"], ["d", "M480-345 240-585l56-56 184 184 184-184 56 56-240 240Z"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(bl), t.\u0275\u0275domElementStart(0, "span", 0), t.\u0275\u0275projection(1), t.\u0275\u0275projection(2, 1), t.\u0275\u0275projection(3, 2), t.\u0275\u0275domElementEnd(), t.\u0275\u0275conditionalCreate(4, vl, 3, 0, "span", 1)), i & 2 && (t.\u0275\u0275classProp("content-hide-toggle", !o._showToggle()), t.\u0275\u0275advance(4), t.\u0275\u0275conditional(o._showToggle() ? 4 : -1)); }, styles: [`.expansion-panel-header{display:flex;flex-direction:row;align-items:center;padding:0 24px;border-radius:inherit}.expansion-panel-animations-enabled .expansion-panel-header{transition:height 225ms cubic-bezier(.4,0,.2,1)}.expansion-panel-header:before{border-radius:inherit}.expansion-panel-header{height:66px;font-family:var(--%NS%md-expansion-header-font-family, var(--%NS%md-font-heading, "Montserrat"));font-size:1rem;font-weight:600;line-height:1.5rem;letter-spacing:.009rem}.expansion-panel-header.expanded{height:66px}.expansion-panel-header[aria-disabled=true]{color:var(--%NS%md-expansion-header-disabled-color, color-mix(in srgb, currentColor 38%, transparent))}.expansion-panel-header:not([aria-disabled=true]){cursor:pointer}.expansion-panel:not(.expanded) .expansion-panel-header:not([aria-disabled=true]):hover{background:var(--%NS%md-expansion-header-hover-background, color-mix(in srgb, currentColor 8%, transparent))}.expansion-panel .expansion-panel-header:not([aria-disabled=true]).cdk-keyboard-focused,.expansion-panel .expansion-panel-header:not([aria-disabled=true]).cdk-program-focused{background:var(--%NS%md-expansion-header-focus-background, color-mix(in srgb, currentColor 12%, transparent))}.expansion-panel-header._animation-noopable{transition:none}.expansion-panel-header:focus,.expansion-panel-header:hover{outline:none}.expansion-panel-header.expanded:focus,.expansion-panel-header.expanded:hover{background:inherit}.expansion-panel-header.expansion-toggle-indicator-before{flex-direction:row-reverse}.expansion-panel-header.expansion-toggle-indicator-before .expansion-indicator{margin:0 16px 0 0}[dir=rtl] .expansion-panel-header.expansion-toggle-indicator-before .expansion-indicator{margin:0 0 0 16px}.content{display:flex;flex:1;flex-direction:row;overflow:hidden}.content.content-hide-toggle{margin-right:8px}[dir=rtl] .content.content-hide-toggle{margin-right:0;margin-left:8px}.expansion-toggle-indicator-before .content.content-hide-toggle{margin-left:24px;margin-right:0}[dir=rtl] .expansion-toggle-indicator-before .content.content-hide-toggle{margin-right:24px;margin-left:0}.expansion-panel-header-title{color:var(--%NS%md-expansion-header-title-color, #373737);font-size:18px;line-height:24px;font-weight:600;text-transform:none}.expansion-panel-header-title,.expansion-panel-header-description{display:flex;flex-grow:1;flex-basis:0;margin-right:16px;align-items:center}[dir=rtl] .expansion-panel-header-title,[dir=rtl] .expansion-panel-header-description{margin-right:0;margin-left:16px}.expansion-panel-header[aria-disabled=true] .expansion-panel-header-title,.expansion-panel-header[aria-disabled=true] .expansion-panel-header-description{color:inherit}.expansion-panel-header-description{flex-grow:2;color:var(--%NS%md-expansion-header-description-color, #373737)}.expansion-panel-animations-enabled .expansion-indicator{transition:transform 225ms cubic-bezier(.4,0,.2,1)}.expansion-panel-header.expanded .expansion-indicator{transform:rotate(180deg)}.expansion-indicator svg{width:24px;height:24px;margin:0 -8px;vertical-align:middle;fill:var(--%NS%md-expansion-indicator-color, #000000);display:inline-block}@media(forced-colors:active){.expansion-panel-content{border-top:1px solid;border-top-left-radius:0;border-top-right-radius:0}}
`], encapsulation: 2 });
    }
    return n;
})(), Lu = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-panel-description"]], hostAttrs: [1, "expansion-panel-header-description"] });
} return n; })(), Bu = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-panel-title"]], hostAttrs: [1, "expansion-panel-header-title"] });
} return n; })(), zu = (() => { class n extends Od {
    _keyManager;
    _ownHeaders = new _t;
    _headers;
    hideToggle = !1;
    displayMode = "default";
    togglePosition = "after";
    ngAfterContentInit() { this._headers.changes.pipe(z(this._headers)).subscribe(e => { this._ownHeaders.reset(e.filter(i => i.panel.accordion === this)), this._ownHeaders.notifyOnChanges(); }), this._keyManager = new Xt(this._ownHeaders).withWrap().withHomeAndEnd(); }
    _handleHeaderKeydown(e) { this._keyManager.onKeydown(e); }
    _handleHeaderFocus(e) { this._keyManager.updateActiveItem(e); }
    ngOnDestroy() { super.ngOnDestroy(), this._keyManager?.destroy(), this._ownHeaders.destroy(); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-accordion"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, va, 5), i & 2) {
            let s;
            t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._headers = s);
        } }, hostAttrs: [1, "accordion"], hostVars: 2, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("accordion-multi", o.multi); }, inputs: { hideToggle: [2, "hideToggle", "hideToggle", m], displayMode: "displayMode", togglePosition: "togglePosition" }, exportAs: ["mdAccordion"], features: [t.\u0275\u0275ProvidersFeature([{ provide: Xi, useExisting: n }]), t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), zv = [zu, _a, Au, va, Bu, Lu, fa], Vv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [ae] });
} return n; })(), Vu = new k("CARD_CONFIG"), Hv = (() => {
    class n {
        appearance;
        constructor() { let e = d(Vu, { optional: !0 }); this.appearance = e?.appearance || "outlined"; }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-card"]], hostAttrs: [1, "mdc-card", "mdc-card"], hostVars: 8, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("mdc-card-outlined", o.appearance === "outlined")("mdc-card--outlined", o.appearance === "outlined")("mdc-card-filled", o.appearance === "filled")("mdc-card--filled", o.appearance === "filled"); }, inputs: { appearance: "appearance" }, exportAs: ["mdCard"], ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275projection(0)); }, styles: [`.mdc-card{flex:1;overflow:auto;display:flex;flex-direction:column;box-sizing:border-box;position:relative;border-style:solid;border-width:0;background-color:var(--%NS%md-card-surface, #fdf1f2);border-color:var(--%NS%md-card-border-color, #fdf1f2);border-radius:var(--%NS%md-card-radius, 5px);color:var(--%NS%md-card-color, var(--%NS%md-color-text, inherit));box-shadow:none;padding:20px;font-family:var(--%NS%md-card-font-family, var(--%NS%md-font-heading, Montserrat))}.mdc-card:after{position:absolute;top:0;left:0;width:100%;height:100%;border:solid 1px transparent;content:"";display:block;pointer-events:none;box-sizing:border-box;border-radius:var(--%NS%md-card-radius, 5px)}.mdc-card-outlined{background-color:var(--%NS%md-card-outlined-surface, #F3F3F3);border-radius:var(--%NS%md-card-radius, 5px)}.mdc-card-outlined:after{border:none}.mdc-card-filled{background-color:var(--%NS%md-card-filled-surface, #e3e2e6);border-radius:var(--%NS%md-card-radius, 5px);box-shadow:none}.mdc-card__media{position:relative;box-sizing:border-box;background-repeat:no-repeat;background-position:center;background-size:cover}.mdc-card__media:before{display:block;content:""}.mdc-card__media:first-child{border-top-left-radius:inherit;border-top-right-radius:inherit}.mdc-card__media:last-child{border-bottom-left-radius:inherit;border-bottom-right-radius:inherit}.mdc-card-actions{display:flex;flex-direction:row;align-items:center;box-sizing:border-box;min-height:52px}.mdc-card-title{color:var(--%NS%md-card-title-color, var(--%NS%md-color-heading, currentColor));line-height:1.75rem;font-size:1.375rem;letter-spacing:0;font-weight:700}.mdc-card-subtitle{color:var(--%NS%md-card-subtitle-color, #201a1b);line-height:1.5rem;font-size:1rem;letter-spacing:.009rem;font-weight:500}.mdc-card-title,.mdc-card-subtitle{display:block;margin:0}.mdc-card-avatar~.mdc-card-header-text .mdc-card-title,.mdc-card-avatar~.mdc-card-header-text .mdc-card-subtitle{padding:16px 16px 0}.mdc-card-content{display:flex;flex-direction:column;height:100%;overflow:auto;flex:1}.mdc-card-title-group{display:flex;justify-content:space-between;width:100%}.mdc-card-avatar{height:40px;width:40px;border-radius:50%;flex-shrink:0;margin-bottom:16px;object-fit:cover}.mdc-card-avatar~.mdc-card-header-text .mdc-card-subtitle,.mdc-card-avatar~.mdc-card-header-text .mdc-card-title{line-height:normal}.mdc-card-sm-image{width:80px;height:80px}.mdc-card-md-image{width:112px;height:112px}.mdc-card-lg-image{width:152px;height:152px}.mdc-card-xl-image{width:240px;height:240px}.mdc-card-subtitle~.mdc-card-title,.mdc-card-title~.mdc-card-subtitle,.mdc-card-header .mdc-card-header-text .mdc-card-title,.mdc-card-header .mdc-card-header-text .mdc-card-subtitle,.mdc-card-title-group .mdc-card-title,.mdc-card-title-group .mdc-card-subtitle{padding-top:0}.mdc-card-content>:last-child:not(.mdc-card-footer){margin-bottom:0}.mdc-card-actions-align-end{justify-content:flex-end}
`], encapsulation: 2 });
    }
    return n;
})(), jv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-card-title"], ["", "md-card-title", ""], ["", "mdCardTitle", ""]], hostAttrs: [1, "mdc-card-title"] });
} return n; })(), Wv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-card-title-group"]], hostAttrs: [1, "mdc-card-title-group"], ngContentSelectors: xl, decls: 4, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(yl), t.\u0275\u0275domElementStart(0, "div"), t.\u0275\u0275projection(1), t.\u0275\u0275domElementEnd(), t.\u0275\u0275projection(2, 1), t.\u0275\u0275projection(3, 2)); }, encapsulation: 2 });
} return n; })(), Gv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-card-content"]], hostAttrs: [1, "mdc-card-content"] });
} return n; })(), $v = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-card-subtitle"], ["", "md-card-subtitle", ""], ["", "mdCardSubtitle", ""]], hostAttrs: [1, "mdc-card-subtitle"] });
} return n; })(), Yv = (() => { class n {
    align = "start";
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-card-actions"]], hostAttrs: [1, "mdc-card-actions", "mdc-card__actions"], hostVars: 2, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("mdc-card-actions-align-end", o.align === "end"); }, inputs: { align: "align" }, exportAs: ["mdCardActions"] });
} return n; })(), qv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-card-header"]], hostAttrs: [1, "mdc-card-header"], ngContentSelectors: Cl, decls: 4, vars: 0, consts: [[1, "mdc-card-header-text"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(kl), t.\u0275\u0275projection(0), t.\u0275\u0275domElementStart(1, "div", 0), t.\u0275\u0275projection(2, 1), t.\u0275\u0275domElementEnd(), t.\u0275\u0275projection(3, 2)); }, encapsulation: 2 });
} return n; })(), Qv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-card-footer"]], hostAttrs: [1, "mdc-card-footer"] });
} return n; })(), Kv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-card-image", ""], ["", "mdCardImage", ""]], hostAttrs: [1, "mdc-card-image", "mdc-card__media"] });
} return n; })(), Uv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-card-sm-image", ""], ["", "mdCardImageSmall", ""]], hostAttrs: [1, "mdc-card-sm-image", "mdc-card__media"] });
} return n; })(), Xv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-card-md-image", ""], ["", "mdCardImageMedium", ""]], hostAttrs: [1, "mdc-card-md-image", "mdc-card__media"] });
} return n; })(), Zv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-card-lg-image", ""], ["", "mdCardImageLarge", ""]], hostAttrs: [1, "mdc-card-lg-image", "mdc-card__media"] });
} return n; })(), Jv = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-card-xl-image", ""], ["", "mdCardImageXLarge", ""]], hostAttrs: [1, "mdc-card-xl-image", "mdc-card__media"] });
} return n; })(), ey = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-card-avatar", ""], ["", "mdCardAvatar", ""]], hostAttrs: [1, "mdc-card-avatar"] });
} return n; })();
var ty = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), Wt = class {
    viewContainerRef;
    injector;
    id;
    role = "dialog";
    panelClass = "";
    hasBackdrop = !0;
    backdropClass = "";
    disableClose = !1;
    closePredicate;
    width = "";
    height = "";
    minWidth;
    minHeight;
    maxWidth;
    maxHeight;
    position;
    data = null;
    direction;
    ariaDescribedBy = null;
    ariaLabelledBy = null;
    ariaLabel = null;
    ariaModal = !1;
    autoFocus = "first-tabbable";
    restoreFocus = !0;
    delayFocusTrap = !0;
    scrollStrategy;
    closeOnNavigation = !0;
    enterAnimationDuration;
    exitAnimationDuration;
    animationPosition;
}, Vt = (function (n) { return n[n.OPEN = 0] = "OPEN", n[n.CLOSING = 1] = "CLOSING", n[n.CLOSED = 2] = "CLOSED", n; })(Vt || {}), ht = class {
    _ref;
    _config;
    _containerInstance;
    componentInstance;
    componentRef;
    disableClose;
    id;
    _afterOpened = new D;
    _beforeClosed = new D;
    _result;
    _closeFallbackTimeout;
    _state = Vt.OPEN;
    _closeInteractionType;
    constructor(a, e, i) { this._ref = a, this._config = e, this._containerInstance = i, this.disableClose = e.disableClose, this.id = a.id, a.addPanelClass("mdc-dialog-panel"), i._animationStateChanged.pipe(V(o => o.state === "opened"), pe(1)).subscribe(() => { this._afterOpened.next(), this._afterOpened.complete(); }), i._animationStateChanged.pipe(V(o => o.state === "closed"), pe(1)).subscribe(() => { clearTimeout(this._closeFallbackTimeout), this._finishDialogClose(); }), a.overlayRef.detachments().subscribe(() => { this._beforeClosed.next(this._result), this._beforeClosed.complete(), this._finishDialogClose(); }), R(this.backdropClick(), this.keydownEvents().pipe(V(o => o.keyCode === qe && !this.disableClose && !q(o)))).subscribe(o => { this.disableClose || (o.preventDefault(), ya(this, o.type === "keydown" ? "keyboard" : "mouse")); }); }
    close(a) { let e = this._config.closePredicate; e && !e(a, this._config, this.componentInstance) || (this._result = a, this._containerInstance._animationStateChanged.pipe(V(i => i.state === "closing"), pe(1)).subscribe(i => { this._beforeClosed.next(a), this._beforeClosed.complete(), this._ref.overlayRef.detachBackdrop(), this._closeFallbackTimeout = setTimeout(() => this._finishDialogClose(), i.totalTime + 100); }), this._state = Vt.CLOSING, this._containerInstance._startExitAnimation()); }
    afterOpened() { return this._afterOpened; }
    afterClosed() { return this._ref.closed; }
    beforeClosed() { return this._beforeClosed; }
    backdropClick() { return this._ref.backdropClick; }
    keydownEvents() { return this._ref.keydownEvents; }
    updatePosition(a) { let e = this._ref.config.positionStrategy; return a && (a.left || a.right) ? a.left ? e.left(a.left) : e.right(a.right) : e.centerHorizontally(), a && (a.top || a.bottom) ? a.top ? e.top(a.top) : e.bottom(a.bottom) : e.centerVertically(), this._ref.updatePosition(), this; }
    updateSize(a = "", e = "") { return this._ref.updateSize(a, e), this; }
    addPanelClass(a) { return this._ref.addPanelClass(a), this; }
    removePanelClass(a) { return this._ref.removePanelClass(a), this; }
    getState() { return this._state; }
    _finishDialogClose() { this._state = Vt.CLOSED, this._ref.close(this._result, { focusOrigin: this._closeInteractionType }), this.componentInstance = null; }
};
function ya(n, a, e) { return n._closeInteractionType = a, n.close(e); }
var Ai = "mdc-dialog--open", hr = "mdc-dialog--opening", pr = "mdc-dialog--closing", Hu = 150, ju = 75, Wu = (() => {
    class n extends Fn {
        _animationStateChanged = new p;
        _animationsEnabled = !0;
        _actionSectionCount = 0;
        _hostElement = this._elementRef.nativeElement;
        _enterAnimationDuration = this._animationsEnabled ? gr(this._config.enterAnimationDuration) ?? Hu : 0;
        _exitAnimationDuration = this._animationsEnabled ? gr(this._config.exitAnimationDuration) ?? ju : 0;
        _animationTimer = null;
        _contentAttached() { super._contentAttached(), this._startOpenAnimation(); }
        ANIMATION_POSITION_CLASS = this._config.animationPosition ? `mdc-animation-position-${this._config.animationPosition}` : null;
        _startOpenAnimation() { this._animationStateChanged.emit({ state: "opening", totalTime: this._enterAnimationDuration }), this._animationsEnabled ? (this._hostElement.style.setProperty(ur, `${this._enterAnimationDuration}ms`), this._requestAnimationFrame(() => { this._hostElement.classList.add(hr, Ai), this.ANIMATION_POSITION_CLASS && this._hostElement.classList.add(this.ANIMATION_POSITION_CLASS); }), this._waitForAnimationToComplete(this._enterAnimationDuration, this._finishDialogOpen)) : (this._hostElement.classList.add(Ai), Promise.resolve().then(() => this._finishDialogOpen())); }
        _startExitAnimation() { this._animationStateChanged.emit({ state: "closing", totalTime: this._exitAnimationDuration }), this._hostElement.classList.remove(Ai), this._animationsEnabled ? (this._hostElement.style.setProperty(ur, `${this._exitAnimationDuration}ms`), this._requestAnimationFrame(() => { this._hostElement.classList.add(pr), this.ANIMATION_POSITION_CLASS && this._hostElement.classList.add(this.ANIMATION_POSITION_CLASS); }), this._waitForAnimationToComplete(this._exitAnimationDuration, this._finishDialogClose)) : Promise.resolve().then(() => this._finishDialogClose()); }
        _updateActionSectionCount(e) { this._actionSectionCount += e, this._changeDetectorRef.markForCheck(); }
        _finishDialogOpen = () => { this._clearAnimationClasses(), this._openAnimationDone(this._enterAnimationDuration); };
        _finishDialogClose = () => { this._clearAnimationClasses(), this._animationStateChanged.emit({ state: "closed", totalTime: this._exitAnimationDuration }); };
        _clearAnimationClasses() { this._hostElement.classList.remove(hr, pr), this.ANIMATION_POSITION_CLASS && this._hostElement.classList.remove(this.ANIMATION_POSITION_CLASS); }
        _waitForAnimationToComplete(e, i) { this._animationTimer !== null && clearTimeout(this._animationTimer), this._animationTimer = setTimeout(i, e); }
        _requestAnimationFrame(e) { this._ngZone.runOutsideAngular(() => { typeof requestAnimationFrame == "function" ? requestAnimationFrame(e) : e(); }); }
        _captureInitialFocus() { this._config.delayFocusTrap || this._trapFocus(); }
        _openAnimationDone(e) { this._config.delayFocusTrap && this._trapFocus(), this._animationStateChanged.next({ state: "opened", totalTime: e }); }
        ngOnDestroy() { super.ngOnDestroy(), this._animationTimer !== null && clearTimeout(this._animationTimer); }
        attachComponentPortal(e) { let i = super.attachComponentPortal(e); return i.location.nativeElement.classList.add("mdc-dialog-component-host"), i; }
        static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-dialog-container"]], hostAttrs: ["tabindex", "-1", 1, "mdc-dialog-container", "mdc-dialog"], hostVars: 10, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275domProperty("id", o._config.id), t.\u0275\u0275attribute("aria-modal", o._config.ariaModal)("role", o._config.role)("aria-labelledby", o._config.ariaLabel ? null : o._ariaLabelledByQueue[0])("aria-label", o._config.ariaLabel)("aria-describedby", o._config.ariaDescribedBy || null), t.\u0275\u0275classProp("animation-noopable", !o._animationsEnabled)("mdc-dialog-container-with-actions", o._actionSectionCount > 0)); }, features: [t.\u0275\u0275InheritDefinitionFeature], decls: 3, vars: 0, consts: [[1, "mdc-dialog-inner-container", "mdc-dialog__container"], [1, "mdc-dialog-surface", "mdc-dialog__surface"], ["cdkPortalOutlet", ""]], template: function (i, o) { i & 1 && (t.\u0275\u0275elementStart(0, "div", 0)(1, "div", 1), t.\u0275\u0275template(2, wl, 0, 0, "ng-template", 2), t.\u0275\u0275elementEnd()()); }, dependencies: [Le], styles: [`.mdc-dialog-container{width:100%;height:100%;display:block;box-sizing:border-box;max-height:inherit;min-height:inherit;min-width:inherit;max-width:inherit;outline:0}.cdk-overlay-pane.mdc-dialog-panel{max-width:560px;min-width:280px}@media(max-width:599px){.cdk-overlay-pane.mdc-dialog-panel{max-width:calc(100vw - 32px)}}.mdc-dialog-inner-container{display:flex;flex-direction:row;align-items:center;justify-content:space-around;box-sizing:border-box;height:100%;opacity:0;transition:opacity linear var(--%NS%dialog-transition-duration, .15s);max-height:inherit;min-height:inherit;min-width:inherit;max-width:inherit}.mdc-dialog--opening.mdc-animation-position-left .mdc-dialog-inner-container{animation:left-enter var(--%NS%dialog-transition-duration, .15s) cubic-bezier(0,0,.2,1) forwards}.mdc-dialog--opening.mdc-animation-position-right .mdc-dialog-inner-container{animation:right-enter var(--%NS%dialog-transition-duration, .15s) cubic-bezier(0,0,.2,1) forwards}.mdc-dialog--opening.mdc-animation-position-top .mdc-dialog-inner-container{animation:top-enter var(--%NS%dialog-transition-duration, .15s) cubic-bezier(0,0,.2,1) forwards}.mdc-dialog--opening.mdc-animation-position-bottom .mdc-dialog-inner-container{animation:bottom-enter var(--%NS%dialog-transition-duration, .15s) cubic-bezier(0,0,.2,1) forwards}.mdc-dialog--closing.mdc-animation-position-left .mdc-dialog-inner-container{animation:left-exit var(--%NS%dialog-transition-duration, 75ms) cubic-bezier(.4,0,1,1) backwards}.mdc-dialog--closing.mdc-animation-position-right .mdc-dialog-inner-container{animation:right-exit var(--%NS%dialog-transition-duration, 75ms) cubic-bezier(.4,0,1,1) backwards}.mdc-dialog--closing.mdc-animation-position-top .mdc-dialog-inner-container{animation:top-exit var(--%NS%dialog-transition-duration, 75ms) cubic-bezier(.4,0,1,1) backwards}.mdc-dialog--closing.mdc-animation-position-bottom .mdc-dialog-inner-container{animation:bottom-exit var(--%NS%dialog-transition-duration, 75ms) cubic-bezier(.4,0,1,1) backwards}.mdc-dialog--closing .mdc-dialog-inner-container{transition:opacity var(--%NS%dialog-transition-duration, 75ms) linear;transform:none}.mdc-dialog--open .mdc-dialog-inner-container{opacity:1}.animation-noopable .mdc-dialog-inner-container{transition:none}.mdc-dialog-surface{display:flex;flex-direction:column;flex-grow:0;flex-shrink:0;box-sizing:border-box;width:100%;height:100%;position:relative;overflow-y:auto;outline:0;transform:scale(.8);transition:transform .15s cubic-bezier(0,0,.2,1);max-height:inherit;min-height:inherit;min-width:inherit;max-width:inherit;box-shadow:var(--%NS%md-dialog-shadow, none);border:var(--%NS%md-dialog-border, none);color:var(--%NS%md-dialog-color, inherit);border-radius:var(--%NS%md-dialog-radius, 5px);background-color:var(--%NS%md-dialog-surface, #FFFFFF)}[dir=rtl] .mdc-dialog-surface{text-align:right}.mdc-dialog--open .mdc-dialog-surface,.mdc-dialog--closing .mdc-dialog-surface{transform:none}.animation-noopable .mdc-dialog-surface{transition:none}.mdc-dialog-surface:before{position:absolute;box-sizing:border-box;width:100%;height:100%;top:0;left:0;border:2px solid transparent;border-radius:inherit;content:"";pointer-events:none}.mdc-dialog-title{display:block;position:relative;flex-shrink:0;box-sizing:border-box;margin:0 0 1px;padding:var(--%NS%md-dialog-title-padding, 6px 24px 13px)}.mdc-dialog-title:before{display:inline-block;width:0;height:var(--%NS%md-dialog-title-spacer-height, 37px);content:"";vertical-align:0}[dir=rtl] .mdc-dialog-title{text-align:right}.mdc-dialog-container .mdc-dialog-title{color:var(--%NS%md-dialog-title-color, #201a1b);font-family:var(--%NS%md-dialog-title-font-family, var(--%NS%md-font-heading, "Montserrat"));line-height:var(--%NS%md-dialog-title-line-height, 2rem);font-size:var(--%NS%md-dialog-title-font-size, 1.5rem);font-weight:var(--%NS%md-dialog-title-font-weight, 400);letter-spacing:var(--%NS%md-dialog-title-letter-spacing, .03125em)}.mdc-dialog-content{display:block;flex-grow:1;box-sizing:border-box;margin:0;overflow:auto;max-height:var(--%NS%md-dialog-content-max-height, 65vh)}.mdc-dialog-content>:first-child{margin-top:0}.mdc-dialog-content>:last-child{margin-bottom:0}.mdc-dialog-container .mdc-dialog-content{color:inherit;font-family:inherit;line-height:inherit;font-size:inherit;font-weight:inherit;letter-spacing:inherit}.mdc-dialog-container .mdc-dialog-content,.mdc-dialog-container-with-actions .mdc-dialog-content{padding:var(--%NS%md-dialog-content-padding, 20px 24px 0)}.mdc-dialog-container .mdc-dialog-title+.mdc-dialog-content{padding-top:var(--%NS%md-dialog-content-padding-top-with-title, 0)}.mdc-dialog-actions{display:flex;position:relative;flex-shrink:0;flex-wrap:wrap;align-items:center;box-sizing:border-box;min-height:var(--%NS%md-dialog-actions-min-height, 52px);margin:0;border-top:1px solid transparent;padding:var(--%NS%md-dialog-actions-padding, 16px 24px);justify-content:flex-end}@media(forced-colors:active){.mdc-dialog-actions{border-top-color:CanvasText}}.mdc-dialog-actions.mdc-dialog-actions-align-start,.mdc-dialog-actions[align=start]{justify-content:start}.mdc-dialog-actions.mdc-dialog-actions-align-center,.mdc-dialog-actions[align=center]{justify-content:center}.mdc-dialog-actions.mdc-dialog-actions-align-end,.mdc-dialog-actions[align=end]{justify-content:flex-end}.mdc-dialog-actions .button-base+.button-base,.mdc-dialog-actions .mdc-button-base+.mdc-button-base{margin-left:var(--%NS%md-dialog-actions-button-spacing, 8px)}[dir=rtl] .mdc-dialog-actions .button-base+.button-base,[dir=rtl] .mdc-dialog-actions .mdc-button-base+.mdc-button-base{margin-left:0;margin-right:var(--%NS%md-dialog-actions-button-spacing, 8px)}.mdc-dialog-component-host{display:contents}.cdk-overlay-dark-backdrop{background-color:var(--%NS%md-color-backdrop, rgba(0, 0, 0, .5))}@keyframes left-enter{0%{transform:translate(-100%)}to{transform:none}}@keyframes left-exit{0%{transform:none}to{transform:translate(-100%)}}@keyframes top-enter{0%{transform:translateY(-100%)}to{transform:none}}@keyframes top-exit{0%{transform:none}to{transform:translateY(-100%)}}@keyframes bottom-enter{0%{transform:translateY(100%)}to{transform:none}}@keyframes bottom-exit{0%{transform:none}to{transform:translateY(100%)}}@keyframes right-enter{0%{transform:translate(100%)}to{transform:none}}@keyframes right-exit{0%{transform:none}to{transform:translate(100%)}}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})(), ur = "--dialog-transition-duration";
function gr(n) { return n == null ? null : typeof n == "number" ? n : n.endsWith("ms") ? Pe(n.substring(0, n.length - 2)) : n.endsWith("s") ? Pe(n.substring(0, n.length - 1)) * 1e3 : n === "0" ? 0 : null; }
var Gu = new k("MdcDialogData"), $u = new k("mdc-dialog-default-options"), Yu = new k("mdc-dialog-scroll-strategy", { providedIn: "root", factory: () => { let n = d(j); return () => Pn(n); } }), $n = (() => { class n {
    _defaultOptions = d($u, { optional: !0 });
    _scrollStrategy = d(Yu);
    _parentDialog = d(n, { optional: !0, skipSelf: !0 });
    _idGenerator = d(W);
    _injector = d(j);
    _dialog = d(Rn);
    _animationsDisabled = !1;
    _openDialogsAtThisLevel = [];
    _afterAllClosedAtThisLevel = new D;
    _afterOpenedAtThisLevel = new D;
    dialogConfigClass = Wt;
    _dialogRefConstructor;
    _dialogContainerType;
    _dialogDataToken;
    get openDialogs() { return this._parentDialog ? this._parentDialog.openDialogs : this._openDialogsAtThisLevel; }
    get afterOpened() { return this._parentDialog ? this._parentDialog.afterOpened : this._afterOpenedAtThisLevel; }
    _getAfterAllClosed() { let e = this._parentDialog; return e ? e._getAfterAllClosed() : this._afterAllClosedAtThisLevel; }
    afterAllClosed = In(() => this.openDialogs.length ? this._getAfterAllClosed() : this._getAfterAllClosed().pipe(z(void 0)));
    constructor() { this._dialogRefConstructor = ht, this._dialogContainerType = Wu, this._dialogDataToken = Gu; }
    open(e, i = {}) { let o; i = _(_({}, this._defaultOptions || new Wt), i), i.id = i.id || this._idGenerator.getId("mdc-dialog-"), i.scrollStrategy = i.scrollStrategy || this._scrollStrategy(); let r = this._dialog.open(e, G(_({}, i), { positionStrategy: Zt(this._injector).centerHorizontally().centerVertically(), disableClose: !0, closePredicate: void 0, closeOnDestroy: !1, closeOnOverlayDetachments: !1, disableAnimations: this._animationsDisabled || i.enterAnimationDuration?.toLocaleString() === "0" || i.exitAnimationDuration?.toString() === "0", container: { type: this._dialogContainerType, providers: () => [{ provide: this.dialogConfigClass, useValue: i }, { provide: Kr, useValue: i }] }, templateContext: () => ({ dialogRef: o }), providers: (s, l, c) => (o = new this._dialogRefConstructor(s, i, c), o.updatePosition(i?.position), [{ provide: this._dialogContainerType, useValue: c }, { provide: this._dialogDataToken, useValue: l.data }, { provide: this._dialogRefConstructor, useValue: o }]) })); return o.componentRef = r.componentRef, o.componentInstance = r.componentInstance, this.openDialogs.push(o), this.afterOpened.next(o), o.afterClosed().subscribe(() => { let s = this.openDialogs.indexOf(o); s > -1 && (this.openDialogs.splice(s, 1), this.openDialogs.length || this._getAfterAllClosed().next()); }), o; }
    closeAll() { this._closeDialogs(this.openDialogs); }
    getDialogById(e) { return this.openDialogs.find(i => i.id === e); }
    ngOnDestroy() { this._closeDialogs(this._openDialogsAtThisLevel), this._afterAllClosedAtThisLevel.complete(), this._afterOpenedAtThisLevel.complete(); }
    _closeDialogs(e) { let i = e.length; for (; i--;)
        e[i].close(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), iy = (() => { class n {
    dialogRef = d(ht, { optional: !0 });
    _elementRef = d(x);
    _dialog = d($n);
    ariaLabel;
    type = "button";
    dialogResult;
    dialogClose;
    constructor() { }
    ngOnInit() { this.dialogRef || (this.dialogRef = ka(this._elementRef, this._dialog.openDialogs)); }
    ngOnChanges(e) { let i = e.dialogClose || e.dialogCloseResult; i && (this.dialogResult = i.currentValue); }
    _onButtonClick(e) { ya(this.dialogRef, e.screenX === 0 && e.screenY === 0 ? "keyboard" : "mouse", this.dialogResult); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-dialog-close", ""], ["", "mdDialogClose", ""]], hostVars: 2, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function (s) { return o._onButtonClick(s); }), i & 2 && t.\u0275\u0275attribute("aria-label", o.ariaLabel || null)("type", o.type); }, inputs: { ariaLabel: [0, "aria-label", "ariaLabel"], type: "type", dialogResult: [0, "md-dialog-close", "dialogResult"], dialogClose: [0, "mdDialogClose", "dialogClose"] }, exportAs: ["mdDialogClose"], features: [t.\u0275\u0275NgOnChangesFeature] });
} return n; })(), xa = (() => { class n {
    _dialogRef = d(ht, { optional: !0 });
    _elementRef = d(x);
    _dialog = d($n);
    constructor() { }
    ngOnInit() { this._dialogRef || (this._dialogRef = ka(this._elementRef, this._dialog.openDialogs)), this._dialogRef && Promise.resolve().then(() => { this._onAdd(); }); }
    ngOnDestroy() { this._dialogRef?._containerInstance && Promise.resolve().then(() => { this._onRemove(); }); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n });
} return n; })(), ny = (() => { class n extends xa {
    id = d(W).getId("mdc-dialog-title-");
    _onAdd() { this._dialogRef._containerInstance?._addAriaLabelledBy?.(this.id); }
    _onRemove() { this._dialogRef?._containerInstance?._removeAriaLabelledBy?.(this.id); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-dialog-title", ""], ["", "mdDialogTitle", ""]], hostAttrs: [1, "mdc-dialog-title", "mdc-dialog__title"], hostVars: 1, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275domProperty("id", o.id); }, inputs: { id: "id" }, exportAs: ["mdDialogTitle"], features: [t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), oy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-dialog-content", ""], ["md-dialog-content"], ["", "mdDialogContent", ""]], hostAttrs: [1, "mdc-dialog-content", "mdc-dialog__content"], features: [t.\u0275\u0275HostDirectivesFeature([Ur.CdkScrollable])] });
} return n; })(), ry = (() => { class n extends xa {
    align;
    _onAdd() { this._dialogRef._containerInstance?._updateActionSectionCount?.(1); }
    _onRemove() { this._dialogRef._containerInstance?._updateActionSectionCount?.(-1); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-dialog-actions", ""], ["md-dialog-actions"], ["", "mdDialogActions", ""]], hostAttrs: [1, "mdc-dialog-actions", "mdc-dialog__actions"], hostVars: 6, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("mdc-dialog-actions-align-start", o.align === "start")("mdc-dialog-actions-align-center", o.align === "center")("mdc-dialog-actions-align-end", o.align === "end"); }, inputs: { align: "align" }, features: [t.\u0275\u0275InheritDefinitionFeature] });
} return n; })();
function ka(n, a) { let e = n.nativeElement.parentElement; for (; e && !e.classList.contains("mdc-dialog-container");)
    e = e.parentElement; return e ? a.find(i => i.id === e.id) : null; }
var ay = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ providers: [$n], imports: [An, vt, Nn] });
} return n; })(), Zi = (() => { class n extends il {
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdStepLabel", ""]], features: [t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), Gt = (() => { class n {
    changes = new D;
    optionalLabel = "Optional";
    completedLabel = "Completed";
    editableLabel = "Editable";
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })();
function qu(n) { return n || new Gt; }
var sy = { provide: Gt, deps: [[new yd, new xd, Gt]], useFactory: qu }, fr = (() => {
    class n extends nl {
        _intl = d(Gt);
        _focusMonitor = d(Ae);
        _intlSubscription;
        state;
        label;
        errorMessage;
        iconOverrides;
        index;
        selected;
        active;
        optional;
        constructor() { super(); let e = d(E); this._intlSubscription = this._intl.changes.subscribe(() => e.markForCheck()); }
        ngAfterViewInit() { this._focusMonitor.monitor(this._elementRef, !0); }
        ngOnDestroy() { this._intlSubscription.unsubscribe(), this._focusMonitor.stopMonitoring(this._elementRef); }
        focus(e, i) { e ? this._focusMonitor.focusVia(this._elementRef, e, i) : this._elementRef.nativeElement.focus(i); }
        _stringLabel() { return this.label instanceof Zi ? null : this.label; }
        _templateLabel() { return this.label instanceof Zi ? this.label : null; }
        _getHostElement() { return this._elementRef.nativeElement; }
        _getDefaultTextForState(e) { return e == "number" ? `${this.index + 1}` : e == "edit" ? "create" : e == "error" ? "warning" : e; }
        _hasEmptyLabel() { return !this._stringLabel() && !this._templateLabel() && !this._hasOptionalLabel() && !this._hasErrorLabel(); }
        _hasOptionalLabel() { return this.optional && this.state !== "error"; }
        _hasErrorLabel() { return this.state === "error"; }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-step-header"]], hostAttrs: ["role", "tab", 1, "step-header"], hostVars: 2, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("md-step-header-empty-label", o._hasEmptyLabel()); }, inputs: { state: "state", label: "label", errorMessage: "errorMessage", iconOverrides: "iconOverrides", index: "index", selected: "selected", active: "active", optional: "optional" }, features: [t.\u0275\u0275InheritDefinitionFeature], decls: 10, vars: 15, consts: [[1, "step-icon-content"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], ["aria-hidden", "true"], [1, "step-label"], [1, "step-text-label"], [1, "step-optional"], [1, "step-sub-label-error"], [1, "icon-wrapper"], ["width", "36", "height", "36", "viewBox", "0 0 36 36", "fill", "none", "xmlns", "http://www.w3.org/2000/svg", 1, "ng-star-inserted"], ["x", "0.5", "y", "0.5", "width", "35", "height", "35", "rx", "17.5", "stroke", "#929292"], ["d", "M24.7373 10L14.5466 20.3769L11.2415 17.0114L8 20.3122L11.3051 23.6777L14.5678 27L17.8093 23.6992L28 13.3224L24.7373 10Z", "fill", "#28B446"], [3, "ngTemplateOutlet"]], template: function (i, o) { if (i & 1 && (t.\u0275\u0275elementStart(0, "div")(1, "div", 0), t.\u0275\u0275conditionalCreate(2, Dl, 1, 6, "ng-container", 1)(3, Ml, 2, 1, "span", 2)(4, Il, 2, 1), t.\u0275\u0275elementEnd()(), t.\u0275\u0275elementStart(5, "div", 3), t.\u0275\u0275conditionalCreate(6, Nl, 2, 1, "div", 4)(7, Pl, 2, 1, "div", 4), t.\u0275\u0275conditionalCreate(8, Ol, 2, 1, "div", 5), t.\u0275\u0275conditionalCreate(9, Fl, 2, 1, "div", 6), t.\u0275\u0275elementEnd()), i & 2) {
                let r;
                t.\u0275\u0275classMap(t.\u0275\u0275interpolate1("step-icon-state-", o.state, " step-icon")), t.\u0275\u0275classProp("step-icon-selected", o.selected), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o.iconOverrides && o.iconOverrides[o.state] ? 2 : o.active ? 4 : 3), t.\u0275\u0275advance(3), t.\u0275\u0275classProp("step-label-active", o.active)("step-label-selected", o.selected)("step-label-error", o.state == "error"), t.\u0275\u0275advance(), t.\u0275\u0275conditional((r = o._templateLabel()) ? 6 : o._stringLabel() ? 7 : -1, r), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o._hasOptionalLabel() ? 8 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o._hasErrorLabel() ? 9 : -1);
            } }, dependencies: [bt], styles: [`.step-header{overflow:hidden;outline:none;cursor:pointer;position:relative;box-sizing:content-box;-webkit-tap-highlight-color:transparent}.step-header:focus .md-focus-indicator:before{content:""}.step-header:hover[aria-disabled=true]{cursor:default}.step-header:hover:not([aria-disabled]) .step-icon:after,.step-header:hover[aria-disabled=false] .step-icon:after{border-radius:100%;content:"";border-width:1px;border-style:solid;border-color:var(--%NS%md-stepper-focus-ring-color, #929292);pointer-events:none;display:block;position:absolute;inset-block-start:-4px;inset-inline-end:-4px;inset-block-end:-4px;inset-inline-start:-4px;z-index:2}.step-header[aria-selected=true]{color:var(--%NS%md-stepper-header-selected-color, #000000)}.step-header.cdk-keyboard-focused:not([aria-disabled]) .step-icon:after,.step-header.cdk-program-focused:not([aria-disabled]) .step-icon:after{border-radius:100%;content:"";border-width:1px;border-style:solid;border-color:var(--%NS%md-stepper-focus-ring-color, #929292);pointer-events:none;display:block;position:absolute;inset-block-start:-4px;inset-inline-end:-4px;inset-block-end:-4px;inset-inline-start:-4px;z-index:2}@media(hover:none){.step-header:hover{background:none}}@media(forced-colors:active){.step-header{outline:solid 1px}.step-header[aria-selected=true] .step-label{text-decoration:underline}.step-header[aria-disabled=true]{outline-color:GrayText}.step-header[aria-disabled=true] .step-label,.step-header[aria-disabled=true] .step-icon,.step-header[aria-disabled=true] .step-optional{color:GrayText}}.step-optional{font-size:12px;color:var(--%NS%md-stepper-optional-color, #dae5e4)}.step-sub-label-error{font-size:12px;font-weight:400}.step-icon{border-radius:50%;height:36px;width:36px;flex-shrink:0;position:relative;color:var(--%NS%md-stepper-icon-color, #EAEAEA);background-color:var(--%NS%md-stepper-icon-background, #4D4D4D)}.step-icon-content{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex}.step-label{display:inline-block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:50px;vertical-align:middle;color:var(--%NS%md-stepper-label-color, #373737)}.step-header-empty-label .step-label{min-width:0}.step-label.step-label-selected{color:var(--%NS%md-stepper-label-selected-color, #000000)}.step-text-label{text-overflow:ellipsis;overflow:hidden}.icon-wrapper{font-size:36px;height:36px;width:36px;display:flex;align-items:center;fill:var(--%NS%md-stepper-icon-fill, #FFFFFF)}.cdk-visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;white-space:nowrap;outline:0;-webkit-appearance:none;-moz-appearance:none;left:0}.step-icon-selected{color:#4d4d4d;background-color:#fff;border:1px solid #CF0106}.step-icon-state-done{background-color:#fff;color:#000}.step-icon-state-edit{background-color:#fff;color:#fff}
`], encapsulation: 2 });
    }
    return n;
})(), Qu = (() => { class n {
    templateRef = d(H);
    name;
    constructor() { }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["ng-template", "mdStepperIcon", ""]], inputs: { name: [0, "stepperIcon", "name"] } });
} return n; })(), Ku = (() => { class n {
    _template = d(H);
    constructor() { }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["ng-template", "mdStepContent", ""]] });
} return n; })(), Uu = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdStepFooter", ""]] });
} return n; })(), Xu = 650, Zu = 100, br = { passive: !0 }, dy = (() => { class n {
    isErrorState(e, i) { return !!(e && e.invalid && (e.dirty || i && i.submitted)); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac });
} return n; })(), _r = (() => { class n {
    isErrorState(e, i) { return !!(e && e.invalid && (e.touched || i && i.submitted)); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), Ju = (() => { class n extends lr {
    _errorStateMatcher = d(_r, { skipSelf: !0 });
    _viewContainerRef = d(ge);
    _isSelected = F.EMPTY;
    stepLabel = void 0;
    _lazyContent;
    _portal;
    ngAfterContentInit() { this._isSelected = this._stepper.steps.changes.pipe(ue(() => this._stepper.selectionChange.pipe(Br(e => e.selectedStep === this), z(this._stepper.selected === this)))).subscribe(e => { e && this._lazyContent && !this._portal && (this._portal = new xe(this._lazyContent._template, this._viewContainerRef)); }); }
    ngOnDestroy() { this._isSelected.unsubscribe(); }
    isErrorState(e, i) { let o = this._errorStateMatcher.isErrorState(e, i), r = !!(e && e.invalid && this.interacted); return o || r; }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-step"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Zi, 5)(r, Ku, 5), i & 2) {
            let s;
            t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.stepLabel = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._lazyContent = s.first);
        } }, hostAttrs: ["hidden", ""], exportAs: ["mdStep"], features: [t.\u0275\u0275ProvidersFeature([{ provide: _r, useExisting: n }, { provide: lr, useExisting: n }]), t.\u0275\u0275InheritDefinitionFeature], ngContentSelectors: T, decls: 1, vars: 0, consts: [[3, "cdkPortalOutlet"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275template(0, Al, 2, 1, "ng-template")); }, dependencies: [Le], encapsulation: 2 });
} return n; })(), ly = (() => {
    class n extends cr {
        _ngZone = d(K);
        _renderer = d(ye);
        _animationsDisabled = !0;
        _cleanupTransition;
        _isAnimating = B(!1);
        _renderedStepHeaders = void 0;
        _animatedContainers;
        _steps = void 0;
        steps = new _t;
        _icons;
        animationDone = new p;
        footer;
        labelPosition = "end";
        headerPosition = "top";
        _iconOverrides = {};
        get animationDuration() { return this._animationDuration; }
        set animationDuration(e) { this._animationDuration = /^\d+$/.test(e) ? e + "ms" : e; }
        _animationDuration = "";
        _isServer = !d(mt).isBrowser;
        _sharedResizeObserver = d(ea);
        constructor() { super(); let i = d(x).nativeElement.nodeName.toLowerCase(); this.orientation = i === "vertical-stepper" ? "vertical" : "horizontal", this._eventCleanups = this._ngZone.runOutsideAngular(() => [this._renderer.listen(this._elementRef.nativeElement, "mouseleave", () => this._stopInterval())]); }
        ngAfterContentInit() { super.ngAfterContentInit(), this._icons.forEach(({ name: o, templateRef: r }) => this._iconOverrides[o] = r), this.steps.changes.pipe(O(this._destroyed)).subscribe(() => this._stateChanged()), this.selectedIndexChange.pipe(O(this._destroyed)).subscribe(() => { let o = this._getAnimationDuration(); o === "0ms" || o === "0s" ? this._onAnimationDone() : this._isAnimating.set(!0), this._scrollSelectedLabelIntoView(); }), this._ngZone.runOutsideAngular(() => { this._animationsDisabled || setTimeout(() => { this._elementRef.nativeElement.classList.add("stepper-animations-enabled"), this._cleanupTransition = this._renderer.listen(this._elementRef.nativeElement, "transitionend", this._handleTransitionend); }, 200); }); let e = this._sharedResizeObserver.observe(this._elementRef.nativeElement).pipe(zr(32), O(this._destroyed)), i = () => { this._scrollToLabel(this.selectedIndex), this._updateTabScrollPosition(), this._checkScrollingControls(), this.changeDetectorRef.markForCheck(); }; R(e, this._stepHeader.changes, this._itemsResized()).pipe(V(() => this.orientation === "horizontal"), O(this._destroyed)).subscribe(() => { this._ngZone.run(() => { Promise.resolve().then(() => { this._scrollDistance = Math.max(0, Math.min(this._getMaxScrollDistance(), this._scrollDistance)), i(); }); }); }); }
        ngAfterViewChecked() { this._stepLabelCount != this._renderedStepHeaders.length && (this.updatePagination(), this._stepLabelCount = this._renderedStepHeaders.length, this.changeDetectorRef.markForCheck()), this._scrollDistanceChanged && (this._updateTabScrollPosition(), this._scrollDistanceChanged = !1, this.changeDetectorRef.markForCheck()); }
        _stopScrolling = new D;
        _eventCleanups;
        _stepLabelCount;
        changeDetectorRef = d(E);
        _platform = d(mt);
        disablePagination = !1;
        _stepHeaderElRef;
        _stepListContainer;
        _stepList;
        _stepListInner;
        _nextPaginator;
        _previousPaginator;
        _scrollDistanceChanged;
        _scrollDistance = 0;
        _showPaginationControls = !1;
        _disableScrollAfter = !0;
        _disableScrollBefore = !0;
        get scrollDistance() { return this._scrollDistance; }
        set scrollDistance(e) { this._scrollTo(e); }
        _handlePaginatorClick(e) { this._stopInterval(), this._scrollHeader(e); }
        _handlePaginatorPress(e, i) { i && i.button != null && i.button !== 0 || (this._stopInterval(), jr(Xu, Zu).pipe(O(R(this._stopScrolling, this._destroyed))).subscribe(() => { let { maxScrollDistance: o, distance: r } = this._scrollHeader(e); (r === 0 || r >= o) && this._stopInterval(); })); }
        _scrollHeader(e) { let i = this._getVisibleRange(), o = this._getLabelRanges(), r = e === "before" ? this._findPreviousClippedLabelRange(o, i.start) : this._findNextClippedLabelRange(o, i.start); return r ? this._scrollTo(this._getScrollPositionForRange(r, e)) : this._scrollTo(e === "before" ? 0 : this._getMaxScrollDistance()); }
        _stopInterval() { this._stopScrolling.next(); }
        _scrollSelectedLabelIntoView() { this.orientation === "horizontal" && Promise.resolve().then(() => { this._scrollToLabel(this.selectedIndex), this._updateTabScrollPosition(), this._checkScrollingControls(), this.changeDetectorRef.markForCheck(); }); }
        _scrollToLabel(e) { if (this.disablePagination)
            return; let i = this._getLabelRanges()[e]; i && (this.scrollDistance = this._getScrollPositionForRange(i)); }
        _getScrollPositionForRange(e, i) { let o = this._getVisibleRange(), r = o.end - o.start; return e.start; }
        _findPreviousClippedLabelRange(e, i) { for (let o = e.length - 1; o >= 0; o--)
            if (e[o].start < i - 1)
                return e[o]; return null; }
        _findNextClippedLabelRange(e, i) { for (let o = 0; o < e.length; o++)
            if (e[o].start === i)
                return e[o + 1]; return null; }
        _getVisibleRange() { let e = this._scrollDistance; return { start: e, end: e + this._stepListContainer.nativeElement.offsetWidth }; }
        _getLabelRanges() { return (this._renderedStepHeaders?.toArray() ?? []).map((e, i) => { let o = e._elementRef.nativeElement, r = o.offsetLeft, s = o.offsetWidth; return { index: i, start: r, end: r + s, width: s }; }); }
        _itemsResized() { return typeof ResizeObserver != "function" ? En : this._stepHeader.changes.pipe(z(this._stepHeader), ue(e => new jt(i => this._ngZone.runOutsideAngular(() => { let o = new ResizeObserver(r => i.next(r)); return e.forEach(r => o.observe(r.elementRef.nativeElement)), () => { o.disconnect(); }; }))), Vr(1), V(e => e.some(i => i.contentRect.width > 0 && i.contentRect.height > 0))); }
        _scrollTo(e) { if (this.disablePagination)
            return { maxScrollDistance: 0, distance: 0 }; let i = this._getMaxScrollDistance(); return this._scrollDistance = Math.max(0, Math.min(i, e)), this._scrollDistanceChanged = !0, this._checkScrollingControls(), { maxScrollDistance: i, distance: this._scrollDistance }; }
        _checkScrollingControls() { if (this.disablePagination)
            this._disableScrollAfter = this._disableScrollBefore = !0;
        else {
            let e = this._getMaxScrollDistance();
            this._disableScrollBefore = this.scrollDistance <= 1, this._disableScrollAfter = this.scrollDistance >= e - 1, this.changeDetectorRef.markForCheck();
        } }
        _getMaxScrollDistance() { let e = this._stepListInner.nativeElement.scrollWidth, i = this._stepListContainer.nativeElement.offsetWidth; return Math.max(0, e - i); }
        _updateTabScrollPosition() { if (this.disablePagination)
            return; let i = -this.scrollDistance; this._stepList.nativeElement.style.transform = `translateX(${Math.round(i)}px)`, this._stepListContainer.nativeElement.scrollLeft = 0; }
        updatePagination() { this.orientation !== "vertical" && (this._checkPaginationEnabled(), this._checkScrollingControls(), this._updateTabScrollPosition()); }
        _checkPaginationEnabled() { if (this.disablePagination)
            this._showPaginationControls = !1, this.changeDetectorRef.markForCheck();
        else {
            let e = this._stepListInner.nativeElement.scrollWidth, i = this._elementRef.nativeElement.offsetWidth, o = e - i >= 5;
            o || (this.scrollDistance = 0), o !== this._showPaginationControls && (this._showPaginationControls = o, this.changeDetectorRef.markForCheck());
        } }
        ngAfterViewInit() { if (super.ngAfterViewInit(), this._renderedStepHeaders.changes.subscribe(() => { Promise.resolve().then(() => { this._scrollToLabel(this.selectedIndex), this._updateTabScrollPosition(), this._checkScrollingControls(), this.changeDetectorRef.markForCheck(); }); }), typeof queueMicrotask == "function") {
            let e = !1;
            this._animatedContainers.changes.pipe(z(null), O(this._destroyed)).subscribe(() => queueMicrotask(() => { e || (e = !0, this.animationDone.emit()), this._stateChanged(); }));
        } this.orientation !== "vertical" && this._eventCleanups.push(this._renderer.listen(this._previousPaginator.nativeElement, "touchstart", () => this._handlePaginatorPress("before"), br), this._renderer.listen(this._nextPaginator.nativeElement, "touchstart", () => this._handlePaginatorPress("after"), br)); }
        ngOnDestroy() { super.ngOnDestroy(), this._cleanupTransition?.(), this._eventCleanups.forEach(e => e()), this._destroyed.next(), this._destroyed.complete(), this._stopScrolling.complete(); }
        _getAnimationDuration() { return this._animationsDisabled ? "0ms" : this.animationDuration ? this.animationDuration : this.orientation === "horizontal" ? "500ms" : "225ms"; }
        _handleTransitionend = e => { let i = e.target; if (!i)
            return; let o = this.orientation === "horizontal" && e.propertyName === "transform" && i.classList.contains("horizontal-stepper-content-current"), r = this.orientation === "vertical" && e.propertyName === "grid-template-rows" && i.classList.contains("vertical-content-container-active"); (o || r) && this._animatedContainers.find(l => l.nativeElement === i) && this._onAnimationDone(); };
        _onAnimationDone() { this._isAnimating.set(!1), this.animationDone.emit(); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-stepper"], ["md-vertical-stepper"], ["md-horizontal-stepper"], ["", "mdStepper", ""]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Uu, 5, H)(r, Ju, 5)(r, Qu, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.footer = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._steps = s), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._icons = s);
            } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(Ll, 5)(Bl, 5)(zl, 5)(Vl, 5)(zn, 5)(Vn, 5)(fr, 5)(Hl, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._stepHeaderElRef = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._stepListContainer = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._stepList = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._stepListInner = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._nextPaginator = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._previousPaginator = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._renderedStepHeaders = r), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._animatedContainers = r);
            } }, hostAttrs: ["role", "tablist"], hostVars: 17, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("aria-orientation", o.orientation), t.\u0275\u0275styleProp("stepper-animation-duration", o._getAnimationDuration()), t.\u0275\u0275classProp("stepper-horizontal", o.orientation === "horizontal")("stepper-vertical", o.orientation === "vertical")("stepper-label-position-end", o.orientation === "horizontal" && o.labelPosition == "end")("stepper-label-position-bottom", o.orientation === "horizontal" && o.labelPosition == "bottom")("stepper-header-position-bottom", o.headerPosition === "bottom")("mdc-step-header-pagination-controls-enabled", o._showPaginationControls)("stepper-animating", o._isAnimating())); }, inputs: { labelPosition: "labelPosition", headerPosition: "headerPosition", animationDuration: "animationDuration", disablePagination: "disablePagination" }, outputs: { animationDone: "animationDone" }, exportAs: ["mdStepper", "mdVerticalStepper", "mdHorizontalStepper"], features: [t.\u0275\u0275ProvidersFeature([{ provide: cr, useExisting: n }]), t.\u0275\u0275InheritDefinitionFeature], ngContentSelectors: T, decls: 6, vars: 3, consts: [["stepTemplate", ""], ["stepHeader", ""], ["previousPaginator", ""], ["stepListContainer", ""], ["stepList", ""], ["stepListInner", ""], ["nextPaginator", ""], ["animatedContainer", ""], [1, "horizontal-stepper-wrapper"], [3, "ngTemplateOutlet"], [1, "mdc-step-header"], [1, "mdc-step-header-pagination", "mdc-step-header-pagination-before", 3, "click", "mousedown", "touchend"], [1, "mdc-step-header-pagination-chevron"], [1, "mdc-step-label-container"], [1, "mdc-step-list"], [1, "horizontal-stepper-header-container"], [1, "mdc-step-header-pagination", "mdc-step-header-pagination-after", 3, "mousedown", "click", "touchend"], [1, "horizontal-content-container"], ["role", "tabpanel", 1, "horizontal-stepper-content", 3, "id", "class"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "stepper-horizontal-line"], ["role", "tabpanel", 1, "horizontal-stepper-content", 3, "id"], [1, "step"], [1, "vertical-content-container"], ["role", "tabpanel", 1, "vertical-stepper-content", 3, "id"], [1, "vertical-content"], [3, "click", "keydown", "tabIndex", "id", "index", "state", "label", "selected", "active", "optional", "errorMessage", "iconOverrides", "disableRipple", "color"]], template: function (i, o) { if (i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275conditionalCreate(0, jl, 1, 0), t.\u0275\u0275conditionalCreate(1, Yl, 20, 4, "div", 8)(2, Ql, 2, 0), t.\u0275\u0275template(3, Kl, 1, 23, "ng-template", null, 0, t.\u0275\u0275templateRefExtractor), t.\u0275\u0275elementContainer(5, 9)), i & 2) {
                let r;
                t.\u0275\u0275conditional(o._isServer ? 0 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional((r = o.orientation) === "horizontal" ? 1 : r === "vertical" ? 2 : -1), t.\u0275\u0275advance(4), t.\u0275\u0275property("ngTemplateOutlet", o.footer);
            } }, dependencies: [bt, fr], styles: [`.stepper-vertical,.stepper-horizontal{display:block;font-family:Montserrat;font-size:14px;color:var(--%NS%md-stepper-color, #000000)}.horizontal-stepper-header-container{white-space:nowrap;display:flex;align-items:center}.stepper-label-position-bottom .horizontal-stepper-header-container{align-items:flex-start}.stepper-header-position-bottom .horizontal-stepper-header-container{order:1}.stepper-horizontal-line{border-top-width:1px;border-top-style:solid;flex:auto;height:0;margin:0 -16px;min-width:32px;border-top-color:var(--%NS%md-stepper-line-color, #889392)}.stepper-label-position-bottom .stepper-horizontal-line{margin:0;min-width:0;position:relative;top:36px}.stepper-label-position-bottom .horizontal-stepper-header:not(:first-child):before,[dir=rtl] .stepper-label-position-bottom .horizontal-stepper-header:not(:last-child):before,.stepper-label-position-bottom .horizontal-stepper-header:not(:last-child):after,[dir=rtl] .stepper-label-position-bottom .horizontal-stepper-header:not(:first-child):after{border-top-width:1px;border-top-style:solid;content:"";display:inline-block;height:0;position:absolute;width:calc(50% - 20px)}.horizontal-stepper-header{display:flex;overflow:hidden;align-items:center;padding:0 24px;height:48px}.horizontal-stepper-header .step-icon{position:relative;margin-right:8px;flex:none}[dir=rtl] .horizontal-stepper-header .step-icon{margin-right:0;margin-left:8px}.horizontal-stepper-header.step-header-empty-label .step-icon{margin:0}.stepper-label-position-bottom .horizontal-stepper-header{padding:24px}.stepper-label-position-bottom .horizontal-stepper-header:before,.stepper-label-position-bottom .horizontal-stepper-header:after{top:36px}.stepper-label-position-bottom .horizontal-stepper-header{box-sizing:border-box;flex-direction:column;height:auto}.stepper-label-position-bottom .horizontal-stepper-header:not(:last-child):after,[dir=rtl] .stepper-label-position-bottom .horizontal-stepper-header:not(:first-child):after{right:0}.stepper-label-position-bottom .horizontal-stepper-header:not(:first-child):before,[dir=rtl] .stepper-label-position-bottom .horizontal-stepper-header:not(:last-child):before{left:0}[dir=rtl] .stepper-label-position-bottom .horizontal-stepper-header:last-child:before,[dir=rtl] .stepper-label-position-bottom .horizontal-stepper-header:first-child:after{display:none}.stepper-label-position-bottom .horizontal-stepper-header .step-icon{margin-right:0;margin-left:0}.stepper-label-position-bottom .horizontal-stepper-header .step-label{padding:16px 0 0;text-align:center;width:100%}.vertical-stepper-header{display:flex;align-items:center;height:24px;padding:24px}.vertical-stepper-header .step-icon{margin-right:12px}[dir=rtl] .vertical-stepper-header .step-icon{margin-right:0;margin-left:12px}.horizontal-stepper-wrapper{display:flex;flex-direction:column;height:100%;flex-grow:1;overflow:auto}.horizontal-stepper-content{visibility:hidden;overflow:hidden;outline:0;height:0}.stepper-animations-enabled .horizontal-stepper-content{transition:transform .5s cubic-bezier(.35,0,.25,1)}.horizontal-stepper-content.horizontal-stepper-content-previous{transform:translate3d(-100%,0,0)}.horizontal-stepper-content.horizontal-stepper-content-next{transform:translate3d(100%,0,0)}.horizontal-stepper-content.horizontal-stepper-content-current{visibility:visible;transform:none;height:auto}.stepper-horizontal:not(.stepper-animating) .horizontal-stepper-content.horizontal-stepper-content-current{overflow:visible}.horizontal-content-container{overflow:auto;flex-grow:1;background:var(--%NS%md-stepper-content-background, #F3F3F3);padding:24px}@media(forced-colors:active){.horizontal-content-container{outline:solid 1px}}.stepper-header-position-bottom .horizontal-content-container{padding:24px 24px 0}.vertical-content-container{display:grid;grid-template-rows:0fr;grid-template-columns:100%;margin-left:36px;border:0;position:relative}.stepper-animations-enabled .vertical-content-container{transition:grid-template-rows .5s cubic-bezier(.4,0,.2,1)}.vertical-content-container.vertical-content-container-active{grid-template-rows:1fr}.step:last-child .vertical-content-container{border:none}@media(forced-colors:active){.vertical-content-container{outline:solid 1px}}[dir=rtl] .vertical-content-container{margin-left:0;margin-right:36px}@supports not (grid-template-rows: 0fr){.vertical-content-container{height:0}.vertical-content-container.vertical-content-container-active{height:auto}}.stepper-vertical-line:before{content:"";position:absolute;left:0;border-left-width:1px;border-left-style:solid;border-left-color:var(--%NS%md-stepper-line-color, #889392);top:-16px;bottom:-16px}[dir=rtl] .stepper-vertical-line:before{left:auto;right:0}.vertical-stepper-content{overflow:hidden;outline:0;visibility:hidden}.stepper-animations-enabled .vertical-stepper-content{transition:visibility .5s linear}.vertical-content-container-active>.vertical-stepper-content{visibility:visible}.vertical-content{padding:0 24px 24px}.mdc-step-header-pagination-before,.mdc-step-header-rtl .mdc-step-header-pagination-after{padding-left:4px}.mdc-step-header-pagination-before .mdc-step-header-pagination-chevron,.mdc-step-header-rtl .mdc-step-header-pagination-after .mdc-step-header-pagination-chevron{transform:rotate(-135deg)}.mdc-step-header-rtl .mdc-step-header-pagination-before,.mdc-step-header-pagination-after{padding-right:4px}.mdc-step-header-rtl .mdc-step-header-pagination-before .mdc-step-header-pagination-chevron,.mdc-step-header-pagination-after .mdc-step-header-pagination-chevron{transform:rotate(45deg)}.mdc-step-header-pagination-chevron{border-style:solid;border-width:2px 2px 0 0;height:8px;width:8px;border-color:var(--%NS%md-stepper-pagination-chevron-color, #201a1b)}.mdc-step-header-pagination-disabled{box-shadow:none;cursor:default;pointer-events:none}.mdc-step-header-pagination-disabled .mdc-step-header-pagination-chevron{opacity:.4}.mdc-step-label-container{display:flex;flex-grow:1;min-width:0;overflow:hidden;z-index:1}.mdc-step-list{flex-grow:1;position:relative;transition:transform .5s cubic-bezier(.35,0,.25,1)}.animation-noopable .mdc-step-list{transition:none}.mdc-step-header{display:flex;overflow:hidden;position:relative;flex-shrink:0;padding-bottom:24px}.mdc-step-header-pagination{position:relative;display:none;justify-content:center;align-items:center;min-width:32px;cursor:pointer;z-index:2;-webkit-tap-highlight-color:transparent;touch-action:none;box-sizing:content-box;outline:0}.mdc-step-header-pagination::-moz-focus-inner{border:0}.mdc-step-header-pagination-controls-enabled .mdc-step-header-pagination{display:flex}
`], encapsulation: 2 });
    }
    return n;
})(), cy = (() => { class n extends ol {
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["button", "mdStepperNext", ""]], hostAttrs: [1, "stepper-next"], hostVars: 1, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275domProperty("type", o.type); }, features: [t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), my = (() => { class n extends rl {
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["button", "mdStepperPrevious", ""]], hostAttrs: [1, "stepper-previous"], hostVars: 1, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275domProperty("type", o.type); }, features: [t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), hy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [ae, Nn, al, ae] });
} return n; })(), Yn = new k("MD_MENU_PANEL"), pt = (() => { class n {
    _elementRef = d(x);
    _document = d(ve);
    _focusMonitor = d(Ae);
    _parentMenu = d(Yn, { optional: !0 });
    _changeDetectorRef = d(E);
    role = "menuitem";
    disabled = !1;
    disableRipple = !1;
    _hovered = new D;
    _focused = new D;
    _highlighted = !1;
    _triggersSubmenu = !1;
    constructor() { this._parentMenu?.addItem?.(this); }
    focus(e, i) { this._focusMonitor && e ? this._focusMonitor.focusVia(this._getHostElement(), e, i) : this._getHostElement().focus(i), this._focused.next(this); }
    ngAfterViewInit() { this._focusMonitor && this._focusMonitor.monitor(this._elementRef, !1); }
    ngOnDestroy() { this._focusMonitor && this._focusMonitor.stopMonitoring(this._elementRef), this._parentMenu && this._parentMenu.removeItem && this._parentMenu.removeItem(this), this._hovered.complete(), this._focused.complete(); }
    _getTabIndex() { return this.disabled ? "-1" : "0"; }
    _getHostElement() { return this._elementRef.nativeElement; }
    _checkDisabled(e) { this.disabled && (e.preventDefault(), e.stopPropagation()); }
    _handleMouseEnter() { this._hovered.next(this); }
    getLabel() { return this._elementRef.nativeElement.cloneNode(!0).textContent?.trim() || ""; }
    _setHighlighted(e) { this._highlighted = e, this._changeDetectorRef.markForCheck(); }
    _setTriggersSubmenu(e) { this._triggersSubmenu = e, this._changeDetectorRef.markForCheck(); }
    _hasFocus() { return this._document && this._document.activeElement === this._getHostElement(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["", "md-menu-item", ""]], hostAttrs: [1, "md-mdc-menu-item", "md-focus-indicator"], hostVars: 8, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function (s) { return o._checkDisabled(s); })("mouseenter", function () { return o._handleMouseEnter(); }), i & 2 && (t.\u0275\u0275attribute("role", o.role)("tabindex", o._getTabIndex())("aria-disabled", o.disabled)("disabled", o.disabled || null), t.\u0275\u0275classProp("md-mdc-menu-item-highlighted", o._highlighted)("md-mdc-menu-item-submenu-trigger", o._triggersSubmenu)); }, inputs: { role: "role", disabled: [2, "disabled", "disabled", m], disableRipple: [2, "disableRipple", "disableRipple", m] }, exportAs: ["mdMenuItem"], ngContentSelectors: T, decls: 3, vars: 1, consts: [[1, "md-mdc-menu-item-text"], ["viewBox", "0 0 5 10", "focusable", "false", "aria-hidden", "true", 1, "md-mdc-menu-submenu-icon"], ["points", "0,0 5,5 0,10"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElementStart(0, "span", 0), t.\u0275\u0275projection(1), t.\u0275\u0275domElementEnd(), t.\u0275\u0275conditionalCreate(2, Ul, 2, 0, ":svg:svg", 1)), i & 2 && (t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o._triggersSubmenu ? 2 : -1)); }, encapsulation: 2 });
} return n; })();
var Ca = new k("MDMenuContent"), eg = (() => { class n {
    _template = d(H);
    _appRef = d(wn);
    _injector = d(j);
    _viewContainerRef = d(ge);
    _document = d(ve);
    _changeDetectorRef = d(E);
    _portal;
    _outlet;
    _attached = new D;
    constructor() { }
    attach(e = {}) { this._portal || (this._portal = new xe(this._template, this._viewContainerRef)), this.detach(), this._outlet || (this._outlet = new Qd(this._document.createElement("div"), this._appRef, this._injector)); let i = this._template.elementRef.nativeElement; i.parentNode.insertBefore(this._outlet.outletElement, i), this._changeDetectorRef.markForCheck(), this._portal.attach(this._outlet, e), this._attached.next(); }
    detach() { this._portal?.isAttached && this._portal.detach(); }
    ngOnDestroy() { this.detach(), this._outlet?.dispose(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["ng-template", "mdMenuContent", ""]], features: [t.\u0275\u0275ProvidersFeature([{ provide: Ca, useExisting: n }])] });
} return n; })(), tg = new k("md-menu-default-options", { providedIn: "root", factory: () => ({ overlapTrigger: !1, xPosition: "after", yPosition: "below", backdropClass: "cdk-overlay-transparent-backdrop" }) }), Li = "_md-menu-enter", zt = "_md-menu-exit", Ye = (() => {
    class n {
        _elementRef = d(x);
        _changeDetectorRef = d(E);
        _injector = d(j);
        _keyManager;
        _xPosition;
        _yPosition;
        _firstItemFocusRef;
        _exitFallbackTimeout;
        _allItems;
        _directDescendantItems = new _t;
        _classList = {};
        _panelAnimationState = "void";
        _animationDone = new D;
        _isAnimating = B(!1);
        parentMenu;
        direction;
        overlayPanelClass;
        animationsDisabled = !1;
        backdropClass;
        ariaLabel;
        ariaLabelledby;
        ariaDescribedby;
        get xPosition() { return this._xPosition; }
        set xPosition(e) { this._xPosition = e, this.setPositionClasses(); }
        get yPosition() { return this._yPosition; }
        set yPosition(e) { this._yPosition = e, this.setPositionClasses(); }
        templateRef;
        items;
        lazyContent;
        overlapTrigger;
        hasBackdrop;
        set panelClass(e) { let i = this._previousPanelClass, o = _({}, this._classList); i && i.length && i.split(" ").forEach(r => { o[r] = !1; }), this._previousPanelClass = e, e && e.length && (e.split(" ").forEach(r => { o[r] = !0; }), this._elementRef.nativeElement.className = ""), this._classList = o; }
        _previousPanelClass;
        get classList() { return this.panelClass; }
        set classList(e) { this.panelClass = e; }
        closed = new p;
        close = this.closed;
        panelId = d(W).getId("md-menu-panel-");
        constructor() { let e = d(tg); this.overlayPanelClass = e.overlayPanelClass || "", this._xPosition = e.xPosition, this._yPosition = e.yPosition, this.backdropClass = e.backdropClass, this.overlapTrigger = e.overlapTrigger, this.hasBackdrop = e.hasBackdrop; }
        ngOnInit() { this.setPositionClasses(); }
        ngAfterContentInit() { this._updateDirectDescendants(), this._keyManager = new Xt(this._directDescendantItems).withWrap().withTypeAhead().withHomeAndEnd(), this._keyManager.tabOut.subscribe(() => this.closed.emit("tab")), this._directDescendantItems.changes.pipe(z(this._directDescendantItems), ue(e => R(...e.map(i => i._focused)))).subscribe(e => this._keyManager.updateActiveItem(e)), this._directDescendantItems.changes.subscribe(e => { let i = this._keyManager; if (this._panelAnimationState === "enter" && i.activeItem?._hasFocus()) {
            let o = e.toArray(), r = Math.max(0, Math.min(o.length - 1, i.activeItemIndex || 0));
            o[r] && !o[r].disabled ? i.setActiveItem(r) : i.setNextItemActive();
        } }); }
        ngOnDestroy() { this._keyManager?.destroy(), this._directDescendantItems.destroy(), this.closed.complete(), this._firstItemFocusRef?.destroy(), clearTimeout(this._exitFallbackTimeout); }
        _hovered() { return this._directDescendantItems.changes.pipe(z(this._directDescendantItems), ue(i => R(...i.map(o => o._hovered)))); }
        addItem(e) { }
        removeItem(e) { }
        _handleKeydown(e) { let i = e.keyCode, o = this._keyManager; switch (i) {
            case qe:
                q(e) || (e.preventDefault(), this.closed.emit("keydown"));
                break;
            case Mn:
                this.parentMenu && this.direction === "ltr" && this.closed.emit("keydown");
                break;
            case Dn:
                this.parentMenu && this.direction === "rtl" && this.closed.emit("keydown");
                break;
            default:
                (i === Fe || i === dt) && o.setFocusOrigin("keyboard"), o.onKeydown(e);
                return;
        } }
        focusFirstItem(e = "program") { this._firstItemFocusRef?.destroy(), this._firstItemFocusRef = Oe(() => { let i = this._resolvePanel(); if (!i || !i.contains(document.activeElement)) {
            let o = this._keyManager;
            o.setFocusOrigin(e).setFirstItemActive(), !o.activeItem && i && i.focus();
        } }, { injector: this._injector }); }
        resetActiveItem() { this._keyManager.setActiveItem(-1); }
        setElevation(e) { }
        setPositionClasses(e = this.xPosition, i = this.yPosition) { this._classList = G(_({}, this._classList), { "md-menu-before": e === "before", "md-menu-after": e === "after", "md-menu-above": i === "above", "md-menu-below": i === "below" }), this._changeDetectorRef.markForCheck(); }
        _onAnimationDone(e) { let i = e === zt; (i || e === Li) && (i && (clearTimeout(this._exitFallbackTimeout), this._exitFallbackTimeout = void 0), this._animationDone.next(i ? "void" : "enter"), this._isAnimating.set(!1)); }
        _onAnimationStart(e) { (e === Li || e === zt) && this._isAnimating.set(!0); }
        _setIsOpen(e) { if (this._panelAnimationState = e ? "enter" : "void", e) {
            if (this._keyManager.activeItemIndex === 0) {
                let i = this._resolvePanel();
                i && (i.scrollTop = 0);
            }
        }
        else
            this.animationsDisabled || (this._exitFallbackTimeout = setTimeout(() => this._onAnimationDone(zt), 200)); this.animationsDisabled && setTimeout(() => { this._onAnimationDone(e ? Li : zt); }), this._changeDetectorRef.markForCheck(); }
        _updateDirectDescendants() { this._allItems.changes.pipe(z(this._allItems)).subscribe(e => { this._directDescendantItems.reset(e.filter(i => i._parentMenu === this)), this._directDescendantItems.notifyOnChanges(); }); }
        _resolvePanel() { let e = null; return this._directDescendantItems.length && (e = this._directDescendantItems.first._getHostElement().closest('[role="menu"]')), e; }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-menu"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Ca, 5)(r, pt, 5)(r, pt, 4), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.lazyContent = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._allItems = s), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.items = s);
            } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(H, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.templateRef = r.first);
            } }, hostVars: 3, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275attribute("aria-label", null)("aria-labelledby", null)("aria-describedby", null); }, inputs: { animationsDisabled: "animationsDisabled", backdropClass: "backdropClass", ariaLabel: [0, "aria-label", "ariaLabel"], ariaLabelledby: [0, "aria-labelledby", "ariaLabelledby"], ariaDescribedby: [0, "aria-describedby", "ariaDescribedby"], xPosition: "xPosition", yPosition: "yPosition", overlapTrigger: [2, "overlapTrigger", "overlapTrigger", m], hasBackdrop: [2, "hasBackdrop", "hasBackdrop", e => e == null ? null : m(e)], panelClass: [0, "class", "panelClass"], classList: "classList" }, outputs: { closed: "closed", close: "close" }, exportAs: ["mdMenu"], features: [t.\u0275\u0275ProvidersFeature([{ provide: Yn, useExisting: n }])], ngContentSelectors: T, decls: 1, vars: 0, consts: [["tabindex", "-1", "role", "menu", 1, "md-mdc-menu-panel", 3, "click", "animationstart", "animationend", "animationcancel", "id"], [1, "md-mdc-menu-content"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domTemplate(0, Xl, 3, 12, "ng-template")); }, styles: [`md-menu{display:none}.md-mdc-menu-content{margin:0;padding:4px;outline:0}.md-mdc-menu-content,.md-mdc-menu-content .md-mdc-menu-item .md-mdc-menu-item-text{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;flex:1;white-space:normal;font-family:var(--%NS%md-menu-font-family, var(--%NS%md-font-heading, Montserrat));line-height:20px;font-size:13px;letter-spacing:.006rem;font-weight:400}@keyframes _md-menu-enter{0%{opacity:0;transform:scale(.8)}to{opacity:1;transform:none}}@keyframes _md-menu-exit{0%{opacity:1}to{opacity:0}}.md-mdc-menu-panel{min-width:112px;max-width:280px;overflow:auto;box-sizing:border-box;outline:0;animation:_md-menu-enter .12s cubic-bezier(0,0,.2,1);border-radius:var(--%NS%md-menu-radius, 5px);background-color:var(--%NS%md-overlay-surface, #FFFFFF);box-shadow:var(--%NS%md-overlay-shadow, 0 1px 3px 1px rgba(0, 0, 0, .1490196078))}.md-mdc-menu-panel.md-menu-panel-exit-animation{animation:_md-menu-exit .1s 25ms linear forwards}.md-mdc-menu-panel.md-menu-panel-animations-disabled{animation:none}.md-mdc-menu-panel.md-menu-panel-animating{pointer-events:none}.md-mdc-menu-panel.md-menu-panel-animating:has(.md-mdc-menu-content:empty){display:none}.md-mdc-menu-item{display:flex;position:relative;align-items:center;justify-content:flex-start;overflow:hidden;width:100%;text-align:left;box-sizing:border-box;color:inherit;font-size:inherit;background:none;text-decoration:none;margin:0;min-height:28px;padding:0 16px;-webkit-user-select:none;user-select:none;cursor:pointer;outline:none;border:none;-webkit-tap-highlight-color:transparent}.md-mdc-menu-item::-moz-focus-inner{border:0}[dir=rtl] .md-mdc-menu-item{padding-left:12px;padding-right:12px}.md-mdc-menu-item,.md-mdc-menu-item:visited,.md-mdc-menu-item:link{color:var(--%NS%md-menu-item-color, #1a1b1f)}.md-mdc-menu-item .md-icon-no-color,.md-mdc-menu-item .md-mdc-menu-submenu-icon{color:var(--%NS%md-menu-icon-color, #44474e)}.md-mdc-menu-item[disabled]{cursor:default;opacity:.38}.md-mdc-menu-item[disabled]:after{display:block;position:absolute;content:"";inset:0}.md-mdc-menu-item:focus{outline:0}[dir=rtl] .md-mdc-menu-item{text-align:right}.md-mdc-menu-item:not([disabled]):hover{background-color:var(--%NS%md-menu-item-hover-background, color-mix(in srgb, #1a1b1f 8%, transparent));color:var(--%NS%md-menu-item-hover-color, #CF0106)}.md-mdc-menu-item:not([disabled]).cdk-program-focused,.md-mdc-menu-item:not([disabled]).cdk-keyboard-focused,.md-mdc-menu-item:not([disabled]).md-mdc-menu-item-highlighted{background-color:var(--%NS%md-menu-item-focus-background, color-mix(in srgb, #1a1b1f 12%, transparent))}.md-mdc-menu-submenu-icon{width:24px;height:10px;fill:currentColor;padding-left:12px}[dir=rtl] .md-mdc-menu-submenu-icon{padding-right:12px;padding-left:0}[dir=rtl] .md-mdc-menu-submenu-icon polygon{transform:scaleX(-1);transform-origin:center}
`], encapsulation: 2 });
    }
    return n;
})(), ig = new k("md-menu-scroll-strategy", { providedIn: "root", factory: () => { let n = d(j); return () => $r(n); } }), py = 8, Ge = new WeakMap, wa = (() => { class n {
    _canHaveBackdrop;
    _element = d(x);
    _viewContainerRef = d(ge);
    _menuItemInstance = d(pt, { optional: !0, self: !0 });
    _dir = d(ke, { optional: !0 });
    _focusMonitor = d(Ae);
    _ngZone = d(K);
    _injector = d(j);
    _scrollStrategy = d(ig);
    _changeDetectorRef = d(E);
    _portal;
    _overlayRef = null;
    _menuOpen = !1;
    _closingActionsSubscription = F.EMPTY;
    _menuCloseSubscription = F.EMPTY;
    _pendingRemoval;
    _parentMenu;
    _openedBy = void 0;
    get _menu() { return this._menuInternal; }
    set _menu(e) { e !== this._menuInternal && (this._menuInternal = e, this._menuCloseSubscription.unsubscribe(), e && (this._parentMenu, this._menuCloseSubscription = e.close.subscribe(i => { this._destroyMenu(i), (i === "click" || i === "tab") && this._parentMenu && this._parentMenu.closed.emit(i); })), this._menuItemInstance?._setTriggersSubmenu(this._triggersSubmenu())); }
    _menuInternal;
    constructor(e) { this._canHaveBackdrop = e; let i = d(Yn, { optional: !0 }); this._parentMenu = i instanceof Ye ? i : void 0; }
    ngOnDestroy() { this._menu && this._ownsMenu(this._menu) && Ge.delete(this._menu), this._pendingRemoval?.unsubscribe(), this._menuCloseSubscription.unsubscribe(), this._closingActionsSubscription.unsubscribe(), this._overlayRef && (this._overlayRef.dispose(), this._overlayRef = null); }
    get menuOpen() { return this._menuOpen; }
    get dir() { return this._dir && this._dir.value === "rtl" ? "rtl" : "ltr"; }
    _triggersSubmenu() { return !!(this._menuItemInstance && this._parentMenu && this._menu); }
    _closeMenu() { this._menu?.close.emit(); }
    _openMenu(e) { let i = this._menu; if (this._menuOpen || !i)
        return; this._pendingRemoval?.unsubscribe(); let o = Ge.get(i); Ge.set(i, this), o && o !== this && o._closeMenu(); let r = this._createOverlay(i), s = r.getConfig(), l = s.positionStrategy; this._setPosition(i, l), this._canHaveBackdrop ? s.hasBackdrop = i.hasBackdrop == null ? !this._triggersSubmenu() : i.hasBackdrop : s.hasBackdrop = !1, r.hasAttached() || (r.attach(this._getPortal(i)), i.lazyContent?.attach(this.menuData)), this._closingActionsSubscription = this._menuClosingActions().subscribe(() => this._closeMenu()), i.parentMenu = this._triggersSubmenu() ? this._parentMenu : void 0, i.direction = this.dir, e && i.focusFirstItem(this._openedBy || "program"), this._setIsMenuOpen(!0), i instanceof Ye && (i._setIsOpen(!0), i._directDescendantItems.changes.pipe(O(i.close)).subscribe(() => { l.withLockedPosition(!1).reapplyLastPosition(), l.withLockedPosition(!0); })); }
    focus(e, i) { this._focusMonitor && e ? this._focusMonitor.focusVia(this._element, e, i) : this._element.nativeElement.focus(i); }
    _destroyMenu(e) { let i = this._overlayRef, o = this._menu; !i || !this.menuOpen || (this._closingActionsSubscription.unsubscribe(), this._pendingRemoval?.unsubscribe(), o instanceof Ye && this._ownsMenu(o) ? (this._pendingRemoval = o._animationDone.pipe(pe(1)).subscribe(() => { i.detach(), Ge.has(o) || o.lazyContent?.detach(); }), o._setIsOpen(!1)) : (i.detach(), o?.lazyContent?.detach()), o && this._ownsMenu(o) && Ge.delete(o), this.restoreFocus && (e === "keydown" || !this._openedBy || !this._triggersSubmenu()) && this.focus(this._openedBy), this._openedBy = void 0, this._setIsMenuOpen(!1)); }
    _setIsMenuOpen(e) { e !== this._menuOpen && (this._menuOpen = e, this._menuOpen ? this.menuOpened.emit() : this.menuClosed.emit(), this._triggersSubmenu() && this._menuItemInstance._setHighlighted(e), this._changeDetectorRef.markForCheck()); }
    _createOverlay(e) { if (!this._overlayRef) {
        let i = this._getOverlayConfig(e);
        this._subscribeToPositions(e, i.positionStrategy), this._overlayRef = On(this._injector, i), this._overlayRef.keydownEvents().subscribe(o => { this._menu instanceof Ye && this._menu._handleKeydown(o); });
    } return this._overlayRef; }
    _getOverlayConfig(e) { return new Yr({ positionStrategy: qr(this._injector, this._getOverlayOrigin()).withLockedPosition().withGrowAfterOpen().withTransformOriginOn(".md-menu-panel, .md-mdc-menu-panel"), backdropClass: e.backdropClass || "cdk-overlay-transparent-backdrop", panelClass: e.overlayPanelClass, scrollStrategy: this._scrollStrategy(), direction: this._dir || "ltr", disableAnimations: this._menu?.animationsDisabled }); }
    _subscribeToPositions(e, i) { e.setPositionClasses && i.positionChanges.subscribe(o => { this._ngZone.run(() => { let r = o.connectionPair.overlayX === "start" ? "after" : "before", s = o.connectionPair.overlayY === "top" ? "below" : "above"; e.setPositionClasses(r, s); }); }); }
    _setPosition(e, i) { let [o, r] = e.xPosition === "before" ? ["end", "start"] : ["start", "end"], [s, l] = e.yPosition === "above" ? ["bottom", "top"] : ["top", "bottom"], [c, h] = [s, l], [g, u] = [o, r], f = 0; this._triggersSubmenu() ? (u = o = e.xPosition === "before" ? "start" : "end", r = g = o === "end" ? "start" : "end") : e.overlapTrigger || (c = s === "top" ? "bottom" : "top", h = l === "top" ? "bottom" : "top"), i.withPositions([{ originX: o, originY: c, overlayX: g, overlayY: s, offsetY: f }, { originX: r, originY: c, overlayX: u, overlayY: s, offsetY: f }, { originX: o, originY: h, overlayX: g, overlayY: l, offsetY: -f }, { originX: r, originY: h, overlayX: u, overlayY: l, offsetY: -f }]); }
    _menuClosingActions() { let e = this._getOutsideClickStream(this._overlayRef), i = this._overlayRef.detachments(), o = this._parentMenu ? this._parentMenu.closed : lt(), r = this._parentMenu ? this._parentMenu._hovered().pipe(V(s => this._menuOpen && s !== this._menuItemInstance)) : lt(); return R(e, o, r, i); }
    _getPortal(e) { return (!this._portal || this._portal.templateRef !== e.templateRef) && (this._portal = new xe(e.templateRef, this._viewContainerRef)), this._portal; }
    _ownsMenu(e) { return Ge.get(e) === this; }
    static \u0275fac = function (i) { t.\u0275\u0275invalidFactory(); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n });
} return n; })(), Sa = (() => { class n extends wa {
    _cleanupTouchstart;
    _hoverSubscription = F.EMPTY;
    get _deprecatedMDMenuTriggerFor() { return this.menu; }
    set _deprecatedMDMenuTriggerFor(e) { this.menu = e; }
    get menu() { return this._menu; }
    set menu(e) { this._menu = e; }
    menuData;
    restoreFocus = !0;
    menuOpened = new p;
    onMenuOpen = this.menuOpened;
    menuClosed = new p;
    onMenuClose = this.menuClosed;
    constructor() { super(!0); let e = d(ye); this._cleanupTouchstart = e.listen(this._element.nativeElement, "touchstart", i => { Fd(i) || (this._openedBy = "touch"); }, { passive: !0 }); }
    triggersSubmenu() { return super._triggersSubmenu(); }
    toggleMenu() { return this.menuOpen ? this.closeMenu() : this.openMenu(); }
    openMenu() { this._openMenu(!0); }
    closeMenu() { this._closeMenu(); }
    updatePosition() { this._overlayRef?.updatePosition(); }
    ngAfterContentInit() { this._handleHover(); }
    ngOnDestroy() { super.ngOnDestroy(), this._cleanupTouchstart(), this._hoverSubscription.unsubscribe(); }
    _getOverlayOrigin() { return this._element; }
    _getOutsideClickStream(e) { return e.backdropClick(); }
    _handleMousedown(e) { Rd(e) || (this._openedBy = e.button === 0 ? "mouse" : void 0, this.triggersSubmenu() && e.preventDefault()); }
    _handleKeydown(e) { let i = e.keyCode; (i === Q || i === se) && (this._openedBy = "keyboard"), this.triggersSubmenu() && (i === Dn && this.dir === "ltr" || i === Mn && this.dir === "rtl") && (this._openedBy = "keyboard", this.openMenu()); }
    _handleClick(e) { this.triggersSubmenu() ? (e.stopPropagation(), this.openMenu()) : this.toggleMenu(); }
    _handleHover() { this.triggersSubmenu() && this._parentMenu && (this._hoverSubscription = this._parentMenu._hovered().subscribe(e => { e === this._menuItemInstance && !e.disabled && this._parentMenu?._panelAnimationState !== "void" && (this._openedBy = "mouse", this._openMenu(!1)); })); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-menu-trigger-for", ""], ["", "mdMenuTriggerFor", ""]], hostAttrs: [1, "md-mdc-menu-trigger"], hostVars: 3, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function (s) { return o._handleClick(s); })("mousedown", function (s) { return o._handleMousedown(s); })("keydown", function (s) { return o._handleKeydown(s); }), i & 2 && t.\u0275\u0275attribute("aria-haspopup", o.menu ? "menu" : null)("aria-expanded", o.menuOpen)("aria-controls", o.menuOpen ? o.menu?.panelId : null); }, inputs: { _deprecatedMDMenuTriggerFor: [0, "md-menu-trigger-for", "_deprecatedMDMenuTriggerFor"], menu: [0, "mdMenuTriggerFor", "menu"], menuData: [0, "mdMenuTriggerData", "menuData"], restoreFocus: [0, "mdMenuTriggerRestoreFocus", "restoreFocus"] }, outputs: { menuOpened: "menuOpened", onMenuOpen: "onMenuOpen", menuClosed: "menuClosed", onMenuClose: "onMenuClose" }, exportAs: ["mdMenuTrigger"], features: [t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), uy = (() => { class n extends wa {
    _point = { x: 0, y: 0, initialX: 0, initialY: 0, initialScrollX: 0, initialScrollY: 0 };
    _triggerPressedControl = !1;
    _rootNode;
    _document = d(ve);
    _viewportRuler = d(Qr);
    _scrollDispatcher = d(Ud);
    _scrollSubscription;
    get menu() { return this._menu; }
    set menu(e) { this._menu = e; }
    menuData;
    restoreFocus = !0;
    disabled = !1;
    menuOpened = new p;
    menuClosed = new p;
    constructor() { super(!1); }
    ngOnDestroy() { super.ngOnDestroy(), this._scrollSubscription?.unsubscribe(); }
    _handleContextMenuEvent(e) { this.disabled || (e.preventDefault(), this.menuOpen ? (this._initializePoint(e.clientX, e.clientY), this._updatePosition()) : this._openContextMenu(e)); }
    _destroyMenu(e) { super._destroyMenu(e), this._scrollSubscription?.unsubscribe(); }
    _getOverlayOrigin() { return this._point; }
    _getOutsideClickStream(e) { return e.outsidePointerEvents().pipe(Vd((i, o) => i.type === "contextmenu" ? this._isWithinMenuOrTrigger(Jr(i)) : i.type === "auxclick" ? o === 0 ? !0 : (this._rootNode ??= sl(this._element.nativeElement) || this._document, this._isWithinMenuOrTrigger(this._rootNode.elementFromPoint(i.clientX, i.clientY))) : this._triggerPressedControl && o === 0 && i.ctrlKey)); }
    _isWithinMenuOrTrigger(e) { if (!e)
        return !1; let i = this._element.nativeElement; if (e === i || i.contains(e))
        return !0; let o = this._overlayRef?.hostElement; return o === e || !!o?.contains(e); }
    _openContextMenu(e) { e.button === 2 ? this._openedBy = "mouse" : this._openedBy = e.button === 0 ? "keyboard" : void 0, this._initializePoint(e.clientX, e.clientY), this._triggerPressedControl = e.ctrlKey, super._openMenu(!0), this._scrollSubscription?.unsubscribe(), this._scrollSubscription = this._scrollDispatcher.scrolled(0).subscribe(() => { let i = this._viewportRuler.getViewportScrollPosition(), o = this._point; o.y = o.initialY + (o.initialScrollY - i.top), o.x = o.initialX + (o.initialScrollX - i.left), this._updatePosition(); }); }
    _initializePoint(e, i) { let o = this._viewportRuler.getViewportScrollPosition(), r = this._point; r.x = r.initialX = e, r.y = r.initialY = i, r.initialScrollX = o.left, r.initialScrollY = o.top; }
    _updatePosition() { let e = this._overlayRef; e && (e.getConfig().positionStrategy.setOrigin(this._point), e.updatePosition()); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdContextMenuTriggerFor", ""]], hostAttrs: [1, "md-context-menu-trigger"], hostVars: 3, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("contextmenu", function (s) { return o._handleContextMenuEvent(s); }), i & 2 && (t.\u0275\u0275attribute("aria-controls", o.menuOpen ? o.menu?.panelId : null), t.\u0275\u0275classProp("md-context-menu-trigger-disabled", o.disabled)); }, inputs: { menu: [0, "mdContextMenuTriggerFor", "menu"], menuData: [0, "mdContextMenuTriggerData", "menuData"], restoreFocus: [0, "mdContextMenuTriggerRestoreFocus", "restoreFocus"], disabled: [2, "mdContextMenuTriggerDisabled", "disabled", m] }, outputs: { menuOpened: "menuOpened", menuClosed: "menuClosed" }, exportAs: ["mdContextMenuTrigger"], features: [t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), ng = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [vt, Qe, Xr] });
} return n; })(), og = (() => {
    class n {
        state = "checked";
        disabled = !1;
        appearance = "full";
        constructor() { }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["pseudo-checkbox"]], hostAttrs: [1, "pseudo-checkbox"], hostVars: 10, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("pseudo-checkbox-indeterminate", o.state === "indeterminate")("pseudo-checkbox-checked", o.state === "checked")("pseudo-checkbox-disabled", o.disabled)("pseudo-checkbox-minimal", o.appearance === "minimal")("pseudo-checkbox-full", o.appearance === "full"); }, inputs: { state: "state", disabled: "disabled", appearance: "appearance" }, decls: 0, vars: 0, template: function (i, o) { }, styles: [`.pseudo-checkbox{border-radius:2px;cursor:pointer;display:inline-block;vertical-align:middle;box-sizing:border-box;position:relative;flex-shrink:0;transition:border-color 90ms cubic-bezier(0,0,.2,.1),background-color 90ms cubic-bezier(0,0,.2,.1);width:18px;height:18px}.pseudo-checkbox:after{position:absolute;opacity:0;content:"";border-bottom:2px solid currentColor;transition:opacity 90ms cubic-bezier(0,0,.2,.1)}.pseudo-checkbox-disabled{cursor:default}.pseudo-checkbox-indeterminate:after{left:1px;opacity:1;border-radius:2px}.pseudo-checkbox-checked:after{left:1px;border-left:2px solid currentColor;transform:rotate(-45deg);opacity:1;box-sizing:content-box}.pseudo-checkbox-full{border-color:var(--%NS%md-pseudo-checkbox-border-color, #44474e);border-width:2px;border-style:solid}.pseudo-checkbox-full.pseudo-checkbox-disabled{border-color:color-mix(in srgb,var(--%NS%md-color-text, #1a1b1f) 38%,transparent);opacity:.38}.pseudo-checkbox-full.pseudo-checkbox-checked,.pseudo-checkbox-full.pseudo-checkbox-indeterminate{background-color:var(--%NS%md-pseudo-checkbox-selected-background, #CF0106);border-color:transparent}.pseudo-checkbox-full.pseudo-checkbox-checked:after,.pseudo-checkbox-full.pseudo-checkbox-indeterminate:after{color:var(--%NS%md-pseudo-checkbox-selected-color, #FFFFFF)}.pseudo-checkbox-full.pseudo-checkbox-checked.pseudo-checkbox-disabled,.pseudo-checkbox-full.pseudo-checkbox-indeterminate.pseudo-checkbox-disabled{background-color:var(--%NS%md-pseudo-checkbox-disabled-background, #e0e3e2);opacity:.38}.pseudo-checkbox-full.pseudo-checkbox-checked.pseudo-checkbox-disabled:after,.pseudo-checkbox-full.pseudo-checkbox-indeterminate.pseudo-checkbox-disabled:after{color:var(--%NS%md-pseudo-checkbox-disabled-color, #101414)}.pseudo-checkbox-full.pseudo-checkbox-checked:after{width:10px;height:4px;transform-origin:center;inset:-2.8284271247px 0 0;margin:auto}.pseudo-checkbox-full.pseudo-checkbox-indeterminate:after{top:6px;width:12px}.pseudo-checkbox-minimal.pseudo-checkbox-checked:after{width:14px;height:6px;transform-origin:center;inset:-4.2426406871px 0 0;margin:auto}.pseudo-checkbox-minimal.pseudo-checkbox-checked:after{color:var(--%NS%md-pseudo-checkbox-selected-background, #CF0106)}.mdc-option .pseudo-checkbox-minimal{margin-left:16px;flex-shrink:0}
`], encapsulation: 2 });
    }
    return n;
})(), $t = class {
    source;
    isUserInput;
    constructor(a, e = !1) { this.source = a, this.isUserInput = e; }
}, qn = (() => {
    class n {
        _element = d(x);
        _changeDetectorRef = d(E);
        _parent = d(Jt, { optional: !0 });
        group = d(Qn, { optional: !0 });
        _selected = !1;
        _active = !1;
        value;
        id = d(W).getId("md-option-");
        get disabled() { return this.group && this.group.disabled || this._disabled(); }
        set disabled(e) { this._disabled.set(e); }
        _disabled = B(!1);
        get multiple() { return this._parent && this._parent.multiple; }
        get selected() { return this._selected; }
        onSelectionChange = new p;
        _text;
        _stateChanges = new D;
        constructor() { }
        get active() { return this._active; }
        select(e = !0) { this._selected || (this._selected = !0, this._changeDetectorRef.markForCheck(), e && this._emitSelectionChangeEvent()); }
        _handleKeydown(e) { (e.keyCode === Q || e.keyCode === se) && !q(e) && (this._selectViaInteraction(), e.preventDefault()); }
        _selectViaInteraction() { this.disabled || (this._selected = this.multiple ? !this._selected : !0, this._changeDetectorRef.markForCheck(), this._emitSelectionChangeEvent(!0)); }
        deselect(e = !0) { this._selected && (this._selected = !1, this._changeDetectorRef.markForCheck(), e && this._emitSelectionChangeEvent()); }
        focus(e, i) { let o = this._getHostElement(); typeof o.focus == "function" && o.focus(i); }
        get viewValue() { return (this._text?.nativeElement.textContent || "").trim(); }
        getLabel() { return this.viewValue; }
        setActiveStyles() { this._active || (this._active = !0, this._changeDetectorRef.markForCheck()); }
        setInactiveStyles() { this._active && (this._active = !1, this._changeDetectorRef.markForCheck()); }
        _getHostElement() { return this._element.nativeElement; }
        _emitSelectionChangeEvent(e = !1) { this.onSelectionChange.emit(new $t(this, e)); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-option"]], viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(Zl, 7), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._text = r.first);
            } }, hostAttrs: ["role", "option", 1, "mdc-option", "mdc-list-item"], hostVars: 11, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function () { return o._selectViaInteraction(); })("keydown", function (s) { return o._handleKeydown(s); }), i & 2 && (t.\u0275\u0275domProperty("id", o.id), t.\u0275\u0275attribute("aria-selected", o.selected)("aria-disabled", o.disabled.toString()), t.\u0275\u0275classProp("mdc-list-item--selected", o.selected)("mdc-option-multiple", o.multiple)("mdc-option-active", o.active)("mdc-list-item--disabled", o.disabled)); }, inputs: { value: "value", id: "id", disabled: [2, "disabled", "disabled", m] }, outputs: { onSelectionChange: "onSelectionChange" }, ngContentSelectors: ec, decls: 6, vars: 2, consts: [["text", ""], ["aria-hidden", "true", 1, "mdc-option-pseudo-checkbox", 3, "disabled", "state"], [1, "mdc-list-item__primary-text"], ["state", "checked", "aria-hidden", "true", "appearance", "minimal", 1, "mdc-option-pseudo-checkbox", 3, "disabled"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(Jl), t.\u0275\u0275conditionalCreate(0, tc, 1, 2, "pseudo-checkbox", 1), t.\u0275\u0275projection(1), t.\u0275\u0275elementStart(2, "span", 2, 0), t.\u0275\u0275projection(4, 1), t.\u0275\u0275elementEnd(), t.\u0275\u0275conditionalCreate(5, ic, 1, 1, "pseudo-checkbox", 3)), i & 2 && (t.\u0275\u0275conditional(o.multiple ? 0 : -1), t.\u0275\u0275advance(5), t.\u0275\u0275conditional(!o.multiple && o.selected ? 5 : -1)); }, dependencies: [og], styles: [`md-option{-webkit-user-select:none;user-select:none;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;display:flex;position:relative;align-items:center;justify-content:flex-start;overflow:hidden;min-height:28px;padding:0 16px;cursor:pointer;-webkit-tap-highlight-color:rgba(0,0,0,0);color:var(--%NS%md-option-color, #000000);font-family:var(--%NS%md-option-font-family, var(--%NS%md-font-heading, "Montserrat"));font-weight:400;font-size:13px;line-height:20px;letter-spacing:.006rem}.mdc-option .pseudo-checkbox-full{margin-right:16px;flex-shrink:0}.mdc-option .pseudo-checkbox-minimal{margin-left:16px;flex-shrink:0}.mdc-option.mdc-list-item{align-items:center;background:#0000}.mdc-option.mdc-option-active.mdc-list-item{background-color:var(--%NS%md-option-active-background, color-mix(in srgb, #1a1b1f 8%, transparent));outline:0}.mdc-option .mdc-list-item__primary-text{white-space:normal;font-size:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;font-family:inherit;text-decoration:inherit;text-transform:inherit;margin-right:auto}.mdc-option:hover:not(.mdc-list-item--disabled){background-color:var(--%NS%md-option-hover-background, color-mix(in srgb, #1a1b1f 8%, transparent));color:var(--%NS%md-option-hover-color, #CF0106)}.mdc-list-item.mdc-list-item--disabled .mdc-list-item__primary-text{color:var(--%NS%md-option-disabled-color, #929292)}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})();
function Da(n, a, e) { if (e.length) {
    let i = a.toArray(), o = e.toArray(), r = 0;
    for (let s = 0; s < n + 1; s++)
        i[s].group && i[s].group === o[r] && r++;
    return r;
} return 0; }
function Ma(n, a, e, i) { return n < e ? n : n + a > e + i ? Math.max(0, n - i + a) : e; }
function gy() { return Error("Cannot change `multiple` mode of select after initialization."); }
function fy() { return Error("Value must be an array in multiple-selection mode."); }
function by() { return Error("`compareWith` must be a function."); }
var Ji = class {
    source;
    value;
    constructor(a, e) { this.source = a, this.value = e; }
}, Ta = new k("MDSelectTrigger"), Jt = (() => {
    class n {
        _viewportRuler = d(Qr);
        _changeDetectorRef = d(E);
        _elementRef = d(x);
        _overlay = d(yt);
        _dir = d(ke, { optional: !0 });
        _initialized = new D;
        ngControl = d(Ln, { self: !0, optional: !0 });
        _idGenerator = d(W);
        _cleanupDetach;
        _renderer = d(ye);
        panelClass;
        disabled = !1;
        get multiple() { return this._multiple; }
        set multiple(e) { this._selectionModel, this._multiple = e; }
        _multiple = !1;
        get value() { return this._value; }
        set value(e) { this._assignValue(e) && this._onChange(e); }
        _value;
        tabIndex = 0;
        get required() { return this._required ?? this.ngControl?.control?.hasValidator(Bn.required) ?? !1; }
        set required(e) { this._required = e, this.stateChanges.next(); }
        _required;
        get compareWith() { return this._compareWith; }
        set compareWith(e) { this._compareWith = e, this._selectionModel && this._initializeSelection(); }
        _compareWith = (e, i) => e === i;
        get placeholder() { return this._placeholder; }
        set placeholder(e) { this._placeholder = e, this.stateChanges.next(); }
        _placeholder = "placeholder";
        canSelectNullableOptions = !1;
        sortComparator;
        valueChange = new p;
        selectionChange = new p;
        openedChange = new p;
        _openedStream = this.openedChange.pipe(ar(e => e), sr(() => { }));
        _closedStream = this.openedChange.pipe(ar(e => !e), sr(() => { }));
        trigger;
        panel;
        _overlayDir;
        customTrigger;
        options;
        optionGroups;
        _positions = [{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top" }, { originX: "end", originY: "bottom", overlayX: "end", overlayY: "top" }, { originX: "start", originY: "top", overlayX: "start", overlayY: "bottom" }, { originX: "end", originY: "top", overlayX: "end", overlayY: "bottom" }];
        get focused() { return this._focused || this._panelOpen; }
        _focused = !1;
        stateChanges = new D;
        _destroy = new D;
        _panelOpen = !1;
        _overlayWidth;
        _scrollStrategy = this._overlay.scrollStrategies.reposition();
        _selectionModel;
        _onChange = () => { };
        _onTouched = () => { };
        _keyManager;
        optionSelectionChanges = In(() => { let e = this.options; return e ? e.changes.pipe(Ki(e), Ui(() => R(...e.map(i => i.onSelectionChange)))) : this._initialized.pipe(Ui(() => this.optionSelectionChanges)); });
        _valueId = this._idGenerator.getId("select-value-");
        get empty() { return !this._selectionModel || this._selectionModel.isEmpty(); }
        constructor() { this.ngControl && (this.ngControl.valueAccessor = this); }
        ngOnChanges(e) { }
        ngAfterContentInit() { this._initialized.next(), this._initialized.complete(), this._initKeyManager(), this._selectionModel.changed.pipe(Ie(this._destroy)).subscribe(e => { e.added.forEach(i => i.select()), e.removed.forEach(i => i.deselect()); }), this.options.changes.pipe(Ki(null), Ie(this._destroy)).subscribe(() => { this._resetOptions(), this._initializeSelection(); }); }
        ngOnInit() { this._selectionModel = new qd(this.multiple), this.stateChanges.next(), this._viewportRuler.change().pipe(Ie(this._destroy)).subscribe(() => { this.panelOpen && (this._overlayWidth = this._getOverlayWidth(), this._changeDetectorRef.detectChanges()); }); }
        ngOnDestroy() { this._keyManager?.destroy(), this._destroy.next(), this._destroy.complete(); }
        get panelOpen() { return this._panelOpen; }
        get selected() { return this.multiple ? this._selectionModel?.selected || [] : this._selectionModel?.selected[0]; }
        get triggerValue() { if (this.empty)
            return ""; if (this._multiple) {
            let e = this._selectionModel.selected.map(i => i.viewValue);
            return this._isRtl() && e.reverse(), e.join(", ");
        } return this._selectionModel.selected[0].viewValue; }
        writeValue(e) { this._assignValue(e); }
        registerOnChange(e) { this._onChange = e; }
        registerOnTouched(e) { this._onTouched = e; }
        setDisabledState(e) { this.disabled = e, this._changeDetectorRef.markForCheck(), this.stateChanges.next(); }
        _canOpen() { return !this._panelOpen && !this.disabled && this.options?.length > 0 && !!this._overlayDir; }
        open() { this._canOpen() && (this._cleanupDetach?.(), this._overlayWidth = this._getOverlayWidth(), this._panelOpen = !0, this._overlayDir.positionChange.pipe($d(1)).subscribe(() => { this._changeDetectorRef.detectChanges(), this._positioningSettled(); }), this._overlayDir.attachOverlay(), this._keyManager.withHorizontalOrientation(null), this._highlightCorrectOption(), this._changeDetectorRef.markForCheck(), this.stateChanges.next(), Promise.resolve().then(() => this.openedChange.emit(!0))); }
        _highlightCorrectOption() { if (this._keyManager)
            if (this.empty) {
                let e = -1;
                for (let i = 0; i < this.options.length; i++)
                    if (!this.options.get(i).disabled) {
                        e = i;
                        break;
                    }
                this._keyManager.setActiveItem(e);
            }
            else
                this._keyManager.setActiveItem(this._selectionModel.selected[0]); }
        _positioningSettled() { this._scrollOptionIntoView(this._keyManager.activeItemIndex || 0); }
        close() { this._panelOpen && (this._panelOpen = !1, this._exitAndDetach(), this._keyManager.withHorizontalOrientation(this._isRtl() ? "rtl" : "ltr"), this._changeDetectorRef.markForCheck(), this._onTouched(), this.stateChanges.next(), Promise.resolve().then(() => this.openedChange.emit(!1))); }
        _exitAndDetach() { if (!this.panel) {
            this._detachOverlay();
            return;
        } this._cleanupDetach?.(), this._cleanupDetach = () => { i(), clearTimeout(o), this._cleanupDetach = void 0; }; let e = this.panel.nativeElement, i = this._renderer.listen(e, "animationend", r => { r.animationName === "select-exit" && (this._cleanupDetach?.(), this._detachOverlay()); }), o = setTimeout(() => { this._cleanupDetach?.(), this._detachOverlay(); }, 200); e.classList.add("select-panel-exit"); }
        _detachOverlay() { this._overlayDir.detachOverlay(), this._changeDetectorRef.markForCheck(); }
        _isRtl() { return this._dir ? this._dir.value === "rtl" : !1; }
        _handleKeydown(e) { this.disabled || (this.panelOpen ? this._handleOpenKeydown(e) : this._handleClosedKeydown(e)); }
        _handleClosedKeydown(e) { let i = e.keyCode, o = i === dt || i === Fe || i === Mn || i === Dn, r = i === Q || i === se, s = this._keyManager; if (!s.isTyping() && r && !q(e) || (this.multiple || e.altKey) && o)
            e.preventDefault(), this.open();
        else if (!this.multiple) {
            let l = this.selected;
            s.onKeydown(e);
            let c = this.selected;
        } }
        _handleOpenKeydown(e) { let i = this._keyManager, o = e.keyCode, r = o === dt || o === Fe, s = i.isTyping(); if (r && e.altKey)
            e.preventDefault(), this.close();
        else if (!s && (o === Q || o === se) && i.activeItem && !q(e))
            e.preventDefault(), i.activeItem._selectViaInteraction();
        else if (!s && this._multiple && o === Wd && e.ctrlKey) {
            e.preventDefault();
            let l = this.options.some(c => !c.disabled && !c.selected);
            this.options.forEach(c => { c.disabled || (l ? c.select() : c.deselect()); });
        }
        else {
            let l = i.activeItemIndex;
            i.onKeydown(e), this._multiple && r && e.shiftKey && i.activeItem && i.activeItemIndex !== l && i.activeItem._selectViaInteraction();
        } }
        _handleOverlayKeydown(e) { e.keyCode === qe && !q(e) && (e.preventDefault(), this.close()); }
        _assignValue(e) { return e !== this._value || this._multiple && Array.isArray(e) ? (this.options && this._setSelectionByValue(e), this._value = e, !0) : !1; }
        _getOverlayOrigin() { return this._elementRef.nativeElement.closest(".md-form-field-shell") ?? this.trigger?.nativeElement ?? this._elementRef.nativeElement; }
        _getOverlayWidth() { return this._getOverlayOrigin().getBoundingClientRect().width; }
        _setSelectionByValue(e) { if (this.options.forEach(i => i.setInactiveStyles()), this._selectionModel.clear(), this.multiple && e)
            Array.isArray(e), e.forEach(i => this._selectOptionByValue(i)), this._sortValues();
        else {
            let i = this._selectOptionByValue(e);
            i ? this._keyManager.updateActiveItem(i) : this.panelOpen || this._keyManager.updateActiveItem(-1);
        } this._changeDetectorRef.markForCheck(); }
        _selectOptionByValue(e) { let i = this.options.find(o => { if (this._selectionModel.isSelected(o))
            return !1; try {
            return (o.value != null || this.canSelectNullableOptions) && this._compareWith(o.value, e);
        }
        catch {
            return !1;
        } }); return i && this._selectionModel.select(i), i; }
        focus(e) { this._elementRef.nativeElement.focus(e); }
        onContainerClick() { this.focus(), this.open(); }
        _initializeSelection() { Promise.resolve().then(() => { this.ngControl && (this._value = this.ngControl.value), this._setSelectionByValue(this._value), this.stateChanges.next(); }); }
        _skipPredicate = e => this.panelOpen ? !1 : e.disabled;
        _scrollOptionIntoView(e) { let i = this.options.toArray()[e]; if (!i)
            return; let o = this.panel.nativeElement, r = Da(e, this.options, this.optionGroups), s = i._getHostElement(); e === 0 && r === 1 ? o.scrollTop = 0 : o.scrollTop = Ma(s.offsetTop, s.offsetHeight, o.scrollTop, o.offsetHeight); }
        _resetOptions() { let e = R(this.options.changes, this._destroy); this.optionSelectionChanges.pipe(Ie(e)).subscribe(i => { this._onSelect(i.source, i.isUserInput), i.isUserInput && !this.multiple && this._panelOpen && (this.close(), this.focus()); }), R(...this.options.map(i => i._stateChanges)).pipe(Ie(e)).subscribe(() => { this._changeDetectorRef.detectChanges(), this.stateChanges.next(); }); }
        _onSelect(e, i) { let o = this._selectionModel.isSelected(e); e.value == null && !this._multiple ? (e.deselect(), this._selectionModel.clear(), this.value != null && this._propagateChanges(e.value)) : (o !== e.selected && (e.selected ? this._selectionModel.select(e) : this._selectionModel.deselect(e)), i && this._keyManager.setActiveItem(e), this.multiple && (this._sortValues(), i && this.focus())), o !== this._selectionModel.isSelected(e) && this._propagateChanges(), this.stateChanges.next(); }
        _sortValues() { if (!this.multiple)
            return; let e = this.options.toArray(); this._selectionModel.sort((i, o) => this.sortComparator ? this.sortComparator(i, o, e) : e.indexOf(i) - e.indexOf(o)), this.stateChanges.next(); }
        _getChangeEvent(e) { return new Ji(this, e); }
        _propagateChanges(e) { let i; this.multiple ? i = this.selected.map(o => o.value) : i = this.selected ? this.selected.value : e, this._value = i, this.valueChange.emit(i), this._onChange(i), this.selectionChange.emit(this._getChangeEvent(i)), this._changeDetectorRef.markForCheck(); }
        _initKeyManager() { this._keyManager = new Ar(this.options).withTypeAhead(200).withVerticalOrientation().withHorizontalOrientation(this._isRtl() ? "rtl" : "ltr").withHomeAndEnd().withPageUpDown().withAllowedModifierKeys(["shiftKey"]).skipPredicate(this._skipPredicate), this._keyManager.tabOut.subscribe(() => { this.panelOpen && (!this.multiple && this._keyManager.activeItem && this._keyManager.activeItem._selectViaInteraction(), this.focus(), this.close()); }), this._keyManager.change.subscribe(() => { this._panelOpen && this.panel ? this._scrollOptionIntoView(this._keyManager.activeItemIndex || 0) : !this._panelOpen && !this.multiple && this._keyManager.activeItem && this._keyManager.activeItem._selectViaInteraction(); }); }
        _getAriaActiveDescendant() { return this.panelOpen && this._keyManager && this._keyManager.activeItem ? this._keyManager.activeItem.id : null; }
        _onFocus() { this.disabled || (this._focused = !0, this.stateChanges.next()); }
        _onBlur() { this._focused = !1, this._keyManager?.cancelTypeahead(), !this.disabled && !this.panelOpen && (this._onTouched(), this._changeDetectorRef.markForCheck(), this.stateChanges.next()); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-select"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Ta, 5)(r, qn, 5)(r, Qn, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.customTrigger = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.options = s), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.optionGroups = s);
            } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(nc, 5)(Hn, 5)(ct, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.trigger = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.panel = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._overlayDir = r.first);
            } }, hostAttrs: ["role", "combobox", "aria-haspopup", "listbox", 1, "mdc-select"], hostVars: 13, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("keydown", function (s) { return o._handleKeydown(s); })("focus", function () { return o._onFocus(); })("blur", function () { return o._onBlur(); })("click", function () { return o.onContainerClick(); }), i & 2 && (t.\u0275\u0275attribute("tabindex", o.disabled ? -1 : o.tabIndex)("aria-expanded", o.panelOpen)("aria-required", o.required.toString())("aria-disabled", o.disabled.toString())("aria-activedescendant", o._getAriaActiveDescendant()), t.\u0275\u0275classProp("mdc-select-disabled", o.disabled)("mdc-select-required", o.required)("mdc-select-empty", o.empty)("mdc-select-multiple", o.multiple)); }, inputs: { panelClass: "panelClass", disabled: [2, "disabled", "disabled", m], multiple: [2, "multiple", "multiple", m], value: "value", tabIndex: [2, "tabIndex", "tabIndex", e => e == null ? 0 : S(e)], required: [2, "required", "required", m], compareWith: "compareWith", placeholder: "placeholder", canSelectNullableOptions: [2, "canSelectNullableOptions", "canSelectNullableOptions", m], sortComparator: "sortComparator" }, outputs: { valueChange: "valueChange", selectionChange: "selectionChange", openedChange: "openedChange", _openedStream: "opened", _closedStream: "closed" }, features: [t.\u0275\u0275NgOnChangesFeature], ngContentSelectors: rc, decls: 8, vars: 8, consts: [["trigger", ""], ["panel", ""], [1, "mdc-select-trigger", 3, "click"], [1, "mdc-select-value"], [1, "mdc-select-placeholder", "mdc-select-min-line"], [1, "mdc-select-value-text"], [1, "mdc-select-arrow-wrapper"], ["aria-hidden", "true", 1, "mdc-select-arrow"], ["cdk-connected-overlay", "", "cdkConnectedOverlayLockPosition", "", "cdkConnectedOverlayHasBackdrop", "", "cdkConnectedOverlayBackdropClass", "cdk-overlay-transparent-backdrop", 3, "detach", "backdropClick", "overlayKeydown", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayWidth", "cdkConnectedOverlayFlexibleDimensions"], [1, "mdc-select-min-line"], ["role", "listbox", "tabindex", "-1", 1, "mdc-select-panel", "mdc-menu-surface", "select-panel-animations-enabled", "mdc-menu-surface--open", 3, "keydown", "ngClass"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(oc), t.\u0275\u0275elementStart(0, "div", 2, 0), t.\u0275\u0275listener("click", function () { return o.open(); }), t.\u0275\u0275elementStart(2, "div", 3), t.\u0275\u0275conditionalCreate(3, ac, 2, 1, "span", 4)(4, lc, 3, 1, "span", 5), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(5, "div", 6), t.\u0275\u0275element(6, "span", 7), t.\u0275\u0275elementEnd()(), t.\u0275\u0275template(7, cc, 3, 4, "ng-template", 8), t.\u0275\u0275listener("detach", function () { return o.close(); })("backdropClick", function () { return o.close(); })("overlayKeydown", function (s) { return o._handleOverlayKeydown(s); })), i & 2 && (t.\u0275\u0275advance(2), t.\u0275\u0275attribute("id", o._valueId), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.empty ? 3 : 4), t.\u0275\u0275advance(4), t.\u0275\u0275property("cdkConnectedOverlayDisableClose", !0)("cdkConnectedOverlayScrollStrategy", o._scrollStrategy)("cdkConnectedOverlayOrigin", o._getOverlayOrigin())("cdkConnectedOverlayPositions", o._positions)("cdkConnectedOverlayWidth", o._overlayWidth)("cdkConnectedOverlayFlexibleDimensions", !0)); }, dependencies: [ct, kn], styles: [`md-select{display:inline-block}md-select[aria-expanded=true] .mdc-select-trigger{border-color:var(--%NS%md-control-expanded-border-color, rgba(0, 0, 0, .1));background-color:var(--%NS%md-control-expanded-background, #F3F3F3);outline:0!important;box-shadow:none}md-select[aria-expanded=true] .mdc-select-placeholder{color:var(--%NS%md-control-text-color, var(--%NS%bs-body-color))}@keyframes select-enter{0%{opacity:0;transform:scaleY(.8)}to{opacity:1;transform:none}}@keyframes select-exit{0%{opacity:1}to{opacity:0}}.select-panel-animations-enabled{animation:select-enter .12s cubic-bezier(0,0,.2,1)}.select-panel-animations-enabled.select-panel-exit{animation:select-exit .2s linear}.mdc-select{width:180px;display:inline-block;outline:none;font-family:var(--%NS%md-control-font-family, var(--%NS%md-font-body, "Open Sans"));line-height:1.5rem;font-size:14px;font-weight:400;letter-spacing:.031rem;color:var(--%NS%md-control-text-color, #373737)}.mdc-select-trigger{display:inline-flex;align-items:center;cursor:pointer;position:relative;box-sizing:border-box;width:100%;height:var(--%NS%md-control-height, 37px);padding:0 12px;border:1px solid var(--%NS%md-control-border-color, #F3F3F3);border-radius:var(--%NS%md-control-radius, 2px);background-color:var(--%NS%md-control-background, #FFFFFF)}.form-control .mdc-select-trigger{background-color:initial;height:initial;border:initial;padding:initial}.mdc-select-value{width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.mdc-select-arrow-wrapper{height:24px;flex-shrink:0;display:inline-flex;align-items:center}div.mdc-select-panel{width:100%;max-height:275px;outline:0;overflow:auto;padding:4px;border-radius:var(--%NS%md-overlay-radius, var(--%NS%md-control-radius, 2px));box-sizing:border-box;position:relative;background-color:var(--%NS%md-overlay-surface, #FFFFFF);box-shadow:var(--%NS%md-overlay-shadow, 0 1px 3px 1px rgba(0, 0, 0, .1490196078))}.mdc-select-disabled{color:var(--%NS%md-control-placeholder-color, #929292);background-color:var(--%NS%md-control-disabled-background, color-mix(in srgb, #e0e3e2 4%, transparent));pointer-events:none}.mdc-select-arrow{display:block;width:0;height:0;border-right:5px solid transparent;border-left:5px solid transparent;border-top:6px solid currentColor;color:var(--%NS%md-control-arrow-color, #929292)}.mdc-select-placeholder{color:var(--%NS%md-control-placeholder-color, #929292)}
`], encapsulation: 2 });
    }
    return n;
})(), _y = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-select-trigger"]], features: [t.\u0275\u0275ProvidersFeature([{ provide: Ta, useExisting: n }])] });
} return n; })(), Qn = (() => {
    class n {
        label;
        disabled = !1;
        _labelId = d(W).getId("optgroup-label-");
        _inert;
        constructor() { let e = d(Jt, { optional: !0 }); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-option-group"]], hostAttrs: [1, "mdc-optgroup"], inputs: { label: "label", disabled: [2, "disabled", "disabled", m] }, ngContentSelectors: hc, decls: 5, vars: 4, consts: [["role", "presentation", 1, "mdc-optgroup-label", 3, "id"], [1, "mdc-list-item__primary-text"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(mc), t.\u0275\u0275domElementStart(0, "span", 0)(1, "span", 1), t.\u0275\u0275text(2), t.\u0275\u0275projection(3), t.\u0275\u0275domElementEnd()(), t.\u0275\u0275projection(4, 1)), i & 2 && (t.\u0275\u0275classProp("mdc-list-item--disabled", o.disabled), t.\u0275\u0275domProperty("id", o._labelId), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate1("", o.label, " ")); }, styles: [`.mdc-optgroup-label{display:flex;position:relative;align-items:center;justify-content:flex-start;overflow:hidden;min-height:36px;padding:0 8px;outline:none}.mdc-optgroup{color:var(--%NS%md-option-group-color, #373737);font-family:Open Sans;line-height:1.25rem;font-size:.875rem;letter-spacing:.006rem;font-weight:500}.mdc-optgroup-label .mdc-list-item__primary-text{font-size:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;font-family:inherit;text-decoration:inherit;text-transform:inherit;white-space:normal;color:inherit}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})(), rg = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [Qe] });
} return n; })(), vr = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [rg, Qe] });
} return n; })(), ag = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [ae, ll, vt] });
} return n; })(), sg = (() => { class n {
    cd = d(E);
    modelValue = B(void 0);
    required = I(void 0, { transform: m });
    invalid = I(void 0, { transform: m });
    disabled = I(void 0, { transform: m });
    name = I();
    _disabled = B(!1);
    $disabled = re(() => this.disabled() || this._disabled());
    onModelChange = () => { };
    onModelTouched = () => { };
    writeDisabledState(e) { this._disabled.set(e); }
    writeControlValue(e, i) { }
    writeValue(e) { this.writeControlValue(e, this.writeModelValue.bind(this)); }
    writeModelValue(e) { this.modelValue.set(e); }
    registerOnChange(e) { this.onModelChange = e; }
    registerOnTouched(e) { this.onModelTouched = e; }
    setDisabledState(e) { this.writeDisabledState(e), this.cd.markForCheck(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, inputs: { required: [1, "required"], invalid: [1, "invalid"], disabled: [1, "disabled"], name: [1, "name"] } });
} return n; })(), vy = (() => {
    class n extends sg {
        _uniqueId;
        id;
        tabindex;
        readonly;
        onHostClick(e) { this._handleClick(e); }
        onChange = new p;
        input;
        focused = !1;
        constructor() { super(), this.id = this._uniqueId = d(W).getId("slide-toggle-"); }
        ngOnInit() { }
        validate() { }
        ngOnDestroy() { }
        writeControlValue(e, i) { i(e), this.cd.markForCheck(); }
        onFocus() { this.focused = !0; }
        onBlur() { this.focused = !1, this.onModelTouched(); }
        _handleClick(e) { !this.$disabled() && !this.readonly && (this.writeModelValue(!this.modelValue()), this.onModelChange(this.modelValue()), this.onChange.emit({ originalEvent: e, checked: this.modelValue() }), this.input.nativeElement.focus()); }
        checked() { return this.modelValue(); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-switch"]], viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(jn, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.input = r.first);
            } }, hostVars: 6, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function (s) { return o.onHostClick(s); }), i & 2 && t.\u0275\u0275classProp("toggleswitch-checked", o.checked())("disabled", o.$disabled())("invalid", o.invalid()); }, inputs: { id: "id", tabindex: [2, "tabindex", "tabindex", S], readonly: [2, "readonly", "readonly", m] }, outputs: { onChange: "onChange" }, standalone: !1, features: [t.\u0275\u0275ProvidersFeature([{ provide: J, useExisting: A(() => n), multi: !0 }, { provide: xt, useExisting: n, multi: !0 }]), t.\u0275\u0275InheritDefinitionFeature], decls: 4, vars: 4, consts: [["input", ""], ["type", "checkbox", "role", "switch", 1, "toggleswitch-input", 3, "focus", "blur", "checked"], [1, "toggleswitch-slider"], [1, "toggleswitch-handle"]], template: function (i, o) { i & 1 && (t.\u0275\u0275elementStart(0, "input", 1, 0), t.\u0275\u0275listener("focus", function () { return o.onFocus(); })("blur", function () { return o.onBlur(); }), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(2, "div", 2), t.\u0275\u0275element(3, "div", 3), t.\u0275\u0275elementEnd()), i & 2 && (t.\u0275\u0275property("checked", o.checked()), t.\u0275\u0275attribute("required", o.required() ? "" : void 0)("disabled", o.$disabled() ? "" : void 0)("aria-checked", o.checked())); }, styles: [`md-switch{display:inline-block;position:relative;width:40px;height:20px}.toggleswitch-input{cursor:pointer;appearance:none;position:absolute;top:0;inset-inline-start:0;width:100%;height:100%;padding:0;margin:0;opacity:0;z-index:1;outline:0 none;border-radius:10px}md-switch.toggleswitch-checked .toggleswitch-slider{background:var(--%NS%md-switch-track-checked-background, #CF0106);border-color:transparent}md-switch.toggleswitch-checked .toggleswitch-handle{inset-inline-start:calc(40px - 1.25rem);background:var(--%NS%md-switch-handle-checked-background, #ffffff);color:var(--%NS%md-switch-handle-checked-color, #CF0106)}md-switch.disabled .toggleswitch-handle{background:var(--%NS%md-switch-handle-disabled-background, #64748b)}md-switch.disabled .toggleswitch-slider{background:var(--%NS%md-switch-track-disabled-background, #e2e8f0)}.toggleswitch-slider{cursor:pointer;width:100%;height:100%;border-width:1px;border-style:solid;border-color:transparent;background:var(--%NS%md-switch-track-background, #cbd5e1);border-radius:10px;outline-color:transparent;box-shadow:0 0 #0000,0 0 #0000,0 1px 2px #1212170d;transition:background .2s,color .2s,border-color .2s,outline-color .2s,box-shadow .2s}.toggleswitch-handle{position:absolute;top:50%;background:var(--%NS%md-switch-handle-background, #ffffff);color:var(--%NS%md-switch-handle-color, #6d5cae);width:1rem;height:1rem;inset-inline-start:.25rem;margin-block-start:-.5rem;border-radius:10px;transition:background .2s,color .2s,inset-inline-start .2s,box-shadow .2s}md-switch:not(.disabled):has(.toggleswitch-input:focus-visible) .toggleswitch-slider{outline:1px solid var(--%NS%md-switch-focus-ring-color, #6d5cae);outline-offset:2px}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})(), yy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [ae] });
} return n; })(), yr = { passive: !0 }, dg = 650, lg = 100, Ea = (() => { class n {
    _elementRef = d(x);
    _changeDetectorRef = d(E);
    _viewportRuler = d(Zr);
    _dir = d(ke, { optional: !0 });
    _ngZone = d(K);
    _platform = d(mt);
    _sharedResizeObserver = d(ea);
    _injector = d(j);
    _renderer = d(ye);
    _eventCleanups;
    _scrollDistance = 0;
    _selectedIndexChanged = !1;
    _destroyed = new D;
    _showPaginationControls = !1;
    _disableScrollAfter = !0;
    _disableScrollBefore = !0;
    _tabLabelCount;
    _scrollDistanceChanged;
    _keyManager;
    _currentTextContent;
    _stopScrolling = new D;
    hideInkBar;
    disablePagination = !1;
    get selectedIndex() { return this._selectedIndex; }
    set selectedIndex(e) { let i = isNaN(e) ? 0 : e; this._selectedIndex != i && (this._selectedIndexChanged = !0, this._selectedIndex = i, this._keyManager && this._keyManager.updateActiveItem(i)); }
    _selectedIndex = 0;
    selectFocusedIndex = new p;
    indexFocused = new p;
    constructor() { this._eventCleanups = this._ngZone.runOutsideAngular(() => [this._renderer.listen(this._elementRef.nativeElement, "mouseleave", () => this._stopInterval())]); }
    ngAfterViewInit() { this._eventCleanups.push(this._renderer.listen(this._previousPaginator.nativeElement, "touchstart", () => this._handlePaginatorPress("before"), yr), this._renderer.listen(this._nextPaginator.nativeElement, "touchstart", () => this._handlePaginatorPress("after"), yr)); }
    ngAfterContentInit() { let e = this._dir ? this._dir.change : lt("ltr"), i = this._sharedResizeObserver.observe(this._elementRef.nativeElement).pipe(zr(32), O(this._destroyed)), o = (r = !1) => { this._checkPaginationEnabled(), r && this._scrollToLabel(this.selectedIndex), this._checkScrollingControls(), this._updateTabScrollPosition(), this._alignInkBarToSelectedTab(); }; this._keyManager = new Xt(this._items).withHorizontalOrientation(this._getLayoutDirection()).withHomeAndEnd().withWrap().skipPredicate(() => !1), this._keyManager.updateActiveItem(Math.max(this._selectedIndex, 0)), Oe(() => o(!0), { injector: this._injector }), R(e, i, this._items.changes, this._itemsResized()).pipe(O(this._destroyed)).subscribe(() => { this._ngZone.run(() => { Promise.resolve().then(() => { this._scrollDistance = Math.max(0, Math.min(this._getMaxScrollDistance(), this._scrollDistance)), o(!0); }); }), this._keyManager?.withHorizontalOrientation(this._getLayoutDirection()); }), this._keyManager.change.subscribe(r => { this.indexFocused.emit(r), this._setTabFocus(r); }); }
    _itemsResized() { return typeof ResizeObserver != "function" ? En : this._items.changes.pipe(z(this._items), ue(e => new jt(i => this._ngZone.runOutsideAngular(() => { let o = new ResizeObserver(r => i.next(r)); return e.forEach(r => o.observe(r.elementRef.nativeElement)), () => o.disconnect(); }))), Vr(1), V(e => e.some(i => i.contentRect.width > 0 && i.contentRect.height > 0))); }
    ngAfterContentChecked() { this._tabLabelCount != this._items.length && (this.updatePagination(), this._tabLabelCount = this._items.length, this._changeDetectorRef.markForCheck()), this._selectedIndexChanged && (this._scrollToLabel(this._selectedIndex), this._checkScrollingControls(), this._alignInkBarToSelectedTab(), this._selectedIndexChanged = !1, this._changeDetectorRef.markForCheck()), this._scrollDistanceChanged && (this._updateTabScrollPosition(), this._scrollDistanceChanged = !1, this._changeDetectorRef.markForCheck()); }
    ngOnDestroy() { this._eventCleanups.forEach(e => e()), this._keyManager?.destroy(), this._destroyed.next(), this._destroyed.complete(), this._stopScrolling.complete(); }
    _handleKeydown(e) { if (!q(e))
        switch (e.keyCode) {
            case Q:
            case se:
                if (this.focusIndex !== this.selectedIndex) {
                    let i = this._items.get(this.focusIndex);
                    i && !i.disabled && (this.selectFocusedIndex.emit(this.focusIndex), this._itemSelected(e));
                }
                break;
            default: this._keyManager?.onKeydown(e);
        } }
    _onContentChanges() { let e = this._elementRef.nativeElement.textContent; e !== this._currentTextContent && (this._currentTextContent = e || "", this._ngZone.run(() => { this.updatePagination(), this._alignInkBarToSelectedTab(), this._changeDetectorRef.markForCheck(); })); }
    updatePagination() { this._checkPaginationEnabled(), this._checkScrollingControls(), this._updateTabScrollPosition(); }
    get focusIndex() { return this._keyManager ? this._keyManager.activeItemIndex : 0; }
    set focusIndex(e) { !this._isValidIndex(e) || this.focusIndex === e || !this._keyManager || this._keyManager.setActiveItem(e); }
    _isValidIndex(e) { return this._items ? !!this._items.toArray()[e] : !0; }
    _setTabFocus(e) { if (this._showPaginationControls && this._scrollToLabel(e), this._items && this._items.length) {
        this._items.toArray()[e].focus();
        let i = this._tabListContainer.nativeElement;
        this._getLayoutDirection() == "ltr" ? i.scrollLeft = 0 : i.scrollLeft = i.scrollWidth - i.offsetWidth;
    } }
    _getLayoutDirection() { return this._dir && this._dir.value === "rtl" ? "rtl" : "ltr"; }
    _updateTabScrollPosition() { if (this.disablePagination)
        return; let e = this.scrollDistance, i = this._getLayoutDirection() === "ltr" ? -e : e; this._tabList.nativeElement.style.transform = `translateX(${Math.round(i)}px)`, (this._platform.TRIDENT || this._platform.EDGE) && (this._tabListContainer.nativeElement.scrollLeft = 0); }
    get scrollDistance() { return this._scrollDistance; }
    set scrollDistance(e) { this._scrollTo(e); }
    _scrollHeader(e) { let i = this._getVisibleRange(), o = this._getItemRanges(), r = e === "before" ? this._findPreviousItemRange(o, i.start) : this._findNextItemRange(o, i.start); return r ? this._scrollTo(r.start) : this._scrollTo(e === "before" ? 0 : this._getMaxScrollDistance()); }
    _handlePaginatorClick(e) { this._stopInterval(), this._scrollHeader(e); }
    _scrollToLabel(e) { if (this.disablePagination || !(this._items ? this._items.toArray()[e] : null))
        return; let o = this._getItemRanges()[e]; o && (this.scrollDistance = o.start); }
    _getVisibleRange() { let e = this._scrollDistance; return { start: e, end: e + this._tabListContainer.nativeElement.offsetWidth }; }
    _getItemRanges() { let e = this._tabListInner.nativeElement.offsetWidth; return (this._items?.toArray() ?? []).map((i, o) => { let r = i.elementRef.nativeElement, s = r.offsetWidth, l = this._getLayoutDirection() === "ltr" ? r.offsetLeft : e - r.offsetLeft - s; return { index: o, start: l, end: l + s, width: s }; }); }
    _findPreviousItemRange(e, i) { for (let o = e.length - 1; o >= 0; o--)
        if (e[o].start < i - 1)
            return e[o]; return null; }
    _findNextItemRange(e, i) { for (let o = 0; o < e.length; o++)
        if (e[o].start > i + 1)
            return e[o]; return null; }
    _checkPaginationEnabled() { if (this.disablePagination)
        this._showPaginationControls = !1;
    else {
        let e = this._tabListInner.nativeElement.scrollWidth, i = this._elementRef.nativeElement.offsetWidth, o = e - i >= 5;
        o || (this.scrollDistance = 0), o !== this._showPaginationControls && (this._showPaginationControls = o, this._changeDetectorRef.markForCheck());
    } }
    _checkScrollingControls() { if (this.disablePagination)
        this._disableScrollAfter = this._disableScrollBefore = !0;
    else {
        let e = this._getMaxScrollDistance();
        this._disableScrollBefore = this.scrollDistance <= 1, this._disableScrollAfter = this.scrollDistance >= e - 1, this._changeDetectorRef.markForCheck();
    } }
    _getMaxScrollDistance() { let e = this._tabListInner.nativeElement.scrollWidth, i = this._tabListContainer.nativeElement.offsetWidth; return Math.max(0, e - i); }
    _alignInkBarToSelectedTab() { if (this.hideInkBar)
        return; let e = this._items && this._items.length ? this._items.toArray()[this.selectedIndex] : null, i = e ? e.elementRef.nativeElement : null; i ? this._inkBar.alignToElement(i) : this._inkBar.hide(); }
    _stopInterval() { this._stopScrolling.next(); }
    _handlePaginatorPress(e, i) { i && i.button != null && i.button !== 0 || (this._stopInterval(), jr(dg, lg).pipe(O(R(this._stopScrolling, this._destroyed))).subscribe(() => { let { maxScrollDistance: o, distance: r } = this._scrollHeader(e); (r === 0 || r >= o) && this._stopInterval(); })); }
    _scrollTo(e) { if (this.disablePagination)
        return { maxScrollDistance: 0, distance: 0 }; let i = this._getMaxScrollDistance(); return this._scrollDistance = Math.max(0, Math.min(i, e)), this._scrollDistanceChanged = !0, this._checkScrollingControls(), { maxScrollDistance: i, distance: this._scrollDistance }; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, inputs: { hideInkBar: "hideInkBar", disablePagination: [2, "disablePagination", "disablePagination", m], selectedIndex: [2, "selectedIndex", "selectedIndex", S] }, outputs: { selectFocusedIndex: "selectFocusedIndex", indexFocused: "indexFocused" } });
} return n; })(), xr = (() => { class n extends Le {
    _host = d(en);
    _centeringSub = F.EMPTY;
    _leavingSub = F.EMPTY;
    constructor() { super(); }
    ngOnInit() { super.ngOnInit(), this._centeringSub = this._host._beforeCentering.pipe(z(this._host._isCenterPosition())).subscribe(e => { this._host._content && e && !this.hasAttached() && this.attach(this._host._content); }), this._leavingSub = this._host._afterLeavingCenter.subscribe(() => { this._host.preserveContent || this.detach(); }); }
    ngOnDestroy() { super.ngOnDestroy(), this._centeringSub.unsubscribe(), this._leavingSub.unsubscribe(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdTabBodyHost", ""]], features: [t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), en = (() => {
    class n {
        _elementRef = d(x);
        _dir = d(ke, { optional: !0 });
        _ngZone = d(K);
        _injector = d(j);
        _renderer = d(ye);
        _eventCleanups;
        _initialized;
        _fallbackTimer;
        _positionIndex;
        _dirChangeSubscription = F.EMPTY;
        _position;
        _previousPosition;
        _onCentering = new p;
        _beforeCentering = new p;
        _afterLeavingCenter = new p;
        _onCentered = new p(!0);
        _portalHost;
        _contentElement;
        _content;
        animationDuration = "500ms";
        preserveContent = !1;
        tabBackgroundColor = "transparent";
        tabPadding = "20px 20px 20px 20px";
        set position(e) { this._positionIndex = e, this._computePositionAnimationState(); }
        constructor() { if (this._dir) {
            let e = d(E);
            this._dirChangeSubscription = this._dir.change.subscribe(i => { this._computePositionAnimationState(i), e.markForCheck(); });
        } }
        ngOnInit() { this._bindTransitionEvents(), this._position === "center" && (this._setActiveClass(!0), Oe(() => this._onCentering.emit(this._elementRef.nativeElement.clientHeight), { injector: this._injector })), this._initialized = !0; }
        ngOnDestroy() { clearTimeout(this._fallbackTimer), this._eventCleanups?.forEach(e => e()), this._dirChangeSubscription.unsubscribe(); }
        _bindTransitionEvents() { this._ngZone.runOutsideAngular(() => { let e = this._elementRef.nativeElement, i = o => { o.target === this._contentElement?.nativeElement && (this._elementRef.nativeElement.classList.remove("tab-body-animating"), o.type === "transitionend" && this._transitionDone()); }; this._eventCleanups = [this._renderer.listen(e, "transitionstart", o => { o.target === this._contentElement?.nativeElement && (this._elementRef.nativeElement.classList.add("tab-body-animating"), this._transitionStarted()); }), this._renderer.listen(e, "transitionend", i), this._renderer.listen(e, "transitioncancel", i)]; }); }
        _transitionStarted() { clearTimeout(this._fallbackTimer); let e = this._position === "center"; this._beforeCentering.emit(e), e && this._onCentering.emit(this._elementRef.nativeElement.clientHeight); }
        _transitionDone() { this._position === "center" ? this._onCentered.emit() : this._previousPosition === "center" && this._afterLeavingCenter.emit(); }
        _setActiveClass(e) { this._elementRef.nativeElement.classList.toggle("mdc-tab-body-active", e); }
        _getLayoutDirection() { return this._dir && this._dir.value === "rtl" ? "rtl" : "ltr"; }
        _isCenterPosition() { return this._positionIndex === 0; }
        _computePositionAnimationState(e = this._getLayoutDirection()) { this._previousPosition = this._position, this._positionIndex < 0 ? this._position = e == "ltr" ? "left" : "right" : this._positionIndex > 0 ? this._position = e == "ltr" ? "right" : "left" : this._position = "center", this._animationsDisabled() ? this._simulateTransitionEvents() : this._initialized && (this._position === "center" || this._previousPosition === "center") && (clearTimeout(this._fallbackTimer), this._fallbackTimer = this._ngZone.runOutsideAngular(() => setTimeout(() => this._simulateTransitionEvents(), 100))); }
        _simulateTransitionEvents() { this._transitionStarted(), Oe(() => this._transitionDone(), { injector: this._injector }); }
        _animationsDisabled() { return this.animationDuration === "0ms" || this.animationDuration === "0s"; }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-tab-body"]], viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(xr, 5)(pc, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._portalHost = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._contentElement = r.first);
            } }, hostAttrs: [1, "mdc-tab-body"], hostVars: 7, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("inert", o._position === "center" ? null : ""), t.\u0275\u0275styleProp("padding", o.tabPadding), t.\u0275\u0275classProp("mdc-tab-body-bg-white", o.tabBackgroundColor === "white")("mdc-tab-body-bg-grey", o.tabBackgroundColor === "grey")); }, inputs: { _content: [0, "content", "_content"], animationDuration: "animationDuration", preserveContent: "preserveContent", tabBackgroundColor: "tabBackgroundColor", tabPadding: "tabPadding", position: "position" }, outputs: { _onCentering: "_onCentering", _beforeCentering: "_beforeCentering", _onCentered: "_onCentered" }, decls: 3, vars: 6, consts: [["content", ""], ["cdkScrollable", "", 1, "mdc-tab-body-content"], ["mdTabBodyHost", ""]], template: function (i, o) { i & 1 && (t.\u0275\u0275elementStart(0, "div", 1, 0), t.\u0275\u0275template(2, uc, 0, 0, "ng-template", 2), t.\u0275\u0275elementEnd()), i & 2 && t.\u0275\u0275classProp("tab-body-content-left", o._position === "left")("tab-body-content-right", o._position === "right")("tab-body-content-can-animate", o._position === "center" || o._previousPosition === "center"); }, dependencies: [xr, tl], styles: [`.mdc-tab-body{inset:0;position:absolute;display:block;overflow:hidden;outline:0;flex-basis:100%}.mdc-tab-body.mdc-tab-body-active{position:relative;overflow-x:hidden;overflow-y:auto;z-index:1;flex-grow:1}.mdc-tab-group.mdc-tab-group-dynamic-height .mdc-tab-body.mdc-tab-body-active{overflow-y:hidden}.mdc-tab-body-content{display:flex;flex-direction:column;color:var(--%NS%md-tabs-body-color, var(--%NS%md-color-text, inherit));height:100%;transform:none;visibility:hidden;overflow-wrap:anywhere}.tab-body-animating>.mdc-tab-body-content,.mdc-tab-body-active>.mdc-tab-body-content{visibility:visible}.tab-body-animating>.mdc-tab-body-content{min-height:1px}.mdc-tab-group-dynamic-height .mdc-tab-body-content{overflow:hidden}.tab-body-content-can-animate{transition:transform .2s 1ms cubic-bezier(.35,0,.25,1)}.mdc-tab-body-wrapper._animation-noopable .tab-body-content-can-animate{transition:none}.tab-body-content-left{transform:translate3d(-100%,0,0)}.tab-body-content-right{transform:translate3d(100%,0,0)}.mdc-tab-body-bg-white{background-color:var(--%NS%md-tabs-body-background, #FFFFFF)}.mdc-tab-body-bg-grey{background-color:var(--%NS%md-tabs-body-muted-background, #F3F3F3)}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})(), cg = new k("TABS_CONFIG"), xy = new k("TabContent"), mg = (() => { class n {
    template = d(H);
    constructor() { }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdTabContent", ""]] });
} return n; })(), hg = new k("MDTabLabel"), Ia = new k("MD_TAB"), pg = (() => { class n extends Kd {
    _closestTab = d(Ia, { optional: !0 });
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "md-tab-label", ""], ["", "mdTabLabel", ""]], features: [t.\u0275\u0275ProvidersFeature([{ provide: hg, useExisting: n }]), t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), Na = new k("TAB_GROUP"), ug = (() => { class n {
    _viewContainerRef = d(ge);
    _closestTabGroup = d(Na, { optional: !0 });
    disabled = !1;
    _explicitContent;
    _implicitContent;
    textLabel = "";
    ariaLabel;
    ariaLabelledby;
    labelClass;
    bodyClass;
    id = null;
    get templateLabel() { return this._templateLabel; }
    set templateLabel(e) { this._setTemplateLabelInput(e); }
    _templateLabel;
    _contentPortal = null;
    get content() { return this._contentPortal; }
    _stateChanges = new D;
    position = null;
    origin = null;
    isActive = !1;
    constructor() { }
    ngOnChanges(e) { (e.hasOwnProperty("textLabel") || e.hasOwnProperty("disabled")) && this._stateChanges.next(); }
    ngOnDestroy() { this._stateChanges.complete(); }
    ngOnInit() { this._contentPortal = new xe(this._explicitContent || this._implicitContent, this._viewContainerRef); }
    _setTemplateLabelInput(e) { e && e._closestTab === this && (this._templateLabel = e); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-tab"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, mg, 7, H)(r, pg, 5), i & 2) {
            let s;
            t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._explicitContent = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.templateLabel = s.first);
        } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(H, 7), i & 2) {
            let r;
            t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._implicitContent = r.first);
        } }, inputs: { disabled: [2, "disabled", "disabled", m], textLabel: [0, "label", "textLabel"], ariaLabel: [0, "aria-label", "ariaLabel"], ariaLabelledby: [0, "aria-labelledby", "ariaLabelledby"], labelClass: "labelClass", bodyClass: "bodyClass", id: "id" }, exportAs: ["mdTab"], features: [t.\u0275\u0275ProvidersFeature([{ provide: Ia, useExisting: n }]), t.\u0275\u0275NgOnChangesFeature], ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domTemplate(0, gc, 1, 0, "ng-template")); }, encapsulation: 2, changeDetection: 1 });
} return n; })(), Bi = "mdc-tab-indicator--active", kr = "mdc-tab-indicator--no-transition", Yt = class {
    _items;
    _currentItem;
    constructor(a) { this._items = a; }
    hide() { this._items.forEach(a => a.deactivateInkBar()), this._currentItem = void 0; }
    alignToElement(a) { let e = this._items.find(o => o.elementRef.nativeElement === a), i = this._currentItem; if (e !== i && (i?.deactivateInkBar(), e)) {
        let o = i?.elementRef.nativeElement.getBoundingClientRect?.();
        e.activateInkBar(o), this._currentItem = e;
    } }
}, Pa = (() => { class n {
    _elementRef = d(x);
    _inkBarElement;
    _inkBarContentElement;
    _fitToContent = !1;
    get fitInkBarToContent() { return this._fitToContent; }
    set fitInkBarToContent(e) { this._fitToContent !== e && (this._fitToContent = e, this._inkBarElement && this._appendInkBarElement()); }
    activateInkBar(e) { let i = this._elementRef.nativeElement; if (!e || !i.getBoundingClientRect || !this._inkBarContentElement) {
        i.classList.add(Bi);
        return;
    } let o = i.getBoundingClientRect(), r = e.width / o.width, s = e.left - o.left; i.classList.add(kr), this._inkBarContentElement.style.setProperty("transform", `translateX(${s}px) scaleX(${r})`), i.getBoundingClientRect(), i.classList.remove(kr), i.classList.add(Bi), this._inkBarContentElement.style.setProperty("transform", ""); }
    deactivateInkBar() { this._elementRef.nativeElement.classList.remove(Bi); }
    ngOnInit() { this._createInkBarElement(); }
    ngOnDestroy() { this._inkBarElement?.remove(), this._inkBarElement = this._inkBarContentElement = null; }
    _createInkBarElement() { let e = this._elementRef.nativeElement.ownerDocument || document, i = this._inkBarElement = e.createElement("span"), o = this._inkBarContentElement = e.createElement("span"); i.className = "mdc-tab-indicator", o.className = "mdc-tab-indicator__content mdc-tab-indicator__content--underline", i.appendChild(this._inkBarContentElement), this._appendInkBarElement(); }
    _appendInkBarElement() { (this._fitToContent ? this._elementRef.nativeElement.querySelector(".mdc-tab__content") : this._elementRef.nativeElement).appendChild(this._inkBarElement); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, inputs: { fitInkBarToContent: [2, "fitInkBarToContent", "fitInkBarToContent", m] } });
} return n; })();
function gg() { return a => ({ left: a ? (a.offsetLeft || 0) + "px" : "0", width: a ? (a.offsetWidth || 0) + "px" : "0" }); }
var ky = new k("InkBarPositioner", { providedIn: "root", factory: gg }), Oa = (() => { class n extends Pa {
    elementRef = d(x);
    disabled = !1;
    overflowLabel = "";
    get overflowTemplate() { return typeof this.overflowLabel == "string" ? null : this.overflowLabel; }
    focus() { this.elementRef.nativeElement.focus(); }
    getOffsetLeft() { return this.elementRef.nativeElement.offsetLeft; }
    getOffsetWidth() { return this.elementRef.nativeElement.offsetWidth; }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdTabLabelWrapper", ""]], hostVars: 3, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("aria-disabled", !!o.disabled), t.\u0275\u0275classProp("mdc-tab-disabled", o.disabled)); }, inputs: { disabled: [2, "disabled", "disabled", m], overflowLabel: "overflowLabel" }, features: [t.\u0275\u0275InheritDefinitionFeature] });
} return n; })();
function fg(n, a, e, i) { if (n.reduce((c, h) => c + h, 0) <= a + 1)
    return []; let o = Math.max(0, a - e), r = new Set, s = i >= 0 && i < n.length, l = s ? Math.min(n[i], o) : 0; s && r.add(i); for (let c = 0; c < n.length; c++) {
    if (c === i)
        continue;
    let h = Math.min(n[c], o);
    if (l + h > o + 1)
        break;
    r.add(c), l += h;
} return n.map((c, h) => h).filter(c => !r.has(c)); }
var bg = (() => {
    class n extends Ea {
        overflowMode = "scroll";
        overflowLabel = "More tabs";
        overflowTrigger;
        moreButton;
        hiddenIndices = B([]);
        overflowResize;
        overflowFrame;
        pendingOverflowIndex;
        previousMode = "";
        overflowDestroyed = !1;
        isOverflowHidden(e) { return this.overflowMode === "menu" && !this.disablePagination && this.hiddenIndices().includes(e); }
        ngAfterViewInit() { super.ngAfterViewInit(), typeof ResizeObserver < "u" && (this.overflowResize = new ResizeObserver(() => { this.overflowMode === "menu" && this.updatePagination(); }), this.overflowResize.observe(this._tabListContainer.nativeElement)); }
        ngAfterContentChecked() { super.ngAfterContentChecked(); let e = `${this.overflowMode}:${this.disablePagination}`; e !== this.previousMode && (this.previousMode = e, this.updatePagination(), this.scheduleOverflow()); }
        _checkPaginationEnabled() { if (this.overflowMode !== "menu" || this.disablePagination) {
            super._checkPaginationEnabled();
            return;
        } let e = this._elementRef.nativeElement.clientWidth, { widths: i, gap: o } = this.labelMeasurements(); this._showPaginationControls = i.reduce((r, s) => r + s, 0) > e + o + 1, this._changeDetectorRef.markForCheck(); }
        _scrollToLabel(e) { this.overflowMode !== "menu" || this.disablePagination ? super._scrollToLabel(e) : this.scheduleOverflow(e); }
        _updateTabScrollPosition() { this.overflowMode === "menu" && !this.disablePagination ? this._tabList.nativeElement.style.transform = "" : super._updateTabScrollPosition(), this.scheduleOverflow(); }
        _setTabFocus(e) { this.overflowMode === "menu" && !this.disablePagination && this.measureOverflow(e), super._setTabFocus(e); }
        restoreOverflowFocus() { this._elementRef.nativeElement.ownerDocument.activeElement?.closest(".md-mdc-menu-panel") && this.moreButton?.nativeElement.focus(); }
        selectOverflow(e) { this._items.get(e)?.disabled || (this.overflowTrigger?.closeMenu(), this.selectFocusedIndex.emit(e), this.focusIndex = e, this._setTabFocus(e)); }
        labelMeasurements() { let e = this._elementRef.nativeElement.ownerDocument.defaultView, i = parseFloat(e?.getComputedStyle(this._tabListInner.nativeElement).columnGap || "0") || 0; return { gap: i, widths: (this._items?.toArray() ?? []).map(o => { let r = o.elementRef.nativeElement, s = e?.getComputedStyle(r); return r.getBoundingClientRect().width + i + (parseFloat(s?.marginInlineStart || "0") || 0) + (parseFloat(s?.marginInlineEnd || "0") || 0); }) }; }
        scheduleOverflow(e) { e !== void 0 && (this.pendingOverflowIndex = e); let i = this._elementRef.nativeElement.ownerDocument.defaultView; !i || this.overflowDestroyed || this.overflowFrame !== void 0 || (this.overflowFrame = i.requestAnimationFrame(() => { this.overflowFrame = void 0, this.measureOverflow(this.pendingOverflowIndex ?? this.selectedIndex), this.pendingOverflowIndex = void 0; })); }
        measureOverflow(e = this.selectedIndex) { if (!this._items || !this._tabListContainer)
            return; let i = this._items.toArray(), o = this.overflowMode === "menu" && !this.disablePagination, r = this._elementRef.nativeElement.clientWidth, { widths: s, gap: l } = this.labelMeasurements(), c = o ? fg(s, r + l, 44, e) : []; if (o && (this._showPaginationControls = c.length > 0, this._elementRef.nativeElement.style.setProperty("--md-tab-label-max-width", `${Math.max(0, r - (c.length ? 44 : 0))}px`)), i.forEach((h, g) => { h.elementRef.nativeElement.classList.toggle("md-tab-overflow-hidden", c.includes(g)); }), c.join(",") !== this.hiddenIndices().join(",") && (this.hiddenIndices.set(c), this._changeDetectorRef.markForCheck()), this._alignInkBarToSelectedTab(), !c.length) {
            let h = this._elementRef.nativeElement.ownerDocument.activeElement === this.moreButton?.nativeElement;
            this.overflowTrigger?.closeMenu(), h && this._items.get(this.selectedIndex)?.focus();
        } }
        ngOnDestroy() { this.overflowDestroyed = !0, this.overflowResize?.disconnect(), this.overflowFrame !== void 0 && this._elementRef.nativeElement.ownerDocument.defaultView?.cancelAnimationFrame(this.overflowFrame), super.ngOnDestroy(); }
        _items;
        _tabListContainer;
        _tabList;
        _tabListInner;
        _nextPaginator;
        _previousPaginator;
        _inkBar;
        ariaLabel;
        ariaLabelledby;
        ngAfterContentInit() { this._inkBar = new Yt(this._items), super.ngAfterContentInit(); }
        _itemSelected(e) { e.preventDefault(); }
        static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-tab-header"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Oa, 4), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._items = s);
            } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(fc, 5)(bc, 5)(aa, 7)(sa, 7)(da, 7)(zn, 5)(Vn, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.overflowTrigger = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.moreButton = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._tabListContainer = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._tabList = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._tabListInner = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._nextPaginator = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._previousPaginator = r.first);
            } }, hostAttrs: [1, "mdc-tab-header"], hostVars: 6, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("mdc-tab-header-pagination-controls-enabled", o._showPaginationControls)("md-tab-header-menu", o.overflowMode === "menu" && !o.disablePagination)("mdc-tab-header-rtl", o._getLayoutDirection() == "rtl"); }, inputs: { overflowMode: "overflowMode", overflowLabel: "overflowLabel", ariaLabel: [0, "aria-label", "ariaLabel"], ariaLabelledby: [0, "aria-labelledby", "ariaLabelledby"] }, features: [t.\u0275\u0275InheritDefinitionFeature], ngContentSelectors: T, decls: 22, vars: 12, consts: [["previousPaginator", ""], ["tabListContainer", ""], ["tabList", ""], ["tabListInner", ""], ["nextPaginator", ""], ["moreButton", "", "overflowTrigger", "mdMenuTrigger"], ["overflowMenu", "mdMenu"], [1, "mdc-tab-header-pagination", "mdc-tab-header-pagination-before", 3, "click", "mousedown", "touchend"], [1, "mdc-tab-header-pagination-chevron"], [1, "mdc-tab-label-container", 3, "keydown"], ["role", "tablist", 1, "mdc-tab-list", 3, "cdkObserveContent"], [1, "mdc-tab-labels"], [1, "mdc-tab-header-pagination", "mdc-tab-header-pagination-after", 3, "mousedown", "click", "touchend"], ["type", "button", 1, "md-tab-overflow-trigger", 3, "menuClosed", "mdMenuTriggerFor", "mdMenuTriggerRestoreFocus"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", "focusable", "false", 2, "display", "inline-block", "vertical-align", "middle", "flex-shrink", "0"], ["d", "M5 12h.01M12 12h.01M19 12h.01"], ["xPosition", "before"], ["md-menu-item", "", "role", "menuitemradio", 3, "disabled"], ["md-menu-item", "", "role", "menuitemradio", 3, "click", "disabled"], [3, "ngTemplateOutlet"]], template: function (i, o) { if (i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275elementStart(0, "div", 7, 0), t.\u0275\u0275listener("click", function () { return o._handlePaginatorClick("before"); })("mousedown", function (s) { return o._handlePaginatorPress("before", s); })("touchend", function () { return o._stopInterval(); }), t.\u0275\u0275element(2, "div", 8), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(3, "div", 9, 1), t.\u0275\u0275listener("keydown", function (s) { return o._handleKeydown(s); }), t.\u0275\u0275elementStart(5, "div", 10, 2), t.\u0275\u0275listener("cdkObserveContent", function () { return o._onContentChanges(); }), t.\u0275\u0275elementStart(7, "div", 11, 3), t.\u0275\u0275projection(9), t.\u0275\u0275elementEnd()()(), t.\u0275\u0275elementStart(10, "div", 12, 4), t.\u0275\u0275listener("mousedown", function (s) { return o._handlePaginatorPress("after", s); })("click", function () { return o._handlePaginatorClick("after"); })("touchend", function () { return o._stopInterval(); }), t.\u0275\u0275element(12, "div", 8), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(13, "button", 13, 5), t.\u0275\u0275listener("menuClosed", function () { return o.restoreOverflowFocus(); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(16, "svg", 14), t.\u0275\u0275element(17, "path", 15), t.\u0275\u0275elementEnd()(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275elementStart(18, "md-menu", 16, 6), t.\u0275\u0275repeaterCreate(20, xc, 1, 1, null, null, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275elementEnd()), i & 2) {
                let r = t.\u0275\u0275reference(19);
                t.\u0275\u0275classProp("mdc-tab-header-pagination-disabled", o._disableScrollBefore), t.\u0275\u0275advance(5), t.\u0275\u0275attribute("aria-label", o.ariaLabel || null)("aria-labelledby", o.ariaLabelledby || null), t.\u0275\u0275advance(5), t.\u0275\u0275classProp("mdc-tab-header-pagination-disabled", o._disableScrollAfter), t.\u0275\u0275advance(3), t.\u0275\u0275classProp("md-tab-overflow-active", o.isOverflowHidden(o.selectedIndex)), t.\u0275\u0275property("mdMenuTriggerFor", r)("mdMenuTriggerRestoreFocus", !1), t.\u0275\u0275attribute("aria-label", o.overflowLabel)("title", o.overflowLabel), t.\u0275\u0275advance(7), t.\u0275\u0275repeater(o.hiddenIndices());
            } }, dependencies: [na, bt, Ye, pt, Sa], styles: [`.mdc-tab-header{display:flex;overflow:hidden;position:relative;flex-shrink:0}.mdc-tab-indicator .mdc-tab-indicator__content{transition-duration:.25s}.mdc-tab-header-pagination{position:relative;display:none;justify-content:center;align-items:center;min-width:32px;cursor:pointer;z-index:2;-webkit-tap-highlight-color:transparent;touch-action:none;box-sizing:content-box;outline:0}.mdc-tab-header-pagination::-moz-focus-inner{border:0}.mdc-tab-header-pagination-controls-enabled .mdc-tab-header-pagination{display:flex}.mdc-tab-header-pagination-before,.mdc-tab-header-rtl .mdc-tab-header-pagination-after{padding-left:4px}.mdc-tab-header-pagination-before .mdc-tab-header-pagination-chevron,.mdc-tab-header-rtl .mdc-tab-header-pagination-after .mdc-tab-header-pagination-chevron{transform:rotate(-135deg)}.mdc-tab-header-rtl .mdc-tab-header-pagination-before,.mdc-tab-header-pagination-after{padding-right:4px}.mdc-tab-header-rtl .mdc-tab-header-pagination-before .mdc-tab-header-pagination-chevron,.mdc-tab-header-pagination-after .mdc-tab-header-pagination-chevron{transform:rotate(45deg)}.mdc-tab-header-pagination-chevron{border-style:solid;border-width:2px 2px 0 0;height:8px;width:8px;border-color:var(--%NS%md-tabs-pagination-chevron-color, var(--%NS%md-tabs-label-color, #201a1b))}.mdc-tab-header-pagination-disabled{box-shadow:none;cursor:default;pointer-events:none}.mdc-tab-header-pagination-disabled .mdc-tab-header-pagination-chevron{opacity:.4}.mdc-tab-list{flex-grow:1;position:relative;transition:transform .5s cubic-bezier(.35,0,.25,1)}.animation-noopable .mdc-tab-list{transition:none}.mdc-tab-label-container{display:flex;flex-grow:1;overflow:hidden;z-index:1;border-bottom-style:solid;border-bottom-width:1px;border-bottom-color:var(--%NS%md-tabs-header-border-color, #f3dde1)}.mdc-tab-group-inverted-header .mdc-tab-label-container{border-bottom:none;border-top-style:solid;border-top-width:1px;border-top-color:var(--%NS%md-tabs-header-border-color, #f3dde1)}.mdc-tab-labels{display:flex;flex:1 0 auto}[align-tabs=center]>.mdc-tab-header .mdc-tab-labels{justify-content:center}[align-tabs=end]>.mdc-tab-header .mdc-tab-labels{justify-content:flex-end}.cdk-drop-list .mdc-tab-labels,.mdc-tab-labels.cdk-drop-list{min-height:48px}.mdc-tab:before{margin:5px}@media(forced-colors:active){.mdc-tab[aria-disabled=true]{color:GrayText}}.md-tab-overflow-trigger,.md-tab-header-menu .mdc-tab-header-pagination{display:none}.md-tab-header-menu .mdc-tab-label-container{min-width:0}.md-tab-header-menu .mdc-tab-list{transition:none}.md-tab-header-menu .mdc-tab-labels{justify-content:flex-start}.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy){flex:0 0 auto;min-width:min(90px,var(--%NS%md-tab-label-max-width, 90px));max-width:var(--%NS%md-tab-label-max-width, none)}.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy) .mdc-tab__content{min-width:0}.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy) .mdc-tab__text-label{overflow:hidden;text-overflow:ellipsis}.md-tab-header-menu .mdc-tab-labels>.md-tab-overflow-hidden{position:absolute;inset-inline-start:-100000px;width:max-content;visibility:hidden;pointer-events:none}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger{display:inline-flex;flex:0 0 44px;align-items:center;justify-content:center;align-self:stretch;border:0;border-bottom:1px solid var(--%NS%md-tabs-header-border-color, var(--%NS%md-color-border));background:var(--%NS%md-tabs-overflow-background, var(--%NS%md-color-surface));color:var(--%NS%md-tabs-label-color, var(--%NS%md-color-text));font:inherit;font-size:24px;line-height:1;padding:0;cursor:pointer}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger:hover{background:var(--%NS%md-color-surface-hover)}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger:focus-visible{outline:2px solid var(--%NS%md-color-focus);outline-offset:-3px}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger.md-tab-overflow-active{color:var(--%NS%md-color-primary)}.mdc-tab-group.mdc-tab-group-stretch-tabs>.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy){flex-grow:0}.mdc-tab-group-inverted-header>.md-tab-header-menu .md-tab-overflow-trigger{border-bottom:0;border-top:1px solid var(--%NS%md-tabs-header-border-color, var(--%NS%md-color-border))}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})(), _g = (() => {
    class n {
        _elementRef = d(x);
        _changeDetectorRef = d(E);
        _ngZone = d(K);
        _tabsSubscription = F.EMPTY;
        _tabLabelSubscription = F.EMPTY;
        _tabBodySubscription = F.EMPTY;
        _allTabs;
        _tabBodies;
        _tabBodyWrapper;
        _tabHeader;
        _tabs = new _t;
        color = "primary";
        _indexToSelect = 0;
        _lastFocusedTabIndex = null;
        _tabBodyWrapperHeight = 0;
        overflowMode = "scroll";
        overflowLabel = "More tabs";
        isLegacyMode = !1;
        hideInkBar;
        legacySize = "medium";
        tabBackgroundColor = "transparent";
        tabPadding = "20px 20px 20px 20px";
        get legacySizeClass() { return `legacy-${this.legacySize}`; }
        c(e) { return console.log(e), e; }
        get fitInkBarToContent() { return this._fitInkBarToContent; }
        set fitInkBarToContent(e) { this._fitInkBarToContent = e, this._changeDetectorRef.markForCheck(); }
        _fitInkBarToContent = !1;
        stretchTabs = !0;
        alignTabs = null;
        dynamicHeight = !1;
        get selectedIndex() { return this._selectedIndex; }
        set selectedIndex(e) { this._indexToSelect = isNaN(e) ? null : e; }
        _selectedIndex = null;
        headerPosition = "above";
        animationDisabled = !1;
        get animationDuration() { return this._animationDuration; }
        set animationDuration(e) { let i = e + ""; this._animationDuration = /^\d+$/.test(i) ? e + "ms" : i; }
        _animationDuration;
        get contentTabIndex() { return this._contentTabIndex; }
        set contentTabIndex(e) { this._contentTabIndex = isNaN(e) ? null : e; }
        _contentTabIndex;
        disablePagination = !1;
        disableRipple = !1;
        preserveContent = !1;
        ariaLabel;
        ariaLabelledby;
        selectedIndexChange = new p;
        focusChange = new p;
        animationDone = new p;
        selectedTabChange = new p(!0);
        _groupId;
        _isServer = !d(mt).isBrowser;
        constructor() { let e = d(cg, { optional: !0 }); this._groupId = d(W).getId("tab-group-"), this.animationDuration = e && e.animationDuration ? e.animationDuration : "500ms", this.disablePagination = e && e.disablePagination != null ? e.disablePagination : !1, this.dynamicHeight = e && e.dynamicHeight != null ? e.dynamicHeight : !1, e?.contentTabIndex != null && (this.contentTabIndex = e.contentTabIndex), this.preserveContent = !!e?.preserveContent, this.fitInkBarToContent = e && e.fitInkBarToContent != null ? e.fitInkBarToContent : !1, this.stretchTabs = e && e.stretchTabs != null ? e.stretchTabs : !0, this.alignTabs = e && e.alignTabs != null ? e.alignTabs : null; }
        ngAfterContentChecked() { let e = this._indexToSelect = this._clampTabIndex(this._indexToSelect); if (this._selectedIndex != e) {
            let i = this._selectedIndex == null;
            if (!i) {
                this.selectedTabChange.emit(this._createChangeEvent(e));
                let o = this._tabBodyWrapper.nativeElement;
                o.style.minHeight = o.clientHeight + "px";
            }
            Promise.resolve().then(() => { this._tabs.forEach((o, r) => o.isActive = r === e), i || (this.selectedIndexChange.emit(e), this._tabBodyWrapper.nativeElement.style.minHeight = ""); });
        } this._tabs.forEach((i, o) => { i.position = o - e, this._selectedIndex != null && i.position == 0 && !i.origin && (i.origin = e - this._selectedIndex); }), this._selectedIndex !== e && (this._selectedIndex = e, this._lastFocusedTabIndex = null, this._changeDetectorRef.markForCheck()); }
        ngAfterContentInit() { this._subscribeToAllTabChanges(), this._subscribeToTabLabels(), this._tabsSubscription = this._tabs.changes.subscribe(() => { let e = this._clampTabIndex(this._indexToSelect); if (e === this._selectedIndex) {
            let i = this._tabs.toArray(), o;
            for (let r = 0; r < i.length; r++)
                if (i[r].isActive) {
                    this._indexToSelect = this._selectedIndex = r, this._lastFocusedTabIndex = null, o = i[r];
                    break;
                }
            !o && i[e] && Promise.resolve().then(() => { i[e].isActive = !0, this.selectedTabChange.emit(this._createChangeEvent(e)); });
        } this._changeDetectorRef.markForCheck(); }); }
        ngAfterViewInit() { this._tabBodySubscription = this._tabBodies.changes.subscribe(() => this._bodyCentered(!0)); }
        _subscribeToAllTabChanges() { this._allTabs.changes.pipe(z(this._allTabs)).subscribe(e => { this._tabs.reset(e.filter(i => i._closestTabGroup === this || !i._closestTabGroup)), this._tabs.notifyOnChanges(); }); }
        ngOnDestroy() { this._tabs.destroy(), this._tabsSubscription.unsubscribe(), this._tabLabelSubscription.unsubscribe(), this._tabBodySubscription.unsubscribe(); }
        realignInkBar() { this._tabHeader && this._tabHeader._alignInkBarToSelectedTab(); }
        updatePagination() { this._tabHeader && this._tabHeader.updatePagination(); }
        focusTab(e) { let i = this._tabHeader; i && (i.focusIndex = e); }
        _focusChanged(e) { this._lastFocusedTabIndex = e, this.focusChange.emit(this._createChangeEvent(e)); }
        _createChangeEvent(e) { let i = new tn; return i.index = e, this._tabs && this._tabs.length && (i.tab = this._tabs.toArray()[e]), i; }
        _subscribeToTabLabels() { this._tabLabelSubscription && this._tabLabelSubscription.unsubscribe(), this._tabLabelSubscription = R(...this._tabs.map(e => e._stateChanges)).subscribe(() => this._changeDetectorRef.markForCheck()); }
        _clampTabIndex(e) { return Math.min(this._tabs.length - 1, Math.max(e || 0, 0)); }
        _getTabLabelId(e, i) { return e.id || `${this._groupId}-label-${i}`; }
        _getTabContentId(e) { return `${this._groupId}-content-${e}`; }
        _setTabBodyWrapperHeight(e) { if (!this.dynamicHeight || !this._tabBodyWrapperHeight) {
            this._tabBodyWrapperHeight = e;
            return;
        } let i = this._tabBodyWrapper.nativeElement; i.style.height = this._tabBodyWrapperHeight + "px", this._tabBodyWrapper.nativeElement.offsetHeight && (i.style.height = e + "px"); }
        _removeTabBodyWrapperHeight() { let e = this._tabBodyWrapper.nativeElement; this._tabBodyWrapperHeight = e.clientHeight, e.style.height = "", this._ngZone.run(() => this.animationDone.emit()); }
        _handleClick(e, i, o) { i.focusIndex = o, e.disabled || (this.selectedIndex = o); }
        _getTabIndex(e) { let i = this._lastFocusedTabIndex ?? this.selectedIndex; return e === i ? 0 : -1; }
        _tabFocusChanged(e, i) { e && e !== "mouse" && e !== "touch" && (this._tabHeader.focusIndex = i); }
        _bodyCentered(e) { e && this._tabBodies?.forEach((i, o) => i._setActiveClass(o === this._selectedIndex)); }
        _animationsDisabled() { return this.animationDisabled || this.animationDuration === "0" || this.animationDuration === "0ms"; }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-tab-group"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, ug, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._allTabs = s);
            } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(kc, 5)(Cc, 5)(en, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._tabBodyWrapper = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._tabHeader = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._tabBodies = r);
            } }, hostAttrs: [1, "mdc-tab-group"], hostVars: 11, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("align-tabs", o.alignTabs), t.\u0275\u0275classMap(o.color || "primary"), t.\u0275\u0275styleProp("--%NS%tab-animation-duration", o.animationDuration), t.\u0275\u0275classProp("mdc-tab-group-dynamic-height", o.dynamicHeight)("mdc-tab-group-inverted-header", o.headerPosition === "below")("mdc-tab-group-stretch-tabs", o.stretchTabs)); }, inputs: { color: "color", overflowMode: "overflowMode", overflowLabel: "overflowLabel", isLegacyMode: "isLegacyMode", hideInkBar: "hideInkBar", legacySize: "legacySize", tabBackgroundColor: "tabBackgroundColor", tabPadding: "tabPadding", fitInkBarToContent: [2, "fitInkBarToContent", "fitInkBarToContent", m], stretchTabs: [2, "md-stretch-tabs", "stretchTabs", m], alignTabs: [0, "md-align-tabs", "alignTabs"], dynamicHeight: [2, "dynamicHeight", "dynamicHeight", m], selectedIndex: [2, "selectedIndex", "selectedIndex", S], headerPosition: "headerPosition", animationDisabled: "animationDisabled", animationDuration: "animationDuration", contentTabIndex: [2, "contentTabIndex", "contentTabIndex", S], disablePagination: [2, "disablePagination", "disablePagination", m], disableRipple: [2, "disableRipple", "disableRipple", m], preserveContent: [2, "preserveContent", "preserveContent", m], ariaLabel: [0, "aria-label", "ariaLabel"], ariaLabelledby: [0, "aria-labelledby", "ariaLabelledby"] }, outputs: { selectedIndexChange: "selectedIndexChange", focusChange: "focusChange", animationDone: "animationDone", selectedTabChange: "selectedTabChange" }, exportAs: ["mdTabGroup"], features: [t.\u0275\u0275ProvidersFeature([{ provide: Na, useExisting: n }])], ngContentSelectors: T, decls: 9, vars: 17, consts: [["tabHeader", ""], ["tabBodyWrapper", ""], ["tabNode", ""], [3, "indexFocused", "selectFocusedIndex", "ngClass", "overflowMode", "overflowLabel", "hideInkBar", "selectedIndex", "disablePagination", "aria-label", "aria-labelledby"], ["role", "tab", "mdTabLabelWrapper", "", "cdkMonitorElementFocus", "", 1, "focus-indicator", 3, "ngClass", "id", "md-tab-overflow-hidden", "overflowLabel", "mdc-tab--active", "class", "disabled", "fitInkBarToContent"], [1, "mdc-tab-body-wrapper"], ["role", "tabpanel", 3, "id", "class", "content", "position", "animationDuration", "preserveContent", "tabBackgroundColor", "tabPadding"], ["role", "tab", "mdTabLabelWrapper", "", "cdkMonitorElementFocus", "", 1, "focus-indicator", 3, "click", "cdkFocusChange", "ngClass", "id", "overflowLabel", "disabled", "fitInkBarToContent"], [1, "mdc-tab__ripple"], [1, "mdc-tab__content"], [1, "mdc-tab__text-label"], [3, "cdkPortalOutlet"], ["role", "tabpanel", 3, "_onCentered", "_onCentering", "_beforeCentering", "id", "content", "position", "animationDuration", "preserveContent", "tabBackgroundColor", "tabPadding"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275elementStart(0, "md-tab-header", 3, 0), t.\u0275\u0275listener("indexFocused", function (s) { return o._focusChanged(s); })("selectFocusedIndex", function (s) { return o.selectedIndex = s; }), t.\u0275\u0275repeaterCreate(2, Ec, 7, 23, "div", 4, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275elementEnd(), t.\u0275\u0275conditionalCreate(4, Ic, 1, 0), t.\u0275\u0275elementStart(5, "div", 5, 1), t.\u0275\u0275repeaterCreate(7, Nc, 1, 12, "md-tab-body", 6, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275elementEnd()), i & 2 && (t.\u0275\u0275classMap(o.isLegacyMode ? "legacy-" + o.legacySize : ""), t.\u0275\u0275classProp("no-animations", o._animationsDisabled()), t.\u0275\u0275property("ngClass", t.\u0275\u0275pureFunction1(15, wc, o.isLegacyMode))("overflowMode", o.overflowMode)("overflowLabel", o.overflowLabel)("hideInkBar", o.hideInkBar)("selectedIndex", o.selectedIndex || 0)("disablePagination", o.disablePagination), t.\u0275\u0275ariaProperty("aria-label", o.ariaLabel)("aria-labelledby", o.ariaLabelledby), t.\u0275\u0275advance(2), t.\u0275\u0275repeater(o._tabs), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o._isServer ? 4 : -1), t.\u0275\u0275advance(), t.\u0275\u0275classProp("no-animations", o._animationsDisabled()), t.\u0275\u0275advance(2), t.\u0275\u0275repeater(o._tabs)); }, dependencies: [bg, Oa, Ad, Le, en, ae, Re.NgClass], styles: [`.mdc-tab{min-width:90px;padding:0 24px;display:flex;flex:1 0 auto;font-family:var(--%NS%md-tabs-font-family, var(--%NS%md-font-heading, "Montserrat"));justify-content:center;box-sizing:border-box;border:none;outline:none;text-align:center;white-space:nowrap;cursor:pointer;z-index:1;touch-action:manipulation}.mdc-tab__content{display:flex;align-items:center;justify-content:center;height:inherit;pointer-events:none}.mdc-tab__text-label{transition:.15s color linear;display:inline-block;line-height:1;z-index:2}.mdc-tab--active .mdc-tab__text-label{transition-delay:.1s}._animation-noopable .mdc-tab__text-label{transition:none}.mdc-tab-indicator{display:flex;position:absolute;top:0;left:0;justify-content:center;width:100%;height:100%;pointer-events:none;z-index:1}.mdc-tab-indicator__content{transition:.25s transform cubic-bezier(.4,0,.2,1);transform-origin:left;opacity:0}.no-animations .mdc-tab-indicator__content{transition:none!important;animation:none!important}.mdc-tab-indicator__content--underline{align-self:flex-end;box-sizing:border-box;width:100%;border-top-style:solid}.mdc-tab-indicator--active .mdc-tab-indicator__content{opacity:1}._animation-noopable .mdc-tab-indicator__content,.mdc-tab-indicator--no-transition .mdc-tab-indicator__content{transition:none}.mdc-tab{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-decoration:none;background:none;height:40px;font-family:var(--%NS%md-tabs-font-family, var(--%NS%md-font-heading, "Montserrat"));font-size:1rem;letter-spacing:.006rem;line-height:1.25rem;font-weight:500}.mdc-tab-group.mdc-tab-group-stretch-tabs>.mdc-tab-header .mdc-tab{flex-grow:1}.mdc-tab.mdc-tab{flex-grow:0}.mdc-tab .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106);border-top-width:2px;border-radius:0}.mdc-tab:focus .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--active .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--active .mdc-tab__ripple:before{background-color:var(--%NS%md-tabs-ripple-color, #201a1b)}.mdc-tab.mdc-tab--%NS%active:hover .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--%NS%active:hover .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106)}.mdc-tab.mdc-tab--%NS%active:focus .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--%NS%active:focus .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106)}.mdc-tab.mdc-tab-disabled{opacity:.4;pointer-events:none}.mdc-tab.mdc-tab-disabled .mdc-tab__content{pointer-events:none}.mdc-tab .mdc-tab__ripple:before{content:"";display:block;position:absolute;inset:0;opacity:0;pointer-events:none;background-color:var(--%NS%md-tabs-ripple-color, #201a1b)}.mdc-tab .mdc-tab__text-label{color:var(--%NS%md-tabs-label-color, #201a1b);display:inline-flex;align-items:center}.mdc-tab .mdc-tab__content{position:relative;pointer-events:auto}.mdc-tab:hover .mdc-tab__ripple:before{opacity:.04}.mdc-tab.cdk-program-focused .mdc-tab__ripple:before,.mdc-tab.cdk-keyboard-focused .mdc-tab__ripple:before{opacity:.12}.mdc-tab-group{display:flex;flex-direction:column;max-width:100%;flex:1}.mdc-tab-group.tabs-with-background>.mdc-tab-header .mdc-tab-header-pagination-chevron,.mdc-tab-group.tabs-with-background>.mdc-tab-header .focus-indicator:before,.mdc-tab-group.tabs-with-background>.mdc-tab-header-pagination .mdc-tab-header-pagination-chevron,.mdc-tab-group.tabs-with-background>.mdc-tab-header-pagination .focus-indicator:before{border-color:var(--%NS%md-tabs-pagination-chevron-color, var(--%NS%md-tabs-label-color, #201a1b))}.mdc-tab-group.tabs-with-background>.mdc-tab-header .mdc-tab-header-pagination-chevron,.mdc-tab-group.tabs-with-background>.mdc-tab-header-pagination .mdc-tab-header-pagination-chevron{color:transparent}.mdc-tab-group.mdc-tab-group-inverted-header{flex-direction:column-reverse}.mdc-tab-group.mdc-tab-group-inverted-header .mdc-tab-indicator__content--underline{align-self:flex-start}.mdc-tab-body-wrapper{position:relative;overflow:hidden;display:flex;height:100%}.mdc-tab-body-wrapper.no-animations .mdc-tab-body-content{transition:none!important;animation:none!important}.focus-indicator{position:relative}.tabs-legacy .mdc-tab-labels{gap:2px}.tabs-legacy .mdc-tab-label-container{border:0px}.mdc-tab-legacy{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-decoration:none;height:28px;padding:0 24px;font-size:12px;letter-spacing:.02rem;font-weight:500;font-family:var(--%NS%md-tabs-font-family, var(--%NS%md-font-heading, "Montserrat"));background-color:var(--%NS%md-tabs-legacy-background, #4D4D4D);border-top-left-radius:5px;border-top-right-radius:5px;cursor:pointer}.legacy-small .mdc-tab-legacy{height:28px;font-size:12px}.legacy-medium .mdc-tab-legacy{height:32px;font-size:14px}.legacy-large .mdc-tab-legacy{height:36px;font-size:16px;font-weight:600}.mdc-tab-group.mdc-tab-group-stretch-tabs>.mdc-tab-header .mdc-tab-legacy{flex-grow:1}.mdc-tab-legacy.mdc-tab{flex-grow:0}.mdc-tab-legacy .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106);border-top-width:2px;border-radius:0}.mdc-tab-legacy:hover:not(.mdc-tab--active){background-color:var(--%NS%md-tabs-legacy-hover-background, #373737)}.mdc-tab-legacy:focus .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-color, #FFFFFF)}.mdc-tab-legacy.mdc-tab--active{background-color:var(--%NS%md-tabs-legacy-active-background, #F3F3F3)}.mdc-tab-legacy.mdc-tab--active .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-active-color, #373737)}.mdc-tab-legacy.mdc-tab--active .mdc-tab__ripple:before{background-color:var(--%NS%md-tabs-ripple-color, #373737)}.mdc-tab-legacy.mdc-tab-disabled{pointer-events:none}.mdc-tab-legacy.mdc-tab-disabled .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-disabled-color, #BDBDBD)}.mdc-tab-legacy.mdc-tab-disabled .mdc-tab__content{pointer-events:none}.mdc-tab-legacy .mdc-tab__ripple:before{content:"";display:block;position:absolute;inset:0;opacity:0;pointer-events:none;background-color:var(--%NS%md-tabs-legacy-color, #FFFFFF)}.mdc-tab-legacy .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-color, #FFFFFF);display:inline-flex;align-items:center;transition:none}.mdc-tab-legacy .mdc-tab__content{position:relative;pointer-events:auto}.mdc-tab-legacy:hover .mdc-tab__ripple:before{opacity:.04}.mdc-tab-legacy.cdk-program-focused .mdc-tab__ripple:before,.mdc-tab-legacy.cdk-keyboard-focused .mdc-tab__ripple:before{opacity:.12}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})(), tn = class {
    index;
    tab;
}, vg = (() => {
    class n extends Ea {
        _focusedItem = B(null);
        get fitInkBarToContent() { return this._fitInkBarToContent.value; }
        set fitInkBarToContent(e) { this._fitInkBarToContent.next(e), this._changeDetectorRef.markForCheck(); }
        _fitInkBarToContent = new Yd(!1);
        stretchTabs = !0;
        isLegacyMode = !1;
        legacySize = "medium";
        get animationDuration() { return this._animationDuration; }
        set animationDuration(e) { let i = e + ""; this._animationDuration = /^\d+$/.test(i) ? `${e}ms` : i; }
        _animationDuration = "500ms";
        get disableRipple() { return this._disableRipple(); }
        set disableRipple(e) { this._disableRipple.set(e); }
        _disableRipple = B(!1);
        tabPanel;
        _items;
        _tabListContainer;
        _tabList;
        _tabListInner;
        _nextPaginator;
        _previousPaginator;
        _inkBar;
        _itemSelected() { }
        ngAfterContentInit() { this._inkBar = new Yt(this._items), this._items.changes.pipe(z(null), O(this._destroyed)).subscribe(() => this.updateActiveLink()), super.ngAfterContentInit(), this._keyManager.change.pipe(z(null), O(this._destroyed)).subscribe(() => this._focusedItem.set(this._keyManager?.activeItem || null)); }
        updateActiveLink() { if (!this._items)
            return; let e = this._items.toArray(); for (let i = 0; i < e.length; i++)
            if (e[i].active) {
                this.selectedIndex = i, this.tabPanel && (this.tabPanel._activeTabId = e[i].id), this._focusedItem.set(e[i]), this._changeDetectorRef.markForCheck();
                return;
            } this.selectedIndex = -1; }
        _getHostRole() { return this.tabPanel ? "tablist" : this._elementRef.nativeElement.getAttribute("role"); }
        _getRole() { return this.tabPanel ? "presentation" : null; }
        _hasFocus(e) { return this._keyManager?.activeItem === e; }
        static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["", "md-tab-nav-bar", ""]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, yg, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._items = s);
            } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(aa, 7)(sa, 7)(da, 7)(zn, 5)(Vn, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._tabListContainer = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._tabList = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._tabListInner = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._nextPaginator = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._previousPaginator = r.first);
            } }, hostAttrs: [1, "mdc-tab-nav-bar", "mdc-tab-header"], hostVars: 17, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("role", o._getHostRole()), t.\u0275\u0275styleProp("--%NS%tab-animation-duration", o.animationDuration), t.\u0275\u0275classProp("mdc-tab-header-pagination-controls-enabled", o._showPaginationControls)("mdc-tab-header-rtl", o._getLayoutDirection() == "rtl")("mdc-tab-nav-bar-stretch-tabs", o.stretchTabs)("tabs-legacy", o.isLegacyMode)("legacy-small", o.isLegacyMode && o.legacySize === "small")("legacy-medium", o.isLegacyMode && o.legacySize === "medium")("legacy-large", o.isLegacyMode && o.legacySize === "large")); }, inputs: { fitInkBarToContent: [2, "fitInkBarToContent", "fitInkBarToContent", m], stretchTabs: [2, "md-stretch-tabs", "stretchTabs", m], isLegacyMode: [2, "isLegacyMode", "isLegacyMode", m], legacySize: "legacySize", animationDuration: "animationDuration", disableRipple: [2, "disableRipple", "disableRipple", m], tabPanel: "tabPanel" }, exportAs: ["mdTabNavBar", "mdTabNav"], features: [t.\u0275\u0275InheritDefinitionFeature], ngContentSelectors: T, decls: 13, vars: 5, consts: [["previousPaginator", ""], ["tabListContainer", ""], ["tabList", ""], ["tabListInner", ""], ["nextPaginator", ""], [1, "mdc-tab-header-pagination", "mdc-tab-header-pagination-before", 3, "click", "mousedown", "touchend"], [1, "mdc-tab-header-pagination-chevron"], [1, "mdc-tab-label-container", 3, "keydown"], [1, "mdc-tab-list", 3, "cdkObserveContent"], [1, "mdc-tab-labels"], [1, "mdc-tab-header-pagination", "mdc-tab-header-pagination-after", 3, "mousedown", "click", "touchend"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275elementStart(0, "div", 5, 0), t.\u0275\u0275listener("click", function () { return o._handlePaginatorClick("before"); })("mousedown", function (s) { return o._handlePaginatorPress("before", s); })("touchend", function () { return o._stopInterval(); }), t.\u0275\u0275element(2, "div", 6), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(3, "div", 7, 1), t.\u0275\u0275listener("keydown", function (s) { return o._handleKeydown(s); }), t.\u0275\u0275elementStart(5, "div", 8, 2), t.\u0275\u0275listener("cdkObserveContent", function () { return o._onContentChanges(); }), t.\u0275\u0275elementStart(7, "div", 9, 3), t.\u0275\u0275projection(9), t.\u0275\u0275elementEnd()()(), t.\u0275\u0275elementStart(10, "div", 10, 4), t.\u0275\u0275listener("mousedown", function (s) { return o._handlePaginatorPress("after", s); })("click", function () { return o._handlePaginatorClick("after"); })("touchend", function () { return o._stopInterval(); }), t.\u0275\u0275element(12, "div", 6), t.\u0275\u0275elementEnd()), i & 2 && (t.\u0275\u0275classProp("mdc-tab-header-pagination-disabled", o._disableScrollBefore), t.\u0275\u0275advance(5), t.\u0275\u0275attribute("role", o._getRole()), t.\u0275\u0275advance(5), t.\u0275\u0275classProp("mdc-tab-header-pagination-disabled", o._disableScrollAfter)); }, dependencies: [na], styles: [`.mdc-tab-header{display:flex;overflow:hidden;position:relative;flex-shrink:0}.mdc-tab-indicator .mdc-tab-indicator__content{transition-duration:.25s}.mdc-tab-header-pagination{position:relative;display:none;justify-content:center;align-items:center;min-width:32px;cursor:pointer;z-index:2;-webkit-tap-highlight-color:transparent;touch-action:none;box-sizing:content-box;outline:0}.mdc-tab-header-pagination::-moz-focus-inner{border:0}.mdc-tab-header-pagination-controls-enabled .mdc-tab-header-pagination{display:flex}.mdc-tab-header-pagination-before,.mdc-tab-header-rtl .mdc-tab-header-pagination-after{padding-left:4px}.mdc-tab-header-pagination-before .mdc-tab-header-pagination-chevron,.mdc-tab-header-rtl .mdc-tab-header-pagination-after .mdc-tab-header-pagination-chevron{transform:rotate(-135deg)}.mdc-tab-header-rtl .mdc-tab-header-pagination-before,.mdc-tab-header-pagination-after{padding-right:4px}.mdc-tab-header-rtl .mdc-tab-header-pagination-before .mdc-tab-header-pagination-chevron,.mdc-tab-header-pagination-after .mdc-tab-header-pagination-chevron{transform:rotate(45deg)}.mdc-tab-header-pagination-chevron{border-style:solid;border-width:2px 2px 0 0;height:8px;width:8px;border-color:var(--%NS%md-tabs-pagination-chevron-color, var(--%NS%md-tabs-label-color, #201a1b))}.mdc-tab-header-pagination-disabled{box-shadow:none;cursor:default;pointer-events:none}.mdc-tab-header-pagination-disabled .mdc-tab-header-pagination-chevron{opacity:.4}.mdc-tab-list{flex-grow:1;position:relative;transition:transform .5s cubic-bezier(.35,0,.25,1)}.animation-noopable .mdc-tab-list{transition:none}.mdc-tab-label-container{display:flex;flex-grow:1;overflow:hidden;z-index:1;border-bottom-style:solid;border-bottom-width:1px;border-bottom-color:var(--%NS%md-tabs-header-border-color, #f3dde1)}.mdc-tab-group-inverted-header .mdc-tab-label-container{border-bottom:none;border-top-style:solid;border-top-width:1px;border-top-color:var(--%NS%md-tabs-header-border-color, #f3dde1)}.mdc-tab-labels{display:flex;flex:1 0 auto}[align-tabs=center]>.mdc-tab-header .mdc-tab-labels{justify-content:center}[align-tabs=end]>.mdc-tab-header .mdc-tab-labels{justify-content:flex-end}.cdk-drop-list .mdc-tab-labels,.mdc-tab-labels.cdk-drop-list{min-height:48px}.mdc-tab:before{margin:5px}@media(forced-colors:active){.mdc-tab[aria-disabled=true]{color:GrayText}}.md-tab-overflow-trigger,.md-tab-header-menu .mdc-tab-header-pagination{display:none}.md-tab-header-menu .mdc-tab-label-container{min-width:0}.md-tab-header-menu .mdc-tab-list{transition:none}.md-tab-header-menu .mdc-tab-labels{justify-content:flex-start}.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy){flex:0 0 auto;min-width:min(90px,var(--%NS%md-tab-label-max-width, 90px));max-width:var(--%NS%md-tab-label-max-width, none)}.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy) .mdc-tab__content{min-width:0}.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy) .mdc-tab__text-label{overflow:hidden;text-overflow:ellipsis}.md-tab-header-menu .mdc-tab-labels>.md-tab-overflow-hidden{position:absolute;inset-inline-start:-100000px;width:max-content;visibility:hidden;pointer-events:none}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger{display:inline-flex;flex:0 0 44px;align-items:center;justify-content:center;align-self:stretch;border:0;border-bottom:1px solid var(--%NS%md-tabs-header-border-color, var(--%NS%md-color-border));background:var(--%NS%md-tabs-overflow-background, var(--%NS%md-color-surface));color:var(--%NS%md-tabs-label-color, var(--%NS%md-color-text));font:inherit;font-size:24px;line-height:1;padding:0;cursor:pointer}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger:hover{background:var(--%NS%md-color-surface-hover)}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger:focus-visible{outline:2px solid var(--%NS%md-color-focus);outline-offset:-3px}.md-tab-header-menu.mdc-tab-header-pagination-controls-enabled .md-tab-overflow-trigger.md-tab-overflow-active{color:var(--%NS%md-color-primary)}.mdc-tab-group.mdc-tab-group-stretch-tabs>.md-tab-header-menu .mdc-tab-labels>:is(.mdc-tab,.mdc-tab-legacy){flex-grow:0}.mdc-tab-group-inverted-header>.md-tab-header-menu .md-tab-overflow-trigger{border-bottom:0;border-top:1px solid var(--%NS%md-tabs-header-border-color, var(--%NS%md-color-border))}.mdc-tab{min-width:90px;padding:0 24px;display:flex;flex:1 0 auto;font-family:var(--%NS%md-tabs-font-family, var(--%NS%md-font-heading, "Montserrat"));justify-content:center;box-sizing:border-box;border:none;outline:none;text-align:center;white-space:nowrap;cursor:pointer;z-index:1;touch-action:manipulation}.mdc-tab__content{display:flex;align-items:center;justify-content:center;height:inherit;pointer-events:none}.mdc-tab__text-label{transition:.15s color linear;display:inline-block;line-height:1;z-index:2}.mdc-tab--active .mdc-tab__text-label{transition-delay:.1s}._animation-noopable .mdc-tab__text-label{transition:none}.mdc-tab-indicator{display:flex;position:absolute;top:0;left:0;justify-content:center;width:100%;height:100%;pointer-events:none;z-index:1}.mdc-tab-indicator__content{transition:.25s transform cubic-bezier(.4,0,.2,1);transform-origin:left;opacity:0}.no-animations .mdc-tab-indicator__content{transition:none!important;animation:none!important}.mdc-tab-indicator__content--underline{align-self:flex-end;box-sizing:border-box;width:100%;border-top-style:solid}.mdc-tab-indicator--active .mdc-tab-indicator__content{opacity:1}._animation-noopable .mdc-tab-indicator__content,.mdc-tab-indicator--no-transition .mdc-tab-indicator__content{transition:none}.mdc-tab{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-decoration:none;background:none;height:40px;font-family:var(--%NS%md-tabs-font-family, var(--%NS%md-font-heading, "Montserrat"));font-size:1rem;letter-spacing:.006rem;line-height:1.25rem;font-weight:500}.mdc-tab-group.mdc-tab-group-stretch-tabs>.mdc-tab-header .mdc-tab{flex-grow:1}.mdc-tab.mdc-tab{flex-grow:0}.mdc-tab .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106);border-top-width:2px;border-radius:0}.mdc-tab:focus .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--active .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--active .mdc-tab__ripple:before{background-color:var(--%NS%md-tabs-ripple-color, #201a1b)}.mdc-tab.mdc-tab--%NS%active:hover .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--%NS%active:hover .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106)}.mdc-tab.mdc-tab--%NS%active:focus .mdc-tab__text-label{color:var(--%NS%md-tabs-active-label-color, #201a1b)}.mdc-tab.mdc-tab--%NS%active:focus .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106)}.mdc-tab.mdc-tab-disabled{opacity:.4;pointer-events:none}.mdc-tab.mdc-tab-disabled .mdc-tab__content{pointer-events:none}.mdc-tab .mdc-tab__ripple:before{content:"";display:block;position:absolute;inset:0;opacity:0;pointer-events:none;background-color:var(--%NS%md-tabs-ripple-color, #201a1b)}.mdc-tab .mdc-tab__text-label{color:var(--%NS%md-tabs-label-color, #201a1b);display:inline-flex;align-items:center}.mdc-tab .mdc-tab__content{position:relative;pointer-events:auto}.mdc-tab:hover .mdc-tab__ripple:before{opacity:.04}.mdc-tab.cdk-program-focused .mdc-tab__ripple:before,.mdc-tab.cdk-keyboard-focused .mdc-tab__ripple:before{opacity:.12}.mdc-tab-group{display:flex;flex-direction:column;max-width:100%;flex:1}.mdc-tab-group.tabs-with-background>.mdc-tab-header .mdc-tab-header-pagination-chevron,.mdc-tab-group.tabs-with-background>.mdc-tab-header .focus-indicator:before,.mdc-tab-group.tabs-with-background>.mdc-tab-header-pagination .mdc-tab-header-pagination-chevron,.mdc-tab-group.tabs-with-background>.mdc-tab-header-pagination .focus-indicator:before{border-color:var(--%NS%md-tabs-pagination-chevron-color, var(--%NS%md-tabs-label-color, #201a1b))}.mdc-tab-group.tabs-with-background>.mdc-tab-header .mdc-tab-header-pagination-chevron,.mdc-tab-group.tabs-with-background>.mdc-tab-header-pagination .mdc-tab-header-pagination-chevron{color:transparent}.mdc-tab-group.mdc-tab-group-inverted-header{flex-direction:column-reverse}.mdc-tab-group.mdc-tab-group-inverted-header .mdc-tab-indicator__content--underline{align-self:flex-start}.mdc-tab-body-wrapper{position:relative;overflow:hidden;display:flex;height:100%}.mdc-tab-body-wrapper.no-animations .mdc-tab-body-content{transition:none!important;animation:none!important}.focus-indicator{position:relative}.tabs-legacy .mdc-tab-labels{gap:2px}.tabs-legacy .mdc-tab-label-container{border:0px}.mdc-tab-legacy{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-decoration:none;height:28px;padding:0 24px;font-size:12px;letter-spacing:.02rem;font-weight:500;font-family:var(--%NS%md-tabs-font-family, var(--%NS%md-font-heading, "Montserrat"));background-color:var(--%NS%md-tabs-legacy-background, #4D4D4D);border-top-left-radius:5px;border-top-right-radius:5px;cursor:pointer}.legacy-small .mdc-tab-legacy{height:28px;font-size:12px}.legacy-medium .mdc-tab-legacy{height:32px;font-size:14px}.legacy-large .mdc-tab-legacy{height:36px;font-size:16px;font-weight:600}.mdc-tab-group.mdc-tab-group-stretch-tabs>.mdc-tab-header .mdc-tab-legacy{flex-grow:1}.mdc-tab-legacy.mdc-tab{flex-grow:0}.mdc-tab-legacy .mdc-tab-indicator__content--underline{border-color:var(--%NS%md-tabs-indicator-color, #CF0106);border-top-width:2px;border-radius:0}.mdc-tab-legacy:hover:not(.mdc-tab--active){background-color:var(--%NS%md-tabs-legacy-hover-background, #373737)}.mdc-tab-legacy:focus .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-color, #FFFFFF)}.mdc-tab-legacy.mdc-tab--active{background-color:var(--%NS%md-tabs-legacy-active-background, #F3F3F3)}.mdc-tab-legacy.mdc-tab--active .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-active-color, #373737)}.mdc-tab-legacy.mdc-tab--active .mdc-tab__ripple:before{background-color:var(--%NS%md-tabs-ripple-color, #373737)}.mdc-tab-legacy.mdc-tab-disabled{pointer-events:none}.mdc-tab-legacy.mdc-tab-disabled .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-disabled-color, #BDBDBD)}.mdc-tab-legacy.mdc-tab-disabled .mdc-tab__content{pointer-events:none}.mdc-tab-legacy .mdc-tab__ripple:before{content:"";display:block;position:absolute;inset:0;opacity:0;pointer-events:none;background-color:var(--%NS%md-tabs-legacy-color, #FFFFFF)}.mdc-tab-legacy .mdc-tab__text-label{color:var(--%NS%md-tabs-legacy-color, #FFFFFF);display:inline-flex;align-items:center;transition:none}.mdc-tab-legacy .mdc-tab__content{position:relative;pointer-events:auto}.mdc-tab-legacy:hover .mdc-tab__ripple:before{opacity:.04}.mdc-tab-legacy.cdk-program-focused .mdc-tab__ripple:before,.mdc-tab-legacy.cdk-keyboard-focused .mdc-tab__ripple:before{opacity:.12}.mdc-tab-nav-bar{max-width:100%}.mdc-tab-nav-bar-stretch-tabs .mdc-tab{flex-grow:1}.md-tab-link{position:relative}.mdc-tab-nav-bar.tabs-legacy .mdc-tab-labels{gap:2px}.mdc-tab-nav-bar.tabs-legacy .mdc-tab-label-container{border:0}.mdc-tab-nav-bar.tabs-legacy .mdc-tab-legacy:hover:not(.mdc-tab--active){background-color:var(--%NS%md-tabs-legacy-hover-background, #373737)}.md-tab-nav-panel{display:block}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})(), yg = (() => { class n extends Pa {
    _tabNavBar = d(vg);
    elementRef = d(x);
    _focusMonitor = d(Ae);
    _destroyed = new D;
    _isActive = !1;
    _tabIndex = re(() => this._tabNavBar._focusedItem() === this ? this.tabIndex : -1);
    get active() { return this._isActive; }
    set active(e) { e !== this._isActive && (this._isActive = e, this._tabNavBar.updateActiveLink()); }
    disabled = !1;
    get disableRipple() { return this._disableRipple(); }
    set disableRipple(e) { this._disableRipple.set(e); }
    _disableRipple = B(!1);
    tabIndex = 0;
    id = d(W).getId("md-tab-link-");
    get rippleDisabled() { return this.disabled || this.disableRipple || this._tabNavBar.disableRipple; }
    constructor() { super(), this._tabNavBar._fitInkBarToContent.pipe(O(this._destroyed)).subscribe(e => { this.fitInkBarToContent = e; }); }
    focus() { this.elementRef.nativeElement.focus(); }
    ngAfterViewInit() { this._focusMonitor.monitor(this.elementRef); }
    ngOnDestroy() { this._destroyed.next(), this._destroyed.complete(), super.ngOnDestroy(), this._focusMonitor.stopMonitoring(this.elementRef); }
    _handleFocus() { this._tabNavBar.focusIndex = this._tabNavBar._items.toArray().indexOf(this); }
    _handleKeydown(e) { (e.keyCode === se || e.keyCode === Q) && (this.disabled ? e.preventDefault() : this._tabNavBar.tabPanel && (e.keyCode === se && e.preventDefault(), this.elementRef.nativeElement.click())); }
    _getAriaControls() { return this._tabNavBar.tabPanel ? this._tabNavBar.tabPanel?.id : this.elementRef.nativeElement.getAttribute("aria-controls"); }
    _getAriaSelected() { return this._tabNavBar.tabPanel ? this.active ? "true" : "false" : this.elementRef.nativeElement.getAttribute("aria-selected"); }
    _getAriaCurrent() { return this.active && !this._tabNavBar.tabPanel ? "page" : null; }
    _getRole() { return this._tabNavBar.tabPanel ? "tab" : this.elementRef.nativeElement.getAttribute("role"); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["", "md-tab-link", ""], ["", "mdTabLink", ""]], hostAttrs: [1, "mdc-tab", "md-tab-link", "focus-indicator"], hostVars: 13, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("focus", function () { return o._handleFocus(); })("keydown", function (s) { return o._handleKeydown(s); }), i & 2 && (t.\u0275\u0275attribute("aria-controls", o._getAriaControls())("aria-current", o._getAriaCurrent())("aria-disabled", o.disabled)("aria-selected", o._getAriaSelected())("id", o.id)("tabIndex", o._tabIndex())("role", o._getRole()), t.\u0275\u0275classProp("mdc-tab-disabled", o.disabled)("mdc-tab--active", o.active)("mdc-tab-legacy", o._tabNavBar.isLegacyMode)); }, inputs: { active: [2, "active", "active", m], disabled: [2, "disabled", "disabled", m], disableRipple: [2, "disableRipple", "disableRipple", m], tabIndex: [2, "tabIndex", "tabIndex", e => e == null ? 0 : S(e)], id: "id" }, exportAs: ["mdTabLink"], features: [t.\u0275\u0275InheritDefinitionFeature], ngContentSelectors: T, decls: 4, vars: 0, consts: [[1, "mdc-tab__ripple"], [1, "mdc-tab__content"], [1, "mdc-tab__text-label"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElement(0, "span", 0), t.\u0275\u0275domElementStart(1, "span", 1)(2, "span", 2), t.\u0275\u0275projection(3), t.\u0275\u0275domElementEnd()()); }, styles: [Pc], encapsulation: 2 });
} return n; })(), Cy = (() => { class n {
    id = d(W).getId("md-tab-nav-panel-");
    _activeTabId;
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-tab-nav-panel"]], hostAttrs: ["role", "tabpanel", 1, "md-tab-nav-panel"], hostVars: 2, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275attribute("aria-labelledby", o._activeTabId)("id", o.id); }, inputs: { id: "id" }, exportAs: ["mdTabNavPanel"], decls: 0, vars: 0, template: function (i, o) { }, encapsulation: 2 });
} return n; })(), wy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [ae, _g] });
} return n; })(), _e = (function (n) { return n[n.Init = 0] = "Init", n[n.Checked = 1] = "Checked", n[n.Unchecked = 2] = "Unchecked", n; })(_e || {}), nn = class {
    source;
    checked;
}, Sy = (() => {
    class n {
        _elementRef = d(x);
        _changeDetectorRef = d(E);
        _ngZone = d(K);
        _animationsDisabled = !1;
        _options = { color: "accent", clickAction: "check", disabledInteractive: !1 };
        focus() { this._inputElement.nativeElement.focus(); }
        _createChangeEvent(e) { let i = new nn; return i.source = this, i.checked = e, i; }
        _getAnimationTargetElement() { return this._inputElement?.nativeElement; }
        _animationClasses = { uncheckedToChecked: "mdc-checkbox--anim-unchecked-checked", checkedToUnchecked: "mdc-checkbox--anim-checked-unchecked" };
        ariaLabel = "";
        ariaLabelledby = null;
        ariaDescribedby;
        ariaExpanded;
        ariaControls;
        ariaOwns;
        _uniqueId;
        id;
        get inputId() { return `${this.id || this._uniqueId}-input`; }
        required;
        labelPosition = "after";
        name = null;
        change = new p;
        value;
        _inputElement;
        _labelElement;
        tabIndex;
        color;
        disabledInteractive;
        _onTouched = () => { };
        _currentAnimationClass = "";
        _currentCheckState = _e.Init;
        _controlValueAccessorChangeFn = () => { };
        _validatorChangeFn = () => { };
        constructor() { let e = d(new Cn("tabindex"), { optional: !0 }); this._options = this._options, this.color = this._options.color, this.tabIndex = e == null ? 0 : parseInt(e) || 0, this.id = this._uniqueId = d(W).getId("mdc-checkbox-"), this.disabledInteractive = this._options?.disabledInteractive ?? !1; }
        ngOnChanges(e) { e.required && this._validatorChangeFn(); }
        get checked() { return this._checked; }
        set checked(e) { e != this.checked && (this._checked = e, this._changeDetectorRef.markForCheck()); }
        _checked = !1;
        get disabled() { return this._disabled; }
        set disabled(e) { e !== this.disabled && (this._disabled = e, this._changeDetectorRef.markForCheck()); }
        _disabled = !1;
        _onLabelTextChange() { this._changeDetectorRef.detectChanges(); }
        writeValue(e) { this.checked = !!e; }
        registerOnChange(e) { this._controlValueAccessorChangeFn = e; }
        registerOnTouched(e) { this._onTouched = e; }
        setDisabledState(e) { this.disabled = e; }
        validate(e) { return this.required && e.value !== !0 ? { required: !0 } : null; }
        registerOnValidatorChange(e) { this._validatorChangeFn = e; }
        _transitionCheckState(e) { let i = this._currentCheckState, o = this._getAnimationTargetElement(); if (!(i === e || !o) && (this._currentAnimationClass && o.classList.remove(this._currentAnimationClass), this._currentAnimationClass = this._getAnimationClassForCheckStateTransition(i, e), this._currentCheckState = e, this._currentAnimationClass.length > 0)) {
            o.classList.add(this._currentAnimationClass);
            let r = this._currentAnimationClass;
            this._ngZone.runOutsideAngular(() => { setTimeout(() => { o.classList.remove(r); }, 1e3); });
        } }
        _getAnimationClassForCheckStateTransition(e, i) { if (this._animationsDisabled)
            return ""; switch (e) {
            case _e.Init:
                if (i === _e.Checked)
                    return this._animationClasses.uncheckedToChecked;
                break;
            case _e.Unchecked: return this._animationClasses.uncheckedToChecked;
            case _e.Checked: return this._animationClasses.checkedToUnchecked;
        } return ""; }
        _onInputClick() { this._handleInputClick(); }
        _onTouchTargetClick() { this._handleInputClick(), this.disabled || this._inputElement.nativeElement.focus(); }
        _onInteractionEvent(e) { e.stopPropagation(); }
        _onBlur() { Promise.resolve().then(() => { this._onTouched(), this._changeDetectorRef.markForCheck(); }); }
        _handleInputClick() { let e = this._options?.clickAction; !this.disabled && e !== "noop" ? (this._checked = !this._checked, this._transitionCheckState(this._checked ? _e.Checked : _e.Unchecked), this._emitChangeEvent()) : (this.disabled && this.disabledInteractive || !this.disabled && e === "noop") && (this._inputElement.nativeElement.checked = this.checked); }
        _emitChangeEvent() { this._controlValueAccessorChangeFn(this.checked), this.change.emit(this._createChangeEvent(this.checked)), this._inputElement && (this._inputElement.nativeElement.checked = this.checked); }
        toggle() { this.checked = !this.checked, this._controlValueAccessorChangeFn(this.checked); }
        _preventBubblingFromLabel(e) { e.target && this._labelElement.nativeElement.contains(e.target) && e.stopPropagation(); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-checkbox"]], viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(jn, 5)(Oc, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._inputElement = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._labelElement = r.first);
            } }, hostAttrs: [1, "md-mdc-checkbox"], hostVars: 16, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275domProperty("id", o.id), t.\u0275\u0275attribute("tabindex", null)("aria-label", null)("aria-labelledby", null), t.\u0275\u0275classMap(o.color ? o.color : "accent"), t.\u0275\u0275classProp("animation-noopable", o._animationsDisabled)("mdc-checkbox--disabled", o.disabled)("mdc-checkbox-disabled", o.disabled)("mdc-checkbox-checked", o.checked)("mdc-checkbox-disabled-interactive", o.disabledInteractive)); }, inputs: { ariaLabel: [0, "aria-label", "ariaLabel"], ariaLabelledby: [0, "aria-labelledby", "ariaLabelledby"], ariaDescribedby: [0, "aria-describedby", "ariaDescribedby"], ariaExpanded: [2, "aria-expanded", "ariaExpanded", m], ariaControls: [0, "aria-controls", "ariaControls"], ariaOwns: [0, "aria-owns", "ariaOwns"], id: "id", required: [2, "required", "required", m], labelPosition: "labelPosition", name: "name", value: "value", tabIndex: [2, "tabIndex", "tabIndex", e => e == null ? void 0 : S(e)], color: "color", disabledInteractive: [2, "disabledInteractive", "disabledInteractive", m], checked: [2, "checked", "checked", m], disabled: [2, "disabled", "disabled", m] }, outputs: { change: "change" }, exportAs: ["mdCheckbox"], features: [t.\u0275\u0275ProvidersFeature([{ provide: J, useExisting: A(() => n), multi: !0 }, { provide: xt, useExisting: n, multi: !0 }]), t.\u0275\u0275NgOnChangesFeature], ngContentSelectors: T, decls: 13, vars: 17, consts: [["checkbox", ""], ["input", ""], ["label", ""], [1, "checkbox-internal-field", 3, "click"], [1, "mdc-checkbox"], [1, "mdc-checkbox-touch-target", 3, "click"], ["type", "checkbox", 1, "mdc-checkbox__native-control", 3, "blur", "click", "change", "checked", "disabled", "id", "required", "tabIndex"], [1, "mdc-checkbox__background"], ["focusable", "false", "viewBox", "0 0 24 24", "aria-hidden", "true", 1, "mdc-checkbox__checkmark"], ["fill", "none", "d", "M1.73,12.91 8.1,19.28 22.79,4.59", 1, "mdc-checkbox__checkmark-path"], [1, "mdc-checkbox__mixedmark"], [1, "mdc-label", 3, "for"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElementStart(0, "div", 3), t.\u0275\u0275domListener("click", function (s) { return o._preventBubblingFromLabel(s); }), t.\u0275\u0275domElementStart(1, "div", 4, 0)(3, "div", 5), t.\u0275\u0275domListener("click", function () { return o._onTouchTargetClick(); }), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(4, "input", 6, 1), t.\u0275\u0275domListener("blur", function () { return o._onBlur(); })("click", function () { return o._onInputClick(); })("change", function (s) { return o._onInteractionEvent(s); }), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(6, "div", 7), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(7, "svg", 8), t.\u0275\u0275domElement(8, "path", 9), t.\u0275\u0275domElementEnd(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275domElement(9, "div", 10), t.\u0275\u0275domElementEnd()(), t.\u0275\u0275domElementStart(10, "label", 11, 2), t.\u0275\u0275projection(12), t.\u0275\u0275domElementEnd()()), i & 2 && (t.\u0275\u0275advance(4), t.\u0275\u0275classProp("mdc-checkbox--selected", o.checked), t.\u0275\u0275domProperty("checked", o.checked)("disabled", o.disabled && !o.disabledInteractive)("id", o.inputId)("required", o.required)("tabIndex", o.disabled && !o.disabledInteractive ? -1 : o.tabIndex), t.\u0275\u0275attribute("aria-label", o.ariaLabel || null)("aria-labelledby", o.ariaLabelledby)("aria-describedby", o.ariaDescribedby)("aria-controls", o.ariaControls)("aria-disabled", o.disabled && o.disabledInteractive ? !0 : null)("aria-expanded", o.ariaExpanded)("aria-owns", o.ariaOwns)("name", o.name)("value", o.value), t.\u0275\u0275advance(6), t.\u0275\u0275domProperty("htmlFor", o.inputId)); }, styles: [`.md-mdc-checkbox{display:inline-block;position:relative;-webkit-tap-highlight-color:rgba(0,0,0,0);padding:0}.checkbox-internal-field{display:inline-flex;align-items:center;vertical-align:middle;line-height:1.25rem;font-family:Montserrat;font-size:.875rem;letter-spacing:.016rem;font-weight:400}.mdc-checkbox{display:inline-block;position:relative;-webkit-tap-highlight-color:transparent}.mdc-checkbox label{cursor:pointer}.mdc-checkbox.mdc-checkbox-disabled.mdc-checkbox-disabled-interactive{pointer-events:auto}.mdc-checkbox.mdc-checkbox-disabled.mdc-checkbox-disabled-interactive input{cursor:default}.mdc-checkbox.mdc-checkbox-disabled label{cursor:default;color:color-mix(in srgb,#000000 38%,transparent)}.mdc-checkbox label:empty{display:none}.mdc-checkbox-touch-target{position:absolute;top:50%;left:50%;height:calc(var(--%NS%md-checkbox-state-layer-size, 40) * 1px * 1.2);width:calc(var(--%NS%md-checkbox-state-layer-size, 40) * 1px * 1.2);transform:translate(-50%,-50%);display:block}.mdc-checkbox__native-control:focus~.focus-indicator:before{content:""}.mdc-checkbox{display:inline-block;position:relative;flex:0 0 18px;box-sizing:content-box!important;width:18px;height:18px;line-height:0;white-space:nowrap;cursor:pointer;vertical-align:bottom;padding:calc((calc(var(--%NS%md-checkbox-state-layer-size, 40) * 1px) - 18px) / 2);margin:calc((calc(var(--%NS%md-checkbox-state-layer-size, 40) * 1px) - calc(var(--%NS%md-checkbox-state-layer-size, 40) * 1px)) / 2)}.mdc-checkbox .mdc-checkbox__native-control{position:absolute;margin:0;padding:0;opacity:0;cursor:inherit;z-index:1;width:calc(var(--%NS%md-checkbox-state-layer-size, 40) * 1px);height:calc(var(--%NS%md-checkbox-state-layer-size, 40) * 1px);top:0;right:0;left:0}.mdc-checkbox .mdc-checkbox__native-control:focus-visible~.mdc-checkbox__background{outline:1px solid #020617;outline-offset:2px}.mdc-checkbox--disabled{cursor:default;pointer-events:none}@media(forced-colors:active){.mdc-checkbox--disabled{opacity:.5}}.mdc-checkbox__background{display:inline-flex;position:absolute;align-items:center;justify-content:center;box-sizing:border-box;width:18px;height:18px;border:2px solid currentColor;border-radius:2px;background-color:transparent;pointer-events:none;will-change:background-color,border-color;transition:background-color 90ms cubic-bezier(.4,0,.6,1),border-color 90ms cubic-bezier(.4,0,.6,1);border-color:#514346;top:calc((calc(var(--%NS%md-checkbox-state-layer-size, 40) * 1px) - 18px) / 2);left:calc((calc(var(--%NS%md-checkbox-state-layer-size, 40) * 1px) - 18px) / 2)}.mdc-checkbox__native-control:enabled:checked~.mdc-checkbox__background{border-color:#cf0106;background-color:#cf0106}.mdc-checkbox--disabled .mdc-checkbox__background{border-color:color-mix(in srgb,#000000 38%,transparent)}.mdc-checkbox__native-control:disabled:checked~.mdc-checkbox__background{background-color:color-mix(in srgb,#000000 38%,transparent);border-color:transparent}.mdc-checkbox:hover>.mdc-checkbox__native-control:not(:checked)~.mdc-checkbox__background{border-color:#000;background-color:transparent}.mdc-checkbox:hover>.mdc-checkbox__native-control:checked~.mdc-checkbox__background{border-color:#cf0106;background-color:#cf0106}.mdc-checkbox__native-control:focus:focus:not(:checked)~.mdc-checkbox__background{border-color:#000}.mdc-checkbox__native-control:focus:focus:checked~.mdc-checkbox__background{border-color:#cf0106;background-color:#cf0106}.mdc-checkbox--disabled.md-mdc-checkbox-disabled-interactive .mdc-checkbox:hover>.mdc-checkbox__native-control~.mdc-checkbox__background,.mdc-checkbox--disabled.md-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus~.mdc-checkbox__background,.mdc-checkbox--disabled.md-mdc-checkbox-disabled-interactive .mdc-checkbox__background{border-color:color-mix(in srgb,#000000 38%,transparent)}.mdc-checkbox--disabled.md-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:checked~.mdc-checkbox__background{background-color:color-mix(in srgb,#000000 38%,transparent);border-color:transparent}.mdc-checkbox__checkmark{position:absolute;inset:0;width:100%;opacity:0;transition:opacity .18s cubic-bezier(.4,0,.6,1);color:#fff}@media(forced-colors:active){.mdc-checkbox__checkmark{color:CanvasText}}.mdc-checkbox--disabled .mdc-checkbox__checkmark{color:#fff8f8}@media(forced-colors:active){.mdc-checkbox--disabled .mdc-checkbox__checkmark{color:CanvasText}}.mdc-checkbox__checkmark-path{transition:stroke-dashoffset .18s cubic-bezier(.4,0,.6,1);stroke:currentColor;stroke-width:3.12px;stroke-dashoffset:29.7833385;stroke-dasharray:29.7833385}.mdc-checkbox__mixedmark{width:100%;height:0;transform:scaleX(0) rotate(0);border-width:1px;border-style:solid;opacity:0;transition:opacity 90ms cubic-bezier(.4,0,.6,1),transform 90ms cubic-bezier(.4,0,.6,1);border-color:#fff}@media(forced-colors:active){.mdc-checkbox__mixedmark{margin:0 1px}}.mdc-checkbox--disabled .mdc-checkbox__mixedmark,.mdc-checkbox--disabled.md-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark{border-color:#fff}.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__background,.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__background{animation-duration:.18s;animation-timing-function:linear}.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__checkmark-path{animation:mdc-checkbox-unchecked-checked-checkmark-path .18s linear;transition:none}.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__checkmark-path{animation:mdc-checkbox-checked-unchecked-checkmark-path 90ms linear;transition:none}.mdc-checkbox__native-control:checked~.mdc-checkbox__background{transition:border-color 90ms cubic-bezier(0,0,.2,1),background-color 90ms cubic-bezier(0,0,.2,1)}.mdc-checkbox__native-control:checked~.mdc-checkbox__background>.mdc-checkbox__checkmark>.mdc-checkbox__checkmark-path{stroke-dashoffset:0}.mdc-checkbox__native-control:checked~.mdc-checkbox__background>.mdc-checkbox__checkmark{transition:opacity .18s cubic-bezier(0,0,.2,1),transform .18s cubic-bezier(0,0,.2,1);opacity:1}.mdc-checkbox__native-control:checked~.mdc-checkbox__background>.mdc-checkbox__mixedmark{transform:scaleX(1) rotate(-45deg)}@keyframes mdc-checkbox-unchecked-checked-checkmark-path{0%,50%{stroke-dashoffset:29.7833385}50%{animation-timing-function:cubic-bezier(0,0,.2,1)}to{stroke-dashoffset:0}}@keyframes mdc-checkbox-checked-unchecked-checkmark-path{0%{animation-timing-function:cubic-bezier(.4,0,1,1);opacity:1;stroke-dashoffset:0}to{opacity:0;stroke-dashoffset:-29.7833385}}
`], encapsulation: 2 });
    }
    return n;
})(), Dy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), on = class {
    source;
    option;
    constructor(a, e) { this.source = a, this.option = e; }
}, Fa = new k("md-autocomplete-default-options", { providedIn: "root", factory: () => ({ autoActiveFirstOption: !1, autoSelectActiveOption: !1, hideSingleSelectionIndicator: !1, requireSelection: !1, hasBackdrop: !1 }) }), xg = new k("MD_OPTION_PARENT_COMPONENT"), My = (() => {
    class n {
        _changeDetectorRef = d(E);
        _elementRef = d(x);
        _defaults = d(Fa);
        _activeOptionChanges = F.EMPTY;
        _keyManager;
        showPanel = !1;
        get isOpen() { return this._isOpen && this.showPanel; }
        _isOpen = !1;
        _latestOpeningTrigger;
        template;
        panel;
        options;
        optionGroups;
        ariaLabel;
        ariaLabelledby;
        displayWith = null;
        autoActiveFirstOption;
        autoSelectActiveOption;
        requireSelection;
        panelWidth;
        _animationsDisabled = !1;
        optionSelected = new p;
        opened = new p;
        closed = new p;
        optionActivated = new p;
        set classList(e) { this._classList = e, this._elementRef.nativeElement.className = ""; }
        _classList;
        get hideSingleSelectionIndicator() { return this._hideSingleSelectionIndicator; }
        set hideSingleSelectionIndicator(e) { this._hideSingleSelectionIndicator = e, this._syncParentProperties(); }
        _hideSingleSelectionIndicator;
        _syncParentProperties() { if (this.options)
            for (let e of this.options)
                e._changeDetectorRef.markForCheck(); }
        id = d(W).getId("md-autocomplete-");
        inertGroups;
        constructor() { let e = d(mt); this.inertGroups = e?.SAFARI || !1, this.autoActiveFirstOption = !!this._defaults.autoActiveFirstOption, this.autoSelectActiveOption = !!this._defaults.autoSelectActiveOption, this.requireSelection = !!this._defaults.requireSelection, this._hideSingleSelectionIndicator = this._defaults.hideSingleSelectionIndicator ?? !1; }
        ngAfterContentInit() { this._keyManager = new Ar(this.options).withWrap().skipPredicate(this._skipPredicate), this._activeOptionChanges = this._keyManager.change.subscribe(e => { this.isOpen && this.optionActivated.emit({ source: this, option: this.options.toArray()[e] || null }); }), this._setVisibility(); }
        ngOnDestroy() { this._keyManager?.destroy(), this._activeOptionChanges.unsubscribe(); }
        _setScrollTop(e) { this.panel && (this.panel.nativeElement.scrollTop = e); }
        _getScrollTop() { return this.panel ? this.panel.nativeElement.scrollTop : 0; }
        _setVisibility() { this.showPanel = !!this.options?.length, this._changeDetectorRef.markForCheck(); }
        _emitSelectEvent(e) { let i = new on(this, e); this.optionSelected.emit(i); }
        _getPanelAriaLabelledby(e) { if (this.ariaLabel)
            return null; let i = e ? e + " " : ""; return this.ariaLabelledby ? i + this.ariaLabelledby : e; }
        _skipPredicate() { return !1; }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-autocomplete"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, qn, 5)(r, Qn, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.options = s), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.optionGroups = s);
            } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(H, 7)(Hn, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.template = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.panel = r.first);
            } }, hostAttrs: [1, "md-mdc-autocomplete"], inputs: { ariaLabel: [0, "aria-label", "ariaLabel"], ariaLabelledby: [0, "aria-labelledby", "ariaLabelledby"], displayWith: "displayWith", autoActiveFirstOption: [2, "autoActiveFirstOption", "autoActiveFirstOption", m], autoSelectActiveOption: [2, "autoSelectActiveOption", "autoSelectActiveOption", m], requireSelection: [2, "requireSelection", "requireSelection", m], panelWidth: "panelWidth", _animationsDisabled: "_animationsDisabled", classList: [0, "class", "classList"], hideSingleSelectionIndicator: [2, "hideSingleSelectionIndicator", "hideSingleSelectionIndicator", m] }, outputs: { optionSelected: "optionSelected", opened: "opened", closed: "closed", optionActivated: "optionActivated" }, exportAs: ["mdAutocomplete"], features: [t.\u0275\u0275ProvidersFeature([{ provide: xg, useExisting: n }])], ngContentSelectors: T, decls: 1, vars: 0, consts: [["panel", ""], ["role", "listbox", 1, "md-mdc-autocomplete-panel", "mdc-menu-surface", "mdc-menu-surface--open", 3, "id"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domTemplate(0, Fc, 3, 16, "ng-template")); }, styles: [`div.md-mdc-autocomplete-panel{width:100%;max-height:256px;visibility:hidden;transform-origin:center top;overflow:auto;padding:8px 0;box-sizing:border-box;position:relative;border-radius:var(--%NS%md-overlay-radius, var(--%NS%md-radius-md, 5px));background-color:var(--%NS%md-overlay-surface, #ffffff);box-shadow:var(--%NS%md-overlay-shadow, 0 2px 8px rgba(0, 0, 0, .15));color:var(--%NS%md-color-text, inherit)}@media(forced-colors:active){div.md-mdc-autocomplete-panel{outline:solid 1px}}.cdk-overlay-pane:not(.md-mdc-autocomplete-panel-above) div.md-mdc-autocomplete-panel{border-top-left-radius:0;border-top-right-radius:0}.md-mdc-autocomplete-panel-above div.md-mdc-autocomplete-panel{border-bottom-left-radius:0;border-bottom-right-radius:0;transform-origin:center bottom}div.md-mdc-autocomplete-panel.md-mdc-autocomplete-visible{visibility:visible}div.md-mdc-autocomplete-panel.md-mdc-autocomplete-hidden{visibility:hidden;pointer-events:none}@keyframes _md-autocomplete-enter{0%{opacity:0;transform:scaleY(.8)}to{opacity:1;transform:none}}.md-autocomplete-panel-animations-enabled{animation:_md-autocomplete-enter .12s cubic-bezier(0,0,.2,1)}md-autocomplete{display:none}
`], encapsulation: 2 });
    }
    return n;
})(), Ty = (() => { class n {
    elementRef = d(x);
    constructor() { }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdAutocompleteOrigin", ""]], exportAs: ["mdAutocompleteOrigin"] });
} return n; })(), kg = { provide: J, useExisting: A(() => wg), multi: !0 };
function Ey() { return Error("Attempting to open an undefined instance of `md-autocomplete`. Make sure that the id passed to the `mdAutocomplete` is correct and that you're attempting to open it after the ngAfterContentInit hook."); }
var Cg = new k("md-autocomplete-scroll-strategy", { providedIn: "root", factory: () => { let n = d(j); return () => $r(n); } }), wg = (() => { class n {
    _environmentInjector = d(kd);
    _element = d(x);
    _injector = d(j);
    _viewContainerRef = d(ge);
    _zone = d(K);
    _changeDetectorRef = d(E);
    _dir = d(ke, { optional: !0 });
    _viewportRuler = d(Zr);
    _scrollStrategy = d(Cg);
    _renderer = d(ye);
    _animationsDisabled = !1;
    _defaults = d(Fa, { optional: !0 });
    _overlayRef;
    _portal;
    _componentDestroyed = !1;
    _initialized = new D;
    _keydownSubscription;
    _outsideClickSubscription;
    _cleanupWindowBlur;
    _previousValue;
    _valueOnAttach;
    _valueOnLastKeydown;
    _positionStrategy;
    _manuallyFloatingLabel = !1;
    _closingActionsSubscription;
    _viewportSubscription = F.EMPTY;
    _breakpointObserver = d(oa);
    _handsetLandscapeSubscription = F.EMPTY;
    _canOpenOnNextFocus = !0;
    _valueBeforeAutoSelection;
    _pendingAutoselectedOption;
    _closeKeyEventStream = new D;
    _overlayPanelClass = el(this._defaults?.overlayPanelClass || []);
    _windowBlurHandler = () => { this._canOpenOnNextFocus = this.panelOpen || !this._hasFocus(); };
    _onChange = () => { };
    _onTouched = () => { };
    autocomplete;
    position = "auto";
    connectedTo;
    autocompleteAttribute = "off";
    autocompleteDisabled;
    constructor() { }
    _aboveClass = "md-mdc-autocomplete-panel-above";
    ngAfterViewInit() { this._initialized.next(), this._initialized.complete(), this._cleanupWindowBlur = this._renderer.listen("window", "blur", this._windowBlurHandler); }
    ngOnChanges(e) { e.position && this._positionStrategy && (this._setStrategyPositions(this._positionStrategy), this.panelOpen && this._overlayRef.updatePosition()); }
    ngOnDestroy() { this._cleanupWindowBlur?.(), this._handsetLandscapeSubscription.unsubscribe(), this._viewportSubscription.unsubscribe(), this._componentDestroyed = !0, this._destroyPanel(), this._closeKeyEventStream.complete(), this._clearFromModal(); }
    get panelOpen() { return this._overlayAttached && this.autocomplete.showPanel; }
    _overlayAttached = !1;
    openPanel() { this._openPanelInternal(); }
    closePanel() { this._overlayAttached && (this.panelOpen && this._zone.run(() => { this.autocomplete.closed.emit(); }), this.autocomplete._latestOpeningTrigger === this && (this.autocomplete._isOpen = !1, this.autocomplete._latestOpeningTrigger = null), this._overlayAttached = !1, this._pendingAutoselectedOption = null, this._overlayRef && this._overlayRef.hasAttached() && (this._overlayRef.detach(), this._closingActionsSubscription.unsubscribe()), this._updatePanelState(), this._componentDestroyed || this._changeDetectorRef.detectChanges(), this._trackedModal && Ne(this._trackedModal, "aria-owns", this.autocomplete.id)); }
    updatePosition() { this._overlayAttached && this._overlayRef.updatePosition(); }
    get panelClosingActions() { return R(this.optionSelections, this.autocomplete._keyManager.tabOut.pipe(V(() => this._overlayAttached)), this._closeKeyEventStream, this._getOutsideClickStream(), this._overlayRef ? this._overlayRef.detachments().pipe(V(() => this._overlayAttached)) : lt()).pipe(Br(e => e instanceof $t ? e : null)); }
    optionSelections = In(() => { let e = this.autocomplete ? this.autocomplete.options : null; return e ? e.changes.pipe(z(e), ue(() => R(...e.map(i => i.onSelectionChange)))) : this._initialized.pipe(ue(() => this.optionSelections)); });
    get activeOption() { return this.autocomplete && this.autocomplete._keyManager ? this.autocomplete._keyManager.activeItem : null; }
    _getOutsideClickStream() { return new jt(e => { let i = r => { let s = Jr(r), l = this.connectedTo ? this.connectedTo.elementRef.nativeElement : null; this._overlayAttached && s !== this._element.nativeElement && !this._hasFocus() && (!l || !l.contains(s)) && this._overlayRef && !this._overlayRef.overlayElement.contains(s) && e.next(r); }, o = [this._renderer.listen("document", "click", i), this._renderer.listen("document", "auxclick", i), this._renderer.listen("document", "touchend", i)]; return () => { o.forEach(r => r()); }; }); }
    writeValue(e) { Promise.resolve(null).then(() => this._assignOptionValue(e)); }
    registerOnChange(e) { this._onChange = e; }
    registerOnTouched(e) { this._onTouched = e; }
    setDisabledState(e) { this._element.nativeElement.disabled = e; }
    _handleKeydown(e) { let i = e, o = i.keyCode, r = q(i); if (o === qe && !r && i.preventDefault(), this._valueOnLastKeydown = this._element.nativeElement.value, this.activeOption && o === Q && this.panelOpen && !r)
        this.activeOption._selectViaInteraction(), this._resetActiveItem(), i.preventDefault();
    else if (this.autocomplete) {
        let s = this.autocomplete._keyManager.activeItem, l = o === Fe || o === dt;
        o === Tn || l && !r && this.panelOpen ? this.autocomplete._keyManager.onKeydown(i) : l && this._canOpen() && this._openPanelInternal(this._valueOnLastKeydown), (l || this.autocomplete._keyManager.activeItem !== s) && (this._scrollToOption(this.autocomplete._keyManager.activeItemIndex || 0), this.autocomplete.autoSelectActiveOption && this.activeOption && (this._pendingAutoselectedOption || (this._valueBeforeAutoSelection = this._valueOnLastKeydown), this._pendingAutoselectedOption = this.activeOption, this._assignOptionValue(this.activeOption.value)));
    } }
    _handleInput(e) { let i = e.target, o = i.value; if (i.type === "number" && (o = o == "" ? null : parseFloat(o)), this._previousValue !== o) {
        if (this._previousValue = o, this._pendingAutoselectedOption = null, (!this.autocomplete || !this.autocomplete.requireSelection) && this._onChange(o), !o)
            this._clearPreviousSelectedOption(null, !1);
        else if (this.panelOpen && !this.autocomplete.requireSelection) {
            let r = this.autocomplete.options?.find(s => s.selected);
            if (r) {
                let s = this._getDisplayValue(r.value);
                o !== s && r.deselect(!1);
            }
        }
        if (this._canOpen() && this._hasFocus()) {
            let r = this._valueOnLastKeydown ?? this._element.nativeElement.value;
            this._valueOnLastKeydown = null, this._openPanelInternal(r);
        }
    } }
    _handleFocus() { this._canOpenOnNextFocus ? this._canOpen() && (this._previousValue = this._element.nativeElement.value, this._attachOverlay(this._previousValue)) : this._canOpenOnNextFocus = !0; }
    _handleClick() { this._canOpen() && !this.panelOpen && this._openPanelInternal(); }
    _hasFocus() { return dl() === this._element.nativeElement; }
    _subscribeToClosingActions() { let e = new jt(o => { Oe(() => { o.next(); }, { injector: this._environmentInjector }); }), i = this.autocomplete.options?.changes.pipe(Hd(() => this._positionStrategy.reapplyLastPosition()), jd(0)) ?? lt(); return R(e, i).pipe(ue(() => this._zone.run(() => { let o = this.panelOpen; return this._resetActiveItem(), this._updatePanelState(), this._changeDetectorRef.detectChanges(), this.panelOpen && this._overlayRef.updatePosition(), o !== this.panelOpen && (this.panelOpen ? this._emitOpened() : this.autocomplete.closed.emit()), this.panelClosingActions; })), pe(1)).subscribe(o => this._setValueAndClose(o)); }
    _emitOpened() { this.autocomplete.opened.emit(); }
    _destroyPanel() { this._overlayRef && (this.closePanel(), this._overlayRef.dispose(), this._overlayRef = null); }
    _getDisplayValue(e) { let i = this.autocomplete; return i && i.displayWith ? i.displayWith(e) : e; }
    _assignOptionValue(e) { let i = this._getDisplayValue(e); e == null && this._clearPreviousSelectedOption(null, !1), this._updateNativeInputValue(i ?? ""); }
    _updateNativeInputValue(e) { this._element.nativeElement.value = e, this._previousValue = e; }
    _setValueAndClose(e) { let i = this.autocomplete, o = e ? e.source : this._pendingAutoselectedOption; o ? (this._clearPreviousSelectedOption(o), this._assignOptionValue(o.value), this._onChange(o.value), i._emitSelectEvent(o), this._element.nativeElement.focus()) : i.requireSelection && this._element.nativeElement.value !== this._valueOnAttach && (this._clearPreviousSelectedOption(null), this._assignOptionValue(null), this._onChange(null)), this.closePanel(); }
    _clearPreviousSelectedOption(e, i) { this.autocomplete?.options?.forEach(o => { o !== e && o.selected && o.deselect(i); }); }
    _openPanelInternal(e = this._element.nativeElement.value) { if (this._attachOverlay(e), this._trackedModal) {
        let i = this.autocomplete.id;
        Ht(this._trackedModal, "aria-owns", i);
    } }
    _attachOverlay(e) { this.autocomplete; let i = this._overlayRef; i ? (this._positionStrategy.setOrigin(this._getConnectedElement()), i.updateSize({ width: this._getPanelWidth() })) : (this._portal = new xe(this.autocomplete.template, this._viewContainerRef), i = On(this._injector, this._getOverlayConfig()), this._overlayRef = i, this._viewportSubscription = this._viewportRuler.change().subscribe(() => { this.panelOpen && i && i.updateSize({ width: this._getPanelWidth() }); }), this._handsetLandscapeSubscription = this._breakpointObserver.observe(Me.HandsetLandscape).subscribe(r => { r.matches ? this._positionStrategy.withFlexibleDimensions(!0).withGrowAfterOpen(!0).withViewportMargin(8) : this._positionStrategy.withFlexibleDimensions(!1).withGrowAfterOpen(!1).withViewportMargin(0); })), i && !i.hasAttached() && (i.attach(this._portal), this._valueOnAttach = e, this._valueOnLastKeydown = null, this._closingActionsSubscription = this._subscribeToClosingActions()); let o = this.panelOpen; this.autocomplete._isOpen = this._overlayAttached = !0, this.autocomplete._latestOpeningTrigger = this, this._updatePanelState(), this._applyModalPanelOwnership(), this.panelOpen && o !== this.panelOpen && this._emitOpened(); }
    _handlePanelKeydown = e => { (e.keyCode === qe && !q(e) || e.keyCode === Fe && q(e, "altKey")) && (this._pendingAutoselectedOption && (this._updateNativeInputValue(this._valueBeforeAutoSelection ?? ""), this._pendingAutoselectedOption = null), this._closeKeyEventStream.next(), this._resetActiveItem(), e.stopPropagation(), e.preventDefault()); };
    _updatePanelState() { if (this.autocomplete._setVisibility(), this.panelOpen) {
        let e = this._overlayRef;
        this._keydownSubscription || (this._keydownSubscription = e.keydownEvents().subscribe(this._handlePanelKeydown)), this._outsideClickSubscription || (this._outsideClickSubscription = e.outsidePointerEvents().subscribe());
    }
    else
        this._keydownSubscription?.unsubscribe(), this._outsideClickSubscription?.unsubscribe(), this._keydownSubscription = this._outsideClickSubscription = null; }
    _getOverlayConfig() { return new Yr({ positionStrategy: this._getOverlayPosition(), scrollStrategy: this._scrollStrategy(), width: this._getPanelWidth(), direction: this._dir ?? void 0, hasBackdrop: this._defaults?.hasBackdrop, backdropClass: this._defaults?.backdropClass || "cdk-overlay-transparent-backdrop", panelClass: this._overlayPanelClass, disableAnimations: this._animationsDisabled }); }
    _getOverlayPosition() { let e = qr(this._injector, this._getConnectedElement()).withFlexibleDimensions(!1).withPush(!1); return this._setStrategyPositions(e), this._positionStrategy = e, e; }
    _setStrategyPositions(e) { let i = [{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top" }, { originX: "end", originY: "bottom", overlayX: "end", overlayY: "top" }], o = this._aboveClass, r = [{ originX: "start", originY: "top", overlayX: "start", overlayY: "bottom", panelClass: o }, { originX: "end", originY: "top", overlayX: "end", overlayY: "bottom", panelClass: o }], s; this.position === "above" ? s = r : this.position === "below" ? s = i : s = [...i, ...r], e.withPositions(s); }
    _getConnectedElement() { return this.connectedTo ? this.connectedTo.elementRef : this._element; }
    _getPanelWidth() { return this.autocomplete.panelWidth || this._getHostWidth(); }
    _getHostWidth() { return this._getConnectedElement().nativeElement.getBoundingClientRect().width; }
    _resetActiveItem() { let e = this.autocomplete; if (e.autoActiveFirstOption) {
        let i = -1;
        for (let o = 0; o < e.options.length; o++)
            if (!e.options.get(o).disabled) {
                i = o;
                break;
            }
        e._keyManager.setActiveItem(i);
    }
    else
        e._keyManager.setActiveItem(-1); }
    _canOpen() { let e = this._element.nativeElement; return !e.readOnly && !e.disabled && !this.autocompleteDisabled; }
    _scrollToOption(e) { let i = this.autocomplete, o = Da(e, i.options, i.optionGroups); if (e === 0 && o === 1)
        i._setScrollTop(0);
    else if (i.panel) {
        let r = i.options.toArray()[e];
        if (r) {
            let s = r._getHostElement(), l = Ma(s.offsetTop, s.offsetHeight, i._getScrollTop(), i.panel.nativeElement.offsetHeight);
            i._setScrollTop(l);
        }
    } }
    _trackedModal = null;
    _applyModalPanelOwnership() { let e = this._element.nativeElement.closest('body > .cdk-overlay-container [aria-modal="true"]'); if (!e)
        return; let i = this.autocomplete.id; this._trackedModal && Ne(this._trackedModal, "aria-owns", i), Ht(e, "aria-owns", i), this._trackedModal = e; }
    _clearFromModal() { if (this._trackedModal) {
        let e = this.autocomplete.id;
        Ne(this._trackedModal, "aria-owns", e), this._trackedModal = null;
    } }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["input", "mdAutocomplete", ""], ["textarea", "mdAutocomplete", ""]], hostAttrs: [1, "md-mdc-autocomplete-trigger"], hostVars: 7, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("focusin", function () { return o._handleFocus(); })("blur", function () { return o._onTouched(); })("input", function (s) { return o._handleInput(s); })("keydown", function (s) { return o._handleKeydown(s); })("click", function () { return o._handleClick(); }), i & 2 && t.\u0275\u0275attribute("autocomplete", o.autocompleteAttribute)("role", o.autocompleteDisabled ? null : "combobox")("aria-autocomplete", o.autocompleteDisabled ? null : "list")("aria-activedescendant", o.panelOpen && o.activeOption ? o.activeOption.id : null)("aria-expanded", o.autocompleteDisabled ? null : o.panelOpen.toString())("aria-controls", o.autocompleteDisabled || !o.panelOpen ? null : o.autocomplete?.id)("aria-haspopup", o.autocompleteDisabled ? null : "listbox"); }, inputs: { autocomplete: [0, "mdAutocomplete", "autocomplete"], position: [0, "mdAutocompletePosition", "position"], connectedTo: [0, "mdAutocompleteConnectedTo", "connectedTo"], autocompleteAttribute: [0, "autocomplete", "autocompleteAttribute"], autocompleteDisabled: [2, "mdAutocompleteDisabled", "autocompleteDisabled", m] }, exportAs: ["mdAutocompleteTrigger"], features: [t.\u0275\u0275ProvidersFeature([kg]), t.\u0275\u0275NgOnChangesFeature] });
} return n; })(), Iy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [vt, vr, Xr, vr, Qe] });
} return n; })(), qt = class {
    source;
    value;
    constructor(a, e) { this.source = a, this.value = e; }
}, Sg = { provide: J, useExisting: A(() => Dg), multi: !0 }, Ra = new k("MDRadioGroup"), Dg = (() => { class n {
    _changeDetector = d(E);
    _value = null;
    _name = d(W).getId("radio-group-");
    _selected = null;
    _isInitialized = !1;
    _disabled = !1;
    _required = !1;
    _buttonChanges;
    _controlValueAccessorChangeFn = () => { };
    onTouched = () => { };
    change = new p;
    _radios;
    get name() { return this._name; }
    set name(e) { this._name = e, this._updateRadioButtonNames(); }
    get value() { return this._value; }
    set value(e) { this._value !== e && (this._value = e, this._updateSelectedRadioFromValue(), this._checkSelectedRadioButton()); }
    _checkSelectedRadioButton() { this._selected && !this._selected.checked && (this._selected.checked = !0); }
    get selected() { return this._selected; }
    set selected(e) { this._selected = e, this.value = e ? e.value : null, this._checkSelectedRadioButton(); }
    get disabled() { return this._disabled; }
    set disabled(e) { this._disabled = e, this._markRadiosForCheck(); }
    get required() { return this._required; }
    set required(e) { this._required = e, this._markRadiosForCheck(); }
    get disabledInteractive() { return this._disabledInteractive; }
    set disabledInteractive(e) { this._disabledInteractive = e, this._markRadiosForCheck(); }
    _disabledInteractive = !1;
    constructor() { }
    ngAfterContentInit() { this._isInitialized = !0, this._buttonChanges = this._radios.changes.subscribe(() => { this.selected && !this._radios.find(e => e === this.selected) && (this._selected = null); }); }
    ngOnDestroy() { this._buttonChanges?.unsubscribe(); }
    _touch() { this.onTouched && this.onTouched(); }
    _updateRadioButtonNames() { this._radios && this._radios.forEach(e => { e.name = this.name, e._markForCheck(); }); }
    _updateSelectedRadioFromValue() { let e = this._selected !== null && this._selected.value === this._value; this._radios && !e && (this._selected = null, this._radios.forEach(i => { i.checked = this.value === i.value, i.checked && (this._selected = i); })); }
    _emitChangeEvent() { this._isInitialized && this.change.emit(new qt(this._selected, this._value)); }
    _markRadiosForCheck() { this._radios && this._radios.forEach(e => e._markForCheck()); }
    writeValue(e) { this.value = e, this._changeDetector.markForCheck(); }
    registerOnChange(e) { this._controlValueAccessorChangeFn = e; }
    registerOnTouched(e) { this.onTouched = e; }
    setDisabledState(e) { this.disabled = e, this._changeDetector.markForCheck(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-radio-group"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Mg, 5), i & 2) {
            let s;
            t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._radios = s);
        } }, hostAttrs: ["role", "radiogroup", 1, "mdc-radio-group"], inputs: { name: "name", value: "value", selected: "selected", disabled: [2, "disabled", "disabled", m], required: [2, "required", "required", m], disabledInteractive: [2, "disabledInteractive", "disabledInteractive", m] }, outputs: { change: "change" }, exportAs: ["mdRadioGroup"], features: [t.\u0275\u0275ProvidersFeature([Sg, { provide: Ra, useExisting: n }])] });
} return n; })(), Mg = (() => {
    class n {
        _elementRef = d(x);
        _changeDetector = d(E);
        _focusMonitor = d(Ae);
        _radioDispatcher = d(Wr);
        _ngZone = d(K);
        _renderer = d(ye);
        _uniqueId = d(W).getId("radio-");
        _cleanupClick;
        id = this._uniqueId;
        name;
        ariaLabel;
        ariaLabelledby;
        ariaDescribedby;
        tabIndex = 0;
        get checked() { return this._checked; }
        set checked(e) { this._checked !== e && (this._checked = e, e && this.radioGroup && this.radioGroup.value !== this.value ? this.radioGroup.selected = this : !e && this.radioGroup && this.radioGroup.value === this.value && (this.radioGroup.selected = null), e && this._radioDispatcher.notify(this.id, this.name), this._changeDetector.markForCheck()); }
        get value() { return this._value; }
        set value(e) { this._value !== e && (this._value = e, this.radioGroup !== null && (this.checked || (this.checked = this.radioGroup.value === e), this.checked && (this.radioGroup.selected = this))); }
        get disabled() { return this._disabled || this.radioGroup !== null && this.radioGroup.disabled; }
        set disabled(e) { this._setDisabled(e); }
        get required() { return this._required || this.radioGroup && this.radioGroup.required; }
        set required(e) { e !== this._required && this._changeDetector.markForCheck(), this._required = e; }
        get disabledInteractive() { return this._disabledInteractive || this.radioGroup !== null && this.radioGroup.disabledInteractive; }
        set disabledInteractive(e) { this._disabledInteractive = e; }
        _disabledInteractive;
        change = new p;
        radioGroup;
        get inputId() { return `${this.id || this._uniqueId}-input`; }
        _checked = !1;
        _disabled;
        _required;
        _value = null;
        _removeUniqueSelectionListener = () => { };
        _previousTabIndex;
        _inputElement;
        _noopAnimations = !1;
        _injector = d(j);
        constructor() { let e = d(Ra, { optional: !0 }), i = d(new Cn("tabindex"), { optional: !0 }); this.radioGroup = e, this._disabledInteractive = !1, i && (this.tabIndex = S(i, 0)); }
        focus(e, i) { i ? this._focusMonitor.focusVia(this._inputElement, i, e) : this._inputElement.nativeElement.focus(e); }
        _markForCheck() { this._changeDetector.markForCheck(); }
        ngOnInit() { this.radioGroup && (this.checked = this.radioGroup.value === this._value, this.checked && (this.radioGroup.selected = this), this.name = this.radioGroup.name), this._removeUniqueSelectionListener = this._radioDispatcher.listen((e, i) => { e !== this.id && i === this.name && (this.checked = !1); }); }
        ngDoCheck() { this._updateTabIndex(); }
        ngAfterViewInit() { this._updateTabIndex(), this._focusMonitor.monitor(this._elementRef, !0).subscribe(e => { !e && this.radioGroup && this.radioGroup._touch(); }), this._ngZone.runOutsideAngular(() => { this._cleanupClick = this._renderer.listen(this._inputElement.nativeElement, "click", this._onInputClick); }); }
        ngOnDestroy() { this._cleanupClick?.(), this._focusMonitor.stopMonitoring(this._elementRef), this._removeUniqueSelectionListener(); }
        _emitChangeEvent() { this.change.emit(new qt(this, this._value)); }
        _onInputInteraction(e) { if (e.stopPropagation(), !this.checked && !this.disabled) {
            let i = this.radioGroup && this.value !== this.radioGroup.value;
            this.checked = !0, this._emitChangeEvent(), this.radioGroup && (this.radioGroup._controlValueAccessorChangeFn(this.value), i && this.radioGroup._emitChangeEvent());
        } }
        _onTouchTargetClick(e) { this._onInputInteraction(e), (!this.disabled || this.disabledInteractive) && this._inputElement?.nativeElement.focus(); }
        _setDisabled(e) { this._disabled !== e && (this._disabled = e, this._changeDetector.markForCheck()); }
        _onInputClick = e => { this.disabled && this.disabledInteractive && e.preventDefault(); };
        _updateTabIndex() { let e = this.radioGroup, i; if (!e || !e.selected || this.disabled ? i = this.tabIndex : i = e.selected === this ? this.tabIndex : -1, i !== this._previousTabIndex) {
            let o = this._inputElement?.nativeElement;
            o && (o.setAttribute("tabindex", i + ""), this._previousTabIndex = i, Oe(() => { queueMicrotask(() => { e && e.selected && e.selected !== this && document.activeElement === o && (e.selected?._inputElement.nativeElement.focus(), document.activeElement === o && this._inputElement.nativeElement.blur()); }); }, { injector: this._injector }));
        } }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-radio-button"]], viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(jn, 5)(Rc, 7, x), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._inputElement = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o._noopAnimations = r.first);
            } }, hostAttrs: [1, "md-mdc-radio-button"], hostVars: 13, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("focus", function () { return o._inputElement.nativeElement.focus(); }), i & 2 && (t.\u0275\u0275attribute("id", o.id)("tabindex", null)("aria-label", null)("aria-labelledby", null)("aria-describedby", null), t.\u0275\u0275classProp("mdc-radio-checked", o.checked)("mdc-radio-disabled", o.disabled)("mdc-radio-disabled-interactive", o.disabledInteractive)("animation-noopable", o._noopAnimations)); }, inputs: { id: "id", name: "name", ariaLabel: [0, "aria-label", "ariaLabel"], ariaLabelledby: [0, "aria-labelledby", "ariaLabelledby"], ariaDescribedby: [0, "aria-describedby", "ariaDescribedby"], tabIndex: [2, "tabIndex", "tabIndex", e => e == null ? 0 : S(e)], checked: [2, "checked", "checked", m], value: "value", disabled: [2, "disabled", "disabled", m], required: [2, "required", "required", m], disabledInteractive: [2, "disabledInteractive", "disabledInteractive", m] }, outputs: { change: "change" }, exportAs: ["mdRadioButton"], ngContentSelectors: T, decls: 11, vars: 13, consts: [["formField", ""], ["input", ""], [1, "radio-internal-form-field"], [1, "mdc-radio"], [1, "mdc-radio-touch-target", 3, "click"], ["type", "radio", "aria-invalid", "false", 1, "mdc-radio__native-control", 3, "change", "id", "checked", "disabled", "required"], [1, "mdc-radio__background"], [1, "mdc-radio__outer-circle"], [1, "mdc-radio__inner-circle"], [1, "mdc-label", 3, "for"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElementStart(0, "div", 2, 0)(2, "div", 3)(3, "div", 4), t.\u0275\u0275domListener("click", function (s) { return o._onTouchTargetClick(s); }), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(4, "input", 5, 1), t.\u0275\u0275domListener("change", function (s) { return o._onInputInteraction(s); }), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(6, "div", 6), t.\u0275\u0275domElement(7, "div", 7)(8, "div", 8), t.\u0275\u0275domElementEnd()(), t.\u0275\u0275domElementStart(9, "label", 9), t.\u0275\u0275projection(10), t.\u0275\u0275domElementEnd()()), i & 2 && (t.\u0275\u0275advance(2), t.\u0275\u0275classProp("mdc-radio--disabled", o.disabled), t.\u0275\u0275advance(2), t.\u0275\u0275domProperty("id", o.inputId)("checked", o.checked)("disabled", o.disabled && !o.disabledInteractive)("required", o.required), t.\u0275\u0275attribute("name", o.name)("value", o.value)("aria-label", o.ariaLabel)("aria-labelledby", o.ariaLabelledby)("aria-describedby", o.ariaDescribedby)("aria-disabled", o.disabled && o.disabledInteractive ? "true" : null), t.\u0275\u0275advance(5), t.\u0275\u0275domProperty("htmlFor", o.inputId)); }, styles: [`.md-mdc-radio-button{-webkit-tap-highlight-color:transparent}.md-mdc-radio-button .mdc-radio{display:inline-block;position:relative;flex:0 0 auto;box-sizing:content-box;width:15px;height:15px;cursor:pointer;will-change:opacity,transform,border-color,color;padding:8.5px}.md-mdc-radio-button .mdc-radio:hover>.mdc-radio__native-control:not([disabled]):not(:focus)~.mdc-radio__background:before{opacity:.04;transform:scale(1)}.md-mdc-radio-button .mdc-radio:hover>.mdc-radio__native-control:not([disabled])~.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-hover-color, #201a1b)}.md-mdc-radio-button .mdc-radio:hover>.mdc-radio__native-control:enabled:checked+.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-selected-color, #CF0106)}.md-mdc-radio-button .mdc-radio:hover>.mdc-radio__native-control:enabled:checked+.mdc-radio__background>.mdc-radio__inner-circle{background-color:var(--%NS%md-radio-selected-color, #CF0106)}.md-mdc-radio-button .mdc-radio:active>.mdc-radio__native-control:enabled:not(:checked)+.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-hover-color, #201a1b)}.md-mdc-radio-button .mdc-radio:active>.mdc-radio__native-control:enabled:checked+.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-selected-color, #CF0106)}.md-mdc-radio-button .mdc-radio:active>.mdc-radio__native-control:enabled:checked+.mdc-radio__background>.mdc-radio__inner-circle{background-color:var(--%NS%md-radio-selected-color, #CF0106)}.md-mdc-radio-button .mdc-radio__background{display:inline-block;position:relative;box-sizing:border-box;width:15px;height:15px}.md-mdc-radio-button .mdc-radio__background:before{position:absolute;transform:scale(0);border-radius:50%;opacity:0;pointer-events:none;content:"";transition:opacity 90ms cubic-bezier(.4,0,.6,1),transform 90ms cubic-bezier(.4,0,.6,1);width:32px;height:32px;top:-8.5px;left:-8.5px}.md-mdc-radio-button .mdc-radio__outer-circle{position:absolute;top:0;left:0;box-sizing:border-box;width:100%;height:100%;border-width:2px;border-style:solid;border-radius:50%;transition:border-color 90ms cubic-bezier(.4,0,.6,1)}.md-mdc-radio-button .mdc-radio__inner-circle{position:absolute;top:0;left:0;box-sizing:border-box;width:100%;height:100%;transform:scale(0);border-radius:50%;transition:transform 90ms cubic-bezier(.4,0,.6,1),background-color 90ms cubic-bezier(.4,0,.6,1)}@media(forced-colors:active){.md-mdc-radio-button .mdc-radio__inner-circle{background-color:CanvasText!important}}.md-mdc-radio-button .mdc-radio__native-control{position:absolute;margin:0;padding:0;opacity:0;top:0;right:0;left:0;cursor:inherit;z-index:1;width:30px;height:30px}.md-mdc-radio-button .mdc-radio__native-control:checked+.mdc-radio__background,.md-mdc-radio-button .mdc-radio__native-control:disabled+.mdc-radio__background{transition:opacity 90ms cubic-bezier(0,0,.2,1),transform 90ms cubic-bezier(0,0,.2,1)}.md-mdc-radio-button .mdc-radio__native-control:checked+.mdc-radio__background>.mdc-radio__outer-circle,.md-mdc-radio-button .mdc-radio__native-control:disabled+.mdc-radio__background>.mdc-radio__outer-circle{transition:_enter-transition(border-color)}.md-mdc-radio-button .mdc-radio__native-control:checked+.mdc-radio__background>.mdc-radio__inner-circle,.md-mdc-radio-button .mdc-radio__native-control:disabled+.mdc-radio__background>.mdc-radio__inner-circle{transition:transform 90ms cubic-bezier(0,0,.2,1),background-color 90ms cubic-bezier(0,0,.2,1)}.md-mdc-radio-button .mdc-radio__native-control:focus+.mdc-radio__background:before{transform:scale(1);opacity:.12;transition:opacity 90ms cubic-bezier(0,0,.2,1),transform 90ms cubic-bezier(0,0,.2,1)}.md-mdc-radio-button .mdc-radio__native-control:disabled:not(:checked)+.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-disabled-color, #929292);opacity:.38}.md-mdc-radio-button .mdc-radio__native-control:disabled+.mdc-radio__background{cursor:default}.md-mdc-radio-button .mdc-radio__native-control:disabled+.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-disabled-color, #929292);opacity:.38}.md-mdc-radio-button .mdc-radio__native-control:disabled+.mdc-radio__background>.mdc-radio__inner-circle{border-color:var(--%NS%md-radio-disabled-color, #929292);opacity:.38}.md-mdc-radio-button .mdc-radio__native-control:enabled:not(:checked)+.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-unselected-color, #514346)}.md-mdc-radio-button .mdc-radio__native-control:enabled:checked+.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-selected-color, #CF0106)}.md-mdc-radio-button .mdc-radio__native-control:enabled:checked+.mdc-radio__background>.mdc-radio__inner-circle{background-color:var(--%NS%md-radio-selected-color, #CF0106)}.md-mdc-radio-button .mdc-radio__native-control:enabled:focus:checked+.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-selected-color, #CF0106)}.md-mdc-radio-button .mdc-radio__native-control:enabled:focus:checked+.mdc-radio__background>.mdc-radio__inner-circle{background-color:var(--%NS%md-radio-selected-color, #CF0106)}.md-mdc-radio-button .mdc-radio__native-control:checked+.mdc-radio__background>.mdc-radio__inner-circle{transform:scale(.5);transition:transform 90ms cubic-bezier(0,0,.2,1),background-color 90ms cubic-bezier(0,0,.2,1)}.md-mdc-radio-button.mdc-radio-disabled-interactive .mdc-radio--disabled{pointer-events:auto}.md-mdc-radio-button.mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__native-control:not(:checked)+.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-disabled-color, #929292);opacity:.38}.md-mdc-radio-button.mdc-radio-disabled-interactive .mdc-radio--%NS%disabled:hover .mdc-radio__native-control:checked+.mdc-radio__background>.mdc-radio__outer-circle,.md-mdc-radio-button.mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__native-control:checked:focus+.mdc-radio__background>.mdc-radio__outer-circle,.md-mdc-radio-button.mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__native-control+.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-disabled-color, #929292);opacity:.38}.md-mdc-radio-button.mdc-radio-disabled-interactive .mdc-radio--%NS%disabled:hover .mdc-radio__native-control:checked+.mdc-radio__background>.mdc-radio__inner-circle,.md-mdc-radio-button.mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__native-control:checked:focus+.mdc-radio__background>.mdc-radio__inner-circle,.md-mdc-radio-button.mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__native-control+.mdc-radio__background>.mdc-radio__inner-circle{border-color:var(--%NS%md-radio-disabled-color, #929292);opacity:.38}.md-mdc-radio-button .mdc-radio__background:before{background-color:var(--%NS%md-radio-state-layer-color, #929292)}.md-mdc-radio-button.mdc-radio-checked .mdc-radio__background:before{background-color:var(--%NS%md-radio-selected-state-layer-color, #CF0106)}.md-mdc-radio-button.mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__background:before{background-color:var(--%NS%md-radio-state-layer-color, #929292)}.md-mdc-radio-button .mdc-radio--disabled+label{color:color-mix(in srgb,var(--%NS%md-radio-disabled-color, #929292) 38%,transparent)}.md-mdc-radio-button .mdc-radio>.mdc-radio__native-control:focus:enabled:not(:checked)~.mdc-radio__background>.mdc-radio__outer-circle{border-color:var(--%NS%md-radio-hover-color, #201a1b)}.md-mdc-radio-button.cdk-focused .focus-indicator:before{content:""}.mdc-radio-disabled{cursor:default;pointer-events:none}.mdc-radio-disabled.mdc-radio-disabled-interactive{pointer-events:auto}.mdc-radio-touch-target{position:absolute;top:50%;left:50%;height:36px;width:36px;transform:translate(-50%,-50%);display:block}[dir=rtl] .mdc-radio-touch-target{left:auto;right:50%;transform:translate(50%,-50%)}.radio-internal-form-field{color:var(--%NS%md-radio-label-color, #201a1b);font-family:var(--%NS%md-radio-label-font-family, var(--%NS%md-font-heading, "Montserrat"));line-height:1.25rem;font-size:.875rem;letter-spacing:.016rem;font-weight:400;-webkit-font-smoothing:antialiased;display:inline-flex;align-items:center;vertical-align:middle}
`], encapsulation: 2 });
    }
    return n;
})(), Ny = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), ei = new k("md-chips-default-options", { providedIn: "root", factory: () => ({ separatorKeyCodes: [Q] }) }), rn = new k("MDChipAvatar"), an = new k("MDChipTrailingIcon"), sn = new k("MDChipEdit"), dn = new k("MDChipRemove"), ti = new k("MDChip"), Kn = (() => { class n {
    _elementRef = d(x);
    _parentChip = d(ti);
    _isPrimary = !0;
    _isLeading = !1;
    get disabled() { return this._disabled || this._parentChip?.disabled || !1; }
    set disabled(e) { this._disabled = e; }
    _disabled = !1;
    tabIndex = -1;
    _allowFocusWhenDisabled = !1;
    _getDisabledAttribute() { return this.disabled && !this._allowFocusWhenDisabled ? "" : null; }
    constructor() { this._elementRef.nativeElement.nodeName === "BUTTON" && this._elementRef.nativeElement.setAttribute("type", "button"); }
    focus() { this._elementRef.nativeElement.focus(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdChipContent", ""]], hostAttrs: [1, "md-mdc-chip-action", "mdc-evolution-chip__action", "mdc-evolution-chip__action--presentational"], hostVars: 8, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("disabled", o._getDisabledAttribute())("aria-disabled", o.disabled), t.\u0275\u0275classProp("mdc-evolution-chip__action--primary", o._isPrimary)("mdc-evolution-chip__action--secondary", !o._isPrimary)("mdc-evolution-chip__action--trailing", !o._isPrimary && !o._isLeading)); }, inputs: { disabled: [2, "disabled", "disabled", m], tabIndex: [2, "tabIndex", "tabIndex", e => e == null ? -1 : S(e)], _allowFocusWhenDisabled: "_allowFocusWhenDisabled" } });
} return n; })(), kt = (() => { class n extends Kn {
    _getTabindex() { return this.disabled && !this._allowFocusWhenDisabled ? null : this.tabIndex.toString(); }
    _handleClick(e) { !this.disabled && this._isPrimary && (e.preventDefault(), this._parentChip._handlePrimaryActionInteraction()); }
    _handleKeydown(e) { (e.keyCode === Q || e.keyCode === se) && !this.disabled && this._isPrimary && !this._parentChip._isEditing && (e.preventDefault(), this._parentChip._handlePrimaryActionInteraction()); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdChipAction", ""]], hostVars: 3, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function (s) { return o._handleClick(s); })("keydown", function (s) { return o._handleKeydown(s); }), i & 2 && (t.\u0275\u0275attribute("tabindex", o._getTabindex()), t.\u0275\u0275classProp("mdc-evolution-chip__action--presentational", !1)); }, features: [t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), ut = (() => {
    class n {
        _changeDetectorRef = d(E);
        _elementRef = d(x);
        _tagName = d(Cd);
        _ngZone = d(K);
        _focusMonitor = d(Ae);
        _document = d(ve);
        _onFocus = new D;
        _onBlur = new D;
        _isBasicChip;
        role = null;
        color = "primary";
        _hasFocusInternal = !1;
        _pendingFocus;
        _actionChanges;
        _animationsDisabled = !1;
        _allLeadingIcons;
        _allTrailingIcons;
        _allEditIcons;
        _allRemoveIcons;
        _hasFocus() { return this._hasFocusInternal; }
        id = d(W).getId("md-mdc-chip-");
        ariaLabel = null;
        ariaDescription = null;
        _chipListDisabled = !1;
        _hadFocusOnRemove = !1;
        _textElement;
        get value() { return this._value !== void 0 ? this._value : this._textElement.textContent.trim(); }
        set value(e) { this._value = e; }
        _value;
        removable = !0;
        highlighted = !1;
        get disabled() { return this._disabled || this._chipListDisabled; }
        set disabled(e) { this._disabled = e; }
        _disabled = !1;
        removed = new p;
        destroyed = new p;
        basicChipAttrName = "md-basic-chip";
        leadingIcon;
        editIcon;
        trailingIcon;
        removeIcon;
        primaryAction;
        _injector = d(j);
        constructor() { this._monitorFocus(); }
        ngOnInit() { this._isBasicChip = this._elementRef.nativeElement.hasAttribute(this.basicChipAttrName) || this._tagName.toLowerCase() === this.basicChipAttrName; }
        ngAfterViewInit() { this._textElement = this._elementRef.nativeElement.querySelector(".md-mdc-chip-action-label"), this._pendingFocus && (this._pendingFocus = !1, this.focus()); }
        ngAfterContentInit() { this._actionChanges = R(this._allLeadingIcons.changes, this._allTrailingIcons.changes, this._allEditIcons.changes, this._allRemoveIcons.changes).subscribe(() => this._changeDetectorRef.markForCheck()); }
        ngOnDestroy() { this._focusMonitor.stopMonitoring(this._elementRef), this._actionChanges?.unsubscribe(), this.destroyed.emit({ chip: this }), this.destroyed.complete(); }
        remove() { this.removable && (this._hadFocusOnRemove = this._hasFocus(), this.removed.emit({ chip: this })); }
        _hasTrailingIcon() { return !!(this.trailingIcon || this.removeIcon); }
        _handleKeydown(e) { (e.keyCode === Hr && !e.repeat || e.keyCode === Gd) && (e.preventDefault(), this.remove()); }
        focus() { this.disabled || (this.primaryAction ? this.primaryAction.focus() : this._pendingFocus = !0); }
        _getSourceAction(e) { return this._getActions().find(i => { let o = i._elementRef.nativeElement; return o === e || o.contains(e); }); }
        _getActions() { let e = []; return this.editIcon && e.push(this.editIcon), this.primaryAction && e.push(this.primaryAction), this.removeIcon && e.push(this.removeIcon), e; }
        _handlePrimaryActionInteraction() { }
        _hasInteractiveActions() { return this._getActions().length > 0; }
        _edit(e) { }
        _monitorFocus() { this._focusMonitor.monitor(this._elementRef, !0).subscribe(e => { let i = e !== null; i !== this._hasFocusInternal && (this._hasFocusInternal = i, i ? this._onFocus.next({ chip: this }) : (this._changeDetectorRef.markForCheck(), setTimeout(() => this._ngZone.run(() => this._onBlur.next({ chip: this }))))); }); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-basic-chip"], ["", "md-basic-chip", ""], ["md-chip"], ["", "md-chip", ""]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, rn, 5)(r, sn, 5)(r, an, 5)(r, dn, 5)(r, rn, 5)(r, an, 5)(r, sn, 5)(r, dn, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.leadingIcon = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.editIcon = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.trailingIcon = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.removeIcon = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._allLeadingIcons = s), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._allTrailingIcons = s), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._allEditIcons = s), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._allRemoveIcons = s);
            } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(kt, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.primaryAction = r.first);
            } }, hostAttrs: [1, "md-mdc-chip"], hostVars: 31, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("keydown", function (s) { return o._handleKeydown(s); }), i & 2 && (t.\u0275\u0275domProperty("id", o.id), t.\u0275\u0275attribute("role", o.role)("aria-label", o.ariaLabel), t.\u0275\u0275classMap("md-" + (o.color || "primary")), t.\u0275\u0275classProp("mdc-evolution-chip", !o._isBasicChip)("mdc-evolution-chip--disabled", o.disabled)("mdc-evolution-chip--with-trailing-action", o._hasTrailingIcon())("mdc-evolution-chip--with-primary-graphic", o.leadingIcon)("mdc-evolution-chip--with-primary-icon", o.leadingIcon)("mdc-evolution-chip--with-avatar", o.leadingIcon)("md-mdc-chip-with-avatar", o.leadingIcon)("md-mdc-chip-highlighted", o.highlighted)("md-mdc-chip-disabled", o.disabled)("md-mdc-basic-chip", o._isBasicChip)("md-mdc-standard-chip", !o._isBasicChip)("md-mdc-chip-with-trailing-icon", o._hasTrailingIcon())("_md-animation-noopable", o._animationsDisabled)); }, inputs: { role: "role", color: "color", id: "id", ariaLabel: [0, "aria-label", "ariaLabel"], ariaDescription: [0, "aria-description", "ariaDescription"], value: "value", removable: [2, "removable", "removable", m], highlighted: [2, "highlighted", "highlighted", m], disabled: [2, "disabled", "disabled", m] }, outputs: { removed: "removed", destroyed: "destroyed" }, exportAs: ["mdChip"], features: [t.\u0275\u0275ProvidersFeature([{ provide: ti, useExisting: n }])], ngContentSelectors: ca, decls: 8, vars: 2, consts: [[1, "md-mdc-chip-focus-overlay"], [1, "mdc-evolution-chip__cell", "mdc-evolution-chip__cell--primary"], ["mdChipContent", ""], [1, "mdc-evolution-chip__graphic", "md-mdc-chip-graphic"], [1, "mdc-evolution-chip__text-label", "md-mdc-chip-action-label"], [1, "md-mdc-chip-primary-focus-indicator", "md-focus-indicator"], [1, "mdc-evolution-chip__cell", "mdc-evolution-chip__cell--trailing"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(la), t.\u0275\u0275element(0, "span", 0), t.\u0275\u0275elementStart(1, "span", 1)(2, "span", 2), t.\u0275\u0275conditionalCreate(3, Ac, 2, 0, "span", 3), t.\u0275\u0275elementStart(4, "span", 4), t.\u0275\u0275projection(5), t.\u0275\u0275element(6, "span", 5), t.\u0275\u0275elementEnd()()(), t.\u0275\u0275conditionalCreate(7, Lc, 2, 0, "span", 6)), i & 2 && (t.\u0275\u0275advance(3), t.\u0275\u0275conditional(o.leadingIcon ? 3 : -1), t.\u0275\u0275advance(4), t.\u0275\u0275conditional(o._hasTrailingIcon() ? 7 : -1)); }, dependencies: [Kn], styles: [`.mdc-evolution-chip,.mdc-evolution-chip__cell,.mdc-evolution-chip__action{display:inline-flex;align-items:center}.mdc-evolution-chip{position:relative;max-width:100%}.mdc-evolution-chip__cell,.mdc-evolution-chip__action{height:100%}.mdc-evolution-chip__cell--primary{flex-basis:100%;overflow-x:hidden}.mdc-evolution-chip__cell--trailing{flex:1 0 auto}.mdc-evolution-chip__action{align-items:center;background:none;border:none;box-sizing:content-box;cursor:pointer;display:inline-flex;justify-content:center;outline:none;padding:0;text-decoration:none;color:inherit}.mdc-evolution-chip__action--presentational{cursor:auto}.mdc-evolution-chip--disabled,.mdc-evolution-chip__action:disabled{pointer-events:none}.mdc-evolution-chip__action--primary{font:inherit;letter-spacing:inherit;white-space:inherit;overflow-x:hidden}.md-mdc-standard-chip .mdc-evolution-chip__action--%NS%primary:before{border-width:1px;border-radius:8px;box-sizing:border-box;content:"";height:100%;left:0;position:absolute;pointer-events:none;top:0;width:100%;z-index:1;border-style:solid}.md-mdc-standard-chip .mdc-evolution-chip__action--primary{padding-left:12px;padding-right:12px}.md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary{padding-left:0;padding-right:12px}[dir=rtl] .md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary{padding-left:12px;padding-right:0}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__action--%NS%primary:before{border-color:var(--%NS%md-chip-border-color, #74777f)}.mdc-evolution-chip__action--%NS%primary:not(.mdc-evolution-chip__action--presentational):focus:before{border-color:var(--%NS%md-chip-border-color, #74777f)}.md-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__action--%NS%primary:before{border-color:color-mix(in srgb,var(--%NS%md-color-text, #1a1b1f) 12%,transparent)}.md-mdc-standard-chip.mdc-evolution-chip--selected .mdc-evolution-chip__action--%NS%primary:before{border-width:0}.md-mdc-basic-chip .mdc-evolution-chip__action--primary{font:inherit}.md-mdc-standard-chip.mdc-evolution-chip--with-leading-action .mdc-evolution-chip__action--primary{padding-left:0;padding-right:12px}[dir=rtl] .md-mdc-standard-chip.mdc-evolution-chip--with-leading-action .mdc-evolution-chip__action--primary,.md-mdc-standard-chip.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary{padding-left:12px;padding-right:0}[dir=rtl] .md-mdc-standard-chip.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary{padding-left:0;padding-right:12px}.md-mdc-standard-chip.mdc-evolution-chip--with-leading-action.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary,.md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary,[dir=rtl] .md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary{padding-left:0;padding-right:0}.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary{padding-left:0;padding-right:12px}[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary{padding-left:12px;padding-right:0}.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary,[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary{padding-left:0;padding-right:0}.mdc-evolution-chip__action--secondary{position:relative;overflow:visible}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__action--secondary{color:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__action--secondary{color:var(--%NS%md-chip-disabled-color, #1a1b1f)}.md-mdc-standard-chip.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary,.md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary,.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary,[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary{padding-left:8px;padding-right:8px}.mdc-evolution-chip__text-label{-webkit-user-select:none;user-select:none;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.md-mdc-standard-chip .mdc-evolution-chip__text-label{font-family:Montserrat;line-height:1.25rem;font-size:.875rem;font-weight:500;letter-spacing:.006rem}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__text-label{color:var(--%NS%md-chip-label-color, #44474e)}.md-mdc-standard-chip.mdc-evolution-chip--%NS%selected:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__text-label{color:var(--%NS%md-chip-selected-label-color, #3e4759)}.md-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__text-label,.md-mdc-standard-chip.mdc-evolution-chip--selected.mdc-evolution-chip--disabled .mdc-evolution-chip__text-label{color:var(--%NS%md-chip-disabled-color, color-mix(in srgb, #1a1b1f 38%, transparent))}.mdc-evolution-chip__graphic{align-items:center;display:inline-flex;justify-content:center;overflow:hidden;pointer-events:none;position:relative;flex:1 0 auto}.md-mdc-standard-chip .mdc-evolution-chip__graphic{width:24px;height:24px;font-size:24px}.mdc-evolution-chip--selecting .mdc-evolution-chip__graphic{transition:width .15s 0ms cubic-bezier(.4,0,.2,1)}.mdc-evolution-chip--%NS%selectable:not(.mdc-evolution-chip--selected):not(.mdc-evolution-chip--with-primary-icon) .mdc-evolution-chip__graphic{width:0}.md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__graphic{padding-left:6px;padding-right:6px}.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__graphic{padding-left:4px;padding-right:8px}[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__graphic{padding-left:8px;padding-right:4px}.md-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__graphic{padding-left:6px;padding-right:6px}.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__graphic{padding-left:4px;padding-right:8px}[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__graphic{padding-left:8px;padding-right:4px}.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-leading-action .mdc-evolution-chip__graphic{padding-left:0}.mdc-evolution-chip__checkmark{position:absolute;opacity:0;top:50%;left:50%;height:20px;width:20px}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__checkmark{color:var(--%NS%md-chip-selected-label-color, #3e4759)}.md-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__checkmark{color:var(--%NS%md-chip-disabled-color, #1a1b1f)}.mdc-evolution-chip--selecting .mdc-evolution-chip__checkmark{transition:transform .15s 0ms cubic-bezier(.4,0,.2,1);transform:translate(-75%,-50%)}.mdc-evolution-chip--selected .mdc-evolution-chip__checkmark{transform:translate(-50%,-50%);opacity:1}.mdc-evolution-chip__checkmark-svg{display:block}.mdc-evolution-chip__checkmark-path{stroke-width:2px;stroke-dasharray:29.7833385;stroke-dashoffset:29.7833385;stroke:currentColor}.mdc-evolution-chip--selecting .mdc-evolution-chip__checkmark-path{transition:stroke-dashoffset .15s 45ms cubic-bezier(.4,0,.2,1)}.mdc-evolution-chip--selected .mdc-evolution-chip__checkmark-path{stroke-dashoffset:0}.md-mdc-standard-chip .mdc-evolution-chip__icon--trailing{height:18px;width:18px;font-size:18px}.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing.md-mdc-chip-remove{opacity:.38}.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing.md-mdc-chip-remove:focus{opacity:.38}.md-mdc-standard-chip{border-radius:8px;height:32px}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled){background-color:transparent}.md-mdc-standard-chip.mdc-evolution-chip--disabled{background-color:var(--%NS%md-chip-disabled-background, color-mix(in srgb, #1a1b1f 38%, transparent))}.md-mdc-standard-chip.mdc-evolution-chip--%NS%selected:not(.mdc-evolution-chip--disabled){background-color:var(--%NS%md-chip-selected-background, #3e4759)}.md-mdc-standard-chip.mdc-evolution-chip--selected.mdc-evolution-chip--disabled{background-color:var(--%NS%md-chip-disabled-background, color-mix(in srgb, #1a1b1f 38%, transparent))}.md-mdc-standard-chip .mdc-evolution-chip__icon--primary{border-radius:24px;width:18px;height:18px;font-size:18px}.mdc-evolution-chip--selected .mdc-evolution-chip__icon--primary{opacity:0}.md-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__icon--primary{color:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--primary{color:var(--%NS%md-chip-disabled-color, #1a1b1f)}.md-mdc-chip-highlighted{--%NS%md-chip-with-icon-icon-color: var(--%NS%md-chip-selected-label-color, #3e4759);--%NS%md-chip-elevated-container-color: var(--%NS%md-chip-selected-background, #3e4759);--%NS%md-chip-label-text-color: var(--%NS%md-chip-selected-label-color, #3e4759);--%NS%md-chip-outline-width: 0}.md-mdc-chip-focus-overlay{background:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-chip-selected .md-mdc-chip-focus-overlay,.md-mdc-chip-highlighted .md-mdc-chip-focus-overlay{background:var(--%NS%md-chip-selected-background, #3e4759)}.md-mdc-chip:hover .md-mdc-chip-focus-overlay,.md-mdc-chip-focus-overlay .md-mdc-chip-selected:hover,.md-mdc-chip-highlighted:hover .md-mdc-chip-focus-overlay{background:var(--%NS%md-chip-icon-color, #44474e);opacity:.08}.md-mdc-chip.cdk-focused .md-mdc-chip-focus-overlay,.md-mdc-chip-selected.cdk-focused .md-mdc-chip-focus-overlay,.md-mdc-chip-highlighted.cdk-focused .md-mdc-chip-focus-overlay{background:var(--%NS%md-chip-icon-color, #44474e);opacity:.12}.mdc-evolution-chip--%NS%disabled:not(.mdc-evolution-chip--selected) .md-mdc-chip-avatar{opacity:.38}.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing,.mdc-evolution-chip--disabled.mdc-evolution-chip--selected .mdc-evolution-chip__checkmark{opacity:.38}.md-mdc-standard-chip.mdc-evolution-chip--disabled{opacity:1}.md-mdc-standard-chip.mdc-evolution-chip--selected .mdc-evolution-chip__icon--trailing,.md-mdc-standard-chip.md-mdc-chip-highlighted .mdc-evolution-chip__icon--trailing{color:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-standard-chip.mdc-evolution-chip--selected.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing,.md-mdc-standard-chip.md-mdc-chip-highlighted.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing{color:var(--%NS%md-chip-disabled-color, #1a1b1f)}.md-mdc-chip-edit:focus,.md-mdc-chip-remove:focus{opacity:1}.md-mdc-chip-edit:after,.md-mdc-chip-remove:after{background-color:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-chip-edit:hover:after,.md-mdc-chip-remove:hover:after{opacity:.2}.md-mdc-chip-edit:focus:after,.md-mdc-chip-remove:focus:after{opacity:.12}.md-mdc-chip-selected .md-mdc-chip-remove:after,.md-mdc-chip-highlighted .md-mdc-chip-remove:after{background-color:var(--%NS%md-chip-icon-color, #44474e)}.md-mdc-chip.cdk-focused .md-mdc-chip-edit:focus:after,.md-mdc-chip.cdk-focused .md-mdc-chip-remove:focus:after{opacity:.12}.md-mdc-chip.cdk-focused .md-mdc-chip-edit:hover:after,.md-mdc-chip.cdk-focused .md-mdc-chip-remove:hover:after{opacity:.08}.md-mdc-standard-chip{-webkit-tap-highlight-color:transparent}.md-mdc-standard-chip .md-mdc-chip-graphic,.md-mdc-standard-chip .md-mdc-chip-trailing-icon{box-sizing:content-box}.md-mdc-standard-chip._md-animation-noopable,.md-mdc-standard-chip._md-animation-noopable .mdc-evolution-chip__graphic,.md-mdc-standard-chip._md-animation-noopable .mdc-evolution-chip__checkmark,.md-mdc-standard-chip._md-animation-noopable .mdc-evolution-chip__checkmark-path{transition-duration:1ms;animation-duration:1ms}.md-mdc-chip-focus-overlay{inset:0;position:absolute;pointer-events:none;opacity:0;border-radius:inherit;transition:opacity .15s linear}._md-animation-noopable .md-mdc-chip-focus-overlay{transition:none}.md-mdc-basic-chip .md-mdc-chip-focus-overlay{display:none}.md-mdc-chip-avatar{text-align:center;line-height:1;color:var(--%NS%md-chip-with-icon-icon-color, currentColor)}.md-mdc-chip{position:relative;z-index:0}.md-mdc-chip-action-label{text-align:left;z-index:1}[dir=rtl] .md-mdc-chip-action-label{text-align:right}.md-mdc-chip.mdc-evolution-chip--with-trailing-action .md-mdc-chip-action-label{position:relative}.md-mdc-chip-action-label .md-mdc-chip-primary-focus-indicator{position:absolute;inset:0;pointer-events:none}.md-mdc-chip-action-label .md-focus-indicator:before{margin:calc(calc(var(--%NS%md-focus-indicator-border-width, 3px) + 2px) * -1)}.md-mdc-chip-edit:before,.md-mdc-chip-remove:before{margin:calc(var(--%NS%md-focus-indicator-border-width, 3px) * -1);left:8px;right:8px}.md-mdc-chip-edit:after,.md-mdc-chip-remove:after{content:"";display:block;opacity:0;position:absolute;inset:-3px 5px;border-radius:50%;box-sizing:border-box;padding:12px;margin:-12px;background-clip:content-box}.md-mdc-chip-edit .md-icon,.md-mdc-chip-remove .md-icon{width:18px;height:18px;font-size:18px;box-sizing:content-box}.md-chip-edit-input{cursor:text;display:inline-block;color:inherit;outline:0}.md-mdc-chip-action:focus .md-focus-indicator:before{content:""}.mdc-evolution-chip__icon,.md-mdc-chip-edit .md-icon,.md-mdc-chip-remove .md-icon{min-height:fit-content}
`], encapsulation: 2 });
    }
    return n;
})(), Cr = class {
    source;
    selected;
    isUserInput;
    constructor(a, e, i = !1) { this.source = a, this.selected = e, this.isUserInput = i; }
}, Tg = (() => { class n extends ut {
    _defaultOptions = d(ei, { optional: !0 });
    chipListSelectable = !0;
    _chipListMultiple = !1;
    _chipListHideSingleSelectionIndicator = this._defaultOptions?.hideSingleSelectionIndicator ?? !1;
    get selectable() { return this._selectable && this.chipListSelectable; }
    set selectable(e) { this._selectable = e, this._changeDetectorRef.markForCheck(); }
    _selectable = !0;
    get selected() { return this._selected; }
    set selected(e) { this._setSelectedState(e, !1, !0); }
    _selected = !1;
    get ariaSelected() { return this.selectable ? this.selected.toString() : null; }
    basicChipAttrName = "md-basic-chip-option";
    selectionChange = new p;
    ngOnInit() { super.ngOnInit(), this.role = "presentation"; }
    select() { this._setSelectedState(!0, !1, !0); }
    deselect() { this._setSelectedState(!1, !1, !0); }
    selectViaInteraction() { this._setSelectedState(!0, !0, !0); }
    toggleSelected(e = !1) { return this._setSelectedState(!this.selected, e, !0), this.selected; }
    _handlePrimaryActionInteraction() { this.disabled || (this.focus(), this.selectable && this.toggleSelected(!0)); }
    _hasLeadingGraphic() { return this.leadingIcon ? !0 : !this._chipListHideSingleSelectionIndicator || this._chipListMultiple; }
    _setSelectedState(e, i, o) { e !== this.selected && (this._selected = e, o && this.selectionChange.emit({ source: this, isUserInput: i, selected: this.selected }), this._changeDetectorRef.markForCheck()); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-basic-chip-option"], ["", "md-basic-chip-option", ""], ["md-chip-option"], ["", "md-chip-option", ""]], hostAttrs: [1, "md-mdc-chip", "md-mdc-chip-option"], hostVars: 37, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275domProperty("id", o.id), t.\u0275\u0275attribute("tabindex", null)("aria-label", null)("aria-description", null)("role", o.role), t.\u0275\u0275classProp("mdc-evolution-chip", !o._isBasicChip)("mdc-evolution-chip--filter", !o._isBasicChip)("mdc-evolution-chip--selectable", !o._isBasicChip)("md-mdc-chip-selected", o.selected)("md-mdc-chip-multiple", o._chipListMultiple)("md-mdc-chip-disabled", o.disabled)("md-mdc-chip-with-avatar", o.leadingIcon)("mdc-evolution-chip--disabled", o.disabled)("mdc-evolution-chip--selected", o.selected)("mdc-evolution-chip--selecting", !o._animationsDisabled)("mdc-evolution-chip--with-trailing-action", o._hasTrailingIcon())("mdc-evolution-chip--with-primary-icon", o.leadingIcon)("mdc-evolution-chip--with-primary-graphic", o._hasLeadingGraphic())("mdc-evolution-chip--with-avatar", o.leadingIcon)("md-mdc-chip-highlighted", o.highlighted)("md-mdc-chip-with-trailing-icon", o._hasTrailingIcon())); }, inputs: { selectable: [2, "selectable", "selectable", m], selected: [2, "selected", "selected", m] }, outputs: { selectionChange: "selectionChange" }, features: [t.\u0275\u0275ProvidersFeature([{ provide: ut, useExisting: n }, { provide: ti, useExisting: n }]), t.\u0275\u0275InheritDefinitionFeature], ngContentSelectors: ca, decls: 8, vars: 6, consts: [[1, "md-mdc-chip-focus-overlay"], [1, "mdc-evolution-chip__cell", "mdc-evolution-chip__cell--primary"], ["mdChipAction", "", "role", "option", 3, "_allowFocusWhenDisabled"], [1, "mdc-evolution-chip__graphic", "md-mdc-chip-graphic"], [1, "mdc-evolution-chip__text-label", "md-mdc-chip-action-label"], [1, "md-mdc-chip-primary-focus-indicator", "md-focus-indicator"], [1, "mdc-evolution-chip__cell", "mdc-evolution-chip__cell--trailing"], [1, "mdc-evolution-chip__checkmark"], ["viewBox", "-2 -3 30 30", "focusable", "false", "aria-hidden", "true", 1, "mdc-evolution-chip__checkmark-svg"], ["fill", "none", "stroke", "currentColor", "d", "M1.73,12.91 8.1,19.28 22.79,4.59", 1, "mdc-evolution-chip__checkmark-path"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(la), t.\u0275\u0275element(0, "span", 0), t.\u0275\u0275elementStart(1, "span", 1)(2, "button", 2), t.\u0275\u0275conditionalCreate(3, Bc, 5, 0, "span", 3), t.\u0275\u0275elementStart(4, "span", 4), t.\u0275\u0275projection(5), t.\u0275\u0275element(6, "span", 5), t.\u0275\u0275elementEnd()()(), t.\u0275\u0275conditionalCreate(7, zc, 2, 0, "span", 6)), i & 2 && (t.\u0275\u0275advance(2), t.\u0275\u0275property("_allowFocusWhenDisabled", !0), t.\u0275\u0275attribute("aria-description", o.ariaDescription)("aria-label", o.ariaLabel)("aria-selected", o.ariaSelected), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o._hasLeadingGraphic() ? 3 : -1), t.\u0275\u0275advance(4), t.\u0275\u0275conditional(o._hasTrailingIcon() ? 7 : -1)); }, dependencies: [kt], styles: [ma], encapsulation: 2 });
} return n; })(), zi = (() => { class n {
    _elementRef = d(x);
    _document = d(ve);
    constructor() { }
    initialize(e) { this.getNativeElement().focus(), this.setValue(e); }
    getNativeElement() { return this._elementRef.nativeElement; }
    setValue(e) { this.getNativeElement().textContent = e, this._moveCursorToEndOfInput(); }
    getValue() { return this.getNativeElement().textContent || ""; }
    _moveCursorToEndOfInput() { let e = this._document.createRange(); e.selectNodeContents(this.getNativeElement()), e.collapse(!1); let i = window.getSelection(); i.removeAllRanges(), i.addRange(e); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["span", "mdChipEditInput", ""]], hostAttrs: ["role", "textbox", "tabindex", "-1", "contenteditable", "true", 1, "md-chip-edit-input"] });
} return n; })(), Eg = (() => { class n extends ut {
    basicChipAttrName = "md-basic-chip-row";
    _editStartPending = !1;
    editable = !1;
    edited = new p;
    defaultEditInput;
    contentEditInput;
    _alreadyFocused = !1;
    _isEditing = !1;
    constructor() { super(), this.role = "row", this._onBlur.pipe(O(this.destroyed)).subscribe(() => { this._isEditing && !this._editStartPending && this._onEditFinish(), this._alreadyFocused = !1; }); }
    ngAfterViewInit() { super.ngAfterViewInit(), this._ngZone.runOutsideAngular(() => { this._elementRef.nativeElement.addEventListener("mousedown", () => this._alreadyFocused = this._hasFocus()); }); }
    _hasLeadingActionIcon() { return !this._isEditing && !!this.editIcon; }
    _hasTrailingIcon() { return !this._isEditing && super._hasTrailingIcon(); }
    _handleFocus() { !this._isEditing && !this.disabled && this.focus(); }
    _handleKeydown(e) { e.keyCode === Q && !this.disabled ? this._isEditing ? (e.preventDefault(), this._onEditFinish()) : this.editable && this._startEditing(e) : this._isEditing ? e.stopPropagation() : super._handleKeydown(e); }
    _handleClick(e) { !this.disabled && this.editable && !this._isEditing && this._alreadyFocused && (e.preventDefault(), e.stopPropagation(), this._startEditing(e)); }
    _handleDoubleclick(e) { !this.disabled && this.editable && this._startEditing(e); }
    _edit() { this._changeDetectorRef.markForCheck(), this._startEditing(); }
    _startEditing(e) { if (!this.primaryAction || this.removeIcon && e && this._getSourceAction(e.target) === this.removeIcon)
        return; let i = this.value; this._isEditing = this._editStartPending = !0, Oe(() => { this._getEditInput().initialize(i), setTimeout(() => this._ngZone.run(() => this._editStartPending = !1)); }, { injector: this._injector }); }
    _onEditFinish() { this._isEditing = this._editStartPending = !1, this.edited.emit({ chip: this, value: this._getEditInput().getValue() }), (this._document.activeElement === this._getEditInput().getNativeElement() || this._document.activeElement === this._document.body) && this.primaryAction.focus(); }
    _getEditInput() { return this.contentEditInput || this.defaultEditInput; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-chip-row"], ["", "md-chip-row", ""], ["md-basic-chip-row"], ["", "md-basic-chip-row", ""]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, zi, 5), i & 2) {
            let s;
            t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.contentEditInput = s.first);
        } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(zi, 5), i & 2) {
            let r;
            t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.defaultEditInput = r.first);
        } }, hostAttrs: [1, "md-mdc-chip", "md-mdc-chip-row", "mdc-evolution-chip"], hostVars: 29, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("focus", function () { return o._handleFocus(); })("click", function (s) { return o._hasInteractiveActions() ? o._handleClick(s) : null; })("dblclick", function (s) { return o._handleDoubleclick(s); }), i & 2 && (t.\u0275\u0275domProperty("id", o.id), t.\u0275\u0275attribute("tabindex", o.disabled ? null : -1)("aria-label", null)("aria-description", null)("role", o.role), t.\u0275\u0275classProp("md-mdc-chip-with-avatar", o.leadingIcon)("md-mdc-chip-disabled", o.disabled)("md-mdc-chip-editing", o._isEditing)("md-mdc-chip-editable", o.editable)("mdc-evolution-chip--disabled", o.disabled)("mdc-evolution-chip--with-leading-action", o._hasLeadingActionIcon())("mdc-evolution-chip--with-trailing-action", o._hasTrailingIcon())("mdc-evolution-chip--with-primary-graphic", o.leadingIcon)("mdc-evolution-chip--with-primary-icon", o.leadingIcon)("mdc-evolution-chip--with-avatar", o.leadingIcon)("md-mdc-chip-highlighted", o.highlighted)("md-mdc-chip-with-trailing-icon", o._hasTrailingIcon())); }, inputs: { editable: "editable" }, outputs: { edited: "edited" }, features: [t.\u0275\u0275ProvidersFeature([{ provide: ut, useExisting: n }, { provide: ti, useExisting: n }]), t.\u0275\u0275InheritDefinitionFeature], ngContentSelectors: Hc, decls: 9, vars: 8, consts: [[1, "md-mdc-chip-focus-overlay"], ["role", "gridcell", 1, "mdc-evolution-chip__cell", "mdc-evolution-chip__cell--leading"], ["role", "gridcell", "mdChipAction", "", 1, "mdc-evolution-chip__cell", "mdc-evolution-chip__cell--primary", 3, "disabled"], [1, "mdc-evolution-chip__graphic", "md-mdc-chip-graphic"], [1, "mdc-evolution-chip__text-label", "md-mdc-chip-action-label"], ["aria-hidden", "true", 1, "md-mdc-chip-primary-focus-indicator", "md-focus-indicator"], ["role", "gridcell", 1, "mdc-evolution-chip__cell", "mdc-evolution-chip__cell--trailing"], ["mdChipEditInput", ""]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(Vc), t.\u0275\u0275conditionalCreate(0, jc, 1, 0, "span", 0), t.\u0275\u0275conditionalCreate(1, Wc, 2, 0, "span", 1), t.\u0275\u0275elementStart(2, "span", 2), t.\u0275\u0275conditionalCreate(3, Gc, 2, 0, "span", 3), t.\u0275\u0275elementStart(4, "span", 4), t.\u0275\u0275conditionalCreate(5, qc, 2, 1)(6, Qc, 1, 0), t.\u0275\u0275element(7, "span", 5), t.\u0275\u0275elementEnd()(), t.\u0275\u0275conditionalCreate(8, Kc, 2, 0, "span", 6)), i & 2 && (t.\u0275\u0275conditional(o._isEditing ? -1 : 0), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o._hasLeadingActionIcon() ? 1 : -1), t.\u0275\u0275advance(), t.\u0275\u0275property("disabled", o.disabled), t.\u0275\u0275attribute("aria-description", o.ariaDescription)("aria-label", o.ariaLabel), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.leadingIcon ? 3 : -1), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o._isEditing ? 5 : 6), t.\u0275\u0275advance(3), t.\u0275\u0275conditional(o._hasTrailingIcon() ? 8 : -1)); }, dependencies: [kt, zi], styles: [ma], encapsulation: 2 });
} return n; })(), Aa = (() => {
    class n {
        _elementRef = d(x);
        _changeDetectorRef = d(E);
        _dir = d(ke, { optional: !0 });
        _lastDestroyedFocusedChipIndex = null;
        _keyManager;
        _destroyed = new D;
        _defaultRole = "presentation";
        get chipFocusChanges() { return this._getChipStream(e => e._onFocus); }
        get chipDestroyedChanges() { return this._getChipStream(e => e.destroyed); }
        get chipRemovedChanges() { return this._getChipStream(e => e.removed); }
        get disabled() { return this._disabled; }
        set disabled(e) { this._disabled = e, this._syncChipsState(); }
        _disabled = !1;
        get empty() { return !this._chips || this._chips.length === 0; }
        get role() { return this._explicitRole ? this._explicitRole : this.empty ? null : this._defaultRole; }
        tabIndex = 0;
        set role(e) { this._explicitRole = e; }
        _explicitRole = null;
        get focused() { return this._hasFocusedChip(); }
        _chips;
        _chipActions = new _t;
        constructor() { }
        ngAfterViewInit() { this._setUpFocusManagement(), this._trackChipSetChanges(), this._trackDestroyedFocusedChip(); }
        ngOnDestroy() { this._keyManager?.destroy(), this._chipActions.destroy(), this._destroyed.next(), this._destroyed.complete(); }
        _hasFocusedChip() { return this._chips && this._chips.some(e => e._hasFocus()); }
        _syncChipsState() { this._chips?.forEach(e => { e._chipListDisabled = this._disabled, e._changeDetectorRef.markForCheck(); }); }
        focus() { }
        _handleKeydown(e) { this._originatesFromChip(e) && this._keyManager.onKeydown(e); }
        _isValidIndex(e) { return e >= 0 && e < this._chips.length; }
        _allowFocusEscape() { let e = this._elementRef.nativeElement.tabIndex; e !== -1 && (this._elementRef.nativeElement.tabIndex = -1, setTimeout(() => this._elementRef.nativeElement.tabIndex = e)); }
        _getChipStream(e) { return this._chips.changes.pipe(z(null), ue(() => R(...this._chips.map(e)))); }
        _originatesFromChip(e) { let i = e.target; for (; i && i !== this._elementRef.nativeElement;) {
            if (i.classList.contains("md-mdc-chip"))
                return !0;
            i = i.parentElement;
        } return !1; }
        _setUpFocusManagement() { this._chips.changes.pipe(z(this._chips)).subscribe(e => { let i = []; e.forEach(o => o._getActions().forEach(r => i.push(r))), this._chipActions.reset(i), this._chipActions.notifyOnChanges(); }), this._keyManager = new Xt(this._chipActions).withVerticalOrientation().withHorizontalOrientation(this._dir ? this._dir.value : "ltr").withHomeAndEnd().skipPredicate(e => this._skipPredicate(e)), this.chipFocusChanges.pipe(O(this._destroyed)).subscribe(({ chip: e }) => { let i = e._getSourceAction(document.activeElement); i && this._keyManager.updateActiveItem(i); }), this._dir?.change.pipe(O(this._destroyed)).subscribe(e => this._keyManager.withHorizontalOrientation(e)); }
        _skipPredicate(e) { return e.disabled; }
        _trackChipSetChanges() { this._chips.changes.pipe(z(null), O(this._destroyed)).subscribe(() => { this.disabled && Promise.resolve().then(() => this._syncChipsState()), this._redirectDestroyedChipFocus(); }); }
        _trackDestroyedFocusedChip() { this.chipDestroyedChanges.pipe(O(this._destroyed)).subscribe(e => { let o = this._chips.toArray().indexOf(e.chip), r = e.chip._hasFocus(), s = e.chip._hadFocusOnRemove && this._keyManager.activeItem && e.chip._getActions().includes(this._keyManager.activeItem), l = r || s; this._isValidIndex(o) && l && (this._lastDestroyedFocusedChipIndex = o); }); }
        _redirectDestroyedChipFocus() { if (this._lastDestroyedFocusedChipIndex != null) {
            if (this._chips.length) {
                let e = Math.min(this._lastDestroyedFocusedChipIndex, this._chips.length - 1), i = this._chips.toArray()[e];
                i.disabled ? this._chips.length === 1 ? this.focus() : this._keyManager.setPreviousItemActive() : i.focus();
            }
            else
                this.focus();
            this._lastDestroyedFocusedChipIndex = null;
        } }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-chip-set"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, ut, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._chips = s);
            } }, hostAttrs: [1, "md-mdc-chip-set", "mdc-evolution-chip-set"], hostVars: 1, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("keydown", function (s) { return o._handleKeydown(s); }), i & 2 && t.\u0275\u0275attribute("role", o.role); }, inputs: { disabled: [2, "disabled", "disabled", m], role: "role", tabIndex: [2, "tabIndex", "tabIndex", e => e == null ? 0 : S(e)] }, ngContentSelectors: T, decls: 2, vars: 0, consts: [["role", "presentation", 1, "mdc-evolution-chip-set__chips"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElementStart(0, "div", 0), t.\u0275\u0275projection(1), t.\u0275\u0275domElementEnd()); }, styles: [`.md-mdc-chip-set{display:flex}.md-mdc-chip-set:focus{outline:none}.md-mdc-chip-set .mdc-evolution-chip-set__chips{min-width:100%;margin-left:-8px;margin-right:0}.md-mdc-chip-set .mdc-evolution-chip{margin:4px 0 4px 8px}[dir=rtl] .md-mdc-chip-set .mdc-evolution-chip-set__chips{margin-left:0;margin-right:-8px}[dir=rtl] .md-mdc-chip-set .mdc-evolution-chip{margin-left:0;margin-right:8px}.mdc-evolution-chip-set__chips{display:flex;flex-flow:wrap;min-width:0}.md-mdc-chip-set-stacked{flex-direction:column;align-items:flex-start}.md-mdc-chip-set-stacked .md-mdc-chip{width:100%}.md-mdc-chip-set-stacked .mdc-evolution-chip__graphic{flex-grow:0}.md-mdc-chip-set-stacked .mdc-evolution-chip__action--primary{flex-basis:100%;justify-content:start}input.md-mdc-chip-input{flex:1 0 150px;margin-left:8px}[dir=rtl] input.md-mdc-chip-input{margin-left:0;margin-right:8px}.md-mdc-form-field input.md-mdc-chip-input::placeholder{opacity:1}.md-mdc-form-field input.md-mdc-chip-input::-moz-placeholder{opacity:1}.md-mdc-form-field input.md-mdc-chip-input::-webkit-input-placeholder{opacity:1}.md-mdc-form-field input.md-mdc-chip-input:-ms-input-placeholder{opacity:1}.md-mdc-chip-set+input.md-mdc-chip-input{margin-left:0;margin-right:0}
`], encapsulation: 2 });
    }
    return n;
})(), ln = class {
    source;
    value;
    constructor(a, e) { this.source = a, this.value = e; }
}, Ig = { provide: J, useExisting: A(() => Ng), multi: !0 }, Ng = (() => { class n extends Aa {
    _onTouched = () => { };
    _onChange = () => { };
    _defaultRole = "listbox";
    _defaultOptions = d(ei, { optional: !0 });
    get multiple() { return this._multiple; }
    set multiple(e) { this._multiple = e, this._syncListboxProperties(); }
    _multiple = !1;
    get selected() { let e = this._chips.toArray().filter(i => i.selected); return this.multiple ? e : e[0]; }
    ariaOrientation = "horizontal";
    get selectable() { return this._selectable; }
    set selectable(e) { this._selectable = e, this._syncListboxProperties(); }
    _selectable = !0;
    compareWith = (e, i) => e === i;
    required = !1;
    get hideSingleSelectionIndicator() { return this._hideSingleSelectionIndicator; }
    set hideSingleSelectionIndicator(e) { this._hideSingleSelectionIndicator = e, this._syncListboxProperties(); }
    _hideSingleSelectionIndicator = this._defaultOptions?.hideSingleSelectionIndicator ?? !1;
    get chipSelectionChanges() { return this._getChipStream(e => e.selectionChange); }
    get chipBlurChanges() { return this._getChipStream(e => e._onBlur); }
    get value() { return this._value; }
    set value(e) { this._chips && this._chips.length && this._setSelectionByValue(e, !1), this._value = e; }
    _value;
    change = new p;
    _chips = void 0;
    ngAfterContentInit() { this._chips.changes.pipe(z(null), O(this._destroyed)).subscribe(() => { this.value !== void 0 && Promise.resolve().then(() => { this._setSelectionByValue(this.value, !1); }), this._syncListboxProperties(); }), this.chipBlurChanges.pipe(O(this._destroyed)).subscribe(() => this._blur()), this.chipSelectionChanges.pipe(O(this._destroyed)).subscribe(e => { this.multiple || this._chips.forEach(i => { i !== e.source && i._setSelectedState(!1, !1, !1); }), e.isUserInput && this._propagateChanges(); }); }
    focus() { if (this.disabled)
        return; let e = this._getFirstSelectedChip(); e && !e.disabled ? e.focus() : this._chips.length > 0 ? this._keyManager.setFirstItemActive() : this._elementRef.nativeElement.focus(); }
    writeValue(e) { e != null ? this.value = e : this.value = void 0; }
    registerOnChange(e) { this._onChange = e; }
    registerOnTouched(e) { this._onTouched = e; }
    setDisabledState(e) { this.disabled = e; }
    _setSelectionByValue(e, i = !0) { this._clearSelection(), Array.isArray(e) ? e.forEach(o => this._selectValue(o, i)) : this._selectValue(e, i); }
    _blur() { this.disabled || setTimeout(() => { this.focused || this._markAsTouched(); }); }
    _keydown(e) { e.keyCode === Tn && super._allowFocusEscape(); }
    _markAsTouched() { this._onTouched(), this._changeDetectorRef.markForCheck(); }
    _propagateChanges() { let e = null; Array.isArray(this.selected) ? e = this.selected.map(i => i.value) : e = this.selected ? this.selected.value : void 0, this._value = e, this.change.emit(new ln(this, e)), this._onChange(e), this._changeDetectorRef.markForCheck(); }
    _clearSelection(e) { this._chips.forEach(i => { i !== e && i.deselect(); }); }
    _selectValue(e, i) { let o = this._chips.find(r => r.value != null && this.compareWith(r.value, e)); return o && (i ? o.selectViaInteraction() : o.select()), o; }
    _syncListboxProperties() { this._chips && Promise.resolve().then(() => { this._chips.forEach(e => { e._chipListMultiple = this.multiple, e.chipListSelectable = this._selectable, e._chipListHideSingleSelectionIndicator = this.hideSingleSelectionIndicator, e._changeDetectorRef.markForCheck(); }); }); }
    _getFirstSelectedChip() { return Array.isArray(this.selected) ? this.selected.length ? this.selected[0] : void 0 : this.selected; }
    _skipPredicate(e) { return !1; }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-chip-listbox"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Tg, 5), i & 2) {
            let s;
            t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._chips = s);
        } }, hostAttrs: [1, "mdc-evolution-chip-set", "md-mdc-chip-listbox"], hostVars: 10, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("focus", function () { return o.focus(); })("blur", function () { return o._blur(); })("keydown", function (s) { return o._keydown(s); }), i & 2 && (t.\u0275\u0275domProperty("tabIndex", o.disabled || o.empty ? -1 : o.tabIndex), t.\u0275\u0275attribute("role", o.role)("aria-required", o.role ? o.required : null)("aria-disabled", o.disabled.toString())("aria-multiselectable", o.multiple)("aria-orientation", o.ariaOrientation), t.\u0275\u0275classProp("md-mdc-chip-list-disabled", o.disabled)("md-mdc-chip-list-required", o.required)); }, inputs: { multiple: [2, "multiple", "multiple", m], ariaOrientation: [0, "aria-orientation", "ariaOrientation"], selectable: [2, "selectable", "selectable", m], compareWith: "compareWith", required: [2, "required", "required", m], hideSingleSelectionIndicator: [2, "hideSingleSelectionIndicator", "hideSingleSelectionIndicator", m], value: "value" }, outputs: { change: "change" }, features: [t.\u0275\u0275ProvidersFeature([Ig]), t.\u0275\u0275InheritDefinitionFeature], ngContentSelectors: T, decls: 2, vars: 0, consts: [["role", "presentation", 1, "mdc-evolution-chip-set__chips"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElementStart(0, "div", 0), t.\u0275\u0275projection(1), t.\u0275\u0275domElementEnd()); }, styles: [ha], encapsulation: 2 });
} return n; })(), cn = class {
    source;
    value;
    constructor(a, e) { this.source = a, this.value = e; }
}, Py = (() => { class n extends Aa {
    ngControl = d(Ln, { optional: !0, self: !0 });
    controlType = "md-chip-grid";
    _chipInput;
    _defaultRole = "grid";
    _errorStateTracker;
    _uid = d(W).getId("md-chip-grid-");
    _ariaDescribedbyIds = [];
    _onTouched = () => { };
    _onChange = () => { };
    get disabled() { return this.ngControl ? !!this.ngControl.disabled : this._disabled; }
    set disabled(e) { this._disabled = e, this._syncChipsState(), this.stateChanges.next(); }
    get id() { return this._chipInput ? this._chipInput.id : this._uid; }
    get empty() { return (!this._chipInput || this._chipInput.empty) && (!this._chips || this._chips.length === 0); }
    get placeholder() { return this._chipInput ? this._chipInput.placeholder : this._placeholder; }
    set placeholder(e) { this._placeholder = e, this.stateChanges.next(); }
    _placeholder;
    get focused() { return this._chipInput?.focused || this._hasFocusedChip(); }
    get required() { return this._required ?? this.ngControl?.control?.hasValidator(Bn.required) ?? !1; }
    set required(e) { this._required = e, this.stateChanges.next(); }
    _required;
    get shouldLabelFloat() { return !this.empty || this.focused; }
    get value() { return this._value; }
    set value(e) { this._value = e; }
    _value = [];
    get errorStateMatcher() { return this._errorStateTracker.matcher; }
    set errorStateMatcher(e) { this._errorStateTracker.matcher = e; }
    get chipBlurChanges() { return this._getChipStream(e => e._onBlur); }
    change = new p;
    valueChange = new p;
    _chips = void 0;
    stateChanges = new D;
    get errorState() { return this._errorStateTracker.errorState; }
    set errorState(e) { this._errorStateTracker.errorState = e; }
    constructor() { super(); let e = d(ta, { optional: !0 }), i = d(ia, { optional: !0 }), o = d(La); this.ngControl && (this.ngControl.valueAccessor = this), this._errorStateTracker = new mn(o, this.ngControl, i, e, this.stateChanges); }
    ngAfterContentInit() { this.chipBlurChanges.pipe(Ie(this._destroyed)).subscribe(() => { this._blur(), this.stateChanges.next(); }), R(this.chipFocusChanges, this._chips.changes).pipe(Ie(this._destroyed)).subscribe(() => this.stateChanges.next()); }
    ngDoCheck() { this.ngControl && this.updateErrorState(); }
    ngOnDestroy() { super.ngOnDestroy(), this.stateChanges.complete(); }
    registerInput(e) { this._chipInput = e, this._chipInput.setDescribedByIds(this._ariaDescribedbyIds), this._elementRef.nativeElement.removeAttribute("aria-describedby"); }
    onContainerClick(e) { !this.disabled && !this._originatesFromChip(e) && this.focus(); }
    focus() { if (!(this.disabled || this._chipInput?.focused)) {
        if (!this._chips.length || this._chips.first.disabled) {
            if (!this._chipInput)
                return;
            Promise.resolve().then(() => this._chipInput.focus());
        }
        else {
            let e = this._keyManager.activeItem;
            e ? e.focus() : this._keyManager.setFirstItemActive();
        }
        this.stateChanges.next();
    } }
    get describedByIds() { if (this._chipInput)
        return this._chipInput.describedByIds || []; let e = this._elementRef.nativeElement.getAttribute("aria-describedby"); return e ? e.split(" ") : []; }
    setDescribedByIds(e) { this._ariaDescribedbyIds = e, this._chipInput ? this._chipInput.setDescribedByIds(e) : e.length ? this._elementRef.nativeElement.setAttribute("aria-describedby", e.join(" ")) : this._elementRef.nativeElement.removeAttribute("aria-describedby"); }
    writeValue(e) { this._value = e; }
    registerOnChange(e) { this._onChange = e; }
    registerOnTouched(e) { this._onTouched = e; }
    setDisabledState(e) { this.disabled = e, this.stateChanges.next(); }
    updateErrorState() { this._errorStateTracker.updateErrorState(); }
    _blur() { this.disabled || setTimeout(() => { this.focused || (this._propagateChanges(), this._markAsTouched()); }); }
    _allowFocusEscape() { this._chipInput?.focused || super._allowFocusEscape(); }
    _handleKeydown(e) { let i = e.keyCode, o = this._keyManager.activeItem; if (i === Tn)
        this._chipInput?.focused && q(e, "shiftKey") && this._chips.length && !this._chips.last.disabled ? (e.preventDefault(), o ? this._keyManager.setActiveItem(o) : this._focusLastChip()) : super._allowFocusEscape();
    else if (!this._chipInput?.focused)
        if ((i === Fe || i === dt) && o) {
            let r = this._chipActions.filter(c => c._isPrimary === o._isPrimary && !this._skipPredicate(c)), s = r.indexOf(o), l = e.keyCode === Fe ? -1 : 1;
            e.preventDefault(), s > -1 && this._isValidIndex(s + l) && this._keyManager.setActiveItem(r[s + l]);
        }
        else
            super._handleKeydown(e); this.stateChanges.next(); }
    _focusLastChip() { this._chips.length && this._chips.last.focus(); }
    _propagateChanges() { let e = this._chips.length ? this._chips.toArray().map(i => i.value) : []; this._value = e, this.change.emit(new cn(this, e)), this.valueChange.emit(e), this._onChange(e), this._changeDetectorRef.markForCheck(); }
    _markAsTouched() { this._onTouched(), this._changeDetectorRef.markForCheck(), this.stateChanges.next(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-chip-grid"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Eg, 5), i & 2) {
            let s;
            t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._chips = s);
        } }, hostAttrs: [1, "md-mdc-chip-set", "md-mdc-chip-grid", "mdc-evolution-chip-set"], hostVars: 10, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("focus", function () { return o.focus(); })("blur", function () { return o._blur(); }), i & 2 && (t.\u0275\u0275attribute("role", o.role)("tabindex", o.disabled || o._chips && o._chips.length === 0 ? -1 : o.tabIndex)("aria-disabled", o.disabled.toString())("aria-invalid", o.errorState), t.\u0275\u0275classProp("md-mdc-chip-list-disabled", o.disabled)("md-mdc-chip-list-invalid", o.errorState)("md-mdc-chip-list-required", o.required)); }, inputs: { disabled: [2, "disabled", "disabled", m], placeholder: "placeholder", required: [2, "required", "required", m], value: "value", errorStateMatcher: "errorStateMatcher" }, outputs: { change: "change", valueChange: "valueChange" }, features: [t.\u0275\u0275InheritDefinitionFeature], ngContentSelectors: T, decls: 2, vars: 0, consts: [["role", "presentation", 1, "mdc-evolution-chip-set__chips"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElementStart(0, "div", 0), t.\u0275\u0275projection(1), t.\u0275\u0275domElementEnd()); }, styles: [ha], encapsulation: 2 });
} return n; })(), La = (() => { class n {
    isErrorState(e, i) { return !!(e && e.invalid && (e.touched || i && i.submitted)); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), mn = class {
    _defaultMatcher;
    ngControl;
    _parentFormGroup;
    _parentForm;
    _stateChanges;
    errorState = !1;
    matcher;
    constructor(a, e, i, o, r) { this._defaultMatcher = a, this.ngControl = e, this._parentFormGroup = i, this._parentForm = o, this._stateChanges = r; }
    updateErrorState() { let a = this.errorState, e = this._parentFormGroup || this._parentForm, i = this.matcher || this._defaultMatcher, o = this.ngControl ? this.ngControl.control : null, r = i?.isErrorState(o, e) ?? !1; r !== a && (this.errorState = r, this._stateChanges.next()); }
}, Oy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-chip-avatar"], ["", "mdChipAvatar", ""]], hostAttrs: ["role", "img", 1, "md-mdc-chip-avatar", "mdc-evolution-chip__icon", "mdc-evolution-chip__icon--primary"], features: [t.\u0275\u0275ProvidersFeature([{ provide: rn, useExisting: n }])] });
} return n; })(), Fy = (() => { class n extends Kn {
    _isPrimary = !1;
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-chip-trailing-icon"], ["", "mdChipTrailingIcon", ""]], hostAttrs: ["aria-hidden", "true", 1, "md-mdc-chip-trailing-icon", "mdc-evolution-chip__icon", "mdc-evolution-chip__icon--trailing"], features: [t.\u0275\u0275ProvidersFeature([{ provide: an, useExisting: n }]), t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), Ry = (() => { class n extends kt {
    _isPrimary = !1;
    _isLeading = !0;
    _handleClick(e) { this.disabled || (e.stopPropagation(), e.preventDefault(), this._parentChip._edit()); }
    _handleKeydown(e) { (e.keyCode === Q || e.keyCode === se) && !this.disabled && (e.stopPropagation(), e.preventDefault(), this._parentChip._edit()); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdChipEdit", ""]], hostAttrs: ["role", "button", 1, "md-mdc-chip-edit", "md-mdc-chip-avatar", "md-focus-indicator", "mdc-evolution-chip__icon", "mdc-evolution-chip__icon--primary"], hostVars: 1, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275attribute("aria-hidden", null); }, features: [t.\u0275\u0275ProvidersFeature([{ provide: sn, useExisting: n }]), t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), Ay = (() => { class n extends kt {
    _isPrimary = !1;
    _handleClick(e) { this.disabled || (e.stopPropagation(), e.preventDefault(), this._parentChip.remove()); }
    _handleKeydown(e) { (e.keyCode === Q || e.keyCode === se) && !this.disabled && (e.stopPropagation(), e.preventDefault(), this._parentChip.remove()); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdChipRemove", ""]], hostAttrs: ["role", "button", 1, "md-mdc-chip-remove", "md-mdc-chip-trailing-icon", "md-focus-indicator", "mdc-evolution-chip__icon", "mdc-evolution-chip__icon--trailing"], hostVars: 1, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275attribute("aria-hidden", null); }, features: [t.\u0275\u0275ProvidersFeature([{ provide: dn, useExisting: n }]), t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), Ly = (() => { class n {
    _elementRef = d(x);
    focused = !1;
    get chipGrid() { return this._chipGrid; }
    set chipGrid(e) { e && (this._chipGrid = e, this._chipGrid.registerInput(this)); }
    _chipGrid;
    addOnBlur = !1;
    separatorKeyCodes;
    chipEnd = new p;
    placeholder = "";
    id = d(W).getId("md-mdc-chip-list-input-");
    get disabled() { return this._disabled || this._chipGrid && this._chipGrid.disabled; }
    set disabled(e) { this._disabled = e; }
    _disabled = !1;
    readonly = !1;
    disabledInteractive;
    get empty() { return !this.inputElement.value; }
    inputElement;
    constructor() { let e = d(ei); this.inputElement = this._elementRef.nativeElement, this.separatorKeyCodes = e.separatorKeyCodes, this.disabledInteractive = e.inputDisabledInteractive ?? !1; }
    ngOnChanges() { this._chipGrid.stateChanges.next(); }
    ngOnDestroy() { this.chipEnd.complete(); }
    _keydown(e) { this.empty && e.keyCode === Hr ? (e.repeat || this._chipGrid._focusLastChip(), e.preventDefault()) : this._emitChipEnd(e); }
    _blur() { this.addOnBlur && this._emitChipEnd(), this.focused = !1, this._chipGrid.focused || this._chipGrid._blur(), this._chipGrid.stateChanges.next(); }
    _focus() { this.focused = !0, this._chipGrid.stateChanges.next(); }
    _emitChipEnd(e) { (!e || this._isSeparatorKey(e) && !e.repeat) && (this.chipEnd.emit({ input: this.inputElement, value: this.inputElement.value, chipInput: this }), e?.preventDefault()); }
    _onInput() { this._chipGrid.stateChanges.next(); }
    focus() { this.inputElement.focus(); }
    clear() { this.inputElement.value = ""; }
    get describedByIds() { return this._elementRef.nativeElement.getAttribute("aria-describedby")?.split(" ") || []; }
    setDescribedByIds(e) { let i = this._elementRef.nativeElement; e.length ? i.setAttribute("aria-describedby", e.join(" ")) : i.removeAttribute("aria-describedby"); }
    _isSeparatorKey(e) { if (!this.separatorKeyCodes)
        return !1; for (let i of this.separatorKeyCodes) {
        let o, r;
        typeof i == "number" ? (o = i, r = null) : (o = i.keyCode, r = i.modifiers);
        let s = r?.length ? q(e, ...r) : !q(e);
        if (o === e.keyCode && s)
            return !0;
    } return !1; }
    _getReadonlyAttribute() { return this.readonly || this.disabled && this.disabledInteractive ? "true" : null; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["input", "mdChipInputFor", ""]], hostAttrs: [1, "md-mdc-chip-input", "md-mdc-input-element", "mdc-text-field__input", "md-input-element"], hostVars: 8, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("keydown", function (s) { return o._keydown(s); })("blur", function () { return o._blur(); })("focus", function () { return o._focus(); })("input", function () { return o._onInput(); }), i & 2 && (t.\u0275\u0275domProperty("id", o.id), t.\u0275\u0275attribute("disabled", o.disabled && !o.disabledInteractive ? "" : null)("placeholder", o.placeholder || null)("aria-invalid", o._chipGrid && o._chipGrid.ngControl ? o._chipGrid.ngControl.invalid : null)("aria-required", o._chipGrid && o._chipGrid.required || null)("aria-disabled", o.disabled && o.disabledInteractive ? "true" : null)("readonly", o._getReadonlyAttribute())("required", o._chipGrid && o._chipGrid.required || null)); }, inputs: { chipGrid: [0, "mdChipInputFor", "chipGrid"], addOnBlur: [2, "mdChipInputAddOnBlur", "addOnBlur", m], separatorKeyCodes: [0, "mdChipInputSeparatorKeyCodes", "separatorKeyCodes"], placeholder: "placeholder", id: "id", disabled: [2, "disabled", "disabled", m], readonly: [2, "readonly", "readonly", m], disabledInteractive: [2, "mdChipInputDisabledInteractive", "disabledInteractive", m] }, outputs: { chipEnd: "mdChipInputTokenEnd" }, exportAs: ["mdChipInput", "mdChipInputFor"], features: [t.\u0275\u0275NgOnChangesFeature] });
} return n; })();
var By = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ providers: [La, { provide: ei, useValue: { separatorKeyCodes: [Q] } }], imports: [Qe] });
} return n; })(), Pg = (() => {
    class n {
        padding = "16px";
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-header-card"]], inputs: { padding: "padding" }, ngContentSelectors: T, decls: 2, vars: 2, consts: [[1, "md-header-card"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElementStart(0, "div", 0), t.\u0275\u0275projection(1), t.\u0275\u0275domElementEnd()), i & 2 && t.\u0275\u0275styleProp("padding", o.padding); }, styles: [`.md-header-card{display:flex;flex-direction:column;box-sizing:border-box;position:relative;border-style:solid;border-width:1px;background-color:var(--%NS%md-header-card-surface, #EAEAEA);border-color:var(--%NS%md-header-card-border-color, #F3F3F3);border-radius:var(--%NS%md-header-card-radius, 5px);height:100%;width:100%;font-family:var(--%NS%md-header-card-font-family, var(--%NS%md-font-heading, Montserrat))}
`], encapsulation: 2 });
    }
    return n;
})(), Og = (() => {
    class n {
        cards;
        _cdr = d(E);
        _cardCount = 0;
        gap = 8;
        padding = "responsive";
        minCardWidth = 300;
        maxCardWidth = 570;
        noWrap = !1;
        ngAfterContentInit() { this._cardCount = this.cards.length, this.cards.changes.subscribe(() => { this._cardCount = this.cards.length, this._cdr.markForCheck(); }); }
        get _containerStyles() { let e = { "--md-header-card-set-gap": `${this.gap}px`, "--md-header-card-min-width": `${this.minCardWidth}px`, "--md-header-card-max-width": `${this.maxCardWidth}px`, "--md-header-card-count": `${this._cardCount}` }; return typeof this.padding == "number" && (e["--md-header-card-set-padding"] = `${this.padding}px`), e; }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-header-card-set"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Pg, 4), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.cards = s);
            } }, hostAttrs: [1, "md-header-card-set"], hostVars: 2, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("md-header-card-set-nowrap", o.noWrap); }, inputs: { gap: "gap", padding: "padding", minCardWidth: "minCardWidth", maxCardWidth: "maxCardWidth", noWrap: [2, "noWrap", "noWrap", m] }, exportAs: ["mdHeaderCardSet"], ngContentSelectors: T, decls: 3, vars: 1, consts: [[1, "md-header-card-set-container", 3, "ngStyle"], [1, "md-header-card-set-wrapper"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275elementStart(0, "div", 0)(1, "div", 1), t.\u0275\u0275projection(2), t.\u0275\u0275elementEnd()()), i & 2 && t.\u0275\u0275property("ngStyle", o._containerStyles); }, dependencies: [ae, Re.NgStyle], styles: [`.md-header-card-set{display:block;width:100%;position:relative;box-sizing:border-box}.md-header-card-set-container{position:relative;width:100%;box-sizing:border-box}.md-header-card-set-wrapper{--%NS%_card-min: var(--%NS%md-header-card-min-width, 300px);--%NS%_card-max: var(--%NS%md-header-card-max-width, 570px);--%NS%_gap: var(--%NS%md-header-card-set-gap, 16px);display:grid;min-width:0;max-width:calc(var(--%NS%md-header-card-count, 1) * var(--%NS%md-header-card-max-width, 570px));box-sizing:border-box}@media(max-width:767px){.md-header-card-set-wrapper{display:flex;gap:var(--%NS%_gap);flex-wrap:wrap;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch}.md-header-card-set-wrapper::-webkit-scrollbar{height:6px}.md-header-card-set-wrapper::-webkit-scrollbar-track{background:var(--%NS%md-scrollbar-track-color, #f1f1f1);border-radius:4px}.md-header-card-set-wrapper::-webkit-scrollbar-thumb{background:var(--%NS%md-scrollbar-thumb-color, #888);border-radius:4px}.md-header-card-set-wrapper::-webkit-scrollbar-thumb:hover{background:var(--%NS%md-scrollbar-thumb-hover-color, #555)}.md-header-card-set-wrapper md-header-card{width:-webkit-fill-available}}@media(min-width:768px){.md-header-card-set-wrapper{display:grid;gap:var(--%NS%_gap);grid-template-columns:repeat(auto-fit,minmax(var(--%NS%_card-min),1fr))}.md-header-card-set-wrapper md-header-card{max-width:var(--%NS%_card-max);justify-self:stretch}}.md-header-card-set-nowrap .md-header-card-set-wrapper{display:flex;flex-wrap:nowrap;overflow-x:auto;scroll-snap-type:x mandatory;grid-template-columns:unset}.md-header-card-set-nowrap .md-header-card-set-wrapper md-header-card{flex:0 0 auto;scroll-snap-align:start;min-width:var(--%NS%_card-min);max-width:var(--%NS%_card-max)}
`], encapsulation: 2 });
    }
    return n;
})(), zy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [ae, Og] });
} return n; })(), Fg = (() => {
    class n {
        offset = 0;
        limit = 10;
        count = 0;
        height = 40;
        showFirstLast = !0;
        pageSizeOptions = [];
        page = new p;
        pageSizeChange = new p;
        get totalPages() { return Math.ceil(this.count / this.limit) || 0; }
        get currentPage() { return this.offset + 1; }
        setPage(e) { let i = Math.max(0, this.totalPages - 1), o = Math.max(0, Math.min(e, i)); o !== this.offset && this.page.emit({ offset: o, limit: this.limit, count: this.count, pageSize: this.limit }); }
        firstPage() { this.setPage(0); }
        prevPage() { this.setPage(this.offset - 1); }
        nextPage() { this.setPage(this.offset + 1); }
        lastPage() { this.setPage(this.totalPages - 1); }
        onPageSizeChange(e) { let i = e.target, o = Number(i.value); o > 0 && o !== this.limit && this.pageSizeChange.emit(o); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-paginator"]], hostAttrs: [1, "md-paginator"], inputs: { offset: [2, "offset", "offset", S], limit: [2, "limit", "limit", S], count: [2, "count", "count", S], height: [2, "height", "height", S], showFirstLast: [2, "showFirstLast", "showFirstLast", m], pageSizeOptions: "pageSizeOptions" }, outputs: { page: "page", pageSizeChange: "pageSizeChange" }, exportAs: ["mdPaginator"], decls: 1, vars: 1, consts: [[1, "md-paginator-inner", 3, "height"], [1, "md-paginator-inner"], [1, "md-paginator-page-size"], [1, "md-paginator-pager"], ["type", "button", "title", "First page", 1, "md-paginator-btn", 3, "disabled"], ["type", "button", "title", "Previous page", 1, "md-paginator-btn", 3, "click", "disabled"], [1, "md-paginator-icon-prev"], [1, "md-paginator-info"], ["type", "button", "title", "Next page", 1, "md-paginator-btn", 3, "click", "disabled"], [1, "md-paginator-icon-next"], ["type", "button", "title", "Last page", 1, "md-paginator-btn", 3, "disabled"], [1, "md-paginator-page-size-label"], [1, "md-paginator-page-size-select", 3, "change", "value"], [3, "value", "selected"], ["type", "button", "title", "First page", 1, "md-paginator-btn", 3, "click", "disabled"], [1, "md-paginator-icon-first"], ["type", "button", "title", "Last page", 1, "md-paginator-btn", 3, "click", "disabled"], [1, "md-paginator-icon-last"]], template: function (i, o) { i & 1 && t.\u0275\u0275conditionalCreate(0, em, 11, 9, "div", 0), i & 2 && t.\u0275\u0275conditional(o.totalPages > 1 ? 0 : -1); }, styles: [`.md-paginator{display:block;width:100%;padding-right:10px;margin-bottom:10px;font-family:var(--%NS%md-paginator-font-family, var(--%NS%md-font-body, Open Sans, Arial, sans-serif));font-size:12px;background:var(--%NS%md-paginator-background, transparent)}.md-paginator *,.md-paginator *:before,.md-paginator *:after{box-sizing:border-box}.md-paginator-inner{display:flex;align-items:center;justify-content:flex-end;padding:12px 0 0;background:var(--%NS%md-paginator-background, transparent);border-top:0;color:var(--%NS%md-paginator-color, #4D4D4D)}.md-paginator-pager{display:flex;align-items:center;gap:4px}.md-paginator-btn{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:1px solid var(--%NS%md-paginator-button-border-color, #EAEAEA);border-radius:var(--%NS%md-paginator-button-radius, var(--%NS%md-radius-sm, 4px));background:var(--%NS%md-paginator-button-background, #FFFFFF);color:var(--%NS%md-paginator-color, #4D4D4D);cursor:pointer;transition:background-color .15s ease,border-color .15s ease}.md-paginator-btn:hover:not(:disabled){background:var(--%NS%md-paginator-button-hover-background, #F3F3F3);border-color:var(--%NS%md-paginator-button-hover-border-color, #929292)}.md-paginator-btn:disabled{opacity:.4;cursor:not-allowed}.md-paginator-btn:focus{outline:2px solid var(--%NS%md-color-focus, #6d5cae);outline-offset:1px}.md-paginator-info{padding:0 12px;font-weight:500}.md-paginator-page-size{display:flex;align-items:center;gap:6px;margin-right:auto}.md-paginator-page-size-label{color:var(--%NS%md-paginator-color, #4D4D4D);white-space:nowrap}.md-paginator-page-size-select{height:28px;padding:0 24px 0 8px;border:1px solid var(--%NS%md-paginator-button-border-color, #EAEAEA);border-radius:var(--%NS%md-paginator-button-radius, var(--%NS%md-radius-sm, 4px));background:var(--%NS%md-paginator-button-background, #FFFFFF);color:var(--%NS%md-paginator-color, #4D4D4D);font-family:var(--%NS%md-paginator-font-family, var(--%NS%md-font-body, Open Sans, Arial, sans-serif));font-size:12px;cursor:pointer;outline:none;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%23666' stroke-width='1.5' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 6px center}.md-paginator-page-size-select:hover{border-color:var(--%NS%md-paginator-button-hover-border-color, #929292)}.md-paginator-page-size-select:focus{border-color:var(--%NS%md-color-focus, #6d5cae);outline:2px solid var(--%NS%md-color-focus, #6d5cae);outline-offset:1px}.md-paginator-icon-first,.md-paginator-icon-prev,.md-paginator-icon-next,.md-paginator-icon-last{display:inline-block;width:12px;height:12px;position:relative}.md-paginator-icon-first:before,.md-paginator-icon-prev:before,.md-paginator-icon-next:before,.md-paginator-icon-last:before{content:"";position:absolute;width:6px;height:6px;border-right:2px solid currentColor;border-bottom:2px solid currentColor;top:50%;left:50%}.md-paginator-icon-prev:before{transform:translate(-25%,-50%) rotate(135deg)}.md-paginator-icon-next:before{transform:translate(-75%,-50%) rotate(-45deg)}.md-paginator-icon-first:before{transform:translate(-10%,-50%) rotate(135deg)}.md-paginator-icon-first:after{content:"";position:absolute;width:2px;height:10px;background:currentColor;top:50%;left:2px;transform:translateY(-50%)}.md-paginator-icon-last:before{transform:translate(-90%,-50%) rotate(-45deg)}.md-paginator-icon-last:after{content:"";position:absolute;width:2px;height:10px;background:currentColor;top:50%;right:2px;transform:translateY(-50%)}
`], encapsulation: 2 });
    }
    return n;
})(), Z = (function (n) { return n.asc = "asc", n.desc = "desc", n.none = "", n; })(Z || {}), hn = (function (n) { return n.single = "single", n.multi = "multi", n; })(hn || {}), Rg = 0;
function Ag() { return `cards-grid-col-${Rg++}`; }
function Lg(n, a) { if (!a)
    return n; let e = a.split("."), i = n; for (let o of e) {
    if (i == null)
        return;
    i = i[o];
} return i; }
function Bg(n, a) { let e = new Map; for (let i of n) {
    let o = typeof a == "function" ? a(i) : i[a];
    e.has(o) || e.set(o, []), e.get(o).push(i);
} return Array.from(e.entries()).map(([i, o]) => ({ key: i, value: o })); }
function zg(n, a, e) { if (!a || a.length === 0)
    return n; let i = [...n]; return i.sort((o, r) => { for (let s of a) {
    if (!s.dir)
        continue;
    let l = e.find(u => u.prop === s.prop);
    if (!l)
        continue;
    let c = l.getValue(o), h = l.getValue(r), g;
    if (l.comparator ? g = l.comparator(c, h, o, r, s.dir) : g = Vg(c, h), g !== 0)
        return s.dir === Z.desc ? -g : g;
} return 0; }), i; }
function Vg(n, a) { return n == null && a == null ? 0 : n == null ? -1 : a == null ? 1 : typeof n == "string" && typeof a == "string" ? n.localeCompare(a) : n < a ? -1 : n > a ? 1 : 0; }
function Hg(n, a = !1) { if (!n)
    return Z.asc; if (n === Z.asc)
    return Z.desc; if (!a)
    return Z.asc; }
var jg = (() => { class n {
    static ngTemplateContextGuard(e, i) { return !0; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdGridCellTemplate", ""]] });
} return n; })(), Wg = (() => { class n {
    static ngTemplateContextGuard(e, i) { return !0; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdGridHeaderTemplate", ""]] });
} return n; })(), Gg = (() => { class n {
    static ngTemplateContextGuard(e, i) { return !0; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdGridEditTemplate", ""]] });
} return n; })(), $g = 200, at = (() => { class n {
    columnId;
    name;
    prop;
    mobileRole = "data";
    width;
    minWidth = 36;
    maxWidth = Number.MAX_SAFE_INTEGER;
    flex = 0;
    suppressSizeToFit = !1;
    suppressAutoSize = !1;
    resizeable = !0;
    pinned = null;
    sortable = !1;
    comparator;
    pipe;
    headerClass;
    cellClass;
    cellTemplate;
    colDefChange = new p;
    contentCellTemplate;
    get resolvedCellTemplate() { return this.cellTemplate || this.contentCellTemplate; }
    headerTemplate;
    contentHeaderTemplate;
    get resolvedHeaderTemplate() { return this.headerTemplate || this.contentHeaderTemplate; }
    editTemplate;
    contentEditTemplate;
    get resolvedEditTemplate() { return this.editTemplate || this.contentEditTemplate; }
    flexOverridden = !1;
    get resolvedFlex() { return this.flexOverridden ? null : this.flex; }
    actualWidth = 0;
    $$id = Ag();
    getValue(e) { return this.prop ? Lg(e, this.prop) : void 0; }
    ngOnInit() { this.resetActualWidth("gridInitializing"); }
    ngOnChanges(e) { (e.width || e.minWidth || e.maxWidth) && this.resetActualWidth("gridInitializing"), this.colDefChange.emit(); }
    getActualWidth() { return this.actualWidth; }
    setActualWidth(e, i) { e = Math.max(e, this.minWidth), e = Math.min(e, this.maxWidth), i !== "flex" && i !== "gridInitializing" && (this.flexOverridden = !0), this.actualWidth = e; }
    resetActualWidth(e) { let i = this.calculateColInitialWidth(); this.setActualWidth(i, e); }
    calculateColInitialWidth() { let e = this.width ?? $g; return Math.max(Math.min(e, this.maxWidth), this.minWidth); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-grid-column"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, jg, 5, H)(r, Wg, 5, H)(r, Gg, 5, H), i & 2) {
            let s;
            t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.contentCellTemplate = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.contentHeaderTemplate = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.contentEditTemplate = s.first);
        } }, inputs: { columnId: "columnId", name: "name", prop: "prop", mobileRole: "mobileRole", width: [2, "width", "width", S], minWidth: [2, "minWidth", "minWidth", e => Pe(e, 36)], maxWidth: [2, "maxWidth", "maxWidth", e => Pe(e, Number.MAX_SAFE_INTEGER)], flex: [2, "flex", "flex", e => Pe(e, 0)], suppressSizeToFit: [2, "suppressSizeToFit", "suppressSizeToFit", m], suppressAutoSize: [2, "suppressAutoSize", "suppressAutoSize", m], resizeable: [2, "resizeable", "resizeable", m], pinned: "pinned", sortable: [2, "sortable", "sortable", m], comparator: "comparator", pipe: "pipe", headerClass: "headerClass", cellClass: "cellClass", cellTemplate: "cellTemplate", headerTemplate: "headerTemplate", editTemplate: "editTemplate" }, outputs: { colDefChange: "colDefChange" }, features: [t.\u0275\u0275NgOnChangesFeature] });
} return n; })(), Vy = (() => { class n {
    column;
    constructor(e) { this.column = e; }
    ngOnInit() { this.column && (this.column.mobileRole = "id"); }
    static \u0275fac = function (i) { return new (i || n)(t.\u0275\u0275directiveInject(at, 9)); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-grid-column", "mdGridIdColumn", ""]] });
} return n; })(), Hy = (() => { class n {
    column;
    constructor(e) { this.column = e; }
    ngOnInit() { this.column && (this.column.mobileRole = "actions"); }
    static \u0275fac = function (i) { return new (i || n)(t.\u0275\u0275directiveInject(at, 9)); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["md-grid-column", "mdGridActionsColumn", ""]] });
} return n; })(), Yg = (() => { class n {
    templateRef;
    constructor(e) { this.templateRef = e; }
    static \u0275fac = function (i) { return new (i || n)(t.\u0275\u0275directiveInject(t.TemplateRef)); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdGridToolbarTemplate", ""]] });
} return n; })();
function Vi(n, a, e) { if (!n)
    return; let i = -1; if (e) {
    let u = new Set(e);
    for (let f = a.length - 1; f >= 0; f--)
        if (u.has(a[f])) {
            i = f;
            break;
        }
} let o = !1, r = a.map((u, f) => { let v = u.resolvedFlex, w = !!v && v > 0 && f > i; return o ||= w, { col: u, isFlex: w, flex: Math.max(0, v ?? 0), initialSize: u.getActualWidth(), min: u.minWidth, max: u.maxWidth, targetSize: 0 }; }); if (!o)
    return; let s = r.length, l = r.reduce((u, f) => u + f.flex, 0), c = n, h = (u, f) => { u.frozenSize = f, u.col.setActualWidth(f, "flex"), c -= f, l -= u.flex, s -= 1; }, g = u => u.frozenSize != null; for (let u of r)
    u.isFlex || h(u, u.initialSize); for (; s > 0;) {
    let u = Math.round(l < 1 ? c * l : c), f, v = 0, w = 0;
    for (let y of r) {
        if (g(y))
            continue;
        f = y, w += u * (y.flex / l);
        let ee = w - v, U = Math.round(ee);
        y.targetSize = U, v += U;
    }
    f && (f.targetSize += u - v);
    let N = 0;
    for (let y of r) {
        if (g(y))
            continue;
        let ee = y.targetSize, U = Math.min(Math.max(ee, y.min), y.max);
        N += U - ee, y.violationType = U === ee ? void 0 : U < ee ? "max" : "min", y.targetSize = U;
    }
    let M = N === 0 ? "all" : N > 0 ? "min" : "max";
    for (let y of r)
        g(y) || (M === "all" || y.violationType === M) && h(y, y.targetSize);
} }
function Hi(n) { return n.reduce((a, e) => a + e.getActualWidth(), 0); }
function qg(n, a) { let e = n.indexOf(a); e >= 0 && n.splice(e, 1); }
function ji(n, a, e, i, o) { if (n <= 0 || !a.length)
    return; let r = Hi(a); if (o && r > n || n === r && a.every(v => { if (v.suppressSizeToFit)
    return !0; let w = v.minWidth || e, N = v.maxWidth || i, M = v.getActualWidth(); return (w == null || M >= w) && (N == null || M <= N); }))
    return; let l = [], c = []; for (let f of a)
    f.suppressSizeToFit ? c.push(f) : l.push(f); let h = !1, g = {}, u = f => { qg(l, f), c.push(f); }; for (let f of l) {
    o && (g[f.$$id] = f.getActualWidth()), f.resetActualWidth("autosizeColumns");
    let v = e ?? -1 / 0, w = i ?? 1 / 0, N = f.getActualWidth(), M = Math.max(Math.min(N, w), v);
    M != N && f.setActualWidth(M, "autosizeColumns");
} for (; !h;) {
    h = !0;
    let f = n - Hi(c);
    if (f <= 0)
        for (let v of l) {
            let w = e ?? v.minWidth;
            v.setActualWidth(w, "autosizeColumns");
        }
    else {
        let v = f / Hi(l), w = f;
        for (let N = l.length - 1; N >= 0; N--) {
            let M = l[N], y = e ?? g[M.$$id], ee = i, U = Math.max(y ?? -1 / 0, M.minWidth), Ke = Math.min(ee ?? 1 / 0, M.maxWidth), X = Math.round(M.getActualWidth() * v);
            X < U ? (X = U, u(M), h = !1) : X > Ke ? (X = Ke, u(M), h = !1) : N === 0 && (X = w), M.setActualWidth(X, "autosizeColumns"), w -= X;
        }
    }
} }
function Qg(n, a) { let e = document.createElement("form"); e.style.position = "fixed", e.append(document.createElement("tr")); for (let o of n)
    e.append(o); a.appendChild(e); let i = Math.ceil(e.getBoundingClientRect().width); return e.remove(), i; }
function Wi(n, a, e = {}) { let i = e.minWidth ?? n.minWidth; a < i && (a = i); let o = e.maxWidth ?? n.maxWidth; return a > o && (a = o), a; }
var Kg = (() => {
    class n {
        _cdr = d(E);
        host = d(x);
        zone = d(K);
        document = d(Ut);
        destroyRef = d(Or);
        isBrowser = _d(d(wd));
        destroyed = !1;
        resizeObserver;
        resizePointerId;
        loading = !1;
        loadingMessage = "Loading\u2026";
        error = null;
        retryLabel = "Try again";
        loadingTemplate;
        errorTemplate;
        retry = new p;
        retryLoad = () => this.retry.emit();
        columnState = [];
        columnStateChange = new p;
        columnStateKey;
        showColumnChooser = !1;
        columnsLabel = "Columns";
        selectable = !1;
        selectedKeys = [];
        selectedKeysChange = new p;
        selectPageLabel = "Select all rows on this page";
        selectRowLabel = "Select row";
        rowSelectable = () => !0;
        get allColumns() { return this._columnDirectives?.toArray() ?? []; }
        columnId(e) { return e.columnId || e.prop || e.$$id; }
        isColumnHidden(e) { return this.columnState.some(i => i.id === this.columnId(e) && i.hidden); }
        setColumnVisible(e, i) { if (!i && this.columns.length <= 1)
            return; let o = this.columnId(e); this.columnState = [...this.columnState.filter(r => r.id !== o), { id: o, width: e.actualWidth, hidden: !i }], this.publishColumnState(), this.refreshFlexedLayout(); }
        restoreColumnState() { if (this.isBrowser && this.columnStateKey)
            try {
                let e = JSON.parse(this.document.defaultView?.localStorage.getItem(this.columnStateKey) || "null");
                Array.isArray(e) && (this.columnState = e.filter(i => i && typeof i.id == "string").map(i => ({ id: i.id, hidden: i.hidden === !0, width: typeof i.width == "number" && Number.isFinite(i.width) && i.width > 0 ? i.width : void 0 })));
            }
            catch { } this.applyColumnState(); }
        applyColumnState() { for (let e of this.allColumns) {
            let i = this.columnState.find(o => o.id === this.columnId(e));
            i?.width != null && Number.isFinite(i.width) && e.setActualWidth(Wi(e, i.width), "uiColumnResized");
        } if (this.allColumns.length && this.allColumns.every(e => this.isColumnHidden(e))) {
            let e = this.columnId(this.allColumns[0]);
            this.columnState = this.columnState.map(i => i.id === e ? G(_({}, i), { hidden: !1 }) : i);
        } }
        publishColumnState() { if (this.columnState = this.allColumns.map(e => ({ id: this.columnId(e), width: e.actualWidth, hidden: this.isColumnHidden(e) })), this.columnStateChange.emit(this.columnState.map(e => _({}, e))), this.isBrowser && this.columnStateKey)
            try {
                this.document.defaultView?.localStorage.setItem(this.columnStateKey, JSON.stringify(this.columnState));
            }
            catch { } }
        get selectionEnabled() { return this.selectable && this.trackByKey != null; }
        isRowSelected(e) { return this.trackByKey != null && this.selectedKeys.includes(e[this.trackByKey]); }
        get selectablePageRows() { return this._displayRows.filter(e => this.rowSelectable(e)); }
        get pageSelected() { return this.selectablePageRows.length > 0 && this.selectablePageRows.every(e => this.isRowSelected(e)); }
        get pagePartiallySelected() { return !this.pageSelected && this.selectablePageRows.some(e => this.isRowSelected(e)); }
        toggleRow(e, i) { if (!this.selectionEnabled || !this.rowSelectable(e))
            return; let o = e[this.trackByKey]; this.selectedKeys = i ? [...new Set([...this.selectedKeys, o])] : this.selectedKeys.filter(r => r !== o), this.selectedKeysChange.emit([...this.selectedKeys]); }
        togglePage(e) { if (!this.selectionEnabled)
            return; let i = this.selectablePageRows.map(o => o[this.trackByKey]); this.selectedKeys = e ? [...new Set([...this.selectedKeys, ...i])] : this.selectedKeys.filter(o => !i.includes(o)), this.selectedKeysChange.emit([...this.selectedKeys]); }
        ariaLabel = "Data table";
        resizeLabel = "Resize column";
        rowActionsWidth = 100;
        rows = [];
        trackByKey = null;
        rowsChange = new p;
        groupRowsBy;
        groupHeaderTemplate;
        rowActionsTemplate;
        headerHeight = 46;
        cellTabNavigation = !1;
        cardHeight = "auto";
        gap = 5;
        defaultColumnWidth = 150;
        showRowActions = !0;
        emptyMessage = "No items to display";
        emptyTemplate;
        enableColumnResize = !1;
        defaultMinColumnWidth = 50;
        defaultMaxColumnWidth = 500;
        columnResize = new p;
        sorts = [];
        sortsChange = new p;
        sortType = hn.single;
        mdSortActive;
        mdSortDirection;
        externalSorting = !1;
        enableClearingSortState = !1;
        sortAscendingIcon;
        sortDescendingIcon;
        sortUnsetIcon;
        sortLabel = "Sort by";
        get mobileSortColumns() { return this.columns.filter(e => e.sortable && !!e.prop); }
        sort = new p;
        limit = 15;
        offset = 0;
        count;
        externalPaging = !1;
        showFooter = !0;
        footerHeight = 40;
        autosizeStrategy;
        pageSizeOptions = [];
        page = new p;
        pageSizeChange = new p;
        editingRow = null;
        editingRowChange = new p;
        rowEditStart = new p;
        rowEditSave = new p;
        rowEditCancel = new p;
        inited = new p;
        firstTimeVisible = new p;
        layoutReady = new p;
        _columnDirectives;
        toolbarTemplate;
        columns__ = Sn(at);
        columnsObs = mr(this.columns__);
        _displayRows = [];
        _groupedRows = null;
        _originalEditRow = null;
        originalEditSnapshot = null;
        _editingRowCopy = null;
        _editingRowIndex = -1;
        _resizingColumn = null;
        _resizeStartX = 0;
        _resizeStartWidth = 0;
        get totalSpace() { return Math.max(0, this.host.nativeElement.clientWidth - this.scrollbarWidth - (this.showRowActions ? this.rowActionsWidth : 0)); }
        get columns() { let e = this.allColumns.filter(i => !this.isColumnHidden(i)); return [...e.filter(i => i.pinned === "left"), ...e.filter(i => !i.pinned), ...e.filter(i => i.pinned === "right")]; }
        get hasPinnedColumns() { return this.columns.some(e => !!e.pinned); }
        get hasRightPinnedColumns() { return this.columns.some(e => e.pinned === "right"); }
        get scrollbarWidth() { let e = this.bodyScroll?.nativeElement; return e ? Math.max(0, e.offsetWidth - e.clientWidth) : 0; }
        getPinnedOffset(e) { if (!e.pinned)
            return null; let i = this.columns.filter(s => s.pinned === e.pinned), o = i.indexOf(e); return (e.pinned === "left" ? i.slice(0, o) : i.slice(o + 1)).reduce((s, l) => s + l.actualWidth, e.pinned === "right" && this.showRowActions ? this.rowActionsWidth : 0); }
        getHeaderClass(e) { return typeof e.headerClass == "function" ? e.headerClass({ column: e }) : e.headerClass; }
        getCellClass(e, i) { return typeof i.cellClass == "function" ? i.cellClass({ row: e, column: i, value: i.getValue(e) }) : i.cellClass; }
        get toolbarContext() { return { $implicit: this, grid: this }; }
        gridInited = !1;
        get actualWidthSum() { return this.columns.reduce((e, i) => e + i.actualWidth, this.showRowActions ? this.rowActionsWidth : 0); }
        ngAfterContentInit() { return oi(this, null, function* () { yield this.waitForFonts(), !this.destroyed && (this._processRows(), this.syncSortState(), this.gridInited = !0, this._cdr.detectChanges(), this.isBrowser && (this.applyInitialColumnSizing(), this.restoreColumnState(), this._cdr.detectChanges(), this.observeGridResize(), this.watchColumnDefinitions(), this.syncScroll(), this.inited.emit(!0))); }); }
        waitForFonts() { return oi(this, null, function* () { this.isBrowser && (yield this.document.fonts?.ready); }); }
        observeGridResize() { let e = this.totalSpace, i = !0; typeof ResizeObserver > "u" || (this.resizeObserver = new ResizeObserver(([o]) => { if (this.destroyed)
            return; let r = o.contentRect.width, s = this.updateScrollState(); if (r > 0 && i) {
            this.firstTimeVisible.emit(), this.refreshLayoutAfterConsumerSizing(), this.layoutReady.emit(!0), i = !1, e = this.totalSpace, this.refreshFlexedLayout();
            return;
        } let l = this.totalSpace; Math.abs(l - e) < .5 && !s || (e = l, this.refreshFlexedLayout()); }), this.resizeObserver.observe(this.host.nativeElement)); }
        watchColumnDefinitions() { this.columnsObs.pipe(Ui(e => { let i = e.map(o => o.colDefChange); return R(...i).pipe(Ki(void 0)); }), ot(this.destroyRef)).subscribe(() => { cancelAnimationFrame(this.requestAnimationFrameId), this.requestAnimationFrameId = requestAnimationFrame(() => { this.destroyed || (this.applyColumnState(), this.syncSortState(), this._processRows(), this.refreshFlexedLayout()); }); }); }
        sizeColumnsToFit() { ji(this.totalSpace, this.columns, null, null, !1), this.updateScrollState(), this._cdr.markForCheck(); }
        autoSize() { this.sizeToFitCellContents(null, null), ji(this.totalSpace, this.columns, null, null, !0), this.updateScrollState(), this._cdr.markForCheck(); }
        resetFlexSizing() { for (let e of this.columns)
            e.flexOverridden = !1, e.resetActualWidth("gridInitializing"); this.refreshFlexedLayout(); }
        sizeToFitCellContents(e, i) { let o = this.cells(), s = this.columns.length; for (let l = 0; l < s; l++) {
            let c = [];
            for (let u = l; u < o.length; u += s) {
                let v = o[u].nativeElement.cloneNode(!0);
                v.style.width = "unset", v.style.position = "static", v.style.left = "", c.push(v);
            }
            let h = this.columns[l], g = Qg(c, this.host.nativeElement);
            if (g > 0) {
                let u = {};
                e && (u.minWidth = e), i && (u.maxWidth = i);
                let f = Wi(h, g, u);
                h.setActualWidth(f, "autosizeColumns");
            }
        } this._cdr.markForCheck(); }
        ngOnChanges(e) { (e.mdSortActive || e.mdSortDirection) && (this.sorts = this.mdSortActive && (this.mdSortDirection === "asc" || this.mdSortDirection === "desc") ? [{ prop: this.mdSortActive, dir: this.mdSortDirection }] : []), (e.sorts || e.mdSortActive || e.mdSortDirection) && this.syncSortState(), ["rows", "sorts", "limit", "offset", "groupRowsBy", "externalSorting", "externalPaging", "mdSortActive", "mdSortDirection"].some(i => e[i]) && this._processRows(), e.columnStateKey && this.gridInited ? this.restoreColumnState() : e.columnState && this.applyColumnState(), e.editingRow && this._handleEditingRowChange(); }
        hasHorizontalScroll = !1;
        hasVerticalScroll = !1;
        applyInitialColumnSizing() { this.updateScrollState(), this.autosizeStrategy === "fitCellContents" ? this.sizeToFitCellContents(null, null) : this.autosizeStrategy === "fitGridWidth" ? ji(this.totalSpace, this.columns, null, null, !1) : Vi(this.totalSpace, this.columns), this.updateScrollState(), this._cdr.detectChanges(); }
        refreshLayoutAfterConsumerSizing() { this.updateScrollState(), this._cdr.detectChanges(); }
        refreshFlexedLayout(e = this.totalSpace) { this.destroyed || !this.bodyScroll || (Vi(e, this.columns), this.updateScrollState(), this._cdr.detectChanges()); }
        updateScrollState() { let e = this.bodyScroll?.nativeElement; if (!e)
            return !1; let i = e.scrollHeight > e.clientHeight, o = e.scrollWidth > e.clientWidth, r = this.hasVerticalScroll !== i || this.hasHorizontalScroll !== o; return this.hasVerticalScroll = i, this.hasHorizontalScroll = o, r; }
        ngOnDestroy() { this.destroyed = !0, this.resizeObserver?.disconnect(), this.isBrowser && cancelAnimationFrame(this.requestAnimationFrameId), this.removeResizeListeners(), this._resizingColumn = null, this.destroyFns.splice(0).forEach(e => e()); }
        editRow(e) { let i = typeof e == "number" ? e : this._displayRows.indexOf(e), o = typeof e == "number" ? this._displayRows[e] : e; i < 0 || !o || (this._editingRowCopy && this.cancelEdit(), this._originalEditRow = o, this.originalEditSnapshot = structuredClone(o), this._editingRowCopy = structuredClone(o), this._editingRowIndex = i, this.editingRow = o, this.editingRowChange.emit(o), this.rowEditStart.emit({ row: o, rowIndex: i }), this._cdr.markForCheck()); }
        saveRow(e) { if (!this._editingRowCopy || this._editingRowIndex < 0)
            return; let i = structuredClone(e || this._editingRowCopy), o = this.originalEditSnapshot, r = this._editingRowIndex, s = this.rows.indexOf(this._originalEditRow); s >= 0 && (this.rows = this.rows.map((l, c) => c === s ? i : l), this.rowsChange.emit(this.rows)), this.rowEditSave.emit({ row: i, rowIndex: r, originalRow: o }), this._clearEditState(), this._processRows(), this._cdr.markForCheck(); }
        cancelEdit() { this._editingRowCopy && (this.rowEditCancel.emit({ row: this._originalEditRow, rowIndex: this._editingRowIndex }), this._clearEditState(), this._cdr.markForCheck()); }
        isEditing(e) { return this._originalEditRow === e; }
        getEditingCopy(e) { return this._originalEditRow === e ? this._editingRowCopy : null; }
        currentSortCol = null;
        currentSortDirection = void 0;
        start = Z.asc;
        syncSortState() { let e = this.sorts.find(i => !!i.dir); this.currentSortCol = this.columns.find(i => i.prop === e?.prop) ?? null, this.currentSortDirection = e?.dir; }
        onColumnSort(e) { if (!e.sortable || !e.prop)
            return; let i = Hg(this.getSortDir(e), this.enableClearingSortState) ?? Z.none, o = this.sortType === hn.multi ? this.sorts.filter(s => !!s.dir).map(s => _({}, s)) : [], r = o.findIndex(s => s.prop === e.prop); r >= 0 ? i ? o[r] = { prop: e.prop, dir: i } : o.splice(r, 1) : i && o.push({ prop: e.prop, dir: i }), this.sorts = o, this.currentSortCol = e, this.currentSortDirection = i, this.mdSortActive = e.prop, this.mdSortDirection = i, this._processRows(), this.sortsChange.emit(o.map(s => _({}, s))), this.sort.emit({ active: e.prop, direction: i, sorts: o.map(s => _({}, s)) }); }
        getSortDir(e) { return this.sorts.find(i => i.prop === e.prop)?.dir || void 0; }
        getAriaSort(e) { if (!e.sortable)
            return null; let i = this.sorts.find(o => !!o.dir); return i && i.prop === e.prop ? i.dir === Z.desc ? "descending" : "ascending" : "none"; }
        getSortDescription(e) { let i = this.sorts.findIndex(o => o.prop === e.prop && !!o.dir); return this.sorts.length > 1 && i >= 0 ? `Sort priority ${i + 1}, ${this.sorts[i].dir === Z.asc ? "ascending" : "descending"}` : null; }
        getSortClass(e) { let i = this.getSortDir(e); return e.sortable ? i === Z.asc ? this.sortAscendingIcon || "md-grid-sort-asc" : i === Z.desc ? this.sortDescendingIcon || "md-grid-sort-desc" : this.sortUnsetIcon || "" : ""; }
        isColumnResizeable(e) { return this.enableColumnResize && e.resizeable; }
        isFirstActionColumn(e) { return this.columns.find(o => o.mobileRole === "actions")?.$$id === e.$$id; }
        isLastActionColumn(e) { let i = this.columns.filter(o => o.mobileRole === "actions"); return i[i.length - 1]?.$$id === e.$$id; }
        onResizeStart(e, i) { !this.isColumnResizeable(i) || e.button !== 0 || (e.preventDefault(), e.stopPropagation(), this.removeResizeListeners(), this.resizePointerId = e.pointerId, this._resizingColumn = i, this._resizeStartX = e.clientX, this._resizeStartWidth = i.getActualWidth(), this.zone.runOutsideAngular(() => { this.document.addEventListener("pointermove", this._onResizeMove); }), this.document.addEventListener("pointerup", this._onResizeEnd), this.document.addEventListener("pointercancel", this._onResizeEnd), this.document.body.classList.add("md-grid-resizing")); }
        _onResizeMove = e => { if (!this._resizingColumn || e.pointerId !== this.resizePointerId)
            return; let i = e.clientX - this._resizeStartX, o = this._resizeStartWidth + i, r = this._resizingColumn, s = e.shiftKey === !0, l = [{ key: r, newWidth: o }]; this.setColumnWidths(l, s); };
        _onResizeEnd = e => { if (!this._resizingColumn || e.pointerId !== this.resizePointerId)
            return; this.removeResizeListeners(); let i = this._resizeStartWidth, o = this._resizingColumn.actualWidth; i !== o && this.columnResize.emit({ column: this._resizingColumn, prevWidth: i, newWidth: o }), this.publishColumnState(), this._resizingColumn = null, this.updateScrollState(), this._cdr.markForCheck(); };
        removeResizeListeners() { this.document.removeEventListener("pointermove", this._onResizeMove), this.document.removeEventListener("pointerup", this._onResizeEnd), this.document.removeEventListener("pointercancel", this._onResizeEnd), this._resizingColumn && this.document.body?.classList.remove("md-grid-resizing"), this.resizePointerId = void 0; }
        onResizeKeydown(e, i) { if (!this.isColumnResizeable(i))
            return; let o = i.actualWidth, r = e.shiftKey ? 50 : 10; if (e.key === "ArrowLeft")
            o -= r;
        else if (e.key === "ArrowRight")
            o += r;
        else if (e.key === "Home")
            o = i.minWidth;
        else if (e.key === "End" && i.maxWidth < Number.MAX_SAFE_INTEGER)
            o = i.maxWidth;
        else
            return; e.preventDefault(), e.stopPropagation(); let s = i.actualWidth; i.setActualWidth(Wi(i, o), "uiColumnResized"), this.refreshFlexedLayout(), s !== i.actualWidth && (this.columnResize.emit({ column: i, prevWidth: s, newWidth: i.actualWidth }), this.publishColumnState()); }
        get _paginatorCount() { return this.count ?? this.rows?.length ?? 0; }
        onPaginatorPage(e) { this.offset = e.offset, this.page.emit(e), this.externalPaging || this._processRows(); }
        onPaginatorPageSizeChange(e) { this.limit = e, this.offset = 0, this.pageSizeChange.emit(e), this.externalPaging || this._processRows(); }
        setPage(e) { let i = this._paginatorCount, o = Math.max(0, Math.ceil(i / this.limit) - 1), r = Math.max(0, Math.min(e, o)); r !== this.offset && (this.offset = r, this.page.emit({ offset: r, limit: this.limit, count: i, pageSize: this.limit }), this.externalPaging || this._processRows()); }
        get totalPages() { return Math.ceil(this._paginatorCount / this.limit); }
        get currentPage() { return this.offset + 1; }
        getCellValue(e, i) { let o = i.getValue(e); return i.pipe ? i.pipe.transform(o) : o; }
        getTemplateRow(e) { return this._originalEditRow === e && this._editingRowCopy ? this._editingRowCopy : e; }
        trackByRow = (e, i) => this.trackByKey ? i[this.trackByKey] : i;
        trackByColumn = (e, i) => i.$$id;
        trackByGroup = (e, i) => i.key;
        _processRows() { let e = [...this?.rows ?? []]; if (!this.externalSorting && this.sorts.length > 0 && (e = zg(e, this.sorts, this.allColumns)), !this.externalPaging) {
            let i = this.offset * this.limit, o = i + this.limit;
            e = e.slice(i, o);
        } this._displayRows = e, this.groupRowsBy ? this._groupedRows = Bg(this._displayRows, this.groupRowsBy) : this._groupedRows = null, this._cdr.markForCheck(); }
        _handleEditingRowChange() { if (this.editingRow && this._originalEditRow !== this.editingRow) {
            let e = this._displayRows.indexOf(this.editingRow);
            e >= 0 && (this._originalEditRow = this.editingRow, this.originalEditSnapshot = structuredClone(this.editingRow), this._editingRowCopy = structuredClone(this.editingRow), this._editingRowIndex = e);
        }
        else
            !this.editingRow && this._originalEditRow && this._clearEditState(); }
        _clearEditState() { this._originalEditRow = null, this.originalEditSnapshot = null, this._editingRowCopy = null, this._editingRowIndex = -1, this.editingRow = null, this.editingRowChange.emit(null); }
        cells = Sd("cell");
        cellsObs = mr(this.cells);
        getColAfter(e) { let i = this.columns, o = i.indexOf(e); return o < i.length - 1 ? i[o + 1] : null; }
        setColumnWidths(e, i) { let o = []; for (let r of e) {
            let s = r.key;
            if (o.push({ width: r.newWidth, ratios: [1], columns: [s] }), i) {
                let l = this.getColAfter(s);
                if (!l)
                    continue;
                let c = s.getActualWidth() - r.newWidth, h = l.getActualWidth() + c;
                o.push({ width: h, ratios: [1], columns: [l] });
            }
        } o.length !== 0 && this.resizeColumnSets(o); }
        resizeColumnSets(e) { if (!(!e || e.every(r => Ug(r))))
            return; let o = []; for (let r of e) {
            let { width: s, columns: l, ratios: c } = r;
            l.forEach((g, u) => { let f = Math.round(c[u] * s), v = g.getActualWidth(); f !== v && (g.setActualWidth(f, "uiColumnResized"), o.push(g)); }), o.length > 0 && (cancelAnimationFrame(this.requestAnimationFrameId), this.requestAnimationFrameId = requestAnimationFrame(() => { this.destroyed || this.zone.run(() => { Vi(this.totalSpace, this.columns, l), this._cdr.detectChanges(), this.updateScrollState(), this._cdr.markForCheck(); }); }));
        } }
        requestAnimationFrameId = 0;
        isSyncing = !1;
        headerScroll;
        bodyScroll;
        destroyFns = [];
        syncScroll() { !this.headerScroll || !this.bodyScroll || this.zone.runOutsideAngular(() => { let e = this.headerScroll.nativeElement, i = this.bodyScroll.nativeElement, o = (l, c) => { this.isSyncing || (this.isSyncing = !0, c.scrollLeft = l.scrollLeft, this.isSyncing = !1); }, r = () => o(e, i), s = () => o(i, e); e.addEventListener("scroll", r), i.addEventListener("scroll", s), this.destroyFns.push(() => e.removeEventListener("scroll", r)), this.destroyFns.push(() => i.removeEventListener("scroll", s)); }); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-grid"]], contentQueries: function (i, o, r) { if (i & 1 && (t.\u0275\u0275contentQuerySignal(r, o.columns__, at, 4), t.\u0275\u0275contentQuery(r, Yg, 5)(r, at, 4)), i & 2) {
                t.\u0275\u0275queryAdvance();
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.toolbarTemplate = s.first), t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o._columnDirectives = s);
            } }, viewQuery: function (i, o) { if (i & 1 && (t.\u0275\u0275viewQuerySignal(o.cells, tm, 5), t.\u0275\u0275viewQuery(im, 5)(nm, 5)), i & 2) {
                t.\u0275\u0275queryAdvance();
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.headerScroll = r.first), t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.bodyScroll = r.first);
            } }, hostAttrs: [1, "md-grid"], hostVars: 3, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("aria-busy", o.loading), t.\u0275\u0275classProp("md-grid-has-pinned-columns", o.hasPinnedColumns)); }, inputs: { loading: [2, "loading", "loading", m], loadingMessage: "loadingMessage", error: "error", retryLabel: "retryLabel", loadingTemplate: "loadingTemplate", errorTemplate: "errorTemplate", columnState: "columnState", columnStateKey: "columnStateKey", showColumnChooser: [2, "showColumnChooser", "showColumnChooser", m], columnsLabel: "columnsLabel", selectable: [2, "selectable", "selectable", m], selectedKeys: "selectedKeys", selectPageLabel: "selectPageLabel", selectRowLabel: "selectRowLabel", rowSelectable: "rowSelectable", ariaLabel: "ariaLabel", resizeLabel: "resizeLabel", rowActionsWidth: [2, "rowActionsWidth", "rowActionsWidth", S], rows: "rows", trackByKey: "trackByKey", groupRowsBy: "groupRowsBy", groupHeaderTemplate: "groupHeaderTemplate", rowActionsTemplate: "rowActionsTemplate", headerHeight: [2, "headerHeight", "headerHeight", S], cellTabNavigation: [2, "cellTabNavigation", "cellTabNavigation", m], cardHeight: "cardHeight", gap: [2, "gap", "gap", S], defaultColumnWidth: [2, "defaultColumnWidth", "defaultColumnWidth", S], showRowActions: [2, "showRowActions", "showRowActions", m], emptyMessage: "emptyMessage", emptyTemplate: "emptyTemplate", enableColumnResize: [2, "enableColumnResize", "enableColumnResize", m], defaultMinColumnWidth: [2, "defaultMinColumnWidth", "defaultMinColumnWidth", e => Pe(e, null)], defaultMaxColumnWidth: [2, "defaultMaxColumnWidth", "defaultMaxColumnWidth", e => Pe(e, null)], sorts: "sorts", sortType: "sortType", mdSortActive: "mdSortActive", mdSortDirection: "mdSortDirection", externalSorting: [2, "externalSorting", "externalSorting", m], enableClearingSortState: [2, "enableClearingSortState", "enableClearingSortState", m], sortAscendingIcon: "sortAscendingIcon", sortDescendingIcon: "sortDescendingIcon", sortUnsetIcon: "sortUnsetIcon", sortLabel: "sortLabel", limit: [2, "limit", "limit", S], offset: [2, "offset", "offset", S], count: [2, "count", "count", S], externalPaging: [2, "externalPaging", "externalPaging", m], showFooter: [2, "showFooter", "showFooter", m], footerHeight: [2, "footerHeight", "footerHeight", S], autosizeStrategy: "autosizeStrategy", pageSizeOptions: "pageSizeOptions", editingRow: "editingRow" }, outputs: { retry: "retry", columnStateChange: "columnStateChange", selectedKeysChange: "selectedKeysChange", rowsChange: "rowsChange", columnResize: "columnResize", sortsChange: "sortsChange", sort: "sort", page: "page", pageSizeChange: "pageSizeChange", editingRowChange: "editingRowChange", rowEditStart: "rowEditStart", rowEditSave: "rowEditSave", rowEditCancel: "rowEditCancel", inited: "inited", firstTimeVisible: "firstTimeVisible", layoutReady: "layoutReady" }, exportAs: ["mdGrid"], features: [t.\u0275\u0275NgOnChangesFeature], decls: 3, vars: 1, consts: [["rowTemplate", ""], ["bodyScroll", ""], ["headerScroll", ""], ["cell", ""], ["role", "status", "aria-live", "polite", 1, "md-grid-state"], ["role", "alert", 1, "md-grid-state"], [1, "md-grid-column-chooser"], [1, "md-grid-actions-toolbar", "d-flex", "justify-content-end", "gap-2"], ["role", "group", 1, "md-grid-mobile-sorting"], ["role", "table", 1, "md-grid-scroll-container", 3, "hidden"], ["role", "row", 1, "md-grid-header", 3, "height", "has-vertical-scroll", "padding-right"], ["role", "rowgroup", 1, "md-grid-body"], [1, "horizontal-scroll-container"], [1, "md-grid-empty"], [3, "offset", "limit", "count", "height", "pageSizeOptions"], [4, "ngTemplateOutlet"], ["aria-hidden", "true", 1, "md-grid-loading-indicator"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["type", "button", 1, "md-grid-retry", 3, "click"], [1, "md-grid-column-options"], ["type", "checkbox", 3, "change", "checked", "disabled"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "md-grid-mobile-sorting-label"], ["type", "button", 1, "md-grid-mobile-sort-button", 3, "is-active"], ["type", "button", 1, "md-grid-mobile-sort-button", 3, "click"], ["aria-hidden", "true"], ["role", "row", 1, "md-grid-header"], [1, "md-grid-header-inner"], ["role", "columnheader", 1, "md-grid-header-cell", 3, "ngClass", "md-grid-pinned", "left", "right", "md-grid-id-cell", "md-grid-data-cell", "md-grid-column-actions-cell", "md-grid-first-action-cell", "md-grid-last-action-cell", "resizeable", "sortable", "sort-active", "sort-asc", "sort-desc", "width"], ["role", "columnheader", "aria-label", "Actions", 1, "md-grid-header-cell", "md-grid-actions-cell", 3, "md-grid-pinned", "right", "--%NS%md-grid-actions-width"], ["role", "columnheader", 1, "md-grid-header-cell", 3, "ngClass"], ["type", "checkbox", 1, "md-grid-selection", 3, "checked", "indeterminate", "disabled"], ["role", "separator", "tabindex", "0", "aria-orientation", "vertical", 1, "md-grid-resize-handle"], ["type", "checkbox", 1, "md-grid-selection", 3, "change", "checked", "indeterminate", "disabled"], ["type", "button", 1, "md-grid-header-sort-trigger", 3, "has-sort"], [1, "md-grid-header-cell-label"], ["type", "button", 1, "md-grid-header-sort-trigger", 3, "click"], ["aria-hidden", "true", 1, "md-grid-header-sort-slot"], [1, "md-grid-sort-icon", 3, "ngClass"], ["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "focusable", "false", 1, "md-grid-design-sort-arrow"], ["d", "M7 2.42v9.16m-4.5-4.5L7 11.58l4.5-4.5", "stroke", "currentColor", "stroke-width", "1.5"], ["role", "separator", "tabindex", "0", "aria-orientation", "vertical", 1, "md-grid-resize-handle", 3, "pointerdown", "keydown"], ["role", "columnheader", "aria-label", "Actions", 1, "md-grid-header-cell", "md-grid-actions-cell"], [3, "ngTemplateOutlet"], [1, "md-grid-empty-text"], [1, "md-grid-group"], ["role", "row", 1, "md-grid-group-header"], ["role", "cell"], [1, "md-grid-group-title"], [1, "md-grid-group-rows"], [3, "page", "pageSizeChange", "offset", "limit", "count", "height", "pageSizeOptions"], ["role", "row", 1, "md-grid-card"], ["role", "cell", 1, "md-grid-cell", 3, "md-grid-id-cell", "md-grid-data-cell", "md-grid-column-actions-cell", "md-grid-first-action-cell", "md-grid-last-action-cell", "width", "ngClass", "md-grid-pinned", "left", "right"], ["role", "cell", 1, "md-grid-cell", "md-grid-actions-cell", "md-grid-row-actions-cell", 3, "md-grid-pinned", "right", "--%NS%md-grid-actions-width"], ["role", "cell", 1, "md-grid-cell", 3, "ngClass"], ["type", "checkbox", 1, "md-grid-selection", 3, "checked", "disabled"], [1, "md-grid-mobile-label"], [1, "md-grid-cell-content"], [1, "md-grid-cell-template-content"], [1, "md-grid-cell-value"], ["type", "checkbox", 1, "md-grid-selection", 3, "change", "checked", "disabled"], ["role", "cell", 1, "md-grid-cell", "md-grid-actions-cell", "md-grid-row-actions-cell"], ["type", "button", "title", "Edit", "aria-label", "Edit", 1, "md-grid-action-btn", "md-grid-action-edit"], ["type", "button", "title", "Save", "aria-label", "Save", 1, "md-grid-action-btn", "md-grid-action-save", 3, "click"], [1, "md-grid-icon-save"], ["type", "button", "title", "Cancel", "aria-label", "Cancel", 1, "md-grid-action-btn", "md-grid-action-cancel", 3, "click"], [1, "md-grid-icon-cancel"], ["type", "button", "title", "Edit", "aria-label", "Edit", 1, "md-grid-action-btn", "md-grid-action-edit", 3, "click"], [1, "md-grid-icon-edit"]], template: function (i, o) { i & 1 && (t.\u0275\u0275conditionalCreate(0, Jm, 14, 16), t.\u0275\u0275template(1, ph, 4, 7, "ng-template", null, 0, t.\u0275\u0275templateRefExtractor)), i & 2 && t.\u0275\u0275conditional(o.gridInited ? 0 : -1); }, dependencies: [ae, Re.NgClass, Re.NgTemplateOutlet, Fg], styles: [`.md-grid-mobile-sorting{display:none}@media(max-width:767.98px){.md-grid-mobile-sorting{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding-block:12px;color:var(--%NS%md-color-text, #373737)}.md-grid-mobile-sorting-label{color:var(--%NS%md-color-text-subtle, #4D4D4D)}.md-grid-mobile-sort-button{display:inline-flex;align-items:center;gap:8px;min-height:36px;padding:6px 12px;border:1px solid var(--%NS%md-color-border, #EAEAEA);border-radius:20px;background:var(--%NS%md-color-surface, #FFFFFF);color:inherit;font:inherit;cursor:pointer}.md-grid-mobile-sort-button.is-active{border-color:currentColor;background:var(--%NS%md-color-surface-selected, #EAEAEA)}.md-grid-mobile-sort-button:focus-visible{outline:2px solid var(--%NS%md-color-focus, #0185CF);outline-offset:2px}}.md-grid{width:100%;height:100%;font-family:Open Sans,Arial,sans-serif;font-size:13px;background:transparent;border:0;border-radius:0;display:flex;flex-direction:column;overflow:auto}.md-grid *,.md-grid *:before,.md-grid *:after{box-sizing:border-box}.md-grid-scroll-container{display:flex;flex-direction:column;height:100%;overflow:auto;flex:1}.md-grid-actions-toolbar{align-items:center;padding:6px 8px;border:1px solid #EAEAEA;border-bottom:0;border-radius:3px 3px 0 0;background-color:#f3f3f3}.md-grid-actions-toolbar .btn{min-height:24px;padding:2px 8px;font-size:12px;line-height:1.25}.md-grid-actions-toolbar+.md-grid-scroll-container{border-radius:0 0 3px 3px;box-shadow:inset 0 0 0 1px #eaeaea}@media(max-width:767.98px){.md-grid-actions-toolbar{display:none!important}.md-grid-actions-toolbar+.md-grid-scroll-container{border-radius:0;box-shadow:none}}.md-grid-header{display:block;width:100%;max-width:100%;flex-shrink:0;overflow-x:auto;scrollbar-width:none;background:transparent;margin:0;padding:0;border:0}.md-grid-header-inner{display:flex;align-items:center;height:100%;width:100%;min-width:fit-content}.md-grid-header-cell{display:flex;align-items:center;flex-shrink:0;height:100%;padding:14px 16px;background:#fff;font-family:Montserrat,Arial,sans-serif;font-size:14px;font-weight:300;color:#4d4d4d;text-transform:uppercase;letter-spacing:.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;user-select:none}.md-grid-header-cell.sortable{transition:background-color .2s ease}.md-grid-header-cell.sort-active{color:#0185cf}.md-grid-header-cell.resizeable{position:relative}.md-grid-header-sort-trigger{display:inline-flex;align-items:center;width:100%;min-width:0;height:100%;padding:0;border:0;background:transparent;color:inherit;font:inherit;letter-spacing:inherit;text-align:left;text-transform:inherit;cursor:pointer}.md-grid-header-sort-trigger:hover{color:inherit}.md-grid-header-sort-trigger:focus{outline:0}.md-grid-header-cell.sortable:has(.md-grid-header-sort-trigger:hover),.md-grid-header-cell.sortable:has(.md-grid-header-sort-trigger:focus-visible){background:#f3f3f3}.md-grid-header-cell-label{flex:1;overflow:hidden;text-overflow:ellipsis}.md-grid-header-sort-slot{display:inline-flex;flex:0 0 16px;align-items:center;justify-content:center;height:100%}.md-grid-header-sort-slot .md-grid-sort-icon{margin:0}.md-grid-sort-icon{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;margin-left:2px;color:#929292;transition:color .2s ease}.md-grid-sort-icon:before{font-family:datatable;font-size:12px}.md-grid-sort-icon.md-grid-sort-asc,.md-grid-sort-icon.md-grid-sort-desc{color:#6d5cae}.md-grid-sort-icon.md-grid-sort-asc:after,.md-grid-sort-icon.md-grid-sort-desc:after{content:"";display:block;width:0;height:0;border-left:4px solid transparent;border-right:4px solid transparent}.md-grid-sort-icon.md-grid-sort-asc:after{border-bottom:5px solid currentColor}.md-grid-sort-icon.md-grid-sort-desc:after{border-top:5px solid currentColor}.md-grid-resize-handle{position:absolute;inset:0 0 0 auto;width:8px;touch-action:none;cursor:ew-resize;z-index:1}.md-grid-resize-handle:after{content:"";position:absolute;top:35%;right:2px;width:2px;height:30%;background:color-mix(in srgb,transparent,#181d1f 15%);border-radius:1px;transition:background-color .2s ease}.md-grid-header-cell:last-of-type:not(.md-grid-actions-cell) .md-grid-resize-handle{right:0}.md-grid-header-cell:has(+.md-grid-actions-cell) .md-grid-resize-handle{right:0}body.md-grid-resizing{cursor:ew-resize!important;-webkit-user-select:none!important;user-select:none!important}body.md-grid-resizing *{cursor:ew-resize!important}.md-grid-body{overflow:auto;max-width:100%;display:flex;flex-direction:column;padding:12px 0 0;width:fit-content;background:transparent}.md-grid-empty{display:flex;align-items:center;justify-content:center;padding:32px 16px;width:100%;min-width:0}.md-grid-empty-text{font-size:14px;color:#4d4d4d;font-style:italic}.md-grid-group{margin-bottom:12px}.md-grid-group:last-child{margin-bottom:0}.md-grid-group-header{display:flex;align-items:center;padding:10px 14px;margin-bottom:12px;background:#eaeaea;border-radius:0;font-size:13px;font-weight:600;color:#000}.md-grid-group-title{flex:1}.md-grid-group-rows{display:flex;flex-direction:column;width:fit-content;min-width:fit-content;gap:5px}.md-grid-card{display:inline-flex;align-items:stretch;width:fit-content;min-width:fit-content;background:#fff;border:0;box-shadow:none;transition:all .2s ease}.md-grid-card:hover{background:#fbfbfb;box-shadow:0 2px 8px #0000001f;transform:translateY(-1px)}.md-grid-card.md-grid-card-editing{background:#cf01061a;border:0;box-shadow:none}.md-grid-card.md-grid-card-fixed-height,.md-grid-card.md-grid-card-fixed-height .md-grid-cell{overflow:hidden}.md-grid-card.md-grid-card-fixed-height .md-grid-cell-value{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.md-grid-cell{display:flex;align-items:center;flex-shrink:0;padding:14px 16px;font-size:14px;color:#000;border:0;overflow:hidden;min-width:0}.md-grid-cell:last-child{border-right:none}.md-grid-cell-value,.md-grid-cell-template-content{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;line-height:1.4}.md-grid-cell-template-content{display:flex;align-items:center;flex-wrap:nowrap;max-width:100%;flex:1}.md-grid-cell-template-content>*{flex:0 1 auto;min-width:0;max-width:100%;overflow:hidden;text-overflow:ellipsis;text-wrap:nowrap;white-space:nowrap}.md-grid-cell-template-content:not(:has(>*)){display:block}.md-grid-mobile-label{display:none}.md-grid-cell-content{display:flex;align-items:center;min-width:0;max-width:100%;overflow:hidden;text-overflow:ellipsis;text-wrap:nowrap;white-space:nowrap;flex:1}.md-grid-cell-content>*{min-width:0;max-width:100%;overflow:hidden;text-overflow:ellipsis;text-wrap:nowrap;white-space:nowrap}.md-grid-actions-cell{display:flex;align-items:center;justify-content:flex-end;gap:6px;min-width:90px;width:auto!important;flex-grow:0!important;flex-shrink:0!important;padding:inherit;border:0}.md-grid-header-cell.md-grid-actions-cell{border-left:none;border-right:none}.md-grid-action-btn{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;padding:0;border:none;border-radius:4px;background:transparent;color:#4d4d4d;cursor:pointer;transition:all .2s ease}.md-grid-action-btn:hover{transform:scale(1.1)}.md-grid-action-btn:focus{outline:2px solid #6d5cae;outline-offset:1px}.md-grid-action-btn:active{transform:scale(.95)}.md-grid-action-edit{color:#6d5cae}.md-grid-action-edit:hover{background:#e9e7f3;color:#564790}.md-grid-action-save{color:#28b446}.md-grid-action-save:hover{background:#dff4e3;color:#1f8a36}.md-grid-action-cancel{color:#cf0106}.md-grid-action-cancel:hover{background:#f8d9da;color:#9c0105}.md-grid-icon-edit,.md-grid-icon-save,.md-grid-icon-cancel{display:inline-block;width:18px;height:18px;position:relative}.md-grid-icon-edit:before,.md-grid-icon-edit:after{content:"";position:absolute}.md-grid-icon-edit:before{width:10px;height:10px;border:2px solid currentColor;border-radius:1px;transform:rotate(45deg);top:1px;left:1px}.md-grid-icon-edit:after{width:0;height:0;border-left:3px solid transparent;border-right:3px solid transparent;border-top:5px solid currentColor;bottom:0;left:0;transform:rotate(-45deg)}.md-grid-icon-save:before{content:"";position:absolute;width:6px;height:10px;border-right:2px solid currentColor;border-bottom:2px solid currentColor;transform:rotate(45deg);top:1px;left:5px}.md-grid-icon-cancel:before,.md-grid-icon-cancel:after{content:"";position:absolute;width:14px;height:2px;background:currentColor;top:50%;left:50%}.md-grid-icon-cancel:before{transform:translate(-50%,-50%) rotate(45deg)}.md-grid-icon-cancel:after{transform:translate(-50%,-50%) rotate(-45deg)}@media(max-width:767.98px){.md-grid{font-size:12px;height:auto}.md-grid-header{display:none}.md-grid-scroll-container,.md-grid-body{width:100%;min-width:0;overflow-x:hidden}.md-grid-body{padding:6px}.horizontal-scroll-container,.md-grid-group,.md-grid-group-rows{width:100%!important;min-width:0!important}.horizontal-scroll-container,.md-grid-group-rows{display:flex;flex-direction:column;gap:10px}.md-grid-card{display:flex;flex-direction:row;flex-wrap:wrap;width:100%;min-width:0;overflow:hidden;border-radius:8px}.md-grid-cell{width:100%!important;min-width:0;padding:7px 12px;border-right:none;border-bottom:1px solid #EAEAEA;gap:0}.md-grid-data-cell{order:3;display:grid;grid-template-columns:minmax(104px,34%) minmax(0,1fr);align-items:center}.md-grid-data-cell:nth-child(1 of.md-grid-data-cell){border-top:1px solid #EAEAEA}.md-grid-mobile-label{display:block;min-width:0;overflow:hidden;color:#4d4d4d;text-overflow:ellipsis;white-space:nowrap}.md-grid-cell-content{min-width:0;justify-content:flex-start}.md-grid-id-cell{order:1;width:auto!important;max-width:calc(100% - 72px);min-height:40px;flex:1 1 auto;border-bottom:0;font-weight:600}.md-grid-id-cell .md-grid-mobile-label{display:none}.md-grid-actions-cell,.md-grid-column-actions-cell{order:2;width:auto!important;min-width:0;min-height:40px;flex:0 0 auto!important;margin-left:0;padding:7px 4px;border-left:none;border-top:none;border-bottom:0;justify-content:flex-end;background:transparent}.md-grid-actions-cell .md-grid-mobile-label,.md-grid-column-actions-cell .md-grid-mobile-label{display:none}.md-grid-actions-cell .md-grid-cell-content,.md-grid-column-actions-cell .md-grid-cell-content{gap:6px;justify-content:flex-end}.md-grid-first-action-cell,.md-grid-row-actions-cell{margin-left:auto}.md-grid-last-action-cell,.md-grid-row-actions-cell{padding-right:16px}.md-grid-card>:nth-last-child(1 of.md-grid-data-cell){border-bottom:0}.md-grid-cell-value{white-space:normal;word-break:break-word}}.md-grid.grey .md-grid-header-cell,.md-grid.grey .md-grid-card{background:#f3f3f3}.md-grid.grey .md-grid-card:hover{background:#efefef}.md-grid.grey .md-grid-card.md-grid-card-editing{background:#cf01061a}.md-grid.zebra .md-grid-card:nth-child(odd){background:#fff}.md-grid.zebra .md-grid-card:nth-child(2n){background:#f3f3f3}.md-grid.zebra .md-grid-card:hover{background:#e4e4e4}.md-grid.zebra .md-grid-card.md-grid-card-editing{background:#cf01061a}.md-grid.zebra .md-grid-group-rows .md-grid-card:nth-child(odd){background:#fff}.md-grid.zebra .md-grid-group-rows .md-grid-card:nth-child(2n){background:#f3f3f3}.md-grid.zebra .md-grid-group-rows .md-grid-card:hover{background:#e4e4e4}.md-grid.zebra .md-grid-group-rows .md-grid-card.md-grid-card-editing{background:#cf01061a}.md-grid.zebra.grey .md-grid-card:nth-child(odd){background:#f3f3f3}.md-grid.zebra.grey .md-grid-card:nth-child(2n){background:#efefef}.md-grid.zebra.grey .md-grid-card:hover{background:#d6d6d6}.md-grid.zebra.grey .md-grid-card.md-grid-card-editing{background:#cf01061a}.md-grid.zebra.grey .md-grid-group-rows .md-grid-card:nth-child(odd){background:#f3f3f3}.md-grid.zebra.grey .md-grid-group-rows .md-grid-card:nth-child(2n){background:#efefef}.md-grid.zebra.grey .md-grid-group-rows .md-grid-card:hover{background:#d6d6d6}.md-grid.zebra.grey .md-grid-group-rows .md-grid-card.md-grid-card-editing{background:#cf01061a}:host-context(.md-theme-dark).zebra .md-grid-card:nth-child(odd),:host-context(.md-theme-dark).zebra .md-grid-group-rows .md-grid-card:nth-child(odd),:host-context(.md-theme-dark).zebra.grey .md-grid-card:nth-child(odd),:host-context(.md-theme-dark).zebra.grey .md-grid-group-rows .md-grid-card:nth-child(odd){background:var(--%NS%md-color-surface)}:host-context(.md-theme-dark).zebra .md-grid-card:nth-child(2n),:host-context(.md-theme-dark).zebra .md-grid-group-rows .md-grid-card:nth-child(2n),:host-context(.md-theme-dark).zebra.grey .md-grid-card:nth-child(2n),:host-context(.md-theme-dark).zebra.grey .md-grid-group-rows .md-grid-card:nth-child(2n){background:var(--%NS%md-color-surface-muted)}:host{position:relative;display:block}.md-grid-header.has-vertical-scroll{padding-right:16px}.md-theme-dark :is(md-grid,.md-grid){color:var(--%NS%md-color-text);background-color:var(--%NS%md-color-surface);border-color:var(--%NS%md-color-border)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-actions-toolbar,.md-theme-dark :is(md-grid,.md-grid) .md-grid-header,.md-theme-dark :is(md-grid,.md-grid) .md-grid-header-cell,.md-theme-dark :is(md-grid,.md-grid) .md-grid-footer,.md-theme-dark :is(md-grid,.md-grid) .md-grid-group-header{background-color:var(--%NS%md-color-surface-muted);color:var(--%NS%md-color-text-subtle);border-color:var(--%NS%md-color-border)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-actions-toolbar+.md-grid-scroll-container{box-shadow:inset 0 0 0 1px var(--%NS%md-color-border)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-body{background-color:var(--%NS%md-color-surface)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-card,.md-theme-dark :is(md-grid,.md-grid) .md-grid-empty{background-color:var(--%NS%md-color-surface);border-color:var(--%NS%md-color-border)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-cell,.md-theme-dark :is(md-grid,.md-grid) .md-grid-actions-cell{color:var(--%NS%md-color-text);border-color:var(--%NS%md-color-border)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-empty-text,.md-theme-dark :is(md-grid,.md-grid) .md-grid-mobile-label,.md-theme-dark :is(md-grid,.md-grid) .md-grid-pager-info{color:var(--%NS%md-color-text-subtle)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-sort-icon{color:var(--%NS%md-color-text-muted)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-header-cell.sort-active,.md-theme-dark :is(md-grid,.md-grid) .md-grid-sort-asc,.md-theme-dark :is(md-grid,.md-grid) .md-grid-sort-desc{color:var(--%NS%md-color-primary)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-header-cell{font-weight:300;text-transform:uppercase;letter-spacing:.5px}.md-theme-dark :is(md-grid,.md-grid) .md-grid-header-cell:not(:first-child){border-left:1px solid var(--%NS%md-color-border)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-header-cell.sortable:hover,.md-theme-dark :is(md-grid,.md-grid) .md-grid-header-cell.sortable:has(.md-grid-header-sort-trigger:focus-visible){background-color:var(--%NS%md-color-surface-hover)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-resize-handle:after{background:var(--%NS%md-color-border)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-resize-handle:hover:after{background:var(--%NS%md-color-focus)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-action-btn{color:var(--%NS%md-color-text-subtle)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-action-btn:hover{background-color:var(--%NS%md-color-surface-hover)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-action-edit{color:var(--%NS%md-color-primary)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-action-edit:hover{color:var(--%NS%md-color-primary);background-color:color-mix(in srgb,var(--%NS%md-color-primary) 16%,transparent)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-action-save{color:var(--%NS%md-color-success)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-action-save:hover{color:var(--%NS%md-color-success);background-color:color-mix(in srgb,var(--%NS%md-color-success) 16%,transparent)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-action-cancel{color:var(--%NS%md-color-danger)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-action-cancel:hover{color:var(--%NS%md-color-danger);background-color:color-mix(in srgb,var(--%NS%md-color-danger) 16%,transparent)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-pager-btn,.md-theme-dark :is(md-grid,.md-grid) .md-paginator-page-size-select{background-color:var(--%NS%md-color-surface);color:var(--%NS%md-color-text);border-color:var(--%NS%md-color-border)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-pager-btn:hover:not(:disabled),.md-theme-dark :is(md-grid,.md-grid) .md-paginator-page-size-select:hover:not(:disabled){background-color:var(--%NS%md-color-surface-hover);color:var(--%NS%md-color-primary)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-pager-btn:disabled,.md-theme-dark :is(md-grid,.md-grid) .md-paginator-page-size-select:disabled{color:var(--%NS%md-color-text-muted)}.md-theme-dark :is(md-grid,.md-grid) .md-paginator-page-size-label{color:var(--%NS%md-color-text-subtle)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-action-btn:focus-visible,.md-theme-dark :is(md-grid,.md-grid) .md-grid-header-sort-trigger:focus-visible,.md-theme-dark :is(md-grid,.md-grid) .md-grid-pager-btn:focus-visible,.md-theme-dark :is(md-grid,.md-grid) .md-paginator-page-size-select:focus-visible{outline:2px solid var(--%NS%md-color-focus);outline-offset:-2px}.md-theme-dark :is(md-grid,.md-grid) .md-grid-scroll-container,.md-theme-dark :is(md-grid,.md-grid) .md-grid-body{scrollbar-color:var(--%NS%md-color-border) var(--%NS%md-color-surface)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-scroll-container::-webkit-scrollbar-track,.md-theme-dark :is(md-grid,.md-grid) .md-grid-body::-webkit-scrollbar-track{background:var(--%NS%md-color-surface)}.md-theme-dark :is(md-grid,.md-grid) .md-grid-scroll-container::-webkit-scrollbar-thumb,.md-theme-dark :is(md-grid,.md-grid) .md-grid-body::-webkit-scrollbar-thumb{background:var(--%NS%md-color-border)}.md-theme-dark :is(.md-grid.zebra,.md-grid.zebra.grey,.md-grid-table.zebra-white,.md-grid-table.zebra-grey,.md-grid-bordered.zebra) .md-grid-card:nth-child(odd),.md-theme-dark :is(.md-grid.zebra,.md-grid.zebra.grey,.md-grid-table.zebra-white,.md-grid-table.zebra-grey,.md-grid-bordered.zebra) .md-grid-group-rows .md-grid-card:nth-child(odd){background-color:var(--%NS%md-color-surface)}.md-theme-dark :is(.md-grid.zebra,.md-grid.zebra.grey,.md-grid-table.zebra-white,.md-grid-table.zebra-grey,.md-grid-bordered.zebra) .md-grid-card:nth-child(2n),.md-theme-dark :is(.md-grid.zebra,.md-grid.zebra.grey,.md-grid-table.zebra-white,.md-grid-table.zebra-grey,.md-grid-bordered.zebra) .md-grid-group-rows .md-grid-card:nth-child(2n){background-color:var(--%NS%md-color-surface-muted)}.md-theme-dark :is(.md-grid,.md-grid-table.zebra-white,.md-grid-table.zebra-grey,.md-grid-bordered.zebra) .md-grid-card:hover{background-color:var(--%NS%md-color-surface-hover)!important}.md-theme-dark :is(.md-grid,.md-grid-table.zebra-white,.md-grid-table.zebra-grey,.md-grid-bordered.zebra) .md-grid-card.md-grid-card-editing{background-color:var(--%NS%md-color-surface-selected)!important;border-color:var(--%NS%md-color-focus)}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-header{background:#f3f3f3;box-shadow:inset 0 -1px #eaeaea}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-header-cell{background:transparent;color:#373737;font-weight:300;text-transform:uppercase;letter-spacing:.5px;border-left-color:#eaeaea}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-header-cell.sortable{transition:background-color .15s ease,color .15s ease}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-header-cell.sortable:hover,.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-header-cell.sortable:has(.md-grid-header-sort-trigger:hover){background:#eaeaea}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-header-cell.sortable:has(.md-grid-header-sort-trigger:focus-visible){background:#eaeaea;box-shadow:inset 0 0 0 2px #6d5cae}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-header-cell.sort-active{color:#6d5cae;box-shadow:inset 0 -2px #6d5cae}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-header-cell.sort-active:has(.md-grid-header-sort-trigger:focus-visible){box-shadow:inset 0 0 0 2px #6d5cae}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-sort-icon{flex-shrink:0;color:#929292}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-sort-icon.md-grid-sort-asc,.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-sort-icon.md-grid-sort-desc{color:#6d5cae}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-resize-handle:after{background:#eaeaea}.md-grid:not(.md-theme-dark,.md-theme-dark *) .md-grid-resize-handle:hover:after{background:#6d5cae}.md-grid-resize-handle:focus-visible{outline:2px solid var(--%NS%md-color-focus);outline-offset:-2px;background:var(--%NS%md-color-surface-selected)}@media(min-width:768px){.md-grid .md-grid-actions-cell{min-width:var(--%NS%md-grid-actions-width, 100px);max-width:var(--%NS%md-grid-actions-width, 100px)}.md-grid.md-grid-has-pinned-columns .md-grid-card{overflow:visible}.md-grid.md-grid-has-pinned-columns .md-grid-header-cell.md-grid-pinned,.md-grid.md-grid-has-pinned-columns .md-grid-cell.md-grid-pinned{position:sticky;z-index:2;background-color:inherit;box-shadow:1px 0 var(--%NS%md-color-border),-1px 0 var(--%NS%md-color-border)}.md-grid.md-grid-has-pinned-columns .md-grid-header-inner{background-color:inherit}.md-grid.md-grid-has-pinned-columns .md-grid-header-cell.md-grid-pinned{background-color:var(--%NS%md-color-surface-muted)}.md-grid.md-grid-has-pinned-columns .md-grid-card.md-grid-card-editing .md-grid-pinned{background-color:var(--%NS%md-color-surface-selected)}}.md-grid-scroll-container[hidden]{display:none!important}.md-grid-state{min-height:160px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px;padding:24px;color:var(--%NS%md-color-text);background:var(--%NS%md-color-surface)}.md-grid-retry,.md-grid-column-chooser summary{color:var(--%NS%md-color-text);background:var(--%NS%md-color-surface);border:1px solid var(--%NS%md-color-border);border-radius:var(--%NS%md-radius-sm);padding:8px 12px;cursor:pointer;font:inherit}.md-grid-column-chooser{margin-bottom:8px}.md-grid-column-options{display:flex;flex-wrap:wrap;gap:16px;padding:12px}.md-grid-column-options label{display:flex;align-items:center;gap:8px}.md-grid-selection{flex:0 0 auto;width:16px;height:16px;margin:0 8px 0 0;accent-color:var(--%NS%md-color-focus)}.md-grid-loading-indicator{width:24px;height:24px;border:2px solid var(--%NS%md-color-border);border-top-color:var(--%NS%md-color-focus);border-radius:50%;animation:md-grid-spin 1s linear infinite}@keyframes md-grid-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.md-grid-loading-indicator{animation:none}}.md-grid-design-sort-arrow{display:none}.md-grid.md-grid-design{--%NS%md-table-heading-background: #EAEAEA;--%NS%md-table-background: #FFFFFF;--%NS%md-table-text: #373737;--%NS%md-table-divider: #BDBDBD;font:400 12px/20px Montserrat,Arial,sans-serif;border:0;border-radius:0}.md-grid.md-grid-design .md-grid-header{margin-bottom:12px;background:var(--%NS%md-table-heading-background)}.md-grid.md-grid-design .md-grid-header-inner{background:var(--%NS%md-table-heading-background)}.md-grid.md-grid-design .md-grid-header-cell{overflow:visible}.md-grid.md-grid-design .md-grid-resize-handle{inset-inline-end:-5px;width:11px;cursor:col-resize}.md-grid.md-grid-design .md-grid-resize-handle:after{content:none}.md-grid.md-grid-design .md-grid-resize-handle:focus-visible{outline:1px solid var(--%NS%md-color-focus, #CF0106);outline-offset:-1px}.md-grid.md-grid-design .md-grid-header-cell{padding:5px 18px;background:var(--%NS%md-table-heading-background);color:var(--%NS%md-table-text);border:0;font:500 12px/20px Montserrat,Arial,sans-serif;letter-spacing:0}.md-grid.md-grid-design .md-grid-header-cell:not(:last-child){border-inline-end:1px dashed var(--%NS%md-table-divider)}.md-grid.md-grid-design .md-grid-header-sort-trigger{display:grid;grid-template-columns:minmax(0,1fr);min-width:0}.md-grid.md-grid-design .md-grid-header-sort-trigger.has-sort{grid-template-columns:minmax(0,1fr) 14px}.md-grid.md-grid-design .md-grid-header-sort-slot{width:14px;overflow:hidden}.md-grid.md-grid-design .md-grid-header-sort-slot .md-grid-sort-icon{width:14px;height:14px;flex-shrink:0}.md-grid.md-grid-design .md-grid-header-cell-label{min-width:0}.md-grid.md-grid-design .md-grid-header-cell.sort-active{color:var(--%NS%md-table-text);box-shadow:none}.md-grid.md-grid-design .md-grid-sort-icon,.md-grid.md-grid-design .md-grid-sort-icon.md-grid-sort-asc,.md-grid.md-grid-design .md-grid-sort-icon.md-grid-sort-desc{color:var(--%NS%md-table-text)}.md-grid.md-grid-design .md-grid-sort-icon:before,.md-grid.md-grid-design .md-grid-sort-icon:after{content:none}.md-grid.md-grid-design .md-grid-sort-icon .md-grid-design-sort-arrow{display:block;flex-shrink:0}.md-grid.md-grid-design .md-grid-sort-icon.md-grid-sort-asc .md-grid-design-sort-arrow{transform:rotate(180deg)}.md-grid.md-grid-design .md-grid-body,.md-grid.md-grid-design .md-grid-group-rows{gap:0;padding:0}.md-grid.md-grid-design .md-grid-card{margin:0;border:0;border-radius:0;box-shadow:none;background:var(--%NS%md-table-background)}.md-grid.md-grid-design .md-grid-card:hover{transform:none;box-shadow:none;background:var(--%NS%md-color-surface-hover, #F3F3F3)}.md-grid.md-grid-design .md-grid-cell{padding:5px 18px;border:0;color:var(--%NS%md-table-text);font:400 12px/20px Montserrat,Arial,sans-serif}.md-grid.md-grid-design .md-grid-cell a{color:inherit;text-decoration:none}.md-grid.md-grid-design .md-grid-cell a:hover{text-decoration:underline}.md-grid.md-grid-design .md-grid-column-actions-cell{padding-inline:12px}.md-theme-dark .md-grid.md-grid-design{--%NS%md-table-heading-background: var(--%NS%md-color-surface-muted);--%NS%md-table-background: var(--%NS%md-color-surface);--%NS%md-table-text: var(--%NS%md-color-text);--%NS%md-table-divider: var(--%NS%md-color-border)}.md-grid.md-grid-design .md-grid-actions-toolbar,.md-theme-dark .md-grid.md-grid-design .md-grid-actions-toolbar{padding:0;margin-bottom:12px;border:0;border-radius:0;background:transparent}.md-grid.md-grid-design .md-grid-actions-toolbar+.md-grid-scroll-container,.md-theme-dark .md-grid.md-grid-design .md-grid-actions-toolbar+.md-grid-scroll-container{border-radius:0;box-shadow:none}.md-theme-dark .md-grid.md-grid-design .md-grid-header-cell:not(:first-child){border-inline-start:0}.md-grid .md-grid-cell[tabindex="0"]:focus-visible{outline:1px solid var(--%NS%md-color-focus, #0185CF);outline-offset:-1px}@media(max-width:767.98px){.md-grid.md-grid-design{height:auto}.md-grid.md-grid-design .md-grid-actions-toolbar{display:flex!important;flex-wrap:wrap}.md-grid.md-grid-design .md-grid-body,.md-grid.md-grid-design .md-grid-group-rows{gap:12px}.md-grid.md-grid-design .md-grid-card{height:auto!important;width:100%;min-width:0;border:1px solid var(--%NS%md-table-divider);border-radius:5px}.md-grid.md-grid-design .md-grid-cell{padding:8px 12px;border-bottom:1px solid var(--%NS%md-table-divider)}.md-grid.md-grid-design .md-grid-id-cell{min-height:44px;max-width:calc(100% - 72px);font-weight:600}.md-grid.md-grid-design .md-grid-column-actions-cell{min-height:44px;padding-inline:4px}.md-grid.md-grid-design .md-grid-column-actions-cell:last-child{padding-right:12px}.md-grid.md-grid-design .md-grid-data-cell{display:grid;grid-template-columns:minmax(104px,34%) minmax(0,1fr)}.md-grid.md-grid-design .md-grid-data-cell:nth-child(1 of.md-grid-data-cell){border-top:1px solid var(--%NS%md-table-divider)}.md-grid.md-grid-design .md-grid-data-cell:nth-last-child(1 of.md-grid-data-cell){border-bottom:0}.md-grid.md-grid-design .md-grid-id-cell,.md-grid.md-grid-design .md-grid-actions-cell,.md-grid.md-grid-design .md-grid-column-actions-cell{border-bottom:0}.md-grid.md-grid-design .md-grid-mobile-label{color:var(--%NS%md-color-text-subtle, #4D4D4D)}.md-grid.md-grid-design .md-grid-cell-content{min-width:0}}
`], encapsulation: 2 });
    }
    return n;
})();
function Ug(n) { let { columns: a, width: e } = n, i = 0, o = 0, r = !0; for (let c of a) {
    let h = c.minWidth;
    i += h || 0;
    let g = c.maxWidth;
    g > 0 ? o += g : r = !1;
} let s = e >= i, l = !r || e <= o; return s && l; }
var jy = (() => { class n {
    grid;
    onClick(e) { e.preventDefault(), this.grid?.autoSize(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdGridAutoSize", ""]], hostAttrs: [1, "md-grid-sizing-action"], hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function (s) { return o.onClick(s); }); }, inputs: { grid: [0, "mdGridAutoSize", "grid"] } });
} return n; })(), Wy = (() => { class n {
    grid;
    onClick(e) { e.preventDefault(), this.grid?.resetFlexSizing(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdGridResetFlexSizing", ""]], hostAttrs: [1, "md-grid-sizing-action"], hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function (s) { return o.onClick(s); }); }, inputs: { grid: [0, "mdGridResetFlexSizing", "grid"] } });
} return n; })();
var Gy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [ae, Kg] });
} return n; })(), $y = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })();
var wr = "_md-bottom-sheet-enter", Sr = "_md-bottom-sheet-exit", Xg = (() => {
    class n extends Fn {
        _breakpointSubscription;
        _animationsDisabled = d(Fr, { optional: !0 }) === "NoopAnimations";
        _animationState = "void";
        _animationStateChanged = new p;
        _destroyed = !1;
        constructor() { super(); let e = d(oa); this._breakpointSubscription = e.observe([Me.Medium, Me.Large, Me.XLarge]).subscribe(() => { let i = this._elementRef.nativeElement.classList; i.toggle("md-bottom-sheet-container-medium", e.isMatched(Me.Medium)), i.toggle("md-bottom-sheet-container-large", e.isMatched(Me.Large)), i.toggle("md-bottom-sheet-container-xlarge", e.isMatched(Me.XLarge)); }); }
        enter() { this._destroyed || (this._animationState = "visible", this._changeDetectorRef.markForCheck(), this._changeDetectorRef.detectChanges(), this._animationsDisabled && this._simulateAnimation(wr)); }
        exit() { this._destroyed || (this._elementRef.nativeElement.setAttribute("md-exit", ""), this._animationState = "hidden", this._changeDetectorRef.markForCheck(), this._animationsDisabled && this._simulateAnimation(Sr)); }
        ngOnDestroy() { super.ngOnDestroy(), this._breakpointSubscription.unsubscribe(), this._destroyed = !0; }
        _simulateAnimation(e) { this._ngZone.run(() => { this._handleAnimationEvent(!0, e, this._elementRef.nativeElement), setTimeout(() => this._handleAnimationEvent(!1, e, this._elementRef.nativeElement)); }); }
        _trapFocus() { super._trapFocus({ preventScroll: !0 }); }
        _handleAnimationEvent(e, i, o) { if (o === this._elementRef.nativeElement) {
            let r = i === wr;
            (r || i === Sr) && this._animationStateChanged.emit({ toState: r ? "visible" : "hidden", phase: e ? "start" : "done" });
        } }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-bottom-sheet-container"]], hostAttrs: ["tabindex", "-1", 1, "md-bottom-sheet-container"], hostVars: 9, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("animationstart", function (s) { return o._handleAnimationEvent(!0, s.animationName, s.target); })("animationend", function (s) { return o._handleAnimationEvent(!1, s.animationName, s.target); })("animationcancel", function (s) { return o._handleAnimationEvent(!1, s.animationName, s.target); }), i & 2 && (t.\u0275\u0275attribute("role", o._config.role)("aria-modal", o._config.ariaModal)("aria-label", o._config.ariaLabel), t.\u0275\u0275classProp("md-bottom-sheet-container-animations-enabled", !o._animationsDisabled)("md-bottom-sheet-container-enter", o._animationState === "visible")("md-bottom-sheet-container-exit", o._animationState === "hidden")); }, features: [t.\u0275\u0275InheritDefinitionFeature], decls: 1, vars: 0, consts: [["cdkPortalOutlet", ""]], template: function (i, o) { i & 1 && t.\u0275\u0275template(0, uh, 0, 0, "ng-template", 0); }, dependencies: [Le], styles: [`@keyframes _md-bottom-sheet-enter{0%{transform:translateY(100%)}to{transform:none}}@keyframes _md-bottom-sheet-exit{0%{transform:none}to{transform:translateY(100%)}}.md-bottom-sheet-container{padding:8px 16px;min-width:100vw;box-sizing:border-box;display:block;outline:0;max-height:80vh;overflow:auto;position:relative;background:var(--%NS%md-bottom-sheet-container-background-color, #fff);color:var(--%NS%md-bottom-sheet-container-text-color, rgba(0, 0, 0, .87));font-family:var(--%NS%md-bottom-sheet-container-text-font, Roboto, sans-serif);font-size:var(--%NS%md-bottom-sheet-container-text-size, 14px);line-height:var(--%NS%md-bottom-sheet-container-text-line-height, 20px);font-weight:var(--%NS%md-bottom-sheet-container-text-weight, 400);letter-spacing:var(--%NS%md-bottom-sheet-container-text-tracking, normal);box-shadow:var(--%NS%md-bottom-sheet-container-shadow, 0 8px 10px -5px rgba(0, 0, 0, .2), 0 16px 24px 2px rgba(0, 0, 0, .14), 0 6px 30px 5px rgba(0, 0, 0, .12))}.md-bottom-sheet-container-animations-enabled{transform:translateY(100%)}.md-bottom-sheet-container-animations-enabled.md-bottom-sheet-container-enter{animation:_md-bottom-sheet-enter 195ms cubic-bezier(0,0,.2,1) forwards}.md-bottom-sheet-container-animations-enabled.md-bottom-sheet-container-exit{animation:_md-bottom-sheet-exit 375ms cubic-bezier(.4,0,1,1) backwards}.md-bottom-sheet-container-xlarge,.md-bottom-sheet-container-large,.md-bottom-sheet-container-medium{border-top-left-radius:var(--%NS%md-bottom-sheet-container-shape, 28px);border-top-right-radius:var(--%NS%md-bottom-sheet-container-shape, 28px)}.md-bottom-sheet-container-medium{min-width:384px;max-width:calc(100vw - 128px)}.md-bottom-sheet-container-large{min-width:512px;max-width:calc(100vw - 256px)}.md-bottom-sheet-container-xlarge{min-width:576px;max-width:calc(100vw - 384px)}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})();
var Zg = new k("MDBottomSheetData"), pn = class {
    viewContainerRef;
    injector;
    panelClass;
    direction;
    data = null;
    hasBackdrop = !0;
    backdropClass;
    disableClose = !1;
    ariaLabel = null;
    ariaModal = !1;
    closeOnNavigation = !0;
    autoFocus = "first-tabbable";
    restoreFocus = !0;
    scrollStrategy;
    height = "";
    minHeight;
    maxHeight;
    bindings;
};
var Qt = class {
    _ref;
    get instance() { return this._ref.componentInstance; }
    get componentRef() { return this._ref.componentRef; }
    containerInstance;
    disableClose;
    _afterOpened = new D;
    _result;
    _closeFallbackTimeout;
    constructor(a, e, i) { this._ref = a, this.containerInstance = i, this.disableClose = e.disableClose, i._animationStateChanged.pipe(V(o => o.phase === "done" && o.toState === "visible"), pe(1)).subscribe(() => { this._afterOpened.next(), this._afterOpened.complete(); }), i._animationStateChanged.pipe(V(o => o.phase === "done" && o.toState === "hidden"), pe(1)).subscribe(() => { clearTimeout(this._closeFallbackTimeout), this._ref.close(this._result); }), a.overlayRef.detachments().subscribe(() => { this._ref.close(this._result); }), R(this.backdropClick(), this.keydownEvents().pipe(V(o => o.keyCode === qe))).subscribe(o => { !this.disableClose && (o.type !== "keydown" || !q(o)) && (o.preventDefault(), this.dismiss()); }); }
    dismiss(a) { this.containerInstance && (this.containerInstance._animationStateChanged.pipe(V(e => e.phase === "start"), pe(1)).subscribe(() => { this._closeFallbackTimeout = setTimeout(() => this._ref.close(this._result), 500), this._ref.overlayRef.detachBackdrop(); }), this._result = a, this.containerInstance.exit(), this.containerInstance = null); }
    afterDismissed() { return this._ref.closed; }
    afterOpened() { return this._afterOpened; }
    backdropClick() { return this._ref.backdropClick; }
    keydownEvents() { return this._ref.keydownEvents; }
};
var Jg = new k("md-bottom-sheet-default-options"), ef = (() => { class n {
    _injector = d(j);
    _parentBottomSheet = d(n, { optional: !0, skipSelf: !0 });
    _animationsDisabled = d(Fr, { optional: !0 }) === "NoopAnimations";
    _defaultOptions = d(Jg, { optional: !0 });
    _bottomSheetRefAtThisLevel = null;
    _dialog = d(Rn);
    get _openedBottomSheetRef() { let e = this._parentBottomSheet; return e ? e._openedBottomSheetRef : this._bottomSheetRefAtThisLevel; }
    set _openedBottomSheetRef(e) { this._parentBottomSheet ? this._parentBottomSheet._openedBottomSheetRef = e : this._bottomSheetRefAtThisLevel = e; }
    open(e, i) { let o = _(_({}, this._defaultOptions || new pn), i), r; return this._dialog.open(e, G(_({}, o), { disableClose: !0, closeOnOverlayDetachments: !1, maxWidth: "100%", container: Xg, scrollStrategy: o.scrollStrategy || Pn(this._injector), positionStrategy: Zt(this._injector).centerHorizontally().bottom("0"), disableAnimations: this._animationsDisabled, templateContext: () => ({ bottomSheetRef: r }), providers: (s, l, c) => (r = new Qt(s, o, c), [{ provide: Qt, useValue: r }, { provide: Zg, useValue: o.data }]) })), r.afterDismissed().subscribe(() => { this._openedBottomSheetRef === r && (this._openedBottomSheetRef = null); }), this._openedBottomSheetRef ? (this._openedBottomSheetRef.afterDismissed().subscribe(() => r.containerInstance?.enter()), this._openedBottomSheetRef.dismiss()) : r.containerInstance.enter(), this._openedBottomSheetRef = r, r; }
    dismiss(e) { this._openedBottomSheetRef && this._openedBottomSheetRef.dismiss(e); }
    ngOnDestroy() { this._bottomSheetRefAtThisLevel && this._bottomSheetRefAtThisLevel.dismiss(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac });
} return n; })();
var Yy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ providers: [ef], imports: [An, Nn, Qe] });
} return n; })();
var tf = (() => {
    class n {
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["button", "md-button", ""], ["a", "md-button", ""], ["button", "md-primary-button", ""], ["a", "md-primary-button", ""], ["button", "md-secondary-button", ""], ["a", "md-secondary-button", ""], ["button", "md-success-button", ""], ["a", "md-success-button", ""], ["button", "md-danger-button", ""], ["a", "md-danger-button", ""], ["button", "md-light-button", ""], ["a", "md-light-button", ""], ["button", "md-warning-button", ""], ["a", "md-warning-button", ""], ["button", "md-info-button", ""], ["a", "md-info-button", ""], ["button", "md-dark-button", ""], ["a", "md-dark-button", ""], ["button", "md-link-button", ""], ["a", "md-link-button", ""], ["button", "md-status-primary-button", ""], ["a", "md-status-primary-button", ""], ["button", "md-status-danger-button", ""], ["a", "md-status-danger-button", ""]], ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275projection(0)); }, styles: [`button[md-button],a[md-button],button[md-primary-button],a[md-primary-button],button[md-secondary-button],a[md-secondary-button],button[md-success-button],a[md-success-button],button[md-danger-button],a[md-danger-button],button[md-light-button],a[md-light-button],button[md-warning-button],a[md-warning-button],button[md-info-button],a[md-info-button],button[md-dark-button],a[md-dark-button],button[md-link-button],a[md-link-button]{padding-left:var(--%NS%md-button-padding-x, 2em);padding-right:var(--%NS%md-button-padding-x, 2em);min-height:var(--%NS%md-button-min-height, 36px);border:none;border-radius:var(--%NS%md-button-radius, 5px);font-family:var(--%NS%md-button-font-family, Montserrat);font-weight:var(--%NS%md-button-font-weight, 600);font-size:14px;line-height:24px}button[md-primary-button],a[md-primary-button]{color:var(--%NS%md-button-primary-color, #fff);background-color:var(--%NS%md-button-primary-bg, #4D4D4D)}button[md-primary-button]:hover,a[md-primary-button]:hover{color:var(--%NS%md-button-primary-hover-color, #fff);background-color:var(--%NS%md-button-primary-hover-bg, #929292);opacity:1}button[md-primary-button]:disabled,a[md-primary-button]:disabled{color:var(--%NS%md-button-primary-hover-color, #fff);background-color:var(--%NS%md-button-primary-hover-bg, #929292);opacity:.5;cursor:not-allowed}button[md-secondary-button],a[md-secondary-button]{color:var(--%NS%md-button-secondary-color, #000);background-color:var(--%NS%md-button-secondary-bg, #EAEAEA)}button[md-secondary-button]:hover,a[md-secondary-button]:hover{color:var(--%NS%md-button-secondary-hover-color, #CF0106);background-color:var(--%NS%md-button-secondary-hover-bg, #EAEAEA);opacity:1}button[md-secondary-button]:disabled,a[md-secondary-button]:disabled{color:var(--%NS%md-button-secondary-hover-color, #CF0106);background-color:var(--%NS%md-button-secondary-hover-bg, #EAEAEA);opacity:.5;cursor:not-allowed}button[md-success-button],a[md-success-button]{color:var(--%NS%md-button-success-color, #fff);background-color:var(--%NS%md-button-success-bg, #28B446)}button[md-success-button]:hover,a[md-success-button]:hover{color:var(--%NS%md-button-success-hover-color, #fff);background-color:var(--%NS%md-button-success-hover-bg, #28B446);opacity:.8}button[md-success-button]:disabled,a[md-success-button]:disabled{color:var(--%NS%md-button-success-hover-color, #fff);background-color:var(--%NS%md-button-success-hover-bg, #28B446);opacity:.5;cursor:not-allowed}button[md-danger-button],a[md-danger-button]{color:var(--%NS%md-button-danger-color, #fff);background-color:var(--%NS%md-button-danger-bg, #CF0106)}button[md-danger-button]:hover,a[md-danger-button]:hover{color:var(--%NS%md-button-danger-hover-color, #fff);background-color:var(--%NS%md-button-danger-hover-bg, #4D4D4D);opacity:1}button[md-danger-button]:disabled,a[md-danger-button]:disabled{color:var(--%NS%md-button-danger-hover-color, #fff);background-color:var(--%NS%md-button-danger-hover-bg, #4D4D4D);opacity:.5;cursor:not-allowed}button[md-light-button],a[md-light-button]{color:var(--%NS%md-button-light-color, #000);background-color:var(--%NS%md-button-light-bg, #FFFFFF)}button[md-light-button]:hover,a[md-light-button]:hover{color:var(--%NS%md-button-light-hover-color, #CF0106);background-color:var(--%NS%md-button-light-hover-bg, #FFFFFF);opacity:1}button[md-light-button]:disabled,a[md-light-button]:disabled{color:var(--%NS%md-button-light-hover-color, #CF0106);background-color:var(--%NS%md-button-light-hover-bg, #FFFFFF);opacity:.5;cursor:not-allowed}button[md-warning-button],a[md-warning-button]{color:var(--%NS%md-button-warning-color, #000);background-color:var(--%NS%md-button-warning-bg, #ffc107)}button[md-warning-button]:hover,a[md-warning-button]:hover{color:var(--%NS%md-button-warning-hover-color, #000);background-color:var(--%NS%md-button-warning-hover-bg, #ffc107);opacity:.85}button[md-warning-button]:disabled,a[md-warning-button]:disabled{color:var(--%NS%md-button-warning-hover-color, #000);background-color:var(--%NS%md-button-warning-hover-bg, #ffc107);opacity:.5;cursor:not-allowed}button[md-info-button],a[md-info-button]{color:var(--%NS%md-button-info-color, #fff);background-color:var(--%NS%md-button-info-bg, #0185CF)}button[md-info-button]:hover,a[md-info-button]:hover{color:var(--%NS%md-button-info-hover-color, #fff);background-color:var(--%NS%md-button-info-hover-bg, #0185CF);opacity:.85}button[md-info-button]:disabled,a[md-info-button]:disabled{color:var(--%NS%md-button-info-hover-color, #fff);background-color:var(--%NS%md-button-info-hover-bg, #0185CF);opacity:.5;cursor:not-allowed}button[md-dark-button],a[md-dark-button]{color:var(--%NS%md-button-dark-color, #fff);background-color:var(--%NS%md-button-dark-bg, #373737)}button[md-dark-button]:hover,a[md-dark-button]:hover{color:var(--%NS%md-button-dark-hover-color, #fff);background-color:var(--%NS%md-button-dark-hover-bg, #4D4D4D);opacity:1}button[md-dark-button]:disabled,a[md-dark-button]:disabled{color:var(--%NS%md-button-dark-hover-color, #fff);background-color:var(--%NS%md-button-dark-hover-bg, #4D4D4D);opacity:.5;cursor:not-allowed}button[md-link-button],a[md-link-button]{color:var(--%NS%md-color-link, #6d5cae);background-color:transparent;text-decoration:underline}button[md-link-button]:hover,a[md-link-button]:hover{color:var(--%NS%md-color-link-hover, #CF0106)}button[md-link-button]:disabled,a[md-link-button]:disabled{color:var(--%NS%md-color-text-muted, #929292);cursor:not-allowed}button[md-status-primary-button],a[md-status-primary-button]{padding-left:var(--%NS%md-button-status-padding-x, var(--%NS%md-button-padding-x, 2em));padding-right:var(--%NS%md-button-status-padding-x, var(--%NS%md-button-padding-x, 2em));min-height:var(--%NS%md-button-status-min-height, 23px);border:0;border-radius:var(--%NS%md-button-status-radius, var(--%NS%md-button-radius, 5px));color:var(--%NS%md-button-status-color, #000);background-color:var(--%NS%md-button-status-bg, #EAEAEA);font-family:var(--%NS%md-button-status-font-family, var(--%NS%md-font-body, "Open Sans"));font-size:11px;line-height:13px}button[md-status-primary-button]:hover,a[md-status-primary-button]:hover{color:var(--%NS%md-color-danger, #CF0106);background-color:var(--%NS%md-button-status-hover-bg, #F3F3F3)}button[md-status-danger-button],a[md-status-danger-button]{padding-left:var(--%NS%md-button-status-padding-x, var(--%NS%md-button-padding-x, 2em));padding-right:var(--%NS%md-button-status-padding-x, var(--%NS%md-button-padding-x, 2em));min-height:var(--%NS%md-button-status-min-height, 23px);border:0;border-radius:var(--%NS%md-button-status-radius, var(--%NS%md-button-radius, 5px));color:var(--%NS%md-color-danger, #CF0106);background-color:var(--%NS%md-button-status-bg, #EAEAEA);font-family:var(--%NS%md-button-status-font-family, var(--%NS%md-font-body, "Open Sans"));font-size:11px;line-height:13px}button[md-status-danger-button]:hover,a[md-status-danger-button]:hover{color:var(--%NS%md-button-status-color, #000);background-color:var(--%NS%md-button-status-hover-bg, #F3F3F3)}
`], encapsulation: 2 });
    }
    return n;
})(), qy = [tf], Qy = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), Un = new k("MD_DATEPICKER_ACTIONS_OWNER"), ii = (() => { class n {
    owner = d(Un);
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-datepicker-actions"], ["md-date-range-picker-actions"]], ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275projection(0)); }, styles: ["[_nghost-%COMP%]{display:flex;width:100%;box-sizing:border-box;justify-content:flex-end;align-items:center;gap:4px;padding:4px 8px 8px}"] });
} return n; })(), Ky = (() => { class n {
    actions = d(ii);
    cancel() { this.actions.owner.cancelPendingSelection(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdDatepickerCancel", ""], ["", "mdDateRangePickerCancel", ""]], hostAttrs: [1, "md-datepicker-action", "md-datepicker-action--cancel"], hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function () { return o.cancel(); }); } });
} return n; })(), Uy = (() => { class n {
    actions = d(ii);
    apply() { this.actions.owner.applyPendingSelection(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdDatepickerApply", ""], ["", "mdDateRangePickerApply", ""]], hostAttrs: [1, "md-datepicker-action", "md-datepicker-action--apply"], hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function () { return o.apply(); }); } });
} return n; })(), Xy = (() => {
    class n {
        cdr = d(E);
        overlay = d(yt);
        input;
        activeMonth = Gi(new Date);
        pendingValue = null;
        disabledOverride;
        popupScrollStrategy = this.overlay.scrollStrategies.reposition();
        dialogScrollStrategy = this.overlay.scrollStrategies.block();
        panel;
        get disabled() { return this.disabledOverride ?? this.input?.disabled ?? !1; }
        set disabled(e) { this.disabledOverride = e; }
        startAt = null;
        startView = "month";
        touchUi = !1;
        panelClass = "";
        dateClass = null;
        locale;
        calendarHeaderComponent = null;
        openedChange = new p;
        openedEvent = new p;
        closedEvent = new p;
        selectedChange = new p;
        yearSelected = new p;
        monthSelected = new p;
        actions;
        positions = [{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top", offsetY: 8 }, { originX: "start", originY: "top", overlayX: "start", overlayY: "bottom", offsetY: -8 }];
        weekdays = nf();
        opened = !1;
        currentView = "month";
        get overlayScrollStrategy() { return this.touchUi ? this.dialogScrollStrategy : this.popupScrollStrategy; }
        get origin() { return this.input?.elementRef ?? null; }
        get periodLabel() { if (this.currentView === "multi-year") {
            let e = this.multiYearStart;
            return `${e} \u2013 ${e + 23}`;
        } return this.currentView === "year" ? String(this.activeMonth.getFullYear()) : new Intl.DateTimeFormat(this.locale, { month: "long", year: "numeric" }).format(this.activeMonth); }
        get days() { let e = De(this.actions ? this.pendingValue : this.input?.value), i = Gi(this.activeMonth), o = new Date(i.getFullYear(), i.getMonth() + 1, 0).getDate(), r = Math.ceil((i.getDay() + o) / 7) * 7, s = new Date(i.getFullYear(), i.getMonth(), i.getDate() - i.getDay()); return Array.from({ length: r }, (l, c) => { let h = new Date(s.getFullYear(), s.getMonth(), s.getDate() + c), g = h.getMonth() !== this.activeMonth.getMonth(); return { date: h, label: h.getDate(), outside: g, disabled: g || !this.input?.isDateEnabled(h), selected: !!e && $i(h, e), today: $i(h, new Date), cssClass: this.dateClass?.(h, "month") ?? null }; }); }
        get periods() { let e = De(this.input?.value); if (this.currentView === "year") {
            let i = new Intl.DateTimeFormat(this.locale, { month: "short" });
            return Array.from({ length: 12 }, (o, r) => ({ value: r, label: i.format(new Date(this.activeMonth.getFullYear(), r, 1)), selected: !!e && e.getFullYear() === this.activeMonth.getFullYear() && e.getMonth() === r, disabled: !this.shouldEnableMonth(this.activeMonth.getFullYear(), r) }));
        } return Array.from({ length: 24 }, (i, o) => { let r = this.multiYearStart + o; return { value: r, label: String(r), selected: e?.getFullYear() === r, disabled: !this.shouldEnableYear(r) }; }); }
        get multiYearStart() { let e = this.activeMonth.getFullYear(), i = this.maxDate ? this.maxDate.getFullYear() - 23 : this.minDate?.getFullYear() ?? 0, o = ((e - i) % 24 + 24) % 24; return e - o; }
        registerInput(e) { this.input = e; }
        open() { let e = this.input; this.disabled || !e || this.opened || (this.activeMonth = Gi(this.clampDate(De(e.value) ?? De(this.startAt) ?? new Date)), this.pendingValue = e.value, this.currentView = this.startView, this.opened = !0, this.openedChange.emit(!0), this.openedEvent.emit(), this.cdr.markForCheck(), setTimeout(() => this.focusActiveDay())); }
        close() { this.opened && (this.opened = !1, this.openedChange.emit(!1), this.closedEvent.emit(), this.cdr.markForCheck()); }
        toggle() { this.opened ? this.close() : this.open(); }
        previousPeriod() { let e = this.currentView === "month" || this.currentView === "year" ? -1 : -24; this.activeMonth = this.currentView === "month" ? new Date(this.activeMonth.getFullYear(), this.activeMonth.getMonth() + e, 1) : new Date(this.activeMonth.getFullYear() + e, this.activeMonth.getMonth(), 1), this.cdr.markForCheck(); }
        nextPeriod() { let e = this.currentView === "month" || this.currentView === "year" ? 1 : 24; this.activeMonth = this.currentView === "month" ? new Date(this.activeMonth.getFullYear(), this.activeMonth.getMonth() + e, 1) : new Date(this.activeMonth.getFullYear() + e, this.activeMonth.getMonth(), 1), this.cdr.markForCheck(); }
        canNavigate(e) { let i = this.minDate, o = this.maxDate; if (this.currentView === "month") {
            let l = new Date(this.activeMonth.getFullYear(), this.activeMonth.getMonth() + e, 1), c = new Date(l.getFullYear(), l.getMonth() + 1, 0);
            return (!i || c >= i) && (!o || l <= o);
        } if (this.currentView === "year") {
            let l = this.activeMonth.getFullYear() + e;
            return (!i || l >= i.getFullYear()) && (!o || l <= o.getFullYear());
        } let r = this.multiYearStart + e * 24, s = r + 23; return (!i || s >= i.getFullYear()) && (!o || r <= o.getFullYear()); }
        openHigherView() { this.currentView = this.currentView === "month" ? "year" : "multi-year", this.cdr.markForCheck(); }
        selectPeriod(e) { if (e.disabled)
            return; let i = e.value; this.currentView === "multi-year" ? (this.activeMonth = new Date(i, this.activeMonth.getMonth(), 1), this.yearSelected.emit(new Date(i, 0, 1)), this.currentView = "year") : (this.activeMonth = new Date(this.activeMonth.getFullYear(), i, 1), this.monthSelected.emit(new Date(this.activeMonth.getFullYear(), i, 1)), this.currentView = "month"), this.cdr.markForCheck(); }
        select(e) { if (e.disabled || !this.input)
            return; let i = e.date; this.actions ? (this.pendingValue = i, this.cdr.markForCheck()) : (this.input.select(i), this.selectedChange.emit(i), this.close()); }
        applyPendingSelection() { this.pendingValue && this.input && (this.input.select(this.pendingValue), this.selectedChange.emit(this.pendingValue)), this.close(); }
        cancelPendingSelection() { this.pendingValue = null, this.close(); }
        handleKeydown(e) { e.key === "Escape" && (e.preventDefault(), this.close()); }
        formatAccessibleDate(e) { return new Intl.DateTimeFormat(this.locale, { dateStyle: "full" }).format(e); }
        isActiveDay(e) { if (e.disabled)
            return !1; let i = De(this.actions ? this.pendingValue : this.input?.value); if (i)
            return $i(e.date, i); let o = new Date; return o.getFullYear() === this.activeMonth.getFullYear() && o.getMonth() === this.activeMonth.getMonth() ? e.today : e.label === 1; }
        focusActiveDay() { this.opened && this.panel?.nativeElement.querySelector('.md-datepicker-grid button[tabindex="0"]')?.focus(); }
        get minDate() { return De(this.input?.min); }
        get maxDate() { return De(this.input?.max); }
        clampDate(e) { let i = this.minDate, o = this.maxDate; return i && e < i ? i : o && e > o ? o : e; }
        shouldEnableMonth(e, i) { let o = new Date(e, i, 1), r = new Date(e, i + 1, 0); if (this.minDate && r < this.minDate || this.maxDate && o > this.maxDate)
            return !1; if (!this.input?.dateFilter)
            return !0; for (let s = 1; s <= r.getDate(); s++)
            if (this.input.isDateEnabled(new Date(e, i, s)))
                return !0; return !1; }
        shouldEnableYear(e) { if (this.minDate && e < this.minDate.getFullYear() || this.maxDate && e > this.maxDate.getFullYear())
            return !1; if (!this.input?.dateFilter)
            return !0; for (let i = 0; i < 12; i++)
            if (this.shouldEnableMonth(e, i))
                return !0; return !1; }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-datepicker"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, ii, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.actions = s.first);
            } }, viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(Hn, 5), i & 2) {
                let r;
                t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.panel = r.first);
            } }, inputs: { disabled: [2, "disabled", "disabled", m], startAt: "startAt", startView: "startView", touchUi: [2, "touchUi", "touchUi", m], panelClass: "panelClass", dateClass: "dateClass", locale: "locale", calendarHeaderComponent: "calendarHeaderComponent" }, outputs: { openedChange: "openedChange", openedEvent: "opened", closedEvent: "closed", selectedChange: "selectedChange", yearSelected: "yearSelected", monthSelected: "monthSelected" }, exportAs: ["mdDatepicker"], features: [t.\u0275\u0275ProvidersFeature([{ provide: Un, useExisting: A(() => n) }])], ngContentSelectors: fh, decls: 1, vars: 1, consts: [["panel", ""], ["cdk-connected-overlay", "", "cdkConnectedOverlayHasBackdrop", "", 3, "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayScrollStrategy"], ["cdk-connected-overlay", "", "cdkConnectedOverlayHasBackdrop", "", 3, "backdropClick", "detach", "overlayKeydown", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayScrollStrategy"], ["role", "dialog", "aria-modal", "true", "aria-label", "Choose a date", 1, "md-datepicker-panel", 3, "cdkTrapFocus", "cdkTrapFocusAutoCapture", "ngClass"], [1, "md-datepicker-header"], ["role", "grid", 1, "md-datepicker-period-grid", 3, "md-datepicker-period-grid--years"], [4, "ngComponentOutlet"], ["type", "button", "aria-label", "Previous period", 3, "click", "disabled"], ["viewBox", "0 0 24 24", "aria-hidden", "true", "focusable", "false"], ["d", "M15 18 9 12l6-6"], ["type", "button", 1, "md-datepicker-period", 3, "click"], ["type", "button", "aria-label", "Next period", 3, "click", "disabled"], ["d", "m9 18 6-6-6-6"], ["aria-hidden", "true", 1, "md-datepicker-weekdays"], ["role", "grid", 1, "md-datepicker-grid"], ["type", "button", "role", "gridcell", 3, "ngClass", "md-datepicker-day--outside", "md-datepicker-day--selected", "md-datepicker-day--today", "disabled"], ["type", "button", "role", "gridcell", 3, "click", "ngClass", "disabled"], [1, "md-datepicker-cell-content"], ["role", "grid", 1, "md-datepicker-period-grid"], ["type", "button", "role", "gridcell", 3, "md-datepicker-period--selected", "disabled"], ["type", "button", "role", "gridcell", 3, "click", "disabled"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(gh), t.\u0275\u0275conditionalCreate(0, Dh, 1, 6, null, 1)), i & 2 && t.\u0275\u0275conditional(o.origin ? 0 : -1); }, dependencies: [ct, Lr, kn, vd], styles: [`@keyframes md-datepicker-content-enter{0%{opacity:0;transform:scaleY(.8)}to{opacity:1;transform:none}}@keyframes md-datepicker-dialog-enter{0%{opacity:0;transform:scale(.8)}to{opacity:1;transform:none}}.md-datepicker-panel{display:block;width:min(296px,100vw - 32px);overflow:hidden;border:0;border-radius:var(--%NS%md-radius-lg);background:var(--%NS%md-datepicker-container-background);color:var(--%NS%md-datepicker-container-text);box-shadow:var(--%NS%md-shadow-md);font-family:var(--%NS%md-font-body);font-size:13px;line-height:normal;animation:md-datepicker-content-enter .12s cubic-bezier(0,0,.2,1)}.md-datepicker-panel--touch{position:relative;width:64vh;height:80vh;min-width:250px;max-width:750px;min-height:fit-content;max-height:788px;overflow:visible;pointer-events:auto;animation:md-datepicker-dialog-enter .15s cubic-bezier(0,0,.2,1)}.cdk-overlay-pane:has(.md-datepicker-panel--touch){position:fixed!important;inset:0!important;display:flex;align-items:center;justify-content:center;transform:none!important;pointer-events:none}.md-datepicker-panel--touch .md-datepicker-weekdays,.md-datepicker-panel--touch .md-datepicker-grid{grid-template-columns:repeat(7,minmax(0,1fr))}.md-datepicker-panel--touch .md-datepicker-grid button{width:100%;height:auto;aspect-ratio:1}.md-datepicker-header{display:grid;grid-template-columns:40px minmax(0,1fr) 40px;align-items:center;padding:8px 8px 0;color:var(--%NS%md-datepicker-header-text);text-align:center}.md-datepicker-header button,.md-datepicker-period-grid button,.md-datepicker-grid button{margin:0;padding:0;border:0;background:transparent;color:inherit;font:inherit;text-align:center;outline:none;cursor:pointer}.md-datepicker-header button{display:inline-grid;width:40px;height:40px;place-items:center;border-radius:50%}.md-datepicker-header button:hover:not(:disabled){background:var(--%NS%md-datepicker-hover-background)}.md-datepicker-header button:disabled{color:color-mix(in srgb,var(--%NS%md-datepicker-header-text) 38%,transparent);cursor:default}.md-datepicker-header button:focus-visible{background:var(--%NS%md-datepicker-focus-background);outline:2px solid var(--%NS%md-color-focus);outline-offset:-2px}.md-datepicker-header button svg{display:block;width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:2.25;stroke-linecap:round;stroke-linejoin:round}.md-datepicker-header .md-datepicker-period{width:auto;min-width:0;margin:0 8px;border-radius:20px;font-weight:600}.md-datepicker-weekdays,.md-datepicker-grid{display:grid;grid-template-columns:repeat(7,minmax(0,40px));padding-inline:8px}.md-datepicker-weekdays span{display:grid;height:32px;place-items:center;color:var(--%NS%md-datepicker-header-text);font-size:12px;font-weight:600}.md-datepicker-grid{padding-bottom:8px}.md-datepicker-grid button{position:relative;display:block;width:40px;height:40px;color:var(--%NS%md-datepicker-date-text)}:where(.md-datepicker-grid) button:before,:where(.md-datepicker-grid) button:after,.md-datepicker-cell-preview{position:absolute;top:5%;left:0;z-index:0;display:block;box-sizing:border-box;width:100%;height:90%;content:"";pointer-events:none}.md-datepicker-cell-content{position:absolute;top:5%;left:5%;z-index:1;display:flex;box-sizing:border-box;width:90%;height:90%;align-items:center;justify-content:center;border:1px solid transparent;border-radius:999px;color:inherit;line-height:1}.md-datepicker-day--outside{visibility:hidden;pointer-events:none}.md-datepicker-day--today>.md-datepicker-cell-content{border-color:var(--%NS%md-datepicker-today-outline)}.md-datepicker-day--selected>.md-datepicker-cell-content,.md-datepicker-day--range-start>.md-datepicker-cell-content,.md-datepicker-day--range-end>.md-datepicker-cell-content{border-color:transparent;background:var(--%NS%md-datepicker-selected-background);color:var(--%NS%md-datepicker-selected-text)}.md-datepicker-day--selected.md-datepicker-day--today>.md-datepicker-cell-content,.md-datepicker-day--range-start.md-datepicker-day--today>.md-datepicker-cell-content,.md-datepicker-day--range-end.md-datepicker-day--today>.md-datepicker-cell-content{box-shadow:inset 0 0 0 1px var(--%NS%md-datepicker-today-outline)}.md-datepicker-grid button:focus-visible:not(.md-datepicker-day--selected):not(.md-datepicker-day--range-start):not(.md-datepicker-day--range-end)>.md-datepicker-cell-content{background:var(--%NS%md-datepicker-focus-background)}@media(hover:hover){.md-datepicker-grid button:hover:not(:disabled):not(.md-datepicker-day--selected):not(.md-datepicker-day--range-start):not(.md-datepicker-day--range-end)>.md-datepicker-cell-content{background:var(--%NS%md-datepicker-hover-background)}}.md-datepicker-grid button:disabled{cursor:default}.md-datepicker-grid button:disabled>.md-datepicker-cell-content{color:color-mix(in srgb,var(--%NS%md-datepicker-date-text) 38%,transparent)}.md-datepicker-day--%NS%in-range:before,.md-datepicker-day--%NS%range-start:before,.md-datepicker-day--%NS%range-end:before{background:var(--%NS%md-datepicker-range-background)}.md-datepicker-day--%NS%range-start:not(.md-datepicker-day--in-comparison):before,.md-datepicker-day--%NS%range-start:after,.md-datepicker-day--preview-start>.md-datepicker-cell-preview,.md-datepicker-day--%NS%comparison-start:not(.md-datepicker-day--comparison-bridge-start):before,.md-datepicker-day--%NS%comparison-start:after{left:5%;width:95%;border-radius:999px 0 0 999px}.md-datepicker-day--%NS%range-end:not(.md-datepicker-day--in-comparison):before,.md-datepicker-day--%NS%range-end:after,.md-datepicker-day--preview-end>.md-datepicker-cell-preview,.md-datepicker-day--%NS%comparison-end:not(.md-datepicker-day--comparison-bridge-end):before,.md-datepicker-day--%NS%comparison-end:after{width:95%;border-radius:0 999px 999px 0}.md-datepicker-day--range-start.md-datepicker-day--%NS%range-end:before,.md-datepicker-day--range-start.md-datepicker-day--%NS%range-end:after,.md-datepicker-day--preview-start.md-datepicker-day--preview-end>.md-datepicker-cell-preview,.md-datepicker-day--comparison-start.md-datepicker-day--%NS%comparison-end:after{left:5%;width:90%;border-radius:999px}.md-datepicker-day--in-preview{color:var(--%NS%md-datepicker-preview-outline)}.md-datepicker-day--in-preview>.md-datepicker-cell-preview{border-block:1px dashed currentColor}.md-datepicker-day--preview-start>.md-datepicker-cell-preview{border-left:1px dashed currentColor}.md-datepicker-day--preview-end>.md-datepicker-cell-preview{border-right:1px dashed currentColor}.md-datepicker-day--comparison-identical>.md-datepicker-cell-content,.md-datepicker-day--%NS%in-comparison:before{background:var(--%NS%md-datepicker-comparison-background)}.md-datepicker-day--%NS%comparison-bridge-start:before{background:linear-gradient(to right,var(--%NS%md-datepicker-range-background) 50%,var(--%NS%md-datepicker-comparison-background) 50%)}.md-datepicker-day--%NS%comparison-bridge-end:before{background:linear-gradient(to left,var(--%NS%md-datepicker-range-background) 50%,var(--%NS%md-datepicker-comparison-background) 50%)}.md-datepicker-day--in-comparison.md-datepicker-day--%NS%in-range:after,.md-datepicker-day--in-range.md-datepicker-day--comparison-identical>.md-datepicker-cell-content{background:var(--%NS%md-datepicker-overlap-background)}.md-datepicker-day--comparison-identical.md-datepicker-day--selected>.md-datepicker-cell-content,.md-datepicker-day--in-comparison.md-datepicker-day--selected>.md-datepicker-cell-content{background:var(--%NS%md-datepicker-overlap-selected-background)}.md-datepicker-day--comparison-start.md-datepicker-day--%NS%range-end:after,.md-datepicker-day--comparison-end.md-datepicker-day--%NS%range-start:after{width:90%}[dir=rtl] .md-datepicker-day--%NS%range-start:before,[dir=rtl] .md-datepicker-day--preview-start>.md-datepicker-cell-preview,[dir=rtl] .md-datepicker-day--%NS%comparison-start:before,[dir=rtl] .md-datepicker-day--%NS%comparison-start:after{right:5%;left:0;border-radius:0 999px 999px 0}[dir=rtl] .md-datepicker-day--%NS%range-end:before,[dir=rtl] .md-datepicker-day--preview-end>.md-datepicker-cell-preview,[dir=rtl] .md-datepicker-day--%NS%comparison-end:before,[dir=rtl] .md-datepicker-day--%NS%comparison-end:after{right:0;left:5%;border-radius:999px 0 0 999px}[dir=rtl] .md-datepicker-day--%NS%comparison-bridge-start:before{background:linear-gradient(to left,var(--%NS%md-datepicker-range-background) 50%,var(--%NS%md-datepicker-comparison-background) 50%)}[dir=rtl] .md-datepicker-day--%NS%comparison-bridge-end:before{background:linear-gradient(to right,var(--%NS%md-datepicker-range-background) 50%,var(--%NS%md-datepicker-comparison-background) 50%)}.md-datepicker-period-grid{display:grid;min-height:280px;grid-template-columns:repeat(3,1fr);gap:8px;align-content:center;padding:8px}.md-datepicker-period-grid--years{grid-template-columns:repeat(4,1fr)}.md-datepicker-period-grid button{min-height:40px;border-radius:20px}.md-datepicker-period-grid button:hover:not(:disabled){background:var(--%NS%md-datepicker-hover-background)}.md-datepicker-period-grid button:focus-visible{background:var(--%NS%md-datepicker-focus-background)}.md-datepicker-period-grid .md-datepicker-period--selected{background:var(--%NS%md-datepicker-selected-background);color:var(--%NS%md-datepicker-selected-text)}.md-datepicker-period-grid button:disabled{color:color-mix(in srgb,var(--%NS%md-datepicker-date-text) 38%,transparent);cursor:default}.md-datepicker-action{display:inline-flex;min-width:60px;height:32px;box-sizing:border-box;align-items:center;justify-content:center;padding:0 12px;border:0;border-radius:var(--%NS%md-radius-md);font:inherit;font-size:12px;font-weight:600;line-height:1;cursor:pointer;transition:background-color .12s ease,color .12s ease}.md-datepicker-action--cancel{background:transparent;color:var(--%NS%md-datepicker-container-text)}.md-datepicker-action--%NS%cancel:hover{background:var(--%NS%md-datepicker-hover-background)}.md-datepicker-action--apply{background:var(--%NS%md-datepicker-selected-background);color:var(--%NS%md-datepicker-selected-text)}.md-datepicker-action--%NS%apply:hover{background:color-mix(in srgb,var(--%NS%md-datepicker-selected-background) 86%,white)}.md-datepicker-action:focus-visible{outline:2px solid var(--%NS%md-color-focus);outline-offset:1px}.md-calendar-inline{box-shadow:none;animation:none}@media(forced-colors:active){.md-datepicker-panel{border:1px solid CanvasText}.md-datepicker-day--%NS%in-range:before{border-block:1px solid CanvasText;background:none}.md-datepicker-day--%NS%in-comparison:before{border-block:1px dashed CanvasText;background:none}}@media all and (orientation:portrait){.md-datepicker-panel--touch{width:80vw;height:100vw}}
`], encapsulation: 2 });
    }
    return n;
})();
function De(n) { return n instanceof Date && !Number.isNaN(n.getTime()) ? n : null; }
function Gi(n) { return new Date(n.getFullYear(), n.getMonth(), 1); }
function $i(n, a) { return n.getFullYear() === a.getFullYear() && n.getMonth() === a.getMonth() && n.getDate() === a.getDate(); }
function nf() { let n = new Date(2024, 0, 7), a = new Intl.DateTimeFormat(void 0, { weekday: "short" }); return Array.from({ length: 7 }, (e, i) => a.format(new Date(2024, 0, n.getDate() + i))); }
var Zy = (() => { class n {
    elementRef;
    min = null;
    max = null;
    dateFilter = null;
    dateParser = null;
    dateFormatter = null;
    dateInput = new p;
    dateChange = new p;
    value = null;
    disabled = !1;
    picker;
    onChange = () => { };
    onTouched = () => { };
    validatorChange = () => { };
    constructor(e) { this.elementRef = e; }
    set mdDatepicker(e) { this.picker = e, e.registerInput(this); }
    writeValue(e) { this.value = e, this.elementRef.nativeElement.value = this.formatValue(e); }
    registerOnChange(e) { this.onChange = e; }
    registerOnTouched(e) { this.onTouched = e; }
    registerOnValidatorChange(e) { this.validatorChange = e; }
    setDisabledState(e) { this.disabled = e, this.elementRef.nativeElement.disabled = e; }
    validate(e) { if (!this.value)
        return null; let i = Te(this.value); return i ? this.min && i < Te(this.min) ? { mdDatepickerMin: { min: this.min, actual: this.value } } : this.max && i > Te(this.max) ? { mdDatepickerMax: { max: this.max, actual: this.value } } : this.dateFilter && !this.dateFilter(this.value) ? { mdDatepickerFilter: !0 } : null : { mdDatepickerParse: !0 }; }
    isDateEnabled(e) { let i = Te(e); return !!i && (!this.min || i >= Te(this.min)) && (!this.max || i <= Te(this.max)) && (!this.dateFilter || this.dateFilter(e)); }
    select(e) { this.value = e, this.elementRef.nativeElement.value = this.formatValue(e), this.onChange(e), this.validatorChange(), this.emit(this.dateInput), this.emit(this.dateChange); }
    handleInput(e) { let i = e.target.value; this.value = this.dateParser ? this.dateParser(i) : of(i), this.onChange(this.value), this.validatorChange(), this.emit(this.dateInput); }
    handleChange() { this.emit(this.dateChange); }
    handleBlur() { this.onTouched(); }
    openFromKeyboard(e) { e.preventDefault(), this.picker?.open(); }
    emit(e) { e.emit({ target: this, targetElement: this.elementRef.nativeElement, value: this.value }); }
    formatValue(e) { return this.dateFormatter ? this.dateFormatter(e) : rf(e); }
    static \u0275fac = function (i) { return new (i || n)(t.\u0275\u0275directiveInject(t.ElementRef)); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["input", "mdDatepicker", ""]], hostAttrs: ["autocomplete", "off", 1, "md-datepicker-input"], hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("input", function (s) { return o.handleInput(s); })("change", function () { return o.handleChange(); })("blur", function () { return o.handleBlur(); })("keydown.alt.arrowdown", function (s) { return o.openFromKeyboard(s); }); }, inputs: { min: "min", max: "max", dateFilter: [0, "mdDatepickerFilter", "dateFilter"], dateParser: [0, "mdDatepickerParse", "dateParser"], dateFormatter: [0, "mdDatepickerFormat", "dateFormatter"], mdDatepicker: "mdDatepicker" }, outputs: { dateInput: "dateInput", dateChange: "dateChange" }, exportAs: ["mdDatepickerInput"], features: [t.\u0275\u0275ProvidersFeature([{ provide: J, useExisting: A(() => n), multi: !0 }, { provide: xt, useExisting: A(() => n), multi: !0 }])] });
} return n; })();
function Te(n) { return n instanceof Date && !Number.isNaN(n.getTime()) ? n : null; }
function of(n) { if (!n.trim())
    return null; let a = new Date(n); return Number.isNaN(a.getTime()) ? null : a; }
function rf(n) { let a = Te(n); return a ? a.toLocaleDateString() : ""; }
var af = (() => { class n {
    openCalendarLabel = "Open calendar";
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), sf = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdDatepickerToggleIcon", ""]] });
} return n; })(), Jy = (() => {
    class n {
        intl;
        datepicker = null;
        disabled = !1;
        ariaLabel;
        customIcon;
        constructor(e) { this.intl = e; }
        static \u0275fac = function (i) { return new (i || n)(t.\u0275\u0275directiveInject(af)); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-datepicker-toggle"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, sf, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.customIcon = s.first);
            } }, hostAttrs: [1, "md-datepicker-toggle"], hostVars: 2, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("md-datepicker-toggle--active", !!o.datepicker?.opened); }, inputs: { datepicker: [0, "for", "datepicker"], disabled: [2, "disabled", "disabled", m], ariaLabel: [0, "aria-label", "ariaLabel"] }, exportAs: ["mdDatepickerToggle"], ngContentSelectors: Th, decls: 3, vars: 5, consts: [["type", "button", 3, "click", "disabled"], ["viewBox", "0 0 24 24", "width", "24", "height", "24", "fill", "currentColor", "aria-hidden", "true", "focusable", "false"], ["d", "M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(Mh), t.\u0275\u0275domElementStart(0, "button", 0), t.\u0275\u0275domListener("click", function () { return o.datepicker?.toggle(); }), t.\u0275\u0275conditionalCreate(1, Eh, 2, 0, ":svg:svg", 1), t.\u0275\u0275projection(2), t.\u0275\u0275domElementEnd()), i & 2 && (t.\u0275\u0275domProperty("disabled", o.disabled || !!o.datepicker?.disabled), t.\u0275\u0275attribute("aria-label", o.ariaLabel || o.intl.openCalendarLabel)("aria-haspopup", o.datepicker ? "dialog" : null)("aria-expanded", o.datepicker?.opened ?? null), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.customIcon ? -1 : 1)); }, styles: [`.md-datepicker-toggle{display:inline-flex;pointer-events:auto;color:var(--%NS%md-color-text-muted)}.md-datepicker-toggle--active{color:var(--%NS%md-color-primary)}.md-datepicker-toggle button{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;padding:8px;border:0;border-radius:50%;background:transparent;color:inherit;cursor:pointer}.md-datepicker-toggle button:hover:not(:disabled){background:color-mix(in srgb,currentColor 8%,transparent)}.md-datepicker-toggle button:focus-visible{background:color-mix(in srgb,currentColor 12%,transparent);outline:2px solid var(--%NS%md-color-focus);outline-offset:-2px}.md-datepicker-toggle button:disabled{opacity:.38;cursor:default}
`], encapsulation: 2 });
    }
    return n;
})(), Ba = new k("MD_DATE_RANGE_INPUT_PARENT"), za = (() => { class n {
    dateInput = new p;
    dateChange = new p;
    elementRef = d(x);
    parent = d(Ba);
    value = null;
    disabled = !1;
    onChange = () => { };
    onTouched = () => { };
    validatorChange = () => { };
    ngOnInit() { this.parent.registerPart(this); }
    ngOnDestroy() { this.parent.unregisterPart(this); }
    writeValue(e) { this.value = e, this.elementRef.nativeElement.value = Dr(e); }
    registerOnChange(e) { this.onChange = e; }
    registerOnTouched(e) { this.onTouched = e; }
    registerOnValidatorChange(e) { this.validatorChange = e; }
    setDisabledState(e) { this.disabled = e, this.updateDisabledState(); }
    validate(e) { if (!this.value)
        return null; let i = Ee(this.value); return i ? this.parent.min && i < Ee(this.parent.min) ? { mdDatepickerMin: { min: this.parent.min, actual: this.value } } : this.parent.max && i > Ee(this.parent.max) ? { mdDatepickerMax: { max: this.parent.max, actual: this.value } } : this.parent.dateFilter && !this.parent.dateFilter(this.value) ? { mdDatepickerFilter: !0 } : null : { mdDatepickerParse: !0 }; }
    isDateEnabled(e) { let i = Ee(e); return !!i && (!this.parent.min || i >= Ee(this.parent.min)) && (!this.parent.max || i <= Ee(this.parent.max)) && (!this.parent.dateFilter || this.parent.dateFilter(e)); }
    select(e) { this.value = e, this.elementRef.nativeElement.value = Dr(e), this.onChange(e), this.validatorChange(), this.emit(this.dateInput), this.emit(this.dateChange); }
    handleInput(e) { this.value = df(e.target.value), this.onChange(this.value), this.validatorChange(), this.emit(this.dateInput); }
    handleChange() { this.emit(this.dateChange); }
    handleBlur() { this.onTouched(); }
    openFromKeyboard(e) { e.preventDefault(), this.parent.open(); }
    updateDisabledState() { this.elementRef.nativeElement.disabled = this.disabled || this.parent.disabled; }
    emit(e) { e.emit({ target: this, targetElement: this.elementRef.nativeElement, value: this.value }); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, outputs: { dateInput: "dateInput", dateChange: "dateChange" } });
} return n; })();
var ex = (() => { class n extends za {
    part = "start";
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["input", "mdStartDate", ""]], hostAttrs: ["autocomplete", "off", 1, "md-date-range-input__input"], hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("input", function (s) { return o.handleInput(s); })("change", function () { return o.handleChange(); })("blur", function () { return o.handleBlur(); })("keydown.alt.arrowdown", function (s) { return o.openFromKeyboard(s); }); }, exportAs: ["mdStartDate"], features: [t.\u0275\u0275ProvidersFeature([{ provide: J, useExisting: A(() => n), multi: !0 }, { provide: xt, useExisting: A(() => n), multi: !0 }]), t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), tx = (() => { class n extends za {
    part = "end";
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["input", "mdEndDate", ""]], hostAttrs: ["autocomplete", "off", 1, "md-date-range-input__input"], hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("input", function (s) { return o.handleInput(s); })("change", function () { return o.handleChange(); })("blur", function () { return o.handleBlur(); })("keydown.alt.arrowdown", function (s) { return o.openFromKeyboard(s); }); }, exportAs: ["mdEndDate"], features: [t.\u0275\u0275ProvidersFeature([{ provide: J, useExisting: A(() => n), multi: !0 }, { provide: xt, useExisting: A(() => n), multi: !0 }]), t.\u0275\u0275InheritDefinitionFeature] });
} return n; })(), ix = (() => {
    class n {
        elementRef;
        min = null;
        max = null;
        dateFilter = null;
        comparisonStart = null;
        comparisonEnd = null;
        separator = "\u2013";
        picker;
        startPart;
        endPart;
        _disabled = !1;
        constructor(e) { this.elementRef = e; }
        get disabled() { return this._disabled; }
        set disabled(e) { this._disabled = e, this.startPart?.updateDisabledState(), this.endPart?.updateDisabledState(); }
        set rangePicker(e) { this.picker = e, e.registerInput(this); }
        get value() { return { start: this.startPart?.value ?? null, end: this.endPart?.value ?? null }; }
        registerPart(e) { e.part === "start" ? this.startPart = e : this.endPart = e, e.updateDisabledState(); }
        unregisterPart(e) { this.startPart === e && (this.startPart = void 0), this.endPart === e && (this.endPart = void 0); }
        isDateEnabled(e) { return (this.startPart ?? this.endPart)?.isDateEnabled(e) ?? !1; }
        setRange(e) { this.startPart?.select(e.start), this.endPart?.select(e.end); }
        open() { this.picker?.open(); }
        static \u0275fac = function (i) { return new (i || n)(t.\u0275\u0275directiveInject(t.ElementRef)); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-date-range-input"]], inputs: { min: "min", max: "max", dateFilter: [0, "mdDatepickerFilter", "dateFilter"], comparisonStart: "comparisonStart", comparisonEnd: "comparisonEnd", separator: "separator", disabled: [2, "disabled", "disabled", m], rangePicker: "rangePicker" }, exportAs: ["mdDateRangeInput"], features: [t.\u0275\u0275ProvidersFeature([{ provide: Ba, useExisting: A(() => n) }])], ngContentSelectors: Nh, decls: 4, vars: 1, consts: [["aria-hidden", "true", 1, "md-date-range-input__separator"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(Ih), t.\u0275\u0275projection(0), t.\u0275\u0275domElementStart(1, "span", 0), t.\u0275\u0275text(2), t.\u0275\u0275domElementEnd(), t.\u0275\u0275projection(3, 1)), i & 2 && (t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(o.separator)); }, styles: [`md-date-range-input{display:inline-flex;width:100%;align-items:center}.md-date-range-input__input{min-width:0;flex:1 1 0;margin:0;padding:0;border:0;outline:0;background:transparent;color:currentColor;font:inherit;vertical-align:bottom;appearance:none}.md-date-range-input__separator{flex:0 0 auto;margin:0 4px;color:currentColor}.md-date-range-input__input:disabled{color:color-mix(in srgb,currentColor 38%,transparent);cursor:default}.md-date-range-input__input::placeholder{transition:color .2s 67ms cubic-bezier(0,0,.2,1)}
`], encapsulation: 2 });
    }
    return n;
})();
function Ee(n) { return n instanceof Date && !Number.isNaN(n.getTime()) ? n : null; }
function df(n) { if (!n.trim())
    return null; let a = new Date(n); return Number.isNaN(a.getTime()) ? null : a; }
function Dr(n) { let a = Ee(n); return a ? a.toLocaleDateString() : ""; }
var lf = new k("MD_DATE_RANGE_SELECTION_STRATEGY"), un = class {
    selectionFinished(a, e) { return a ? !e.start || e.end ? { start: a, end: null } : Mr(a, e.start) < 0 ? { start: a, end: e.start } : { start: e.start, end: a } : { start: null, end: null }; }
    createPreview(a, e) { return !a || !e.start || e.end ? { start: null, end: null } : Mr(a, e.start) < 0 ? { start: a, end: e.start } : { start: e.start, end: a }; }
};
function Mr(n, a) { return Tr(n) - Tr(a); }
function Tr(n) { return n instanceof Date ? n.getTime() : Number(n); }
var nx = (() => { class n {
    cdr = d(E);
    providedStrategy = d(lf, { optional: !0 });
    defaultStrategy = new un;
    input;
    activeMonth = Yi(new Date);
    previewRange = { start: null, end: null };
    pendingRange = null;
    disabledOverride;
    get disabled() { return this.disabledOverride ?? this.input?.disabled ?? !1; }
    set disabled(e) { this.disabledOverride = e; }
    startAt = null;
    startView = "month";
    rangeSelectionStrategy = null;
    openedChange = new p;
    openedEvent = new p;
    closedEvent = new p;
    selectedChange = new p;
    actions;
    positions = [{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top", offsetY: 8 }, { originX: "start", originY: "top", overlayX: "start", overlayY: "bottom", offsetY: -8 }];
    weekdays = cf();
    opened = !1;
    get origin() { return this.input?.elementRef ?? null; }
    get monthLabel() { return new Intl.DateTimeFormat(void 0, { month: "long", year: "numeric" }).format(this.activeMonth); }
    get days() { let e = this.effectiveRange, i = he(e?.start), o = he(e?.end), r = he(this.previewRange.start), s = he(this.previewRange.end), l = he(this.input?.comparisonStart), c = he(this.input?.comparisonEnd), h = !!i && !!o && !Y(i, o), g = !!l && !!c && !Y(l, c), u = Yi(this.activeMonth), f = new Date(u.getFullYear(), u.getMonth() + 1, 0).getDate(), v = Math.ceil((u.getDay() + f) / 7) * 7, w = new Date(u.getFullYear(), u.getMonth(), u.getDate() - u.getDay()); return Array.from({ length: v }, (N, M) => { let y = new Date(w.getFullYear(), w.getMonth(), w.getDate() + M), ee = y.getMonth() !== this.activeMonth.getMonth(), U = h && Y(y, i), Ke = h && Y(y, o), X = h && qi(y, i, o), Zn = g && Y(y, l), Jn = g && Y(y, c), eo = g && qi(y, l, c), to = M > 0 ? new Date(y.getFullYear(), y.getMonth(), y.getDate() - 1) : null, io = M < v - 1 ? new Date(y.getFullYear(), y.getMonth(), y.getDate() + 1) : null; return { date: y, label: y.getDate(), outside: ee, disabled: ee || !this.input?.isDateEnabled(y), selected: !!i && Y(y, i) || !!o && Y(y, o), rangeStart: U, rangeEnd: Ke, inRange: X, previewStart: !!r && Y(y, r), previewEnd: !!s && Y(y, s), inPreview: qi(y, r, s), comparisonStart: Zn, comparisonEnd: Jn, comparisonBridgeStart: Zn && !U && X && !!to && !(h && Y(to, o)), comparisonBridgeEnd: Jn && !Ke && X && !!io && !(h && Y(io, i)), comparisonIdentical: !!l && !!c && Y(l, c) && Y(y, l), inComparison: eo, inOverlap: X && eo, today: Y(y, new Date) }; }); }
    registerInput(e) { this.input = e; }
    open() { let e = this.input; if (this.disabled || !e || this.opened)
        return; let i = e.value; this.pendingRange = this.actions ? _({}, i) : null, this.previewRange = { start: null, end: null }, this.activeMonth = Yi(he(i.start) ?? he(i.end) ?? he(this.startAt) ?? new Date), this.opened = !0, this.openedChange.emit(!0), this.openedEvent.emit(), this.cdr.markForCheck(); }
    close() { this.opened && (this.previewRange = { start: null, end: null }, this.opened = !1, this.openedChange.emit(!1), this.closedEvent.emit(), this.cdr.markForCheck()); }
    toggle() { this.opened ? this.close() : this.open(); }
    previousMonth() { this.activeMonth = new Date(this.activeMonth.getFullYear(), this.activeMonth.getMonth() - 1, 1), this.cdr.markForCheck(); }
    nextMonth() { this.activeMonth = new Date(this.activeMonth.getFullYear(), this.activeMonth.getMonth() + 1, 1), this.cdr.markForCheck(); }
    select(e) { if (e.disabled || !this.input)
        return; let o = (this.rangeSelectionStrategy ?? this.providedStrategy ?? this.defaultStrategy).selectionFinished(e.date, this.effectiveRange); this.actions ? this.pendingRange = o : (this.input.setRange(o), this.selectedChange.emit(o)), this.previewRange = { start: null, end: null }, o.start && o.end && !this.actions ? this.close() : this.cdr.markForCheck(); }
    preview(e) { if (e.disabled || !this.input)
        return; let i = this.rangeSelectionStrategy ?? this.providedStrategy ?? this.defaultStrategy; this.previewRange = i.createPreview(e.date, this.effectiveRange), this.cdr.markForCheck(); }
    clearPreview() { this.previewRange = { start: null, end: null }, this.cdr.markForCheck(); }
    applyPendingSelection() { this.pendingRange && this.input && (this.input.setRange(this.pendingRange), this.selectedChange.emit(this.pendingRange)), this.close(); }
    cancelPendingSelection() { this.pendingRange = null, this.close(); }
    get effectiveRange() { return this.pendingRange ?? this.input?.value ?? { start: null, end: null }; }
    handleKeydown(e) { e.key === "Escape" && (e.preventDefault(), this.close()); }
    formatAccessibleDate(e) { return new Intl.DateTimeFormat(void 0, { dateStyle: "full" }).format(e); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-date-range-picker"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, ii, 5), i & 2) {
            let s;
            t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.actions = s.first);
        } }, inputs: { disabled: [2, "disabled", "disabled", m], startAt: "startAt", startView: "startView", rangeSelectionStrategy: "rangeSelectionStrategy" }, outputs: { openedChange: "openedChange", openedEvent: "opened", closedEvent: "closed", selectedChange: "selectedChange" }, exportAs: ["mdDateRangePicker"], features: [t.\u0275\u0275ProvidersFeature([{ provide: Un, useExisting: A(() => n) }])], ngContentSelectors: Oh, decls: 1, vars: 1, consts: [["cdk-connected-overlay", "", "cdkConnectedOverlayHasBackdrop", "", "cdkConnectedOverlayBackdropClass", "cdk-overlay-transparent-backdrop", 3, "cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayOpen", "cdkConnectedOverlayPush"], ["cdk-connected-overlay", "", "cdkConnectedOverlayHasBackdrop", "", "cdkConnectedOverlayBackdropClass", "cdk-overlay-transparent-backdrop", 3, "backdropClick", "detach", "overlayKeydown", "cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayOpen", "cdkConnectedOverlayPush"], ["role", "dialog", "aria-modal", "true", "aria-label", "Choose a date range", 1, "md-datepicker-panel", "md-date-range-picker-panel", 3, "mouseleave"], [1, "md-datepicker-header"], ["type", "button", "aria-label", "Previous month", 3, "click"], ["viewBox", "0 0 24 24", "aria-hidden", "true", "focusable", "false"], ["d", "M15 18 9 12l6-6"], ["type", "button", "aria-label", "Next month", 3, "click"], ["d", "m9 18 6-6-6-6"], ["aria-hidden", "true", 1, "md-datepicker-weekdays"], ["role", "grid", 1, "md-datepicker-grid"], ["type", "button", "role", "gridcell", 3, "md-datepicker-day--outside", "md-datepicker-day--selected", "md-datepicker-day--range-start", "md-datepicker-day--range-end", "md-datepicker-day--in-range", "md-datepicker-day--preview-start", "md-datepicker-day--preview-end", "md-datepicker-day--in-preview", "md-datepicker-day--comparison-start", "md-datepicker-day--comparison-end", "md-datepicker-day--comparison-bridge-start", "md-datepicker-day--comparison-bridge-end", "md-datepicker-day--comparison-identical", "md-datepicker-day--in-comparison", "md-datepicker-day--in-overlap", "md-datepicker-day--today", "disabled"], ["type", "button", "role", "gridcell", 3, "mouseenter", "focus", "click", "disabled"], [1, "md-datepicker-cell-content"], ["aria-hidden", "true", 1, "md-datepicker-cell-preview"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(Ph), t.\u0275\u0275conditionalCreate(0, Lh, 1, 4, null, 0)), i & 2 && t.\u0275\u0275conditional(o.origin ? 0 : -1); }, dependencies: [ct], styles: [pa], encapsulation: 2 });
} return n; })();
function he(n) { return n instanceof Date && !Number.isNaN(n.getTime()) ? n : null; }
function Yi(n) { return new Date(n.getFullYear(), n.getMonth(), 1); }
function Y(n, a) { return n.getFullYear() === a.getFullYear() && n.getMonth() === a.getMonth() && n.getDate() === a.getDate(); }
function qi(n, a, e) { return !!a && !!e && n >= a && n <= e; }
function cf() { let n = new Date(2024, 0, 7), a = new Intl.DateTimeFormat(void 0, { weekday: "short" }); return Array.from({ length: 7 }, (e, i) => a.format(new Date(2024, 0, n.getDate() + i))); }
var ox = (() => { class n {
    selected = null;
    startAt = null;
    min = null;
    max = null;
    dateFilter = null;
    dateClass = null;
    locale;
    selectedChange = new p;
    weekdays = mf();
    activeMonth = Qi(new Date);
    ngOnInit() { this.activeMonth = Qi($e(this.selected) ?? $e(this.startAt) ?? new Date); }
    get monthLabel() { return new Intl.DateTimeFormat(this.locale, { month: "long", year: "numeric" }).format(this.activeMonth); }
    get days() { let e = $e(this.selected), i = Qi(this.activeMonth), o = new Date(i.getFullYear(), i.getMonth() + 1, 0).getDate(), r = Math.ceil((i.getDay() + o) / 7) * 7, s = new Date(i.getFullYear(), i.getMonth(), i.getDate() - i.getDay()); return Array.from({ length: r }, (l, c) => { let h = new Date(s.getFullYear(), s.getMonth(), s.getDate() + c), g = h.getMonth() !== this.activeMonth.getMonth(); return { date: h, label: h.getDate(), outside: g, disabled: g || !this.isEnabled(h), selected: !!e && Er(h, e), today: Er(h, new Date), cssClass: this.dateClass?.(h, "month") ?? null }; }); }
    previousMonth() { this.activeMonth = new Date(this.activeMonth.getFullYear(), this.activeMonth.getMonth() - 1, 1); }
    nextMonth() { this.activeMonth = new Date(this.activeMonth.getFullYear(), this.activeMonth.getMonth() + 1, 1); }
    select(e) { e.disabled || (this.selected = e.date, this.selectedChange.emit(this.selected)); }
    formatAccessibleDate(e) { return new Intl.DateTimeFormat(this.locale, { dateStyle: "full" }).format(e); }
    isEnabled(e) { let i = $e(e); return !!i && (!this.min || i >= $e(this.min)) && (!this.max || i <= $e(this.max)) && (!this.dateFilter || this.dateFilter(e)); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-calendar"]], inputs: { selected: "selected", startAt: "startAt", min: "min", max: "max", dateFilter: "dateFilter", dateClass: "dateClass", locale: "locale" }, outputs: { selectedChange: "selectedChange" }, exportAs: ["mdCalendar"], decls: 16, vars: 1, consts: [["role", "application", "aria-label", "Calendar", 1, "md-datepicker-panel", "md-calendar-inline"], [1, "md-datepicker-header"], ["type", "button", "aria-label", "Previous month", 3, "click"], ["viewBox", "0 0 24 24", "aria-hidden", "true"], ["d", "M15 18 9 12l6-6"], [1, "md-datepicker-period"], ["type", "button", "aria-label", "Next month", 3, "click"], ["d", "m9 18 6-6-6-6"], ["aria-hidden", "true", 1, "md-datepicker-weekdays"], ["role", "grid", 1, "md-datepicker-grid"], ["type", "button", "role", "gridcell", 3, "ngClass", "md-datepicker-day--outside", "md-datepicker-day--selected", "md-datepicker-day--today", "disabled"], ["type", "button", "role", "gridcell", 3, "click", "ngClass", "disabled"], [1, "md-datepicker-cell-content"]], template: function (i, o) { i & 1 && (t.\u0275\u0275elementStart(0, "div", 0)(1, "header", 1)(2, "button", 2), t.\u0275\u0275listener("click", function () { return o.previousMonth(); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(3, "svg", 3), t.\u0275\u0275element(4, "path", 4), t.\u0275\u0275elementEnd()(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275elementStart(5, "span", 5), t.\u0275\u0275text(6), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(7, "button", 6), t.\u0275\u0275listener("click", function () { return o.nextMonth(); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(8, "svg", 3), t.\u0275\u0275element(9, "path", 7), t.\u0275\u0275elementEnd()()(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275elementStart(10, "div", 8), t.\u0275\u0275repeaterCreate(11, Bh, 2, 1, "span", null, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(13, "div", 9), t.\u0275\u0275repeaterCreate(14, zh, 3, 11, "button", 10, Wn), t.\u0275\u0275elementEnd()()), i & 2 && (t.\u0275\u0275advance(6), t.\u0275\u0275textInterpolate(o.monthLabel), t.\u0275\u0275advance(5), t.\u0275\u0275repeater(o.weekdays), t.\u0275\u0275advance(3), t.\u0275\u0275repeater(o.days)); }, dependencies: [kn], styles: [pa], encapsulation: 2 });
} return n; })();
function $e(n) { return n instanceof Date && !Number.isNaN(n.getTime()) ? n : null; }
function Qi(n) { return new Date(n.getFullYear(), n.getMonth(), 1); }
function Er(n, a) { return n.getFullYear() === a.getFullYear() && n.getMonth() === a.getMonth() && n.getDate() === a.getDate(); }
function mf() { let n = new Intl.DateTimeFormat(void 0, { weekday: "short" }); return Array.from({ length: 7 }, (a, e) => n.format(new Date(2024, 0, 7 + e))); }
var rx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), ax = (() => {
    class n {
        color = "primary";
        mode;
        diameter = 100;
        strokeWidth = 10;
        _value = 0;
        get value() { return this.mode === "determinate" ? this._value : 0; }
        set value(e) { this._value = hf(e); }
        get normalizedStrokeWidth() { return this.diameter > 0 ? this.strokeWidth * 100 / this.diameter : 0; }
        get radius() { return Math.max(0, 50 - this.normalizedStrokeWidth / 2); }
        constructor(e) { this.mode = e.nativeElement.nodeName.toLowerCase() === "md-spinner" ? "indeterminate" : "determinate"; }
        static \u0275fac = function (i) { return new (i || n)(t.\u0275\u0275directiveInject(t.ElementRef)); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-progress-spinner"], ["md-spinner"]], hostAttrs: ["role", "progressbar", "tabindex", "-1", 1, "md-progress-spinner"], hostVars: 9, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("mode", o.mode)("data-color", o.color)("aria-valuemin", 0)("aria-valuemax", 100)("aria-valuenow", o.mode === "determinate" ? o.value : null), t.\u0275\u0275styleProp("width", o.diameter, "px")("height", o.diameter, "px")); }, inputs: { color: "color", mode: "mode", diameter: [2, "diameter", "diameter", S], strokeWidth: [2, "strokeWidth", "strokeWidth", S], value: [2, "value", "value", S] }, exportAs: ["mdProgressSpinner"], decls: 3, vars: 5, consts: [["viewBox", "0 0 100 100", "aria-hidden", "true", "focusable", "false", 1, "md-progress-spinner__svg"], ["cx", "50", "cy", "50", 1, "md-progress-spinner__track"], ["cx", "50", "cy", "50", "pathLength", "100", 1, "md-progress-spinner__indicator"]], template: function (i, o) { i & 1 && (t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(0, "svg", 0), t.\u0275\u0275domElement(1, "circle", 1)(2, "circle", 2), t.\u0275\u0275domElementEnd()), i & 2 && (t.\u0275\u0275advance(), t.\u0275\u0275attribute("r", o.radius)("stroke-width", o.normalizedStrokeWidth), t.\u0275\u0275advance(), t.\u0275\u0275attribute("r", o.radius)("stroke-width", o.normalizedStrokeWidth)("stroke-dashoffset", o.mode === "determinate" ? 100 - o.value : null)); }, styles: [`md-progress-spinner,md-spinner{display:block;overflow:hidden;line-height:0;color:var(--%NS%md-progress-spinner-color, var(--%NS%md-color-primary))}md-progress-spinner[data-color=accent],md-spinner[data-color=accent]{color:var(--%NS%md-progress-spinner-accent-color, var(--%NS%md-color-info))}md-progress-spinner[data-color=warn],md-spinner[data-color=warn]{color:var(--%NS%md-progress-spinner-warn-color, var(--%NS%md-color-danger))}.md-progress-spinner__svg{display:block;width:100%;height:100%;transform:rotate(-90deg);transform-origin:center}.md-progress-spinner__track,.md-progress-spinner__indicator{fill:none}.md-progress-spinner__track{stroke:var(--%NS%md-progress-spinner-track-color, var(--%NS%md-color-surface-selected))}.md-progress-spinner__indicator{stroke:currentColor;stroke-linecap:round;stroke-dasharray:100;transition:stroke-dashoffset .3s ease}[mode=indeterminate] .md-progress-spinner__svg{animation:md-progress-spinner-rotate 1.4s linear infinite}[mode=indeterminate] .md-progress-spinner__indicator{animation:md-progress-spinner-dash 1.4s ease-in-out infinite}@keyframes md-progress-spinner-rotate{to{transform:rotate(270deg)}}@keyframes md-progress-spinner-dash{0%{stroke-dasharray:1 99;stroke-dashoffset:0}50%{stroke-dasharray:70 30;stroke-dashoffset:-20}to{stroke-dasharray:1 99;stroke-dashoffset:-100}}@media(prefers-reduced-motion:reduce){[mode=indeterminate] .md-progress-spinner__svg{animation:none}[mode=indeterminate] .md-progress-spinner__indicator{animation:md-progress-spinner-pulse 1.8s ease-in-out infinite;stroke-dasharray:70 30}}@keyframes md-progress-spinner-pulse{50%{opacity:.35}}
`], encapsulation: 2 });
    }
    return n;
})();
function hf(n) { return Math.max(0, Math.min(100, n || 0)); }
var sx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), dx = (() => {
    class n {
        color = "primary";
        mode = "determinate";
        animationEnd = new p;
        _value = 0;
        _bufferValue = 0;
        get value() { return this._value; }
        set value(e) { this._value = Ir(e); }
        get bufferValue() { return this._bufferValue; }
        set bufferValue(e) { this._bufferValue = Ir(e); }
        get isContinuous() { return this.mode === "indeterminate" || this.mode === "query"; }
        handleTransitionEnd(e) { !this.isContinuous && e.propertyName === "width" && this.animationEnd.emit({ value: this.value }); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-progress-bar"]], hostAttrs: ["role", "progressbar", 1, "md-progress-bar"], hostVars: 5, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275attribute("mode", o.mode)("data-color", o.color)("aria-valuemin", 0)("aria-valuemax", 100)("aria-valuenow", o.isContinuous ? null : o.value); }, inputs: { color: "color", mode: "mode", value: [2, "value", "value", S], bufferValue: [2, "bufferValue", "bufferValue", S] }, outputs: { animationEnd: "animationEnd" }, exportAs: ["mdProgressBar"], decls: 4, vars: 4, consts: [["aria-hidden", "true", 1, "md-progress-bar__track"], [1, "md-progress-bar__buffer"], [1, "md-progress-bar__indicator", "md-progress-bar__indicator--primary", 3, "transitionend"], [1, "md-progress-bar__indicator", "md-progress-bar__indicator--secondary"]], template: function (i, o) { i & 1 && (t.\u0275\u0275domElementStart(0, "div", 0), t.\u0275\u0275domElement(1, "div", 1), t.\u0275\u0275domElementStart(2, "div", 2), t.\u0275\u0275domListener("transitionend", function (s) { return o.handleTransitionEnd(s); }), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElement(3, "div", 3), t.\u0275\u0275domElementEnd()), i & 2 && (t.\u0275\u0275advance(), t.\u0275\u0275styleProp("width", o.mode === "buffer" ? o.bufferValue : 0, "%"), t.\u0275\u0275advance(), t.\u0275\u0275styleProp("width", o.isContinuous ? null : o.value, "%")); }, styles: [`md-progress-bar{display:block;width:100%;height:var(--%NS%md-progress-bar-height, 4px);overflow:hidden;color:var(--%NS%md-progress-bar-color, var(--%NS%md-color-primary));border-radius:var(--%NS%md-progress-bar-radius, var(--%NS%md-radius-xs))}md-progress-bar[data-color=accent]{color:var(--%NS%md-progress-bar-accent-color, var(--%NS%md-color-info))}md-progress-bar[data-color=warn]{color:var(--%NS%md-progress-bar-warn-color, var(--%NS%md-color-danger))}.md-progress-bar__track{position:relative;width:100%;height:100%;overflow:hidden;background:var(--%NS%md-progress-bar-track-color, var(--%NS%md-color-surface-selected))}.md-progress-bar__buffer,.md-progress-bar__indicator{position:absolute;inset:0 auto 0 0;height:100%}.md-progress-bar__buffer{background:var(--%NS%md-progress-bar-buffer-color, color-mix(in srgb, currentColor 28%, transparent));transition:width .25s ease}.md-progress-bar__indicator{background:currentColor}.md-progress-bar__indicator--primary{transition:width .25s ease}.md-progress-bar__indicator--secondary{display:none}md-progress-bar[mode=indeterminate] .md-progress-bar__indicator,md-progress-bar[mode=query] .md-progress-bar__indicator{display:block}md-progress-bar[mode=indeterminate] .md-progress-bar__indicator--primary,md-progress-bar[mode=query] .md-progress-bar__indicator--primary{width:45%;animation:md-progress-bar-primary 1.8s ease-in-out infinite}md-progress-bar[mode=indeterminate] .md-progress-bar__indicator--secondary,md-progress-bar[mode=query] .md-progress-bar__indicator--secondary{width:30%;animation:md-progress-bar-secondary 1.8s ease-in-out .9s infinite}md-progress-bar[mode=query] .md-progress-bar__track{transform:scaleX(-1)}@keyframes md-progress-bar-primary{0%{left:-45%}65%,to{left:100%}}@keyframes md-progress-bar-secondary{0%{left:-30%}55%,to{left:100%}}@media(prefers-reduced-motion:reduce){md-progress-bar[mode=indeterminate] .md-progress-bar__indicator--primary,md-progress-bar[mode=query] .md-progress-bar__indicator--primary{inset:0;width:100%;animation:md-progress-bar-pulse 1.8s ease-in-out infinite}md-progress-bar[mode=indeterminate] .md-progress-bar__indicator--secondary,md-progress-bar[mode=query] .md-progress-bar__indicator--secondary{display:none}}@keyframes md-progress-bar-pulse{50%{opacity:.35}}
`], encapsulation: 2 });
    }
    return n;
})();
function Ir(n) { return Math.max(0, Math.min(100, n || 0)); }
var lx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), cx = (() => {
    class n {
        vertical = !1;
        inset = !1;
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-divider"]], hostAttrs: ["role", "separator", 1, "md-divider"], hostVars: 5, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("aria-orientation", o.vertical ? "vertical" : "horizontal"), t.\u0275\u0275classProp("md-divider--vertical", o.vertical)("md-divider--inset", o.inset)); }, inputs: { vertical: [2, "vertical", "vertical", m], inset: [2, "inset", "inset", m] }, exportAs: ["mdDivider"], decls: 0, vars: 0, template: function (i, o) { }, styles: [`md-divider{display:block;box-sizing:border-box;width:100%;height:0;margin:0;border:0;border-top:var(--%NS%md-divider-width, 1px) solid var(--%NS%md-divider-color, var(--%NS%md-color-border));flex-shrink:0}md-divider.md-divider--%NS%inset:not(.md-divider--vertical){width:calc(100% - var(--%NS%md-divider-inset, 72px));margin-inline-start:var(--%NS%md-divider-inset, 72px)}md-divider.md-divider--vertical{display:inline-block;align-self:stretch;width:0;height:auto;min-height:1em;border-top:0;border-inline-start:var(--%NS%md-divider-width, 1px) solid var(--%NS%md-divider-color, var(--%NS%md-color-border))}md-divider.md-divider--vertical.md-divider--inset{align-self:center;height:calc(100% - var(--%NS%md-divider-inset, 16px) * 2);margin-block:var(--%NS%md-divider-inset, 16px)}
`], encapsulation: 2 });
    }
    return n;
})(), mx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), Va = new k("MDSlider"), pf = (() => { class n {
    slider = d(Va, { optional: !0 });
    elementRef = d(x);
    valueChange = new p;
    dragStart = new p;
    dragEnd = new p;
    kind;
    valueWasSet = !1;
    onChange = () => { };
    onTouched = () => { };
    constructor() { let e = this.elementRef.nativeElement; this.kind = e.hasAttribute("mdSliderStartThumb") ? "start" : e.hasAttribute("mdSliderEndThumb") ? "end" : "single"; }
    get value() { return this.elementRef.nativeElement.valueAsNumber; }
    set value(e) { this.valueWasSet = !0, this.setValue(e); }
    get disabled() { return this.elementRef.nativeElement.disabled; }
    writeValue(e) { e !== null && Number.isFinite(Number(e)) && (this.valueWasSet = !0, this.setValue(Number(e))); }
    registerOnChange(e) { this.onChange = e; }
    registerOnTouched(e) { this.onTouched = e; }
    setDisabledState(e) { this.elementRef.nativeElement.disabled = e; }
    setValue(e, i = !1) { this.elementRef.nativeElement.value = String(e), i && (this.onChange(e), this.valueChange.emit(e)); }
    handleInput() { this.valueWasSet = !0, this.onChange(this.value), this.valueChange.emit(this.value), this.slider?.handleThumbInput(this); }
    handleChange() { this.slider?.handleThumbInput(this); }
    handleFocus() { this.slider?.handleThumbFocus(this); }
    handleBlur() { this.onTouched(), this.slider?.handleThumbBlur(this); }
    handleDragStart() { this.dragStart.emit({ source: this, value: this.value }); }
    handleDragEnd() { this.dragEnd.emit({ source: this, value: this.value }); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["input", "mdSliderThumb", ""], ["input", "mdSliderStartThumb", ""], ["input", "mdSliderEndThumb", ""]], hostAttrs: ["type", "range", 1, "md-slider-thumb"], hostVars: 4, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("input", function () { return o.handleInput(); })("change", function () { return o.handleChange(); })("focus", function () { return o.handleFocus(); })("blur", function () { return o.handleBlur(); })("pointerdown", function () { return o.handleDragStart(); })("pointerup", function () { return o.handleDragEnd(); })("pointercancel", function () { return o.handleDragEnd(); }), i & 2 && t.\u0275\u0275classProp("md-slider-thumb--start", o.kind === "start")("md-slider-thumb--end", o.kind === "end"); }, inputs: { value: [2, "value", "value", S] }, outputs: { valueChange: "valueChange", dragStart: "dragStart", dragEnd: "dragEnd" }, exportAs: ["mdSliderThumb"], features: [t.\u0275\u0275ProvidersFeature([{ provide: J, useExisting: A(() => n), multi: !0 }])] });
} return n; })(), hx = (() => {
    class n {
        cdr = d(E);
        thumbQuery;
        min = 0;
        max = 100;
        step = 1;
        discrete = !1;
        showTickMarks = !1;
        disabled = !1;
        displayWith = e => e;
        activeThumb = null;
        get thumbs() { return this.thumbQuery?.toArray() ?? []; }
        get isRange() { return this.thumbs.some(e => e.kind !== "single"); }
        get startPercent() { if (!this.thumbs.length)
            return 0; let e = this.isRange ? this.thumbs.find(i => i.kind === "start")?.value ?? this.min : this.min; return this.toPercent(e); }
        get endPercent() { if (!this.thumbs.length)
            return 0; let e = this.isRange ? this.thumbs.find(i => i.kind === "end")?.value ?? this.max : this.thumbs[0].value; return this.toPercent(e); }
        get tickStepPercent() { let e = this.max - this.min; return e > 0 && this.step > 0 ? Math.min(100, this.step / e * 100) : 100; }
        ngAfterContentInit() { this.syncThumbs(), this.thumbQuery.changes.subscribe(() => { this.syncThumbs(), this.cdr.markForCheck(); }); }
        ngOnChanges(e) { this.thumbQuery && (this.syncThumbs(), this.cdr.markForCheck()); }
        handleThumbInput(e) { this.constrainRange(e), this.updateRangeBounds(), this.updateAriaValue(e), this.activeThumb = e, this.cdr.markForCheck(); }
        handleThumbFocus(e) { this.activeThumb = e, this.cdr.markForCheck(); }
        handleThumbBlur(e) { this.activeThumb === e && (this.activeThumb = null, this.cdr.markForCheck()); }
        thumbPercent(e) { return this.toPercent(e.value); }
        syncThumbs() { for (let e of this.thumbs) {
            let i = e.elementRef.nativeElement;
            i.min = String(this.min), i.max = String(this.max), i.step = String(this.step), i.disabled = this.disabled, e.valueWasSet || e.setValue(e.kind === "end" ? this.max : this.min), this.updateAriaValue(e);
        } this.constrainRange(), this.updateRangeBounds(); }
        constrainRange(e) { if (!this.isRange)
            return; let i = this.thumbs.find(r => r.kind === "start"), o = this.thumbs.find(r => r.kind === "end"); !i || !o || i.value <= o.value || (e === o ? o.setValue(i.value, !0) : i.setValue(o.value, !0)); }
        updateRangeBounds() { if (!this.isRange)
            return; let e = this.thumbs.find(o => o.kind === "start"), i = this.thumbs.find(o => o.kind === "end"); !e || !i || (e.elementRef.nativeElement.min = String(this.min), e.elementRef.nativeElement.max = String(i.value), i.elementRef.nativeElement.min = String(e.value), i.elementRef.nativeElement.max = String(this.max)); }
        updateAriaValue(e) { e.elementRef.nativeElement.setAttribute("aria-valuetext", String(this.displayWith(e.value))); }
        toPercent(e) { let i = this.max - this.min; return i <= 0 ? 0 : Math.max(0, Math.min(100, (e - this.min) / i * 100)); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-slider"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, pf, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.thumbQuery = s);
            } }, hostAttrs: [1, "md-slider"], hostVars: 10, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275styleProp("--%NS%md-slider-active-start", o.startPercent + "%")("--%NS%md-slider-active-end", o.endPercent + "%")("--%NS%md-slider-tick-step", o.tickStepPercent + "%"), t.\u0275\u0275classProp("md-slider--disabled", o.disabled)("md-slider--range", o.isRange)); }, inputs: { min: [2, "min", "min", S], max: [2, "max", "max", S], step: [2, "step", "step", S], discrete: [2, "discrete", "discrete", m], showTickMarks: [2, "showTickMarks", "showTickMarks", m], disabled: [2, "disabled", "disabled", m], displayWith: "displayWith" }, exportAs: ["mdSlider"], features: [t.\u0275\u0275ProvidersFeature([{ provide: Va, useExisting: A(() => n) }]), t.\u0275\u0275NgOnChangesFeature], ngContentSelectors: Hh, decls: 6, vars: 2, consts: [["aria-hidden", "true", 1, "md-slider-track"], [1, "md-slider-track__inactive"], [1, "md-slider-track__active"], [1, "md-slider-track__ticks"], ["aria-hidden", "true", 1, "md-slider-value-indicator", 3, "md-slider-value-indicator--active", "left"], ["aria-hidden", "true", 1, "md-slider-value-indicator"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(Vh), t.\u0275\u0275domElementStart(0, "div", 0), t.\u0275\u0275domElement(1, "div", 1)(2, "div", 2), t.\u0275\u0275conditionalCreate(3, jh, 1, 0, "div", 3), t.\u0275\u0275domElementEnd(), t.\u0275\u0275projection(4), t.\u0275\u0275conditionalCreate(5, Gh, 2, 0)), i & 2 && (t.\u0275\u0275advance(3), t.\u0275\u0275conditional(o.showTickMarks ? 3 : -1), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o.discrete ? 5 : -1)); }, styles: [`md-slider{position:relative;display:inline-flex;align-items:center;width:var(--%NS%md-slider-width, 300px);min-width:120px;height:var(--%NS%md-slider-height, 48px);padding-inline:var(--%NS%md-slider-side-padding, 8px);box-sizing:border-box;touch-action:none;vertical-align:middle}.md-slider-track{position:absolute;inset-inline:var(--%NS%md-slider-side-padding, 8px);top:50%;height:var(--%NS%md-slider-track-height, 4px);transform:translateY(-50%);pointer-events:none}.md-slider-track__inactive,.md-slider-track__active,.md-slider-track__ticks{position:absolute;inset-block:0;border-radius:var(--%NS%md-slider-track-radius, 999px)}.md-slider-track__inactive{inset-inline:0;background:var(--%NS%md-slider-inactive-color, var(--%NS%md-color-surface-selected))}.md-slider-track__active{inset-inline-start:var(--%NS%md-slider-active-start, 0%);width:calc(var(--%NS%md-slider-active-end, 0%) - var(--%NS%md-slider-active-start, 0%));background:var(--%NS%md-slider-active-color, var(--%NS%md-color-primary))}.md-slider-track__ticks{inset-inline:0;background:repeating-linear-gradient(to right,transparent 0 calc(var(--%NS%md-slider-tick-step, 10%) - 1px),var(--%NS%md-slider-tick-color, var(--%NS%md-color-surface)) calc(var(--%NS%md-slider-tick-step, 10%) - 1px) var(--%NS%md-slider-tick-step, 10%));opacity:.8}md-slider .md-slider-thumb{position:absolute;inset-inline:var(--%NS%md-slider-side-padding, 8px);z-index:2;width:calc(100% - var(--%NS%md-slider-side-padding, 8px) * 2);height:100%;margin:0;padding:0;appearance:none;border:0;outline:none;background:transparent;pointer-events:none}md-slider .md-slider-thumb::-webkit-slider-runnable-track{height:var(--%NS%md-slider-track-height, 4px);background:transparent}md-slider .md-slider-thumb::-moz-range-track{height:var(--%NS%md-slider-track-height, 4px);background:transparent}md-slider .md-slider-thumb::-webkit-slider-thumb{width:var(--%NS%md-slider-handle-size, 20px);height:var(--%NS%md-slider-handle-size, 20px);margin-top:calc((var(--%NS%md-slider-track-height, 4px) - var(--%NS%md-slider-handle-size, 20px)) / 2);appearance:none;border:0;border-radius:50%;background:var(--%NS%md-slider-handle-color, var(--%NS%md-color-primary));box-shadow:var(--%NS%md-slider-handle-shadow, 0 1px 3px rgba(0, 0, 0, .28));cursor:grab;pointer-events:auto;transition:box-shadow .12s ease,transform .12s ease}md-slider .md-slider-thumb::-moz-range-thumb{width:var(--%NS%md-slider-handle-size, 20px);height:var(--%NS%md-slider-handle-size, 20px);border:0;border-radius:50%;background:var(--%NS%md-slider-handle-color, var(--%NS%md-color-primary));box-shadow:var(--%NS%md-slider-handle-shadow, 0 1px 3px rgba(0, 0, 0, .28));cursor:grab;pointer-events:auto;transition:box-shadow .12s ease,transform .12s ease}md-slider .md-slider-thumb:focus-visible::-webkit-slider-thumb{box-shadow:0 0 0 8px color-mix(in srgb,var(--%NS%md-slider-focus-color, var(--%NS%md-color-focus)) 22%,transparent)}md-slider .md-slider-thumb:focus-visible::-moz-range-thumb{box-shadow:0 0 0 8px color-mix(in srgb,var(--%NS%md-slider-focus-color, var(--%NS%md-color-focus)) 22%,transparent)}md-slider .md-slider-thumb:active::-webkit-slider-thumb{cursor:grabbing;transform:scale(1.1)}md-slider .md-slider-thumb:active::-moz-range-thumb{cursor:grabbing;transform:scale(1.1)}.md-slider-value-indicator{position:absolute;bottom:calc(50% + 16px);z-index:3;min-width:28px;padding:4px 7px;transform:translate(-50%) translateY(4px);border-radius:var(--%NS%md-radius-sm);background:var(--%NS%md-slider-label-background, var(--%NS%md-color-heading));color:var(--%NS%md-slider-label-color, var(--%NS%md-color-surface));font:600 11px/16px var(--%NS%md-font-body);text-align:center;opacity:0;pointer-events:none;transition:opacity .12s ease,transform .12s ease}md-slider:hover .md-slider-value-indicator,md-slider:focus-within .md-slider-value-indicator,.md-slider-value-indicator--active{transform:translate(-50%) translateY(0);opacity:1}md-slider.md-slider--disabled{opacity:var(--%NS%md-slider-disabled-opacity, .45)}md-slider.md-slider--disabled .md-slider-thumb::-webkit-slider-thumb,md-slider .md-slider-thumb:disabled::-webkit-slider-thumb,md-slider.md-slider--disabled .md-slider-thumb::-moz-range-thumb,md-slider .md-slider-thumb:disabled::-moz-range-thumb{cursor:default}
`], encapsulation: 2 });
    }
    return n;
})(), px = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), uf = (() => {
    class n {
        id = "";
        text = B("");
        template = B(null);
        context = B({});
        interactive = B(!1);
        label = B("");
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-tooltip-panel"]], hostAttrs: [1, "md-tooltip"], hostVars: 6, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("id", o.id)("role", o.interactive() ? "dialog" : "tooltip")("aria-label", o.interactive() ? o.label() : null)("tabindex", o.interactive() ? -1 : null), t.\u0275\u0275classProp("md-tooltip-interactive", o.interactive())); }, decls: 2, vars: 1, consts: [[3, "ngTemplateOutlet", "ngTemplateOutletContext"]], template: function (i, o) { if (i & 1 && t.\u0275\u0275conditionalCreate(0, $h, 1, 2, "ng-container", 0)(1, Yh, 1, 1), i & 2) {
                let r;
                t.\u0275\u0275conditional((r = o.template()) ? 0 : 1, r);
            } }, dependencies: [bt], styles: [`.md-tooltip{display:block;box-sizing:border-box;max-width:min(var(--%NS%md-tooltip-max-width, 320px),100vw - 16px);max-height:calc(100dvh - 16px);overflow:auto;overflow-wrap:anywhere;padding:var(--%NS%md-tooltip-padding, 8px 12px);border:1px solid var(--%NS%md-tooltip-border-color, var(--%NS%md-color-border));border-radius:var(--%NS%md-tooltip-radius, var(--%NS%md-radius-md));background:var(--%NS%md-tooltip-background, var(--%NS%md-overlay-surface));color:var(--%NS%md-tooltip-color, var(--%NS%md-color-text));box-shadow:var(--%NS%md-tooltip-shadow, var(--%NS%md-shadow-md));font:var(--%NS%md-tooltip-font, 400 13px/1.5 var(--%NS%md-font-body));white-space:pre-line;pointer-events:auto}.md-tooltip.md-tooltip-interactive{white-space:normal}.md-tooltip:focus-visible{outline:2px solid var(--%NS%md-color-focus)}
`], encapsulation: 2 });
    }
    return n;
})(), gf = 0, ux = (() => { class n {
    mdTooltip = I("");
    mdTooltipContext = I();
    mdTooltipPosition = I("above");
    mdTooltipDisabled = I(!1, { transform: m });
    mdTooltipInteractive = I(!1, { transform: m });
    mdTooltipShowDelay = I(300, { transform: S });
    mdTooltipHideDelay = I(100, { transform: S });
    mdTooltipClass = I("");
    mdTooltipDescription = I("");
    mdTooltipShown = rt();
    mdTooltipHidden = rt();
    element = d(x).nativeElement;
    document = d(Ut);
    overlay = d(yt);
    viewContainer = d(ge);
    aria = d(Ld);
    checker = d(Bd);
    direction = d(ke, { optional: !0 });
    id = `md-tooltip-${gf++}`;
    overlayRef;
    panel;
    subscriptions = new F;
    themeObserver;
    resizeObserver;
    listeners = [];
    showTimer;
    hideTimer;
    touchTimer;
    touchStart;
    describedText = "";
    panelClasses = [];
    hovered = !1;
    focused = !1;
    panelHovered = !1;
    destroyed = !1;
    restoringFocus = !1;
    constructor() { Dd(() => { let e = this.mdTooltip(); this.mdTooltipContext(), this.mdTooltipPosition(), this.mdTooltipInteractive(), this.mdTooltipClass(); let i = this.mdTooltipDisabled() ? "" : this.mdTooltipDescription() || (typeof e == "string" ? e : ""); i !== this.describedText && (this.describedText && this.aria.removeDescription(this.element, this.describedText), this.describedText = i, i && this.aria.describe(this.element, i)), this.canShow() ? this.panel && this.updatePanel() : this.hide(0); }); }
    show(e = this.mdTooltipShowDelay()) { !this.canShow() || this.destroyed || !this.document.defaultView || (clearTimeout(this.hideTimer), clearTimeout(this.showTimer), !this.panel && (e > 0 ? this.showTimer = setTimeout(() => this.open(), e) : this.open())); }
    hide(e = this.mdTooltipHideDelay()) { clearTimeout(this.showTimer), clearTimeout(this.hideTimer), e > 0 && this.panel ? this.hideTimer = setTimeout(() => this.close(), e) : this.close(); }
    onEnter(e) { e.pointerType !== "touch" && (this.hovered = !0, this.show()); }
    onLeave(e) { e.pointerType !== "touch" && (this.hovered = !1, this.hideIfInactive()); }
    onFocus() { this.focused = !0, !this.restoringFocus && !this.touchStart && this.show(0); }
    onBlur(e) { this.focused = this.element.contains(e.relatedTarget), this.panel?.location.nativeElement.contains(e.relatedTarget) || this.hideIfInactive(); }
    onKeydown(e) { if (e.key === "Escape" && this.hide(0), e.key === "Tab" && !e.shiftKey && this.mdTooltipInteractive() && this.panel) {
        let i = this.panel.location.nativeElement, o = Array.from(i.querySelectorAll("*")).find(r => this.checker.isTabbable(r));
        o && (e.preventDefault(), o.focus());
    } }
    onPointerDown(e) { e.pointerType === "touch" && (this.cancelTouch(), this.touchStart = { x: e.clientX, y: e.clientY }, this.touchTimer = setTimeout(() => this.show(0), 500)); }
    onPointerMove(e) { this.touchStart && Math.hypot(e.clientX - this.touchStart.x, e.clientY - this.touchStart.y) > 10 && this.cancelTouch(); }
    onPointerUp() { this.touchStart && (this.cancelTouch(), this.hide(1500)); }
    cancelTouch() { clearTimeout(this.touchTimer), this.touchStart = void 0; }
    canShow() { let e = this.mdTooltip(); return !this.mdTooltipDisabled() && (e instanceof H || typeof e == "string" && !!e.trim()); }
    hideIfInactive() { !this.hovered && !this.focused && !this.panelHovered && !this.panel?.location.nativeElement.contains(this.document.activeElement) && this.hide(); }
    positions() { let e = this.direction?.value === "rtl", i = this.mdTooltipPosition(); i === "left" && (i = e ? "after" : "before"), i === "right" && (i = e ? "before" : "after"); let o = { originX: "center", originY: "top", overlayX: "center", overlayY: "bottom", offsetY: -8 }, r = { originX: "center", originY: "bottom", overlayX: "center", overlayY: "top", offsetY: 8 }, s = { originX: "start", originY: "center", overlayX: "end", overlayY: "center", offsetX: e ? 8 : -8 }, l = { originX: "end", originY: "center", overlayX: "start", overlayY: "center", offsetX: e ? -8 : 8 }; return i === "below" ? [r, o, l, s] : i === "before" ? [s, l, o, r] : i === "after" ? [l, s, o, r] : [o, r, l, s]; }
    open() { if (!this.canShow() || this.destroyed || this.panel || !this.element.isConnected)
        return; let e = this.overlay.position().flexibleConnectedTo(this.element).withPositions(this.positions()).withViewportMargin(8).withFlexibleDimensions(!1).withPush(!0); this.overlayRef = this.overlay.create({ positionStrategy: e, direction: this.direction?.value || "ltr", scrollStrategy: this.overlay.scrollStrategies.reposition({ autoClose: !0 }), panelClass: "md-tooltip-overlay" }), this.syncTheme(), this.panel = this.overlayRef.attach(new Gr(uf, this.viewContainer)), this.panel.instance.id = this.id, this.updatePanel(), this.subscriptions.add(this.overlayRef.keydownEvents().subscribe(o => { o.key === "Escape" && (o.preventDefault(), o.stopPropagation(), this.hide(0)); })), this.subscriptions.add(this.overlayRef.outsidePointerEvents().subscribe(o => { this.element.contains(o.target) || this.hide(0); })), this.subscriptions.add(this.overlayRef.detachments().subscribe(() => this.close())), this.direction && this.subscriptions.add(this.direction.change.subscribe(() => this.updatePanel())); let i = this.panel.location.nativeElement; if (this.listen(i, "pointerenter", () => { this.panelHovered = !0, clearTimeout(this.hideTimer); }), this.listen(i, "pointerleave", () => { this.panelHovered = !1, this.hideIfInactive(); }), this.listen(i, "focusin", () => clearTimeout(this.hideTimer)), this.listen(i, "focusout", () => queueMicrotask(() => this.hideIfInactive())), this.listen(i, "keydown", o => { if (o.key === "Tab" && o.shiftKey) {
        let r = Array.from(i.querySelectorAll("*")).find(s => this.checker.isTabbable(s));
        this.document.activeElement === r && (o.preventDefault(), this.element.focus());
    } }), typeof MutationObserver < "u") {
        this.themeObserver = new MutationObserver(() => this.syncTheme());
        for (let o = this.element; o; o = o.parentElement)
            this.themeObserver.observe(o, { attributes: !0, attributeFilter: ["class", "style", "dir"] });
    } typeof ResizeObserver < "u" && (this.resizeObserver = new ResizeObserver(() => this.overlayRef?.updatePosition()), this.resizeObserver.observe(i)), this.mdTooltipShown.emit(); }
    updatePanel() { if (!this.panel || !this.overlayRef)
        return; let e = this.mdTooltip(); this.panel.instance.template.set(e instanceof H ? e : null), this.panel.instance.text.set(typeof e == "string" ? e : ""), this.panel.instance.context.set(this.mdTooltipContext() ?? {}), this.panel.instance.interactive.set(this.mdTooltipInteractive()), this.panel.instance.label.set(this.mdTooltipDescription() || (typeof e == "string" ? e : this.element.getAttribute("aria-label") || "Details")); let i = this.mdTooltipClass(); this.overlayRef.removePanelClass(this.panelClasses), this.panelClasses = typeof i == "string" ? i.split(/\s+/).filter(Boolean) : i, this.overlayRef.addPanelClass(this.panelClasses), Ne(this.element, "aria-describedby", this.id), Ne(this.element, "aria-controls", this.id), this.mdTooltipInteractive() ? Ht(this.element, "aria-controls", this.id) : this.describedText || Ht(this.element, "aria-describedby", this.id), this.overlayRef.setDirection(this.direction?.value || "ltr"), this.overlayRef.updatePositionStrategy(this.overlay.position().flexibleConnectedTo(this.element).withPositions(this.positions()).withViewportMargin(8).withFlexibleDimensions(!1).withPush(!0)), this.panel.changeDetectorRef.detectChanges(), this.overlayRef.updatePosition(); }
    syncTheme() { let e = this.overlayRef?.overlayElement, i = this.document.defaultView; if (!e || !i)
        return; let r = !!this.element.closest(".md-theme-dark, .md-theme-light, .theme-dark")?.matches(".md-theme-dark, .theme-dark"); e.classList.toggle("md-theme-dark", r), e.classList.toggle("md-theme-light", !r); let s = i.getComputedStyle(this.element); for (let l of Array.from(e.style))
        l.startsWith("--md-") && e.style.removeProperty(l); for (let l of Array.from(s))
        l.startsWith("--md-") && e.style.setProperty(l, s.getPropertyValue(l)); }
    listen(e, i, o) { e.addEventListener(i, o), this.listeners.push(() => e.removeEventListener(i, o)); }
    close() { let e = this.overlayRef; if (!e)
        return; let i = this.panel?.location.nativeElement.contains(this.document.activeElement); this.overlayRef = void 0, this.panel = void 0, this.panelHovered = !1, this.themeObserver?.disconnect(), this.resizeObserver?.disconnect(), this.subscriptions.unsubscribe(), this.subscriptions = new F, this.listeners.splice(0).forEach(o => o()), Ne(this.element, "aria-describedby", this.id), Ne(this.element, "aria-controls", this.id), e.dispose(), i && !this.destroyed && (this.restoringFocus = !0, this.element.focus(), this.restoringFocus = !1), this.destroyed || this.mdTooltipHidden.emit(); }
    ngOnDestroy() { this.destroyed = !0, clearTimeout(this.showTimer), clearTimeout(this.hideTimer), this.cancelTouch(), this.close(), this.describedText && this.aria.removeDescription(this.element, this.describedText); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdTooltip", ""]], hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("pointerenter", function (s) { return o.onEnter(s); })("pointerleave", function (s) { return o.onLeave(s); })("focusin", function () { return o.onFocus(); })("focusout", function (s) { return o.onBlur(s); })("keydown", function (s) { return o.onKeydown(s); })("pointerdown", function (s) { return o.onPointerDown(s); })("pointermove", function (s) { return o.onPointerMove(s); })("pointerup", function () { return o.onPointerUp(); })("pointercancel", function () { return o.cancelTouch(); }); }, inputs: { mdTooltip: [1, "mdTooltip"], mdTooltipContext: [1, "mdTooltipContext"], mdTooltipPosition: [1, "mdTooltipPosition"], mdTooltipDisabled: [1, "mdTooltipDisabled"], mdTooltipInteractive: [1, "mdTooltipInteractive"], mdTooltipShowDelay: [1, "mdTooltipShowDelay"], mdTooltipHideDelay: [1, "mdTooltipHideDelay"], mdTooltipClass: [1, "mdTooltipClass"], mdTooltipDescription: [1, "mdTooltipDescription"] }, outputs: { mdTooltipShown: "mdTooltipShown", mdTooltipHidden: "mdTooltipHidden" }, exportAs: ["mdTooltip"] });
} return n; })(), gx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), fx = (() => { class n {
    el = d(x);
    getContainerElement() { return this.el.nativeElement; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "toastContainer", ""]], exportAs: ["toastContainer"] });
} return n; })(), gt = class {
    toastId;
    config;
    message;
    title;
    toastType;
    toastRef;
    onTapValue = new D;
    onActionValue = new D;
    constructor(a, e, i, o, r, s) { this.toastId = a, this.config = e, this.message = i, this.title = o, this.toastType = r, this.toastRef = s, this.toastRef.afterClosed().subscribe(() => { this.onActionValue.complete(), this.onTapValue.complete(); }); }
    triggerTap() { this.onTapValue.next(), this.config.tapToDismiss && this.onTapValue.complete(); }
    onTap() { return this.onTapValue.asObservable(); }
    triggerAction(a) { this.onActionValue.next(a); }
    onAction() { return this.onActionValue.asObservable(); }
}, Xn = { maxOpened: 0, autoDismiss: !1, newestOnTop: !0, preventDuplicates: !1, countDuplicates: !1, resetTimeoutOnDuplicate: !1, includeTitleDuplicates: !1, iconClasses: { error: "toast-error", info: "toast-info", success: "toast-success", warning: "toast-warning" }, closeButton: !1, disableTimeOut: !1, timeOut: 5e3, extendedTimeOut: 1e3, enableHtml: !1, progressBar: !1, toastClass: "ngx-toastr", positionClass: "toast-top-right", titleClass: "toast-title", messageClass: "toast-message", easing: "ease-in", easeTime: 300, tapToDismiss: !0, onActivateTick: !1, progressAnimation: "decreasing" }, ni = new k("ToastConfig"), gn = class {
    attachedHost;
    component;
    viewContainerRef;
    injector;
    constructor(a, e) { this.component = a, this.injector = e; }
    attach(a, e) { return this.attachedHost = a, a.attach(this, e); }
    detach() { let a = this.attachedHost; if (a)
        return this.attachedHost = void 0, a.detach(); }
    get isAttached() { return this.attachedHost != null; }
    setAttachedHost(a) { this.attachedHost = a; }
}, fn = class {
    attachedPortal;
    disposeFn;
    attach(a, e) { return this.attachedPortal = a, this.attachComponentPortal(a, e); }
    detach() { this.attachedPortal && this.attachedPortal.setAttachedHost(), this.attachedPortal = void 0, this.disposeFn && (this.disposeFn(), this.disposeFn = void 0); }
    setDisposeFn(a) { this.disposeFn = a; }
}, bn = class extends fn {
    hostDomElement;
    appRef;
    constructor(a, e) { super(), this.hostDomElement = a, this.appRef = e; }
    attachComponentPortal(a, e) { let i = Md(a.component, { environmentInjector: this.appRef.injector, elementInjector: a.injector }); return this.appRef.attachView(i.hostView), this.setDisposeFn(() => { this.appRef.detachView(i.hostView), i.destroy(); }), e ? this.hostDomElement.insertBefore(this.getComponentRootNode(i), this.hostDomElement.firstChild) : this.hostDomElement.appendChild(this.getComponentRootNode(i)), i; }
    getComponentRootNode(a) { return a.hostView.rootNodes[0]; }
}, ff = (() => { class n {
    document = d(Ut);
    containerElement;
    ngOnDestroy() { this.containerElement && this.containerElement.parentNode && this.containerElement.parentNode.removeChild(this.containerElement); }
    getContainerElement() { return this.containerElement || this.createContainer(), this.containerElement; }
    createContainer() { let e = this.document.createElement("div"); e.classList.add("overlay-container"), e.setAttribute("aria-live", "polite"), this.document.body.appendChild(e), this.containerElement = e; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), _n = class {
    portalHost;
    constructor(a) { this.portalHost = a; }
    attach(a, e = !0) { return this.portalHost.attach(a, e); }
    detach() { return this.portalHost.detach(); }
}, bf = (() => { class n {
    overlayContainer = d(ff);
    appRef = d(wn);
    document = d(Ut);
    paneElements = new Map;
    create(e, i) { return this.createOverlayRef(this.getPaneElement(e, i)); }
    getPaneElement(e = "", i) { return this.paneElements.get(i) || this.paneElements.set(i, {}), this.paneElements.get(i)[e] || (this.paneElements.get(i)[e] = this.createPaneElement(e, i)), this.paneElements.get(i)[e]; }
    createPaneElement(e, i) { let o = this.document.createElement("div"); return o.id = "toast-container", o.classList.add(e), o.classList.add("toast-container"), i ? i.getContainerElement().appendChild(o) : this.overlayContainer.getContainerElement().appendChild(o), o; }
    createPortalHost(e) { return new bn(e, this.appRef); }
    createOverlayRef(e) { return new _n(this.createPortalHost(e)); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), vn = class {
    overlayRef;
    componentInstance;
    duplicatesCount = 0;
    afterClosedValue = new D;
    activateValue = new D;
    manualCloseValue = new D;
    resetTimeout = new D;
    countDuplicateValue = new D;
    constructor(a) { this.overlayRef = a; }
    manualClose() { this.manualCloseValue.next(), this.manualCloseValue.complete(); }
    manualClosed() { return this.manualCloseValue.asObservable(); }
    timeoutReset() { return this.resetTimeout.asObservable(); }
    countDuplicate() { return this.countDuplicateValue.asObservable(); }
    close() { this.overlayRef.detach(), this.afterClosedValue.next(), this.manualCloseValue.next(), this.afterClosedValue.complete(), this.manualCloseValue.complete(), this.activateValue.complete(), this.resetTimeout.complete(), this.countDuplicateValue.complete(); }
    afterClosed() { return this.afterClosedValue.asObservable(); }
    isInactive() { return this.activateValue.closed; }
    activate() { this.activateValue.next(), this.activateValue.complete(); }
    afterActivate() { return this.activateValue.asObservable(); }
    onDuplicate(a, e) { a && this.resetTimeout.next(), e && this.countDuplicateValue.next(++this.duplicatesCount); }
}, _f = (() => { class n {
    overlay = d(bf);
    injector = d(j);
    sanitizer = d(cl);
    ngZone = d(K);
    toastrConfig;
    currentlyActive = 0;
    toasts = [];
    overlayContainer;
    previousToastMessage;
    index = 0;
    constructor() { let e = d(ni); this.toastrConfig = _(_({}, e.default), e.config), e.config.iconClasses && (this.toastrConfig.iconClasses = _(_({}, e.default.iconClasses), e.config.iconClasses)); }
    show(e, i, o = {}, r = "") { return this.preBuildNotification(r, e, i, this.applyConfig(o)); }
    success(e, i, o = {}) { let r = this.toastrConfig.iconClasses.success || ""; return this.preBuildNotification(r, e, i, this.applyConfig(o)); }
    error(e, i, o = {}) { let r = this.toastrConfig.iconClasses.error || ""; return this.preBuildNotification(r, e, i, this.applyConfig(o)); }
    info(e, i, o = {}) { let r = this.toastrConfig.iconClasses.info || ""; return this.preBuildNotification(r, e, i, this.applyConfig(o)); }
    warning(e, i, o = {}) { let r = this.toastrConfig.iconClasses.warning || ""; return this.preBuildNotification(r, e, i, this.applyConfig(o)); }
    clear(e) { for (let i of this.toasts)
        if (e !== void 0) {
            if (i.toastId === e) {
                i.toastRef.manualClose();
                return;
            }
        }
        else
            i.toastRef.manualClose(); }
    remove(e) { let i = this.findToast(e); if (!i || (i.activeToast.toastRef.close(), this.toasts.splice(i.index, 1), this.currentlyActive = this.currentlyActive - 1, !this.toastrConfig.maxOpened || !this.toasts.length))
        return !1; if (this.currentlyActive < this.toastrConfig.maxOpened && this.toasts[this.currentlyActive]) {
        let o = this.toasts[this.currentlyActive].toastRef;
        o.isInactive() || (this.currentlyActive = this.currentlyActive + 1, o.activate());
    } return !0; }
    findDuplicate(e = "", i = "", o, r) { let { includeTitleDuplicates: s } = this.toastrConfig; for (let l of this.toasts) {
        let c = s && l.title === e;
        if ((!s || c) && l.message === i)
            return l.toastRef.onDuplicate(o, r), l;
    } return null; }
    applyConfig(e = {}) { return _(_({}, this.toastrConfig), e); }
    findToast(e) { for (let i = 0; i < this.toasts.length; i++)
        if (this.toasts[i].toastId === e)
            return { index: i, activeToast: this.toasts[i] }; return null; }
    preBuildNotification(e, i, o, r) { return r.onActivateTick ? this.ngZone.run(() => this.buildNotification(e, i, o, r)) : this.buildNotification(e, i, o, r); }
    buildNotification(e, i, o, r) { if (!r.toastComponent)
        throw new Error("toastComponent required"); let s = this.findDuplicate(o, i, this.toastrConfig.resetTimeoutOnDuplicate && r.timeOut > 0, this.toastrConfig.countDuplicates); if ((this.toastrConfig.includeTitleDuplicates && o || i) && this.toastrConfig.preventDuplicates && s !== null)
        return s; this.previousToastMessage = i; let l = !1; this.toastrConfig.maxOpened && this.currentlyActive >= this.toastrConfig.maxOpened && (l = !0, this.toastrConfig.autoDismiss && this.clear(this.toasts[0].toastId)); let c = this.overlay.create(r.positionClass, this.overlayContainer); this.index = this.index + 1; let h = i; i && r.enableHtml && (h = this.sanitizer.sanitize(Td.HTML, i)); let g = new vn(c), u = new gt(this.index, r, h, o, e, g), f = [{ provide: gt, useValue: u }], v = j.create({ providers: f, parent: this.injector }), w = new gn(r.toastComponent, v), N = c.attach(w, r.newestOnTop); g.componentInstance = N.instance; let M = { toastId: this.index, title: o || "", message: i || "", toastRef: g, onShown: g.afterActivate(), onHidden: g.afterClosed(), onTap: u.onTap(), onAction: u.onAction(), portal: N }; return l || (this.currentlyActive = this.currentlyActive + 1, setTimeout(() => { M.toastRef.activate(); })), this.toasts.push(M), M; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), vf = (() => { class n {
    ngZone = d(K);
    setInterval(e, i) { return this.ngZone ? this.ngZone.runOutsideAngular(() => window.setInterval(() => this.runInsideAngular(e), i)) : window.setInterval(() => e(), i); }
    setTimeout(e, i) { return this.ngZone ? this.ngZone.runOutsideAngular(() => window.setTimeout(() => this.runInsideAngular(e), i)) : window.setTimeout(() => e(), i); }
    runInsideAngular(e) { this.ngZone ? this.ngZone.run(() => e()) : e(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), Ha = (() => { class n {
    destroyRef = d(Or);
    toastPackage = d(gt);
    toastrService = d(_f);
    appRef = d(wn);
    timeoutsService = d(vf);
    duplicatesCount;
    hideTime;
    width = B(-1);
    state = B("inactive");
    displayStyle = re(() => this.state() === "inactive" ? "none" : void 0);
    message = re(() => this.toastPackage.message);
    title = re(() => this.toastPackage.title);
    options = Ed(() => this.toastPackage.config);
    originalTimeout = re(() => this.toastPackage.config.timeOut);
    toastClasses = re(() => `${this.toastPackage.toastType} ${this.toastPackage.config.toastClass}`);
    timeout;
    intervalId;
    constructor() { this.toastPackage.toastRef.afterActivate().pipe(ot(this.destroyRef)).subscribe(() => { this.activateToast(); }), this.toastPackage.toastRef.manualClosed().pipe(ot(this.destroyRef)).subscribe(() => { this.remove(); }), this.toastPackage.toastRef.timeoutReset().pipe(ot(this.destroyRef)).subscribe(() => { this.resetTimeout(); }), this.toastPackage.toastRef.countDuplicate().pipe(ot(this.destroyRef)).subscribe(e => { this.duplicatesCount = e; }); }
    ngOnDestroy() { clearInterval(this.intervalId), clearTimeout(this.timeout); }
    activateToast() { let e = this.options(); this.state.set("active"), !(e.disableTimeOut === !0 || e.disableTimeOut === "timeOut") && e.timeOut && (this.timeout = this.timeoutsService.setTimeout(() => this.remove(), e.timeOut), this.hideTime = new Date().getTime() + e.timeOut, e.progressBar && (this.intervalId = this.timeoutsService.setInterval(() => this.updateProgress(), 10))); }
    updateProgress() { let e = this.options(); if (this.width() === 0 || this.width() === 100 || !e.timeOut)
        return; let i = new Date().getTime(), o = this.hideTime - i; this.width.set(o / e.timeOut * 100), e.progressAnimation === "increasing" && this.width.update(r => 100 - r), this.width() <= 0 && this.width.set(0), this.width() >= 100 && this.width.set(100); }
    resetTimeout() { let e = this.options(); clearTimeout(this.timeout), clearInterval(this.intervalId), this.state.set("active"), this.options.update(i => G(_({}, i), { timeOut: this.originalTimeout() })), this.timeout = this.timeoutsService.setTimeout(() => this.remove(), this.originalTimeout()), this.hideTime = new Date().getTime() + (this.originalTimeout() || 0), this.width.set(-1), e.progressBar && (this.intervalId = this.timeoutsService.setInterval(() => this.updateProgress(), 10)); }
    remove() { this.state() !== "removed" && (clearTimeout(this.timeout), this.state.set("removed"), this.timeout = this.timeoutsService.setTimeout(() => this.toastrService.remove(this.toastPackage.toastId))); }
    tapToast() { this.state() !== "removed" && (this.toastPackage.triggerTap(), this.options().tapToDismiss && this.remove()); }
    stickAround() { this.state() !== "removed" && this.options().disableTimeOut !== "extendedTimeOut" && (clearTimeout(this.timeout), this.options.update(e => G(_({}, e), { timeOut: 0 })), this.hideTime = 0, clearInterval(this.intervalId), this.width.set(0)); }
    delayedHideToast() { let e = this.options(); if (e.disableTimeOut === !0 || e.disableTimeOut === "extendedTimeOut" || e.extendedTimeOut === 0 || this.state() === "removed")
        return; let i = e.extendedTimeOut; this.timeout = this.timeoutsService.setTimeout(() => this.remove(), i), this.options.update(o => G(_({}, o), { timeOut: i })), this.hideTime = new Date().getTime() + (i || 0), this.width.set(-1), e.progressBar && (this.intervalId = this.timeoutsService.setInterval(() => this.updateProgress(), 10)); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["", "toast-component", ""]], hostVars: 4, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("mouseenter", function () { return o.stickAround(); })("mouseleave", function () { return o.delayedHideToast(); })("click", function () { return o.tapToast(); }), i & 2 && (t.\u0275\u0275classMap(o.toastClasses()), t.\u0275\u0275styleProp("display", o.displayStyle())); }, decls: 5, vars: 5, consts: [["type", "button", "aria-label", "Close", 1, "toast-close-button"], [3, "class"], ["type", "button", "aria-label", "Close", 1, "toast-close-button", 3, "click"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "aria-hidden", "true", "focusable", "false", 2, "display", "block"], ["d", "m6 6 12 12M18 6 6 18"], ["role", "alert", 3, "class", "innerHTML"], ["role", "alert", 3, "class"], ["role", "alert", 3, "innerHTML"], ["role", "alert"], [1, "toast-progress"]], template: function (i, o) { if (i & 1 && (t.\u0275\u0275declareLet(0), t.\u0275\u0275conditionalCreate(1, qh, 3, 0, "button", 0), t.\u0275\u0275conditionalCreate(2, Kh, 3, 5, "div", 1), t.\u0275\u0275conditionalCreate(3, Zh, 2, 1), t.\u0275\u0275conditionalCreate(4, Jh, 2, 2, "div")), i & 2) {
            let r = t.\u0275\u0275storeLet(o.options());
            t.\u0275\u0275advance(), t.\u0275\u0275conditional(r.closeButton ? 1 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.title() ? 2 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.message() ? 3 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(r.progressBar ? 4 : -1);
        } }, encapsulation: 2 });
} return n; })(), yf = (() => { class n extends Ha {
    params = { easeTime: this.toastPackage.config.easeTime, easing: "ease-in" };
    elementRef = d(x);
    remove() { this.state() !== "removed" && (clearTimeout(this.timeout), this.state.set("removed"), this.elementRef.nativeElement.classList.add("toast-out"), this.timeout = this.timeoutsService.setTimeout(() => this.toastrService.remove(this.toastPackage.toastId), +this.params.easeTime)); }
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["", "toast-component", ""]], hostVars: 4, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275animateEnter("toast-in"), i & 2 && t.\u0275\u0275styleProp("--%NS%animation-easing", o.params.easing)("--%NS%animation-duration", o.params.easeTime + "ms"); }, features: [t.\u0275\u0275InheritDefinitionFeature], decls: 5, vars: 5, consts: [["type", "button", "aria-label", "Close", 1, "toast-close-button"], [3, "class"], ["type", "button", "aria-label", "Close", 1, "toast-close-button", 3, "click"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "aria-hidden", "true", "focusable", "false", 2, "display", "block"], ["d", "m6 6 12 12M18 6 6 18"], ["role", "alert", 3, "class", "innerHTML"], ["role", "alert", 3, "class"], ["role", "alert", 3, "innerHTML"], ["role", "alert"], [1, "toast-progress"]], template: function (i, o) { if (i & 1 && (t.\u0275\u0275declareLet(0), t.\u0275\u0275conditionalCreate(1, ep, 3, 0, "button", 0), t.\u0275\u0275conditionalCreate(2, ip, 3, 5, "div", 1), t.\u0275\u0275conditionalCreate(3, rp, 2, 1), t.\u0275\u0275conditionalCreate(4, ap, 2, 2, "div")), i & 2) {
            let r = t.\u0275\u0275storeLet(o.options());
            t.\u0275\u0275advance(), t.\u0275\u0275conditional(r.closeButton ? 1 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.title() ? 2 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.message() ? 3 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(r.progressBar ? 4 : -1);
        } }, styles: [".toast-in[_nghost-%COMP%]{animation:_ngcontent-%COMP%_toast-animation var(--%NS%animation-duration) var(--%NS%animation-easing)}.toast-out[_nghost-%COMP%]{animation:_ngcontent-%COMP%_toast-animation var(--%NS%animation-duration) var(--%NS%animation-easing) reverse forwards}@keyframes _ngcontent-%COMP%_toast-animation{0%{opacity:0}to{opacity:1}}"] });
} return n; })(), xf = G(_({}, Xn), { toastComponent: yf }), kf = (n = {}) => Id([{ provide: ni, useValue: { default: xf, config: n } }]), bx = (() => { class n {
    static forRoot(e = {}) { return { ngModule: n, providers: [kf(e)] }; }
    static forChild() { return { ngModule: n, providers: [] }; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), _x = (() => { class n {
    static forRoot(e = {}) { return { ngModule: n, providers: [{ provide: ni, useValue: { default: Xn, config: e } }] }; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), Cf = G(_({}, Xn), { toastComponent: Ha }), vx = (() => { class n {
    static forRoot(e = {}) { return { ngModule: n, providers: [{ provide: ni, useValue: { default: Cf, config: e } }] }; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), wf = (() => {
    class n {
        multiple = !1;
        vertical = !1;
        disabled = !1;
        value = null;
        valueChange = new p;
        change = new p;
        toggles;
        element = d(x);
        onChange = () => { };
        onTouched = () => { };
        isSelected(e) { return this.multiple ? Array.isArray(this.value) && this.value.includes(e) : Object.is(this.value, e); }
        select(e) { if (!(this.disabled || e.disabled)) {
            if (this.multiple) {
                let i = Array.isArray(this.value) ? this.value : [];
                this.value = this.isSelected(e.value) ? i.filter(o => !Object.is(o, e.value)) : [...i, e.value];
            }
            else {
                if (this.isSelected(e.value))
                    return;
                this.value = e.value;
            }
            this.onChange(this.value), this.valueChange.emit(this.value), this.change.emit({ source: e, value: this.value });
        } }
        tabIndex(e) { if (e.isDisabled)
            return -1; if (this.multiple)
            return 0; let i = this.toggles?.filter(o => !o.isDisabled) ?? []; return (i.find(o => o.checked) ?? i[0]) === e ? 0 : -1; }
        navigate(e, i) { if (this.disabled || i.isDisabled)
            return; let o = this.vertical ? "ArrowUp" : "ArrowLeft", r = this.vertical ? "ArrowDown" : "ArrowRight"; if (![o, r, "Home", "End"].includes(e.key))
            return; let s = this.toggles.filter(h => !h.isDisabled); if (!s.length)
            return; e.preventDefault(); let l = e.key === r ? 1 : -1; !this.vertical && getComputedStyle(this.element.nativeElement).direction === "rtl" && (l *= -1); let c = e.key === "Home" ? 0 : e.key === "End" ? s.length - 1 : (s.indexOf(i) + l + s.length) % s.length; s[c].focus(), this.multiple || s[c].activate(); }
        onFocusOut(e) { this.element.nativeElement.contains(e.relatedTarget) || this.onTouched(); }
        writeValue(e) { this.value = e; }
        registerOnChange(e) { this.onChange = e; }
        registerOnTouched(e) { this.onTouched = e; }
        setDisabledState(e) { this.disabled = e; }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-button-toggle-group"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Sf, 4), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.toggles = s);
            } }, hostAttrs: [1, "md-button-toggle-group"], hostVars: 5, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("focusout", function (s) { return o.onFocusOut(s); }), i & 2 && (t.\u0275\u0275attribute("role", o.multiple ? "group" : "radiogroup")("aria-disabled", o.disabled)("aria-orientation", o.vertical ? "vertical" : "horizontal"), t.\u0275\u0275classProp("md-button-toggle-vertical", o.vertical)); }, inputs: { multiple: [2, "multiple", "multiple", m], vertical: [2, "vertical", "vertical", m], disabled: [2, "disabled", "disabled", m], value: "value" }, outputs: { valueChange: "valueChange", change: "change" }, features: [t.\u0275\u0275ProvidersFeature([{ provide: J, useExisting: A(() => n), multi: !0 }])], ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275projection(0)); }, styles: [`.md-button-toggle-group{display:inline-flex;border:1px solid var(--%NS%md-color-border, #b8bcc2);border-radius:var(--%NS%md-button-toggle-radius, 6px);isolation:isolate;vertical-align:middle}.md-button-toggle-group>.md-button-toggle{border:0;border-radius:0}.md-button-toggle-group>.md-button-toggle:first-child{border-start-start-radius:inherit;border-end-start-radius:inherit}.md-button-toggle-group>.md-button-toggle:last-child{border-start-end-radius:inherit;border-end-end-radius:inherit}.md-button-toggle-group>.md-button-toggle+.md-button-toggle{border-inline-start:1px solid var(--%NS%md-color-border, #b8bcc2)}.md-button-toggle-group.md-button-toggle-vertical{flex-direction:column}.md-button-toggle-group.md-button-toggle-vertical>.md-button-toggle{border-radius:0}.md-button-toggle-group.md-button-toggle-vertical>.md-button-toggle:first-child{border-start-start-radius:inherit;border-start-end-radius:inherit}.md-button-toggle-group.md-button-toggle-vertical>.md-button-toggle:last-child{border-end-start-radius:inherit;border-end-end-radius:inherit}.md-button-toggle-group.md-button-toggle-vertical>.md-button-toggle+.md-button-toggle{border-inline-start:0;border-block-start:1px solid var(--%NS%md-color-border, #b8bcc2)}.md-button-toggle{display:inline-flex;position:relative;border:1px solid var(--%NS%md-color-border, #b8bcc2);border-radius:var(--%NS%md-button-toggle-radius, 6px);color:var(--%NS%md-button-toggle-color, var(--%NS%md-color-text, #30343b));background:var(--%NS%md-button-toggle-bg, var(--%NS%md-color-surface, #fff))}.md-button-toggle.md-button-toggle-checked{color:var(--%NS%md-button-toggle-selected-color, #174ea6);background:var(--%NS%md-button-toggle-selected-bg, #d3e3fd)}.md-button-toggle.md-button-toggle-disabled{opacity:.45}.md-button-toggle-button{display:inline-flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:var(--%NS%md-button-toggle-height, 40px);padding:0 20px;border:0;border-radius:inherit;background:transparent;color:inherit;font-family:var(--%NS%md-button-font-family, Montserrat, sans-serif);font-size:14px;font-weight:600;line-height:24px;cursor:pointer}.md-button-toggle-button:hover:not(:disabled){background:var(--%NS%md-button-toggle-hover-bg, rgba(0, 0, 0, .06))}.md-button-toggle-button:focus-visible{outline:2px solid var(--%NS%md-color-link, #1967d2);outline-offset:-3px}.md-button-toggle-button:disabled{cursor:not-allowed}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})(), Sf = (() => { class n {
    group = d(wf, { optional: !0 });
    value;
    disabled = !1;
    ariaLabel = null;
    ariaLabelledby = null;
    standaloneChecked = !1;
    get checked() { return this.group ? this.group.isSelected(this.value) : this.standaloneChecked; }
    set checked(e) { this.standaloneChecked = e; }
    checkedChange = new p;
    change = new p;
    button;
    get isDisabled() { return this.disabled || !!this.group?.disabled; }
    focus() { this.button.nativeElement.focus(); }
    activate() { if (this.isDisabled)
        return; let e = this.checked; this.group ? this.group.select(this) : this.standaloneChecked = !this.standaloneChecked, e !== this.checked && (this.checkedChange.emit(this.checked), this.change.emit({ source: this, value: this.value })); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-button-toggle"]], viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(sp, 7), i & 2) {
            let r;
            t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.button = r.first);
        } }, hostAttrs: [1, "md-button-toggle"], hostVars: 4, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("md-button-toggle-checked", o.checked)("md-button-toggle-disabled", o.isDisabled); }, inputs: { value: "value", disabled: [2, "disabled", "disabled", m], ariaLabel: [0, "aria-label", "ariaLabel"], ariaLabelledby: [0, "aria-labelledby", "ariaLabelledby"], checked: [2, "checked", "checked", m] }, outputs: { checkedChange: "checkedChange", change: "change" }, ngContentSelectors: T, decls: 3, vars: 7, consts: [["button", ""], ["type", "button", 1, "md-button-toggle-button", 3, "click", "keydown", "disabled"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElementStart(0, "button", 1, 0), t.\u0275\u0275domListener("click", function () { return o.activate(); })("keydown", function (s) { return o.group?.navigate(s, o); }), t.\u0275\u0275projection(2), t.\u0275\u0275domElementEnd()), i & 2 && (t.\u0275\u0275domProperty("disabled", o.isDisabled), t.\u0275\u0275attribute("role", o.group && !o.group.multiple ? "radio" : "button")("aria-checked", o.group && !o.group.multiple ? o.checked : null)("aria-pressed", !o.group || o.group.multiple ? o.checked : null)("aria-label", o.ariaLabel)("aria-labelledby", o.ariaLabelledby)("tabindex", o.group ? o.group.tabIndex(o) : o.isDisabled ? -1 : 0)); }, styles: [dp], encapsulation: 2, changeDetection: 1 });
} return n; })(), yx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), yn = class {
    duration = 0;
    horizontalPosition = "center";
    verticalPosition = "bottom";
    direction = "ltr";
    politeness = "polite";
    announcementMessage;
    panelClass;
}, Df = new k("MD_SNACK_BAR_DEFAULT_OPTIONS"), ft = class {
    dispose;
    opened = new dr(1);
    dismissed = new dr(1);
    action = new D;
    closed = !1;
    timer;
    remaining = 0;
    started = 0;
    pauses = new Set;
    constructor(a) { this.dispose = a; }
    afterOpened() { return this.opened.asObservable(); }
    afterDismissed() { return this.dismissed.asObservable(); }
    onAction() { return this.action.asObservable(); }
    dismiss() { this.finish(!1); }
    dismissWithAction() { this.finish(!0); }
    _open(a) { this.closed || (this.remaining = Number.isFinite(a) ? Math.max(0, a) : 0, this.opened.next(), this.opened.complete(), this.schedule()); }
    _pause(a) { !this.pauses.size && this.timer !== void 0 && (clearTimeout(this.timer), this.timer = void 0, this.remaining = Math.max(1, this.remaining - (Date.now() - this.started))), this.pauses.add(a); }
    _resume(a) { this.pauses.delete(a), this.pauses.size || this.schedule(); }
    schedule() { this.closed || this.pauses.size || this.remaining <= 0 || this.timer !== void 0 || (this.started = Date.now(), this.timer = setTimeout(() => this.dismiss(), this.remaining)); }
    finish(a) { this.closed || (this.closed = !0, clearTimeout(this.timer), this.dispose(), a && this.action.next(), this.action.complete(), this.opened.complete(), this.dismissed.next({ dismissedByAction: a }), this.dismissed.complete()); }
}, ja = new k("MD_SNACK_BAR_CONTENT"), Mf = (() => {
    class n {
        content = d(ja);
        ref = d(ft);
        element = d(x);
        onFocusOut(e) { this.element.nativeElement.contains(e.relatedTarget) || this.ref._resume("focus"); }
        dismiss(e) { e.stopPropagation(), this.ref.dismiss(); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-snack-bar-container"]], hostAttrs: ["role", "group", 1, "md-snack-bar-container"], hostVars: 1, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("mouseenter", function () { return o.ref._pause("hover"); })("mouseleave", function () { return o.ref._resume("hover"); })("focusin", function () { return o.ref._pause("focus"); })("focusout", function (s) { return o.onFocusOut(s); })("keydown.escape", function (s) { return o.dismiss(s); }), i & 2 && t.\u0275\u0275attribute("aria-label", o.content.message); }, decls: 3, vars: 2, consts: [[1, "md-snack-bar-message"], ["type", "button", 1, "md-snack-bar-action"], ["type", "button", 1, "md-snack-bar-action", 3, "click"]], template: function (i, o) { i & 1 && (t.\u0275\u0275domElementStart(0, "span", 0), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd(), t.\u0275\u0275conditionalCreate(2, lp, 2, 1, "button", 1)), i & 2 && (t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(o.content.message), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.content.action ? 2 : -1)); }, styles: [`.md-snack-bar-container{display:flex;align-items:center;gap:16px;box-sizing:border-box;width:max-content;min-width:min(344px,100vw - 32px);max-width:min(560px,100vw - 32px);min-height:48px;padding:8px 16px;border-radius:var(--%NS%md-snack-bar-radius, 4px);background:var(--%NS%md-snack-bar-background, #323232);color:var(--%NS%md-snack-bar-color, #fff);box-shadow:0 3px 5px -1px #0003,0 6px 10px #0002,0 1px 18px #0002;font-family:var(--%NS%md-font-body, "Open Sans", sans-serif);font-size:14px;line-height:20px;animation:md-snack-bar-enter .15s ease-out}.md-snack-bar-message{flex:1;min-width:0;overflow-wrap:anywhere}.md-snack-bar-action{flex-shrink:0;max-width:45%;overflow-wrap:anywhere;min-height:36px;padding:0 8px;border:none;border-radius:4px;background:transparent;color:var(--%NS%md-snack-bar-action-color, #a8c7fa);font:inherit;font-weight:600;cursor:pointer}.md-snack-bar-action:hover{background:#ffffff14}.md-snack-bar-action:focus-visible{outline:2px solid currentColor;outline-offset:2px}@keyframes md-snack-bar-enter{0%{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){.md-snack-bar-container{animation:none}}
`], encapsulation: 2 });
    }
    return n;
})(), xx = (() => { class n {
    injector = d(j);
    announcer = d(zd);
    directionality = d(ke, { optional: !0 });
    defaults = d(Df, { optional: !0 });
    current = null;
    open(e, i = "", o = {}) { let r = _(_(G(_({}, new yn), { direction: this.directionality?.value ?? "ltr" }), this.defaults), o); this.dismiss(); let s = Zt(this.injector); r.verticalPosition === "top" ? s.top("24px") : s.bottom("24px"); let l = r.horizontalPosition; l === "center" ? s.centerHorizontally() : l === "left" || l === "start" && r.direction === "ltr" || l === "end" && r.direction === "rtl" ? s.left("16px") : s.right("16px"); let c = On(this.injector, { positionStrategy: s, scrollStrategy: Xd(), direction: r.direction, panelClass: r.panelClass, maxWidth: "calc(100vw - 32px)", hasBackdrop: !1 }), h = new ft(() => c.dispose()); this.current = h, h.afterDismissed().subscribe(() => { this.current === h && (this.current = null); }), c.detachments().subscribe(() => h.dismiss()); let g = j.create({ parent: this.injector, providers: [{ provide: ft, useValue: h }, { provide: ja, useValue: { message: e, action: i } }] }); try {
        c.attach(new Gr(Mf, null, g)), h._open(r.duration);
        let u = r.announcementMessage ?? e;
        u && r.politeness !== "off" && this.announcer.announce(u, r.politeness);
    }
    catch (u) {
        throw h.dismiss(), u;
    } return h; }
    dismiss() { this.current?.dismiss(); }
    ngOnDestroy() { this.dismiss(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), kx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [vt] });
} return n; })(), Wa = new k("MD_FORM_FIELD"), Tf = 0, Ef = (() => { class n {
    element = d(x);
    ngControl = d(Ln, { self: !0, optional: !0 });
    select = d(Jt, { self: !0, optional: !0 });
    field = d(Wa, { optional: !0 });
    subscriptions = new F;
    originalLabel = this.element.nativeElement.getAttribute("aria-labelledby");
    originalDescription = this.element.nativeElement.getAttribute("aria-describedby");
    id = this.element.nativeElement.id || `md-input-${Tf++}`;
    get labelledBy() { return [this.originalLabel, this.field?.label ? this.field.labelId : null].filter(Boolean).join(" ") || null; }
    get describedBy() { return [this.originalDescription, this.field?.describedBy].filter(Boolean).join(" ") || null; }
    get empty() { return this.select ? this.select.empty : !this.element.nativeElement.value; }
    get disabled() { return this.select ? this.select.disabled : this.element.nativeElement.disabled; }
    get readonly() { return "readOnly" in this.element.nativeElement && this.element.nativeElement.readOnly; }
    get required() { return !!(this.select?.required || this.element.nativeElement.required || this.ngControl?.control?.hasValidator(Bn.required)); }
    get focused() { return !!this.select?.focused; }
    get alwaysFloat() { return !!this.select || this.element.nativeElement.tagName === "SELECT" || ["date", "time", "datetime-local", "month", "week", "color", "file"].includes(this.element.nativeElement.type); }
    focus() { this.disabled || this.element.nativeElement.focus(); }
    refresh() { this.field?.refresh(); }
    ngAfterViewInit() { this.select && this.subscriptions.add(this.select.stateChanges.subscribe(() => this.refresh())), this.ngControl?.control && this.subscriptions.add(this.ngControl.control.events.subscribe(() => this.refresh())); }
    ngOnDestroy() { this.subscriptions.unsubscribe(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["input", "mdInput", ""], ["textarea", "mdInput", ""], ["select", "mdInput", ""], ["md-select", "mdFormFieldControl", ""]], hostAttrs: [1, "md-form-field-control"], hostVars: 5, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("input", function () { return o.refresh(); })("change", function () { return o.refresh(); })("focus", function () { return o.refresh(); })("blur", function () { return o.refresh(); }), i & 2 && t.\u0275\u0275attribute("id", o.id)("aria-labelledby", o.labelledBy)("aria-describedby", o.describedBy)("aria-invalid", o.field?.invalid || null)("aria-required", o.required || null); } });
} return n; })(), Cx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdPrefix", ""]] });
} return n; })(), wx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdSuffix", ""]] });
} return n; })(), If = 0, Sx = (() => {
    class n {
        appearance = "outlined";
        labelPosition = "top";
        label = "";
        hint = "";
        error = "Invalid value";
        invalidState = !1;
        hideRequiredMarker = !1;
        control;
        labelId = `md-form-field-${If++}-label`;
        hintId = `${this.labelId}-hint`;
        errorId = `${this.labelId}-error`;
        focused = !1;
        element = d(x);
        cdr = d(E);
        formGroup = d(ia, { optional: !0 });
        form = d(ta, { optional: !0 });
        get invalid() { if (this.control?.disabled)
            return !1; let e = this.control?.ngControl; return this.invalidState || !!(e?.invalid && (e.touched || this.formGroup?.submitted || this.form?.submitted)); }
        get floated() { return this.focused || !!this.control?.focused || !!this.control?.alwaysFloat || !this.control?.empty; }
        get describedBy() { return this.invalid && this.error ? this.errorId : this.hint ? this.hintId : null; }
        refresh() { this.cdr.markForCheck(); }
        focusControl() { this.control?.focus(); }
        onFocusOut(e) { this.focused = this.element.nativeElement.contains(e.relatedTarget); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-form-field"]], contentQueries: function (i, o, r) { if (i & 1 && t.\u0275\u0275contentQuery(r, Ef, 5), i & 2) {
                let s;
                t.\u0275\u0275queryRefresh(s = t.\u0275\u0275loadQuery()) && (o.control = s.first);
            } }, hostAttrs: [1, "md-form-field"], hostVars: 18, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("focusin", function () { return o.focused = !0; })("focusout", function (s) { return o.onFocusOut(s); }), i & 2 && t.\u0275\u0275classProp("md-form-field-filled", o.appearance === "filled")("md-form-field-floating", o.labelPosition === "floating")("md-form-field-inside", o.labelPosition === "inside")("md-form-field-horizontal", o.labelPosition === "left")("md-form-field-floated", o.floated)("md-form-field-invalid", o.invalid)("md-form-field-disabled", o.control?.disabled)("md-form-field-readonly", o.control?.readonly)("md-form-field-focused", o.focused || o.control?.focused); }, inputs: { appearance: "appearance", labelPosition: "labelPosition", label: "label", hint: "hint", error: "error", invalidState: [2, "invalidState", "invalidState", m], hideRequiredMarker: [2, "hideRequiredMarker", "hideRequiredMarker", m] }, features: [t.\u0275\u0275ProvidersFeature([{ provide: Wa, useExisting: A(() => n) }])], ngContentSelectors: mp, decls: 13, vars: 3, consts: [[1, "md-form-field-label", 3, "id"], [1, "md-form-field-main"], [1, "md-form-field-shell"], [1, "md-form-field-prefix"], [1, "md-form-field-body"], [1, "md-form-field-suffix"], [1, "md-form-field-support"], ["aria-live", "polite", 1, "md-form-field-error", 3, "id"], [3, "id"], [1, "md-form-field-label", 3, "click", "id"], ["aria-hidden", "true"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(cp), t.\u0275\u0275conditionalCreate(0, pp, 3, 4, "label", 0), t.\u0275\u0275domElementStart(1, "div", 1)(2, "div", 2)(3, "span", 3), t.\u0275\u0275projection(4), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(5, "div", 4), t.\u0275\u0275conditionalCreate(6, gp, 3, 4, "label", 0), t.\u0275\u0275projection(7, 1), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(8, "span", 5), t.\u0275\u0275projection(9, 2), t.\u0275\u0275domElementEnd()(), t.\u0275\u0275domElementStart(10, "div", 6), t.\u0275\u0275conditionalCreate(11, fp, 2, 2, "span", 7)(12, bp, 2, 2, "span", 8), t.\u0275\u0275domElementEnd()()), i & 2 && (t.\u0275\u0275conditional(o.label && (o.labelPosition === "top" || o.labelPosition === "left") ? 0 : -1), t.\u0275\u0275advance(6), t.\u0275\u0275conditional(o.label && (o.labelPosition === "floating" || o.labelPosition === "inside") ? 6 : -1), t.\u0275\u0275advance(5), t.\u0275\u0275conditional(o.invalid && o.error ? 11 : o.hint ? 12 : -1)); }, styles: [`.md-form-field{display:block;min-width:0;color:var(--%NS%md-color-text, #30343b);font-family:var(--%NS%md-font-body, "Open Sans", sans-serif);font-size:14px;--%NS%md-field-surface: var(--%NS%md-color-surface, #fff)}.md-form-field .md-form-field-label{display:block;margin:0 0 6px;color:inherit;font-size:14px;line-height:20px;cursor:text}.md-form-field .md-form-field-main,.md-form-field .md-form-field-body{min-width:0;flex:1}.md-form-field .md-form-field-body{position:relative}.md-form-field .md-form-field-shell{display:flex;align-items:center;gap:8px;min-height:48px;padding:0 12px;border:1px solid var(--%NS%md-color-border, #929292);border-radius:var(--%NS%md-form-field-radius, 4px);background:var(--%NS%md-field-surface);box-sizing:border-box}.md-form-field .md-form-field-prefix:empty,.md-form-field .md-form-field-suffix:empty{display:none}.md-form-field .md-form-field-prefix,.md-form-field .md-form-field-suffix{display:inline-flex;align-items:center;flex-shrink:0}.md-form-field .md-form-field-control{display:block;width:100%;min-width:0;min-height:46px;box-sizing:border-box;padding:12px 0;margin:0;border:0;border-radius:0;background:transparent;color:inherit;font:inherit;line-height:22px;box-shadow:none}.md-form-field .md-form-field-control:focus{outline:none;box-shadow:none;background:transparent}.md-form-field .md-form-field-control::placeholder{color:var(--%NS%md-color-text-muted, #666)}.md-form-field textarea.md-form-field-control{resize:vertical}.md-form-field md-select.md-form-field-control{padding:0}.md-form-field md-select.md-form-field-control .mdc-select-trigger{min-height:46px;padding:0;border:0;background:transparent;box-shadow:none}.md-form-field .md-form-field-support{min-height:22px;padding:4px 12px 0;font-size:12px;line-height:18px;color:var(--%NS%md-color-text-muted, #666)}.md-form-field.md-form-field-filled{--%NS%md-field-surface: var(--%NS%md-color-surface-muted, #f1f3f4)}.md-form-field.md-form-field-filled .md-form-field-shell{border-color:transparent;border-bottom-color:var(--%NS%md-color-border, #929292);border-radius:4px 4px 0 0}.md-form-field.md-form-field-focused .md-form-field-shell{outline:2px solid var(--%NS%md-color-link, #1967d2);outline-offset:-2px}.md-form-field.md-form-field-invalid .md-form-field-shell{border-color:var(--%NS%md-color-danger, #b3261e);outline-color:var(--%NS%md-color-danger, #b3261e)}.md-form-field.md-form-field-invalid .md-form-field-error,.md-form-field.md-form-field-invalid .md-form-field-label{color:var(--%NS%md-color-danger, #b3261e)}.md-form-field.md-form-field-disabled{opacity:.55}.md-form-field.md-form-field-disabled .md-form-field-label{cursor:default}.md-form-field.md-form-field-floating .md-form-field-label,.md-form-field.md-form-field-inside .md-form-field-label{position:absolute;inset-inline-start:0;top:13px;margin:0;z-index:1;max-width:100%;pointer-events:auto;transition:top .12s,font-size .12s}.md-form-field.md-form-field-floating:not(.md-form-field-floated) .md-form-field-control::placeholder{color:transparent}.md-form-field.md-form-field-floating.md-form-field-floated:not(.md-form-field-filled) .md-form-field-label{top:-10px;font-size:12px;line-height:18px;padding:0 4px;margin-inline-start:-4px;background:var(--%NS%md-field-surface)}.md-form-field.md-form-field-inside .md-form-field-control,.md-form-field.md-form-field-floating.md-form-field-filled .md-form-field-control{padding-top:22px;padding-bottom:4px;min-height:54px}.md-form-field.md-form-field-inside md-select.md-form-field-control,.md-form-field.md-form-field-floating.md-form-field-filled md-select.md-form-field-control{padding-top:16px;padding-bottom:0}.md-form-field.md-form-field-inside .md-form-field-label,.md-form-field.md-form-field-floating.md-form-field-filled.md-form-field-floated .md-form-field-label{top:3px;font-size:11px;line-height:16px}.md-form-field.md-form-field-horizontal{display:flex;align-items:flex-start;gap:16px}.md-form-field.md-form-field-horizontal>.md-form-field-label{width:var(--%NS%md-form-field-label-width, 140px);flex-shrink:0;padding-top:13px}@media(max-width:600px){.md-form-field.md-form-field-horizontal{display:block}.md-form-field.md-form-field-horizontal>.md-form-field-label{width:auto;padding-top:0}}@media(prefers-reduced-motion:reduce){.md-form-field .md-form-field-label{transition:none}}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})(), Dx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), xn = class extends Kr {
    title = "";
    position = "right";
    size = "medium";
    showCloseButton = !0;
    closeLabel = "Close panel";
}, Nf = new k("MD_DRAWER_DATA"), Ga = new k("MD_DRAWER_CONFIG"), Pf = 0, Of = (() => {
    class n extends Fn {
        options = d(Ga);
        titleId = `md-drawer-title-${Pf++}`;
        dialog = d(Jd);
        close() { this.dialog.close(); }
        static \u0275fac = (() => { let e; return function (o) { return (e || (e = t.\u0275\u0275getInheritedFactory(n)))(o || n); }; })();
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-drawer-container"]], hostAttrs: ["tabindex", "-1", 1, "md-drawer-container"], hostVars: 7, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("role", o._config.role)("aria-modal", o._config.ariaModal)("aria-label", o._config.ariaLabel)("aria-labelledby", o._config.ariaLabelledBy || (!o._config.ariaLabel && o.options.title ? o.titleId : null))("aria-describedby", o._config.ariaDescribedBy), t.\u0275\u0275classProp("md-drawer-left", o.options.position === "left")); }, features: [t.\u0275\u0275InheritDefinitionFeature], decls: 5, vars: 2, consts: [[1, "md-drawer-header"], [3, "id"], ["type", "button", 1, "md-drawer-close"], [1, "md-drawer-body"], ["cdkPortalOutlet", ""], ["type", "button", 1, "md-drawer-close", 3, "click"], ["viewBox", "0 0 24 24", "width", "20", "height", "20", "aria-hidden", "true"], ["d", "m6 6 12 12M6 18 18 6", "fill", "none", "stroke", "currentColor", "stroke-width", "2"]], template: function (i, o) { i & 1 && (t.\u0275\u0275elementStart(0, "header", 0), t.\u0275\u0275conditionalCreate(1, _p, 2, 2, "h2", 1), t.\u0275\u0275conditionalCreate(2, vp, 3, 1, "button", 2), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(3, "div", 3), t.\u0275\u0275template(4, yp, 0, 0, "ng-template", 4), t.\u0275\u0275elementEnd()), i & 2 && (t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.options.title ? 1 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.options.showCloseButton ? 2 : -1)); }, dependencies: [Le], styles: [`.md-drawer-container{display:flex;flex-direction:column;width:100%;height:100%;min-width:0;box-sizing:border-box;overflow:hidden;outline:none;background:var(--%NS%md-color-surface, #fff);color:var(--%NS%md-color-text, #30343b);box-shadow:-8px 0 32px #0003;font-family:var(--%NS%md-font-body, "Open Sans", sans-serif);animation:md-drawer-enter-right .18s ease-out}.md-drawer-container.md-drawer-left{animation-name:md-drawer-enter-left;box-shadow:8px 0 32px #0003}.md-drawer-header{display:flex;align-items:center;gap:16px;padding:16px 24px;border-bottom:1px solid var(--%NS%md-color-border, #ddd);flex-shrink:0}.md-drawer-header h2{margin:0;font-size:20px;line-height:28px;font-weight:600;overflow-wrap:anywhere}.md-drawer-close{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:36px;height:36px;margin-inline-start:auto;border:0;border-radius:4px;background:transparent;color:inherit;cursor:pointer}.md-drawer-close:hover{background:var(--%NS%md-color-surface-hover, #eee)}.md-drawer-close:focus-visible{outline:2px solid var(--%NS%md-color-link, #1967d2);outline-offset:2px}.md-drawer-body{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;padding:24px}@keyframes md-drawer-enter-right{0%{transform:translate(100%)}to{transform:translate(0)}}@keyframes md-drawer-enter-left{0%{transform:translate(-100%)}to{transform:translate(0)}}@media(prefers-reduced-motion:reduce){.md-drawer-container{animation:none}}
`], encapsulation: 2, changeDetection: 1 });
    }
    return n;
})(), Kt = class {
    dialog;
    constructor(a) { this.dialog = a; }
    get componentInstance() { return this.dialog.componentInstance; }
    close(a) { this.dialog.close(a); }
    afterClosed() { return this.dialog.closed; }
}, Mx = (() => { class n {
    dialog = d(Rn);
    injector = d(j);
    refs = new Set;
    open(e, i = {}) { let o = _(_({}, new xn), i), r = Zt(this.injector).top("0"); o.position === "left" ? r.left("0") : r.right("0"); let s; return this.dialog.open(e, G(_({}, o), { width: o.width || { small: "320px", medium: "480px", large: "720px" }[o.size], maxWidth: o.maxWidth || "100vw", height: "100dvh", maxHeight: "100dvh", positionStrategy: r, scrollStrategy: o.scrollStrategy || Pn(this.injector), autoFocus: o.autoFocus ?? "dialog", container: { type: Of, providers: () => [{ provide: Ga, useValue: o }] }, templateContext: () => ({ drawerRef: s }), providers: l => (s = new Kt(l), [{ provide: Kt, useValue: s }, { provide: Nf, useValue: o.data }]) })), this.refs.add(s), s.afterClosed().subscribe(() => this.refs.delete(s)), s; }
    closeAll() { for (let e of [...this.refs])
        e.close(); }
    ngOnDestroy() { this.closeAll(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), Tx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [An] });
} return n; })(), Nr = (() => { class n {
    element = d(x);
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["li", "mdBreadcrumbItem", ""], ["li", 8, "breadcrumb-item"]] });
} return n; })(), Ff = (() => {
    class n {
        ariaLabel = "Breadcrumb";
        overflowLabel = "Show breadcrumb path";
        cdr = d(E);
        breadcrumb = Nd.required("breadcrumb");
        breadcrumbItems = Sn(Nr, { descendants: !0 });
        collapsed = B(!1);
        hiddenItems = B([]);
        measuring = B(!1);
        resizeObserver = null;
        contentCheckFrame = null;
        contentKey = null;
        fullRequiredWidth = 0;
        fullHiddenItems = [];
        itemCount = 0;
        ngAfterViewInit() { typeof ResizeObserver < "u" && (this.resizeObserver = new ResizeObserver(() => this.applyLayoutForCurrentWidth()), this.resizeObserver.observe(this.breadcrumb().nativeElement)), this.updateProjectedContentLayout(); }
        ngAfterContentChecked() { this.scheduleContentLayoutUpdate(); }
        ngOnDestroy() { this.cancelContentLayoutUpdate(), this.resizeObserver?.disconnect(); }
        navigateHiddenItem(e, i) { if (!i.href || i.target && i.target !== "_self" || e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey)
            return; let o = this.getItems()[i.index]?.querySelector("a"); o && (e.preventDefault(), o.click()); }
        scheduleContentLayoutUpdate() { typeof requestAnimationFrame > "u" || this.contentCheckFrame !== null || (this.contentCheckFrame = requestAnimationFrame(() => { this.contentCheckFrame = null, this.updateProjectedContentLayout(); })); }
        updateProjectedContentLayout() { let e = this.breadcrumb().nativeElement, i = this.getItems(), o = this.getContentKey(i); o !== this.contentKey && (this.contentKey = o, this.measureFullLayout(e), this.applyLayoutForCurrentWidth()); }
        applyLayoutForCurrentWidth() { let e = this.breadcrumb().nativeElement, i = this.itemCount >= 2 && this.fullRequiredWidth > e.clientWidth, o = i ? this.fullHiddenItems : []; i === this.collapsed() && this.areHiddenItemsEqual(o, this.hiddenItems()) || (this.collapsed.set(i), this.hiddenItems.set(o), this.cdr.detectChanges()); }
        getItems() { return this.breadcrumbItems().map(e => e.element.nativeElement); }
        getContentKey(e) { return e.map(i => { let o = i.querySelector("a"); return `${i.textContent?.trim() ?? ""}:${o?.href ?? ""}:${o?.target ?? ""}`; }).join("|"); }
        measureFullLayout(e) { this.measuring.set(!0), this.collapsed.set(!1), this.hiddenItems.set([]), this.cdr.detectChanges(); let i = this.getItems(); this.itemCount = i.length, this.fullRequiredWidth = Math.ceil(e.scrollWidth), this.fullHiddenItems = i.slice(0, -1).map((o, r) => this.toHiddenItem(o, r)), this.measuring.set(!1), this.cdr.detectChanges(); }
        toHiddenItem(e, i) { let o = e.querySelector("a"); return { index: i, label: e.textContent?.trim() ?? "", href: o?.href ?? null, target: o?.getAttribute("target") ?? null }; }
        areHiddenItemsEqual(e, i) { return e.length === i.length && e.every((o, r) => o.label === i[r].label && o.href === i[r].href && o.target === i[r].target); }
        cancelContentLayoutUpdate() { this.contentCheckFrame !== null && (cancelAnimationFrame(this.contentCheckFrame), this.contentCheckFrame = null); }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-breadcrumbs"]], contentQueries: function (i, o, r) { i & 1 && t.\u0275\u0275contentQuerySignal(r, o.breadcrumbItems, Nr, 5), i & 2 && t.\u0275\u0275queryAdvance(); }, viewQuery: function (i, o) { i & 1 && t.\u0275\u0275viewQuerySignal(o.breadcrumb, xp, 5), i & 2 && t.\u0275\u0275queryAdvance(); }, inputs: { ariaLabel: "ariaLabel", overflowLabel: "overflowLabel" }, ngContentSelectors: T, decls: 10, vars: 11, consts: [["breadcrumb", ""], ["breadcrumbMenu", "mdMenu"], [1, "md-breadcrumbs-list"], [1, "breadcrumb-item", "breadcrumb-overflow"], ["type", "button", 1, "breadcrumb-overflow-toggle", 3, "mdMenuTriggerFor"], [1, "breadcrumb-overflow-menu"], ["mdMenuContent", ""], ["md-menu-item", "", 1, "breadcrumb-overflow-menu-item", 3, "href"], ["md-menu-item", "", 1, "breadcrumb-overflow-menu-item"], ["md-menu-item", "", 1, "breadcrumb-overflow-menu-item", 3, "click", "href"]], template: function (i, o) { if (i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275elementStart(0, "nav")(1, "ol", 2, 0)(3, "li", 3)(4, "button", 4), t.\u0275\u0275text(5, "..."), t.\u0275\u0275elementEnd()(), t.\u0275\u0275projection(6), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(7, "md-menu", 5, 1), t.\u0275\u0275template(9, Dp, 2, 0, "ng-template", 6), t.\u0275\u0275elementEnd()()), i & 2) {
                let r = t.\u0275\u0275reference(8);
                t.\u0275\u0275attribute("aria-label", o.ariaLabel), t.\u0275\u0275advance(), t.\u0275\u0275classProp("breadcrumb-collapsed", o.collapsed())("breadcrumb-measuring", o.measuring()), t.\u0275\u0275advance(2), t.\u0275\u0275classProp("breadcrumb-overflow-hidden", !o.collapsed())("breadcrumb-first-visible", o.collapsed()), t.\u0275\u0275advance(), t.\u0275\u0275property("mdMenuTriggerFor", r), t.\u0275\u0275attribute("aria-label", o.overflowLabel);
            } }, dependencies: [ng, Ye, pt, eg, Sa], styles: [`md-breadcrumbs{display:block;min-width:0}md-breadcrumbs .md-breadcrumbs-list{display:flex;flex-wrap:nowrap;align-items:center;min-width:0;max-width:100%;margin:0;padding:0;min-height:36px;list-style:none;font:600 13px/18px var(--%NS%md-breadcrumb-font-family, Lato, Arial, sans-serif);letter-spacing:normal;color:var(--%NS%md-breadcrumb-color, #000)}md-breadcrumbs .md-breadcrumbs-list.breadcrumb-measuring{width:max-content;max-width:none}md-breadcrumbs .md-breadcrumbs-list a,md-breadcrumbs .md-breadcrumbs-list span{color:inherit;font:inherit}md-breadcrumbs .md-breadcrumbs-list a{text-decoration:none}md-breadcrumbs .md-breadcrumbs-list a[href]:hover{text-decoration:underline;text-underline-offset:3px}md-breadcrumbs .md-breadcrumbs-list>.breadcrumb-item,md-breadcrumbs .md-breadcrumbs-list>[mdBreadcrumbItem]{display:flex;align-items:center;flex:0 0 auto;min-width:0;gap:6px;padding:0;color:inherit;white-space:nowrap}md-breadcrumbs .md-breadcrumbs-list>.breadcrumb-item+li:before,md-breadcrumbs .md-breadcrumbs-list>[mdBreadcrumbItem]+li:before{content:"";display:block;width:12px;height:12px;flex:0 0 12px;margin:0 0 0 6px;padding:0;color:inherit;background:currentColor;mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='none' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round' d='M4 12h16m-6-6 6 6-6 6'/%3E%3C/svg%3E") center/contain no-repeat}md-breadcrumbs .md-breadcrumbs-list>.breadcrumb-item:last-child,md-breadcrumbs .md-breadcrumbs-list>[mdBreadcrumbItem]:last-child{flex-shrink:1;overflow:hidden;font-weight:300}md-breadcrumbs .md-breadcrumbs-list>.breadcrumb-item:last-child a,md-breadcrumbs .md-breadcrumbs-list>.breadcrumb-item:last-child span,md-breadcrumbs .md-breadcrumbs-list>[mdBreadcrumbItem]:last-child a,md-breadcrumbs .md-breadcrumbs-list>[mdBreadcrumbItem]:last-child span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}md-breadcrumbs .md-breadcrumbs-list:not(.breadcrumb-collapsed)>.breadcrumb-overflow+li:before{display:none}md-breadcrumbs .md-breadcrumbs-list.breadcrumb-measuring>li:last-child{overflow:visible}md-breadcrumbs .md-breadcrumbs-list.breadcrumb-collapsed>li:not(.breadcrumb-overflow):not(:last-child){display:none}md-breadcrumbs .md-breadcrumbs-list>.breadcrumb-overflow-hidden{display:none}md-breadcrumbs .md-breadcrumbs-list .breadcrumb-overflow-toggle{border:0;padding:0;background:transparent;color:inherit;font:inherit;font-weight:600;cursor:pointer;border-radius:4px}md-breadcrumbs .md-breadcrumbs-list a:focus-visible,md-breadcrumbs .md-breadcrumbs-list .breadcrumb-overflow-toggle:focus-visible{outline:2px solid var(--%NS%md-color-link, #1967d2);outline-offset:2px}.breadcrumb-overflow-menu .breadcrumb-overflow-menu-item{max-width:min(280px,100vw - 32px);overflow:hidden;color:var(--%NS%md-color-text, #30343b);text-overflow:ellipsis;white-space:nowrap}[dir=rtl] md-breadcrumbs .md-breadcrumbs-list>li+li:before{transform:rotate(180deg)}
`], encapsulation: 2 });
    }
    return n;
})(), Ex = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [Ff] });
} return n; })(), Ix = (() => {
    class n {
        variant = "text";
        animation = "pulse";
        width = null;
        height = null;
        borderRadius = null;
        cssSize(e) { return typeof e == "number" ? Number.isFinite(e) ? `${Math.max(0, e)}px` : null : e; }
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-skeleton"]], hostAttrs: ["aria-hidden", "true", 1, "md-skeleton"], hostVars: 8, hostBindings: function (i, o) { i & 2 && (t.\u0275\u0275attribute("data-variant", o.variant)("data-animation", o.animation), t.\u0275\u0275styleProp("width", o.cssSize(o.width))("height", o.cssSize(o.height))("border-radius", o.cssSize(o.borderRadius))); }, inputs: { variant: "variant", animation: "animation", width: "width", height: "height", borderRadius: "borderRadius" }, decls: 0, vars: 0, template: function (i, o) { }, styles: [`.md-skeleton{display:block;position:relative;overflow:hidden;isolation:isolate;box-sizing:border-box;width:100%;height:1em;border-radius:4px;background:var(--%NS%md-skeleton-background, color-mix(in srgb, var(--%NS%md-color-text, #30343b) 12%, var(--%NS%md-color-surface, #fff)));pointer-events:none;-webkit-user-select:none;user-select:none}.md-skeleton[data-variant=rectangle]{height:120px;border-radius:0}.md-skeleton[data-variant=rounded]{height:120px;border-radius:var(--%NS%md-skeleton-radius, 8px)}.md-skeleton[data-variant=circle]{width:40px;height:40px;border-radius:50%}.md-skeleton[data-animation=pulse]{animation:md-skeleton-pulse 1.6s ease-in-out infinite}.md-skeleton[data-animation=wave]:after{content:"";position:absolute;inset:0;transform:translate(-100%);background:linear-gradient(90deg,transparent,var(--%NS%md-skeleton-highlight, color-mix(in srgb, var(--%NS%md-color-surface, #fff) 65%, transparent)),transparent);animation:md-skeleton-wave 1.6s ease-in-out infinite}@keyframes md-skeleton-pulse{0%,to{opacity:1}50%{opacity:.45}}@keyframes md-skeleton-wave{to{transform:translate(100%)}}@media(prefers-reduced-motion:reduce){.md-skeleton[data-animation]{animation:none}.md-skeleton[data-animation=wave]:after{animation:none;display:none}}@media(forced-colors:active){.md-skeleton{background:Canvas;border:1px solid GrayText}}
`], encapsulation: 2 });
    }
    return n;
})(), Nx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })();
function Rf(n, a) { let e = a.split(",").map(i => i.trim().toLowerCase()).filter(Boolean); return !e.length || e.some(i => i.startsWith(".") ? n.name.toLowerCase().endsWith(i) : i.endsWith("/*") ? n.type.toLowerCase().startsWith(i.slice(0, -1)) : n.type.toLowerCase() === i); }
var Px = (() => { class n {
    compact = !1;
    files = [];
    showFiles = !0;
    filesChange = new p;
    rejected = new p;
    accept = "";
    multiple = !0;
    disabled = !1;
    maxFileSize = 0;
    maxFiles = 0;
    label = "Drop files here or click to browse";
    hint = "";
    removeLabel = "Remove file";
    errorText = e => `${e.file.name}: ${{ type: "file type is not allowed", size: "file is too large", count: "file limit reached", duplicate: "file is already selected" }[e.reason]}`;
    picker;
    errors = [];
    dragging = !1;
    dragDepth = 0;
    browse() { this.disabled || this.picker.nativeElement.click(); }
    choose(e) { let i = e.target; this.addFiles(Array.from(i.files ?? [])), i.value = ""; }
    dragEnter(e) { e.preventDefault(), !this.disabled && e.dataTransfer?.types.includes("Files") && (this.dragDepth++, this.dragging = !0); }
    dragLeave(e) { e.preventDefault(), this.dragDepth = Math.max(0, this.dragDepth - 1), this.dragDepth || (this.dragging = !1); }
    dragOver(e) { e.preventDefault(), e.dataTransfer && (e.dataTransfer.dropEffect = this.disabled ? "none" : "copy"); }
    drop(e) { e.preventDefault(), e.stopPropagation(), this.dragDepth = 0, this.dragging = !1, this.disabled || this.addFiles(Array.from(e.dataTransfer?.files ?? [])); }
    addFiles(e) { if (this.disabled)
        return; let i = this.multiple ? [...this.files] : [], o = [], r = this.multiple ? this.maxFiles > 0 ? this.maxFiles : 1 / 0 : 1, s = !1; for (let l of e) {
        let c;
        Rf(l, this.accept) ? this.maxFileSize > 0 && l.size > this.maxFileSize ? c = "size" : i.some(h => h.name === l.name && h.size === l.size && h.lastModified === l.lastModified) ? c = "duplicate" : i.length >= r && (c = "count") : c = "type", c ? o.push({ file: l, reason: c }) : (i.push(l), s = !0);
    } this.errors = o, s && (this.files = i, this.filesChange.emit(i)), o.length && this.rejected.emit(o); }
    remove(e) { this.disabled || (this.files = this.files.filter((i, o) => o !== e), this.errors = [], this.filesChange.emit(this.files)); }
    formatSize(e) { return e < 1024 ? `${e} B` : e < 1048576 ? `${(e / 1024).toFixed(1)} KB` : `${(e / 1048576).toFixed(1)} MB`; }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-dropzone"]], viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(Mp, 5), i & 2) {
            let r;
            t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.picker = r.first);
        } }, hostVars: 2, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("md-dropzone-compact", o.compact); }, inputs: { compact: [2, "compact", "compact", m], files: "files", showFiles: [2, "showFiles", "showFiles", m], accept: "accept", multiple: [2, "multiple", "multiple", m], disabled: [2, "disabled", "disabled", m], maxFileSize: "maxFileSize", maxFiles: "maxFiles", label: "label", hint: "hint", removeLabel: "removeLabel", errorText: "errorText" }, outputs: { filesChange: "filesChange", rejected: "rejected" }, decls: 12, vars: 12, consts: [["picker", ""], ["type", "file", "hidden", "", 3, "change", "accept", "multiple", "disabled"], [1, "drop-surface", 3, "dragenter", "dragleave", "dragover", "drop"], ["type", "button", 1, "browse", 3, "click", "disabled"], ["width", "32", "height", "32", "viewBox", "0 0 24 24", "aria-hidden", "true"], ["d", "M12 16V4m-4 4 4-4 4 4M4 16v4h16v-4", "fill", "none", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round"], [1, "hint"], [1, "files"], ["aria-live", "polite", "aria-atomic", "true"], [1, "errors"], [1, "filename", 3, "title"], [1, "size"], ["type", "button", 1, "remove", 3, "click", "disabled"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", "focusable", "false", 2, "display", "inline-block", "vertical-align", "middle", "flex-shrink", "0"], ["d", "M6 6l12 12M18 6 6 18"]], template: function (i, o) { i & 1 && (t.\u0275\u0275domElementStart(0, "input", 1, 0), t.\u0275\u0275domListener("change", function (s) { return o.choose(s); }), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(2, "div", 2), t.\u0275\u0275domListener("dragenter", function (s) { return o.dragEnter(s); })("dragleave", function (s) { return o.dragLeave(s); })("dragover", function (s) { return o.dragOver(s); })("drop", function (s) { return o.drop(s); }), t.\u0275\u0275domElementStart(3, "button", 3), t.\u0275\u0275domListener("click", function () { return o.browse(); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(4, "svg", 4), t.\u0275\u0275domElement(5, "path", 5), t.\u0275\u0275domElementEnd(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275domElementStart(6, "span"), t.\u0275\u0275text(7), t.\u0275\u0275domElementEnd(), t.\u0275\u0275conditionalCreate(8, Tp, 2, 1, "span", 6), t.\u0275\u0275domElementEnd()(), t.\u0275\u0275conditionalCreate(9, Ip, 3, 0, "ul", 7), t.\u0275\u0275domElementStart(10, "div", 8), t.\u0275\u0275conditionalCreate(11, Pp, 3, 0, "ul", 9), t.\u0275\u0275domElementEnd()), i & 2 && (t.\u0275\u0275domProperty("accept", o.accept)("multiple", o.multiple)("disabled", o.disabled), t.\u0275\u0275advance(2), t.\u0275\u0275classProp("dragging", o.dragging && !o.disabled)("disabled", o.disabled), t.\u0275\u0275advance(), t.\u0275\u0275domProperty("disabled", o.disabled), t.\u0275\u0275advance(4), t.\u0275\u0275textInterpolate(o.label), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.hint ? 8 : -1), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.showFiles && o.files.length ? 9 : -1), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o.errors.length ? 11 : -1)); }, styles: ['[_nghost-%COMP%]{display:block;min-width:0;color:var(--%NS%md-color-text, #30343b);font-family:var(--%NS%md-font-body, "Open Sans", sans-serif);font-size:var(--%NS%md-text-md, 14px)}.drop-surface[_ngcontent-%COMP%]{border:1px dashed var(--%NS%md-color-border, #929292);border-radius:var(--%NS%md-radius-lg, 8px);background:var(--%NS%md-color-surface, #fff)}.drop-surface[_ngcontent-%COMP%]:hover:not(.disabled), .drop-surface.dragging[_ngcontent-%COMP%]{border-color:var(--%NS%md-color-link, #1967d2);background:var(--%NS%md-color-surface-hover, #f1f3f4)}.drop-surface.dragging[_ngcontent-%COMP%]{outline:2px solid var(--%NS%md-color-link, #1967d2);outline-offset:2px}.drop-surface.disabled[_ngcontent-%COMP%]{opacity:.5}.browse[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;gap:var(--%NS%md-spacing-3, 12px);width:100%;min-height:160px;padding:var(--%NS%md-spacing-6, 24px);border:0;border-radius:inherit;background:transparent;color:inherit;font:inherit;cursor:pointer}button[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-color-link, #1967d2);outline-offset:3px}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed}.hint[_ngcontent-%COMP%], .size[_ngcontent-%COMP%]{color:var(--%NS%md-color-text-muted, #666);font-size:var(--%NS%md-text-sm, 12px)}.files[_ngcontent-%COMP%]{list-style:none;padding:0;margin:var(--%NS%md-spacing-3, 12px) 0 0}.files[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--%NS%md-spacing-3, 12px);padding:var(--%NS%md-spacing-2, 8px) 0;border-bottom:1px solid var(--%NS%md-color-border, #ddd)}.filename[_ngcontent-%COMP%]{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.size[_ngcontent-%COMP%]{flex-shrink:0}.remove[_ngcontent-%COMP%]{width:32px;height:32px;flex-shrink:0;border:0;border-radius:var(--%NS%md-radius-sm, 4px);background:transparent;color:inherit;font-size:22px;cursor:pointer}.remove[_ngcontent-%COMP%]:hover:not(:disabled){background:var(--%NS%md-color-surface-hover, #eee)}.errors[_ngcontent-%COMP%]{margin:var(--%NS%md-spacing-3, 12px) 0 0;padding-inline-start:20px;color:var(--%NS%md-color-danger, #b3261e);overflow-wrap:anywhere}button.remove[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:8px}.md-dropzone-compact[_nghost-%COMP%]   .browse[_ngcontent-%COMP%]{display:grid;grid-template-columns:24px minmax(0,1fr);min-height:56px;padding:12px;gap:4px 12px;text-align:start}.md-dropzone-compact[_nghost-%COMP%]   .browse[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:24px;height:24px;grid-column:1;grid-row:1/span 2}.md-dropzone-compact[_nghost-%COMP%]   .browse[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{grid-column:2;overflow-wrap:anywhere}.md-dropzone-compact[_nghost-%COMP%]   .browse[_ngcontent-%COMP%]:not(:has(.hint))   svg[_ngcontent-%COMP%]{grid-row:1}.md-dropzone-compact[_nghost-%COMP%]   .files[_ngcontent-%COMP%], .md-dropzone-compact[_nghost-%COMP%]   .errors[_ngcontent-%COMP%]{margin-top:6px}.md-dropzone-compact[_nghost-%COMP%]   .files[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{padding:4px 0;gap:8px}'] });
} return n; })(), Ox = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), Fx = (() => {
    class n {
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-menubar"]], hostAttrs: [1, "md-menubar"], features: [t.\u0275\u0275HostDirectivesFeature([nr])], ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275projection(0)); }, styles: [`md-menubar.md-menubar{display:flex;flex-wrap:wrap;gap:var(--%NS%md-spacing-1, 4px);padding:var(--%NS%md-spacing-1, 4px);border:1px solid var(--%NS%md-color-border, #ddd);border-radius:var(--%NS%md-radius-lg, 8px);background:var(--%NS%md-color-surface, #fff);color:var(--%NS%md-color-text, #222)}md-menubar-menu.md-menubar-menu{display:flex;flex-direction:column;min-width:220px;max-width:min(360px,100vw - 24px);max-height:calc(100vh - 32px);overflow-y:auto;padding:6px;border:1px solid var(--%NS%md-color-border, #ddd);border-radius:var(--%NS%md-radius-lg, 8px);background:var(--%NS%md-overlay-surface, var(--%NS%md-color-surface, #fff));color:var(--%NS%md-color-text, #222);box-shadow:var(--%NS%md-overlay-shadow, 0 6px 24px rgba(0, 0, 0, .1333333333))}.md-menubar,.md-menubar-menu{font-family:var(--%NS%md-font-body, inherit);font-size:var(--%NS%md-text-md, 14px)}.md-menubar .md-menubar-item,.md-menubar-menu .md-menubar-item{display:flex;align-items:center;gap:var(--%NS%md-spacing-3, 12px);position:relative;border:0;border-radius:var(--%NS%md-radius-sm, 4px);padding:var(--%NS%md-spacing-2, 8px) var(--%NS%md-spacing-3, 12px);min-height:36px;background:transparent;color:inherit;font:inherit;text-align:start;cursor:pointer}.md-menubar .md-menubar-item:hover,.md-menubar .md-menubar-item:focus-visible,.md-menubar .md-menubar-item[aria-expanded=true],.md-menubar-menu .md-menubar-item:hover,.md-menubar-menu .md-menubar-item:focus-visible,.md-menubar-menu .md-menubar-item[aria-expanded=true]{background:var(--%NS%md-color-surface-hover, #f0f0f0)}.md-menubar .md-menubar-item:focus-visible,.md-menubar-menu .md-menubar-item:focus-visible{outline:2px solid var(--%NS%md-color-link, #5265df);outline-offset:-2px}.md-menubar .md-menubar-item[aria-disabled=true],.md-menubar-menu .md-menubar-item[aria-disabled=true]{opacity:.4;cursor:default}.md-menubar .md-menubar-selectable,.md-menubar-menu .md-menubar-selectable{padding-inline-start:40px}.md-menubar .md-menubar-selectable[aria-checked=true]:before,.md-menubar-menu .md-menubar-selectable[aria-checked=true]:before{content:"";position:absolute;inset-inline-start:8px;top:50%;transform:translateY(-50%);width:24px;height:24px;background:currentColor;mask:url(data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22none%22%20stroke%3D%22black%22%20stroke-width%3D%222%22%20d%3D%22m5%2012%204%204L19%206%22/%3E%3C/svg%3E) center/contain no-repeat}.md-menubar [role=menuitemradio][aria-checked=true]:before,.md-menubar-menu [role=menuitemradio][aria-checked=true]:before{mask-image:url(data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2024%2024%22%3E%3Ccircle%20cx%3D%2212%22%20cy%3D%2212%22%20r%3D%225%22/%3E%3C/svg%3E)}.md-menubar .md-menubar-hint,.md-menubar-menu .md-menubar-hint{margin-inline-start:auto;padding-inline-start:20px;opacity:.6;font-size:var(--%NS%md-text-sm, 12px)}.md-menubar .md-menubar-label,.md-menubar-menu .md-menubar-label{display:block;padding:var(--%NS%md-spacing-2, 8px) var(--%NS%md-spacing-3, 12px) var(--%NS%md-spacing-1, 4px);font-size:var(--%NS%md-text-sm, 12px);opacity:.65}.md-menubar [role=separator],.md-menubar-menu [role=separator]{border:0;border-top:1px solid var(--%NS%md-color-border, #ddd);margin:5px 0}
`], encapsulation: 2 });
    }
    return n;
})(), Rx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-menubar-menu"]], hostAttrs: [1, "md-menubar-menu"], features: [t.\u0275\u0275HostDirectivesFeature([ir])], ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275projection(0)); }, styles: [Op], encapsulation: 2 });
} return n; })(), Ax = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdMenubarTriggerFor", ""]], features: [t.\u0275\u0275HostDirectivesFeature([{ directive: Ri, inputs: ["cdkMenuTriggerFor", "mdMenubarTriggerFor"], outputs: ["cdkMenuOpened", "menuOpened", "cdkMenuClosed", "menuClosed"] }])] });
} return n; })(), Lx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdMenubarItem", ""]], hostAttrs: [1, "md-menubar-item"], features: [t.\u0275\u0275HostDirectivesFeature([{ directive: We, inputs: ["cdkMenuItemDisabled", "disabled", "cdkMenuitemTypeaheadLabel", "typeaheadLabel"], outputs: ["cdkMenuItemTriggered", "triggered"] }])] });
} return n; })(), Bx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdMenubarCheckbox", ""]], hostAttrs: [1, "md-menubar-item", "md-menubar-selectable"], features: [t.\u0275\u0275HostDirectivesFeature([{ directive: rr, inputs: ["cdkMenuItemDisabled", "disabled", "cdkMenuItemChecked", "checked"], outputs: ["cdkMenuItemTriggered", "triggered"] }])] });
} return n; })(), zx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdMenubarRadio", ""]], hostAttrs: [1, "md-menubar-item", "md-menubar-selectable"], features: [t.\u0275\u0275HostDirectivesFeature([{ directive: or, inputs: ["cdkMenuItemDisabled", "disabled", "cdkMenuItemChecked", "checked"], outputs: ["cdkMenuItemTriggered", "triggered"] }])] });
} return n; })(), Vx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdMenubarGroup", ""]], features: [t.\u0275\u0275HostDirectivesFeature([nt])] });
} return n; })();
var Hx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })();
function st(n, a) { return Number.isFinite(n) && n >= 1 ? Math.floor(n) : a; }
function Af(n, a) { let e = st(a, 1), i = Math.min(st(n, 1), e); if (e <= 7)
    return Array.from({ length: e }, (l, c) => c + 1); let o = Math.max(2, Math.min(i - 1, e - 4)), r = Math.min(e - 1, Math.max(i + 1, 5)), s = [1]; o > 2 && s.push("start-gap"); for (let l = o; l <= r; l++)
    s.push(l); return r < e - 1 && s.push("end-gap"), s.push(e), s; }
var Lf = (() => { class n {
    page = 1;
    total = 0;
    pageSize = 10;
    pageSizeOptions = [];
    disabled = !1;
    showFirstLast = !0;
    label = "Pagination";
    pageSizeLabel = "Rows per page";
    firstLabel = "First page";
    previousLabel = "Previous page";
    nextLabel = "Next page";
    lastLabel = "Last page";
    pageLabel = e => `Page ${e}`;
    rangeLabel = (e, i, o) => `${e}\u2013${i} of ${o}`;
    pageChange = new p;
    pageSizeChange = new p;
    changed = new p;
    get count() { return Number.isFinite(this.total) ? Math.max(0, Math.floor(this.total)) : 0; }
    get size() { return st(this.pageSize, 10); }
    get pageCount() { return Math.max(1, Math.ceil(this.count / this.size)); }
    get current() { return Math.min(st(this.page, 1), this.pageCount); }
    get pages() { return Af(this.current, this.pageCount); }
    get start() { return this.count ? (this.current - 1) * this.size + 1 : 0; }
    get end() { return Math.min(this.current * this.size, this.count); }
    get sizes() { return [...new Set([this.size, ...this.pageSizeOptions.filter(e => Number.isInteger(e) && e > 0)])].sort((e, i) => e - i); }
    isPage(e) { return typeof e == "number"; }
    go(e) { if (this.disabled)
        return; let i = Math.min(st(e, 1), this.pageCount); i !== this.current && (this.page = i, this.pageChange.emit(i), this.changed.emit({ page: i, pageSize: this.size })); }
    resize(e) { if (this.disabled || !Number.isInteger(e) || e <= 0 || e === this.size)
        return; let i = Math.floor((this.current - 1) * this.size / e) + 1; this.pageSize = e, this.page = i, this.pageSizeChange.emit(e), this.pageChange.emit(i), this.changed.emit({ page: i, pageSize: e }); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-pagination"]], inputs: { page: "page", total: "total", pageSize: "pageSize", pageSizeOptions: "pageSizeOptions", disabled: [2, "disabled", "disabled", m], showFirstLast: [2, "showFirstLast", "showFirstLast", m], label: "label", pageSizeLabel: "pageSizeLabel", firstLabel: "firstLabel", previousLabel: "previousLabel", nextLabel: "nextLabel", lastLabel: "lastLabel", pageLabel: "pageLabel", rangeLabel: "rangeLabel" }, outputs: { pageChange: "pageChange", pageSizeChange: "pageSizeChange", changed: "changed" }, decls: 15, vars: 9, consts: [[1, "size-label"], ["role", "status", "aria-live", "polite", 1, "range"], [1, "pages"], ["type", "button", 3, "disabled"], ["type", "button", 3, "click", "disabled"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", "focusable", "false", 2, "display", "inline-block", "vertical-align", "middle", "flex-shrink", "0"], ["d", "m15 5-7 7 7 7"], ["d", "m9 5 7 7-7 7"], [3, "valueChange", "value", "disabled"], [3, "value"], ["d", "M5 5v14m12-14-7 7 7 7"], ["type", "button", 3, "disabled", "active"], ["aria-hidden", "true", 1, "gap"], ["d", "M5 12h.01M12 12h.01M19 12h.01"], ["d", "M19 5v14M7 5l7 7-7 7"]], template: function (i, o) { i & 1 && (t.\u0275\u0275elementStart(0, "nav"), t.\u0275\u0275conditionalCreate(1, Rp, 5, 4, "label", 0), t.\u0275\u0275elementStart(2, "span", 1), t.\u0275\u0275text(3), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(4, "div", 2), t.\u0275\u0275conditionalCreate(5, Ap, 3, 2, "button", 3), t.\u0275\u0275elementStart(6, "button", 4), t.\u0275\u0275listener("click", function () { return o.go(o.current - 1); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(7, "svg", 5), t.\u0275\u0275element(8, "path", 6), t.\u0275\u0275elementEnd()(), t.\u0275\u0275repeaterCreate(9, zp, 2, 1, null, null, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275elementStart(11, "button", 4), t.\u0275\u0275listener("click", function () { return o.go(o.current + 1); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275elementStart(12, "svg", 5), t.\u0275\u0275element(13, "path", 7), t.\u0275\u0275elementEnd()(), t.\u0275\u0275conditionalCreate(14, Vp, 3, 2, "button", 3), t.\u0275\u0275elementEnd()()), i & 2 && (t.\u0275\u0275attribute("aria-label", o.label), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.pageSizeOptions.length ? 1 : -1), t.\u0275\u0275advance(2), t.\u0275\u0275textInterpolate(o.rangeLabel(o.start, o.end, o.count)), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o.showFirstLast ? 5 : -1), t.\u0275\u0275advance(), t.\u0275\u0275property("disabled", o.disabled || o.current === 1), t.\u0275\u0275attribute("aria-label", o.previousLabel), t.\u0275\u0275advance(3), t.\u0275\u0275repeater(o.pages), t.\u0275\u0275advance(2), t.\u0275\u0275property("disabled", o.disabled || o.current === o.pageCount), t.\u0275\u0275attribute("aria-label", o.nextLabel), t.\u0275\u0275advance(3), t.\u0275\u0275conditional(o.showFirstLast ? 14 : -1)); }, dependencies: [ag, qn, Jt], styles: ["[_nghost-%COMP%]{display:block;color:var(--%NS%md-color-text, #222)}nav[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;align-items:center;gap:var(--%NS%md-spacing-4, 16px);font-size:var(--%NS%md-text-md, 14px)}.pages[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;align-items:center;gap:var(--%NS%md-spacing-1, 4px)}button[_ngcontent-%COMP%], .gap[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px}button[_ngcontent-%COMP%]{padding:0 var(--%NS%md-spacing-2, 8px);background:transparent;color:inherit;border:1px solid var(--%NS%md-color-border, #ddd);border-radius:6px;font:inherit;cursor:pointer}button[_ngcontent-%COMP%]:hover:not(:disabled){background:var(--%NS%md-color-surface-hover, #f0f0f0)}button.active[_ngcontent-%COMP%]{color:var(--%NS%md-color-link, #5265df);border-color:currentColor;font-weight:600}button[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-color-link, #5265df);outline-offset:2px}button[_ngcontent-%COMP%]:disabled{opacity:.4;cursor:default}.range[_ngcontent-%COMP%]{white-space:nowrap;font-variant-numeric:tabular-nums}.size-label[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--%NS%md-spacing-3, 12px);margin:0}md-select[_ngcontent-%COMP%]{width:76px}button[_ngcontent-%COMP%], .gap[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:8px}"] });
} return n; })(), jx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [Lf] });
} return n; })(), Wx = (() => { class n {
    items = [];
    disabled = !1;
    label = "Uploads";
    emptyLabel = "No files to upload";
    cancelLabel = "Cancel";
    retryLabel = "Retry";
    removeLabel = "Remove";
    statusLabel = e => ({ queued: "Waiting", uploading: "Uploading", success: "Uploaded", error: "Upload failed", cancelled: "Cancelled" })[e.status];
    cancel = new p;
    retry = new p;
    remove = new p;
    progress(e) { return typeof e.progress == "number" && Number.isFinite(e.progress) ? Math.min(100, Math.max(0, e.progress)) : null; }
    formatSize(e) { return !Number.isFinite(e) || e < 0 ? "" : e < 1024 ? `${e} B` : e < 1048576 ? `${(e / 1024).toFixed(1)} KB` : `${(e / 1048576).toFixed(1)} MB`; }
    action(e, i) { if (this.disabled)
        return; let o = i.status === "queued" || i.status === "uploading"; (e === "cancel" && o || e === "remove" && !o || e === "retry" && (i.status === "error" || i.status === "cancelled")) && this[e].emit(i); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-upload-list"]], inputs: { items: "items", disabled: [2, "disabled", "disabled", m], label: "label", emptyLabel: "emptyLabel", cancelLabel: "cancelLabel", retryLabel: "retryLabel", removeLabel: "removeLabel", statusLabel: "statusLabel" }, outputs: { cancel: "cancel", retry: "retry", remove: "remove" }, decls: 4, vars: 2, consts: [[3, "error"], [1, "empty"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "aria-hidden", "true", 1, "file-icon"], ["d", "M14 3H5v18h14V8Zm0 0v5h5M8 13h8M8 17h6", "fill", "none", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linejoin", "round"], [1, "details"], [1, "heading"], [1, "name", 3, "title"], [1, "size"], ["aria-live", "polite", 1, "status"], [1, "progress-row"], [1, "error-text"], [1, "actions"], ["type", "button", 3, "disabled"], ["max", "100"], [1, "percent"], ["type", "button", 3, "click", "disabled"]], template: function (i, o) { i & 1 && (t.\u0275\u0275domElementStart(0, "ul"), t.\u0275\u0275repeaterCreate(1, Qp, 15, 9, "li", 0, ua, !1, Kp, 2, 1, "li", 1), t.\u0275\u0275domElementEnd()), i & 2 && (t.\u0275\u0275attribute("aria-label", o.label), t.\u0275\u0275advance(), t.\u0275\u0275repeater(o.items)); }, styles: ["[_nghost-%COMP%]{display:block;color:var(--%NS%md-color-text, #222)}ul[_ngcontent-%COMP%]{list-style:none;padding:0;margin:0;display:grid;gap:10px}li[_ngcontent-%COMP%]{display:flex;align-items:flex-start;flex-wrap:wrap;gap:var(--%NS%md-spacing-3, 12px);padding:14px;border:1px solid var(--%NS%md-color-border, #ddd);border-radius:var(--%NS%md-radius-lg, 8px);background:var(--%NS%md-color-surface, #fff)}.file-icon[_ngcontent-%COMP%]{flex:0 0 auto;opacity:.65}.details[_ngcontent-%COMP%]{flex:1 1 140px;min-width:0}.heading[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:var(--%NS%md-spacing-1, 4px) var(--%NS%md-spacing-3, 12px);align-items:baseline}.name[_ngcontent-%COMP%]{overflow-wrap:anywhere;font-size:var(--%NS%md-text-md, 14px);font-weight:500}.size[_ngcontent-%COMP%], .status[_ngcontent-%COMP%]{font-size:var(--%NS%md-text-sm, 12px);opacity:.65}.size[_ngcontent-%COMP%]{white-space:nowrap}.status[_ngcontent-%COMP%], .error-text[_ngcontent-%COMP%]{display:block;margin-top:var(--%NS%md-spacing-1, 4px)}.progress-row[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;margin-top:var(--%NS%md-spacing-2, 8px)}progress[_ngcontent-%COMP%]{width:100%;min-width:0;height:6px;accent-color:var(--%NS%md-color-link, #5265df)}.percent[_ngcontent-%COMP%]{font-size:var(--%NS%md-text-sm, 12px);min-width:34px;font-variant-numeric:tabular-nums}.error-text[_ngcontent-%COMP%]{color:var(--%NS%md-color-danger, #c62828);font-size:var(--%NS%md-text-sm, 12px)}.actions[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:6px}button[_ngcontent-%COMP%]{border:1px solid var(--%NS%md-color-border, #ddd);border-radius:5px;background:transparent;color:inherit;padding:6px 10px;font:inherit;font-size:var(--%NS%md-text-sm, 12px);cursor:pointer}button[_ngcontent-%COMP%]:hover:not(:disabled){background:var(--%NS%md-color-surface-hover, #f0f0f0)}button[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-color-link, #5265df);outline-offset:2px}button[_ngcontent-%COMP%]:disabled{opacity:.4;cursor:default}.empty[_ngcontent-%COMP%]{justify-content:center;font-size:var(--%NS%md-text-md, 14px);opacity:.65}"] });
} return n; })(), Gx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), $x = (() => { class n {
    heading = "Nothing here yet";
    description = "";
    icon = "empty";
    compact = !1;
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-empty-state"]], hostVars: 2, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("compact", o.compact); }, inputs: { heading: "heading", description: "description", icon: "icon", compact: [2, "compact", "compact", m] }, ngContentSelectors: Xp, decls: 9, vars: 2, consts: [[1, "content"], [1, "illustration"], [1, "actions"], ["width", "48", "height", "48", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "1.3", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true"], ["d", "m3 8 9-5 9 5v10l-9 4-9-4Zm0 0 9 5 9-5M12 13v9M7.5 5.5l9 5"], ["cx", "10.5", "cy", "10.5", "r", "6.5"], ["d", "m16 16 5 5M8 10.5h5"], ["cx", "12", "cy", "12", "r", "9"], ["d", "M12 7v6m0 4h.01"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(Up), t.\u0275\u0275domElementStart(0, "div", 0)(1, "div", 1), t.\u0275\u0275projection(2, 0, null, iu, 1, 1), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(4, "h3"), t.\u0275\u0275text(5), t.\u0275\u0275domElementEnd(), t.\u0275\u0275conditionalCreate(6, nu, 2, 1, "p"), t.\u0275\u0275domElementStart(7, "div", 2), t.\u0275\u0275projection(8, 1), t.\u0275\u0275domElementEnd()()), i & 2 && (t.\u0275\u0275advance(5), t.\u0275\u0275textInterpolate(o.heading), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.description ? 6 : -1)); }, styles: ["[_nghost-%COMP%]{display:block;color:var(--%NS%md-color-text, #222)}.content[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;text-align:center;padding:var(--%NS%md-spacing-10, 40px) var(--%NS%md-spacing-6, 24px)}.illustration[_ngcontent-%COMP%]{color:var(--%NS%md-color-link, #6d5cae);margin-bottom:var(--%NS%md-spacing-5, 20px)}.illustration[_ngcontent-%COMP%]:empty, .actions[_ngcontent-%COMP%]:empty{display:none}h3[_ngcontent-%COMP%]{margin:0;font-size:var(--%NS%md-text-title, 20px);font-weight:600;line-height:1.4;overflow-wrap:anywhere}p[_ngcontent-%COMP%]{margin:10px 0 0;max-width:420px;font-size:var(--%NS%md-text-md, 14px);line-height:1.6;opacity:.7;overflow-wrap:anywhere}.actions[_ngcontent-%COMP%]{display:flex;justify-content:center;flex-wrap:wrap;gap:10px;margin-top:var(--%NS%md-spacing-6, 24px)}.compact[_nghost-%COMP%]   .content[_ngcontent-%COMP%]{padding:var(--%NS%md-spacing-5, 20px) var(--%NS%md-spacing-4, 16px)}.compact[_nghost-%COMP%]   .illustration[_ngcontent-%COMP%]{margin-bottom:var(--%NS%md-spacing-3, 12px)}.compact[_nghost-%COMP%]   h3[_ngcontent-%COMP%]{font-size:var(--%NS%md-text-lg, 16px)}.compact[_nghost-%COMP%]   .actions[_ngcontent-%COMP%]{margin-top:var(--%NS%md-spacing-4, 16px)}"] });
} return n; })(), Yx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), qx = (() => { class n {
    label = "Details";
    template;
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-popover"]], viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(H, 7), i & 2) {
            let r;
            t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.template = r.first);
        } }, inputs: { label: "label" }, exportAs: ["mdPopover"], ngContentSelectors: T, decls: 1, vars: 0, consts: [["role", "dialog", "tabindex", "-1", 1, "panel"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domTemplate(0, ou, 2, 1, "ng-template")); }, styles: [".panel[_ngcontent-%COMP%]{box-sizing:border-box;width:max-content;max-width:min(360px,100vw - 24px);max-height:calc(100vh - 24px);overflow:auto;padding:var(--%NS%md-spacing-5, 20px);border:1px solid var(--%NS%md-color-border, #ddd);border-radius:10px;color:var(--%NS%md-color-text, #222);background:var(--%NS%md-overlay-surface, var(--%NS%md-color-surface, #fff));box-shadow:var(--%NS%md-overlay-shadow, 0 8px 28px rgba(0, 0, 0, .2));font-size:var(--%NS%md-text-md, 14px)}.panel[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-color-link, #6d5cae);outline-offset:2px}"] });
} return n; })(), Qx = (() => { class n {
    overlay = d(yt);
    cdr = d(E);
    element = d(x);
    view = d(ge);
    ref;
    subscriptions = new F;
    mdPopoverTriggerFor;
    popoverDisabled = !1;
    opened = new p;
    closed = new p;
    isOpen = !1;
    panelId = "";
    toggle() { this.isOpen ? this.close() : this.open(); }
    open() { if (this.isOpen || this.popoverDisabled || !this.mdPopoverTriggerFor)
        return; let e = this.overlay.position().flexibleConnectedTo(this.element).withPush(!0).withViewportMargin(12).withPositions([{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top", offsetY: 8 }, { originX: "end", originY: "bottom", overlayX: "end", overlayY: "top", offsetY: 8 }, { originX: "start", originY: "top", overlayX: "start", overlayY: "bottom", offsetY: -8 }]); this.ref = this.overlay.create({ positionStrategy: e, scrollStrategy: this.overlay.scrollStrategies.reposition() }), this.panelId = this.ref.overlayElement.id, this.ref.attach(new xe(this.mdPopoverTriggerFor.template, this.view)), this.isOpen = !0, this.subscriptions.add(this.ref.outsidePointerEvents().subscribe(o => { this.element.nativeElement.contains(o.target) || this.close(!1); })), this.subscriptions.add(this.ref.keydownEvents().subscribe(o => { if (o.key === "Escape" && (o.preventDefault(), o.stopPropagation(), this.close()), o.key === "Tab") {
        let r = this.ref?.overlayElement.querySelectorAll('button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex="0"]'), s = this.element.nativeElement.ownerDocument.activeElement;
        (!r?.length || !o.shiftKey && s === r[r.length - 1] || o.shiftKey && s === r[0]) && (o.preventDefault(), this.close());
    } })); let i = this.ref.overlayElement.querySelector('[role="dialog"]'); (i?.querySelector("[cdkFocusInitial], button:not([disabled]), input:not([disabled]), a[href]") ?? i)?.focus(), this.opened.emit(); }
    close(e = !0) { this.isOpen && (this.isOpen = !1, this.cdr.markForCheck(), this.subscriptions.unsubscribe(), this.subscriptions = new F, this.ref?.dispose(), this.ref = void 0, e && this.element.nativeElement.focus(), this.closed.emit()); }
    ngOnDestroy() { this.close(!1); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdPopoverTriggerFor", ""]], hostVars: 3, hostBindings: function (i, o) { i & 1 && t.\u0275\u0275listener("click", function () { return o.toggle(); }), i & 2 && t.\u0275\u0275attribute("aria-haspopup", "dialog")("aria-expanded", o.isOpen)("aria-controls", o.isOpen ? o.panelId : null); }, inputs: { mdPopoverTriggerFor: "mdPopoverTriggerFor", popoverDisabled: [2, "popoverDisabled", "popoverDisabled", m] }, outputs: { opened: "opened", closed: "closed" }, exportAs: ["mdPopoverTrigger"] });
} return n; })(), Kx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), Ux = (() => { class n {
    element = d(x);
    orientation = "horizontal";
    size = 40;
    min = 15;
    max = 85;
    step = 2;
    separatorLabel = "Resize panels";
    disabled = !1;
    sizeChange = new p;
    resizeEnd = new p;
    resizing = !1;
    pointer = null;
    get lower() { return Number.isFinite(this.min) ? Math.max(0, Math.min(100, this.min)) : 15; }
    get upper() { return Math.max(this.lower, Number.isFinite(this.max) ? Math.min(100, Math.max(0, this.max)) : 85); }
    get value() { return Math.min(this.upper, Math.max(this.lower, Number.isFinite(this.size) ? this.size : 40)); }
    setSize(e) { let i = Math.round(Math.min(this.upper, Math.max(this.lower, e)) * 10) / 10; i !== this.value && (this.size = i, this.sizeChange.emit(i)); }
    start(e) { if (this.disabled || e.button !== 0 || this.pointer !== null)
        return; e.preventDefault(); let i = e.currentTarget; i.focus(), i.setPointerCapture(e.pointerId), this.pointer = e.pointerId, this.resizing = !0; }
    move(e) { if (this.pointer !== e.pointerId || this.disabled)
        return; let i = this.element.nativeElement.getBoundingClientRect(), o = this.orientation === "vertical", r = (o ? i.height : i.width) - 12; if (r <= 0)
        return; let s = !o && getComputedStyle(this.element.nativeElement).direction === "rtl", l = o ? e.clientY - i.top : s ? i.right - e.clientX : e.clientX - i.left; this.setSize((l - 6) / r * 100); }
    end(e) { if (this.pointer !== e.pointerId)
        return; this.pointer = null, this.resizing = !1; let i = e.currentTarget; i.hasPointerCapture(e.pointerId) && i.releasePointerCapture(e.pointerId), this.resizeEnd.emit(this.value); }
    key(e) { if (this.disabled)
        return; let i = this.orientation === "vertical", o = !i && getComputedStyle(this.element.nativeElement).direction === "rtl", r = Number.isFinite(this.step) && this.step > 0 ? this.step : 2, s = this.value; switch (e.key) {
        case "Home":
            s = this.lower;
            break;
        case "End":
            s = this.upper;
            break;
        case "ArrowLeft":
            if (i)
                return;
            s += o ? r : -r;
            break;
        case "ArrowRight":
            if (i)
                return;
            s += o ? -r : r;
            break;
        case "ArrowUp":
            if (!i)
                return;
            s -= r;
            break;
        case "ArrowDown":
            if (!i)
                return;
            s += r;
            break;
        default: return;
    } e.preventDefault(), this.setSize(s), this.resizeEnd.emit(this.value); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-split-pane"]], hostVars: 4, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275classProp("vertical", o.orientation === "vertical")("resizing", o.resizing); }, inputs: { orientation: "orientation", size: "size", min: "min", max: "max", step: "step", separatorLabel: "separatorLabel", disabled: [2, "disabled", "disabled", m] }, outputs: { sizeChange: "sizeChange", resizeEnd: "resizeEnd" }, ngContentSelectors: au, decls: 6, vars: 12, consts: [[1, "pane"], ["role", "separator", 1, "separator", 3, "pointerdown", "pointermove", "pointerup", "pointercancel", "lostpointercapture", "keydown"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(ru), t.\u0275\u0275domElementStart(0, "div", 0), t.\u0275\u0275projection(1), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(2, "div", 1), t.\u0275\u0275domListener("pointerdown", function (s) { return o.start(s); })("pointermove", function (s) { return o.move(s); })("pointerup", function (s) { return o.end(s); })("pointercancel", function (s) { return o.end(s); })("lostpointercapture", function (s) { return o.end(s); })("keydown", function (s) { return o.key(s); }), t.\u0275\u0275domElement(3, "span"), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(4, "div", 0), t.\u0275\u0275projection(5, 1), t.\u0275\u0275domElementEnd()), i & 2 && (t.\u0275\u0275styleProp("flex-grow", o.value), t.\u0275\u0275advance(2), t.\u0275\u0275attribute("tabindex", o.disabled ? -1 : 0)("aria-disabled", o.disabled)("aria-label", o.separatorLabel)("aria-orientation", o.orientation === "vertical" ? "horizontal" : "vertical")("aria-valuemin", o.lower)("aria-valuemax", o.upper)("aria-valuenow", o.value)("aria-valuetext", o.value + "%"), t.\u0275\u0275advance(2), t.\u0275\u0275styleProp("flex-grow", 100 - o.value)); }, styles: ["[_nghost-%COMP%]{display:flex;width:100%;height:100%;min-width:0;min-height:0;overflow:hidden}.pane[_ngcontent-%COMP%]{flex-basis:0;min-width:0;min-height:0;overflow:auto}.separator[_ngcontent-%COMP%]{flex:0 0 12px;display:flex;align-items:center;justify-content:center;cursor:col-resize;touch-action:none;-webkit-user-select:none;user-select:none;background:var(--%NS%md-color-surface-hover, #f0f0f0)}.separator[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{width:3px;height:32px;border-radius:3px;background:var(--%NS%md-color-border, #bbb)}.separator[_ngcontent-%COMP%]:hover   span[_ngcontent-%COMP%], .separator[_ngcontent-%COMP%]:focus-visible   span[_ngcontent-%COMP%]{background:var(--%NS%md-color-link, #6d5cae)}.separator[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-color-link, #6d5cae);outline-offset:-2px}.separator[aria-disabled=true][_ngcontent-%COMP%]{cursor:default;opacity:.45}.vertical[_nghost-%COMP%]{flex-direction:column}.vertical[_nghost-%COMP%]   .separator[_ngcontent-%COMP%]{cursor:row-resize}.vertical[_nghost-%COMP%]   .separator[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{width:32px;height:3px}.resizing[_nghost-%COMP%]{-webkit-user-select:none;user-select:none}.resizing[_nghost-%COMP%]   .pane[_ngcontent-%COMP%]{pointer-events:none}"] });
} return n; })(), Xx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), Bf = 0, Zx = (() => { class n {
    cdr = d(E);
    document = d(ve);
    options = [];
    value = [];
    label = "Select options";
    placeholder = "Search\u2026";
    emptyLabel = "No matching options";
    removeLabel = "Remove";
    clearLabel = "Clear selection";
    disabled = !1;
    valueChange = new p;
    id = `md-combobox-${Bf++}`;
    query = "";
    open = !1;
    active = -1;
    onChange = () => { };
    onTouched = () => { };
    get filtered() { let e = this.query.trim().toLocaleLowerCase(); return this.options.filter(i => i.label.toLocaleLowerCase().includes(e)); }
    get activeId() { return this.open && this.filtered[this.active] ? `${this.id}-option-${this.active}` : null; }
    labelFor(e) { return this.options.find(i => i.value === e)?.label ?? e; }
    show() { this.disabled || (this.open = !0, this.active = this.filtered.findIndex(e => !e.disabled)); }
    search(e) { this.query = e.target.value, this.show(); }
    close() { this.open = !1, this.active = -1; }
    change(e) { this.disabled || (this.value = [...new Set(e)], this.valueChange.emit(this.value), this.onChange(this.value)); }
    toggle(e) { e.disabled || this.disabled || this.change(this.value.includes(e.value) ? this.value.filter(i => i !== e.value) : [...this.value, e.value]); }
    remove(e) { this.change(this.value.filter(i => i !== e)); }
    key(e) { if (this.disabled)
        return; if (e.key === "Escape") {
        this.open && (e.preventDefault(), e.stopPropagation(), this.close());
        return;
    } if (e.key === "Tab") {
        this.close();
        return;
    } if (e.key === "Enter") {
        e.preventDefault(), this.open ? this.filtered[this.active] && this.toggle(this.filtered[this.active]) : this.show();
        return;
    } if (!["ArrowDown", "ArrowUp"].includes(e.key))
        return; if (e.preventDefault(), !this.open) {
        this.show();
        return;
    } let i = this.filtered; if (!i.length)
        return; let o = e.key === "ArrowDown" ? 1 : -1; for (let r = 0; r < i.length && (this.active = (this.active + o + i.length) % i.length, !!i[this.active].disabled); r++)
        ; this.document.getElementById(`${this.id}-option-${this.active}`)?.scrollIntoView({ block: "nearest" }); }
    blur(e) { e.currentTarget.contains(e.relatedTarget) || (this.onTouched(), this.close()); }
    writeValue(e) { this.value = Array.isArray(e) ? [...e] : [], this.cdr.markForCheck(); }
    registerOnChange(e) { this.onChange = e; }
    registerOnTouched(e) { this.onTouched = e; }
    setDisabledState(e) { this.disabled = e, e && this.close(), this.cdr.markForCheck(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-combobox"]], inputs: { options: "options", value: "value", label: "label", placeholder: "placeholder", emptyLabel: "emptyLabel", removeLabel: "removeLabel", clearLabel: "clearLabel", disabled: [2, "disabled", "disabled", m] }, outputs: { valueChange: "valueChange" }, features: [t.\u0275\u0275ProvidersFeature([{ provide: J, useExisting: A(() => n), multi: !0 }])], decls: 10, vars: 16, consts: [["origin", "cdkOverlayOrigin"], [3, "focusout"], [3, "for"], ["cdkOverlayOrigin", "", 1, "control"], [1, "chip"], ["type", "text", "role", "combobox", "autocomplete", "off", "aria-autocomplete", "list", "aria-haspopup", "listbox", 3, "input", "click", "keydown", "id", "placeholder", "disabled", "value"], ["type", "button", 1, "clear", 3, "disabled"], ["cdkConnectedOverlay", "", 3, "overlayOutsideClick", "detach", "cdkConnectedOverlayOrigin", "cdkConnectedOverlayOpen", "cdkConnectedOverlayWidth", "cdkConnectedOverlayPush"], ["type", "button", 3, "click", "disabled"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", "focusable", "false", 2, "display", "inline-block", "vertical-align", "middle", "flex-shrink", "0"], ["d", "M6 6l12 12M18 6 6 18"], ["type", "button", 1, "clear", 3, "click", "disabled"], ["role", "listbox", "aria-multiselectable", "true", 1, "panel", 3, "pointerdown", "id"], ["role", "option", 3, "id", "active"], ["role", "status"], ["role", "option", 3, "click", "id"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "aria-hidden", "true", "focusable", "false", 2, "display", "block", "flex-shrink", "0"], ["x", "3", "y", "3", "width", "18", "height", "18", "rx", "4"], ["d", "m7 12 3 3 7-7"]], template: function (i, o) { if (i & 1 && (t.\u0275\u0275elementStart(0, "div", 1), t.\u0275\u0275listener("focusout", function (s) { return o.blur(s); }), t.\u0275\u0275elementStart(1, "label", 2), t.\u0275\u0275text(2), t.\u0275\u0275elementEnd(), t.\u0275\u0275elementStart(3, "div", 3, 0), t.\u0275\u0275repeaterCreate(5, su, 5, 3, "span", 4, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275elementStart(7, "input", 5), t.\u0275\u0275listener("input", function (s) { return o.search(s); })("click", function () { return o.show(); })("keydown", function (s) { return o.key(s); }), t.\u0275\u0275elementEnd(), t.\u0275\u0275conditionalCreate(8, du, 3, 2, "button", 6), t.\u0275\u0275elementEnd()(), t.\u0275\u0275template(9, hu, 4, 3, "ng-template", 7), t.\u0275\u0275listener("overlayOutsideClick", function () { return o.close(); })("detach", function () { return o.close(); })), i & 2) {
            let r = t.\u0275\u0275reference(4);
            t.\u0275\u0275advance(), t.\u0275\u0275property("for", o.id), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(o.label), t.\u0275\u0275advance(), t.\u0275\u0275classProp("disabled", o.disabled), t.\u0275\u0275advance(2), t.\u0275\u0275repeater(o.value), t.\u0275\u0275advance(2), t.\u0275\u0275property("id", o.id)("placeholder", o.placeholder)("disabled", o.disabled)("value", o.query), t.\u0275\u0275attribute("aria-expanded", o.open)("aria-controls", o.open ? o.id + "-list" : null)("aria-activedescendant", o.activeId), t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.value.length ? 8 : -1), t.\u0275\u0275advance(), t.\u0275\u0275property("cdkConnectedOverlayOrigin", r)("cdkConnectedOverlayOpen", o.open && !o.disabled)("cdkConnectedOverlayWidth", r.elementRef.nativeElement.getBoundingClientRect().width)("cdkConnectedOverlayPush", !0);
        } }, dependencies: [ct, Zd], styles: ["[_nghost-%COMP%]{display:block}label[_ngcontent-%COMP%]{display:block;margin-bottom:var(--%NS%md-spacing-2, 8px)}.control[_ngcontent-%COMP%]{display:flex;align-items:center;flex-wrap:wrap;gap:var(--%NS%md-spacing-2, 8px);border:1px solid var(--%NS%md-color-border, #bbb);border-radius:var(--%NS%md-radius-lg, 8px);padding:var(--%NS%md-spacing-2, 8px);background:var(--%NS%md-color-surface, white);color:var(--%NS%md-color-text, #222)}.control[_ngcontent-%COMP%]:focus-within{outline:2px solid var(--%NS%md-color-focus, #6d5cae)}input[_ngcontent-%COMP%]{flex:1 1 100px;min-width:60px;width:100%;border:0;background:transparent;color:inherit;padding:6px;font:inherit;outline:none}.chip[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:4px;background:var(--%NS%md-color-surface-selected, #eee);border-radius:var(--%NS%md-radius-sm, 4px);padding-inline-start:8px;font-size:14px}button[_ngcontent-%COMP%]{border:0;background:transparent;color:inherit;cursor:pointer;min-width:28px;min-height:28px;font-size:18px}button[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-color-focus, #6d5cae)}.disabled[_ngcontent-%COMP%]{opacity:.5}.panel[_ngcontent-%COMP%]{width:100%;box-sizing:border-box;max-height:280px;overflow:auto;margin-top:4px;padding:4px;border:1px solid var(--%NS%md-color-border, #bbb);border-radius:var(--%NS%md-radius-lg, 8px);background:var(--%NS%md-overlay-surface, white);color:var(--%NS%md-color-text, #222);box-shadow:var(--%NS%md-overlay-shadow, 0 4px 16px rgba(0, 0, 0, .1333333333))}[role=option][_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:10px 12px;cursor:pointer}[role=option][_ngcontent-%COMP%]:hover, [role=option].active[_ngcontent-%COMP%]{background:var(--%NS%md-color-surface-hover, #eee)}[aria-disabled=true][_ngcontent-%COMP%]{opacity:.45;cursor:default}p[_ngcontent-%COMP%]{padding:12px;margin:0}button[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:8px}"] });
} return n; })(), Jx = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), ek = (() => { class n {
    cdr = d(E);
    items = [];
    value = [];
    disabled = !1;
    availableLabel = "Available";
    selectedLabel = "Selected";
    searchLabel = "Search";
    selectAllLabel = "Select visible items";
    addLabel = "Move to selected";
    removeLabel = "Move to available";
    emptyLabel = "No items";
    announcement = (e, i) => `${e} items moved to ${i}`;
    valueChange = new p;
    sides = [!1, !0];
    queries = ["", ""];
    checked = new Set;
    message = "";
    onChange = () => { };
    onTouched = () => { };
    title(e) { return e ? this.selectedLabel : this.availableLabel; }
    list(e) { let i = this.queries[Number(e)].trim().toLocaleLowerCase(); return this.items.filter(o => this.value.includes(o.value) === e && o.label.toLocaleLowerCase().includes(i)); }
    eligible(e) { return this.list(e).filter(i => !i.disabled); }
    marked(e) { return this.eligible(e).filter(i => this.checked.has(i.value)); }
    all(e) { return this.eligible(e).length > 0 && this.marked(e).length === this.eligible(e).length; }
    partial(e) { return this.marked(e).length > 0 && !this.all(e); }
    search(e, i) { this.queries[Number(e)] = i.target.value; }
    check(e) { this.disabled || e.disabled || (this.checked.has(e.value) ? this.checked.delete(e.value) : this.checked.add(e.value), this.onTouched()); }
    checkAll(e) { if (this.disabled)
        return; let i = this.all(e); for (let o of this.eligible(e))
        i ? this.checked.delete(o.value) : this.checked.add(o.value); this.onTouched(); }
    move(e) { if (this.disabled)
        return; let i = this.marked(e).map(o => o.value); i.length && (this.value = e ? this.value.filter(o => !i.includes(o)) : [...new Set([...this.value, ...i])], i.forEach(o => this.checked.delete(o)), this.message = this.announcement(i.length, this.title(!e)), this.valueChange.emit([...this.value]), this.onChange([...this.value]), this.onTouched()); }
    writeValue(e) { this.value = Array.isArray(e) ? [...new Set(e)] : [], this.checked.clear(), this.cdr.markForCheck(); }
    registerOnChange(e) { this.onChange = e; }
    registerOnTouched(e) { this.onTouched = e; }
    setDisabledState(e) { this.disabled = e, this.cdr.markForCheck(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-transfer-list"]], inputs: { items: "items", value: "value", disabled: [2, "disabled", "disabled", m], availableLabel: "availableLabel", selectedLabel: "selectedLabel", searchLabel: "searchLabel", selectAllLabel: "selectAllLabel", addLabel: "addLabel", removeLabel: "removeLabel", emptyLabel: "emptyLabel", announcement: "announcement" }, outputs: { valueChange: "valueChange" }, features: [t.\u0275\u0275ProvidersFeature([{ provide: J, useExisting: A(() => n), multi: !0 }])], decls: 5, vars: 1, consts: [[1, "transfer"], ["role", "status", "aria-live", "polite", 1, "status"], [1, "actions"], [3, "disabled"], [1, "search"], ["type", "search", 3, "input", "value"], [1, "select-all"], ["type", "checkbox", 3, "change", "checked", "indeterminate", "disabled"], [1, "empty"], ["type", "button", 3, "click", "disabled"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", "focusable", "false", 2, "display", "inline-block", "vertical-align", "middle", "flex-shrink", "0"], ["d", "M4 12h16m-7-7 7 7-7 7"], ["d", "M20 12H4m7-7-7 7 7 7"], ["type", "checkbox", 3, "change", "checked", "disabled"]], template: function (i, o) { i & 1 && (t.\u0275\u0275domElementStart(0, "div", 0), t.\u0275\u0275repeaterCreate(1, fu, 14, 12, null, null, t.\u0275\u0275repeaterTrackByIdentity), t.\u0275\u0275domElementEnd(), t.\u0275\u0275domElementStart(3, "p", 1), t.\u0275\u0275text(4), t.\u0275\u0275domElementEnd()), i & 2 && (t.\u0275\u0275advance(), t.\u0275\u0275repeater(o.sides), t.\u0275\u0275advance(3), t.\u0275\u0275textInterpolate(o.message)); }, styles: ["[_nghost-%COMP%]{display:block;color:var(--%NS%md-color-text, #222)}.transfer[_ngcontent-%COMP%]{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);gap:var(--%NS%md-spacing-4, 16px);align-items:center}fieldset[_ngcontent-%COMP%]{min-width:0;padding:var(--%NS%md-spacing-4, 16px);border:1px solid var(--%NS%md-color-border, #bbb);border-radius:var(--%NS%md-radius-lg, 8px);background:var(--%NS%md-color-surface, #fff)}legend[_ngcontent-%COMP%]{float:none;width:auto;font-size:16px;padding:0 6px;margin:0}label[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;font-size:14px}.search[_ngcontent-%COMP%]{flex-direction:column;align-items:stretch;gap:4px;margin:8px 0 12px}input[type=search][_ngcontent-%COMP%]{width:100%;min-width:0;padding:8px;border:1px solid var(--%NS%md-color-border, #bbb);border-radius:4px;color:inherit;background:transparent;font:inherit}input[type=checkbox][_ngcontent-%COMP%]{accent-color:var(--%NS%md-color-link, #6d5cae);flex-shrink:0}.select-all[_ngcontent-%COMP%]{padding-bottom:12px;border-bottom:1px solid var(--%NS%md-color-border, #bbb)}ul[_ngcontent-%COMP%]{height:220px;overflow:auto;list-style:none;padding:0;margin:8px 0 0}li[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]{min-height:40px;padding:6px;cursor:pointer;overflow-wrap:anywhere}li[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]:hover{background:var(--%NS%md-color-surface-hover, #eee)}.disabled[_ngcontent-%COMP%]{opacity:.5}.actions[_ngcontent-%COMP%]{display:grid;gap:8px}button[_ngcontent-%COMP%]{padding:8px 12px;min-height:36px;border:1px solid var(--%NS%md-color-border, #bbb);border-radius:4px;color:inherit;background:var(--%NS%md-color-surface, #fff);cursor:pointer;font:inherit;font-size:13px}button[_ngcontent-%COMP%]:disabled{opacity:.45;cursor:default}input[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-color-focus, #6d5cae);outline-offset:2px}.empty[_ngcontent-%COMP%]{padding:16px 0;color:var(--%NS%md-color-text-muted, #626872)}.status[_ngcontent-%COMP%]{font-size:13px;margin:8px 0 0}@media(max-width:900px){.transfer[_ngcontent-%COMP%]{grid-template-columns:1fr}.actions[_ngcontent-%COMP%]{grid-template-columns:1fr 1fr}}button[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:8px}"] });
} return n; })(), tk = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), $a = (() => { class n {
    targets = new Map;
    register(e, i) { this.targets.set(e, [...this.targets.get(e) ?? [], i]); }
    unregister(e, i) { let o = (this.targets.get(e) ?? []).filter(r => r !== i); o.length ? this.targets.set(e, o) : this.targets.delete(e); }
    resolve(e) { return this.targets.get(e)?.find(i => i.isConnected && i.getClientRects().length > 0); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275prov = t.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })(), ik = (() => { class n {
    registry = d($a);
    element = d(x);
    name = "";
    set mdTourTarget(e) { this.registry.unregister(this.name, this.element.nativeElement), this.name = e, e && this.registry.register(e, this.element.nativeElement); }
    ngOnDestroy() { this.registry.unregister(this.name, this.element.nativeElement); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["", "mdTourTarget", ""]], inputs: { mdTourTarget: "mdTourTarget" } });
} return n; })(), zf = 0, nk = (() => { class n {
    overlay = d(yt);
    targets = d($a);
    view = d(ge);
    cdr = d(E);
    document = d(ve);
    zone = d(K);
    spotlight;
    frame;
    lastBounds = "";
    spotlightPadding = 8;
    spotlightRadius = 10;
    ref;
    subscriptions = new F;
    restore;
    activeSteps = [];
    steps = [];
    nextLabel = "Next";
    backLabel = "Back";
    finishLabel = "Finish";
    closeLabel = "Close tour";
    progressLabel = (e, i) => `Step ${e} of ${i}`;
    completed = new p;
    dismissed = new p;
    stepChange = new p;
    template;
    id = `md-tour-${zf++}`;
    index = 0;
    get current() { return this.activeSteps[this.index]; }
    get total() { return this.activeSteps.length; }
    start(e = this.steps) { this.ref || (this.activeSteps = e.filter(i => { let o = this.resolve(i); return o?.isConnected && o.getClientRects().length > 0; }), this.total && (this.restore = this.document.activeElement, this.index = 0, this.show())); }
    resolve(e) { return typeof e?.target == "string" ? this.targets.resolve(e.target) : e?.target; }
    show() { let e = this.current, i = this.resolve(e); if (!i?.isConnected || !i.getClientRects().length) {
        this.close();
        return;
    } i.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" }); let o = this.overlay.position().flexibleConnectedTo(i).withViewportMargin(12).withPush(!0).withPositions([{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top", offsetY: 12 }, { originX: "end", originY: "top", overlayX: "end", overlayY: "bottom", offsetY: -12 }]); this.ref ? this.ref.updatePositionStrategy(o) : (this.ref = this.overlay.create({ positionStrategy: o, hasBackdrop: !0, scrollStrategy: this.overlay.scrollStrategies.reposition(), maxWidth: "calc(100vw - 24px)" }), this.ref.attach(new xe(this.template, this.view)), this.installSpotlight(), this.subscriptions.add(this.ref.backdropClick().subscribe(() => this.close())), this.subscriptions.add(this.ref.keydownEvents().subscribe(r => { r.key === "Escape" && (r.preventDefault(), r.stopPropagation(), this.close()); }))), this.updateSpotlight(), this.cdr.detectChanges(), this.ref.updatePosition(), this.ref.overlayElement.querySelector('[role="dialog"]')?.focus(), this.stepChange.emit(this.index); }
    installSpotlight() { let e = this.ref?.backdropElement; if (!e)
        return; e.style.background = "transparent"; let i = this.document.createElement("div"); i.setAttribute("aria-hidden", "true"), Object.assign(i.style, { position: "fixed", pointerEvents: "none", boxSizing: "border-box", border: "2px solid var(--md-color-focus, #b9a8ff)", boxShadow: "0 0 0 9999px rgba(0, 0, 0, .66)" }), e.appendChild(i), this.spotlight = i; let o = this.document.defaultView; o && this.zone.runOutsideAngular(() => { let r = () => { this.ref && (this.updateSpotlight(), this.ref && (this.frame = o.requestAnimationFrame(r))); }; this.frame = o.requestAnimationFrame(r); }); }
    updateSpotlight() { let e = this.resolve(this.current), i = this.document.defaultView; if (!e || !this.spotlight || !i)
        return; if (!e.isConnected || !e.getClientRects().length) {
        this.zone.run(() => this.close());
        return;
    } let o = e.getBoundingClientRect(), r = Number.isFinite(this.spotlightPadding) ? Math.max(0, this.spotlightPadding) : 8, s = Math.max(0, o.left - r), l = Math.max(0, o.top - r), c = Math.min(i.innerWidth, o.right + r), h = Math.min(i.innerHeight, o.bottom + r); for (let w = e.parentElement; w && w !== this.document.body; w = w.parentElement) {
        let N = i.getComputedStyle(w), M = w.getBoundingClientRect();
        /(auto|scroll|hidden|clip)/.test(N.overflowX) && (s = Math.max(s, M.left), c = Math.min(c, M.right)), /(auto|scroll|hidden|clip)/.test(N.overflowY) && (l = Math.max(l, M.top), h = Math.min(h, M.bottom));
    } let g = Math.max(0, c - s), u = Math.max(0, h - l), f = Number.isFinite(this.spotlightRadius) ? Math.max(0, this.spotlightRadius) : 10, v = [s, l, g, u, f].join(","); v !== this.lastBounds && (this.lastBounds = v, Object.assign(this.spotlight.style, { left: `${s}px`, top: `${l}px`, width: `${g}px`, height: `${u}px`, borderRadius: `${f}px` }), this.ref?.updatePosition()); }
    next() { this.index === this.total - 1 ? (this.dispose(), this.completed.emit()) : (this.index++, this.show()); }
    back() { this.index > 0 && (this.index--, this.show()); }
    close() { this.ref && (this.dispose(), this.dismissed.emit()); }
    dispose() { this.frame !== void 0 && this.document.defaultView?.cancelAnimationFrame(this.frame), this.frame = void 0, this.spotlight?.remove(), this.spotlight = void 0, this.lastBounds = "", this.subscriptions.unsubscribe(), this.subscriptions = new F, this.ref?.dispose(), this.ref = void 0, this.restore?.isConnected && this.restore.focus(), this.cdr.markForCheck(); }
    ngOnDestroy() { this.dispose(); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-tour"]], viewQuery: function (i, o) { if (i & 1 && t.\u0275\u0275viewQuery(H, 7), i & 2) {
            let r;
            t.\u0275\u0275queryRefresh(r = t.\u0275\u0275loadQuery()) && (o.template = r.first);
        } }, inputs: { spotlightPadding: "spotlightPadding", spotlightRadius: "spotlightRadius", steps: "steps", nextLabel: "nextLabel", backLabel: "backLabel", finishLabel: "finishLabel", closeLabel: "closeLabel", progressLabel: "progressLabel" }, outputs: { completed: "completed", dismissed: "dismissed", stepChange: "stepChange" }, exportAs: ["mdTour"], decls: 1, vars: 0, consts: [["role", "dialog", "aria-modal", "true", "tabindex", "-1", "cdkTrapFocus", "", 1, "tour"], ["type", "button", 3, "click"], ["width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", "focusable", "false", 2, "display", "inline-block", "vertical-align", "middle", "flex-shrink", "0"], ["d", "M6 6l12 12M18 6 6 18"], [3, "id"], ["type", "button", 3, "click", "disabled"], ["type", "button", 1, "next", 3, "click"]], template: function (i, o) { i & 1 && t.\u0275\u0275template(0, bu, 16, 11, "ng-template"); }, dependencies: [Lr], styles: [".tour[_ngcontent-%COMP%]{width:340px;max-width:calc(100vw - 24px);box-sizing:border-box;max-height:calc(100vh - 24px);overflow:auto;padding:var(--%NS%md-spacing-5, 20px);border:1px solid var(--%NS%md-color-border, #bbb);border-radius:var(--%NS%md-radius-lg, 8px);background:var(--%NS%md-overlay-surface, #fff);color:var(--%NS%md-color-text, #222);box-shadow:var(--%NS%md-shadow-lg, 0 8px 24px rgba(0, 0, 0, .2))}header[_ngcontent-%COMP%], footer[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;gap:12px}header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:var(--%NS%md-color-text-muted, #626872);font-size:12px}h2[_ngcontent-%COMP%]{font-size:20px;margin:12px 0}p[_ngcontent-%COMP%]{font-size:14px;line-height:1.6;margin:0 0 20px}button[_ngcontent-%COMP%]{cursor:pointer;padding:6px 12px;min-height:36px;border:1px solid var(--%NS%md-color-border, #bbb);border-radius:4px;color:inherit;background:transparent;font:inherit}button[_ngcontent-%COMP%]:disabled{opacity:.4;cursor:default}.next[_ngcontent-%COMP%]{border-color:var(--%NS%md-color-link, #6d5cae);color:var(--%NS%md-color-link, #6d5cae)}button[_ngcontent-%COMP%]:focus-visible, .tour[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-color-focus, #6d5cae);outline-offset:2px}header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:8px}"] });
} return n; })(), ok = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), Pr = (() => { class n {
    template = d(H);
    label = I("", { alias: "mdCarouselSlide" });
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275dir = t.\u0275\u0275defineDirective({ type: n, selectors: [["ng-template", "mdCarouselSlide", ""]], inputs: { label: [1, "mdCarouselSlide", "label"] } });
} return n; })(), rk = (() => { class n {
    label = I("Carousel");
    loop = I(!0, { transform: m });
    index = Rr(0);
    slides = Sn(Pr);
    current = re(() => Math.max(0, Math.min(Number.isFinite(this.index()) ? Math.trunc(this.index()) : 0, this.slides().length - 1)));
    active = re(() => this.slides()[this.current()]);
    previousDisabled = re(() => this.slides().length < 2 || !this.loop() && this.current() === 0);
    nextDisabled = re(() => this.slides().length < 2 || !this.loop() && this.current() === this.slides().length - 1);
    goTo(e) { let i = this.slides().length; if (!i)
        return; let o = this.loop() ? (e + i) % i : Math.max(0, Math.min(e, i - 1)); this.index.set(o); }
    onKeydown(e) { if (!(e.target !== e.currentTarget || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey)) {
        switch (e.key) {
            case "ArrowLeft":
                this.goTo(this.current() - 1);
                break;
            case "ArrowRight":
                this.goTo(this.current() + 1);
                break;
            case "Home":
                this.goTo(0);
                break;
            case "End":
                this.goTo(this.slides().length - 1);
                break;
            default: return;
        }
        e.preventDefault();
    } }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-carousel"]], contentQueries: function (i, o, r) { i & 1 && t.\u0275\u0275contentQuerySignal(r, o.slides, Pr, 4), i & 2 && t.\u0275\u0275queryAdvance(); }, hostAttrs: ["role", "region", "aria-roledescription", "carousel"], hostVars: 1, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275attribute("aria-label", o.label()); }, inputs: { label: [1, "label"], loop: [1, "loop"], index: [1, "index"] }, outputs: { index: "indexChange" }, decls: 1, vars: 1, consts: [["tabindex", "0", "role", "group", "aria-roledescription", "slide", 1, "viewport", 3, "keydown"], [3, "ngTemplateOutlet"], [1, "navigation"], ["role", "status", "aria-atomic", "true", 1, "sr-only"], ["type", "button", "aria-label", "Previous slide", 1, "arrow", 3, "click", "disabled"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", "focusable", "false"], ["points", "15 5 8 12 15 19"], ["role", "group", "aria-label", "Choose slide", 1, "indicators"], ["type", "button", 1, "indicator", 3, "active"], ["type", "button", "aria-label", "Next slide", 1, "arrow", 3, "click", "disabled"], ["points", "9 5 16 12 9 19"], ["type", "button", 1, "indicator", 3, "click"]], template: function (i, o) { if (i & 1 && t.\u0275\u0275conditionalCreate(0, yu, 5, 6), i & 2) {
            let r;
            t.\u0275\u0275conditional((r = o.active()) ? 0 : -1, r);
        } }, dependencies: [bt], styles: ["[_nghost-%COMP%]{display:block;min-width:0;color:var(--%NS%md-color-text)}.viewport[_ngcontent-%COMP%]{overflow:hidden;border-radius:var(--%NS%md-panel-radius, 12px);background:var(--%NS%md-color-surface-muted)}.viewport[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-color-focus);outline-offset:3px}.navigation[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;gap:12px;margin-top:16px}button[_ngcontent-%COMP%]{color:inherit;cursor:pointer;border:0;background:transparent;min-width:36px;height:36px;border-radius:8px}button[_ngcontent-%COMP%]:hover:not(:disabled){background:var(--%NS%md-color-surface-hover)}button[_ngcontent-%COMP%]:disabled{opacity:.35;cursor:default}.arrow[_ngcontent-%COMP%]{display:grid;place-items:center;width:44px;height:44px;padding:0;border:1px solid var(--%NS%md-color-border);flex-shrink:0}.arrow[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{display:block;width:28px;height:28px}.indicators[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;justify-content:center}.indicator[_ngcontent-%COMP%]{display:grid;place-items:center;padding:0}.indicator[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{width:7px;height:7px;border-radius:999px;background:var(--%NS%md-color-text-muted)}.indicator.active[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{width:22px;background:var(--%NS%md-color-focus)}.sr-only[_ngcontent-%COMP%]{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}"] });
} return n; })(), ak = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), sk = (() => {
    class n {
        static \u0275fac = function (i) { return new (i || n); };
        static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["table", "md-platform-table", ""]], ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275projection(0)); }, styles: [`table[md-platform-table]{width:100%;border-collapse:separate;border-spacing:0;color:var(--%NS%md-table-text, #373737);background:var(--%NS%md-table-background, #FFFFFF);font:400 12px/20px Montserrat,Arial,sans-serif;text-align:left}table[md-platform-table] caption{padding:0;text-align:left}table[md-platform-table] th,table[md-platform-table] td{padding:5px 18px;vertical-align:middle;white-space:nowrap}table[md-platform-table] thead th{position:relative;height:48px;box-sizing:border-box;background:var(--%NS%md-table-heading-background, #EAEAEA);border-bottom:12px solid var(--%NS%md-table-background, #FFFFFF);font-weight:500;text-transform:uppercase}table[md-platform-table] thead th:not(:last-child):after{content:"";position:absolute;inset-block:0;inset-inline-end:0;border-inline-end:1px dashed var(--%NS%md-table-divider, #BDBDBD);pointer-events:none}table[md-platform-table] thead abbr{text-decoration:none}table[md-platform-table] thead button{display:inline-flex;align-items:center;justify-content:space-between;gap:24px;width:100%;padding:0;border:0;background:transparent;color:inherit;font:inherit;text-transform:inherit;cursor:pointer}table[md-platform-table] thead svg{width:14px;height:14px;flex-shrink:0}table[md-platform-table] button:focus-visible,table[md-platform-table] a:focus-visible{outline:2px solid #0185CF;outline-offset:3px}table[md-platform-table] tbody td{height:29px;box-sizing:border-box}table[md-platform-table] tbody tr:hover{background:var(--%NS%md-table-hover, #F3F3F3)}table[md-platform-table] tbody tr:focus-within{background:var(--%NS%md-table-hover, #F3F3F3)}table[md-platform-table] tbody a{color:inherit;text-decoration:none}table[md-platform-table] tbody a:hover{text-decoration:underline}table[md-platform-table] tfoot td{position:relative;background:var(--%NS%md-table-heading-background, #EAEAEA);border-top:24px solid var(--%NS%md-table-background, #FFFFFF);font-weight:500}table[md-platform-table] tfoot td:not(:last-child):after{content:"";position:absolute;inset-block:0;inset-inline-end:0;border-inline-end:1px solid var(--%NS%md-table-background, #FFFFFF);pointer-events:none}table[md-platform-table] [data-status=approved]{color:var(--%NS%md-table-success, #28B446)}table[md-platform-table] [data-status=restricted]{color:var(--%NS%md-table-danger, #CF0106)}table[md-platform-table] [data-status=pending]{color:var(--%NS%md-table-muted, #4D4D4D)}.md-theme-dark table[md-platform-table]{--%NS%md-table-text: var(--%NS%md-color-text);--%NS%md-table-background: var(--%NS%md-color-surface);--%NS%md-table-heading-background: var(--%NS%md-color-surface-muted);--%NS%md-table-divider: var(--%NS%md-color-border);--%NS%md-table-hover: var(--%NS%md-color-surface-muted);--%NS%md-table-muted: var(--%NS%md-color-text-subtle)}
`], encapsulation: 2 });
    }
    return n;
})(), dk = (() => { class n {
    items = I([]);
    label = I("Breadcrumb");
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-platform-breadcrumbs"]], inputs: { items: [1, "items"], label: [1, "label"] }, decls: 1, vars: 1, consts: [["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", "focusable", "false"], ["aria-current", "page"], [3, "routerLink"], [3, "href"], ["d", "M4 12h16m-6-6 6 6-6 6"]], template: function (i, o) { i & 1 && t.\u0275\u0275conditionalCreate(0, Mu, 4, 1, "nav"), i & 2 && t.\u0275\u0275conditional(o.items().length ? 0 : -1); }, dependencies: [ml], styles: ["[_nghost-%COMP%]{display:block;min-width:0;color:var(--%NS%md-platform-ink, #444);font:400 13px/20px Lato,Arial,sans-serif}ol[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;align-items:center;gap:4px 8px;list-style:none;margin:0;padding:0}li[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:8px;min-width:0;max-width:100%}a[_ngcontent-%COMP%], span[_ngcontent-%COMP%]{color:inherit;overflow-wrap:anywhere;min-width:0}a[_ngcontent-%COMP%]{text-decoration:none;border-radius:2px}a[_ngcontent-%COMP%]:hover{color:var(--%NS%md-platform-link, #a50105);text-decoration:underline;text-underline-offset:3px}a[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-platform-focus, #cf0106);outline-offset:3px}svg[_ngcontent-%COMP%]{width:24px;height:24px;display:block;flex:0 0 24px;color:var(--%NS%md-platform-muted, #666)}[dir=rtl][_nghost-%COMP%]   svg[_ngcontent-%COMP%], [dir=rtl]   [_nghost-%COMP%]   svg[_ngcontent-%COMP%]{transform:rotate(180deg)}"] });
} return n; })(), lk = (() => { class n {
    heading = I.required();
    icon = I("information");
    expanded = Rr(!1);
    onToggle(e) { this.expanded.set(e.target.open); }
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-platform-accordion"]], inputs: { heading: [1, "heading"], icon: [1, "icon"], expanded: [1, "expanded"] }, outputs: { expanded: "expandedChange" }, ngContentSelectors: T, decls: 13, vars: 3, consts: [[3, "toggle", "open"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "1.8", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", "focusable", "false", 1, "icon"], ["d", "M13 4H4v16h16v-9M14 3h7v7M21 3 10 14"], ["d", "m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM12 3v18M4 12h16"], ["viewBox", "0 0 24 24", "aria-hidden", "true", "focusable", "false", 1, "chevron"], ["d", "m6 9 6 6 6-6z", "fill", "currentColor"], [1, "content"], ["cx", "12", "cy", "12", "r", "9"], ["d", "M12 11v6M12 7h.01"], ["cx", "15", "cy", "8", "r", "5"], ["d", "m11 12-8 8v1h4v-3h3v-3l3-3M17 6h.01"]], template: function (i, o) { if (i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElementStart(0, "details", 0), t.\u0275\u0275domListener("toggle", function (s) { return o.onToggle(s); }), t.\u0275\u0275domElementStart(1, "summary"), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(2, "svg", 1), t.\u0275\u0275conditionalCreate(3, Tu, 2, 0)(4, Eu, 1, 0, ":svg:path", 2)(5, Iu, 1, 0, ":svg:path", 3)(6, Nu, 2, 0), t.\u0275\u0275domElementEnd(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275domElementStart(7, "span"), t.\u0275\u0275text(8), t.\u0275\u0275domElementEnd(), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(9, "svg", 4), t.\u0275\u0275domElement(10, "path", 5), t.\u0275\u0275domElementEnd()(), t.\u0275\u0275namespaceHTML(), t.\u0275\u0275domElementStart(11, "div", 6), t.\u0275\u0275projection(12), t.\u0275\u0275domElementEnd()()), i & 2) {
            let r;
            t.\u0275\u0275domProperty("open", o.expanded()), t.\u0275\u0275advance(3), t.\u0275\u0275conditional((r = o.icon()) === "information" ? 3 : r === "references" ? 4 : r === "security" ? 5 : r === "credentials" ? 6 : -1), t.\u0275\u0275advance(5), t.\u0275\u0275textInterpolate(o.heading());
        } }, styles: ["[_nghost-%COMP%]{display:block;color:var(--%NS%md-platform-ink, #444);font:14px/1.5 Lato,Arial,sans-serif}details[_ngcontent-%COMP%]{border-radius:4px;overflow:clip;background:var(--%NS%md-platform-canvas, #f3f3f3)}summary[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;min-height:64px;padding:16px;box-sizing:border-box;list-style:none;cursor:pointer;text-transform:uppercase}summary[_ngcontent-%COMP%]::-webkit-details-marker{display:none}summary[_ngcontent-%COMP%]:hover{background:var(--%NS%md-platform-gray, #e8e8e8)}summary[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-platform-focus, #cf0106);outline-offset:-3px}summary[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{flex:1;overflow-wrap:anywhere}svg[_ngcontent-%COMP%]{display:block;width:24px;height:24px;flex-shrink:0}details[open][_ngcontent-%COMP%]   .chevron[_ngcontent-%COMP%]{transform:rotate(180deg)}.content[_ngcontent-%COMP%]{padding:4px 52px 24px}@media(max-width:480px){.content[_ngcontent-%COMP%]{padding:4px 16px 20px}}"] });
} return n; })(), ck = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-platform-surface"]], ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275projection(0)); }, styles: ["[_nghost-%COMP%]{--%NS%md-platform-red: #cf0106;--%NS%md-platform-ink: #444;--%NS%md-platform-muted: #666;--%NS%md-platform-gray: #e8e8e8;--%NS%md-platform-canvas: #f3f3f3;--%NS%md-platform-white: #fff;--%NS%md-platform-hover: #666;--%NS%md-platform-green: #008a37;--%NS%md-platform-confirm: #444;--%NS%md-platform-chip: #444;--%NS%md-platform-on-solid: #fff;--%NS%md-platform-input: #fff;--%NS%md-platform-border: #ccc;--%NS%md-platform-link: #a50105;--%NS%md-platform-error: #cf0106;--%NS%md-platform-focus: #cf0106;--%NS%md-platform-success-hover: #00752f;display:block;color-scheme:light;color:var(--%NS%md-platform-ink);background:var(--%NS%md-platform-white);font-family:Lato,Arial,sans-serif;font-size:14px;line-height:1.5;padding:24px;border-radius:4px;--%NS%text: var(--%NS%md-platform-ink);--%NS%bs-body-color: var(--%NS%md-platform-ink);--%NS%bs-heading-color: var(--%NS%md-platform-ink);--%NS%md-color-heading: var(--%NS%md-platform-ink);--%NS%md-control-background: var(--%NS%md-platform-input);--%NS%md-control-text-color: var(--%NS%md-platform-ink);--%NS%md-control-placeholder-color: var(--%NS%md-platform-muted);--%NS%md-control-arrow-color: var(--%NS%md-platform-muted);--%NS%md-color-text: var(--%NS%md-platform-ink);--%NS%md-color-text-muted: var(--%NS%md-platform-muted);--%NS%md-color-surface: var(--%NS%md-platform-white);--%NS%md-color-surface-muted: var(--%NS%md-platform-canvas);--%NS%md-color-border: var(--%NS%md-platform-border);--%NS%md-color-focus: var(--%NS%md-platform-focus)}.theme-dark[_nghost-%COMP%], .theme-dark   [_nghost-%COMP%], .md-theme-dark[_nghost-%COMP%], .md-theme-dark   [_nghost-%COMP%]{color-scheme:dark;--%NS%md-platform-ink: #f4f6fb;--%NS%md-platform-muted: #b6bfcc;--%NS%md-platform-white: #181b20;--%NS%md-platform-canvas: #22262d;--%NS%md-platform-gray: #303641;--%NS%md-platform-input: #181b20;--%NS%md-platform-border: #616a78;--%NS%md-platform-confirm: #3d4452;--%NS%md-platform-chip: #3d4452;--%NS%md-platform-hover: #525d70;--%NS%md-platform-error: #ff8b91;--%NS%md-platform-focus: #ff8b91;--%NS%md-platform-link: #66c7ff}"] });
} return n; })(), mk = (() => { class n {
    variant = I("primary");
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["button", "md-platform-button", ""]], hostVars: 1, hostBindings: function (i, o) { i & 2 && t.\u0275\u0275attribute("data-variant", o.variant()); }, inputs: { variant: [1, "variant"] }, ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275projection(0)); }, styles: ["[_nghost-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:36px;min-width:104px;padding:7px 18px;box-sizing:border-box;border:0;border-radius:4px;background:var(--%NS%md-platform-red, #cf0106);color:#fff;font:700 14px/18px Lato,Arial,sans-serif;cursor:pointer}[data-variant=confirm][_nghost-%COMP%]{background:var(--%NS%md-platform-confirm, #444)}[data-variant=cancel][_nghost-%COMP%]{background:var(--%NS%md-platform-gray, #e8e8e8);color:var(--%NS%md-platform-ink, #111)}[data-variant=text][_nghost-%COMP%]{background:transparent;color:var(--%NS%md-platform-ink, #111)}[data-variant=success][_nghost-%COMP%]{background:var(--%NS%md-platform-green, #00ad45)}[_nghost-%COMP%]:hover:not(:disabled){background:var(--%NS%md-platform-hover, #888);color:#fff}[data-variant=cancel][_nghost-%COMP%]:hover:not(:disabled){background:var(--%NS%md-platform-canvas, #f3f3f3);color:var(--%NS%md-platform-ink, #111)}[data-variant=text][_nghost-%COMP%]:hover:not(:disabled){background:transparent;color:var(--%NS%md-platform-error, #cf0106)}[data-variant=success][_nghost-%COMP%]:hover:not(:disabled){background:var(--%NS%md-platform-success-hover, #00752f)}[_nghost-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-platform-focus, #cf0106);outline-offset:3px}[_nghost-%COMP%]:disabled{opacity:.45;cursor:not-allowed}"] });
} return n; })(), hk = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["input", "md-platform-input", ""], ["textarea", "md-platform-input", ""]], decls: 0, vars: 0, template: function (i, o) { }, styles: ["[_nghost-%COMP%]{display:block;width:100%;min-height:36px;box-sizing:border-box;border:1px solid transparent;border-radius:4px;padding:8px 12px;font:14px/18px Lato,Arial,sans-serif;color:var(--%NS%md-platform-ink, #444);background:var(--%NS%md-platform-input, #fff)}[_nghost-%COMP%]::placeholder{color:var(--%NS%md-platform-muted, #666);opacity:1}[_nghost-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-platform-focus, #cf0106);outline-offset:2px}[aria-invalid=true][_nghost-%COMP%]{border-color:var(--%NS%md-platform-error, #cf0106)}[_nghost-%COMP%]:disabled{color:var(--%NS%md-platform-muted, #888);background:var(--%NS%md-platform-gray, #e8e8e8);cursor:not-allowed}textarea[_nghost-%COMP%]{min-height:90px;resize:vertical}"] });
} return n; })(), pk = (() => { class n {
    controlId = I.required();
    label = I.required();
    hint = I("");
    error = I("");
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-platform-field"]], inputs: { controlId: [1, "controlId"], label: [1, "label"], hint: [1, "hint"], error: [1, "error"] }, ngContentSelectors: T, decls: 5, vars: 3, consts: [[1, "error", 3, "id"], [1, "hint", 3, "id"]], template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275domElementStart(0, "label"), t.\u0275\u0275text(1), t.\u0275\u0275domElementEnd(), t.\u0275\u0275projection(2), t.\u0275\u0275conditionalCreate(3, Pu, 2, 2, "span", 0)(4, Ou, 2, 2, "span", 1)), i & 2 && (t.\u0275\u0275attribute("for", o.controlId()), t.\u0275\u0275advance(), t.\u0275\u0275textInterpolate(o.label()), t.\u0275\u0275advance(2), t.\u0275\u0275conditional(o.error() ? 3 : o.hint() ? 4 : -1)); }, styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;gap:6px;min-width:0;color:var(--%NS%md-platform-ink, #444);font:14px/18px Lato,Arial,sans-serif}label[_ngcontent-%COMP%]{margin:0}.hint[_ngcontent-%COMP%]{color:var(--%NS%md-platform-muted, #666);font-size:12px}.error[_ngcontent-%COMP%]{color:var(--%NS%md-platform-error, #cf0106);font-size:12px;text-align:end}[_nghost-%COMP%]   label[_ngcontent-%COMP%]{color:var(--%NS%md-platform-ink, #444)}"] });
} return n; })(), uk = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-platform-chip"]], ngContentSelectors: T, decls: 1, vars: 0, template: function (i, o) { i & 1 && (t.\u0275\u0275projectionDef(), t.\u0275\u0275projection(0)); }, styles: ["[_nghost-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:28px;padding:2px 8px;box-sizing:border-box;border-radius:4px;background:var(--%NS%md-platform-chip, #444);color:#fff;font:12px/18px Lato,Arial,sans-serif}"] });
} return n; })(), gk = (() => { class n {
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = t.\u0275\u0275defineInjector({});
} return n; })(), fk = (() => { class n {
    filters = I([]);
    openLabel = I("Open filters");
    removeLabel = I("Remove filter");
    selectLabel = I("Edit filter");
    disabled = I(!1);
    openFilters = rt();
    removeFilter = rt();
    selectFilter = rt();
    static \u0275fac = function (i) { return new (i || n); };
    static \u0275cmp = t.\u0275\u0275defineComponent({ type: n, selectors: [["md-filter-action-bar"]], inputs: { filters: [1, "filters"], openLabel: [1, "openLabel"], removeLabel: [1, "removeLabel"], selectLabel: [1, "selectLabel"], disabled: [1, "disabled"] }, outputs: { openFilters: "openFilters", removeFilter: "removeFilter", selectFilter: "selectFilter" }, decls: 5, vars: 3, consts: [[1, "md-filter-action-bar"], ["role", "list", 1, "md-filter-chips"], ["type", "button", "aria-haspopup", "dialog", 1, "md-filter-toggle", 3, "click", "disabled"], ["viewBox", "0 0 16 16", "aria-hidden", "true", "focusable", "false"], ["d", "M1 1h14L10 7v8l-4-3V7z", "fill", "currentColor"], ["role", "listitem", 1, "md-filter-chip"], ["type", "button", 1, "md-filter-chip-label", 3, "click", "disabled"], ["type", "button", 1, "md-filter-chip-remove", 3, "click", "disabled"], ["d", "M2 2l12 12M14 2L2 14", "fill", "none", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round"]], template: function (i, o) { i & 1 && (t.\u0275\u0275domElementStart(0, "div", 0), t.\u0275\u0275conditionalCreate(1, Ru, 3, 0, "div", 1), t.\u0275\u0275domElementStart(2, "button", 2), t.\u0275\u0275domListener("click", function () { return o.openFilters.emit(); }), t.\u0275\u0275namespaceSVG(), t.\u0275\u0275domElementStart(3, "svg", 3), t.\u0275\u0275domElement(4, "path", 4), t.\u0275\u0275domElementEnd()()()), i & 2 && (t.\u0275\u0275advance(), t.\u0275\u0275conditional(o.filters().length ? 1 : -1), t.\u0275\u0275advance(), t.\u0275\u0275domProperty("disabled", o.disabled()), t.\u0275\u0275attribute("aria-label", o.openLabel())); }, styles: ["[_nghost-%COMP%]{display:block;min-width:0}.md-filter-action-bar[_ngcontent-%COMP%]{display:flex;align-items:flex-start;justify-content:flex-end;gap:12px;min-height:36px}.md-filter-chips[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:6px;min-width:0;max-width:100%}.md-filter-chip[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:8px;max-width:100%;min-height:24px;padding:2px 10px;box-sizing:border-box;border-radius:4px;background:var(--%NS%md-filter-chip-background, #4D4D4D);color:var(--%NS%md-filter-chip-color, #FFFFFF);font:500 12px/20px Montserrat,Arial,sans-serif;letter-spacing:normal}button[_ngcontent-%COMP%]{border:0;padding:0;color:inherit;font:inherit;cursor:pointer}.md-filter-chip-label[_ngcontent-%COMP%]{min-width:0;overflow:hidden;background:transparent;text-overflow:ellipsis;white-space:nowrap}.md-filter-chip-remove[_ngcontent-%COMP%]{display:inline-flex;flex:0 0 9px;align-items:center;background:transparent}.md-filter-chip-remove[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{display:block;width:9px;height:9px}.md-filter-toggle[_ngcontent-%COMP%]{display:inline-flex;flex:0 0 50px;align-items:center;justify-content:center;width:50px;height:36px;border-radius:4px;background:var(--%NS%md-filter-button-background, #FFFFFF);color:var(--%NS%md-filter-button-color, #373737);box-shadow:0 2px 8px #00000029}.md-filter-toggle[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{display:block;width:16px;height:16px}button[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--%NS%md-color-focus, #CF0106);outline-offset:3px}button[_ngcontent-%COMP%]:disabled{cursor:default;opacity:.5}.md-theme-dark[_nghost-%COMP%], .md-theme-dark   [_nghost-%COMP%]{--%NS%md-filter-chip-background: var(--%NS%md-color-surface-muted);--%NS%md-filter-chip-color: var(--%NS%md-color-text);--%NS%md-filter-button-background: var(--%NS%md-color-surface);--%NS%md-filter-button-color: var(--%NS%md-color-text-subtle)}"] });
} return n; })();
export { Xi as ACCORDION, fn as BasePortalHost, Vu as CARD_CONFIG, gn as ComponentPortal, Gu as DIALOG_DATA, $u as DIALOG_DEFAULT_OPTIONS, Yu as DIALOG_SCROLL_STRATEGY, xf as DefaultGlobalConfig, Cf as DefaultNoAnimationsGlobalConfig, Xn as DefaultNoComponentGlobalConfig, Vt as DialogState, ba as EXPANSION_PANEL_DEFAULT_OPTIONS, La as ErrorStateMatcher, Au as ExpansionPanelActionRow, Lu as ExpansionPanelDescription, Bu as ExpansionPanelTitle, ky as INK_BAR_POSITIONER, gg as INK_BAR_POSITIONER_FACTORY, Yt as InkBar, zu as MDAccordion, My as MDAutocomplete, Iy as MDAutocompleteModule, Ty as MDAutocompleteOrigin, on as MDAutocompleteSelectedEvent, wg as MDAutocompleteTrigger, ef as MDBottomSheet, pn as MDBottomSheetConfig, Xg as MDBottomSheetContainer, Yy as MDBottomSheetModule, Qt as MDBottomSheetRef, Nr as MDBreadcrumbItem, Ff as MDBreadcrumbs, Ex as MDBreadcrumbsModule, tf as MDButton, Qy as MDButtonModule, Sf as MDButtonToggle, wf as MDButtonToggleGroup, yx as MDButtonToggleModule, ox as MDCalendar, Hv as MDCard, Yv as MDCardActions, ey as MDCardAvatar, Gv as MDCardContent, Qv as MDCardFooter, qv as MDCardHeader, Kv as MDCardImage, Zv as MDCardLgImage, Xv as MDCardMdImage, ty as MDCardModule, Uv as MDCardSmImage, $v as MDCardSubtitle, jv as MDCardTitle, Wv as MDCardTitleGroup, Jv as MDCardXlImage, rk as MDCarousel, ak as MDCarouselModule, Pr as MDCarouselSlide, Sy as MDCheckBox, Dy as MDCheckBoxModule, nn as MDCheckboxChange, ut as MDChip, Oy as MDChipAvatar, Ry as MDChipEdit, zi as MDChipEditInput, Py as MDChipGrid, cn as MDChipGridChange, Ly as MDChipInput, Ng as MDChipListbox, ln as MDChipListboxChange, Tg as MDChipOption, Ay as MDChipRemove, Eg as MDChipRow, Cr as MDChipSelectionChange, Aa as MDChipSet, Fy as MDChipTrailingIcon, By as MDChipsModule, Vv as MDCollapseModule, Zx as MDCombobox, Jx as MDComboboxModule, uy as MDContextMenuTrigger, tf as MDDangerButton, tf as MDDarkButton, ix as MDDateRangeInput, nx as MDDateRangePicker, Xy as MDDatepicker, ii as MDDatepickerActions, Uy as MDDatepickerApply, Ky as MDDatepickerCancel, Zy as MDDatepickerInput, af as MDDatepickerIntl, rx as MDDatepickerModule, Jy as MDDatepickerToggle, sf as MDDatepickerToggleIcon, un as MDDefaultDateRangeSelectionStrategy, $n as MDDialog, ry as MDDialogActions, iy as MDDialogClose, Wu as MDDialogContainer, oy as MDDialogContent, ny as MDDialogTitle, cx as MDDivider, mx as MDDividerModule, Mx as MDDrawer, xn as MDDrawerConfig, Tx as MDDrawerModule, Kt as MDDrawerRef, Px as MDDropzone, Ox as MDDropzoneModule, $x as MDEmptyState, Yx as MDEmptyStateModule, tx as MDEndDate, _a as MDExpansionPanel, fa as MDExpansionPanelContent, va as MDExpansionPanelHeader, fk as MDFilterActionBar, Sx as MDFormField, Dx as MDFormFieldModule, Cx as MDFormFieldPrefix, wx as MDFormFieldSuffix, Hy as MDGridActionsColumnDirective, jy as MDGridAutoSizeDirective, jg as MDGridCellTemplateDirective, at as MDGridColumnDirective, Kg as MDGridComponent, Gg as MDGridEditTemplateDirective, Wg as MDGridHeaderTemplateDirective, Vy as MDGridIdColumnDirective, Gy as MDGridModule, Wy as MDGridResetFlexSizingDirective, Yg as MDGridToolbarTemplateDirective, Pg as MDHeaderCardComponent, zy as MDHeaderCardModule, Og as MDHeaderCardSetComponent, tf as MDInfoButton, Ef as MDInput, tf as MDLightButton, tf as MDLinkButton, Ye as MDMenu, eg as MDMenuContent, pt as MDMenuItem, ng as MDMenuModule, Sa as MDMenuTrigger, Fx as MDMenubar, Bx as MDMenubarCheckbox, Vx as MDMenubarGroup, Lx as MDMenubarItem, Rx as MDMenubarMenu, Hx as MDMenubarModule, zx as MDMenubarRadio, Ax as MDMenubarTrigger, ay as MDModalModule, qn as MDOption, Qn as MDOptionGroup, vr as MDOptionModule, $t as MDOptionSelectionChange, Lf as MDPagination, jx as MDPaginationModule, Fg as MDPaginatorComponent, $y as MDPaginatorModule, lk as MDPlatformAccordion, dk as MDPlatformBreadcrumbs, mk as MDPlatformButton, uk as MDPlatformChip, pk as MDPlatformField, hk as MDPlatformInput, gk as MDPlatformModule, ck as MDPlatformSurface, sk as MDPlatformTable, qx as MDPopover, Kx as MDPopoverModule, Qx as MDPopoverTrigger, tf as MDPrimaryButton, dx as MDProgressBar, lx as MDProgressBarModule, ax as MDProgressSpinner, sx as MDProgressSpinnerModule, rg as MDPseudoCheckboxModule, Mg as MDRadioButton, Dg as MDRadioGroup, Ny as MDRadioModule, tf as MDSecondaryButton, Jt as MDSelect, ag as MDSelectModule, _y as MDSelectTrigger, Ix as MDSkeleton, Nx as MDSkeletonModule, hx as MDSlider, px as MDSliderModule, pf as MDSliderRangeThumb, pf as MDSliderThumb, xx as MDSnackBar, yn as MDSnackBarConfig, kx as MDSnackBarModule, ft as MDSnackBarRef, ax as MDSpinner, Ux as MDSplitPane, Xx as MDSplitPaneModule, ex as MDStartDate, tf as MDStatusDangerButton, tf as MDStatusPrimaryButton, Ju as MDStep, Ku as MDStepContent, hy as MDStepExecutorModule, Uu as MDStepFooter, fr as MDStepHeader, Zi as MDStepLabel, ly as MDStepper, Qu as MDStepperIcon, cy as MDStepperNext, my as MDStepperPrevious, tf as MDSuccessButton, vy as MDSwitch, yy as MDSwitchModule, ug as MDTab, en as MDTabBody, tn as MDTabChangeEvent, mg as MDTabContent, _g as MDTabGroup, bg as MDTabHeader, pg as MDTabLabel, Oa as MDTabLabelWrapper, yg as MDTabLink, vg as MDTabNav, Cy as MDTabNavPanel, wy as MDTabsModule, ux as MDTooltip, gx as MDTooltipModule, nk as MDTour, ok as MDTourModule, ik as MDTourTarget, $a as MDTourTargets, ek as MDTransferList, tk as MDTransferListModule, Wx as MDUploadList, Gx as MDUploadListModule, tf as MDWarningButton, Fa as MD_AUTOCOMPLETE_DEFAULT_OPTIONS, Cg as MD_AUTOCOMPLETE_SCROLL_STRATEGY, kg as MD_AUTOCOMPLETE_VALUE_ACCESSOR, Zg as MD_BOTTOM_SHEET_DATA, Jg as MD_BOTTOM_SHEET_DEFAULT_OPTIONS, qy as MD_BUTTON_DIRECTIVES, ti as MD_CHIP, ei as MD_CHIPS_DEFAULT_OPTIONS, rn as MD_CHIP_AVATAR, sn as MD_CHIP_EDIT, Ig as MD_CHIP_LISTBOX_CONTROL_VALUE_ACCESSOR, dn as MD_CHIP_REMOVE, an as MD_CHIP_TRAILING_ICON, Un as MD_DATEPICKER_ACTIONS_OWNER, lf as MD_DATE_RANGE_SELECTION_STRATEGY, Ga as MD_DRAWER_CONFIG, Nf as MD_DRAWER_DATA, ga as MD_EXPANSION_PANEL, Wa as MD_FORM_FIELD, Ca as MD_MENU_CONTENT, tg as MD_MENU_DEFAULT_OPTIONS, Yn as MD_MENU_PANEL, ig as MD_MENU_SCROLL_STRATEGY, xg as MD_OPTION_PARENT_COMPONENT, Ra as MD_RADIO_GROUP, Ta as MD_SELECT_TRIGGER, Va as MD_SLIDER, Df as MD_SNACK_BAR_DEFAULT_OPTIONS, Ia as MD_TAB, hg as MD_TAB_LABEL, py as MENU_PANEL_TOP_PADDING, Wt as MefDevDialogConfig, ht as MefDevDialogRef, bf as Overlay, ff as OverlayContainer, _n as OverlayRef, Ea as PaginatedTabHeader, og as PseudoCheckbox, Sg as RADIO_GROUP_CONTROL_VALUE_ACCESSOR, qt as RadioChange, sy as STEPPER_INTL_PROVIDER, qu as STEPPER_INTL_PROVIDER_FACTORY, Ji as SelectChange, dy as ShowOnDirtyErrorStateMatcher, Z as SortDirection, hn as SortType, _r as StepperErrorStateMatcher, Gt as StepperIntl, cg as TABS_CONFIG, xy as TAB_CONTENT, Na as TAB_GROUP, ni as TOAST_CONFIG, xr as TabBodyPortal, yf as Toast, fx as ToastContainerDirective, Ha as ToastNoAnimation, vx as ToastNoAnimationModule, gt as ToastPackage, vn as ToastRef, _x as ToastrComponentlessModule, bx as ToastrModule, _f as ToastrService, _e as TransitionCheckState, mn as _ErrorStateTracker, ya as _closeDialogVia, Da as _countGroupLabelsBeforeOption, Ma as _getOptionScrollPosition, zv as components, Ey as getMDAutocompleteMissingPanelError, gy as getMDSelectDynamicMultipleError, fy as getMDSelectNonArrayValueError, by as getMDSelectNonFunctionValueError, Bg as groupRowsByProperty, Rf as matchesFileAccept, kf as provideToastr, zg as sortRows };
/*! Bundled license information:

@natec/mef-dev-ui-kit/fesm2022/natec-mef-dev-ui-kit.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.dev/license
   *)
*/
