import { a as b, c as d } from "@nf-internal/chunk-MQ6KVUBG";
import * as n from "@angular/core";
import { inject as c, ElementRef as f, EventEmitter as h, booleanAttribute as m, NgZone as _ } from "@angular/core";
import { Observable as p, Subject as g } from "rxjs";
import { debounceTime as E, map as y, filter as O } from "rxjs/operators";
function D(t) { if (t.type === "characterData" && t.target instanceof Comment)
    return !0; if (t.type === "childList") {
    for (let r = 0; r < t.addedNodes.length; r++)
        if (!(t.addedNodes[r] instanceof Comment))
            return !1;
    for (let r = 0; r < t.removedNodes.length; r++)
        if (!(t.removedNodes[r] instanceof Comment))
            return !1;
    return !0;
} return !1; }
var a = (() => { class t {
    create(e) { return typeof MutationObserver > "u" ? null : new MutationObserver(e); }
    static \u0275fac = function (s) { return new (s || t); };
    static \u0275prov = n.\u0275\u0275defineService({ token: t, factory: t.\u0275fac });
} return t; })(), M = (() => { class t {
    _mutationObserverFactory = c(a);
    _observedElements = new Map;
    _ngZone = c(_);
    ngOnDestroy() { this._observedElements.forEach((e, s) => this._cleanupObserver(s)); }
    observe(e) { let s = d(e); return new p(i => { let v = this._observeElement(s).pipe(y(o => o.filter(l => !D(l))), O(o => !!o.length)).subscribe(o => { this._ngZone.run(() => { i.next(o); }); }); return () => { v.unsubscribe(), this._unobserveElement(s); }; }); }
    _observeElement(e) { return this._ngZone.runOutsideAngular(() => { if (this._observedElements.has(e))
        this._observedElements.get(e).count++;
    else {
        let s = new g, i = this._mutationObserverFactory.create(u => s.next(u));
        i && i.observe(e, { characterData: !0, childList: !0, subtree: !0 }), this._observedElements.set(e, { observer: i, stream: s, count: 1 });
    } return this._observedElements.get(e).stream; }); }
    _unobserveElement(e) { this._observedElements.has(e) && (this._observedElements.get(e).count--, this._observedElements.get(e).count || this._cleanupObserver(e)); }
    _cleanupObserver(e) { if (this._observedElements.has(e)) {
        let { observer: s, stream: i } = this._observedElements.get(e);
        s && s.disconnect(), i.complete(), this._observedElements.delete(e);
    } }
    static \u0275fac = function (s) { return new (s || t); };
    static \u0275prov = n.\u0275\u0275defineService({ token: t, factory: t.\u0275fac });
} return t; })(), I = (() => { class t {
    _contentObserver = c(M);
    _elementRef = c(f);
    event = new h;
    get disabled() { return this._disabled; }
    set disabled(e) { this._disabled = e, this._disabled ? this._unsubscribe() : this._subscribe(); }
    _disabled = !1;
    get debounce() { return this._debounce; }
    set debounce(e) { this._debounce = b(e), this._subscribe(); }
    _debounce;
    _currentSubscription = null;
    ngAfterContentInit() { !this._currentSubscription && !this.disabled && this._subscribe(); }
    ngOnDestroy() { this._unsubscribe(); }
    _subscribe() { this._unsubscribe(); let e = this._contentObserver.observe(this._elementRef); this._currentSubscription = (this.debounce ? e.pipe(E(this.debounce)) : e).subscribe(this.event); }
    _unsubscribe() { this._currentSubscription?.unsubscribe(); }
    static \u0275fac = function (s) { return new (s || t); };
    static \u0275dir = n.\u0275\u0275defineDirective({ type: t, selectors: [["", "cdkObserveContent", ""]], inputs: { disabled: [2, "cdkObserveContentDisabled", "disabled", m], debounce: "debounce" }, outputs: { event: "cdkObserveContent" }, exportAs: ["cdkObserveContent"] });
} return t; })(), R = (() => { class t {
    static \u0275fac = function (s) { return new (s || t); };
    static \u0275mod = n.\u0275\u0275defineNgModule({ type: t });
    static \u0275inj = n.\u0275\u0275defineInjector({ providers: [a] });
} return t; })();
export { a, M as b, I as c, R as d };
