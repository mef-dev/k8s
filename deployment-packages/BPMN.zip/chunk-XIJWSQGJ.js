var zt = Object.defineProperty, er = Object.defineProperties;
var nr = Object.getOwnPropertyDescriptors;
var ue = Object.getOwnPropertySymbols;
var xn = Object.prototype.hasOwnProperty, Rn = Object.prototype.propertyIsEnumerable;
var Fe = (e, n) => (n = Symbol[e]) ? n : Symbol.for("Symbol." + e), tr = e => { throw TypeError(e); };
var Fn = (e, n, t) => n in e ? zt(e, n, { enumerable: !0, configurable: !0, writable: !0, value: t }) : e[n] = t, I = (e, n) => { for (var t in n ||= {})
    xn.call(n, t) && Fn(e, t, n[t]); if (ue)
    for (var t of ue(n))
        Rn.call(n, t) && Fn(e, t, n[t]); return e; }, w = (e, n) => er(e, nr(n));
var oi = (e, n) => { var t = {}; for (var r in e)
    xn.call(e, r) && n.indexOf(r) < 0 && (t[r] = e[r]); if (e != null && ue)
    for (var r of ue(e))
        n.indexOf(r) < 0 && Rn.call(e, r) && (t[r] = e[r]); return t; };
var xe = (e, n, t) => new Promise((r, o) => { var i = u => { try {
    c(t.next(u));
}
catch (d) {
    o(d);
} }, s = u => { try {
    c(t.throw(u));
}
catch (d) {
    o(d);
} }, c = u => u.done ? r(u.value) : Promise.resolve(u.value).then(i, s); c((t = t.apply(e, n)).next()); }), rr = function (e, n) { this[0] = e, this[1] = n; };
var ii = e => { var n = e[Fe("asyncIterator")], t = !1, r, o = {}; return n == null ? (n = e[Fe("iterator")](), r = i => o[i] = s => n[i](s)) : (n = n.call(e), r = i => o[i] = s => { if (t) {
    if (t = !1, i === "throw")
        throw s;
    return s;
} return t = !0, { done: !1, value: new rr(new Promise(c => { var u = n[i](s); u instanceof Object || tr("Object expected"), c(u); }), 1) }; }), o[Fe("iterator")] = () => o, r("next"), "throw" in n ? r("throw") : o.throw = i => { throw i; }, "return" in n && r("return"), o; };
var v = null, ae = !1, R = 1, or = null, y = Symbol("SIGNAL");
function p(e) { let n = v; return v = e, n; }
function Re() { return v; }
var J = { version: 0, lastCleanEpoch: 0, dirty: !1, producers: void 0, producersTail: void 0, consumers: void 0, consumersTail: void 0, recomputing: !1, consumerAllowSignalWrites: !1, consumerIsAlwaysLive: !1, kind: "unknown", producerMustRecompute: () => !1, producerRecomputeValue: () => { }, consumerMarkedDirty: () => { }, consumerOnSignalRead: () => { } };
function Q(e) { if (ae)
    throw new Error(""); if (v === null)
    return; v.consumerOnSignalRead(e); let n = v.producersTail; if (n !== void 0 && n.producer === e)
    return; let t, r = v.recomputing; if (r && (t = n !== void 0 ? n.nextProducer : v.producers, t !== void 0 && t.producer === e)) {
    v.producersTail = t, t.lastReadVersion = e.version, t.knownValidAtEpoch = R;
    return;
} let o = e.consumersTail; if (o !== void 0 && o.consumer === v && (!r || o.knownValidAtEpoch === R))
    return; let i = $(v), s = { producer: e, consumer: v, nextProducer: t, prevConsumer: void 0, knownValidAtEpoch: R, lastReadVersion: e.version, nextConsumer: void 0 }; v.producersTail = s, n !== void 0 ? n.nextProducer = s : v.producers = s, i && Pn(e, s); }
function On() { R++; }
function j(e) { if (!($(e) && !e.dirty) && !(!e.dirty && e.lastCleanEpoch === R)) {
    if (!e.producerMustRecompute(e) && !An(e)) {
        V(e);
        return;
    }
    e.producerRecomputeValue(e), V(e);
} }
function Oe(e) { if (e.consumers === void 0)
    return; let n = ae; ae = !0; try {
    for (let t = e.consumers; t !== void 0; t = t.nextConsumer) {
        let r = t.consumer;
        r.dirty || ir(r);
    }
}
finally {
    ae = n;
} }
function ke() { return v?.consumerAllowSignalWrites !== !1; }
function ir(e) { e.dirty = !0, Oe(e), e.consumerMarkedDirty?.(e); }
function V(e) { e.dirty = !1, e.lastCleanEpoch = R; }
function ce(e) { return e && kn(e), p(e); }
function kn(e) { if (e.producersTail?.knownValidAtEpoch === R) {
    let n = e.producers;
    for (; n !== void 0;)
        n.knownValidAtEpoch = null, n = n.nextProducer;
} e.producersTail = void 0, e.recomputing = !0; }
function de(e, n) { p(n), e && jn(e); }
function jn(e) { e.recomputing = !1; let n = e.producersTail, t = n !== void 0 ? n.nextProducer : e.producers; if (t !== void 0) {
    if ($(e))
        do
            t = Ae(t);
        while (t !== void 0);
    n !== void 0 ? n.nextProducer = void 0 : e.producers = void 0;
} }
function An(e) { for (let n = e.producers; n !== void 0; n = n.nextProducer) {
    let t = n.producer, r = n.lastReadVersion;
    if (r !== t.version || (j(t), r !== t.version))
        return !0;
} return !1; }
function je(e) { if ($(e)) {
    let n = e.producers;
    for (; n !== void 0;)
        n = Ae(n);
} e.producers = void 0, e.producersTail = void 0, e.consumers = void 0, e.consumersTail = void 0; }
function Pn(e, n) { let t = e.consumersTail, r = $(e); if (t !== void 0 ? (n.nextConsumer = t.nextConsumer, t.nextConsumer = n) : (n.nextConsumer = void 0, e.consumers = n), n.prevConsumer = t, e.consumersTail = n, !r)
    for (let o = e.producers; o !== void 0; o = o.nextProducer)
        Pn(o.producer, o); }
function Ae(e) { let n = e.producer, t = e.nextProducer, r = e.nextConsumer, o = e.prevConsumer; if (e.nextConsumer = void 0, e.prevConsumer = void 0, r !== void 0 ? r.prevConsumer = o : n.consumersTail = o, o !== void 0)
    o.nextConsumer = r;
else if (n.consumers = r, !$(n)) {
    let i = n.producers;
    for (; i !== void 0;)
        i = Ae(i);
} return t; }
function $(e) { return e.consumerIsAlwaysLive || e.consumers !== void 0; }
function X(e) { or?.(e); }
function z(e, n) { return Object.is(e, n); }
function Pe(e, n) { let t = Object.create(sr); t.computation = e, n !== void 0 && (t.equal = n); let r = () => { if (j(t), Q(t), t.value === N)
    throw t.error; return t.value; }; return r[y] = t, X(t), r; }
var O = Symbol("UNSET"), k = Symbol("COMPUTING"), N = Symbol("ERRORED"), sr = w(I({}, J), { value: O, dirty: !0, error: null, equal: z, kind: "computed", producerMustRecompute(e) { return e.value === O || e.value === k; }, producerRecomputeValue(e) { if (e.value === k)
        throw new Error(""); let n = e.value; e.value = k; let t = ce(e), r, o = !1; try {
        r = e.computation(), p(null), o = n !== O && n !== N && r !== N && e.equal(n, r);
    }
    catch (i) {
        r = N, e.error = i;
    }
    finally {
        de(e, t);
    } if (o) {
        e.value = n;
        return;
    } e.value = r, e.version++; } });
function ur() { throw new Error; }
var Ln = ur;
function Vn(e) { Ln(e); }
function ar(e) { Ln = e; }
var cr = null;
function Le(e, n) { let t = Object.create(qn); t.value = e, n !== void 0 && (t.equal = n); let r = () => $n(t); return r[y] = t, X(t), [r, s => ee(t, s), s => le(t, s)]; }
function $n(e) { return Q(e), e.value; }
function ee(e, n) { ke() || Vn(e), e.equal(e.value, n) || (e.value = n, dr(e)); }
function le(e, n) { ke() || Vn(e), ee(e, n(e.value)); }
var qn = w(I({}, J), { equal: z, value: void 0, kind: "signal" });
function dr(e) { e.version++, On(), Oe(e), cr?.(e); }
var Ve = w(I({}, J), { consumerIsAlwaysLive: !0, consumerAllowSignalWrites: !0, dirty: !0, kind: "effect" });
function $e(e) { if (e.dirty = !1, e.version > 0 && !An(e))
    return; e.version++; let n = ce(e); try {
    e.cleanup(), e.fn();
}
finally {
    de(e, n);
} }
var qe;
function fe() { return qe; }
function C(e) { let n = qe; return qe = e, n; }
var Un = Symbol("NotFound");
function q(e) { return e === Un || e?.name === "\u0275NotFound"; }
function Ue(e, n, t) { let r = Object.create(lr); r.source = e, r.computation = n, t != null && (r.equal = t); let i = () => { if (j(r), Q(r), r.value === N)
    throw r.error; return r.value; }; return i[y] = r, X(r), i; }
function Ge(e, n) { j(e), ee(e, n), V(e); }
function Gn(e, n) { if (j(e), e.value === N)
    throw e.error; le(e, n), V(e); }
var lr = w(I({}, J), { value: O, dirty: !0, error: null, equal: z, kind: "linkedSignal", producerMustRecompute(e) { return e.value === O || e.value === k; }, producerRecomputeValue(e) { if (e.value === k)
        throw new Error(""); let n = e.value; e.value = k; let t = ce(e), r, o = !1; try {
        let i = e.source(), s = n !== O && n !== N, c = s ? { source: e.sourceValue, value: n } : void 0;
        r = e.computation(i, c), e.sourceValue = i, p(null), o = s && r !== N && e.equal(n, r);
    }
    catch (i) {
        r = N, e.error = i;
    }
    finally {
        de(e, t);
    } if (o) {
        e.value = n;
        return;
    } e.value = r, e.version++; } });
function Hn(e) { let n = p(null); try {
    return e();
}
finally {
    p(n);
} }
function gi(e) { }
import { BehaviorSubject as fr, Observable as gr, Subject as pr, Subscription as hr } from "rxjs";
var Be = class {
    full;
    major;
    minor;
    patch;
    constructor(n) { this.full = n; let t = n.split("."); this.major = t[0], this.minor = t[1], this.patch = t.slice(2).join("."); }
}, Bn = new Be("22.1.4"), mr = (() => { let e = Bn.full; return `https://${e.includes("-next") || e.includes("-rc") || e === "0.0.0-PLACEHOLDER" ? "next" : `v${Bn.major}`}.angular.dev`; })(), Ri = `${mr}/errors`, Oi = "https://angular.dev/best-practices/security#preventing-cross-site-scripting-xss", g = class extends Error {
    code;
    constructor(n, t) { super(ln(n, t)), this.code = n; }
};
function vr(e) { return `NG0${Math.abs(e)}`; }
function ln(e, n) { return `${vr(e)}${n ? ": " + n : ""}`; }
function l(e) { for (let n in e)
    if (e[n] === l)
        return n; throw Error(""); }
function ki(e, n) { for (let t in n)
    Object.hasOwn(n, t) && !Object.hasOwn(e, t) && (e[t] = n[t]); }
function yr(e) {
    if (typeof e == "string")
        return e;
    if (Array.isArray(e))
        return `[${e.map(yr).join(", ")}]`;
    if (e == null)
        return "" + e;
    let n = e.overriddenName || e.name;
    if (n)
        return `${n}`;
    let t = e.toString();
    if (t == null)
        return "" + t;
    let r = t.indexOf(`
`);
    return r >= 0 ? t.slice(0, r) : t;
}
function ji(e, n) { return e ? n ? `${e} ${n}` : e : n || ""; }
function Ai(e, n = 100) { if (!e || n < 1 || e.length <= n)
    return e; if (n == 1)
    return e.substring(0, 1) + "..."; let t = Math.round(n / 2); return e.substring(0, t) + "..." + e.substring(e.length - t); }
var Dr = l({ __forward_ref__: l });
function st(e) { return e.__forward_ref__ = st, e; }
function b(e) { return Er(e) ? e() : e; }
function Er(e) { return typeof e == "function" && Object.hasOwn(e, Dr) && e.__forward_ref__ === st; }
function Ir(e, n, t) { e != n && ie(t, e, n, "=="); }
function ut(e, n) { e == null && ie(n, e, null, "!="); }
function ie(e, n, t, r) { throw new Error(`ASSERTION ERROR: ${e}` + (r == null ? "" : ` [Expected=> ${t} ${r} ${n} <=Actual]`)); }
function Z(e) { return { token: e.token, providedIn: e.providedIn || null, factory: e.factory, value: void 0 }; }
function Pi(e) { return { providers: e.providers || [], imports: e.imports || [] }; }
function Te(e) { return wr(e, at); }
function Li(e) { return Te(e) !== null; }
function wr(e, n) { return Object.hasOwn(e, n) && e[n] || null; }
function Tr(e) { let n = e?.[at] ?? null; return n || null; }
function Zn(e) { return e && Object.hasOwn(e, Wn) ? e[Wn] : null; }
var at = l({ \u0275prov: l }), Wn = l({ \u0275inj: l }), h = class {
    _desc;
    ngMetadataName = "InjectionToken";
    \u0275prov;
    constructor(n, t) { this._desc = n, this.\u0275prov = void 0, typeof t == "number" ? this.__NG_ELEMENT_ID__ = t : t !== void 0 && (this.\u0275prov = Z({ token: this, providedIn: t.providedIn || "root", factory: t.factory })); }
    get multi() { return this; }
    toString() { return `InjectionToken ${this._desc}`; }
}, Yn;
function Vi(e) { ie("setInjectorProfilerContext should never be called in production mode"); let n = Yn; return Yn = e, n; }
function ct(e) { return e && !!e.\u0275providers; }
var Nr = l({ \u0275cmp: l }), Cr = l({ \u0275dir: l }), br = l({ \u0275pipe: l }), Mr = l({ \u0275mod: l }), Kn = l({ \u0275fac: l }), $i = l({ __NG_ELEMENT_ID__: l }), Jn = l({ __NG_ENV_ID__: l });
function _r(e) { return Ne(e, "@NgModule"), e[Mr] || null; }
function qi(e) { let n = _r(e); if (!n)
    throw new g(915, !1); return n; }
function dt(e) { return Ne(e, "@Component"), e[Nr] || null; }
function Sr(e) { return Ne(e, "@Directive"), e[Cr] || null; }
function Fr(e) { return Ne(e, "@Pipe"), e[br] || null; }
function Ne(e, n) { if (e == null)
    throw new g(-919, !1); }
function Ui(e) { let n = dt(e) || Sr(e) || Fr(e); return n !== null && n.standalone; }
function xr(e) { return typeof e == "string" ? e : e == null ? "" : String(e); }
function Gi(e) { return typeof e == "function" ? e.name || e.toString() : typeof e == "object" && e != null && typeof e.type == "function" ? e.type.name || e.type.toString() : xr(e); }
var lt = l({ ngErrorCode: l }), Rr = l({ ngErrorMessage: l }), Or = l({ ngTokenPath: l });
function kr(e, n) { return ft("", -200, n); }
function jr(e, n) { throw new g(-201, !1); }
function ft(e, n, t) { let r = new g(n, e); return r[lt] = n, r[Rr] = e, t && (r[Or] = t), r; }
function Ar(e) { return e[lt]; }
var Ze;
function gt() { return Ze; }
function S(e) { let n = Ze; return Ze = e, n; }
function Pr(e, n, t) { let r = Te(e); if (r && r.providedIn == "root")
    return r.value === void 0 ? r.value = r.factory() : r.value; if (t & 8)
    return null; if (n !== void 0)
    return n; jr(e, ""); }
var Hi = globalThis;
var Lr = {}, A = Lr, We = "__NG_DI_FLAG__", Ye = class {
    injector;
    constructor(n) { this.injector = n; }
    retrieve(n, t) { let r = pe(t) || 0; try {
        return this.injector.get(n, r & 8 ? null : A, r);
    }
    catch (o) {
        if (q(o))
            return o;
        throw o;
    } }
};
function Vr(e, n = 0) { let t = fe(); if (t === void 0)
    throw new g(-203, !1); if (t === null)
    return Pr(e, void 0, n); {
    let r = $r(n), o = t.retrieve(e, r);
    if (q(o)) {
        if (r.optional)
            return null;
        throw o;
    }
    return o;
} }
function H(e, n = 0) { return (gt() || Vr)(b(e), n); }
function Bi(e) { throw new g(202, !1); }
function m(e, n) { return H(e, pe(n)); }
function pe(e) { return typeof e > "u" || typeof e == "number" ? e : 0 | (e.optional && 8) | (e.host && 1) | (e.self && 2) | (e.skipSelf && 4); }
function $r(e) { return { optional: !!(e & 8), host: !!(e & 1), self: !!(e & 2), skipSelf: !!(e & 4) }; }
function Ke(e) { let n = []; for (let t = 0; t < e.length; t++) {
    let r = b(e[t]);
    if (Array.isArray(r)) {
        if (r.length === 0)
            throw new g(900, !1);
        let o, i = 0;
        for (let s = 0; s < r.length; s++) {
            let c = r[s], u = qr(c);
            typeof u == "number" ? u === -1 ? o = c.token : i |= u : o = c;
        }
        n.push(H(o, i));
    }
    else
        n.push(H(r));
} return n; }
function Zi(e, n) { return e[We] = n, e.prototype[We] = n, e; }
function qr(e) { return e[We]; }
function he(e, n) { let t = Object.hasOwn(e, Kn); return t ? e[Kn] : null; }
function Wi(e, n, t) { if (e.length !== n.length)
    return !1; for (let r = 0; r < e.length; r++) {
    let o = e[r], i = n[r];
    if (t && (o = t(o), i = t(i)), i !== o)
        return !1;
} return !0; }
function Yi(e) { return e.flat(Number.POSITIVE_INFINITY); }
function fn(e, n) { e.forEach(t => Array.isArray(t) ? fn(t, n) : n(t)); }
function Ki(e, n, t) { n >= e.length ? e.push(t) : e.splice(n, 0, t); }
function Ji(e, n) { return n >= e.length - 1 ? e.pop() : e.splice(n, 1)[0]; }
function Qi(e, n) { let t = []; for (let r = 0; r < e; r++)
    t.push(n); return t; }
function Xi(e, n, t) { let r = e.length - t; for (; n < r;)
    e[n] = e[n + t], n++; for (; t--;)
    e.pop(); }
function Ur(e, n, t, r) { let o = e.length; if (o == n)
    e.push(t, r);
else if (o === 1)
    e.push(r, e[0]), e[0] = t;
else {
    for (o--, e.push(e[o - 1], e[o]); o > n;) {
        let i = o - 2;
        e[o] = e[i], o--;
    }
    e[n] = t, e[n + 1] = r;
} }
function zi(e, n, t) { let r = pt(e, n); return r >= 0 ? e[r | 1] = t : (r = ~r, Ur(e, r, n, t)), r; }
function es(e, n) { let t = pt(e, n); if (t >= 0)
    return e[t | 1]; }
function pt(e, n) { return Gr(e, n, 1); }
function Gr(e, n, t) { let r = 0, o = e.length >> t; for (; o !== r;) {
    let i = r + (o - r >> 1), s = e[i << t];
    if (n === s)
        return i << t;
    s > n ? o = i : r = i + 1;
} return ~(o << t); }
var ns = {}, me = [], Ce = new h(""), ht = new h("", -1), mt = new h(""), ve = class {
    get(n, t = A) { if (t === A) {
        let o = ft("", -201);
        throw o.name = "\u0275NotFound", o;
    } return t; }
};
function vt(e) { return { \u0275providers: e }; }
function Hr(e) { return vt([{ provide: Ce, multi: !0, useValue: e }]); }
function Br(...e) { return { \u0275providers: Zr(!0, e), \u0275fromNgModule: !0 }; }
function Zr(e, ...n) { let t = [], r = new Set, o, i = s => { t.push(s); }; return fn(n, s => { let c = s; Je(c, i, [], r) && (o ||= [], o.push(c)); }), o !== void 0 && yt(o, i), t; }
function yt(e, n) { for (let t = 0; t < e.length; t++) {
    let { ngModule: r, providers: o } = e[t];
    gn(o, i => { n(i, r); });
} }
function Je(e, n, t, r) { if (e = b(e), !e)
    return !1; let o = null, i = Zn(e), s = !i && dt(e); if (!i && !s) {
    let u = e.ngModule;
    if (i = Zn(u), i)
        o = u;
    else
        return !1;
}
else {
    if (s && !s.standalone)
        return !1;
    o = e;
} let c = r.has(o); if (s) {
    if (c)
        return !1;
    if (r.add(o), s.dependencies) {
        let u = typeof s.dependencies == "function" ? s.dependencies() : s.dependencies;
        for (let d of u)
            Je(d, n, t, r);
    }
}
else if (i) {
    if (i.imports != null && !c) {
        r.add(o);
        let d;
        fn(i.imports, f => { Je(f, n, t, r) && (d ||= [], d.push(f)); }), d !== void 0 && yt(d, n);
    }
    if (!c) {
        let d = he(o) || (() => new o);
        n({ provide: o, useFactory: d, deps: me }, o), n({ provide: mt, useValue: o, multi: !0 }, o), n({ provide: Ce, useValue: () => H(o), multi: !0 }, o);
    }
    let u = i.providers;
    if (u != null && !c) {
        let d = e;
        gn(u, f => { n(f, d); });
    }
}
else
    return !1; return o !== e && e.providers !== void 0; }
function gn(e, n) { for (let t of e)
    ct(t) && (t = t.\u0275providers), Array.isArray(t) ? gn(t, n) : n(t); }
var Wr = l({ provide: String, useValue: l });
function Dt(e) { return e !== null && typeof e == "object" && Wr in e; }
function Yr(e) { return !!(e && e.useExisting); }
function Kr(e) { return !!(e && e.useFactory); }
function Qe(e) { return typeof e == "function"; }
function ts(e) { return !!e.useClass; }
var Jr = new h(""), ge = {}, Qn = {}, He;
function Et() { return He === void 0 && (He = new ve), He; }
var re = class {
}, ye = class extends re {
    parent;
    source;
    scopes;
    records = new Map;
    _ngOnDestroyHooks = new Set;
    _onDestroyHooks = [];
    get destroyed() { return this._destroyed; }
    _destroyed = !1;
    injectorDefTypes;
    constructor(n, t, r, o) { super(), this.parent = t, this.source = r, this.scopes = o, ze(n, s => this.processProvider(s)), this.records.set(ht, U(void 0, this)), o.has("environment") && this.records.set(re, U(void 0, this)); let i = this.records.get(Jr); i != null && typeof i.value == "string" && this.scopes.add(i.value), this.injectorDefTypes = new Set(this.get(mt, me, { self: !0 })); }
    retrieve(n, t) { let r = pe(t) || 0; try {
        return this.get(n, A, r);
    }
    catch (o) {
        if (q(o))
            return o;
        throw o;
    } }
    destroy() { ne(this), this._destroyed = !0; let n = p(null); try {
        for (let r of this._ngOnDestroyHooks)
            r.ngOnDestroy();
        let t = this._onDestroyHooks;
        this._onDestroyHooks = [];
        for (let r of t)
            r();
    }
    finally {
        this.records.clear(), this._ngOnDestroyHooks.clear(), this.injectorDefTypes.clear(), p(n);
    } }
    onDestroy(n) { return ne(this), this._onDestroyHooks.push(n), () => this.removeOnDestroy(n); }
    runInContext(n) { ne(this); let t = C(this), r = S(void 0), o; try {
        return n();
    }
    finally {
        C(t), S(r);
    } }
    get(n, t = A, r) { if (ne(this), Object.hasOwn(n, Jn))
        return n[Jn](this); let o = pe(r), i, s = C(this), c = S(void 0); try {
        if (!(o & 4)) {
            let d = this.records.get(n);
            if (d === void 0) {
                let f = to(n) && Te(n);
                f && this.injectableDefInScope(f) ? d = U(Xe(n), ge) : d = null, this.records.set(n, d);
            }
            if (d != null)
                return this.hydrate(n, d, o);
        }
        let u = o & 2 ? Et() : this.parent;
        return t = o & 8 && t === A ? null : t, u.get(n, t);
    }
    catch (u) {
        let d = Ar(u);
        throw d === -200 || d === -201 ? new g(d, null) : u;
    }
    finally {
        S(c), C(s);
    } }
    resolveInjectorInitializers() { let n = p(null), t = C(this), r = S(void 0), o; try {
        let i = this.get(Ce, me, { self: !0 });
        for (let s of i)
            s();
    }
    finally {
        C(t), S(r), p(n);
    } }
    toString() { return "R3Injector[...]"; }
    processProvider(n) { n = b(n); let t = Qe(n) ? n : b(n && n.provide), r = Xr(n); if (!Qe(n) && n.multi === !0) {
        let o = this.records.get(t);
        o || (o = U(void 0, ge, !0), o.factory = () => Ke(o.multi), this.records.set(t, o)), t = n, o.multi.push(n);
    } this.records.set(t, r); }
    hydrate(n, t, r) { let o = p(null); try {
        if (t.value === Qn)
            throw kr("");
        return t.value === ge && (t.value = Qn, t.value = t.factory(void 0, r)), typeof t.value == "object" && t.value && no(t.value) && this._ngOnDestroyHooks.add(t.value), t.value;
    }
    finally {
        p(o);
    } }
    injectableDefInScope(n) { if (!n.providedIn)
        return !1; let t = b(n.providedIn); return typeof t == "string" ? t === "any" || this.scopes.has(t) : this.injectorDefTypes.has(t); }
    removeOnDestroy(n) { let t = this._onDestroyHooks.indexOf(n); t !== -1 && this._onDestroyHooks.splice(t, 1); }
};
function Xe(e) { let n = Te(e), t = n !== null ? n.factory : he(e); if (t !== null)
    return t; if (e instanceof h)
    throw new g(-204, !1); if (e instanceof Function)
    return Qr(e); throw new g(-204, !1); }
function Qr(e) { if (e.length > 0)
    throw new g(-204, !1); let t = Tr(e); return t !== null ? () => t.factory(e) : () => new e; }
function Xr(e) { if (Dt(e))
    return U(void 0, e.useValue); {
    let n = zr(e);
    return U(n, ge);
} }
function zr(e, n, t) { let r; if (Qe(e)) {
    let o = b(e);
    return he(o) || Xe(o);
}
else if (Dt(e))
    r = () => b(e.useValue);
else if (Kr(e))
    r = () => e.useFactory(...Ke(e.deps || []));
else if (Yr(e))
    r = (o, i) => H(b(e.useExisting), i !== void 0 && i & 8 ? 8 : void 0);
else {
    let o = b(e && (e.useClass || e.provide));
    if (eo(e))
        r = () => new o(...Ke(e.deps));
    else
        return he(o) || Xe(o);
} return r; }
function ne(e) { if (e.destroyed)
    throw new g(-205, !1); }
function U(e, n, t = !1) { return { factory: e, value: n, multi: t ? [] : void 0 }; }
function eo(e) { return !!e.deps; }
function no(e) { return e !== null && typeof e == "object" && typeof e.ngOnDestroy == "function"; }
function to(e) { return typeof e == "function" || typeof e == "object" && e.ngMetadataName === "InjectionToken"; }
function ze(e, n) { for (let t of e)
    Array.isArray(t) ? ze(t, n) : t && ct(t) ? ze(t.\u0275providers, n) : n(t); }
function rs(e, n) { let t; e instanceof ye ? (ne(e), t = e) : t = new Ye(e); let r, o = C(t), i = S(void 0); try {
    return n();
}
finally {
    C(o), S(i);
} }
function It() { return gt() !== void 0 || fe() != null; }
function os(e) { if (!It())
    throw new g(-203, !1); }
var pn = 0, hn = 1, D = 2, en = 3, is = 4, ro = 5, ss = 6, oo = 7, wt = 8, us = 9, Tt = 10, as = 11, cs = 12, ds = 13, Nt = 14, ls = 15, fs = 16, io = 17, gs = 18, ps = 19, hs = 20, G = 21, ms = 22, nn = 23, so = 24, vs = 25, ys = 26, uo = 27, mn = 1, Ds = 6, Es = 7, Is = 8, ws = 9, Ts = 10;
function Ct(e) { return Array.isArray(e) && typeof e[mn] == "object"; }
function bt(e) { return Array.isArray(e) && e[mn] === !0; }
function Ns(e) { return (e.flags & 4) !== 0; }
function Cs(e) { return e.componentOffset > -1; }
function bs(e) { return (e.flags & 1) === 1; }
function Ms(e) { return !!e.template; }
function _s(e) { return (e[D] & 512) !== 0; }
function Ss(e) { return (e.type & 16) === 16; }
function Fs(e) { return (e[D] & 32) === 32; }
function Mt(e) { return (e[D] & 256) === 256; }
function xs(e, n) { ao(e, n[hn]); }
function ao(e, n) { co(e); let t = n.data; for (let r = uo; r < t.length; r++)
    if (t[r] === e)
        return; ie("This TNode does not belong to this TView."); }
function co(e) { ut(e, "TNode must be defined"), e && typeof e == "object" && Object.hasOwn(e, "directiveStylingLast") || ie("Not of type TNode, got: " + e); }
function Rs(e) { ut(e, "LView must be defined"), Ir(Ct(e), !0, "Expecting LView"); }
var T = (function (e) { return e[e.NONE = 0] = "NONE", e[e.HTML = 1] = "HTML", e[e.STYLE = 2] = "STYLE", e[e.SCRIPT = 3] = "SCRIPT", e[e.URL = 4] = "URL", e[e.RESOURCE_URL = 5] = "RESOURCE_URL", e[e.ATTRIBUTE_NO_BINDING = 6] = "ATTRIBUTE_NO_BINDING", e; })(T || {}), te, tn = "svg", _t = "math", St = "", Xn = "*", rn = () => Object.create(null);
function lo() { return te || (te = rn(), _(T.HTML, void 0, [["iframe", ["srcdoc"]], ["*", ["innerHTML", "outerHTML"]]]), _(T.STYLE, void 0, [["*", ["style"]]]), _(T.URL, void 0, [["*", ["formAction"]], ["area", ["href"]], ["a", ["href", "xlink:href"]], ["form", ["action"]], ["img", ["src"]], ["video", ["src"]]]), _(T.URL, _t, [["*", ["href", "xlink:href"]]]), _(T.RESOURCE_URL, void 0, [["base", ["href"]], ["embed", ["src"]], ["frame", ["src"]], ["iframe", ["src"]], ["link", ["href"]], ["object", ["codebase", "data"]]]), _(T.URL, tn, [["a", ["href", "xlink:href"]]]), _(T.ATTRIBUTE_NO_BINDING, tn, [["animate", ["attributeName", "values", "to", "from"]], ["set", ["to", "attributeName"]], ["animateMotion", ["attributeName"]], ["animateTransform", ["attributeName"]]]), _(T.ATTRIBUTE_NO_BINDING, void 0, [["unknown", ["attributeName", "values", "to", "from", "sandbox", "allow", "allowFullscreen", "referrerPolicy", "csp", "fetchPriority", "credentialless"]], ["iframe", ["sandbox", "allow", "allowFullscreen", "referrerPolicy", "csp", "fetchPriority", "credentialless"]]]), te); }
function _(e, n, t) { let r = n ?? St; for (let [o, i] of t) {
    let s = o.toLowerCase();
    for (let c of i) {
        let u = c.toLowerCase(), d = te[u] ??= rn(), f = d[r] ??= rn();
        f[s] = e;
    }
} }
function Os(e, n, t) { let o = lo()[n.toLowerCase()]; if (!o)
    return T.NONE; let i = e.toLowerCase(), s; if (t) {
    let c = o[t];
    c && (s = c[i] ?? c[Xn]);
} if (s === void 0) {
    let c = o[St];
    c && (s = c[i] ?? c[Xn]);
} return s ?? T.NONE; }
function vn(e) { for (; Array.isArray(e);)
    e = e[pn]; return e; }
function ks(e) { for (; Array.isArray(e);) {
    if (typeof e[mn] == "object")
        return e;
    e = e[pn];
} return null; }
function js(e, n) { return vn(n[e]); }
function As(e, n) { return vn(n[e.index]); }
function Ps(e, n) { let t = e === null ? -1 : e.index; return t !== -1 ? vn(n[t]) : null; }
function fo(e, n) { return e.data[n]; }
function Ls(e, n) { return e[n]; }
function Vs(e, n, t, r) { t >= e.data.length && (e.data[t] = null, e.blueprint[t] = null), n[t] = r; }
function $s(e, n) { let t = n[e]; return Ct(t) ? t : t[pn]; }
function qs(e) { return (e[D] & 4) === 4; }
function Ft(e) { return (e[D] & 128) === 128; }
function Us(e) { return bt(e[en]); }
function Gs(e, n) { return n == null ? null : e[n]; }
function Hs(e) { e[io] = 0; }
function Bs(e) { e[D] & 1024 || (e[D] |= 1024, Ft(e) && yn(e)); }
function go(e, n) { for (; e > 0;)
    n = n[Nt], e--; return n; }
function po(e) { return !!(e[D] & 9216 || e[so]?.dirty); }
function Zs(e) { e[Tt].changeDetectionScheduler?.notify(8), e[D] & 64 && (e[D] |= 1024), po(e) && yn(e); }
function yn(e) { e[Tt].changeDetectionScheduler?.notify(0); let n = zn(e); for (; n !== null && !(n[D] & 8192 || (n[D] |= 8192, !Ft(n)));)
    n = zn(n); }
function ho(e, n) { if (Mt(e))
    throw new g(911, !1); e[G] === null && (e[G] = []), e[G].push(n); }
function mo(e, n) { if (e[G] === null)
    return; let t = e[G].indexOf(n); t !== -1 && e[G].splice(t, 1); }
function zn(e) { let n = e[en]; return bt(n) ? n[en] : n; }
function vo(e) { return e[oo] ??= []; }
function yo(e) { return e.cleanup ??= []; }
function Ws(e, n, t, r) { let o = vo(n); o.push(t), e.firstCreatePass && yo(e).push(r, o.length - 1); }
var a = { lFrame: Ot(null), bindingsEnabled: !0, skipHydrationRootTNode: null };
var on = !1;
function Ys() { return a.lFrame.elementDepthCount; }
function Ks() { a.lFrame.elementDepthCount++; }
function Js() { a.lFrame.elementDepthCount--; }
function Qs() { return a.bindingsEnabled; }
function Xs() { return a.skipHydrationRootTNode !== null; }
function zs(e) { return a.skipHydrationRootTNode === e; }
function eu() { a.bindingsEnabled = !0; }
function nu(e) { a.skipHydrationRootTNode = e; }
function tu() { a.bindingsEnabled = !1; }
function ru() { a.skipHydrationRootTNode = null; }
function xt() { return a.lFrame.lView; }
function ou() { return a.lFrame.tView; }
function iu(e) { return a.lFrame.contextLView = e, e[wt]; }
function su(e) { return a.lFrame.contextLView = null, e; }
function Do() { let e = Eo(); for (; e !== null && e.type === 64;)
    e = e.parent; return e; }
function Eo() { return a.lFrame.currentTNode; }
function uu() { let e = a.lFrame, n = e.currentTNode; return e.isParent ? n : n.parent; }
function au(e, n) { let t = a.lFrame; t.currentTNode = e, t.isParent = n; }
function cu() { return a.lFrame.isParent; }
function du() { a.lFrame.isParent = !1; }
function lu() { return a.lFrame.contextLView; }
function fu() { return on; }
function et(e) { let n = on; return on = e, n; }
function gu() { let e = a.lFrame, n = e.bindingRootIndex; return n === -1 && (n = e.bindingRootIndex = e.tView.bindingStartIndex), n; }
function pu() { return a.lFrame.bindingIndex; }
function hu(e) { return a.lFrame.bindingIndex = e; }
function mu() { return a.lFrame.bindingIndex++; }
function vu(e) { let n = a.lFrame, t = n.bindingIndex; return n.bindingIndex = n.bindingIndex + e, t; }
function yu() { return a.lFrame.inI18n; }
function Du(e) { a.lFrame.inI18n = e; }
function Eu(e, n) { let t = a.lFrame; t.bindingIndex = t.bindingRootIndex = e, Io(n); }
function Iu() { return a.lFrame.currentDirectiveIndex; }
function Io(e) { a.lFrame.currentDirectiveIndex = e; }
function wu(e) { let n = a.lFrame.currentDirectiveIndex; return n === -1 ? null : e[n]; }
function Tu() { return a.lFrame.currentQueryIndex; }
function Nu(e) { a.lFrame.currentQueryIndex = e; }
function wo(e) { let n = e[hn]; return n.type === 2 ? n.declTNode : n.type === 1 ? e[ro] : null; }
function Cu(e, n, t) { if (t & 4) {
    let o = n, i = e;
    for (; o = o.parent, o === null && !(t & 1);)
        if (o = wo(i), o === null || (i = i[Nt], o.type & 10))
            break;
    if (o === null)
        return !1;
    n = o, e = i;
} let r = a.lFrame = Rt(); return r.currentTNode = n, r.lView = e, !0; }
function bu(e) { let n = Rt(), t = e[hn]; a.lFrame = n, n.currentTNode = t.firstChild, n.lView = e, n.tView = t, n.contextLView = e, n.bindingIndex = t.bindingStartIndex, n.inI18n = !1; }
function Rt() { let e = a.lFrame, n = e === null ? null : e.child; return n === null ? Ot(e) : n; }
function Ot(e) { let n = { currentTNode: null, isParent: !0, lView: null, tView: null, selectedIndex: -1, contextLView: null, elementDepthCount: 0, currentNamespace: null, currentDirectiveIndex: -1, bindingRootIndex: -1, bindingIndex: -1, currentQueryIndex: 0, parent: e, child: null, inI18n: !1 }; return e !== null && (e.child = n), n; }
function kt() { let e = a.lFrame; return a.lFrame = e.parent, e.currentTNode = null, e.lView = null, e; }
var Mu = kt;
function _u() { let e = kt(); e.isParent = !0, e.tView = null, e.selectedIndex = -1, e.contextLView = null, e.elementDepthCount = 0, e.currentDirectiveIndex = -1, e.currentNamespace = null, e.bindingRootIndex = -1, e.bindingIndex = -1, e.currentQueryIndex = 0; }
function Su(e) { return (a.lFrame.contextLView = go(e, a.lFrame.contextLView))[wt]; }
function Fu() { return a.lFrame.selectedIndex; }
function xu(e) { a.lFrame.selectedIndex = e; }
function Ru() { let e = a.lFrame; return fo(e.tView, e.selectedIndex); }
function Ou() { a.lFrame.currentNamespace = tn; }
function ku() { a.lFrame.currentNamespace = _t; }
function ju() { To(); }
function To() { a.lFrame.currentNamespace = null; }
function Au() { return a.lFrame.currentNamespace; }
var jt = !0;
function Pu() { return jt; }
function Lu(e) { jt = e; }
function Vu() { let e, n; return { promise: new Promise((r, o) => { e = r, n = o; }), resolve: e, reject: n }; }
function nt(e, n = null, t = null, r) { let o = No(e, n, t, r); return o.resolveInjectorInitializers(), o; }
function No(e, n = null, t = null, r, o = new Set) { let i = [t || me, Br(e)], s; return new ye(i, n || Et(), s || null, o); }
var Co = new Set;
function $u() { return Co; }
var oe = class e {
    static THROW_IF_NOT_FOUND = A;
    static NULL = new ve;
    static create(n, t) { if (Array.isArray(n))
        return nt({ name: "" }, t, n, ""); {
        let r = n.name ?? "";
        return nt({ name: r }, n.parent, n.providers, r);
    } }
    static \u0275prov = Z({ token: e, providedIn: "any", factory: () => H(ht) });
    static __NG_ELEMENT_ID__ = -1;
}, Dn = new h(""), M = class {
    static __NG_ELEMENT_ID__ = bo;
    static __NG_ENV_ID__ = n => n;
}, De = class extends M {
    _lView;
    constructor(n) { super(), this._lView = n; }
    get destroyed() { return Mt(this._lView); }
    onDestroy(n) { let t = this._lView; return ho(t, n), () => mo(t, n); }
};
function bo() { return new De(xt()); }
var Mo = !1, _o = new h(""), At = (() => { class e {
    taskId = 0;
    pendingTasks = new Set;
    destroyed = !1;
    pendingTask = new fr(!1);
    debugTaskTracker = m(_o, { optional: !0 });
    get hasPendingTasks() { return this.destroyed ? !1 : this.pendingTask.value; }
    get hasPendingTasksObservable() { return this.destroyed ? new gr(t => { t.next(!1), t.complete(); }) : this.pendingTask; }
    add() { !this.hasPendingTasks && !this.destroyed && this.pendingTask.next(!0); let t = this.taskId++; return this.pendingTasks.add(t), this.debugTaskTracker?.add(t), t; }
    has(t) { return this.pendingTasks.has(t); }
    remove(t) { this.pendingTasks.delete(t), this.debugTaskTracker?.remove(t), this.pendingTasks.size === 0 && this.hasPendingTasks && this.pendingTask.next(!1); }
    ngOnDestroy() { this.pendingTasks.clear(), this.hasPendingTasks && this.pendingTask.next(!1), this.destroyed = !0, this.pendingTask.unsubscribe(); }
    static \u0275prov = Z({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), sn = class extends pr {
    __isAsync;
    destroyRef = void 0;
    pendingTasks = void 0;
    constructor(n = !1) { super(), this.__isAsync = n, It() && (this.destroyRef = m(M, { optional: !0 }) ?? void 0, this.pendingTasks = m(At, { optional: !0 }) ?? void 0); }
    emit(n) { let t = p(null); try {
        super.next(n);
    }
    finally {
        p(t);
    } }
    subscribe(n, t, r) { let o = n, i = t || (() => null), s = r; if (n && typeof n == "object") {
        let u = n;
        o = u.next?.bind(u), i = u.error?.bind(u), s = u.complete?.bind(u);
    } this.__isAsync && (i = this.wrapInTimeout(i), o && (o = this.wrapInTimeout(o)), s && (s = this.wrapInTimeout(s))); let c = super.subscribe({ next: o, error: i, complete: s }); return n instanceof hr && n.add(c), c; }
    wrapInTimeout(n) { return t => { let r = this.pendingTasks?.add(); setTimeout(() => { try {
        n(t);
    }
    finally {
        r !== void 0 && this.pendingTasks?.remove(r);
    } }); }; }
}, F = sn;
function Ee(...e) { }
function So(e) { let n, t; function r() { e = Ee; try {
    t !== void 0 && typeof cancelAnimationFrame == "function" && cancelAnimationFrame(t), n !== void 0 && clearTimeout(n);
}
catch { } } return n = setTimeout(() => { e(), r(); }), typeof requestAnimationFrame == "function" && (t = requestAnimationFrame(() => { e(), r(); })), () => r(); }
function qu(e) { return queueMicrotask(() => e()), () => { e = Ee; }; }
var En = "isAngularZone", tt = En + "_ID", Fo = 0, un = class e {
    hasPendingMacrotasks = !1;
    hasPendingMicrotasks = !1;
    isStable = !0;
    onUnstable = new F(!1);
    onMicrotaskEmpty = new F(!1);
    onStable = new F(!1);
    onError = new F(!1);
    constructor(n) { let { enableLongStackTrace: t = !1, shouldCoalesceEventChangeDetection: r = !1, shouldCoalesceRunChangeDetection: o = !1, scheduleInRootZone: i = Mo } = n; if (typeof Zone > "u")
        throw new g(908, !1); Zone.assertZonePatched(); let s = this; s._nesting = 0, s._outer = s._inner = Zone.current, Zone.TaskTrackingZoneSpec && (s._inner = s._inner.fork(new Zone.TaskTrackingZoneSpec)), t && Zone.longStackTraceZoneSpec && (s._inner = s._inner.fork(Zone.longStackTraceZoneSpec)), s.shouldCoalesceEventChangeDetection = !o && r, s.shouldCoalesceRunChangeDetection = o, s.callbackScheduled = !1, s.scheduleInRootZone = i, Oo(s); }
    static isInAngularZone() { return typeof Zone < "u" && Zone.current.get(En) === !0; }
    static assertInAngularZone() { if (!e.isInAngularZone())
        throw new g(909, !1); }
    static assertNotInAngularZone() { if (e.isInAngularZone())
        throw new g(909, !1); }
    run(n, t, r) { return this._inner.run(n, t, r); }
    runTask(n, t, r, o) { let i = this._inner, s = i.scheduleEventTask("NgZoneEvent: " + o, n, xo, Ee, Ee); try {
        return i.runTask(s, t, r);
    }
    finally {
        i.cancelTask(s);
    } }
    runGuarded(n, t, r) { return this._inner.runGuarded(n, t, r); }
    runOutsideAngular(n) { return this._outer.run(n); }
}, xo = {};
function In(e) { if (e._nesting == 0 && !e.hasPendingMicrotasks && !e.isStable)
    try {
        e._nesting++, e.onMicrotaskEmpty.emit(null);
    }
    finally {
        if (e._nesting--, !e.hasPendingMicrotasks)
            try {
                e.runOutsideAngular(() => e.onStable.emit(null));
            }
            finally {
                e.isStable = !0;
            }
    } }
function Ro(e) { if (e.isCheckStableRunning || e.callbackScheduled)
    return; e.callbackScheduled = !0; function n() { So(() => { e.callbackScheduled = !1, an(e), e.isCheckStableRunning = !0, In(e), e.isCheckStableRunning = !1; }); } e.scheduleInRootZone ? Zone.root.run(() => { n(); }) : e._outer.run(() => { n(); }), an(e); }
function Oo(e) { let n = () => { Ro(e); }, t = Fo++; e._inner = e._inner.fork({ name: "angular", properties: { [En]: !0, [tt]: t, [tt + t]: !0 }, onInvokeTask: (r, o, i, s, c, u) => { if (ko(u))
        return r.invokeTask(i, s, c, u); try {
        return rt(e), r.invokeTask(i, s, c, u);
    }
    finally {
        (e.shouldCoalesceEventChangeDetection && s.type === "eventTask" || e.shouldCoalesceRunChangeDetection) && n(), ot(e);
    } }, onInvoke: (r, o, i, s, c, u, d) => { try {
        return rt(e), r.invoke(i, s, c, u, d);
    }
    finally {
        e.shouldCoalesceRunChangeDetection && !e.callbackScheduled && !jo(u) && n(), ot(e);
    } }, onHasTask: (r, o, i, s) => { r.hasTask(i, s), o === i && (s.change == "microTask" ? (e._hasPendingMicrotasks = s.microTask, an(e), In(e)) : s.change == "macroTask" && (e.hasPendingMacrotasks = s.macroTask)); }, onHandleError: (r, o, i, s) => (r.handleError(i, s), e.runOutsideAngular(() => e.onError.emit(s)), !1) }); }
function an(e) { e._hasPendingMicrotasks || (e.shouldCoalesceEventChangeDetection || e.shouldCoalesceRunChangeDetection) && e.callbackScheduled === !0 ? e.hasPendingMicrotasks = !0 : e.hasPendingMicrotasks = !1; }
function rt(e) { e._nesting++, e.isStable && (e.isStable = !1, e.onUnstable.emit(null)); }
function ot(e) { e._nesting--, In(e); }
var it = class {
    hasPendingMicrotasks = !1;
    hasPendingMacrotasks = !1;
    isStable = !0;
    onUnstable = new F;
    onMicrotaskEmpty = new F;
    onStable = new F;
    onError = new F;
    run(n, t, r) { return n.apply(t, r); }
    runGuarded(n, t, r) { return n.apply(t, r); }
    runOutsideAngular(n) { return n(); }
    runTask(n, t, r, o) { return n.apply(t, r); }
};
function ko(e) { return Pt(e, "__ignore_ng_zone__"); }
function jo(e) { return Pt(e, "__scheduler_tick__"); }
function Pt(e, n) { return !Array.isArray(e) || e.length !== 1 ? !1 : e[0]?.data?.[n] === !0; }
var B = class {
    _console = console;
    handleError(n) { this._console.error("ERROR", n); }
}, Lt = new h("", { factory: () => { let e = m(un), n = m(re), t; return r => { e.runOutsideAngular(() => { n.destroyed && !t ? setTimeout(() => { throw r; }) : (t ??= n.get(B), t.handleError(r)); }); }; } }), Uu = { provide: Ce, useValue: () => { let e = m(B, { optional: !0 }); }, multi: !0 }, Ao = new h("", { factory: () => { if (typeof ngServerMode < "u" && ngServerMode)
        return; let e = m(Dn).defaultView; if (!e)
        return; let n = m(Lt), t = i => { n(i.reason), i.preventDefault(); }, r = i => { i.error ? n(i.error) : n(new Error(i.message, { cause: i })), i.preventDefault(); }, o = () => { e.addEventListener("unhandledrejection", t), e.addEventListener("error", r); }; typeof Zone < "u" ? Zone.root.run(o) : o(), m(M).onDestroy(() => { e.removeEventListener("error", r), e.removeEventListener("unhandledrejection", t); }); } });
function Gu() { return vt([Hr(() => { m(Ao); })]); }
function Hu(e) { return null; }
function P(e, n) { let [t, r, o] = Le(e, n?.equal), i = t, s = i[y]; return i.set = r, i.update = o, i.asReadonly = be.bind(i), i; }
function be() { let e = this[y]; if (e.readonlyFn === void 0) {
    let n = () => this();
    n[y] = e, e.readonlyFn = n;
} return e.readonlyFn; }
var Po = new h("", { factory: () => Lo }), Lo = "ng";
var Bu = new h(""), Zu = new h("", { providedIn: "platform", factory: () => "unknown" }), Wu = new h(""), Yu = new h("", { factory: () => m(Dn).body?.querySelector("[ngCspNonce]")?.getAttribute("ngCspNonce") || null }), Vo = { breakpoints: [16, 32, 48, 64, 96, 128, 256, 384, 640, 750, 828, 1080, 1200, 1920, 2048, 3840], placeholderResolution: 30, disableImageSizeWarning: !1, disableImageLazyLoadWarning: !1 }, Ku = new h("", { factory: () => Vo });
function Ju(e) { return e; }
function Ie() { return Object.create(null); }
var Vt = (() => { class e {
    static \u0275prov = Z({ token: e, providedIn: "root", factory: () => { let t = new e; return (typeof ngServerMode > "u" || !ngServerMode) && (t.store = $o(m(Dn), m(Po))), t; } });
    store = Ie();
    onSerializeCallbacks = Ie();
    get(t, r) { if (!Object.hasOwn(this.store, t))
        return r; let o = this.store[t]; return o !== void 0 ? o : r; }
    set(t, r) { this.store[t] = r; }
    remove(t) { delete this.store[t]; }
    hasKey(t) { return Object.hasOwn(this.store, t); }
    get isEmpty() { return Object.keys(this.store).length === 0; }
    onSerialize(t, r) { this.onSerializeCallbacks[t] = r; }
    toJson() { for (let t in this.onSerializeCallbacks)
        if (Object.hasOwn(this.onSerializeCallbacks, t))
            try {
                this.store[t] = this.onSerializeCallbacks[t]();
            }
            catch (r) {
                console.warn("Exception in onSerialize callback: ", r);
            } return JSON.stringify(this.store).replace(/</g, "\\u003C").replace(/\//g, "\\u002F"); }
} return e; })();
function $o(e, n) { let t = e.getElementById(n + "-state"); if (t?.tagName === "SCRIPT" && t.textContent)
    try {
        return Object.assign(Ie(), JSON.parse(t.textContent));
    }
    catch (r) {
        console.warn("Exception while restoring TransferState for app " + n, r);
    } return Ie(); }
function Qu(e, n) { if (Re() !== null)
    throw new g(-602, !1); }
var $t = (() => { class e {
    view;
    node;
    constructor(t, r) { this.view = t, this.node = r; }
    static __NG_ELEMENT_ID__ = qo;
} return e; })();
function qo() { return new $t(xt(), Do()); }
var we = class {
}, Xu = new h("", { factory: () => !0 }), zu = new h("", { factory: () => !1 }), ea = new h(""), Uo = (() => { class e {
    static \u0275prov = Z({ token: e, providedIn: "root", factory: () => new cn });
} return e; })(), cn = class {
    dirtyEffectCount = 0;
    queues = new Map;
    add(n) { this.enqueue(n), this.schedule(n); }
    schedule(n) { n.dirty && this.dirtyEffectCount++; }
    remove(n) { let t = n.zone, r = this.queues.get(t); r.has(n) && (r.delete(n), n.dirty && this.dirtyEffectCount--); }
    enqueue(n) { let t = n.zone; this.queues.has(t) || this.queues.set(t, new Set); let r = this.queues.get(t); r.has(n) || r.add(n); }
    flush() { for (; this.dirtyEffectCount > 0;) {
        let n = !1;
        for (let [t, r] of this.queues)
            t === null ? n ||= this.flushQueue(r) : n ||= t.run(() => this.flushQueue(r));
        n || (this.dirtyEffectCount = 0);
    } }
    flushQueue(n) { let t = !1; for (let r of n)
        r.dirty && (this.dirtyEffectCount--, t = !0, r.run()); return t; }
}, dn = class {
    [y];
    constructor(n) { this[y] = n; }
    destroy() { this[y].destroy(); }
};
function qt(e, n) { let t = n?.injector ?? m(oe), r = n?.manualCleanup !== !0 ? t.get(M) : null, o, i = t.get($t, null, { optional: !0 }), s = t.get(we); return i !== null ? (o = Bo(i.view, s, e), r instanceof De && r._lView === i.view && (r = null)) : o = Zo(e, t.get(Uo), s), o.injector = t, r !== null && (o.onDestroyFns = [r.onDestroy(() => o.destroy())]), new dn(o); }
var Ut = w(I({}, Ve), { cleanupFns: void 0, zone: null, onDestroyFns: null, run() { let e = et(!1); try {
        $e(this);
    }
    finally {
        et(e);
    } }, cleanup() { if (!this.cleanupFns?.length)
        return; let e = p(null); try {
        for (; this.cleanupFns.length;)
            this.cleanupFns.pop()();
    }
    finally {
        this.cleanupFns = [], p(e);
    } } }), Go = w(I({}, Ut), { consumerMarkedDirty() { this.scheduler.schedule(this), this.notifier.notify(12); }, destroy() { if (je(this), this.onDestroyFns !== null)
        for (let e of this.onDestroyFns)
            e(); this.cleanup(), this.scheduler.remove(this); } }), Ho = w(I({}, Ut), { consumerMarkedDirty() { this.view[D] |= 8192, yn(this.view), this.notifier.notify(13); }, destroy() { if (je(this), this.onDestroyFns !== null)
        for (let e of this.onDestroyFns)
            e(); this.cleanup(), this.view[nn]?.delete(this); } });
function Bo(e, n, t) { let r = Object.create(Ho); return r.view = e, r.zone = typeof Zone < "u" ? Zone.current : null, r.notifier = n, r.fn = Gt(r, t), e[nn] ??= new Set, e[nn].add(r), r.consumerMarkedDirty(r), r; }
function Zo(e, n, t) { let r = Object.create(Go); return r.fn = Gt(r, e), r.scheduler = n, r.notifier = t, r.zone = typeof Zone < "u" ? Zone.current : null, r.scheduler.add(r), r.notifier.notify(12), r; }
function Gt(e, n) { return () => { n(t => (e.cleanupFns ??= []).push(t)); }; }
function wn(e) { return typeof e == "function" && e[y] !== void 0; }
function na(e) { return wn(e) && typeof e.set == "function"; }
var Ht = (() => { class e {
    internalPendingTasks = m(At);
    scheduler = m(we);
    errorHandler = m(Lt);
    add() { let t = this.internalPendingTasks.add(); return () => { this.internalPendingTasks.has(t) && (this.scheduler.notify(11), this.internalPendingTasks.remove(t)); }; }
    run(t) { let r = this.add(); try {
        t().catch(this.errorHandler).finally(r);
    }
    catch (o) {
        this.errorHandler(o), r();
    } }
    static \u0275prov = Z({ token: e, providedIn: "root", factory: () => new e });
} return e; })();
var Bt = class {
    destroyed = !1;
    listeners = null;
    errorHandler = m(B, { optional: !0 });
    isEmitting = !1;
    hasNullListeners = !1;
    destroyRef = m(M);
    constructor() { this.destroyRef.onDestroy(() => { this.destroyed = !0, this.listeners = null; }); }
    subscribe(n) { if (this.destroyed)
        throw new g(953, !1); return (this.listeners ??= []).push(n), { unsubscribe: () => { let t = this.listeners ? this.listeners.indexOf(n) : -1; t > -1 && (this.isEmitting ? (this.hasNullListeners = !0, this.listeners[t] = null) : this.listeners.splice(t, 1)); } }; }
    emit(n) { if (this.destroyed) {
        console.warn(ln(953, !1));
        return;
    } if (this.listeners === null)
        return; this.isEmitting = !0; let t = p(null); try {
        for (let r of this.listeners)
            try {
                r !== null && r(n);
            }
            catch (o) {
                this.errorHandler?.handleError(o);
            }
    }
    finally {
        this.hasNullListeners && (this.hasNullListeners = !1, this.listeners && Wo(this.listeners)), p(t), this.isEmitting = !1;
    } }
};
function Wo(e) { let n = e.length - 1; for (; n > -1;)
    e[n] === null && e.splice(n, 1), n--; }
function aa(e) { return e.destroyRef; }
var Yo = new h("");
function L(e, n) { return Pe(e, n?.equal); }
function E(e) { return Hn(e); }
var Tn = class extends Error {
    dependency;
    constructor(n) { super("Dependency error", { cause: n.error() }), this.name = "ResourceDependencyError", this.dependency = n; }
}, W = class e extends Error {
    _brand;
    constructor(n) { super(n); }
    static IDLE = new e("IDLE");
    static LOADING = new e("LOADING");
}, Ko = e => e;
function Zt(e, n) { if (typeof e == "function") {
    let t = Ue(e, Ko, n?.equal);
    return Wt(t, n?.debugName, n?.set);
}
else {
    let t = Ue(e.source, e.computation, e.equal);
    return Wt(t, e.debugName, e.set);
} }
function Wt(e, n, t) { let r = e[y], o = e; if (t !== void 0) {
    let i = s => Ge(r, s);
    o.set = s => t(s, i), o.update = s => t(s(E(e)), i);
}
else
    o.set = i => Ge(r, i), o.update = i => Gn(r, i); return o.asReadonly = be.bind(e), o; }
function ca(e) { let n = e.request, t = e.params ?? n ?? (() => null); return new Cn(t, Qo(e), e.defaultValue, e.equal ? Jo(e.equal) : void 0, e.debugName, e.injector ?? m(oe), e.id); }
var Nn = class {
    value;
    isLoading;
    constructor(n, t) { this.value = n, this.value.set = this.set.bind(this), this.value.update = this.update.bind(this), this.value.asReadonly = be, this.isLoading = L(() => this.status() === "loading" || this.status() === "reloading", void 0); }
    isError = L(() => this.status() === "error");
    update(n) { this.set(n(E(this.value))); }
    isValueDefined = L(() => this.isError() ? !1 : this.value() !== void 0);
    _snapshot;
    get snapshot() { return this._snapshot ??= L(() => { let n = this.status(); return n === "error" ? { status: "error", error: this.error() } : { status: n, value: this.value() }; }); }
    hasValue() { return this.isValueDefined(); }
    asReadonly() { return this; }
}, Cn = class extends Nn {
    loaderFn;
    equal;
    debugName;
    transferCacheKey;
    pendingTasks;
    state;
    extRequest;
    effectRef;
    pendingController;
    resolvePendingTask = void 0;
    destroyed = !1;
    unregisterOnDestroy;
    status;
    error;
    transferState;
    constructor(n, t, r, o, i, s, c, u) { if (ti())
        throw ri(); super(L(() => { let f = this.state().stream?.(); if (!f || this.state().status === "loading" && this.error())
        return r; if (!Me(f))
        throw new Mn(this.error()); return f.value; }, { equal: o }), i), this.loaderFn = t, this.equal = o, this.debugName = i, this.transferCacheKey = c; let d = s.get(Yo, void 0, { optional: !0 }) ?? { isActive: !1 }; this.transferState = s.get(Vt, void 0, { optional: !0 }) ?? void 0, this.extRequest = Zt(() => { try {
        return Jt(!0), { request: n(ni), reload: 0 };
    }
    catch (f) {
        return Qt(f), f === W.IDLE ? { status: "idle", reload: 0 } : f === W.LOADING ? { status: "loading", reload: 0 } : { error: f, reload: 0 };
    }
    finally {
        Jt(!1);
    } }, void 0), this.state = Zt({ source: this.extRequest, computation: (f, Y) => { let { request: se, status: K, error: Sn } = f, x; if (Sn)
            K = "resolved", x = P({ error: bn(Sn) }, void 0);
        else if (!K)
            if (Y)
                K = se === void 0 ? "idle" : "loading", Y.value.extRequest.request === se && (x = Y.value.stream);
            else {
                let _e = this.transferState, Se = this.transferCacheKey;
                d.isActive && Se && _e && se !== void 0 && _e.hasKey(Se) && (x = P({ value: _e.get(Se, r) }, void 0)), x || (x = u?.(f.request)), u = void 0, K = se === void 0 ? "idle" : x ? "resolved" : "loading";
            } return { extRequest: f, status: K, previousStatus: Y ? Kt(Y.value) : "idle", stream: x }; } }), this.effectRef = qt(this.loadEffect.bind(this), { injector: s, manualCleanup: !0 }), this.pendingTasks = s.get(Ht), this.unregisterOnDestroy = s.get(M).onDestroy(() => this.destroy()), this.status = L(() => Kt(this.state()), void 0), this.error = L(() => { let f = this.state().stream?.(); return f && !Me(f) ? f.error : void 0; }, void 0); }
    set(n) { if (this.destroyed)
        return; let t = E(this.error), r = E(this.state); if (!t) {
        let o = E(this.value);
        if (r.status === "local" && (this.equal ? this.equal(o, n) : o === n))
            return;
    } this.state.set({ extRequest: r.extRequest, status: "local", previousStatus: "local", stream: P({ value: n }, void 0) }), this.abortInProgressLoad(); }
    reload() { let { status: n } = E(this.state); return n === "idle" || n === "loading" ? !1 : (this.extRequest.update(({ request: t, reload: r }) => ({ request: t, reload: r + 1 })), !0); }
    destroy() { this.destroyed = !0, this.unregisterOnDestroy(), this.effectRef.destroy(), this.abortInProgressLoad(), this.state.set({ extRequest: { request: void 0, reload: 0 }, status: "idle", previousStatus: "idle", stream: void 0 }); }
    loadEffect() { return xe(this, null, function* () { let n = this.extRequest(), { status: t, previousStatus: r } = E(this.state); if (n.request === void 0)
        return; if (t !== "loading")
        return; this.abortInProgressLoad(); let o = this.resolvePendingTask = this.pendingTasks.add(), { signal: i } = this.pendingController = new AbortController; try {
        let s = E(() => this.loaderFn({ params: n.request, abortSignal: i, previous: { status: r } })), c = () => i.aborted || E(this.extRequest) !== n;
        if (wn(s)) {
            if (c())
                return;
            this.state.set({ extRequest: n, status: "resolved", previousStatus: "resolved", stream: s });
            let u = E(s);
            typeof ngServerMode < "u" && ngServerMode && Yt(u, this.transferCacheKey, this.transferState);
        }
        else {
            let u = yield s;
            if (c())
                return;
            this.state.set({ extRequest: n, status: "resolved", previousStatus: "resolved", stream: u });
            let d = u ? E(u) : void 0;
            typeof ngServerMode < "u" && ngServerMode && Yt(d, this.transferCacheKey, this.transferState);
        }
    }
    catch (s) {
        if (Qt(s), i.aborted || E(this.extRequest) !== n)
            return;
        this.state.set({ extRequest: n, status: "resolved", previousStatus: "error", stream: P({ error: bn(s) }, void 0) });
    }
    finally {
        o?.(), o = void 0;
    } }); }
    abortInProgressLoad() { E(() => this.pendingController?.abort()), this.pendingController = void 0, this.resolvePendingTask?.(), this.resolvePendingTask = void 0; }
};
function Yt(e, n, t) { n && t && e && Me(e) && t.set(n, e.value); }
function Jo(e) { return (n, t) => n === void 0 || t === void 0 ? n === t : e(n, t); }
function Qo(e) { return Xo(e) ? e.stream : n => xe(null, null, function* () { try {
    return P({ value: yield e.loader(n) }, void 0);
}
catch (t) {
    return P({ error: bn(t) }, void 0);
} }); }
function Xo(e) { return !!e.stream; }
function Kt(e) { switch (e.status) {
    case "loading": return e.extRequest.reload === 0 ? "loading" : "reloading";
    case "resolved": return Me(e.stream()) ? "resolved" : "error";
    default: return e.status;
} }
function Me(e) { return e.error === void 0; }
function bn(e) { return zo(e) ? e : new _n(e); }
function zo(e) { return e instanceof Error || typeof e == "object" && typeof e.name == "string" && typeof e.message == "string"; }
var Mn = class extends Error {
    constructor(n) { super(n.message, { cause: n }); }
}, _n = class extends Error {
    constructor(n) { super(String(n), { cause: n }); }
};
function ei(e) { switch (e.status()) {
    case "idle": throw W.IDLE;
    case "error": throw new Tn(e);
    case "loading":
    case "reloading": throw W.LOADING;
} return e.value(); }
var ni = { chain: ei }, Xt = !1;
function ti() { return Xt; }
function Jt(e) { Xt = e; }
function ri() { return new g(992, !1); }
function Qt(e) { if (e instanceof g && e.code === 992)
    throw e; }
export { I as a, w as b, oi as c, xe as d, ii as e, y as f, p as g, Re as h, J as i, Q as j, ce as k, de as l, An as m, je as n, Pe as o, ar as p, ee as q, qn as r, C as s, gi as t, Be as u, Bn as v, mr as w, Oi as x, g as y, ln as z, l as A, ki as B, yr as C, ji as D, Ai as E, st as F, b as G, Er as H, Ir as I, ie as J, Z as K, Pi as L, Te as M, Li as N, Zn as O, at as P, Wn as Q, h as R, Vi as S, ct as T, Nr as U, Cr as V, br as W, Mr as X, Kn as Y, $i as Z, _r as _, qi as $, dt as aa, Sr as ba, Fr as ca, Ui as da, xr as ea, Gi as fa, kr as ga, jr as ha, S as ia, Pr as ja, Hi as ka, H as la, Bi as ma, m as na, pe as oa, Zi as pa, he as qa, Wi as ra, Yi as sa, fn as ta, Ki as ua, Ji as va, Qi as wa, Xi as xa, Ur as ya, zi as za, es as Aa, pt as Ba, ns as Ca, me as Da, Ce as Ea, ht as Fa, mt as Ga, ve as Ha, vt as Ia, Hr as Ja, Br as Ka, Zr as La, Je as Ma, Qe as Na, ts as Oa, Jr as Pa, Et as Qa, re as Ra, ye as Sa, zr as Ta, rs as Ua, It as Va, os as Wa, pn as Xa, hn as Ya, D as Za, en as _a, is as $a, ro as ab, ss as bb, oo as cb, wt as db, us as eb, Tt as fb, as as gb, cs as hb, ds as ib, Nt as jb, ls as kb, fs as lb, io as mb, gs as nb, ps as ob, hs as pb, G as qb, ms as rb, nn as sb, so as tb, vs as ub, ys as vb, uo as wb, Ds as xb, Es as yb, Is as zb, ws as Ab, Ts as Bb, Ct as Cb, bt as Db, Ns as Eb, Cs as Fb, bs as Gb, Ms as Hb, _s as Ib, Ss as Jb, Fs as Kb, Mt as Lb, xs as Mb, co as Nb, Rs as Ob, T as Pb, tn as Qb, _t as Rb, Os as Sb, vn as Tb, ks as Ub, js as Vb, As as Wb, Ps as Xb, fo as Yb, Ls as Zb, Vs as _b, $s as $b, qs as ac, Ft as bc, Us as cc, Gs as dc, Hs as ec, Bs as fc, go as gc, po as hc, Zs as ic, yn as jc, ho as kc, mo as lc, zn as mc, vo as nc, yo as oc, Ws as pc, Ys as qc, Ks as rc, Js as sc, Qs as tc, Xs as uc, zs as vc, eu as wc, nu as xc, tu as yc, ru as zc, xt as Ac, ou as Bc, iu as Cc, su as Dc, Do as Ec, Eo as Fc, uu as Gc, au as Hc, cu as Ic, du as Jc, lu as Kc, fu as Lc, et as Mc, gu as Nc, pu as Oc, hu as Pc, mu as Qc, vu as Rc, yu as Sc, Du as Tc, Eu as Uc, Iu as Vc, Io as Wc, wu as Xc, Tu as Yc, Nu as Zc, Cu as _c, bu as $c, Mu as ad, _u as bd, Su as cd, Fu as dd, xu as ed, Ru as fd, Ou as gd, ku as hd, ju as id, Au as jd, Pu as kd, Lu as ld, Vu as md, nt as nd, No as od, $u as pd, oe as qd, Dn as rd, M as sd, Mo as td, _o as ud, At as vd, F as wd, So as xd, qu as yd, tt as zd, un as Ad, it as Bd, B as Cd, Lt as Dd, Uu as Ed, Gu as Fd, Hu as Gd, P as Hd, be as Id, Po as Jd, Bu as Kd, Zu as Ld, Wu as Md, Yu as Nd, Vo as Od, Ku as Pd, Ju as Qd, Vt as Rd, $o as Sd, Qu as Td, $t as Ud, we as Vd, Xu as Wd, zu as Xd, ea as Yd, Uo as Zd, dn as _d, qt as $d, wn as ae, na as be, Ht as ce, Bt as de, aa as ee, Yo as fe, L as ge, E as he, Tn as ie, W as je, Zt as ke, ca as le, Cn as me, bn as ne, Mn as oe, ei as pe, ti as qe, Jt as re, ri as se, Qt as te };
/*! Bundled license information:

@angular/core/fesm2022/_effect-chunk.mjs:
@angular/core/fesm2022/_not_found-chunk.mjs:
@angular/core/fesm2022/_untracked-chunk.mjs:
@angular/core/fesm2022/_weak_ref-chunk.mjs:
@angular/core/fesm2022/primitives-signals.mjs:
@angular/core/fesm2022/primitives-di.mjs:
@angular/core/fesm2022/_pending_tasks-chunk.mjs:
@angular/core/fesm2022/_resource-chunk.mjs:
  (**
   * @license Angular v22.1.4
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
