var hf = Object.defineProperty, ff = Object.defineProperties;
var df = Object.getOwnPropertyDescriptors;
var Dl = Object.getOwnPropertySymbols;
var mf = Object.prototype.hasOwnProperty, gf = Object.prototype.propertyIsEnumerable;
var Pl = (n, e, t) => e in n ? hf(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t, E = (n, e) => { for (var t in e ||= {})
    mf.call(e, t) && Pl(n, t, e[t]); if (Dl)
    for (var t of Dl(e))
        gf.call(e, t) && Pl(n, t, e[t]); return n; }, se = (n, e) => ff(n, df(e));
import * as sa from "@angular/core";
import { Version as w2, ViewEncapsulation as S2, Injector as E2, Compiler as Il, createPlatformFactory as x2, COMPILER_OPTIONS as cf, CompilerFactory as y2 } from "@angular/core";
var Ll = new RegExp(`(\\:not\\()|(([\\.\\#]?)[-\\w]+)|(?:\\[([-.\\w*\\\\$]+)(?:=(["']?)([^\\]"']*)\\5)?\\])|(\\))|(\\s*,\\s*)`, "g"), hr = class n {
    element = null;
    classNames = [];
    attrs = [];
    notSelectors = [];
    static parse(e) { let t = [], s = (c, l) => { l.notSelectors.length > 0 && !l.element && l.classNames.length == 0 && l.attrs.length == 0 && (l.element = "*"), c.push(l); }, r = new n, i, o = r, a = !1; for (Ll.lastIndex = 0; i = Ll.exec(e);) {
        if (i[1]) {
            if (a)
                throw new Error("Nesting :not in a selector is not allowed");
            a = !0, o = new n, r.notSelectors.push(o);
        }
        let c = i[2];
        if (c) {
            let p = i[3];
            p === "#" ? o.addAttribute("id", c.slice(1)) : p === "." ? o.addClassName(c.slice(1)) : o.setElement(c);
        }
        let l = i[4];
        if (l && o.addAttribute(o.unescapeAttribute(l), i[6]), i[7] && (a = !1, o = r), i[8]) {
            if (a)
                throw new Error("Multiple selectors in :not are not supported");
            s(t, r), r = o = new n;
        }
    } return s(t, r), t; }
    unescapeAttribute(e) { let t = "", s = !1; for (let r = 0; r < e.length; r++) {
        let i = e.charAt(r);
        if (i === "\\") {
            s = !0;
            continue;
        }
        if (i === "$" && !s)
            throw new Error(`Error in attribute selector "${e}". Unescaped "$" is not supported. Please escape with "\\$".`);
        s = !1, t += i;
    } return t; }
    escapeAttribute(e) { return e.replace(/\\/g, "\\\\").replace(/\$/g, "\\$"); }
    isElementSelector() { return this.hasElementSelector() && this.classNames.length == 0 && this.attrs.length == 0 && this.notSelectors.length === 0; }
    hasElementSelector() { return !!this.element; }
    setElement(e = null) { this.element = e; }
    getAttrs() { let e = []; return this.classNames.length > 0 && e.push("class", this.classNames.join(" ")), e.concat(this.attrs); }
    addAttribute(e, t = "") { this.attrs.push(e, t && t.toLowerCase() || ""); }
    addClassName(e) { this.classNames.push(e.toLowerCase()); }
    toString() { let e = this.element || ""; if (this.classNames && this.classNames.forEach(t => e += `.${t}`), this.attrs)
        for (let t = 0; t < this.attrs.length; t += 2) {
            let s = this.escapeAttribute(this.attrs[t]), r = this.attrs[t + 1];
            e += `[${s}${r ? "=" + r : ""}]`;
        } return this.notSelectors.forEach(t => e += `:not(${t})`), e; }
}, Hi = class n {
    static createNotMatcher(e) { let t = new n; return t.addSelectables(e, null), t; }
    _elementMap = new Map;
    _elementPartialMap = new Map;
    _classMap = new Map;
    _classPartialMap = new Map;
    _attrValueMap = new Map;
    _attrValuePartialMap = new Map;
    _listContexts = [];
    addSelectables(e, t) { let s = null; e.length > 1 && (s = new Aa(e), this._listContexts.push(s)); for (let r = 0; r < e.length; r++)
        this._addSelectable(e[r], t, s); }
    _addSelectable(e, t, s) { let r = this, i = e.element, o = e.classNames, a = e.attrs, c = new ka(e, t, s); if (i && (a.length === 0 && o.length === 0 ? this._addTerminal(r._elementMap, i, c) : r = this._addPartial(r._elementPartialMap, i)), o)
        for (let l = 0; l < o.length; l++) {
            let p = a.length === 0 && l === o.length - 1, h = o[l];
            p ? this._addTerminal(r._classMap, h, c) : r = this._addPartial(r._classPartialMap, h);
        } if (a)
        for (let l = 0; l < a.length; l += 2) {
            let p = l === a.length - 2, h = a[l], d = a[l + 1];
            if (p) {
                let v = r._attrValueMap, w = v.get(h);
                w || (w = new Map, v.set(h, w)), this._addTerminal(w, d, c);
            }
            else {
                let v = r._attrValuePartialMap, w = v.get(h);
                w || (w = new Map, v.set(h, w)), r = this._addPartial(w, d);
            }
        } }
    _addTerminal(e, t, s) { let r = e.get(t); r || (r = [], e.set(t, r)), r.push(s); }
    _addPartial(e, t) { let s = e.get(t); return s || (s = new n, e.set(t, s)), s; }
    match(e, t) { let s = !1, r = e.element, i = e.classNames, o = e.attrs; for (let a = 0; a < this._listContexts.length; a++)
        this._listContexts[a].alreadyMatched = !1; if (s = this._matchTerminal(this._elementMap, r, e, t) || s, s = this._matchPartial(this._elementPartialMap, r, e, t) || s, i)
        for (let a = 0; a < i.length; a++) {
            let c = i[a];
            s = this._matchTerminal(this._classMap, c, e, t) || s, s = this._matchPartial(this._classPartialMap, c, e, t) || s;
        } if (o)
        for (let a = 0; a < o.length; a += 2) {
            let c = o[a], l = o[a + 1], p = this._attrValueMap.get(c);
            l && (s = this._matchTerminal(p, "", e, t) || s), s = this._matchTerminal(p, l, e, t) || s;
            let h = this._attrValuePartialMap.get(c);
            l && (s = this._matchPartial(h, "", e, t) || s), s = this._matchPartial(h, l, e, t) || s;
        } return s; }
    _matchTerminal(e, t, s, r) { if (!e || typeof t != "string")
        return !1; let i = e.get(t) || [], o = e.get("*"); if (o && (i = i.concat(o)), i.length === 0)
        return !1; let a, c = !1; for (let l = 0; l < i.length; l++)
        a = i[l], c = a.finalize(s, r) || c; return c; }
    _matchPartial(e, t, s, r) { if (!e || typeof t != "string")
        return !1; let i = e.get(t); return i ? i.match(s, r) : !1; }
}, Aa = class {
    selectors;
    alreadyMatched = !1;
    constructor(e) { this.selectors = e; }
}, ka = class {
    selector;
    cbContext;
    listContext;
    notSelectors;
    constructor(e, t, s) { this.selector = e, this.cbContext = t, this.listContext = s, this.notSelectors = e.notSelectors; }
    finalize(e, t) { let s = !0; return this.notSelectors.length > 0 && (!this.listContext || !this.listContext.alreadyMatched) && (s = !Hi.createNotMatcher(this.notSelectors).match(e, null)), s && t && (!this.listContext || !this.listContext.alreadyMatched) && (this.listContext && (this.listContext.alreadyMatched = !0), t(this.selector, this.cbContext)), s; }
}, fr = class {
    registry;
    constructor(e) { this.registry = e; }
    match(e) { return this.registry.has(e) ? this.registry.get(e) : []; }
}, V = (function (n) { return n[n.NONE = 0] = "NONE", n[n.HTML = 1] = "HTML", n[n.STYLE = 2] = "STYLE", n[n.SCRIPT = 3] = "SCRIPT", n[n.URL = 4] = "URL", n[n.RESOURCE_URL = 5] = "RESOURCE_URL", n[n.ATTRIBUTE_NO_BINDING = 6] = "ATTRIBUTE_NO_BINDING", n; })(V || {}), Ys, Bl = "svg", vf = "math", Tp = "", $l = "*", Ta = () => Object.create(null);
function wf() { return Ys || (Ys = Ta(), Gt(V.HTML, void 0, [["iframe", ["srcdoc"]], ["*", ["innerHTML", "outerHTML"]]]), Gt(V.STYLE, void 0, [["*", ["style"]]]), Gt(V.URL, void 0, [["*", ["formAction"]], ["area", ["href"]], ["a", ["href", "xlink:href"]], ["form", ["action"]], ["img", ["src"]], ["video", ["src"]]]), Gt(V.URL, vf, [["*", ["href", "xlink:href"]]]), Gt(V.RESOURCE_URL, void 0, [["base", ["href"]], ["embed", ["src"]], ["frame", ["src"]], ["iframe", ["src"]], ["link", ["href"]], ["object", ["codebase", "data"]]]), Gt(V.URL, Bl, [["a", ["href", "xlink:href"]]]), Gt(V.ATTRIBUTE_NO_BINDING, Bl, [["animate", ["attributeName", "values", "to", "from"]], ["set", ["to", "attributeName"]], ["animateMotion", ["attributeName"]], ["animateTransform", ["attributeName"]]]), Gt(V.ATTRIBUTE_NO_BINDING, void 0, [["unknown", ["attributeName", "values", "to", "from", "sandbox", "allow", "allowFullscreen", "referrerPolicy", "csp", "fetchPriority", "credentialless"]], ["iframe", ["sandbox", "allow", "allowFullscreen", "referrerPolicy", "csp", "fetchPriority", "credentialless"]]]), Ys); }
function Gt(n, e, t) { let s = e ?? Tp; for (let [r, i] of t) {
    let o = r.toLowerCase();
    for (let a of i) {
        let c = a.toLowerCase(), l = Ys[c] ??= Ta(), p = l[s] ??= Ta();
        p[o] = n;
    }
} }
function Sf(n, e, t) { let r = wf()[e.toLowerCase()]; if (!r)
    return V.NONE; let i = n.toLowerCase(), o; if (t) {
    let a = r[t];
    a && (o = a[i] ?? a[$l]);
} if (o === void 0) {
    let a = r[Tp];
    a && (o = a[i] ?? a[$l]);
} return o ?? V.NONE; }
var en = (function (n) { return n[n.Emulated = 0] = "Emulated", n[n.None = 2] = "None", n[n.ShadowDom = 3] = "ShadowDom", n[n.ExperimentalIsolatedShadowDom = 4] = "ExperimentalIsolatedShadowDom", n; })(en || {}), sl = (function (n) { return n[n.OnPush = 0] = "OnPush", n[n.Default = 1] = "Default", n[n.Eager = 1] = "Eager", n; })(sl || {}), Zs = (function (n) { return n[n.None = 0] = "None", n[n.SignalBased = 1] = "SignalBased", n[n.HasDecoratorInputTransform = 2] = "HasDecoratorInputTransform", n; })(Zs || {}), Ml = { name: "custom-elements" }, Rl = { name: "no-errors-schema" };
function Ef(n) { let e = n.classNames && n.classNames.length ? [8, ...n.classNames] : []; return [n.element && n.element !== "*" ? n.element : "", ...n.attrs, ...e]; }
function xf(n) { let e = n.classNames && n.classNames.length ? [8, ...n.classNames] : []; return n.element ? [5, n.element, ...n.attrs, ...e] : n.attrs.length ? [3, ...n.attrs, ...e] : n.classNames && n.classNames.length ? [9, ...n.classNames] : []; }
function yf(n) { let e = Ef(n), t = n.notSelectors && n.notSelectors.length ? n.notSelectors.map(s => xf(s)) : []; return e.concat(...t); }
function rl(n) { return n ? hr.parse(n).map(yf) : []; }
var Rt = (function (n) { return n[n.Directive = 0] = "Directive", n[n.Component = 1] = "Component", n[n.Injectable = 2] = "Injectable", n[n.Pipe = 3] = "Pipe", n[n.NgModule = 4] = "NgModule", n[n.Service = 5] = "Service", n; })(Rt || {});
var Ui;
function Cf(n) { return Tf(kf(n.nodes).join("") + `[${n.meaning}]`); }
function bf(n) { return n.id || _p(n); }
function _p(n) { let e = new _a, t = n.nodes.map(s => s.visit(e, null)); return Ip(t.join(""), n.meaning); }
var Wi = class {
    visitText(e, t) { return e.value; }
    visitContainer(e, t) { return `[${e.children.map(s => s.visit(this)).join(", ")}]`; }
    visitIcu(e, t) { let s = Object.keys(e.cases).map(r => `${r} {${e.cases[r].visit(this)}}`); return `{${e.expression}, ${e.type}, ${s.join(", ")}}`; }
    visitTagPlaceholder(e, t) { return e.isVoid ? `<ph tag name="${e.startName}"/>` : `<ph tag name="${e.startName}">${e.children.map(s => s.visit(this)).join(", ")}</ph name="${e.closeName}">`; }
    visitPlaceholder(e, t) { return e.value ? `<ph name="${e.name}">${e.value}</ph>` : `<ph name="${e.name}"/>`; }
    visitIcuPlaceholder(e, t) { return `<ph icu name="${e.name}">${e.value.visit(this)}</ph>`; }
    visitBlockPlaceholder(e, t) { return `<ph block name="${e.startName}">${e.children.map(s => s.visit(this)).join(", ")}</ph name="${e.closeName}">`; }
}, Af = new Wi;
function kf(n) { return n.map(e => e.visit(Af, null)); }
var _a = class extends Wi {
    visitIcu(e) { let t = Object.keys(e.cases).map(s => `${s} {${e.cases[s].visit(this)}}`); return `{${e.type}, ${t.join(", ")}}`; }
};
function Tf(n) { Ui ??= new TextEncoder; let e = [...Ui.encode(n)], t = Nf(e, il.Big), s = e.length * 8, r = new Uint32Array(80), i = 1732584193, o = 4023233417, a = 2562383102, c = 271733878, l = 3285377520; t[s >> 5] |= 128 << 24 - s % 32, t[(s + 64 >> 9 << 4) + 15] = s; for (let p = 0; p < t.length; p += 16) {
    let h = i, d = o, v = a, w = c, y = l;
    for (let b = 0; b < 80; b++) {
        b < 16 ? r[b] = t[p + b] : r[b] = ia(r[b - 3] ^ r[b - 8] ^ r[b - 14] ^ r[b - 16], 1);
        let T = _f(b, o, a, c), $ = T[0], W = T[1], J = [ia(i, 5), $, l, W, r[b]].reduce(es);
        l = c, c = a, a = ia(o, 30), o = i, i = J;
    }
    i = es(i, h), o = es(o, d), a = es(a, v), c = es(c, w), l = es(l, y);
} return qs(i) + qs(o) + qs(a) + qs(c) + qs(l); }
function qs(n) { return (n >>> 0).toString(16).padStart(8, "0"); }
function _f(n, e, t, s) { return n < 20 ? [e & t | ~e & s, 1518500249] : n < 40 ? [e ^ t ^ s, 1859775393] : n < 60 ? [e & t | e & s | t & s, 2400959708] : [e ^ t ^ s, 3395469782]; }
function Fl(n) { Ui ??= new TextEncoder; let e = Ui.encode(n), t = new DataView(e.buffer, e.byteOffset, e.byteLength), s = Ol(t, e.length, 0), r = Ol(t, e.length, 102072); return s == 0 && (r == 0 || r == 1) && (s = s ^ 319790063, r = r ^ -1801410264), BigInt.asUintN(32, BigInt(s)) << BigInt(32) | BigInt.asUintN(32, BigInt(r)); }
function Ip(n, e = "") { let t = Fl(n); return e && (t = BigInt.asUintN(64, t << BigInt(1)) | t >> BigInt(63) & BigInt(1), t += Fl(e)), BigInt.asUintN(63, t).toString(); }
function Ol(n, e, t) { let s = 2654435769, r = 2654435769, i = 0, o = e - 12; for (; i <= o; i += 12) {
    s += n.getUint32(i, !0), r += n.getUint32(i + 4, !0), t += n.getUint32(i + 8, !0);
    let c = Vl(s, r, t);
    s = c[0], r = c[1], t = c[2];
} let a = e - i; return t += e, a >= 4 ? (s += n.getUint32(i, !0), i += 4, a >= 8 ? (r += n.getUint32(i, !0), i += 4, a >= 9 && (t += n.getUint8(i++) << 8), a >= 10 && (t += n.getUint8(i++) << 16), a === 11 && (t += n.getUint8(i++) << 24)) : (a >= 5 && (r += n.getUint8(i++)), a >= 6 && (r += n.getUint8(i++) << 8), a === 7 && (r += n.getUint8(i++) << 16))) : (a >= 1 && (s += n.getUint8(i++)), a >= 2 && (s += n.getUint8(i++) << 8), a === 3 && (s += n.getUint8(i++) << 16)), Vl(s, r, t)[2]; }
function Vl(n, e, t) { return n -= e, n -= t, n ^= t >>> 13, e -= t, e -= n, e ^= n << 8, t -= n, t -= e, t ^= e >>> 13, n -= e, n -= t, n ^= t >>> 12, e -= t, e -= n, e ^= n << 16, t -= n, t -= e, t ^= e >>> 5, n -= e, n -= t, n ^= t >>> 3, e -= t, e -= n, e ^= n << 10, t -= n, t -= e, t ^= e >>> 15, [n, e, t]; }
var il = (function (n) { return n[n.Little = 0] = "Little", n[n.Big = 1] = "Big", n; })(il || {});
function es(n, e) { return If(n, e)[1]; }
function If(n, e) { let t = (n & 65535) + (e & 65535), s = (n >>> 16) + (e >>> 16) + (t >>> 16); return [s >>> 16, s << 16 | t & 65535]; }
function ia(n, e) { return n << e | n >>> 32 - e; }
function Nf(n, e) { let t = n.length + 3 >>> 2, s = []; for (let r = 0; r < t; r++)
    s[r] = Df(n, r * 4, e); return s; }
function ql(n, e) { return e >= n.length ? 0 : n[e]; }
function Df(n, e, t) { let s = 0; if (t === il.Big)
    for (let r = 0; r < 4; r++)
        s += ql(n, e + r) << 24 - 8 * r;
else
    for (let r = 0; r < 4; r++)
        s += ql(n, e + r) << 8 * r; return s; }
var Np = (function (n) { return n[n.None = 0] = "None", n[n.Const = 1] = "Const", n; })(Np || {}), ji = class {
    modifiers;
    constructor(e = Np.None) { this.modifiers = e; }
    hasModifier(e) { return (this.modifiers & e) !== 0; }
}, Ce = (function (n) { return n[n.Dynamic = 0] = "Dynamic", n[n.Bool = 1] = "Bool", n[n.String = 2] = "String", n[n.Int = 3] = "Int", n[n.Number = 4] = "Number", n[n.Function = 5] = "Function", n[n.Inferred = 6] = "Inferred", n[n.None = 7] = "None", n; })(Ce || {}), _t = class extends ji {
    name;
    constructor(e, t) { super(t), this.name = e; }
    visitType(e, t) { return e.visitBuiltinType(this, t); }
}, He = class extends ji {
    value;
    typeParams;
    constructor(e, t, s = null) { super(t), this.value = e, this.typeParams = s; }
    visitType(e, t) { return e.visitExpressionType(this, t); }
};
var ge = new _t(Ce.Dynamic), It = new _t(Ce.Inferred), Pf = new _t(Ce.Bool), N2 = new _t(Ce.Int), Rn = new _t(Ce.Number), ol = new _t(Ce.String), D2 = new _t(Ce.Function), Je = new _t(Ce.None), dr = (function (n) { return n[n.Minus = 0] = "Minus", n[n.Plus = 1] = "Plus", n; })(dr || {}), x = (function (n) { return n[n.Equals = 0] = "Equals", n[n.NotEquals = 1] = "NotEquals", n[n.Assign = 2] = "Assign", n[n.Identical = 3] = "Identical", n[n.NotIdentical = 4] = "NotIdentical", n[n.Minus = 5] = "Minus", n[n.Plus = 6] = "Plus", n[n.Divide = 7] = "Divide", n[n.Multiply = 8] = "Multiply", n[n.Modulo = 9] = "Modulo", n[n.And = 10] = "And", n[n.Or = 11] = "Or", n[n.BitwiseOr = 12] = "BitwiseOr", n[n.BitwiseAnd = 13] = "BitwiseAnd", n[n.Lower = 14] = "Lower", n[n.LowerEquals = 15] = "LowerEquals", n[n.Bigger = 16] = "Bigger", n[n.BiggerEquals = 17] = "BiggerEquals", n[n.NullishCoalesce = 18] = "NullishCoalesce", n[n.Exponentiation = 19] = "Exponentiation", n[n.In = 20] = "In", n[n.InstanceOf = 21] = "InstanceOf", n[n.AdditionAssignment = 22] = "AdditionAssignment", n[n.SubtractionAssignment = 23] = "SubtractionAssignment", n[n.MultiplicationAssignment = 24] = "MultiplicationAssignment", n[n.DivisionAssignment = 25] = "DivisionAssignment", n[n.RemainderAssignment = 26] = "RemainderAssignment", n[n.ExponentiationAssignment = 27] = "ExponentiationAssignment", n[n.AndAssignment = 28] = "AndAssignment", n[n.OrAssignment = 29] = "OrAssignment", n[n.NullishCoalesceAssignment = 30] = "NullishCoalesceAssignment", n; })(x || {});
function Lf(n, e) { return n == null || e == null ? n == e : n.isEquivalent(e); }
function Dp(n, e, t) { let s = n.length; if (s !== e.length)
    return !1; for (let r = 0; r < s; r++)
    if (!t(n[r], e[r]))
        return !1; return !0; }
function tt(n, e) { return Dp(n, e, (t, s) => t.isEquivalent(s)); }
var j = class {
    leadingComments;
    type;
    sourceSpan;
    constructor(e, t, s) { this.leadingComments = s, this.type = e || null, this.sourceSpan = t || null; }
    prop(e, t) { return new We(this, e, null, t); }
    key(e, t, s) { return new gt(this, e, t, s); }
    callFn(e, t, s, r) { return new pe(this, e, null, t, s, r); }
    instantiate(e, t, s, r) { return new gr(this, e, t, s); }
    conditional(e, t = null, s, r) { return new Nt(this, e, t, null, s); }
    equals(e, t) { return new H(x.Equals, this, e, null, t); }
    notEquals(e, t) { return new H(x.NotEquals, this, e, null, t); }
    identical(e, t) { return new H(x.Identical, this, e, null, t); }
    notIdentical(e, t) { return new H(x.NotIdentical, this, e, null, t); }
    minus(e, t) { return new H(x.Minus, this, e, null, t); }
    plus(e, t) { return new H(x.Plus, this, e, null, t); }
    divide(e, t) { return new H(x.Divide, this, e, null, t); }
    multiply(e, t) { return new H(x.Multiply, this, e, null, t); }
    modulo(e, t) { return new H(x.Modulo, this, e, null, t); }
    power(e, t) { return new H(x.Exponentiation, this, e, null, t); }
    and(e, t) { return new H(x.And, this, e, null, t); }
    bitwiseOr(e, t) { return new H(x.BitwiseOr, this, e, null, t); }
    bitwiseAnd(e, t) { return new H(x.BitwiseAnd, this, e, null, t); }
    or(e, t) { return new H(x.Or, this, e, null, t); }
    lower(e, t) { return new H(x.Lower, this, e, null, t); }
    lowerEquals(e, t) { return new H(x.LowerEquals, this, e, null, t); }
    bigger(e, t) { return new H(x.Bigger, this, e, null, t); }
    biggerEquals(e, t) { return new H(x.BiggerEquals, this, e, null, t); }
    isBlank(e) { return this.equals(Ff, e); }
    nullishCoalesce(e, t) { return new H(x.NullishCoalesce, this, e, null, t); }
    toStmt(e) { return new ke(this, null, e); }
}, dt = class n extends j {
    name;
    constructor(e, t, s, r) { super(t, s, r), this.name = e; }
    isEquivalent(e) { return e instanceof n && this.name === e.name; }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitReadVarExpr(this, t); }
    clone() { return new n(this.name, this.type, this.sourceSpan); }
    set(e) { return new H(x.Assign, this, e, null, this.sourceSpan); }
}, Es = class n extends j {
    expr;
    constructor(e, t, s, r) { super(t, s, r), this.expr = e; }
    visitExpression(e, t) { return e.visitTypeofExpr(this, t); }
    isEquivalent(e) { return e instanceof n && e.expr.isEquivalent(this.expr); }
    isConstant() { return this.expr.isConstant(); }
    clone() { return new n(this.expr.clone()); }
}, zi = class n extends j {
    expr;
    constructor(e, t, s, r) { super(t, s, r), this.expr = e; }
    visitExpression(e, t) { return e.visitVoidExpr(this, t); }
    isEquivalent(e) { return e instanceof n && e.expr.isEquivalent(this.expr); }
    isConstant() { return this.expr.isConstant(); }
    clone() { return new n(this.expr.clone()); }
}, q = class n extends j {
    node;
    constructor(e, t, s, r) { super(t, s, r), this.node = e; }
    isEquivalent(e) { return e instanceof n && this.node === e.node; }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitWrappedNodeExpr(this, t); }
    clone() { return new n(this.node, this.type, this.sourceSpan); }
}, pe = class n extends j {
    fn;
    args;
    pure;
    isOptional;
    constructor(e, t, s, r, i = !1, o, a = !1) { super(s, r, o), this.fn = e, this.args = t, this.pure = i, this.isOptional = a; }
    get receiver() { return this.fn; }
    isEquivalent(e) { return e instanceof n && this.fn.isEquivalent(e.fn) && tt(this.args, e.args) && this.pure === e.pure; }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitInvokeFunctionExpr(this, t); }
    clone() { return new n(this.fn.clone(), this.args.map(e => e.clone()), this.type, this.sourceSpan, this.pure, [], this.isOptional); }
}, mr = class n extends j {
    tag;
    template;
    constructor(e, t, s, r, i) { super(s, r, i), this.tag = e, this.template = t; }
    isEquivalent(e) { return e instanceof n && this.tag.isEquivalent(e.tag) && this.template.isEquivalent(e.template); }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitTaggedTemplateLiteralExpr(this, t); }
    clone() { return new n(this.tag.clone(), this.template.clone(), this.type, this.sourceSpan); }
}, gr = class n extends j {
    classExpr;
    args;
    constructor(e, t, s, r, i) { super(s, r, i), this.classExpr = e, this.args = t; }
    isEquivalent(e) { return e instanceof n && this.classExpr.isEquivalent(e.classExpr) && tt(this.args, e.args); }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitInstantiateExpr(this, t); }
    clone() { return new n(this.classExpr.clone(), this.args.map(e => e.clone()), this.type, this.sourceSpan); }
}, xs = class n extends j {
    body;
    flags;
    constructor(e, t, s, r) { super(null, s, r), this.body = e, this.flags = t; }
    isEquivalent(e) { return e instanceof n && this.body === e.body && this.flags === e.flags; }
    isConstant() { return !0; }
    visitExpression(e, t) { return e.visitRegularExpressionLiteral(this, t); }
    clone() { return new n(this.body, this.flags, this.sourceSpan); }
}, Ae = class n extends j {
    value;
    constructor(e, t, s, r) { super(t, s, r), this.value = e; }
    isEquivalent(e) { return e instanceof n && this.value === e.value; }
    isConstant() { return !0; }
    visitExpression(e, t) { return e.visitLiteralExpr(this, t); }
    clone() { return new n(this.value, this.type, this.sourceSpan); }
}, vr = class n extends j {
    elements;
    expressions;
    constructor(e, t, s, r) { super(null, s, r), this.elements = e, this.expressions = t; }
    isEquivalent(e) { return e instanceof n && Dp(this.elements, e.elements, (t, s) => t.text === s.text) && tt(this.expressions, e.expressions); }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitTemplateLiteralExpr(this, t); }
    clone() { return new n(this.elements.map(e => e.clone()), this.expressions.map(e => e.clone())); }
}, Gi = class n extends j {
    text;
    rawText;
    constructor(e, t, s, r) { super(ol, t, r), this.text = e, this.rawText = s ?? Ia($i(e)); }
    visitExpression(e, t) { return e.visitTemplateLiteralElementExpr(this, t); }
    isEquivalent(e) { return e instanceof n && e.text === this.text && e.rawText === this.rawText; }
    isConstant() { return !0; }
    clone() { return new n(this.text, this.sourceSpan, this.rawText); }
}, _n = class {
    text;
    sourceSpan;
    constructor(e, t) { this.text = e, this.sourceSpan = t; }
}, gs = class {
    text;
    sourceSpan;
    associatedMessage;
    constructor(e, t, s) { this.text = e, this.sourceSpan = t, this.associatedMessage = s; }
}, Bf = "|", Hl = "@@", $f = "\u241F", Xi = class n extends j {
    metaBlock;
    messageParts;
    placeHolderNames;
    expressions;
    constructor(e, t, s, r, i, o) { super(ol, i, o), this.metaBlock = e, this.messageParts = t, this.placeHolderNames = s, this.expressions = r; }
    isEquivalent(e) { return !1; }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitLocalizedString(this, t); }
    clone() { return new n(this.metaBlock, this.messageParts, this.placeHolderNames, this.expressions.map(e => e.clone()), this.sourceSpan); }
    serializeI18nHead() { let e = this.metaBlock.description || ""; return this.metaBlock.meaning && (e = `${this.metaBlock.meaning}${Bf}${e}`), this.metaBlock.customId && (e = `${e}${Hl}${this.metaBlock.customId}`), this.metaBlock.legacyIds && this.metaBlock.legacyIds.forEach(t => { e = `${e}${$f}${t}`; }), Ul(e, this.messageParts[0].text, this.getMessagePartSourceSpan(0)); }
    getMessagePartSourceSpan(e) { return this.messageParts[e]?.sourceSpan ?? this.sourceSpan; }
    getPlaceholderSourceSpan(e) { return this.placeHolderNames[e]?.sourceSpan ?? this.expressions[e]?.sourceSpan ?? this.sourceSpan; }
    serializeI18nTemplatePart(e) { let t = this.placeHolderNames[e - 1], s = this.messageParts[e], r = t.text; return t.associatedMessage?.legacyIds.length === 0 && (r += `${Hl}${Ip(t.associatedMessage.messageString, t.associatedMessage.meaning)}`), Ul(r, s.text, this.getMessagePartSourceSpan(e)); }
}, $i = n => n.replace(/\\/g, "\\\\"), Mf = n => n.replace(/^:/, "\\:"), Rf = n => n.replace(/:/g, "\\:"), Ia = n => n.replace(/`/g, "\\`").replace(/\${/g, "$\\{");
function Ul(n, e, t) { return n === "" ? { cooked: e, raw: Ia(Mf($i(e))), range: t } : { cooked: `:${n}:${e}`, raw: Ia(`:${Rf($i(n))}:${$i(e)}`), range: t }; }
var Fn = class n extends j {
    value;
    typeParams;
    constructor(e, t, s = null, r, i) { super(t, r, i), this.value = e, this.typeParams = s; }
    isEquivalent(e) { return e instanceof n && this.value.name === e.value.name && this.value.moduleName === e.value.moduleName; }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitExternalExpr(this, t); }
    clone() { return new n(this.value, this.type, this.typeParams, this.sourceSpan); }
};
var Nt = class n extends j {
    condition;
    falseCase;
    trueCase;
    constructor(e, t, s = null, r, i, o) { super(r || t.type, i, o), this.condition = e, this.falseCase = s, this.trueCase = t; }
    isEquivalent(e) { return e instanceof n && this.condition.isEquivalent(e.condition) && this.trueCase.isEquivalent(e.trueCase) && Lf(this.falseCase, e.falseCase); }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitConditionalExpr(this, t); }
    clone() { return new n(this.condition.clone(), this.trueCase.clone(), this.falseCase?.clone(), this.type, this.sourceSpan); }
};
var wr = class n extends j {
    condition;
    constructor(e, t, s) { super(Pf, t, s), this.condition = e; }
    isEquivalent(e) { return e instanceof n && this.condition.isEquivalent(e.condition); }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitNotExpr(this, t); }
    clone() { return new n(this.condition.clone(), this.sourceSpan); }
}, he = class n {
    name;
    type;
    constructor(e, t = null) { this.name = e, this.type = t; }
    isEquivalent(e) { return this.name === e.name; }
    clone() { return new n(this.name, this.type); }
}, Vt = class n extends j {
    params;
    statements;
    name;
    constructor(e, t, s, r, i, o) { super(s, r, o), this.params = e, this.statements = t, this.name = i; }
    isEquivalent(e) { return (e instanceof n || e instanceof Sr) && tt(this.params, e.params) && tt(this.statements, e.statements); }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitFunctionExpr(this, t); }
    toDeclStmt(e, t) { return new Sr(e, this.params, this.statements, this.type, t, this.sourceSpan); }
    clone() { return new n(this.params.map(e => e.clone()), this.statements, this.type, this.sourceSpan, this.name); }
}, rn = class Na extends j {
    params;
    body;
    constructor(e, t, s, r, i) { super(s, r, i), this.params = e, this.body = t; }
    isEquivalent(e) { return !(e instanceof Na) || !tt(this.params, e.params) ? !1 : this.body instanceof j && e.body instanceof j ? this.body.isEquivalent(e.body) : Array.isArray(this.body) && Array.isArray(e.body) ? tt(this.body, e.body) : !1; }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitArrowFunctionExpr(this, t); }
    clone() { return new Na(this.params.map(e => e.clone()), Array.isArray(this.body) ? this.body : this.body.clone(), this.type, this.sourceSpan); }
    toDeclStmt(e, t) { return new ve(e, this, It, t, this.sourceSpan); }
}, On = class n extends j {
    operator;
    expr;
    parens;
    constructor(e, t, s, r, i = !0, o) { super(s || Rn, r, o), this.operator = e, this.expr = t, this.parens = i; }
    isEquivalent(e) { return e instanceof n && this.operator === e.operator && this.expr.isEquivalent(e.expr); }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitUnaryOperatorExpr(this, t); }
    clone() { return new n(this.operator, this.expr.clone(), this.type, this.sourceSpan, this.parens); }
}, mt = class n extends j {
    expr;
    constructor(e, t, s, r) { super(t, s, r), this.expr = e; }
    visitExpression(e, t) { return e.visitParenthesizedExpr(this, t); }
    isEquivalent(e) { return e instanceof n && e.expr.isEquivalent(this.expr); }
    isConstant() { return this.expr.isConstant(); }
    clone() { return new n(this.expr.clone()); }
}, H = class n extends j {
    operator;
    rhs;
    lhs;
    constructor(e, t, s, r, i, o) { super(r || t.type, i, o), this.operator = e, this.rhs = s, this.lhs = t; }
    isEquivalent(e) { return e instanceof n && this.operator === e.operator && this.lhs.isEquivalent(e.lhs) && this.rhs.isEquivalent(e.rhs); }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitBinaryOperatorExpr(this, t); }
    clone() { return new n(this.operator, this.lhs.clone(), this.rhs.clone(), this.type, this.sourceSpan); }
    isAssignment() { let e = this.operator; return e === x.Assign || e === x.AdditionAssignment || e === x.SubtractionAssignment || e === x.MultiplicationAssignment || e === x.DivisionAssignment || e === x.RemainderAssignment || e === x.ExponentiationAssignment || e === x.AndAssignment || e === x.OrAssignment || e === x.NullishCoalesceAssignment; }
}, We = class n extends j {
    receiver;
    name;
    isOptional;
    constructor(e, t, s, r, i, o = !1) { super(s, r, i), this.receiver = e, this.name = t, this.isOptional = o; }
    get index() { return this.name; }
    isEquivalent(e) { return e instanceof n && this.receiver.isEquivalent(e.receiver) && this.name === e.name && this.isOptional === e.isOptional; }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitReadPropExpr(this, t); }
    set(e) { return new H(x.Assign, this.receiver.prop(this.name), e, null, this.sourceSpan); }
    clone() { return new n(this.receiver.clone(), this.name, this.type, this.sourceSpan, [], this.isOptional); }
}, gt = class n extends j {
    receiver;
    index;
    isOptional;
    constructor(e, t, s, r, i, o = !1) { super(s, r, i), this.receiver = e, this.index = t, this.isOptional = o; }
    isEquivalent(e) { return e instanceof n && this.receiver.isEquivalent(e.receiver) && this.index.isEquivalent(e.index) && this.isOptional === e.isOptional; }
    isConstant() { return !1; }
    visitExpression(e, t) { return e.visitReadKeyExpr(this, t); }
    set(e) { return new H(x.Assign, this.receiver.key(this.index), e, null, this.sourceSpan); }
    clone() { return new n(this.receiver.clone(), this.index.clone(), this.type, this.sourceSpan, [], this.isOptional); }
}, Dt = class n extends j {
    entries;
    constructor(e, t, s, r) { super(t, s, r), this.entries = e; }
    isConstant() { return this.entries.every(e => e.isConstant()); }
    isEquivalent(e) { return e instanceof n && tt(this.entries, e.entries); }
    visitExpression(e, t) { return e.visitLiteralArrayExpr(this, t); }
    clone() { return new n(this.entries.map(e => e.clone()), this.type, this.sourceSpan); }
}, ys = class n {
    key;
    value;
    quoted;
    constructor(e, t, s) { this.key = e, this.value = t, this.quoted = s; }
    isEquivalent(e) { return this.key === e.key && this.value.isEquivalent(e.value); }
    clone() { return new n(this.key, this.value.clone(), this.quoted); }
    isConstant() { return this.value.isConstant(); }
}, on = class n {
    expression;
    constructor(e) { this.expression = e; }
    isEquivalent(e) { return e instanceof n && this.expression.isEquivalent(e.expression); }
    clone() { return new n(this.expression.clone()); }
    isConstant() { return this.expression.isConstant(); }
}, vt = class n extends j {
    entries;
    valueType = null;
    constructor(e, t, s, r) { super(t, s, r), this.entries = e, t && (this.valueType = t.valueType); }
    isEquivalent(e) { return e instanceof n && tt(this.entries, e.entries); }
    isConstant() { return this.entries.every(e => e.isConstant()); }
    visitExpression(e, t) { return e.visitLiteralMapExpr(this, t); }
    clone() { let e = this.entries.map(t => t.clone()); return new n(e, this.type, this.sourceSpan); }
};
var Vn = class n extends j {
    expression;
    constructor(e, t, s) { super(null, t, s), this.expression = e; }
    isEquivalent(e) { return e instanceof n && this.expression.isEquivalent(e.expression); }
    isConstant() { return this.expression.isConstant(); }
    visitExpression(e, t) { return e.visitSpreadElementExpr(this, t); }
    clone() { return new n(this.expression.clone(), this.sourceSpan); }
}, Cs = new Ae(null, null, null), Ff = new Ae(null, It, null), xe = (function (n) { return n[n.None = 0] = "None", n[n.Final = 1] = "Final", n[n.Private = 2] = "Private", n[n.Exported = 4] = "Exported", n[n.Static = 8] = "Static", n; })(xe || {}), Qi = class {
    text;
    multiline;
    trailingNewline;
    constructor(e, t, s) { this.text = e, this.multiline = t, this.trailingNewline = s; }
    toString() { return this.multiline ? ` ${this.text} ` : this.text; }
}, Yi = class extends Qi {
    tags;
    constructor(e) { super("", !0, !0), this.tags = e; }
    toString() { return Wf(this.tags); }
}, qn = class {
    modifiers;
    sourceSpan;
    leadingComments;
    constructor(e = xe.None, t = null, s) { this.modifiers = e, this.sourceSpan = t, this.leadingComments = s; }
    hasModifier(e) { return (this.modifiers & e) !== 0; }
    addLeadingComment(e) { this.leadingComments = this.leadingComments ?? [], this.leadingComments.push(e); }
}, ve = class n extends qn {
    name;
    value;
    type;
    constructor(e, t, s, r, i, o) { super(r, i, o), this.name = e, this.value = t, this.type = s || t && t.type || null; }
    isEquivalent(e) { return e instanceof n && this.name === e.name && (this.value ? !!e.value && this.value.isEquivalent(e.value) : !e.value); }
    visitStatement(e, t) { return e.visitDeclareVarStmt(this, t); }
}, Sr = class n extends qn {
    name;
    params;
    statements;
    type;
    constructor(e, t, s, r, i, o, a) { super(i, o, a), this.name = e, this.params = t, this.statements = s, this.type = r || null; }
    isEquivalent(e) { return e instanceof n && tt(this.params, e.params) && tt(this.statements, e.statements); }
    visitStatement(e, t) { return e.visitDeclareFunctionStmt(this, t); }
}, ke = class n extends qn {
    expr;
    constructor(e, t, s) { super(xe.None, t, s), this.expr = e; }
    isEquivalent(e) { return e instanceof n && this.expr.isEquivalent(e.expr); }
    visitStatement(e, t) { return e.visitExpressionStmt(this, t); }
}, fe = class n extends qn {
    value;
    constructor(e, t = null, s) { super(xe.None, t, s), this.value = e; }
    isEquivalent(e) { return e instanceof n && this.value.isEquivalent(e.value); }
    visitStatement(e, t) { return e.visitReturnStmt(this, t); }
}, Zi = class n extends qn {
    condition;
    trueCase;
    falseCase;
    constructor(e, t, s = [], r, i) { super(xe.None, r, i), this.condition = e, this.trueCase = t, this.falseCase = s; }
    isEquivalent(e) { return e instanceof n && this.condition.isEquivalent(e.condition) && tt(this.trueCase, e.trueCase) && tt(this.falseCase, e.falseCase); }
    visitStatement(e, t) { return e.visitIfStmt(this, t); }
};
function Of(n, e = !1, t = !0) { return new Qi(n, e, t); }
function Vf(n = []) { return new Yi(n); }
function F(n, e, t, s) { return new dt(n, e, t, s); }
function A(n, e = null, t) { return new Fn(n, null, e, t); }
function we(n, e, t) { return new He(n, e, t); }
function di(n) { return new Es(n); }
function X(n, e, t) { return new Dt(n, e, t); }
function nt(n, e = null) { return new vt(n.map(t => new ys(t.key, t.value, t.quoted)), e, null); }
function qf(n, e) { return new wr(n, e); }
function an(n, e, t, s, r) { return new Vt(n, e, t, s, r); }
function je(n, e, t, s) { return new rn(n, e, t, s); }
function Qo(n, e, t, s, r) { return new Zi(n, e, t, s, r); }
function Hf(n, e, t, s) { return new mr(n, e, t, s); }
function g(n, e, t) { return new Ae(n, e, t); }
function Uf(n, e, t, s, r) { return new Xi(n, e, t, s, r); }
function Wl(n) { let e = ""; if (n.tagName && (e += ` @${n.tagName}`), n.text) {
    if (n.text.match(/\/\*|\*\//))
        throw new Error('JSDoc text cannot contain "/*" and "*/"');
    e += " " + n.text.replace(/@/g, "\\@");
} return e; }
function Wf(n) {
    if (n.length === 0)
        return "";
    if (n.length === 1 && n[0].tagName && !n[0].text)
        return `*${Wl(n[0])} `;
    let e = `*
`;
    for (let t of n)
        e += " *", e += Wl(t).replace(/\n/g, `
 * `), e += `
`;
    return e += " ", e;
}
var jf = "_c", zf = {}, Gf = 50, Ji = class n extends j {
    resolved;
    original;
    shared = !1;
    constructor(e) { super(e.type), this.resolved = e, this.original = e; }
    visitExpression(e, t) { return t === zf ? this.original.visitExpression(e, t) : this.resolved.visitExpression(e, t); }
    isEquivalent(e) { return e instanceof n && this.resolved.isEquivalent(e.resolved); }
    isConstant() { return !0; }
    clone() { throw new Error("Not supported."); }
    fixup(e) { this.resolved = e, this.shared = !0; }
}, Ki = class {
    isClosureCompilerEnabled;
    statements = [];
    literals = new Map;
    sharedConstants = new Map;
    _claimedNames = new Map;
    constructor(e = !1) { this.isClosureCompilerEnabled = e; }
    getConstLiteral(e, t) { if (e instanceof Ae && !jl(e) || e instanceof Ji)
        return e; let s = Er.INSTANCE.keyOf(e), r = this.literals.get(s), i = !1; if (r || (r = new Ji(e), this.literals.set(s, r), i = !0), !i && !r.shared || i && t) {
        let o = this.freshName(), a, c;
        this.isClosureCompilerEnabled && jl(e) ? (a = new Vt([], [new fe(e)]), c = F(o).callFn([])) : (a = e, c = F(o)), this.statements.push(new ve(o, a, It, xe.Final)), r.fixup(c);
    } return r; }
    getSharedConstant(e, t) { let s = e.keyOf(t); if (!this.sharedConstants.has(s)) {
        let r = this.freshName();
        this.sharedConstants.set(s, F(r)), this.statements.push(e.toSharedConstantDeclaration(r, t));
    } return this.sharedConstants.get(s); }
    getSharedFunctionReference(e, t, s = !0) { let r = e instanceof rn; for (let o of this.statements)
        if (r && o instanceof ve && o.value?.isEquivalent(e) || !r && o instanceof Sr && e instanceof Vt && e.isEquivalent(o))
            return F(o.name); let i = s ? this.uniqueName(t) : t; return this.statements.push(e instanceof Vt ? e.toDeclStmt(i, xe.Final) : new ve(i, e, It, xe.Final, e.sourceSpan)), F(i); }
    uniqueName(e, t = !0) { let s = this._claimedNames.get(e) ?? 0, r = s === 0 && !t ? `${e}` : `${e}${s}`; return this._claimedNames.set(e, s + 1), r; }
    freshName() { return this.uniqueName(jf); }
}, Er = class n {
    static INSTANCE = new n;
    keyOf(e) { if (e instanceof Ae && typeof e.value == "string")
        return `"${e.value}"`; if (e instanceof Ae)
        return String(e.value); if (e instanceof xs)
        return `/${e.body}/${e.flags ?? ""}`; if (e instanceof Dt) {
        let t = [];
        for (let s of e.entries)
            t.push(this.keyOf(s));
        return `[${t.join(",")}]`;
    }
    else if (e instanceof vt) {
        let t = [];
        for (let s of e.entries)
            if (s instanceof on)
                t.push("..." + this.keyOf(s.expression));
            else {
                let r = s.key;
                s.quoted && (r = `"${r}"`), t.push(r + ":" + this.keyOf(s.value));
            }
        return `{${t.join(",")}}`;
    }
    else {
        if (e instanceof Fn)
            return `import("${e.value.moduleName}", ${e.value.name})`;
        if (e instanceof dt)
            return `read(${e.name})`;
        if (e instanceof Es)
            return `typeof(${this.keyOf(e.expr)})`;
        if (e instanceof Vn)
            return `...${this.keyOf(e.expression)}`;
        throw new Error(`${this.constructor.name} does not handle expressions of type ${e.constructor.name}`);
    } }
};
function jl(n) { return n instanceof Ae && typeof n.value == "string" && n.value.length >= Gf; }
var m = "@angular/core", f = (() => { class n {
    static core = { name: null, moduleName: m };
    static namespaceHTML = { name: "\u0275\u0275namespaceHTML", moduleName: m };
    static namespaceMathML = { name: "\u0275\u0275namespaceMathML", moduleName: m };
    static namespaceSVG = { name: "\u0275\u0275namespaceSVG", moduleName: m };
    static element = { name: "\u0275\u0275element", moduleName: m };
    static elementStart = { name: "\u0275\u0275elementStart", moduleName: m };
    static elementEnd = { name: "\u0275\u0275elementEnd", moduleName: m };
    static foreignComponent = { name: "\u0275\u0275foreignComponent", moduleName: m };
    static foreignContent = { name: "\u0275\u0275foreignContent", moduleName: m };
    static foreignContentFn = { name: "\u0275\u0275foreignContentFn", moduleName: m };
    static domElement = { name: "\u0275\u0275domElement", moduleName: m };
    static domElementStart = { name: "\u0275\u0275domElementStart", moduleName: m };
    static domElementEnd = { name: "\u0275\u0275domElementEnd", moduleName: m };
    static domElementContainer = { name: "\u0275\u0275domElementContainer", moduleName: m };
    static domElementContainerStart = { name: "\u0275\u0275domElementContainerStart", moduleName: m };
    static domElementContainerEnd = { name: "\u0275\u0275domElementContainerEnd", moduleName: m };
    static domTemplate = { name: "\u0275\u0275domTemplate", moduleName: m };
    static domListener = { name: "\u0275\u0275domListener", moduleName: m };
    static advance = { name: "\u0275\u0275advance", moduleName: m };
    static syntheticHostProperty = { name: "\u0275\u0275syntheticHostProperty", moduleName: m };
    static syntheticHostListener = { name: "\u0275\u0275syntheticHostListener", moduleName: m };
    static attribute = { name: "\u0275\u0275attribute", moduleName: m };
    static classProp = { name: "\u0275\u0275classProp", moduleName: m };
    static elementContainerStart = { name: "\u0275\u0275elementContainerStart", moduleName: m };
    static elementContainerEnd = { name: "\u0275\u0275elementContainerEnd", moduleName: m };
    static elementContainer = { name: "\u0275\u0275elementContainer", moduleName: m };
    static styleMap = { name: "\u0275\u0275styleMap", moduleName: m };
    static classMap = { name: "\u0275\u0275classMap", moduleName: m };
    static styleProp = { name: "\u0275\u0275styleProp", moduleName: m };
    static interpolate = { name: "\u0275\u0275interpolate", moduleName: m };
    static interpolate1 = { name: "\u0275\u0275interpolate1", moduleName: m };
    static interpolate2 = { name: "\u0275\u0275interpolate2", moduleName: m };
    static interpolate3 = { name: "\u0275\u0275interpolate3", moduleName: m };
    static interpolate4 = { name: "\u0275\u0275interpolate4", moduleName: m };
    static interpolate5 = { name: "\u0275\u0275interpolate5", moduleName: m };
    static interpolate6 = { name: "\u0275\u0275interpolate6", moduleName: m };
    static interpolate7 = { name: "\u0275\u0275interpolate7", moduleName: m };
    static interpolate8 = { name: "\u0275\u0275interpolate8", moduleName: m };
    static interpolateV = { name: "\u0275\u0275interpolateV", moduleName: m };
    static nextContext = { name: "\u0275\u0275nextContext", moduleName: m };
    static resetView = { name: "\u0275\u0275resetView", moduleName: m };
    static templateCreate = { name: "\u0275\u0275template", moduleName: m };
    static defer = { name: "\u0275\u0275defer", moduleName: m };
    static deferWhen = { name: "\u0275\u0275deferWhen", moduleName: m };
    static deferOnIdle = { name: "\u0275\u0275deferOnIdle", moduleName: m };
    static deferOnImmediate = { name: "\u0275\u0275deferOnImmediate", moduleName: m };
    static deferOnTimer = { name: "\u0275\u0275deferOnTimer", moduleName: m };
    static deferOnHover = { name: "\u0275\u0275deferOnHover", moduleName: m };
    static deferOnInteraction = { name: "\u0275\u0275deferOnInteraction", moduleName: m };
    static deferOnViewport = { name: "\u0275\u0275deferOnViewport", moduleName: m };
    static deferPrefetchWhen = { name: "\u0275\u0275deferPrefetchWhen", moduleName: m };
    static deferPrefetchOnIdle = { name: "\u0275\u0275deferPrefetchOnIdle", moduleName: m };
    static deferPrefetchOnImmediate = { name: "\u0275\u0275deferPrefetchOnImmediate", moduleName: m };
    static deferPrefetchOnTimer = { name: "\u0275\u0275deferPrefetchOnTimer", moduleName: m };
    static deferPrefetchOnHover = { name: "\u0275\u0275deferPrefetchOnHover", moduleName: m };
    static deferPrefetchOnInteraction = { name: "\u0275\u0275deferPrefetchOnInteraction", moduleName: m };
    static deferPrefetchOnViewport = { name: "\u0275\u0275deferPrefetchOnViewport", moduleName: m };
    static deferHydrateWhen = { name: "\u0275\u0275deferHydrateWhen", moduleName: m };
    static deferHydrateNever = { name: "\u0275\u0275deferHydrateNever", moduleName: m };
    static deferHydrateOnIdle = { name: "\u0275\u0275deferHydrateOnIdle", moduleName: m };
    static deferHydrateOnImmediate = { name: "\u0275\u0275deferHydrateOnImmediate", moduleName: m };
    static deferHydrateOnTimer = { name: "\u0275\u0275deferHydrateOnTimer", moduleName: m };
    static deferHydrateOnHover = { name: "\u0275\u0275deferHydrateOnHover", moduleName: m };
    static deferHydrateOnInteraction = { name: "\u0275\u0275deferHydrateOnInteraction", moduleName: m };
    static deferHydrateOnViewport = { name: "\u0275\u0275deferHydrateOnViewport", moduleName: m };
    static deferEnableTimerScheduling = { name: "\u0275\u0275deferEnableTimerScheduling", moduleName: m };
    static enableIncrementalHydrationRuntime = { name: "\u0275\u0275enableIncrementalHydrationRuntime", moduleName: m };
    static conditionalCreate = { name: "\u0275\u0275conditionalCreate", moduleName: m };
    static conditionalBranchCreate = { name: "\u0275\u0275conditionalBranchCreate", moduleName: m };
    static conditional = { name: "\u0275\u0275conditional", moduleName: m };
    static repeater = { name: "\u0275\u0275repeater", moduleName: m };
    static repeaterCreate = { name: "\u0275\u0275repeaterCreate", moduleName: m };
    static repeaterTrackByIndex = { name: "\u0275\u0275repeaterTrackByIndex", moduleName: m };
    static repeaterTrackByIdentity = { name: "\u0275\u0275repeaterTrackByIdentity", moduleName: m };
    static componentInstance = { name: "\u0275\u0275componentInstance", moduleName: m };
    static text = { name: "\u0275\u0275text", moduleName: m };
    static enableBindings = { name: "\u0275\u0275enableBindings", moduleName: m };
    static disableBindings = { name: "\u0275\u0275disableBindings", moduleName: m };
    static getCurrentView = { name: "\u0275\u0275getCurrentView", moduleName: m };
    static textInterpolate = { name: "\u0275\u0275textInterpolate", moduleName: m };
    static textInterpolate1 = { name: "\u0275\u0275textInterpolate1", moduleName: m };
    static textInterpolate2 = { name: "\u0275\u0275textInterpolate2", moduleName: m };
    static textInterpolate3 = { name: "\u0275\u0275textInterpolate3", moduleName: m };
    static textInterpolate4 = { name: "\u0275\u0275textInterpolate4", moduleName: m };
    static textInterpolate5 = { name: "\u0275\u0275textInterpolate5", moduleName: m };
    static textInterpolate6 = { name: "\u0275\u0275textInterpolate6", moduleName: m };
    static textInterpolate7 = { name: "\u0275\u0275textInterpolate7", moduleName: m };
    static textInterpolate8 = { name: "\u0275\u0275textInterpolate8", moduleName: m };
    static textInterpolateV = { name: "\u0275\u0275textInterpolateV", moduleName: m };
    static restoreView = { name: "\u0275\u0275restoreView", moduleName: m };
    static pureFunction0 = { name: "\u0275\u0275pureFunction0", moduleName: m };
    static pureFunction1 = { name: "\u0275\u0275pureFunction1", moduleName: m };
    static pureFunction2 = { name: "\u0275\u0275pureFunction2", moduleName: m };
    static pureFunction3 = { name: "\u0275\u0275pureFunction3", moduleName: m };
    static pureFunction4 = { name: "\u0275\u0275pureFunction4", moduleName: m };
    static pureFunction5 = { name: "\u0275\u0275pureFunction5", moduleName: m };
    static pureFunction6 = { name: "\u0275\u0275pureFunction6", moduleName: m };
    static pureFunction7 = { name: "\u0275\u0275pureFunction7", moduleName: m };
    static pureFunction8 = { name: "\u0275\u0275pureFunction8", moduleName: m };
    static pureFunctionV = { name: "\u0275\u0275pureFunctionV", moduleName: m };
    static pipeBind1 = { name: "\u0275\u0275pipeBind1", moduleName: m };
    static pipeBind2 = { name: "\u0275\u0275pipeBind2", moduleName: m };
    static pipeBind3 = { name: "\u0275\u0275pipeBind3", moduleName: m };
    static pipeBind4 = { name: "\u0275\u0275pipeBind4", moduleName: m };
    static pipeBindV = { name: "\u0275\u0275pipeBindV", moduleName: m };
    static domProperty = { name: "\u0275\u0275domProperty", moduleName: m };
    static ariaProperty = { name: "\u0275\u0275ariaProperty", moduleName: m };
    static property = { name: "\u0275\u0275property", moduleName: m };
    static control = { name: "\u0275\u0275control", moduleName: m };
    static controlCreate = { name: "\u0275\u0275controlCreate", moduleName: m };
    static animationEnterListener = { name: "\u0275\u0275animateEnterListener", moduleName: m };
    static animationLeaveListener = { name: "\u0275\u0275animateLeaveListener", moduleName: m };
    static animationEnter = { name: "\u0275\u0275animateEnter", moduleName: m };
    static animationLeave = { name: "\u0275\u0275animateLeave", moduleName: m };
    static i18n = { name: "\u0275\u0275i18n", moduleName: m };
    static i18nAttributes = { name: "\u0275\u0275i18nAttributes", moduleName: m };
    static i18nExp = { name: "\u0275\u0275i18nExp", moduleName: m };
    static i18nStart = { name: "\u0275\u0275i18nStart", moduleName: m };
    static i18nEnd = { name: "\u0275\u0275i18nEnd", moduleName: m };
    static i18nApply = { name: "\u0275\u0275i18nApply", moduleName: m };
    static i18nPostprocess = { name: "\u0275\u0275i18nPostprocess", moduleName: m };
    static pipe = { name: "\u0275\u0275pipe", moduleName: m };
    static projection = { name: "\u0275\u0275projection", moduleName: m };
    static projectionDef = { name: "\u0275\u0275projectionDef", moduleName: m };
    static reference = { name: "\u0275\u0275reference", moduleName: m };
    static inject = { name: "\u0275\u0275inject", moduleName: m };
    static injectAttribute = { name: "\u0275\u0275injectAttribute", moduleName: m };
    static directiveInject = { name: "\u0275\u0275directiveInject", moduleName: m };
    static invalidFactory = { name: "\u0275\u0275invalidFactory", moduleName: m };
    static invalidFactoryDep = { name: "\u0275\u0275invalidFactoryDep", moduleName: m };
    static templateRefExtractor = { name: "\u0275\u0275templateRefExtractor", moduleName: m };
    static forwardRef = { name: "forwardRef", moduleName: m };
    static resolveForwardRef = { name: "resolveForwardRef", moduleName: m };
    static replaceMetadata = { name: "\u0275\u0275replaceMetadata", moduleName: m };
    static getReplaceMetadataURL = { name: "\u0275\u0275getReplaceMetadataURL", moduleName: m };
    static \u0275\u0275defineInjectable = { name: "\u0275\u0275defineInjectable", moduleName: m };
    static declareInjectable = { name: "\u0275\u0275ngDeclareInjectable", moduleName: m };
    static InjectableDeclaration = { name: "\u0275\u0275InjectableDeclaration", moduleName: m };
    static defineService = { name: "\u0275\u0275defineService", moduleName: m };
    static declareService = { name: "\u0275\u0275ngDeclareService", moduleName: m };
    static resolveWindow = { name: "\u0275\u0275resolveWindow", moduleName: m };
    static resolveDocument = { name: "\u0275\u0275resolveDocument", moduleName: m };
    static resolveBody = { name: "\u0275\u0275resolveBody", moduleName: m };
    static getComponentDepsFactory = { name: "\u0275\u0275getComponentDepsFactory", moduleName: m };
    static defineComponent = { name: "\u0275\u0275defineComponent", moduleName: m };
    static declareComponent = { name: "\u0275\u0275ngDeclareComponent", moduleName: m };
    static setComponentScope = { name: "\u0275\u0275setComponentScope", moduleName: m };
    static ChangeDetectionStrategy = { name: "ChangeDetectionStrategy", moduleName: m };
    static ViewEncapsulation = { name: "ViewEncapsulation", moduleName: m };
    static ComponentDeclaration = { name: "\u0275\u0275ComponentDeclaration", moduleName: m };
    static FactoryDeclaration = { name: "\u0275\u0275FactoryDeclaration", moduleName: m };
    static declareFactory = { name: "\u0275\u0275ngDeclareFactory", moduleName: m };
    static FactoryTarget = { name: "\u0275\u0275FactoryTarget", moduleName: m };
    static defineDirective = { name: "\u0275\u0275defineDirective", moduleName: m };
    static declareDirective = { name: "\u0275\u0275ngDeclareDirective", moduleName: m };
    static DirectiveDeclaration = { name: "\u0275\u0275DirectiveDeclaration", moduleName: m };
    static InjectorDef = { name: "\u0275\u0275InjectorDef", moduleName: m };
    static InjectorDeclaration = { name: "\u0275\u0275InjectorDeclaration", moduleName: m };
    static defineInjector = { name: "\u0275\u0275defineInjector", moduleName: m };
    static declareInjector = { name: "\u0275\u0275ngDeclareInjector", moduleName: m };
    static NgModuleDeclaration = { name: "\u0275\u0275NgModuleDeclaration", moduleName: m };
    static ModuleWithProviders = { name: "ModuleWithProviders", moduleName: m };
    static defineNgModule = { name: "\u0275\u0275defineNgModule", moduleName: m };
    static declareNgModule = { name: "\u0275\u0275ngDeclareNgModule", moduleName: m };
    static setNgModuleScope = { name: "\u0275\u0275setNgModuleScope", moduleName: m };
    static registerNgModuleType = { name: "\u0275\u0275registerNgModuleType", moduleName: m };
    static PipeDeclaration = { name: "\u0275\u0275PipeDeclaration", moduleName: m };
    static definePipe = { name: "\u0275\u0275definePipe", moduleName: m };
    static declarePipe = { name: "\u0275\u0275ngDeclarePipe", moduleName: m };
    static declareClassMetadata = { name: "\u0275\u0275ngDeclareClassMetadata", moduleName: m };
    static declareClassMetadataAsync = { name: "\u0275\u0275ngDeclareClassMetadataAsync", moduleName: m };
    static setClassMetadata = { name: "\u0275setClassMetadata", moduleName: m };
    static setClassMetadataAsync = { name: "\u0275setClassMetadataAsync", moduleName: m };
    static setClassDebugInfo = { name: "\u0275setClassDebugInfo", moduleName: m };
    static queryRefresh = { name: "\u0275\u0275queryRefresh", moduleName: m };
    static viewQuery = { name: "\u0275\u0275viewQuery", moduleName: m };
    static loadQuery = { name: "\u0275\u0275loadQuery", moduleName: m };
    static contentQuery = { name: "\u0275\u0275contentQuery", moduleName: m };
    static viewQuerySignal = { name: "\u0275\u0275viewQuerySignal", moduleName: m };
    static contentQuerySignal = { name: "\u0275\u0275contentQuerySignal", moduleName: m };
    static queryAdvance = { name: "\u0275\u0275queryAdvance", moduleName: m };
    static twoWayProperty = { name: "\u0275\u0275twoWayProperty", moduleName: m };
    static twoWayBindingSet = { name: "\u0275\u0275twoWayBindingSet", moduleName: m };
    static twoWayListener = { name: "\u0275\u0275twoWayListener", moduleName: m };
    static declareLet = { name: "\u0275\u0275declareLet", moduleName: m };
    static storeLet = { name: "\u0275\u0275storeLet", moduleName: m };
    static readContextLet = { name: "\u0275\u0275readContextLet", moduleName: m };
    static arrowFunction = { name: "\u0275\u0275arrowFunction", moduleName: m };
    static attachSourceLocations = { name: "\u0275\u0275attachSourceLocations", moduleName: m };
    static NgOnChangesFeature = { name: "\u0275\u0275NgOnChangesFeature", moduleName: m };
    static ControlFeature = { name: "\u0275\u0275ControlFeature", moduleName: m };
    static InheritDefinitionFeature = { name: "\u0275\u0275InheritDefinitionFeature", moduleName: m };
    static ProvidersFeature = { name: "\u0275\u0275ProvidersFeature", moduleName: m };
    static HostDirectivesFeature = { name: "\u0275\u0275HostDirectivesFeature", moduleName: m };
    static ExternalStylesFeature = { name: "\u0275\u0275ExternalStylesFeature", moduleName: m };
    static listener = { name: "\u0275\u0275listener", moduleName: m };
    static getInheritedFactory = { name: "\u0275\u0275getInheritedFactory", moduleName: m };
    static sanitizeHtml = { name: "\u0275\u0275sanitizeHtml", moduleName: m };
    static sanitizeStyle = { name: "\u0275\u0275sanitizeStyle", moduleName: m };
    static validateAttribute = { name: "\u0275\u0275validateAttribute", moduleName: m };
    static sanitizeResourceUrl = { name: "\u0275\u0275sanitizeResourceUrl", moduleName: m };
    static sanitizeScript = { name: "\u0275\u0275sanitizeScript", moduleName: m };
    static sanitizeUrl = { name: "\u0275\u0275sanitizeUrl", moduleName: m };
    static sanitizeUrlOrResourceUrl = { name: "\u0275\u0275sanitizeUrlOrResourceUrl", moduleName: m };
    static trustConstantHtml = { name: "\u0275\u0275trustConstantHtml", moduleName: m };
    static trustConstantResourceUrl = { name: "\u0275\u0275trustConstantResourceUrl", moduleName: m };
    static inputDecorator = { name: "Input", moduleName: m };
    static outputDecorator = { name: "Output", moduleName: m };
    static viewChildDecorator = { name: "ViewChild", moduleName: m };
    static viewChildrenDecorator = { name: "ViewChildren", moduleName: m };
    static contentChildDecorator = { name: "ContentChild", moduleName: m };
    static contentChildrenDecorator = { name: "ContentChildren", moduleName: m };
    static InputSignalBrandWriteType = { name: "\u0275INPUT_SIGNAL_BRAND_WRITE_TYPE", moduleName: m };
    static UnwrapDirectiveSignalInputs = { name: "\u0275UnwrapDirectiveSignalInputs", moduleName: m };
    static unwrapWritableSignal = { name: "\u0275unwrapWritableSignal", moduleName: m };
    static assertType = { name: "\u0275assertType", moduleName: m };
} return n; })(), Xf = /-+([a-z0-9])/g;
function Qf(n) { return n.replace(Xf, (...e) => e[1].toUpperCase()); }
function Yf(n, e) { return Pp(n, ":", e); }
function Zf(n, e) { return Pp(n, ".", e); }
function Pp(n, e, t) { let s = n.indexOf(e); return s == -1 ? t : [n.slice(0, s).trim(), n.slice(s + 1).trim()]; }
function Jf(n) { return n === void 0 ? null : n; }
function Kf(n) { let e = []; for (let t = 0; t < n.length; t++) {
    let s = n.charCodeAt(t);
    if (s >= 55296 && s <= 56319 && n.length > t + 1) {
        let r = n.charCodeAt(t + 1);
        r >= 56320 && r <= 57343 && (t++, s = (s - 55296 << 10) + r - 56320 + 65536);
    }
    s <= 127 ? e.push(s) : s <= 2047 ? e.push(s >> 6 & 31 | 192, s & 63 | 128) : s <= 65535 ? e.push(s >> 12 | 224, s >> 6 & 63 | 128, s & 63 | 128) : s <= 2097151 && e.push(s >> 18 & 7 | 240, s >> 12 & 63 | 128, s >> 6 & 63 | 128, s & 63 | 128);
} return e; }
function Lp(n) {
    if (typeof n == "string")
        return n;
    if (Array.isArray(n))
        return `[${n.map(Lp).join(", ")}]`;
    if (n == null)
        return "" + n;
    let e = n.overriddenName || n.name;
    if (e)
        return `${e}`;
    if (!n.toString)
        return "object";
    let t = n.toString();
    if (t == null)
        return "" + t;
    let s = t.indexOf(`
`);
    return s >= 0 ? t.slice(0, s) : t;
}
var Da = class {
    full;
    major;
    minor;
    patch;
    constructor(e) { this.full = e; let t = e.split("."); this.major = t[0], this.minor = t[1], this.patch = t.slice(2).join("."); }
}, nr = globalThis, ed = /^([1-9]|1[0-8])\./;
function Bp(n) { return n.startsWith("0.") ? !0 : !ed.test(n); }
function al(n) { return n.startsWith("--global--") ? "--" + n.substring(10) : "--%NS%" + n.substring(2); }
var td = 3, nd = "# sourceMappingURL=data:application/json;base64,", Pa = class {
    file;
    sourcesContent = new Map;
    lines = [];
    lastCol0 = 0;
    hasMappings = !1;
    constructor(e = null) { this.file = e; }
    addSource(e, t = null) { return this.sourcesContent.has(e) || this.sourcesContent.set(e, t), this; }
    addLine() { return this.lines.push([]), this.lastCol0 = 0, this; }
    addMapping(e, t, s, r) { if (!this.currentLine)
        throw new Error("A line must be added before mappings can be added"); if (t != null && !this.sourcesContent.has(t))
        throw new Error(`Unknown source file "${t}"`); if (e == null)
        throw new Error("The column in the generated code must be provided"); if (e < this.lastCol0)
        throw new Error("Mapping should be added in output order"); if (t && (s == null || r == null))
        throw new Error("The source location must be provided when a source url is provided"); return this.hasMappings = !0, this.lastCol0 = e, this.currentLine.push({ col0: e, sourceUrl: t, sourceLine0: s, sourceCol0: r }), this; }
    get currentLine() { return this.lines.slice(-1)[0]; }
    toJSON() { if (!this.hasMappings)
        return null; let e = new Map, t = [], s = []; Array.from(this.sourcesContent.keys()).forEach((l, p) => { e.set(l, p), t.push(l), s.push(this.sourcesContent.get(l) || null); }); let r = "", i = 0, o = 0, a = 0, c = 0; return this.lines.forEach(l => { i = 0, r += l.map(p => { let h = Si(p.col0 - i); return i = p.col0, p.sourceUrl != null && (h += Si(e.get(p.sourceUrl) - o), o = e.get(p.sourceUrl), h += Si(p.sourceLine0 - a), a = p.sourceLine0, h += Si(p.sourceCol0 - c), c = p.sourceCol0), h; }).join(","), r += ";"; }), r = r.slice(0, -1), { file: this.file || "", version: td, sourceRoot: "", sources: t, sourcesContent: s, mappings: r }; }
    toJsComment() { return this.hasMappings ? "//" + nd + sd(JSON.stringify(this, null, 0)) : ""; }
};
function sd(n) { let e = "", t = Kf(n); for (let s = 0; s < t.length;) {
    let r = t[s++], i = s < t.length ? t[s++] : null, o = s < t.length ? t[s++] : null;
    e += Js(r >> 2), e += Js((r & 3) << 4 | (i === null ? 0 : i >> 4)), e += i === null ? "=" : Js((i & 15) << 2 | (o === null ? 0 : o >> 6)), e += i === null || o === null ? "=" : Js(o & 63);
} return e; }
function Si(n) { n = n < 0 ? (-n << 1) + 1 : n << 1; let e = ""; do {
    let t = n & 31;
    n = n >> 5, n > 0 && (t = t | 32), e += Js(t);
} while (n > 0); return e; }
var rd = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function Js(n) { if (n < 0 || n >= 64)
    throw new Error("Can only encode value in the range [0, 63]"); return rd[n]; }
var id = /'|\\|\n|\r/g, od = /^[$A-Z_][0-9A-Z_$]*$/i, Ei = "  ", eo = class {
    indent;
    partsLength = 0;
    parts = [];
    srcSpans = [];
    constructor(e) { this.indent = e; }
}, ad = new Map([[x.And, "&&"], [x.Bigger, ">"], [x.BiggerEquals, ">="], [x.BitwiseOr, "|"], [x.BitwiseAnd, "&"], [x.Divide, "/"], [x.Assign, "="], [x.Equals, "=="], [x.Identical, "==="], [x.Lower, "<"], [x.LowerEquals, "<="], [x.Minus, "-"], [x.Modulo, "%"], [x.Exponentiation, "**"], [x.Multiply, "*"], [x.NotEquals, "!="], [x.NotIdentical, "!=="], [x.NullishCoalesce, "??"], [x.Or, "||"], [x.Plus, "+"], [x.In, "in"], [x.InstanceOf, "instanceof"], [x.AdditionAssignment, "+="], [x.SubtractionAssignment, "-="], [x.MultiplicationAssignment, "*="], [x.DivisionAssignment, "/="], [x.RemainderAssignment, "%="], [x.ExponentiationAssignment, "**="], [x.AndAssignment, "&&="], [x.OrAssignment, "||="], [x.NullishCoalesceAssignment, "??="]]), La = class n {
    _indent;
    static createRoot() { return new n(0); }
    _lines;
    constructor(e) { this._indent = e, this._lines = [new eo(e)]; }
    get _currentLine() { return this._lines[this._lines.length - 1]; }
    println(e, t = "") { this.print(e || null, t, !0); }
    lineIsEmpty() { return this._currentLine.parts.length === 0; }
    lineLength() { return this._currentLine.indent * Ei.length + this._currentLine.partsLength; }
    print(e, t, s = !1) { t.length > 0 && (this._currentLine.parts.push(t), this._currentLine.partsLength += t.length, this._currentLine.srcSpans.push(e && e.sourceSpan || null)), s && this._lines.push(new eo(this._indent)); }
    removeEmptyLastLine() { this.lineIsEmpty() && this._lines.pop(); }
    incIndent() { this._indent++, this.lineIsEmpty() && (this._currentLine.indent = this._indent); }
    decIndent() { this._indent--, this.lineIsEmpty() && (this._currentLine.indent = this._indent); }
    toSource() {
        return this.sourceLines.map(e => e.parts.length > 0 ? Ei.repeat(e.indent) + e.parts.join("") : "").join(`
`);
    }
    toSourceMapGenerator(e, t = 0) { let s = new Pa(e), r = !1, i = () => { r || (s.addSource(e, " ").addMapping(0, e, 0, 0), r = !0); }; for (let o = 0; o < t; o++)
        s.addLine(), i(); return this.sourceLines.forEach((o, a) => { s.addLine(); let c = o.srcSpans, l = o.parts, p = o.indent * Ei.length, h = 0; for (; h < c.length && !c[h];)
        p += l[h].length, h++; for (h < c.length && a === 0 && p === 0 ? r = !0 : i(); h < c.length;) {
        let d = c[h], v = d.start.file, w = d.start.line, y = d.start.col;
        for (s.addSource(v.url, v.content).addMapping(p, v.url, w, y), p += l[h].length, h++; h < c.length && (d === c[h] || !c[h]);)
            p += l[h].length, h++;
    } }), s; }
    spanOf(e, t) { let s = this._lines[e]; if (s) {
        let r = t - Ei.repeat(s.indent).length;
        for (let i = 0; i < s.parts.length; i++) {
            let o = s.parts[i];
            if (o.length > r)
                return s.srcSpans[i];
            r -= o.length;
        }
    } return null; }
    get sourceLines() { return this._lines.length && this._lines[this._lines.length - 1].parts.length === 0 ? this._lines.slice(0, -1) : this._lines; }
}, Ba = class {
    printComments;
    printTypes;
    lastIfCondition = null;
    constructor(e, t) { this.printComments = e, this.printTypes = t; }
    visitExpressionStmt(e, t) { this.printLeadingComments(e, t), e.expr.visitExpression(this, t), t.println(e, ";"); }
    visitReturnStmt(e, t) { this.printLeadingComments(e, t), t.print(e, "return "), e.value.visitExpression(this, t), t.println(e, ";"); }
    visitIfStmt(e, t) { this.printLeadingComments(e, t), t.print(e, "if ("), this.lastIfCondition = e.condition, e.condition.visitExpression(this, t), this.lastIfCondition = null, t.print(e, ") {"); let s = e.falseCase != null && e.falseCase.length > 0; e.trueCase.length <= 1 && !s ? (t.print(e, " "), this.visitAllStatements(e.trueCase, t), t.removeEmptyLastLine(), t.print(e, " ")) : (t.println(), t.incIndent(), this.visitAllStatements(e.trueCase, t), t.decIndent(), s && (t.println(e, "} else {"), t.incIndent(), this.visitAllStatements(e.falseCase, t), t.decIndent())), t.println(e, "}"); }
    visitDeclareVarStmt(e, t) { let s = e.hasModifier(xe.Final) ? "const" : "let"; this.printLeadingComments(e, t), t.print(e, `${s} ${e.name}`), e.type?.visitType(this, t), e.value && (t.print(e, " = "), e.value.visitExpression(this, t)), t.println(e, ";"); }
    visitInvokeFunctionExpr(e, t) { this.printLeadingComments(e, t); let s = this.shouldParenthesize(e.fn, e); s && t.print(e.fn, "("), e.fn.visitExpression(this, t), s && t.print(e.fn, ")"), t.print(e, e.isOptional ? "?.(" : "("), this.visitAllExpressions(e.args, t, ","), t.print(e, ")"); }
    visitTaggedTemplateLiteralExpr(e, t) { this.printLeadingComments(e, t), e.tag.visitExpression(this, t), e.template.visitExpression(this, t); }
    visitTemplateLiteralExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "`"); for (let s = 0; s < e.elements.length; s++) {
        e.elements[s].visitExpression(this, t);
        let r = s < e.expressions.length ? e.expressions[s] : null;
        r !== null && (t.print(r, "${"), r.visitExpression(this, t), t.print(r, "}"));
    } t.print(e, "`"); }
    visitTemplateLiteralElementExpr(e, t) { this.printLeadingComments(e, t), t.print(e, e.rawText); }
    visitTypeofExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "typeof "), e.expr.visitExpression(this, t); }
    visitVoidExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "void "), e.expr.visitExpression(this, t); }
    visitReadVarExpr(e, t) { this.printLeadingComments(e, t), t.print(e, e.name); }
    visitInstantiateExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "new "), e.classExpr.visitExpression(this, t), t.print(e, "("), this.visitAllExpressions(e.args, t, ","), t.print(e, ")"); }
    visitLiteralExpr(e, t) { this.printLeadingComments(e, t); let s = e.value; typeof s == "string" ? t.print(e, nn(s)) : t.print(e, `${s}`); }
    visitRegularExpressionLiteral(e, t) { this.printLeadingComments(e, t), t.print(e, `/${e.body}/${e.flags || ""}`); }
    visitLocalizedString(e, t) { this.printLeadingComments(e, t); let s = e.serializeI18nHead(); t.print(e, "$localize `" + s.raw); for (let r = 1; r < e.messageParts.length; r++)
        t.print(e, "${"), e.expressions[r - 1].visitExpression(this, t), t.print(e, `}${e.serializeI18nTemplatePart(r).raw}`); t.print(e, "`"); }
    visitConditionalExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "("), e.condition.visitExpression(this, t), t.print(e, " ? "), e.trueCase.visitExpression(this, t), t.print(e, " : "), e.falseCase?.visitExpression(this, t), t.print(e, ")"); }
    visitDynamicImportExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "import("), typeof e.url == "string" ? t.print(e, nn(e.url, !0)) : e.url.visitExpression(this, t), t.print(e, ")"); }
    visitNotExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "!"), e.condition.visitExpression(this, t); }
    visitFunctionExpr(e, t) { this.printLeadingComments(e, t), t.print(e, `function${e.name ? " " + e.name : ""}(`), this.visitParams(e.params, t), t.print(e, ")"), e.type?.visitType(this, t), t.print(e, " {"), t.println(e), t.incIndent(), this.visitAllStatements(e.statements, t), t.decIndent(), t.println(e, "}"); }
    visitArrowFunctionExpr(e, t) { if (this.printLeadingComments(e, t), t.print(e, "("), this.visitParams(e.params, t), t.print(e, ")"), e.type?.visitType(this, t), t.print(e, " => "), Array.isArray(e.body))
        t.print(e, "{"), t.println(e), t.incIndent(), this.visitAllStatements(e.body, t), t.decIndent(), t.println(e, "}");
    else {
        let s = this.shouldParenthesize(e.body, e);
        s && t.print(e, "("), e.body.visitExpression(this, t), s && t.print(e, ")");
    } }
    visitDeclareFunctionStmt(e, t) { this.printLeadingComments(e, t), t.print(e, `function ${e.name}(`), this.visitParams(e.params, t), t.print(e, ")"), e.type?.visitType(this, t), t.print(e, " {"), t.println(e), t.incIndent(), this.visitAllStatements(e.statements, t), t.decIndent(), t.println(e, "}"); }
    visitUnaryOperatorExpr(e, t) { this.printLeadingComments(e, t); let s; switch (e.operator) {
        case dr.Plus:
            s = "+";
            break;
        case dr.Minus:
            s = "-";
            break;
        default: throw new Error(`Unknown operator ${e.operator}`);
    } let r = e !== this.lastIfCondition; r && t.print(e, "("), t.print(e, s), e.expr.visitExpression(this, t), r && t.print(e, ")"); }
    visitBinaryOperatorExpr(e, t) { this.printLeadingComments(e, t); let s = ad.get(e.operator); if (!s)
        throw new Error(`Unknown operator ${e.operator}`); let r = e !== this.lastIfCondition; r && t.print(e, "("), e.lhs.visitExpression(this, t), t.print(e, ` ${s} `), e.rhs.visitExpression(this, t), r && t.print(e, ")"); }
    visitReadPropExpr(e, t) { this.printLeadingComments(e, t), e.receiver.visitExpression(this, t), t.print(e, e.isOptional ? "?." : "."), t.print(e, e.name); }
    visitReadKeyExpr(e, t) { this.printLeadingComments(e, t), e.receiver.visitExpression(this, t), t.print(e, e.isOptional ? "?.[" : "["), e.index.visitExpression(this, t), t.print(e, "]"); }
    visitLiteralArrayExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "["), this.visitAllExpressions(e.entries, t, ", "), t.print(e, "]"); }
    visitLiteralMapExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "{"), this.visitAllObjects(s => { s instanceof on ? (t.print(e, "..."), s.expression.visitExpression(this, t)) : (t.print(e, `${nn(s.key, s.quoted)}: `), s.value.visitExpression(this, t)); }, e.entries, t, ", "), t.print(e, "}"); }
    visitCommaExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "("), this.visitAllExpressions(e.parts, t, ", "), t.print(e, ")"); }
    visitParenthesizedExpr(e, t) { this.printLeadingComments(e, t), e.expr.visitExpression(this, t); }
    visitSpreadElementExpr(e, t) { this.printLeadingComments(e, t), t.print(e, "..."), e.expression.visitExpression(this, t); }
    visitBuiltinType(e, t) { if (this.printTypes)
        switch (e.name) {
            case Ce.Bool:
                t.print(null, ": boolean");
                break;
            case Ce.Dynamic:
                t.print(null, ": any");
                break;
            case Ce.Int:
            case Ce.Number:
                t.print(null, ": number");
                break;
            case Ce.String:
                t.print(null, ": string");
                break;
            case Ce.None:
                t.print(null, ": void");
                break;
            case Ce.Inferred: break;
            case Ce.Function:
                t.print(null, ": Function");
                break;
            default:
                t.print(null, ": any");
                break;
        } }
    visitExpressionType(e, t) { this.printTypes && (t.print(null, ": "), e.value.visitExpression(this, t), e.typeParams && e.typeParams.length > 0 && (t.print(null, "<"), this.visitAllObjects(s => s.visitType(this, t), e.typeParams, t, ","), t.print(null, ">"))); }
    visitArrayType(e, t) { this.printTypes && (t.print(null, ": "), e.of.visitType(this, t), t.print(null, "[]")); }
    visitMapType(e, t) { this.printTypes && (t.print(null, ": { [key: string]: "), e.valueType ? e.valueType.visitType(this, t) : t.print(null, "any"), t.print(null, "}")); }
    visitTransplantedType(e, t) { throw new Error("TransplantedType nodes are not supported"); }
    visitAllExpressions(e, t, s) { this.visitAllObjects(r => r.visitExpression(this, t), e, t, s); }
    visitAllObjects(e, t, s, r) { for (let i = 0; i < t.length; i++)
        i > 0 && s.print(null, r, !1), e(t[i]); }
    visitAllStatements(e, t) { e.forEach(s => s.visitStatement(this, t)); }
    visitParams(e, t) { this.visitAllObjects(s => { t.print(null, s.name), s.type?.visitType(this, t); }, e, t, ", "); }
    shouldParenthesize(e, t) { return (e instanceof rn || e instanceof Vt) && t instanceof pe || e instanceof vt && t instanceof rn; }
    printLeadingComments(e, t) {
        if (!(!this.printComments || e.leadingComments === void 0))
            for (let s of e.leadingComments)
                s instanceof Yi ? t.print(e, `/*${s.toString()}*/`, s.trailingNewline) : s.multiline ? t.print(e, `/* ${s.text} */`, s.trailingNewline) : s.text.split(`
`).forEach(r => t.println(e, `// ${r}`));
    }
};
function nn(n, e = !0) {
    if (n == null)
        return null;
    let t = n.replace(id, (...r) => r[0] == `
` ? "\\n" : r[0] == "\r" ? "\\r" : `\\${r[0]}`);
    return e || !od.test(t) ? `'${t}'` : t;
}
var cd = /[-.]/, cl = /^[$A-Z_][0-9A-Z_$]*$/i, $p = /^let\s+([\S\s]*)/;
function Yo(n, e) { if (e === 0)
    return we(n); let t = []; for (let s = 0; s < e; s++)
    t.push(ge); return we(n, void 0, t); }
function ld(n, e) { let t = nn(e, !1); return t !== e ? `${n}[${t}]` : `${n}.${e}`; }
function ud(n) { return pd("ngJitMode", n); }
function pd(n, e) { let t = new Fn({ name: n, moduleName: null }), s = new H(x.Identical, new Es(t), g("undefined")), r = new H(x.Or, s, t, void 0, void 0); return new H(x.And, r, e); }
function ie(n) { let e = new q(n); return { value: e, type: e }; }
function bn(n, e) { let t = X(n.map(s => s.value)); return e ? je([], t) : t; }
function xr() { return Of("@ts-ignore", !0, !0); }
function Mp(n) { return cd.test(n); }
function ll(n, e) { return { expression: n, forwardRef: e }; }
function hd({ expression: n, forwardRef: e }) { switch (e) {
    case 0:
    case 1: return n;
    case 2: return fd(n);
} }
function fd(n) { return A(f.forwardRef).callFn([je([], n)]); }
var to = (function (n) { return n[n.Class = 0] = "Class", n[n.Function = 1] = "Function", n; })(to || {});
function xn(n) { let e = F("__ngFactoryType__"), t = null, s = Gl(n) ? e : new H(x.Or, e, n.type.value), r = null, i = n.deps !== null && n.deps !== "invalid" && n.deps.length > 0 ? [xr()] : void 0; n.deps !== null ? n.deps !== "invalid" && (r = new gr(s, zl(n.deps, n.target))) : (t = F(`\u0275${n.name}_BaseFactory`), r = t.callFn([s])); let o = [], a = null; function c(p) { let h = F("__ngConditionalFactory__"); o.push(new ve(h.name, Cs, ge)); let d = r !== null ? h.set(r).toStmt(i) : A(f.invalidFactory).callFn([]).toStmt(); return o.push(Qo(e, [d], [h.set(p).toStmt([xr()])])), h; } if (Gl(n)) {
    let p = zl(n.delegateDeps, n.target), h = new (n.delegateType === to.Class ? gr : pe)(n.delegate, p);
    a = c(h);
}
else
    wd(n) ? a = c(n.expression) : a = r; if (a === null)
    o.push(A(f.invalidFactory).callFn([]).toStmt());
else if (t !== null) {
    let p = A(f.getInheritedFactory).callFn([n.type.value]), h = new H(x.Or, t, t.set(p));
    o.push(new fe(h.callFn([s])));
}
else
    o.push(new fe(a, null, i)); let l = an([new he(e.name, ge)], o, It, void 0, `${n.name}_Factory`); return t !== null && (l = je([], [new ve(t.name, void 0, ge), new fe(l)]).callFn([], void 0, !0)), { expression: l, statements: [], type: dd(n) }; }
function dd(n) { let e = n.deps !== null && n.deps !== "invalid" ? gd(n.deps) : Je; return we(A(f.FactoryDeclaration, [Yo(n.type.type, n.typeArgumentCount), e])); }
function zl(n, e) { return n.map((t, s) => md(t, e, s)); }
function md(n, e, t) { if (n.token === null)
    return A(f.invalidFactoryDep).callFn([g(t)]); if (n.attributeNameType === null) {
    let s = 0 | (n.self ? 2 : 0) | (n.skipSelf ? 4 : 0) | (n.host ? 1 : 0) | (n.optional ? 8 : 0) | (e === Rt.Pipe ? 16 : 0), r = s !== 0 || n.optional ? g(s) : null, i = [n.token];
    r && i.push(r);
    let o = Sd(e);
    return A(o).callFn(i);
}
else
    return A(f.injectAttribute).callFn([n.token]); }
function gd(n) { let e = !1, t = n.map(s => { let r = vd(s); return r !== null ? (e = !0, r) : g(null); }); return e ? we(X(t)) : Je; }
function vd(n) { let e = []; return n.attributeNameType !== null && e.push({ key: "attribute", value: n.attributeNameType, quoted: !1 }), n.optional && e.push({ key: "optional", value: g(!0), quoted: !1 }), n.host && e.push({ key: "host", value: g(!0), quoted: !1 }), n.self && e.push({ key: "self", value: g(!0), quoted: !1 }), n.skipSelf && e.push({ key: "skipSelf", value: g(!0), quoted: !1 }), e.length > 0 ? nt(e) : null; }
function Gl(n) { return n.delegateType !== void 0; }
function wd(n) { return n.expression !== void 0; }
function Sd(n) { switch (n) {
    case Rt.Component:
    case Rt.Directive:
    case Rt.Pipe: return f.directiveInject;
    case Rt.NgModule:
    case Rt.Injectable:
    default: return f.inject;
} }
var Hn = class {
    start;
    end;
    constructor(e, t) { this.start = e, this.end = t; }
    toAbsolute(e) { return new Ke(e + this.start, e + this.end); }
}, Q = class {
    span;
    sourceSpan;
    constructor(e, t) { this.span = e, this.sourceSpan = t; }
    toString() { return "AST"; }
}, yr = class extends Q {
    nameSpan;
    constructor(e, t, s) { super(e, t), this.nameSpan = s; }
}, Te = class extends Q {
    visit(e, t = null) { return e.visitEmptyExpr?.(this, t); }
}, Pt = class extends Q {
    visit(e, t = null) { return e.visitImplicitReceiver(this, t); }
}, Cr = class extends Q {
    visit(e, t = null) { return e.visitThisReceiver?.(this, t); }
}, bs = class extends Q {
    expressions;
    constructor(e, t, s) { super(e, t), this.expressions = s; }
    visit(e, t = null) { return e.visitChain(this, t); }
}, no = class extends Q {
    condition;
    trueExp;
    falseExp;
    constructor(e, t, s, r, i) { super(e, t), this.condition = s, this.trueExp = r, this.falseExp = i; }
    visit(e, t = null) { return e.visitConditional(this, t); }
}, kt = class extends yr {
    receiver;
    name;
    constructor(e, t, s, r, i) { super(e, t, s), this.receiver = r, this.name = i; }
    visit(e, t = null) { return e.visitPropertyRead(this, t); }
}, br = class extends yr {
    receiver;
    name;
    constructor(e, t, s, r, i) { super(e, t, s), this.receiver = r, this.name = i; }
    visit(e, t = null) { return e.visitSafePropertyRead(this, t); }
}, Un = class extends Q {
    receiver;
    key;
    constructor(e, t, s, r) { super(e, t), this.receiver = s, this.key = r; }
    visit(e, t = null) { return e.visitKeyedRead(this, t); }
}, Ar = class extends Q {
    receiver;
    key;
    constructor(e, t, s, r) { super(e, t), this.receiver = s, this.key = r; }
    visit(e, t = null) { return e.visitSafeKeyedRead(this, t); }
}, Mi = (function (n) { return n[n.ReferencedByName = 0] = "ReferencedByName", n[n.ReferencedDirectly = 1] = "ReferencedDirectly", n; })(Mi || {}), so = class extends yr {
    exp;
    name;
    args;
    type;
    constructor(e, t, s, r, i, o, a) { super(e, t, a), this.exp = s, this.name = r, this.args = i, this.type = o; }
    visit(e, t = null) { return e.visitPipe(this, t); }
}, Qe = class extends Q {
    value;
    constructor(e, t, s) { super(e, t), this.value = s; }
    visit(e, t = null) { return e.visitLiteralPrimitive(this, t); }
}, kr = class extends Q {
    expressions;
    constructor(e, t, s) { super(e, t), this.expressions = s; }
    visit(e, t = null) { return e.visitLiteralArray(this, t); }
}, ro = class extends Q {
    expression;
    constructor(e, t, s) { super(e, t), this.expression = s; }
    visit(e, t = null) { return e.visitSpreadElement(this, t); }
}, Wn = class extends Q {
    keys;
    values;
    constructor(e, t, s, r) { super(e, t), this.keys = s, this.values = r; }
    visit(e, t = null) { return e.visitLiteralMap(this, t); }
}, mi = class extends Q {
    strings;
    expressions;
    constructor(e, t, s, r) { super(e, t), this.strings = s, this.expressions = r; }
    visit(e, t = null) { return e.visitInterpolation(this, t); }
}, Ne = class extends Q {
    operation;
    left;
    right;
    constructor(e, t, s, r, i) { super(e, t), this.operation = s, this.left = r, this.right = i; }
    visit(e, t = null) { return e.visitBinary(this, t); }
    static isAssignmentOperation(e) { return e === "=" || e === "+=" || e === "-=" || e === "*=" || e === "/=" || e === "%=" || e === "**=" || e === "&&=" || e === "||=" || e === "??="; }
}, vs = class n extends Ne {
    operator;
    expr;
    left = null;
    right = null;
    operation = null;
    static createMinus(e, t, s) { return new n(e, t, "-", s, "-", new Qe(e, t, 0), s); }
    static createPlus(e, t, s) { return new n(e, t, "+", s, "-", s, new Qe(e, t, 0)); }
    constructor(e, t, s, r, i, o, a) { super(e, t, i, o, a), this.operator = s, this.expr = r; }
    visit(e, t = null) { return e.visitUnary !== void 0 ? e.visitUnary(this, t) : e.visitBinary(this, t); }
}, Tr = class extends Q {
    expression;
    constructor(e, t, s) { super(e, t), this.expression = s; }
    visit(e, t = null) { return e.visitPrefixNot(this, t); }
}, _r = class extends Q {
    expression;
    constructor(e, t, s) { super(e, t), this.expression = s; }
    visit(e, t = null) { return e.visitTypeofExpression(this, t); }
}, Ir = class extends Q {
    expression;
    constructor(e, t, s) { super(e, t), this.expression = s; }
    visit(e, t = null) { return e.visitVoidExpression(this, t); }
}, Nr = class extends Q {
    expression;
    constructor(e, t, s) { super(e, t), this.expression = s; }
    visit(e, t = null) { return e.visitNonNullAssert(this, t); }
}, jn = class extends Q {
    receiver;
    args;
    argumentSpan;
    constructor(e, t, s, r, i) { super(e, t), this.receiver = s, this.args = r, this.argumentSpan = i; }
    visit(e, t = null) { return e.visitCall(this, t); }
}, io = class extends Q {
    receiver;
    args;
    argumentSpan;
    constructor(e, t, s, r, i) { super(e, t), this.receiver = s, this.args = r, this.argumentSpan = i; }
    visit(e, t = null) { return e.visitSafeCall(this, t); }
}, Dr = class extends Q {
    tag;
    template;
    constructor(e, t, s, r) { super(e, t), this.tag = s, this.template = r; }
    visit(e, t) { return e.visitTaggedTemplateLiteral(this, t); }
}, Pr = class extends Q {
    elements;
    expressions;
    constructor(e, t, s, r) { super(e, t), this.elements = s, this.expressions = r; }
    visit(e, t) { return e.visitTemplateLiteral(this, t); }
}, oo = class extends Q {
    text;
    constructor(e, t, s) { super(e, t), this.text = s; }
    visit(e, t) { return e.visitTemplateLiteralElement(this, t); }
}, Lr = class extends Q {
    expression;
    constructor(e, t, s) { super(e, t), this.expression = s; }
    visit(e, t) { return e.visitParenthesizedExpression(this, t); }
}, $a = class {
    name;
    span;
    sourceSpan;
    constructor(e, t, s) { this.name = e, this.span = t, this.sourceSpan = s; }
}, ao = class extends Q {
    parameters;
    body;
    constructor(e, t, s, r) { super(e, t), this.parameters = s, this.body = r; }
    visit(e, t) { return e.visitArrowFunction(this, t); }
}, co = class extends Q {
    body;
    flags;
    constructor(e, t, s, r) { super(e, t), this.body = s, this.flags = r; }
    visit(e, t) { return e.visitRegularExpressionLiteral(this, t); }
}, Ke = class {
    start;
    end;
    constructor(e, t) { this.start = e, this.end = t; }
}, Ue = class extends Q {
    ast;
    source;
    location;
    errors;
    constructor(e, t, s, r, i) { super(new Hn(0, t === null ? 0 : t.length), new Ke(r, t === null ? r : r + t.length)), this.ast = e, this.source = t, this.location = s, this.errors = i; }
    visit(e, t = null) { return e.visitASTWithSource ? e.visitASTWithSource(this, t) : this.ast.visit(e, t); }
    toString() { return `${this.source} in ${this.location}`; }
}, Br = class {
    sourceSpan;
    key;
    value;
    constructor(e, t, s) { this.sourceSpan = e, this.key = t, this.value = s; }
}, Ma = class {
    sourceSpan;
    key;
    value;
    constructor(e, t, s) { this.sourceSpan = e, this.key = t, this.value = s; }
}, As = class {
    visit(e, t) { e.visit(this, t); }
    visitUnary(e, t) { this.visit(e.expr, t); }
    visitBinary(e, t) { this.visit(e.left, t), this.visit(e.right, t); }
    visitChain(e, t) { this.visitAll(e.expressions, t); }
    visitConditional(e, t) { this.visit(e.condition, t), this.visit(e.trueExp, t), this.visit(e.falseExp, t); }
    visitPipe(e, t) { this.visit(e.exp, t), this.visitAll(e.args, t); }
    visitImplicitReceiver(e, t) { }
    visitThisReceiver(e, t) { }
    visitInterpolation(e, t) { this.visitAll(e.expressions, t); }
    visitKeyedRead(e, t) { this.visit(e.receiver, t), this.visit(e.key, t); }
    visitLiteralArray(e, t) { this.visitAll(e.expressions, t); }
    visitLiteralMap(e, t) { this.visitAll(e.values, t); }
    visitLiteralPrimitive(e, t) { }
    visitPrefixNot(e, t) { this.visit(e.expression, t); }
    visitTypeofExpression(e, t) { this.visit(e.expression, t); }
    visitVoidExpression(e, t) { this.visit(e.expression, t); }
    visitNonNullAssert(e, t) { this.visit(e.expression, t); }
    visitPropertyRead(e, t) { this.visit(e.receiver, t); }
    visitSafePropertyRead(e, t) { this.visit(e.receiver, t); }
    visitSafeKeyedRead(e, t) { this.visit(e.receiver, t), this.visit(e.key, t); }
    visitCall(e, t) { this.visit(e.receiver, t), this.visitAll(e.args, t); }
    visitSafeCall(e, t) { this.visit(e.receiver, t), this.visitAll(e.args, t); }
    visitTemplateLiteral(e, t) { for (let s = 0; s < e.elements.length; s++) {
        this.visit(e.elements[s], t);
        let r = s < e.expressions.length ? e.expressions[s] : null;
        r !== null && this.visit(r, t);
    } }
    visitTemplateLiteralElement(e, t) { }
    visitTaggedTemplateLiteral(e, t) { this.visit(e.tag, t), this.visit(e.template, t); }
    visitParenthesizedExpression(e, t) { this.visit(e.expression, t); }
    visitArrowFunction(e, t) { this.visit(e.body, t); }
    visitRegularExpressionLiteral(e, t) { }
    visitSpreadElement(e, t) { this.visit(e.expression, t); }
    visitEmptyExpr(e, t) { }
    visitAll(e, t) { for (let s of e)
        this.visit(s, t); }
}, us = class {
    name;
    expression;
    type;
    sourceSpan;
    keySpan;
    valueSpan;
    isLiteral;
    isLegacyAnimation;
    isAnimation;
    constructor(e, t, s, r, i, o) { this.name = e, this.expression = t, this.type = s, this.sourceSpan = r, this.keySpan = i, this.valueSpan = o, this.isLiteral = this.type === yt.LITERAL_ATTR, this.isLegacyAnimation = this.type === yt.LEGACY_ANIMATION, this.isAnimation = this.type === yt.ANIMATION; }
}, yt = (function (n) { return n[n.DEFAULT = 0] = "DEFAULT", n[n.LITERAL_ATTR = 1] = "LITERAL_ATTR", n[n.LEGACY_ANIMATION = 2] = "LEGACY_ANIMATION", n[n.TWO_WAY = 3] = "TWO_WAY", n[n.ANIMATION = 4] = "ANIMATION", n; })(yt || {}), $e = (function (n) { return n[n.Regular = 0] = "Regular", n[n.LegacyAnimation = 1] = "LegacyAnimation", n[n.TwoWay = 2] = "TwoWay", n[n.Animation = 3] = "Animation", n; })($e || {}), lo = class {
    name;
    targetOrPhase;
    type;
    handler;
    sourceSpan;
    handlerSpan;
    keySpan;
    constructor(e, t, s, r, i, o, a) { this.name = e, this.targetOrPhase = t, this.type = s, this.handler = r, this.sourceSpan = i, this.handlerSpan = o, this.keySpan = a; }
}, Ra = class {
    name;
    value;
    sourceSpan;
    keySpan;
    valueSpan;
    constructor(e, t, s, r, i) { this.name = e, this.value = t, this.sourceSpan = s, this.keySpan = r, this.valueSpan = i; }
}, U = (function (n) { return n[n.Property = 0] = "Property", n[n.Attribute = 1] = "Attribute", n[n.Class = 2] = "Class", n[n.Style = 3] = "Style", n[n.LegacyAnimation = 4] = "LegacyAnimation", n[n.TwoWay = 5] = "TwoWay", n[n.Animation = 6] = "Animation", n; })(U || {}), uo = class {
    name;
    type;
    securityContext;
    value;
    unit;
    sourceSpan;
    keySpan;
    valueSpan;
    constructor(e, t, s, r, i, o, a, c) { this.name = e, this.type = t, this.securityContext = s, this.value = r, this.unit = i, this.sourceSpan = o, this.keySpan = a, this.valueSpan = c; }
}, Ct = (function (n) { return n[n.RAW_TEXT = 0] = "RAW_TEXT", n[n.ESCAPABLE_RAW_TEXT = 1] = "ESCAPABLE_RAW_TEXT", n[n.PARSABLE_DATA = 2] = "PARSABLE_DATA", n; })(Ct || {});
function be(n, e = !0) { if (n[0] != ":")
    return [null, n]; let t = n.indexOf(":", 1); if (t === -1) {
    if (e)
        throw new Error(`Unsupported format "${n}" expecting ":namespace:name"`);
    return [null, n];
} return [n.slice(1, t), n.slice(t + 1)]; }
function Xl(n) { return be(n)[1] === "ng-container"; }
function Fa(n) { return be(n)[1] === "ng-content"; }
function Ed(n) { return be(n)[1] === "ng-template"; }
function Oa(n) { return n === null ? null : be(n)[0]; }
function Ri(n, e) { return n ? `:${n}:${e}` : e; }
var An = class {
    value;
    sourceSpan;
    constructor(e, t) { this.value = e, this.sourceSpan = t; }
    visit(e) { throw new Error("visit() not implemented for Comment"); }
}, kn = class {
    value;
    sourceSpan;
    constructor(e, t) { this.value = e, this.sourceSpan = t; }
    visit(e) { return e.visitText(this); }
}, ks = class {
    value;
    sourceSpan;
    i18n;
    constructor(e, t, s) { this.value = e, this.sourceSpan = t, this.i18n = s; }
    visit(e) { return e.visitBoundText(this); }
}, Ts = class {
    name;
    value;
    sourceSpan;
    keySpan;
    valueSpan;
    i18n;
    constructor(e, t, s, r, i, o) { this.name = e, this.value = t, this.sourceSpan = s, this.keySpan = r, this.valueSpan = i, this.i18n = o; }
    visit(e) { return e.visitTextAttribute(this); }
}, Va = class n {
    name;
    type;
    securityContext;
    value;
    unit;
    sourceSpan;
    keySpan;
    valueSpan;
    i18n;
    constructor(e, t, s, r, i, o, a, c, l) { this.name = e, this.type = t, this.securityContext = s, this.value = r, this.unit = i, this.sourceSpan = o, this.keySpan = a, this.valueSpan = c, this.i18n = l; }
    static fromBoundElementProperty(e, t) { if (e.keySpan === void 0)
        throw new Error(`Unexpected state: keySpan must be defined for bound attributes but was not for ${e.name}: ${e.sourceSpan}`); return new n(e.name, e.type, e.securityContext, e.value, e.unit, e.sourceSpan, e.keySpan, e.valueSpan, t); }
    visit(e) { return e.visitBoundAttribute(this); }
}, qa = class n {
    name;
    type;
    handler;
    target;
    phase;
    sourceSpan;
    handlerSpan;
    keySpan;
    constructor(e, t, s, r, i, o, a, c) { this.name = e, this.type = t, this.handler = s, this.target = r, this.phase = i, this.sourceSpan = o, this.handlerSpan = a, this.keySpan = c; }
    static fromParsedEvent(e) { let t = e.type === $e.Regular ? e.targetOrPhase : null, s = e.type === $e.LegacyAnimation ? e.targetOrPhase : null; if (e.keySpan === void 0)
        throw new Error(`Unexpected state: keySpan must be defined for bound event but was not for ${e.name}: ${e.sourceSpan}`); return new n(e.name, e.type, e.handler, t, s, e.sourceSpan, e.handlerSpan, e.keySpan); }
    visit(e) { return e.visitBoundEvent(this); }
}, wt = class {
    name;
    attributes;
    inputs;
    outputs;
    directives;
    children;
    references;
    isSelfClosing;
    sourceSpan;
    startSourceSpan;
    endSourceSpan;
    isVoid;
    i18n;
    constructor(e, t, s, r, i, o, a, c, l, p, h, d, v) { this.name = e, this.attributes = t, this.inputs = s, this.outputs = r, this.directives = i, this.children = o, this.references = a, this.isSelfClosing = c, this.sourceSpan = l, this.startSourceSpan = p, this.endSourceSpan = h, this.isVoid = d, this.i18n = v; }
    visit(e) { return e.visitElement(this); }
}, Lt = class {
    nameSpan;
    sourceSpan;
    prefetchSpan;
    whenOrOnSourceSpan;
    hydrateSpan;
    constructor(e, t, s, r, i) { this.nameSpan = e, this.sourceSpan = t, this.prefetchSpan = s, this.whenOrOnSourceSpan = r, this.hydrateSpan = i; }
    visit(e) { return e.visitDeferredTrigger(this); }
}, po = class extends Lt {
    value;
    constructor(e, t, s, r, i) { super(null, t, s, r, i), this.value = e; }
}, Ha = class extends Lt {
}, Ua = class extends Lt {
    timeout;
    constructor(e, t, s, r, i, o) { super(e, t, s, r, i), this.timeout = o; }
}, Wa = class extends Lt {
}, ho = class extends Lt {
    reference;
    constructor(e, t, s, r, i, o) { super(t, s, r, i, o), this.reference = e; }
}, ja = class extends Lt {
    delay;
    constructor(e, t, s, r, i, o) { super(t, s, r, i, o), this.delay = e; }
}, fo = class extends Lt {
    reference;
    constructor(e, t, s, r, i, o) { super(t, s, r, i, o), this.reference = e; }
}, $r = class extends Lt {
    reference;
    options;
    constructor(e, t, s, r, i, o, a) { super(s, r, i, o, a), this.reference = e, this.options = t; }
}, Fe = class {
    nameSpan;
    sourceSpan;
    startSourceSpan;
    endSourceSpan;
    constructor(e, t, s, r) { this.nameSpan = e, this.sourceSpan = t, this.startSourceSpan = s, this.endSourceSpan = r; }
}, Mr = class extends Fe {
    children;
    minimumTime;
    i18n;
    constructor(e, t, s, r, i, o, a) { super(s, r, i, o), this.children = e, this.minimumTime = t, this.i18n = a; }
    visit(e) { return e.visitDeferredBlockPlaceholder(this); }
}, Rr = class extends Fe {
    children;
    afterTime;
    minimumTime;
    i18n;
    constructor(e, t, s, r, i, o, a, c) { super(r, i, o, a), this.children = e, this.afterTime = t, this.minimumTime = s, this.i18n = c; }
    visit(e) { return e.visitDeferredBlockLoading(this); }
}, Fr = class extends Fe {
    children;
    i18n;
    constructor(e, t, s, r, i, o) { super(t, s, r, i), this.children = e, this.i18n = o; }
    visit(e) { return e.visitDeferredBlockError(this); }
}, _s = class extends Fe {
    name;
    variables;
    children;
    i18n;
    constructor(e, t, s, r, i, o, a, c) { super(r, i, o, a), this.name = e, this.variables = t, this.children = s, this.i18n = c; }
    visit(e) { return e.visitContentBlock(this); }
}, zn = class extends Fe {
    children;
    placeholder;
    loading;
    error;
    mainBlockSpan;
    i18n;
    triggers;
    prefetchTriggers;
    hydrateTriggers;
    definedTriggers;
    definedPrefetchTriggers;
    definedHydrateTriggers;
    constructor(e, t, s, r, i, o, a, c, l, p, h, d, v) { super(c, l, h, d), this.children = e, this.placeholder = i, this.loading = o, this.error = a, this.mainBlockSpan = p, this.i18n = v, this.triggers = t, this.prefetchTriggers = s, this.hydrateTriggers = r, this.definedTriggers = Object.keys(t), this.definedPrefetchTriggers = Object.keys(s), this.definedHydrateTriggers = Object.keys(r); }
    visit(e) { return e.visitDeferredBlock(this); }
    visitAll(e) { this.visitTriggers(this.definedHydrateTriggers, this.hydrateTriggers, e), this.visitTriggers(this.definedTriggers, this.triggers, e), this.visitTriggers(this.definedPrefetchTriggers, this.prefetchTriggers, e), oa(e, this.children); let t = [this.placeholder, this.loading, this.error].filter(s => s !== null); oa(e, t); }
    visitTriggers(e, t, s) { oa(s, e.map(r => t[r])); }
}, mo = class extends Fe {
    expression;
    groups;
    unknownBlocks;
    exhaustiveCheck;
    constructor(e, t, s, r, i, o, a, c) { super(c, i, o, a), this.expression = e, this.groups = t, this.unknownBlocks = s, this.exhaustiveCheck = r; }
    visit(e) { return e.visitSwitchBlock(this); }
}, za = class extends Fe {
    expression;
    constructor(e, t, s, r, i) { super(i, t, s, r), this.expression = e; }
    visit(e) { return e.visitSwitchBlockCase(this); }
}, Or = class extends Fe {
    cases;
    children;
    i18n;
    constructor(e, t, s, r, i, o, a) { super(o, s, r, i), this.cases = e, this.children = t, this.i18n = a; }
    visit(e) { return e.visitSwitchBlockCaseGroup(this); }
}, Ga = class extends Fe {
    expression;
    constructor(e, t, s, r, i) { super(i, t, s, r), this.expression = e; }
    visit(e) { return e.visitSwitchExhaustiveCheck(this); }
}, Is = class extends Fe {
    item;
    expression;
    trackBy;
    trackKeywordSpan;
    contextVariables;
    children;
    empty;
    mainBlockSpan;
    i18n;
    constructor(e, t, s, r, i, o, a, c, l, p, h, d, v) { super(d, c, p, h), this.item = e, this.expression = t, this.trackBy = s, this.trackKeywordSpan = r, this.contextVariables = i, this.children = o, this.empty = a, this.mainBlockSpan = l, this.i18n = v; }
    visit(e) { return e.visitForLoopBlock(this); }
}, Vr = class extends Fe {
    children;
    i18n;
    constructor(e, t, s, r, i, o) { super(i, t, s, r), this.children = e, this.i18n = o; }
    visit(e) { return e.visitForLoopBlockEmpty(this); }
}, go = class extends Fe {
    branches;
    constructor(e, t, s, r, i) { super(i, t, s, r), this.branches = e; }
    visit(e) { return e.visitIfBlock(this); }
}, In = class extends Fe {
    expression;
    children;
    expressionAlias;
    i18n;
    constructor(e, t, s, r, i, o, a, c) { super(a, r, i, o), this.expression = e, this.children = t, this.expressionAlias = s, this.i18n = c; }
    visit(e) { return e.visitIfBlockBranch(this); }
}, vo = class {
    name;
    sourceSpan;
    nameSpan;
    constructor(e, t, s) { this.name = e, this.sourceSpan = t, this.nameSpan = s; }
    visit(e) { return e.visitUnknownBlock(this); }
}, ul = class {
    name;
    value;
    sourceSpan;
    nameSpan;
    valueSpan;
    constructor(e, t, s, r, i) { this.name = e, this.value = t, this.sourceSpan = s, this.nameSpan = r, this.valueSpan = i; }
    visit(e) { return e.visitLetDeclaration(this); }
}, sr = class {
    componentName;
    tagName;
    fullName;
    attributes;
    inputs;
    outputs;
    directives;
    children;
    references;
    isSelfClosing;
    sourceSpan;
    startSourceSpan;
    endSourceSpan;
    i18n;
    constructor(e, t, s, r, i, o, a, c, l, p, h, d, v, w) { this.componentName = e, this.tagName = t, this.fullName = s, this.attributes = r, this.inputs = i, this.outputs = o, this.directives = a, this.children = c, this.references = l, this.isSelfClosing = p, this.sourceSpan = h, this.startSourceSpan = d, this.endSourceSpan = v, this.i18n = w; }
    visit(e) { return e.visitComponent(this); }
}, Rp = class {
    name;
    attributes;
    inputs;
    outputs;
    references;
    sourceSpan;
    startSourceSpan;
    endSourceSpan;
    i18n;
    constructor(e, t, s, r, i, o, a, c, l) { this.name = e, this.attributes = t, this.inputs = s, this.outputs = r, this.references = i, this.sourceSpan = o, this.startSourceSpan = a, this.endSourceSpan = c, this.i18n = l; }
    visit(e) { return e.visitDirective(this); }
}, et = class {
    tagName;
    attributes;
    inputs;
    outputs;
    directives;
    templateAttrs;
    children;
    references;
    variables;
    isSelfClosing;
    sourceSpan;
    startSourceSpan;
    endSourceSpan;
    i18n;
    constructor(e, t, s, r, i, o, a, c, l, p, h, d, v, w) { this.tagName = e, this.attributes = t, this.inputs = s, this.outputs = r, this.directives = i, this.templateAttrs = o, this.children = a, this.references = c, this.variables = l, this.isSelfClosing = p, this.sourceSpan = h, this.startSourceSpan = d, this.endSourceSpan = v, this.i18n = w; }
    visit(e) { return e.visitTemplate(this); }
}, Ns = class {
    selector;
    attributes;
    children;
    isSelfClosing;
    sourceSpan;
    startSourceSpan;
    endSourceSpan;
    i18n;
    name = "ng-content";
    constructor(e, t, s, r, i, o, a, c) { this.selector = e, this.attributes = t, this.children = s, this.isSelfClosing = r, this.sourceSpan = i, this.startSourceSpan = o, this.endSourceSpan = a, this.i18n = c; }
    visit(e) { return e.visitContent(this); }
}, Wt = class {
    name;
    value;
    sourceSpan;
    keySpan;
    valueSpan;
    constructor(e, t, s, r, i) { this.name = e, this.value = t, this.sourceSpan = s, this.keySpan = r, this.valueSpan = i; }
    visit(e) { return e.visitVariable(this); }
}, qr = class {
    name;
    value;
    sourceSpan;
    keySpan;
    valueSpan;
    constructor(e, t, s, r, i) { this.name = e, this.value = t, this.sourceSpan = s, this.keySpan = r, this.valueSpan = i; }
    visit(e) { return e.visitReference(this); }
}, Fp = class {
    vars;
    placeholders;
    sourceSpan;
    i18n;
    constructor(e, t, s, r) { this.vars = e, this.placeholders = t, this.sourceSpan = s, this.i18n = r; }
    visit(e) { return e.visitIcu(this); }
}, Hr = class {
    tagNames;
    bindings;
    listeners;
    sourceSpan;
    constructor(e, t, s, r) { if (this.tagNames = e, this.bindings = t, this.listeners = s, this.sourceSpan = r, e.length === 0)
        throw new Error("HostElement must have at least one tag name."); }
    visit() { throw new Error("HostElement cannot be visited"); }
};
function oa(n, e) { let t = []; if (n.visit)
    for (let s of e)
        n.visit(s);
else
    for (let s of e) {
        let r = s.visit(n);
        r && t.push(r);
    } return t; }
var Me = class {
    nodes;
    placeholders;
    placeholderToMessage;
    meaning;
    description;
    customId;
    sources;
    id;
    legacyIds = [];
    messageString;
    constructor(e, t, s, r, i, o) { this.nodes = e, this.placeholders = t, this.placeholderToMessage = s, this.meaning = r, this.description = i, this.customId = o, this.id = this.customId, this.messageString = xd(this.nodes), e.length ? this.sources = [{ filePath: e[0].sourceSpan.start.file.url, startLine: e[0].sourceSpan.start.line + 1, startCol: e[0].sourceSpan.start.col + 1, endLine: e[e.length - 1].sourceSpan.end.line + 1, endCol: e[0].sourceSpan.start.col + 1 }] : this.sources = []; }
}, Hs = class {
    value;
    sourceSpan;
    constructor(e, t) { this.value = e, this.sourceSpan = t; }
    visit(e, t) { return e.visitText(this, t); }
}, qt = class {
    children;
    sourceSpan;
    constructor(e, t) { this.children = e, this.sourceSpan = t; }
    visit(e, t) { return e.visitContainer(this, t); }
}, wo = class {
    expression;
    type;
    cases;
    sourceSpan;
    expressionPlaceholder;
    constructor(e, t, s, r, i) { this.expression = e, this.type = t, this.cases = s, this.sourceSpan = r, this.expressionPlaceholder = i; }
    visit(e, t) { return e.visitIcu(this, t); }
}, cn = class {
    tag;
    attrs;
    startName;
    closeName;
    children;
    isVoid;
    sourceSpan;
    startSourceSpan;
    endSourceSpan;
    constructor(e, t, s, r, i, o, a, c, l) { this.tag = e, this.attrs = t, this.startName = s, this.closeName = r, this.children = i, this.isVoid = o, this.sourceSpan = a, this.startSourceSpan = c, this.endSourceSpan = l; }
    visit(e, t) { return e.visitTagPlaceholder(this, t); }
}, Ur = class {
    value;
    name;
    sourceSpan;
    constructor(e, t, s) { this.value = e, this.name = t, this.sourceSpan = s; }
    visit(e, t) { return e.visitPlaceholder(this, t); }
}, Ds = class {
    value;
    name;
    sourceSpan;
    previousMessage;
    constructor(e, t, s) { this.value = e, this.name = t, this.sourceSpan = s; }
    visit(e, t) { return e.visitIcuPlaceholder(this, t); }
}, ln = class {
    name;
    parameters;
    startName;
    closeName;
    children;
    sourceSpan;
    startSourceSpan;
    endSourceSpan;
    constructor(e, t, s, r, i, o, a, c) { this.name = e, this.parameters = t, this.startName = s, this.closeName = r, this.children = i, this.sourceSpan = o, this.startSourceSpan = a, this.endSourceSpan = c; }
    visit(e, t) { return e.visitBlockPlaceholder(this, t); }
};
function xd(n) { let e = new Xa; return n.map(s => s.visit(e)).join(""); }
var Xa = class {
    visitText(e) { return e.value; }
    visitContainer(e) { return e.children.map(t => t.visit(this)).join(""); }
    visitIcu(e) { let t = Object.keys(e.cases).map(s => `${s} {${e.cases[s].visit(this)}}`); return `{${e.expressionPlaceholder}, ${e.type}, ${t.join(" ")}}`; }
    visitTagPlaceholder(e) { let t = e.children.map(s => s.visit(this)).join(""); return `{$${e.startName}}${t}{$${e.closeName}}`; }
    visitPlaceholder(e) { return `{$${e.name}}`; }
    visitIcuPlaceholder(e) { return `{$${e.name}}`; }
    visitBlockPlaceholder(e) { let t = e.children.map(s => s.visit(this)).join(""); return `{$${e.startName}}${t}{$${e.closeName}}`; }
};
var yd = class {
    visitTag(e) { let t = this._serializeAttributes(e.attrs); if (e.children.length == 0)
        return `<${e.name}${t}/>`; let s = e.children.map(r => r.visit(this)); return `<${e.name}${t}>${s.join("")}</${e.name}>`; }
    visitText(e) { return e.value; }
    visitDeclaration(e) { return `<?xml${this._serializeAttributes(e.attrs)} ?>`; }
    _serializeAttributes(e) { let t = Object.keys(e).map(s => `${s}="${e[s]}"`).join(" "); return t.length > 0 ? " " + t : ""; }
    visitDoctype(e) {
        return `<!DOCTYPE ${e.rootTag} [
${e.dtd}
]>`;
    }
}, U2 = new yd;
function Cd(n) { return n.toUpperCase().replace(/[^A-Z0-9_]/g, "_"); }
var Op = "i18n", Qa = "i18n-", bd = "VAR_";
function Vp(n) { return n === Op || n.startsWith(Qa); }
function Ad(n) { return n.attrs.some(e => Vp(e.name)); }
function qp(n) { return n.nodes[0]; }
function pl(n = {}, e) { let t = {}; return n && Object.keys(n).length && Object.keys(n).forEach(s => t[gi(s, e)] = n[s]), t; }
function gi(n, e = !0) { let t = Cd(n); if (!e)
    return t; let s = t.split("_"); if (s.length === 1)
    return n.toLowerCase(); let r; /^\d+$/.test(s[s.length - 1]) && (r = s.pop()); let i = s.shift().toLowerCase(); return s.length && (i += s.map(o => o.charAt(0).toUpperCase() + o.slice(1).toLowerCase()).join("")), r ? `${i}_${r}` : i; }
var hl = "_t", st = "ctx", Ms = "rf";
function Hp(n, e) { let t = null; return () => (t || (n(new ve(hl, void 0, ge)), t = F(e)), t); }
function ps(n) { return Array.isArray(n) ? X(n.map(ps)) : g(n, It); }
function Ql(n, e) { let t = Object.getOwnPropertyNames(n); return t.length === 0 ? null : nt(t.map(s => { let r = n[s], i, o, a, c; if (typeof r == "string")
    i = s, a = s, o = r, c = ps(o);
else {
    a = s, i = r.classPropertyName, o = r.bindingPropertyName;
    let l = o !== i, p = r.transformFunction !== null, h = Zs.None;
    if (r.isSignal && (h |= Zs.SignalBased), p && (h |= Zs.HasDecoratorInputTransform), e && (l || p || h !== Zs.None)) {
        let d = [g(h), ps(o)];
        (l || p) && (d.push(ps(i)), p && d.push(r.transformFunction)), c = X(d);
    }
    else
        c = ps(o);
} return { key: a, quoted: Mp(a), value: c }; })); }
var jt = class {
    values = [];
    set(e, t) { if (t) {
        let s = this.values.find(r => r.key === e);
        s ? s.value = t : this.values.push({ key: e, value: t, quoted: !1 });
    } }
    toLiteralMap() { return nt(this.values); }
};
function kd(n) { let e = n instanceof wt ? n.name : "ng-template", t = Td(n), s = new hr, r = be(e)[1]; return s.setElement(r), Object.getOwnPropertyNames(t).forEach(i => { let o = be(i)[1], a = t[i]; s.addAttribute(o, a), i.toLowerCase() === "class" && a.trim().split(/\s+/).forEach(l => s.addClassName(l)); }), s; }
function Td(n) { let e = {}; return n instanceof et && n.tagName !== "ng-template" ? n.templateAttrs.forEach(t => e[t.name] = "") : (n.attributes.forEach(t => { Vp(t.name) || (e[t.name] = t.value); }), n.inputs.forEach(t => { (t.type === U.Property || t.type === U.TwoWay) && (e[t.name] = ""); }), n.outputs.forEach(t => { e[t.name] = ""; })), e; }
function Yl(n, e) { let t = null, s = { name: n.name, type: n.type, typeArgumentCount: n.typeArgumentCount, deps: [], target: Rt.Injectable }; if (n.useClass !== void 0) {
    let a = n.useClass.expression.isEquivalent(n.type.value), c;
    n.deps !== void 0 && (c = n.deps), c !== void 0 ? t = xn(se(E({}, s), { delegate: n.useClass.expression, delegateDeps: c, delegateType: to.Class })) : a ? t = xn(s) : t = { statements: [], expression: Ya(n.type.value, n.useClass.expression, e) };
}
else
    n.useFactory !== void 0 ? n.deps !== void 0 ? t = xn(se(E({}, s), { delegate: n.useFactory, delegateDeps: n.deps || [], delegateType: to.Function })) : t = { statements: [], expression: je([], n.useFactory.callFn([])) } : n.useValue !== void 0 ? t = xn(se(E({}, s), { expression: n.useValue.expression })) : n.useExisting !== void 0 ? t = xn(se(E({}, s), { expression: A(f.inject).callFn([n.useExisting.expression]) })) : t = { statements: [], expression: Ya(n.type.value, n.type.value, e) }; let r = n.type.value, i = new jt; return i.set("token", r), i.set("factory", t.expression), n.providedIn.expression.value !== null && i.set("providedIn", hd(n.providedIn)), { expression: A(f.\u0275\u0275defineInjectable).callFn([i.toLiteralMap()], void 0, !0), type: Up(n.type.type, n.typeArgumentCount), statements: t.statements }; }
function Up(n, e) { return new He(A(f.InjectableDeclaration, [Yo(n, e)])); }
function Ya(n, e, t) { if (n.node === e.node)
    return e.prop("\u0275fac"); if (!t)
    return Zl(e); let s = A(f.resolveForwardRef).callFn([e]); return Zl(s); }
function Zl(n) { let e = new he("__ngFactoryType__", ge); return je([e], n.prop("\u0275fac").callFn([F(e.name)])); }
var Wp = !1, le = 0, _d = 8, fl = 9, Nn = 10, jp = 11, zp = 12, dl = 13, Gp = 32, Za = 33, Wr = 34, Xp = 35, Zo = 36, Id = 37, So = 38, jr = 39, Be = 40, ue = 41, Ja = 42, Qp = 43, _e = 44, Eo = 45, En = 46, Xe = 47, bt = 58, qe = 59, ws = 60, Se = 61, De = 62, hs = 63, ml = 48, Nd = 55, Yp = 57, gn = 65, Dd = 69, Pd = 70, Ld = 88, Rs = 90, Tt = 91, Dn = 92, Ft = 93, Bd = 94, vn = 95, Gn = 97, $d = 98, Md = 101, gl = 102, Zp = 110, Jp = 114, Kp = 116, eh = 117, th = 118, nh = 120, vi = 122, pt = 123, Jl = 124, Le = 125, sh = 160, ts = 64, Ka = 96;
function zr(n) { return n >= fl && n <= Gp || n == sh; }
function lt(n) { return ml <= n && n <= Yp; }
function un(n) { return n >= Gn && n <= vi || n >= gn && n <= Rs; }
function Rd(n) { return n >= Gn && n <= gl || n >= gn && n <= Pd || lt(n); }
function rr(n) { return n === Nn || n === dl; }
function Kl(n) { return ml <= n && n <= Nd; }
function ir(n) { return n === jr || n === Wr || n === Ka; }
var Gr = class n {
    file;
    offset;
    line;
    col;
    constructor(e, t, s, r) { this.file = e, this.offset = t, this.line = s, this.col = r; }
    toString() { return this.offset != null ? `${this.file.url}@${this.line}:${this.col}` : this.file.url; }
    moveBy(e) { let t = this.file.content, s = t.length, r = this.offset, i = this.line, o = this.col; for (; r > 0 && e < 0;)
        if (r--, e++, t.charCodeAt(r) == Nn) {
            i--;
            let c = t.substring(0, r - 1).lastIndexOf(String.fromCharCode(Nn));
            o = c > 0 ? r - c : r;
        }
        else
            o--; for (; r < s && e > 0;) {
        let a = t.charCodeAt(r);
        r++, e--, a == Nn ? (i++, o = 0) : o++;
    } return new n(this.file, r, i, o); }
    getContext(e, t) {
        let s = this.file.content, r = this.offset;
        if (r != null) {
            r > s.length - 1 && (r = s.length - 1);
            let i = r, o = 0, a = 0;
            for (; o < e && r > 0 && (r--, o++, !(s[r] == `
` && ++a == t));)
                ;
            for (o = 0, a = 0; o < e && i < s.length - 1 && (i++, o++, !(s[i] == `
` && ++a == t));)
                ;
            return { before: s.substring(r, this.offset), after: s.substring(this.offset, i + 1) };
        }
        return null;
    }
}, xo = class {
    content;
    url;
    constructor(e, t) { this.content = e, this.url = t; }
}, D = class {
    start;
    end;
    fullStart;
    details;
    constructor(e, t, s = e, r = null) { this.start = e, this.end = t, this.fullStart = s, this.details = r; }
    toString() { return this.start.file.content.substring(this.start.offset, this.end.offset); }
}, sn = (function (n) { return n[n.WARNING = 0] = "WARNING", n[n.ERROR = 1] = "ERROR", n; })(sn || {}), N = class extends Error {
    span;
    msg;
    level;
    relatedError;
    constructor(e, t, s = sn.ERROR, r) { super(t), this.span = e, this.msg = t, this.level = s, this.relatedError = r, Object.setPrototypeOf(this, new.target.prototype); }
    contextualMessage() { let e = this.span.start.getContext(100, 3); return e ? `${this.msg} ("${e.before}[${sn[this.level]} ->]${e.after}")` : this.msg; }
    toString() { let e = this.span.details ? `, ${this.span.details}` : ""; return `${this.contextualMessage()}: ${this.span.start}${e}`; }
};
function Fd(n, e, t) { let s = `in ${n} ${e} in ${t}`, r = new xo("", s); return new D(new Gr(r, -1, -1, -1), new Gr(r, -1, -1, -1)); }
var Od = 0;
function Vd(n) { if (!n || !n.reference)
    return null; let e = n.reference; if (e.__anonymousType)
    return e.__anonymousType; if (e.__forward_ref__)
    return "__forward_ref__"; let t = Lp(e); return t.indexOf("(") >= 0 ? (t = `anonymous_${Od++}`, e.__anonymousType = t) : t = yn(t), t; }
function yn(n) { return n.replace(/\W/g, "_"); }
var eu = '(this&&this.__makeTemplateObject||function(e,t){return Object.defineProperty?Object.defineProperty(e,"raw",{value:t}):e.raw=t,e})', ec = class extends Ba {
    constructor() { super(!1, !1); }
    visitWrappedNodeExpr(e, t) { throw new Error("Cannot emit a WrappedNodeExpr in Javascript."); }
    visitDeclareVarStmt(e, t) { t.print(e, `var ${e.name}`), e.value && (t.print(e, " = "), e.value.visitExpression(this, t)), t.println(e, ";"); }
    visitTaggedTemplateLiteralExpr(e, t) { let s = e.template.elements; e.tag.visitExpression(this, t), t.print(e, `(${eu}(`), t.print(e, `[${s.map(r => nn(r.text)).join(", ")}], `), t.print(e, `[${s.map(r => nn(r.rawText)).join(", ")}])`), e.template.expressions.forEach(r => { t.print(e, ", "), r.visitExpression(this, t); }), t.print(e, ")"); }
    visitTemplateLiteralExpr(e, t) { t.print(e, "`"); for (let s = 0; s < e.elements.length; s++) {
        e.elements[s].visitExpression(this, t);
        let r = s < e.expressions.length ? e.expressions[s] : null;
        r !== null && (t.print(r, "${"), r.visitExpression(this, t), t.print(r, "}"));
    } t.print(e, "`"); }
    visitTemplateLiteralElementExpr(e, t) { t.print(e, e.rawText); }
    visitLocalizedString(e, t) { t.print(e, `$localize(${eu}(`); let s = [e.serializeI18nHead()]; for (let r = 1; r < e.messageParts.length; r++)
        s.push(e.serializeI18nTemplatePart(r)); t.print(e, `[${s.map(r => nn(r.cooked)).join(", ")}], `), t.print(e, `[${s.map(r => nn(r.raw)).join(", ")}])`), e.expressions.forEach(r => { t.print(e, ", "), r.visitExpression(this, t); }), t.print(e, ")"); }
}, xi;
function qd() { if (xi === void 0) {
    let n = nr.trustedTypes;
    if (xi = null, n)
        try {
            xi = n.createPolicy("angular#unsafe-jit", { createScript: e => e });
        }
        catch { }
} return xi; }
function Hd(n) { return qd()?.createScript(n) || n; }
function tu(...n) {
    if (!nr.trustedTypes)
        return new Function(...n);
    let e = n.slice(0, -1).join(","), t = n[n.length - 1], s = `(function anonymous(${e}
) { ${t}
})`, r = nr.eval(Hd(s));
    return r.bind === void 0 ? new Function(...n) : (r.toString = () => s, r.bind(nr));
}
var tc = class {
    evaluateStatements(e, t, s, r) { let i = new nc(s), o = La.createRoot(); return t.length > 0 && !Ud(t[0]) && (t = [g("use strict").toStmt(), ...t]), i.visitAllStatements(t, o), i.createReturnStmt(o), this.evaluateCode(e, o, i.getArgs(), r); }
    evaluateCode(e, t, s, r) {
        let i = `"use strict";${t.toSource()}
//# sourceURL=${e}`, o = [], a = [];
        for (let l in s)
            a.push(s[l]), o.push(l);
        if (r) {
            let l = tu(...o.concat("return null;")).toString(), p = l.slice(0, l.indexOf("return null;")).split(`
`).length - 1;
            i += `
${t.toSourceMapGenerator(e, p).toJsComment()}`;
        }
        let c = tu(...o.concat(i));
        return this.executeFunction(c, a);
    }
    executeFunction(e, t) { return e(...t); }
}, nc = class extends ec {
    refResolver;
    _evalArgNames = [];
    _evalArgValues = [];
    _evalExportedVars = [];
    constructor(e) { super(), this.refResolver = e; }
    createReturnStmt(e) { new fe(new vt(this._evalExportedVars.map(s => new ys(s, F(s), !1)))).visitStatement(this, e); }
    getArgs() { let e = {}; for (let t = 0; t < this._evalArgNames.length; t++)
        e[this._evalArgNames[t]] = this._evalArgValues[t]; return e; }
    visitExternalExpr(e, t) { return this._emitReferenceToExternal(e, this.refResolver.resolveExternalReference(e.value), t), null; }
    visitWrappedNodeExpr(e, t) { return this._emitReferenceToExternal(e, e.node, t), null; }
    visitDeclareVarStmt(e, t) { return e.hasModifier(xe.Exported) && this._evalExportedVars.push(e.name), super.visitDeclareVarStmt(e, t); }
    visitDeclareFunctionStmt(e, t) { return e.hasModifier(xe.Exported) && this._evalExportedVars.push(e.name), super.visitDeclareFunctionStmt(e, t); }
    _emitReferenceToExternal(e, t, s) { let r = this._evalArgValues.indexOf(t); if (r === -1) {
        r = this._evalArgValues.length, this._evalArgValues.push(t);
        let i = Vd({ reference: t }) || "val";
        this._evalArgNames.push(`jit_${i}_${r}`);
    } s.print(e, this._evalArgNames[r]); }
};
function Ud(n) { return n.isEquivalent(g("use strict").toStmt()); }
function nu(n) { let e = new jt; n.providers !== null && e.set("providers", n.providers), n.imports.length > 0 && e.set("imports", X(n.imports)); let t = A(f.defineInjector).callFn([e.toLiteralMap()], void 0, !0), s = Wd(n); return { expression: t, type: s, statements: [] }; }
function Wd(n) { return new He(A(f.InjectorDeclaration, [new He(n.type.type)])); }
var sc = class {
    context;
    constructor(e) { this.context = e; }
    resolveExternalReference(e) { if (e.moduleName !== "@angular/core")
        throw new Error(`Cannot resolve external reference to ${e.moduleName}, only references to @angular/core are supported.`); if (!Object.hasOwn(this.context, e.name))
        throw new Error(`No value provided for @angular/core symbol '${e.name}'.`); return this.context[e.name]; }
}, yo = (function (n) { return n[n.Inline = 0] = "Inline", n[n.SideEffect = 1] = "SideEffect", n[n.Omit = 2] = "Omit", n; })(yo || {}), at = (function (n) { return n[n.Global = 0] = "Global", n[n.Local = 1] = "Local", n[n.Isolated = 2] = "Isolated", n; })(at || {});
function jd(n) { let e = [], t = new jt; if (t.set("type", n.type.value), n.kind === at.Global && n.bootstrap.length > 0 && t.set("bootstrap", bn(n.bootstrap, n.containsForwardDecls)), n.selectorScopeMode === yo.Inline)
    n.declarations.length > 0 && t.set("declarations", bn(n.declarations, n.containsForwardDecls)), n.imports.length > 0 && t.set("imports", bn(n.imports, n.containsForwardDecls)), n.exports.length > 0 && t.set("exports", bn(n.exports, n.containsForwardDecls));
else if (n.selectorScopeMode === yo.SideEffect) {
    let i = Xd(n);
    i !== null && e.push(i);
} n.schemas !== null && n.schemas.length > 0 && t.set("schemas", X(n.schemas.map(i => i.value))), n.id !== null && (t.set("id", n.id), e.push(A(f.registerNgModuleType).callFn([n.type.value, n.id]).toStmt())); let s = A(f.defineNgModule).callFn([t.toLiteralMap()], void 0, !0), r = Gd(n); return { expression: s, type: r, statements: e }; }
function zd(n) { let e = new jt; return e.set("type", new q(n.type)), n.bootstrap !== void 0 && e.set("bootstrap", new q(n.bootstrap)), n.declarations !== void 0 && e.set("declarations", new q(n.declarations)), n.imports !== void 0 && e.set("imports", new q(n.imports)), n.exports !== void 0 && e.set("exports", new q(n.exports)), n.schemas !== void 0 && e.set("schemas", new q(n.schemas)), n.id !== void 0 && e.set("id", new q(n.id)), A(f.defineNgModule).callFn([e.toLiteralMap()]); }
function Gd(n) { if (n.kind === at.Local)
    return new He(n.type.value); if (n.kind === at.Isolated)
    return new He(A(f.NgModuleDeclaration, [new He(n.type.type), Je, n.importsExpression ? we(n.importsExpression) : Je, n.exportsExpression ? we(n.exportsExpression) : Je])); let { type: e, declarations: t, exports: s, imports: r, includeImportTypes: i, publicDeclarationTypes: o } = n; return new He(A(f.NgModuleDeclaration, [new He(e.type), o === null ? aa(t) : Qd(o), i ? aa(r) : Je, aa(s)])); }
function Xd(n) { let e = new jt; if (n.kind === at.Global ? n.declarations.length > 0 && e.set("declarations", bn(n.declarations, n.containsForwardDecls)) : n.kind === at.Local && n.declarationsExpression && e.set("declarations", n.declarationsExpression), n.kind === at.Global ? n.imports.length > 0 && e.set("imports", bn(n.imports, n.containsForwardDecls)) : n.kind === at.Local && n.importsExpression && e.set("imports", n.importsExpression), n.kind === at.Global ? n.exports.length > 0 && e.set("exports", bn(n.exports, n.containsForwardDecls)) : n.kind === at.Local && n.exportsExpression && e.set("exports", n.exportsExpression), n.kind === at.Local && n.bootstrapExpression && e.set("bootstrap", n.bootstrapExpression), Object.keys(e.values).length === 0)
    return null; let t = new pe(A(f.setNgModuleScope), [n.type.value, e.toLiteralMap()]), s = ud(t), r = new Vt([], [s.toStmt()]); return new pe(r, []).toStmt(); }
function aa(n) { let e = n.map(t => di(t.type)); return n.length > 0 ? we(X(e)) : Je; }
function Qd(n) { let e = n.map(t => di(t)); return n.length > 0 ? we(X(e)) : Je; }
function su(n) { let e = []; e.push({ key: "name", value: g(n.pipeName ?? n.name), quoted: !1 }), e.push({ key: "type", value: n.type.value, quoted: !1 }), e.push({ key: "pure", value: g(n.pure), quoted: !1 }), n.isStandalone === !1 && e.push({ key: "standalone", value: g(!1), quoted: !1 }); let t = A(f.definePipe).callFn([nt(e)], void 0, !0), s = Yd(n); return { expression: t, type: s, statements: [] }; }
function Yd(n) { return new He(A(f.PipeDeclaration, [Yo(n.type.type, n.typeArgumentCount), new He(new Ae(n.pipeName)), new He(new Ae(n.isStandalone))])); }
var Xn = (function (n) { return n[n.Directive = 0] = "Directive", n[n.Pipe = 1] = "Pipe", n[n.NgModule = 2] = "NgModule", n; })(Xn || {}), Zd = new Set(["inherit", "initial", "revert", "unset", "alternate", "alternate-reverse", "normal", "reverse", "backwards", "both", "forwards", "none", "paused", "running", "ease", "ease-in", "ease-in-out", "ease-out", "linear", "step-start", "step-end", "end", "jump-both", "jump-end", "jump-none", "jump-start", "start"]), Jd = ["@media", "@supports", "@document", "@layer", "@container", "@scope", "@starting-style"], rc = class {
    shimCssText(e, t, s = "") { let r = []; e = e.replace(pm, a => { if (a.match(hm))
        r.push(a);
    else {
        let c = a.match(um);
        r.push(c?.join("") ?? "");
    } return wl; }); let i = this._scopeCssText(e, t, s), o = 0; return i.replace(fm, () => r[o++]); }
    _scopeKeyframesRelatedCss(e, t) { let s = new Set, r = yi(e, i => this._scopeLocalKeyframeDeclarations(i, t, s)); return yi(r, i => this._scopeAnimationRule(i, t, s)); }
    _scopeLocalKeyframeDeclarations(e, t, s) { return se(E({}, e), { selector: e.selector.replace(/(^@(?:-webkit-)?keyframes(?:\s+))(['"]?)(.+)\2(\s*)$/, (r, i, o, a, c) => (s.add(iu(a, o)), `${i}${o}${t}_${a}${o}${c}`)) }); }
    _scopeAnimationKeyframe(e, t, s) { return e.replace(/^(\s*)(['"]?)(.+?)\2(\s*)$/, (r, i, o, a, c) => (a = `${s.has(iu(a, o)) ? t + "_" : ""}${a}`, `${i}${o}${a}${o}${c}`)); }
    _animationDeclarationKeyframesRe = /(^|\s+|,)(?:(?:(['"])((?:\\\\|\\\2|(?!\2).)+)\2)|(-?[A-Za-z][\w\-]*))(?=[,\s]|$)/g;
    _scopeAnimationRule(e, t, s) { let r = e.content.replace(/((?:^|[\s;{])(?:-webkit-)?animation\s*:\s*)([^;}]+)/g, (i, o, a) => o + a.replace(this._animationDeclarationKeyframesRe, (c, l, p = "", h, d) => h ? `${l}${this._scopeAnimationKeyframe(`${p}${h}${p}`, t, s)}` : Zd.has(d) ? c : `${l}${this._scopeAnimationKeyframe(d, t, s)}`)); return r = r.replace(/((?:^|[\s;{])(?:-webkit-)?animation-name(?:\s*):(?:\s*))([^;}]+)/g, (i, o, a) => `${o}${a.split(",").map(c => this._scopeAnimationKeyframe(c, t, s)).join(",")}`), se(E({}, e), { content: r }); }
    _scopeCssText(e, t, s) { return e = this._insertPolyfillHostInCssText(e), e = this._convertColonHost(e), e = this._convertColonHostContext(e), t && (e = this._scopeKeyframesRelatedCss(e, t), e = this._scopeSelectors(e, t, s)), e.trim(); }
    _convertColonHost(e) { return e.replace(sm, (t, s, r) => { if (s) {
        let i = [...this._splitOnTopLevelCommas(s, !0)];
        if (i.length > 1)
            return ":host(" + s + ")" + r;
        let o = i[0].trim();
        if (o)
            return Jt + o.replace(Co, "") + r;
    } return Jt + r; }); }
    *_splitOnTopLevelCommas(e, t) { let s = e.length, r = 0, i = 0; for (let o = 0; o < s; o++) {
        let a = e.charCodeAt(o);
        if (a === Be)
            r++;
        else if (a === ue) {
            if (r--, r < 0 && t) {
                yield e.slice(i, o);
                return;
            }
        }
        else
            a === _e && r === 0 && (yield e.slice(i, o), i = o + 1);
    } yield e.slice(i); }
    _convertColonHostContext(e) { let t = []; for (let s of this._splitOnTopLevelCommas(e, !1))
        t.push(this._convertColonHostContextInSelectorPart(s)); return t.join(","); }
    _convertColonHostContextInSelectorPart(e) { return e.replace(im, (t, s) => { let r = [[]], i = t.indexOf(as); for (; i !== -1;) {
        let o = t.substring(i + as.length);
        if (!o || o[0] !== "(") {
            t = o, i = t.indexOf(as);
            continue;
        }
        let a = [], c = 0;
        for (let p of this._splitOnTopLevelCommas(o.substring(1), !0)) {
            c = c + p.length + 1;
            let h = p.trim();
            h && a.push(h);
        }
        let l = r.length;
        km(r, a.length);
        for (let p = 0; p < a.length; p++)
            for (let h = 0; h < l; h++)
                r[h + p * l].push(a[p]);
        t = o.substring(c + 1), i = t.indexOf(as);
    } return r.map(o => Am(o, t, s)).join(", "); }); }
    _scopeSelectors(e, t, s) { return yi(e, r => { let i = r.selector, o = r.content; return r.selector[0] !== "@" ? i = this._scopeSelector({ selector: i, scopeSelector: t, hostSelector: s, isParentSelector: !0 }) : Jd.some(a => r.selector.startsWith(a)) ? o = this._scopeSelectors(r.content, t, s) : (r.selector.startsWith("@font-face") || r.selector.startsWith("@page")) && (o = this._stripScopingSelectors(r.content)), new Xr(i, o); }); }
    _stripScopingSelectors(e) { return yi(e, t => { let s = t.selector.replace(ru, " ").replace(ca, " "); return new Xr(s, t.content); }); }
    _safeSelector;
    _shouldScopeIndicator;
    _scopeSelector({ selector: e, scopeSelector: t, hostSelector: s, isParentSelector: r = !1 }) { let i = / ?,(?!(?:[^)(]*(?:\([^)(]*(?:\([^)(]*(?:\([^)(]*\)[^)(]*)*\)[^)(]*)*\)[^)(]*)*\))) ?/; return e.split(i).map(o => o.split(ru)).map(o => { let [a, ...c] = o; return [(p => this._selectorNeedsScoping(p, t) ? this._applySelectorScope({ selector: p, scopeSelector: t, hostSelector: s, isParentSelector: r }) : p)(a), ...c].join(" "); }).join(", "); }
    _selectorNeedsScoping(e, t) { return !this._makeScopeMatcher(t).test(e); }
    _makeScopeMatcher(e) { let t = /\[/g, s = /\]/g; return e = e.replace(t, "\\[").replace(s, "\\]"), new RegExp("^(" + e + ")" + am, "m"); }
    _applySimpleSelectorScope(e, t, s) { if (fs.lastIndex = 0, fs.test(e)) {
        let r = `[${s}]`, i = e;
        for (; i.match(ca);)
            i = i.replace(ca, (o, a) => a.replace(/([^:\)]*)(:*)(.*)/, (c, l, p, h) => l + r + p + h));
        return i.replace(fs, r);
    } return t + " " + e; }
    _applySelectorScope({ selector: e, scopeSelector: t, hostSelector: s, isParentSelector: r }) { let i = /\[is=([^\]]*)\]/g; t = t.replace(i, (y, ...b) => b[0]); let o = `[${t}]`, a = y => { let b = y.trim(); if (!b)
        return y; if (y.includes(Jt)) {
        if (b = this._applySimpleSelectorScope(y, t, s), !y.match(om)) {
            let [T, $, W, J] = b.match(/([^:]*)(:*)([\s\S]*)/);
            b = $ + o + W + J;
        }
    }
    else {
        let T = y.replace(fs, "");
        if (T.length > 0) {
            let $ = T.match(/([^:]*)(:*)([\s\S]*)/);
            $ && (b = $[1] + o + $[2] + $[3]);
        }
    } return b; }, c = y => { let b = "", T = [], $; for (; ($ = Us.exec(y)) !== null;) {
        let W = 1, J = Us.lastIndex;
        for (; J < y.length;) {
            let Mt = y[J];
            if (J++, Mt === "(") {
                W++;
                continue;
            }
            if (Mt === ")") {
                if (W--, W === 0)
                    break;
                continue;
            }
        }
        T.push(`${$[0]}${y.slice(Us.lastIndex, J)}`), Us.lastIndex = J;
    } return T.join("") === y ? b = T.map(W => { let [J] = W.match(Us) ?? [], Mt = W.slice(J?.length, -1); Mt.includes(Jt) && (this._shouldScopeIndicator = !0); let ee = this._scopeSelector({ selector: Mt, scopeSelector: t, hostSelector: s }); return `${J}${ee})`; }).join("") : (this._shouldScopeIndicator = this._shouldScopeIndicator || y.includes(Jt), b = this._shouldScopeIndicator ? a(y) : y), b; }; r && (this._safeSelector = new ic(e), e = this._safeSelector.content()); let l = "", p = 0, h, d = /( |>|\+|~(?!=))(?!([^)(]*(?:\([^)(]*(?:\([^)(]*(?:\([^)(]*\)[^)(]*)*\)[^)(]*)*\)[^)(]*)*\)))\s*/g, v = e.includes(Jt); for ((r || this._shouldScopeIndicator) && (this._shouldScopeIndicator = !v); (h = d.exec(e)) !== null;) {
        let y = h[1], b = e.slice(p, h.index);
        if (b.match(/__esc-ph-(\d+)__/) && e[h.index + 1]?.match(/[a-fA-F\d]/))
            continue;
        let T = c(b);
        l += `${T} ${y} `, p = d.lastIndex;
    } let w = e.substring(p); return l += c(w), this._safeSelector.restore(l); }
    _insertPolyfillHostInCssText(e) { return e.replace(lm, as).replace(cm, Co); }
}, ic = class {
    placeholders = [];
    index = 0;
    _content;
    constructor(e) { e = this._escapeRegexMatches(e, /(\[[^\]]*\])/g), e = e.replace(/(\\.)/g, (t, s) => { let r = `__esc-ph-${this.index}__`; return this.placeholders.push(s), this.index++, r; }), this._content = e.replace(nm, (t, s, r) => { let i = `__ph-${this.index}__`; return this.placeholders.push(`(${r})`), this.index++, s + i; }); }
    restore(e) { return e.replace(/__(?:ph|esc-ph)-(\d+)__/g, (t, s) => this.placeholders[+s]); }
    content() { return this._content; }
    _escapeRegexMatches(e, t) { return e.replace(t, (s, r) => { let i = `__ph-${this.index}__`; return this.placeholders.push(r), this.index++, i; }); }
}, Kd = "(:(where|is)\\()?", Us = /:(where|is)\(/gi, Co = "-shadowcsshost", as = "-shadowcsscontext", oc = "[^)(]*", em = String.raw `(?:\(${oc}\)|${oc})+?`, tm = String.raw `(?:\(${em}\)|${oc})+?`, vl = String.raw `(?:\((${tm})\))`, nm = new RegExp(String.raw `(:nth-[-\w]+)` + vl, "g"), sm = new RegExp(Co + vl + "?([^,{]*)", "gim"), rm = as + vl + "([^{]*)", im = new RegExp(`${Kd}(${rm})`, "gim"), Jt = Co + "-no-combinator", om = new RegExp(`${Jt}(?![^(]*\\))`, "g"), ca = /-shadowcsshost-no-combinator([^\s,]*)/, ru = /(?:>>>)|(?:\/deep\/)|(?:::ng-deep)/g, am = "([>\\s~+[.,{:][\\s\\S]*)?$", fs = /-shadowcsshost/gim, cm = /:host(?!\-context)/gim, lm = /:host-context(?=\(\s*[^)\s])/gim, um = /\r?\n/g, pm = /\/\*[\s\S]*?\*\//g, hm = /\/\*\s*#\s*source(Mapping)?URL=/g, wl = "%COMMENT%", fm = new RegExp(wl, "g"), la = "%BLOCK%", dm = new RegExp(`(\\s*(?:${wl}\\s*)*)([^;\\{\\}]+?)(\\s*)((?:{%BLOCK%}?\\s*;?)|(?:\\s*;))`, "g"), mm = new Map([["{", "}"]]), rh = "%COMMA_IN_PLACEHOLDER%", ih = "%SEMI_IN_PLACEHOLDER%", oh = "%COLON_IN_PLACEHOLDER%", gm = new RegExp(rh, "g"), vm = new RegExp(ih, "g"), wm = new RegExp(oh, "g"), Sm = /(var\(\s*)?(--(?:[a-zA-Z0-9_-]|[^\x00-\x7F])+)(\s*:)?/g;
function Em(n) { return n.replace(Sm, (e, t, s, r) => !t && !r ? e : (t ?? "") + al(s) + (r ?? "")); }
var Xr = class {
    selector;
    content;
    constructor(e, t) { this.selector = e, this.content = t; }
};
function yi(n, e) { let t = Cm(n), s = xm(t, mm, la), r = 0, i = s.escapedString.replace(dm, (...o) => { let a = o[2], c = "", l = o[4], p = ""; l && l.startsWith("{" + la) && (c = s.blocks[r++], l = l.substring(la.length + 1), p = "{"); let h = e(new Xr(a, c)); return `${o[1]}${h.selector}${o[3]}${p}${h.content}${l}`; }); return bm(i); }
var ac = class {
    escapedString;
    blocks;
    constructor(e, t) { this.escapedString = e, this.blocks = t; }
};
function xm(n, e, t) { let s = [], r = [], i = 0, o = 0, a = -1, c, l; for (let p = 0; p < n.length; p++) {
    let h = n[p];
    h === "\\" ? p++ : h === l ? (i--, i === 0 && (r.push(n.substring(a, p)), s.push(t), o = p, a = -1, c = l = void 0)) : h === c ? i++ : i === 0 && e.has(h) && (c = h, l = e.get(h), i = 1, a = p + 1, s.push(n.substring(o, a)));
} return a !== -1 ? (r.push(n.substring(a)), s.push(t)) : s.push(n.substring(o)), new ac(s.join(""), r); }
var ym = { ";": ih, ",": rh, ":": oh };
function Cm(n) { let e = n, t = null; for (let s = 0; s < e.length; s++) {
    let r = e[s];
    if (r === "\\")
        s++;
    else if (t !== null)
        if (r === t)
            t = null;
        else {
            let i = ym[r];
            i && (e = `${e.substr(0, s)}${i}${e.substr(s + 1)}`, s += i.length - 1);
        }
    else
        (r === "'" || r === '"') && (t = r);
} return e; }
function bm(n) { let e = n.replace(gm, ","); return e = e.replace(vm, ";"), e = e.replace(wm, ":"), e; }
function iu(n, e) { return e ? n.replace(/((?:^|[^\\])(?:\\\\)*)\\(?=['"])/g, "$1") : n; }
function Am(n, e, t = "") { let s = Jt; fs.lastIndex = 0; let r = fs.test(e); if (n.length === 0)
    return s + e; let i = [n.pop() || ""]; for (; n.length > 0;) {
    let o = i.length, a = n.pop();
    for (let c = 0; c < o; c++) {
        let l = i[c];
        i[o * 2 + c] = l + " " + a, i[o + c] = a + " " + l, i[c] = a + l;
    }
} return i.map(o => r ? `${t}${o}${e}` : `${t}${o}${s}${e}, ${t}${o} ${s}${e}`).join(","); }
function km(n, e) { let t = n.length; for (let s = 1; s < e; s++)
    for (let r = 0; r < t; r++)
        n[r + s * t] = n[r].slice(0); }
var u = (function (n) { return n[n.ListEnd = 0] = "ListEnd", n[n.Statement = 1] = "Statement", n[n.Variable = 2] = "Variable", n[n.ElementStart = 3] = "ElementStart", n[n.Element = 4] = "Element", n[n.ForeignComponent = 5] = "ForeignComponent", n[n.Template = 6] = "Template", n[n.ElementEnd = 7] = "ElementEnd", n[n.ContainerStart = 8] = "ContainerStart", n[n.Container = 9] = "Container", n[n.ContainerEnd = 10] = "ContainerEnd", n[n.DisableBindings = 11] = "DisableBindings", n[n.ConditionalCreate = 12] = "ConditionalCreate", n[n.ConditionalBranchCreate = 13] = "ConditionalBranchCreate", n[n.Conditional = 14] = "Conditional", n[n.EnableBindings = 15] = "EnableBindings", n[n.Text = 16] = "Text", n[n.Listener = 17] = "Listener", n[n.InterpolateText = 18] = "InterpolateText", n[n.Binding = 19] = "Binding", n[n.Property = 20] = "Property", n[n.StyleProp = 21] = "StyleProp", n[n.ClassProp = 22] = "ClassProp", n[n.StyleMap = 23] = "StyleMap", n[n.ClassMap = 24] = "ClassMap", n[n.Advance = 25] = "Advance", n[n.Pipe = 26] = "Pipe", n[n.Attribute = 27] = "Attribute", n[n.ExtractedAttribute = 28] = "ExtractedAttribute", n[n.Defer = 29] = "Defer", n[n.DeferOn = 30] = "DeferOn", n[n.DeferWhen = 31] = "DeferWhen", n[n.I18nMessage = 32] = "I18nMessage", n[n.DomProperty = 33] = "DomProperty", n[n.Namespace = 34] = "Namespace", n[n.ProjectionDef = 35] = "ProjectionDef", n[n.EnableIncrementalHydrationRuntime = 36] = "EnableIncrementalHydrationRuntime", n[n.Projection = 37] = "Projection", n[n.Content = 38] = "Content", n[n.RepeaterCreate = 39] = "RepeaterCreate", n[n.Repeater = 40] = "Repeater", n[n.TwoWayProperty = 41] = "TwoWayProperty", n[n.TwoWayListener = 42] = "TwoWayListener", n[n.DeclareLet = 43] = "DeclareLet", n[n.StoreLet = 44] = "StoreLet", n[n.I18nStart = 45] = "I18nStart", n[n.I18n = 46] = "I18n", n[n.I18nEnd = 47] = "I18nEnd", n[n.I18nExpression = 48] = "I18nExpression", n[n.I18nApply = 49] = "I18nApply", n[n.IcuStart = 50] = "IcuStart", n[n.IcuEnd = 51] = "IcuEnd", n[n.IcuPlaceholder = 52] = "IcuPlaceholder", n[n.I18nContext = 53] = "I18nContext", n[n.I18nAttributes = 54] = "I18nAttributes", n[n.SourceLocation = 55] = "SourceLocation", n[n.Animation = 56] = "Animation", n[n.AnimationString = 57] = "AnimationString", n[n.AnimationBinding = 58] = "AnimationBinding", n[n.AnimationListener = 59] = "AnimationListener", n[n.Control = 60] = "Control", n[n.ControlCreate = 61] = "ControlCreate", n; })(u || {}), I = (function (n) { return n[n.LexicalRead = 0] = "LexicalRead", n[n.Context = 1] = "Context", n[n.TrackContext = 2] = "TrackContext", n[n.ReadVariable = 3] = "ReadVariable", n[n.NextContext = 4] = "NextContext", n[n.Reference = 5] = "Reference", n[n.StoreLet = 6] = "StoreLet", n[n.ContextLetReference = 7] = "ContextLetReference", n[n.GetCurrentView = 8] = "GetCurrentView", n[n.RestoreView = 9] = "RestoreView", n[n.ResetView = 10] = "ResetView", n[n.PureFunctionExpr = 11] = "PureFunctionExpr", n[n.PureFunctionParameterExpr = 12] = "PureFunctionParameterExpr", n[n.PipeBinding = 13] = "PipeBinding", n[n.PipeBindingVariadic = 14] = "PipeBindingVariadic", n[n.SafePropertyRead = 15] = "SafePropertyRead", n[n.SafeKeyedRead = 16] = "SafeKeyedRead", n[n.SafeNavigationMigration = 17] = "SafeNavigationMigration", n[n.SafeTernaryExpr = 18] = "SafeTernaryExpr", n[n.EmptyExpr = 19] = "EmptyExpr", n[n.AssignTemporaryExpr = 20] = "AssignTemporaryExpr", n[n.ReadTemporaryExpr = 21] = "ReadTemporaryExpr", n[n.SlotLiteralExpr = 22] = "SlotLiteralExpr", n[n.ConditionalCase = 23] = "ConditionalCase", n[n.ConstCollected = 24] = "ConstCollected", n[n.TwoWayBindingSet = 25] = "TwoWayBindingSet", n[n.ForeignContent = 26] = "ForeignContent", n[n.ArrowFunction = 27] = "ArrowFunction", n; })(I || {}), ht = (function (n) { return n[n.None = 0] = "None", n[n.AlwaysInline = 1] = "AlwaysInline", n; })(ht || {}), Ee = (function (n) { return n[n.Context = 0] = "Context", n[n.Identifier = 1] = "Identifier", n[n.SavedView = 2] = "SavedView", n[n.Alias = 3] = "Alias", n; })(Ee || {}), _ = (function (n) { return n[n.Attribute = 0] = "Attribute", n[n.ClassName = 1] = "ClassName", n[n.StyleProperty = 2] = "StyleProperty", n[n.Property = 3] = "Property", n[n.Template = 4] = "Template", n[n.I18n = 5] = "I18n", n[n.LegacyAnimation = 6] = "LegacyAnimation", n[n.TwoWayProperty = 7] = "TwoWayProperty", n[n.Animation = 8] = "Animation", n; })(_ || {}), Qr = (function (n) { return n[n.Creation = 0] = "Creation", n[n.Postproccessing = 1] = "Postproccessing", n; })(Qr || {}), Fs = (function (n) { return n[n.I18nText = 0] = "I18nText", n[n.I18nAttribute = 1] = "I18nAttribute", n; })(Fs || {}), Y = (function (n) { return n[n.None = 0] = "None", n[n.ElementTag = 1] = "ElementTag", n[n.TemplateTag = 2] = "TemplateTag", n[n.OpenTag = 4] = "OpenTag", n[n.CloseTag = 8] = "CloseTag", n[n.ExpressionIndex = 16] = "ExpressionIndex", n; })(Y || {}), oe = (function (n) { return n[n.HTML = 0] = "HTML", n[n.SVG = 1] = "SVG", n[n.Math = 2] = "Math", n; })(oe || {}), G = (function (n) { return n[n.Idle = 0] = "Idle", n[n.Immediate = 1] = "Immediate", n[n.Timer = 2] = "Timer", n[n.Hover = 3] = "Hover", n[n.Interaction = 4] = "Interaction", n[n.Viewport = 5] = "Viewport", n[n.Never = 6] = "Never", n; })(G || {}), Tn = (function (n) { return n[n.RootI18n = 0] = "RootI18n", n[n.Icu = 1] = "Icu", n[n.Attr = 2] = "Attr", n; })(Tn || {}), Re = (function (n) { return n[n.NgTemplate = 0] = "NgTemplate", n[n.Structural = 1] = "Structural", n[n.Block = 2] = "Block", n; })(Re || {}), S = (() => { class n {
    static nextListId = 0;
    debugListId = n.nextListId++;
    head = { kind: u.ListEnd, next: null, prev: null, debugListId: this.debugListId };
    tail = { kind: u.ListEnd, next: null, prev: null, debugListId: this.debugListId };
    constructor() { this.head.next = this.tail, this.tail.prev = this.head; }
    push(t) { if (Array.isArray(t)) {
        for (let r of t)
            this.push(r);
        return;
    } n.assertIsNotEnd(t), n.assertIsUnowned(t), t.debugListId = this.debugListId; let s = this.tail.prev; t.prev = s, s.next = t, t.next = this.tail, this.tail.prev = t; }
    prepend(t) { if (t.length === 0)
        return; for (let i of t)
        n.assertIsNotEnd(i), n.assertIsUnowned(i), i.debugListId = this.debugListId; let s = this.head.next, r = this.head; for (let i of t)
        r.next = i, i.prev = r, r = i; r.next = s, s.prev = r; }
    *[Symbol.iterator]() { let t = this.head.next; for (; t !== this.tail;) {
        n.assertIsOwned(t, this.debugListId);
        let s = t.next;
        yield t, t = s;
    } }
    *reversed() { let t = this.tail.prev; for (; t !== this.head;) {
        n.assertIsOwned(t, this.debugListId);
        let s = t.prev;
        yield t, t = s;
    } }
    static replace(t, s) { n.assertIsNotEnd(t), n.assertIsNotEnd(s), n.assertIsOwned(t), n.assertIsUnowned(s), s.debugListId = t.debugListId, t.prev !== null && (t.prev.next = s, s.prev = t.prev), t.next !== null && (t.next.prev = s, s.next = t.next), t.debugListId = null, t.prev = null, t.next = null; }
    static replaceWithMany(t, s) { if (s.length === 0) {
        n.remove(t);
        return;
    } n.assertIsNotEnd(t), n.assertIsOwned(t); let r = t.debugListId; t.debugListId = null; for (let p of s)
        n.assertIsNotEnd(p), n.assertIsUnowned(p); let { prev: i, next: o } = t; t.prev = null, t.next = null; let a = i; for (let p of s)
        n.assertIsUnowned(p), p.debugListId = r, a.next = p, p.prev = a, p.next = null, a = p; let c = s[0], l = a; i !== null && (i.next = c, c.prev = i), o !== null && (o.prev = l, l.next = o); }
    static remove(t) { n.assertIsNotEnd(t), n.assertIsOwned(t), t.prev.next = t.next, t.next.prev = t.prev, t.debugListId = null, t.prev = null, t.next = null; }
    static insertBefore(t, s) { if (Array.isArray(t)) {
        for (let r of t)
            n.insertBefore(r, s);
        return;
    } if (n.assertIsOwned(s), s.prev === null)
        throw new Error("AssertionError: illegal operation on list start"); n.assertIsNotEnd(t), n.assertIsUnowned(t), t.debugListId = s.debugListId, t.prev = null, s.prev.next = t, t.prev = s.prev, t.next = s, s.prev = t; }
    static insertAfter(t, s) { if (n.assertIsOwned(s), s.next === null)
        throw new Error("AssertionError: illegal operation on list end"); n.assertIsNotEnd(t), n.assertIsUnowned(t), t.debugListId = s.debugListId, s.next.prev = t, t.next = s.next, t.prev = s, s.next = t; }
    static assertIsUnowned(t) { if (t.debugListId !== null)
        throw new Error(`AssertionError: illegal operation on owned node: ${u[t.kind]}`); }
    static assertIsOwned(t, s) { if (t.debugListId === null)
        throw new Error(`AssertionError: illegal operation on unowned node: ${u[t.kind]}`); if (s !== void 0 && t.debugListId !== s)
        throw new Error(`AssertionError: node belongs to the wrong list (expected ${s}, actual ${t.debugListId})`); }
    static assertIsNotEnd(t) { if (t.kind === u.ListEnd)
        throw new Error("AssertionError: illegal operation on list head or tail"); }
} return n; })();
function rt(n) { return E({ kind: u.Statement, statement: n }, P); }
function tn(n, e, t, s) { return E({ kind: u.Variable, xref: n, variable: e, initializer: t, flags: s }, P); }
var P = { debugListId: null, prev: null, next: null }, ah = Symbol("ConsumesSlot"), Sl = Symbol("DependsOnSlotContext"), Kn = Symbol("ConsumesVars"), wi = Symbol("UsesVarOffset"), ot = { [ah]: !0, numSlotsUsed: 1 }, ze = { [Sl]: !0 }, Ge = { [Kn]: !0 };
function Os(n) { return n[ah] === !0; }
function Yr(n) { return n[Sl] === !0; }
function ua(n) { return n[Kn] === !0; }
function ou(n) { return n[wi] === !0; }
function Tm(n, e, t) { return E(E(E({ kind: u.InterpolateText, target: n, interpolation: e, sourceSpan: t }, ze), Ge), P); }
var ne = class {
    strings;
    expressions;
    i18nPlaceholders;
    constructor(e, t, s) { if (this.strings = e, this.expressions = t, this.i18nPlaceholders = s, s.length !== 0 && s.length !== t.length)
        throw new Error(`Expected ${t.length} placeholders to match interpolation expression count, but got ${s.length}`); }
};
function Qn(n, e, t, s, r, i, o, a, c, l, p) { return E({ kind: u.Binding, bindingKind: e, target: n, name: t, expression: s, unit: r, securityContext: i, isTextAttribute: o, isStructuralTemplateAttribute: a, templateKind: c, i18nContext: null, i18nMessage: l, sourceSpan: p }, P); }
function _m(n, e, t, s, r, i, o, a, c, l) { return E(E(E({ kind: u.Property, target: n, name: e, expression: t, bindingKind: s, securityContext: r, sanitizer: null, isStructuralTemplateAttribute: i, templateKind: o, i18nContext: a, i18nMessage: c, sourceSpan: l }, ze), Ge), P); }
function Im(n, e, t, s, r, i, o, a, c) { return E(E(E({ kind: u.TwoWayProperty, target: n, name: e, expression: t, securityContext: s, sanitizer: null, isStructuralTemplateAttribute: r, templateKind: i, i18nContext: o, i18nMessage: a, sourceSpan: c }, ze), Ge), P); }
function Nm(n, e, t, s, r) { return E(E(E({ kind: u.StyleProp, target: n, name: e, expression: t, unit: s, sourceSpan: r }, ze), Ge), P); }
function Dm(n, e, t, s) { return E(E(E({ kind: u.ClassProp, target: n, name: e, expression: t, sourceSpan: s }, ze), Ge), P); }
function Pm(n, e, t) { return E(E(E({ kind: u.StyleMap, target: n, expression: e, sourceSpan: t }, ze), Ge), P); }
function Lm(n, e, t) { return E(E(E({ kind: u.ClassMap, target: n, expression: e, sourceSpan: t }, ze), Ge), P); }
function au(n, e, t, s, r, i, o, a, c, l) { return E(E(E({ kind: u.Attribute, target: n, namespace: e, name: t, expression: s, securityContext: r, sanitizer: null, isTextAttribute: i, isStructuralTemplateAttribute: o, templateKind: a, i18nContext: null, i18nMessage: c, sourceSpan: l }, ze), Ge), P); }
function Bm(n, e) { return E({ kind: u.Advance, delta: n, sourceSpan: e }, P); }
function ch(n, e, t, s) { return E(E(E({ kind: u.Conditional, target: n, test: e, conditions: t, processed: null, sourceSpan: s, contextValue: null }, P), ze), Ge); }
function $m(n, e, t, s) { return E(E({ kind: u.Repeater, target: n, targetSlot: e, collection: t, sourceSpan: s }, P), ze); }
function cu(n, e, t, s, r, i, o) { return E({ kind: u.AnimationBinding, name: n, target: e, animationKind: t, expression: s, i18nMessage: null, securityContext: r, sanitizer: null, sourceSpan: i, animationBindingKind: o }, P); }
function Mm(n, e, t, s) { return E(E(E({ kind: u.DeferWhen, target: n, expr: e, modifier: t, sourceSpan: s }, P), ze), Ge); }
function lh(n, e, t, s, r, i, o, a, c, l, p) { return E(E(E({ kind: u.I18nExpression, context: n, target: e, i18nOwner: t, handle: s, expression: r, icuPlaceholder: i, i18nPlaceholder: o, resolutionTime: a, usage: c, name: l, sourceSpan: p }, P), Ge), ze); }
function Rm(n, e, t) { return E({ kind: u.I18nApply, owner: n, handle: e, sourceSpan: t }, P); }
function Fm(n, e, t, s) { return E(E(E({ kind: u.StoreLet, target: n, declaredName: e, value: t, sourceSpan: s }, ze), Ge), P); }
function Om(n, e) { return E(E({ kind: u.Control, sourceSpan: e, target: n }, ze), P); }
function Bt(n) { return n instanceof z; }
var z = class extends j {
    constructor(e = null) { super(null, e); }
}, me = class n extends z {
    name;
    kind = I.LexicalRead;
    constructor(e) { super(), this.name = e; }
    visitExpression(e, t) { }
    isEquivalent(e) { return this.name === e.name; }
    isConstant() { return !1; }
    transformInternalExpressions() { }
    clone() { return new n(this.name); }
}, bo = class n extends z {
    target;
    targetSlot;
    offset;
    kind = I.Reference;
    constructor(e, t, s) { super(), this.target = e, this.targetSlot = t, this.offset = s; }
    visitExpression() { }
    isEquivalent(e) { return e instanceof n && e.target === this.target; }
    isConstant() { return !1; }
    transformInternalExpressions() { }
    clone() { return new n(this.target, this.targetSlot, this.offset); }
}, cc = class n extends z {
    childrenViewXref;
    childrenViewHandle;
    foreignComponentConstIndex;
    kind = I.ForeignContent;
    constructor(e, t, s) { super(), this.childrenViewXref = e, this.childrenViewHandle = t, this.foreignComponentConstIndex = s; }
    visitExpression() { }
    isEquivalent(e) { return e instanceof n && e.childrenViewXref === this.childrenViewXref && e.foreignComponentConstIndex === this.foreignComponentConstIndex; }
    isConstant() { return !1; }
    transformInternalExpressions() { }
    clone() { return new n(this.childrenViewXref, this.childrenViewHandle, this.foreignComponentConstIndex); }
}, Zr = class n extends z {
    target;
    value;
    sourceSpan;
    kind = I.StoreLet;
    [Kn] = !0;
    [Sl] = !0;
    constructor(e, t, s) { super(), this.target = e, this.value = t, this.sourceSpan = s; }
    visitExpression() { }
    isEquivalent(e) { return e instanceof n && e.target === this.target && e.value.isEquivalent(this.value); }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { this.value = k(this.value, e, t); }
    clone() { return new n(this.target, this.value, this.sourceSpan); }
}, Jr = class n extends z {
    target;
    targetSlot;
    kind = I.ContextLetReference;
    constructor(e, t) { super(), this.target = e, this.targetSlot = t; }
    visitExpression() { }
    isEquivalent(e) { return e instanceof n && e.target === this.target; }
    isConstant() { return !1; }
    transformInternalExpressions() { }
    clone() { return new n(this.target, this.targetSlot); }
}, pn = class n extends z {
    view;
    kind = I.Context;
    constructor(e) { super(), this.view = e; }
    visitExpression() { }
    isEquivalent(e) { return e instanceof n && e.view === this.view; }
    isConstant() { return !1; }
    transformInternalExpressions() { }
    clone() { return new n(this.view); }
}, lc = class n extends z {
    view;
    kind = I.TrackContext;
    constructor(e) { super(), this.view = e; }
    visitExpression() { }
    isEquivalent(e) { return e instanceof n && e.view === this.view; }
    isConstant() { return !1; }
    transformInternalExpressions() { }
    clone() { return new n(this.view); }
}, Ao = class n extends z {
    kind = I.NextContext;
    steps = 1;
    visitExpression() { }
    isEquivalent(e) { return e instanceof n && e.steps === this.steps; }
    isConstant() { return !1; }
    transformInternalExpressions() { }
    clone() { let e = new n; return e.steps = this.steps, e; }
}, uc = class n extends z {
    kind = I.GetCurrentView;
    constructor() { super(); }
    visitExpression() { }
    isEquivalent(e) { return e instanceof n; }
    isConstant() { return !1; }
    transformInternalExpressions() { }
    clone() { return new n; }
}, Kr = class n extends z {
    view;
    kind = I.RestoreView;
    constructor(e) { super(), this.view = e; }
    visitExpression(e, t) { typeof this.view != "number" && this.view.visitExpression(e, t); }
    isEquivalent(e) { return !(e instanceof n) || typeof e.view != typeof this.view ? !1 : typeof this.view == "number" ? this.view === e.view : this.view.isEquivalent(e.view); }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { typeof this.view != "number" && (this.view = k(this.view, e, t)); }
    clone() { return new n(this.view instanceof j ? this.view.clone() : this.view); }
}, ko = class n extends z {
    expr;
    kind = I.ResetView;
    constructor(e) { super(), this.expr = e; }
    visitExpression(e, t) { this.expr.visitExpression(e, t); }
    isEquivalent(e) { return e instanceof n && this.expr.isEquivalent(e.expr); }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { this.expr = k(this.expr, e, t); }
    clone() { return new n(this.expr.clone()); }
}, To = class n extends z {
    target;
    value;
    kind = I.TwoWayBindingSet;
    constructor(e, t) { super(), this.target = e, this.value = t; }
    visitExpression(e, t) { this.target.visitExpression(e, t), this.value.visitExpression(e, t); }
    isEquivalent(e) { return this.target.isEquivalent(e.target) && this.value.isEquivalent(e.value); }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { this.target = k(this.target, e, t), this.value = k(this.value, e, t); }
    clone() { return new n(this.target, this.value); }
}, Ht = class n extends z {
    xref;
    kind = I.ReadVariable;
    name = null;
    constructor(e) { super(), this.xref = e; }
    visitExpression() { }
    isEquivalent(e) { return e instanceof n && e.xref === this.xref; }
    isConstant() { return !1; }
    transformInternalExpressions() { }
    clone() { let e = new n(this.xref); return e.name = this.name, e; }
}, Yn = class n extends z {
    kind = I.PureFunctionExpr;
    [Kn] = !0;
    [wi] = !0;
    varOffset = null;
    body;
    args;
    fn = null;
    constructor(e, t) { super(), this.body = e, this.args = t; }
    visitExpression(e, t) { this.body?.visitExpression(e, t); for (let s of this.args)
        s.visitExpression(e, t); }
    isEquivalent(e) { return !(e instanceof n) || e.args.length !== this.args.length ? !1 : e.body !== null && this.body !== null && e.body.isEquivalent(this.body) && e.args.every((t, s) => t.isEquivalent(this.args[s])); }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { this.body !== null ? this.body = k(this.body, e, t | M.InChildOperation) : this.fn !== null && (this.fn = k(this.fn, e, t)); for (let s = 0; s < this.args.length; s++)
        this.args[s] = k(this.args[s], e, t); }
    clone() { let e = new n(this.body?.clone() ?? null, this.args.map(t => t.clone())); return e.fn = this.fn?.clone() ?? null, e.varOffset = this.varOffset, e; }
}, hn = class n extends z {
    index;
    kind = I.PureFunctionParameterExpr;
    constructor(e) { super(), this.index = e; }
    visitExpression() { }
    isEquivalent(e) { return e instanceof n && e.index === this.index; }
    isConstant() { return !0; }
    transformInternalExpressions() { }
    clone() { return new n(this.index); }
}, Zn = class n extends z {
    target;
    targetSlot;
    name;
    args;
    kind = I.PipeBinding;
    [Kn] = !0;
    [wi] = !0;
    varOffset = null;
    constructor(e, t, s, r) { super(), this.target = e, this.targetSlot = t, this.name = s, this.args = r; }
    visitExpression(e, t) { for (let s of this.args)
        s.visitExpression(e, t); }
    isEquivalent() { return !1; }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { for (let s = 0; s < this.args.length; s++)
        this.args[s] = k(this.args[s], e, t); }
    clone() { let e = new n(this.target, this.targetSlot, this.name, this.args.map(t => t.clone())); return e.varOffset = this.varOffset, e; }
}, ei = class n extends z {
    target;
    targetSlot;
    name;
    args;
    numArgs;
    kind = I.PipeBindingVariadic;
    [Kn] = !0;
    [wi] = !0;
    varOffset = null;
    constructor(e, t, s, r, i) { super(), this.target = e, this.targetSlot = t, this.name = s, this.args = r, this.numArgs = i; }
    visitExpression(e, t) { this.args.visitExpression(e, t); }
    isEquivalent() { return !1; }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { this.args = k(this.args, e, t); }
    clone() { let e = new n(this.target, this.targetSlot, this.name, this.args.clone(), this.numArgs); return e.varOffset = this.varOffset, e; }
}, Pn = class n extends z {
    receiver;
    name;
    kind = I.SafePropertyRead;
    constructor(e, t) { super(), this.receiver = e, this.name = t; }
    get index() { return this.name; }
    visitExpression(e, t) { this.receiver.visitExpression(e, t); }
    isEquivalent() { return !1; }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { this.receiver = k(this.receiver, e, t); }
    clone() { return new n(this.receiver.clone(), this.name); }
}, Ln = class n extends z {
    receiver;
    index;
    kind = I.SafeKeyedRead;
    constructor(e, t, s) { super(s), this.receiver = e, this.index = t; }
    visitExpression(e, t) { this.receiver.visitExpression(e, t), this.index.visitExpression(e, t); }
    isEquivalent() { return !1; }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { this.receiver = k(this.receiver, e, t), this.index = k(this.index, e, t); }
    clone() { return new n(this.receiver.clone(), this.index.clone(), this.sourceSpan); }
}, ti = class n extends z {
    expr;
    kind = I.SafeNavigationMigration;
    constructor(e) { super(), this.expr = e; }
    visitExpression(e, t) { this.expr.visitExpression(e, t); }
    isEquivalent(e) { return e instanceof n && this.expr.isEquivalent(e.expr); }
    isConstant() { return this.expr.isConstant(); }
    transformInternalExpressions(e, t) { this.expr = k(this.expr, e, t | M.InSafeNavigationMigration); }
    clone() { return new n(this.expr.clone()); }
}, Ps = class n extends z {
    guard;
    expr;
    kind = I.SafeTernaryExpr;
    constructor(e, t) { super(), this.guard = e, this.expr = t; }
    visitExpression(e, t) { this.guard.visitExpression(e, t), this.expr.visitExpression(e, t); }
    isEquivalent() { return !1; }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { this.guard = k(this.guard, e, t), this.expr = k(this.expr, e, t); }
    clone() { return new n(this.guard.clone(), this.expr.clone()); }
}, ni = class n extends z {
    kind = I.EmptyExpr;
    visitExpression(e, t) { }
    isEquivalent(e) { return e instanceof n; }
    isConstant() { return !0; }
    clone() { return new n; }
    transformInternalExpressions() { }
}, $t = class n extends z {
    expr;
    xref;
    kind = I.AssignTemporaryExpr;
    name = null;
    constructor(e, t) { super(), this.expr = e, this.xref = t; }
    visitExpression(e, t) { this.expr.visitExpression(e, t); }
    isEquivalent() { return !1; }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { this.expr = k(this.expr, e, t); }
    clone() { let e = new n(this.expr.clone(), this.xref); return e.name = this.name, e; }
}, fn = class n extends z {
    xref;
    kind = I.ReadTemporaryExpr;
    name = null;
    constructor(e) { super(), this.xref = e; }
    visitExpression(e, t) { }
    isEquivalent() { return this.xref === this.xref; }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { }
    clone() { let e = new n(this.xref); return e.name = this.name, e; }
}, _o = class n extends z {
    slot;
    kind = I.SlotLiteralExpr;
    constructor(e) { super(), this.slot = e; }
    visitExpression(e, t) { }
    isEquivalent(e) { return e instanceof n && e.slot === this.slot; }
    isConstant() { return !0; }
    clone() { return new n(this.slot); }
    transformInternalExpressions() { }
}, Io = class n extends z {
    expr;
    target;
    targetSlot;
    alias;
    kind = I.ConditionalCase;
    constructor(e, t, s, r = null) { super(), this.expr = e, this.target = t, this.targetSlot = s, this.alias = r; }
    visitExpression(e, t) { this.expr !== null && this.expr.visitExpression(e, t); }
    isEquivalent(e) { return e instanceof n && e.expr === this.expr; }
    isConstant() { return !0; }
    clone() { return new n(this.expr, this.target, this.targetSlot); }
    transformInternalExpressions(e, t) { this.expr !== null && (this.expr = k(this.expr, e, t)); }
}, si = class n extends z {
    expr;
    kind = I.ConstCollected;
    constructor(e) { super(), this.expr = e; }
    transformInternalExpressions(e, t) { this.expr = e(this.expr, t); }
    visitExpression(e, t) { this.expr.visitExpression(e, t); }
    isEquivalent(e) { return e instanceof n ? this.expr.isEquivalent(e.expr) : !1; }
    isConstant() { return this.expr.isConstant(); }
    clone() { return new n(this.expr); }
}, pc = class n extends z {
    parameters;
    body;
    kind = I.ArrowFunction;
    [Kn] = !0;
    [wi] = !0;
    contextName = st;
    currentViewName = "view";
    varOffset = null;
    ops;
    constructor(e, t) { super(), this.parameters = e, this.body = t, this.ops = new S, this.ops.push([rt(new fe(t, t.sourceSpan))]); }
    visitExpression(e, t) { for (let s of this.ops)
        ae(s, r => { r.visitExpression(e, t); }); }
    isEquivalent(e) { return e instanceof n && e.parameters.length === this.parameters.length && e.parameters.every((t, s) => t.isEquivalent(this.parameters[s])) && e.body.isEquivalent(this.body); }
    isConstant() { return !1; }
    transformInternalExpressions(e, t) { for (let s of this.ops)
        te(s, e, t | (M.InChildOperation | M.InArrowFunctionOperation)); }
    clone() { let e = new n(this.parameters, this.body); return e.varOffset = this.varOffset, e.ops = this.ops, e; }
};
function ae(n, e) { te(n, (t, s) => (e(t, s), t), M.None); }
var M = (function (n) { return n[n.None = 0] = "None", n[n.InChildOperation = 1] = "InChildOperation", n[n.InArrowFunctionOperation = 2] = "InArrowFunctionOperation", n[n.InSafeNavigationMigration = 4] = "InSafeNavigationMigration", n; })(M || {});
function pa(n, e, t) { for (let s = 0; s < n.expressions.length; s++)
    n.expressions[s] = k(n.expressions[s], e, t); }
function te(n, e, t) { switch (n.kind) {
    case u.StyleProp:
    case u.StyleMap:
    case u.ClassProp:
    case u.ClassMap:
    case u.AnimationString:
    case u.AnimationBinding:
    case u.Binding:
        n.expression instanceof ne ? pa(n.expression, e, t) : n.expression = k(n.expression, e, t);
        break;
    case u.Property:
    case u.DomProperty:
    case u.Attribute:
        n.expression instanceof ne ? pa(n.expression, e, t) : n.expression = k(n.expression, e, t), n.sanitizer = n.sanitizer && k(n.sanitizer, e, t);
        break;
    case u.TwoWayProperty:
        n.expression = k(n.expression, e, t), n.sanitizer = n.sanitizer && k(n.sanitizer, e, t);
        break;
    case u.I18nExpression:
        n.expression = k(n.expression, e, t);
        break;
    case u.InterpolateText:
        pa(n.interpolation, e, t);
        break;
    case u.Statement:
        No(n.statement, e, t);
        break;
    case u.Variable:
        n.initializer = k(n.initializer, e, t);
        break;
    case u.Conditional:
        for (let s of n.conditions)
            s.expr !== null && (s.expr = k(s.expr, e, t));
        n.processed !== null && (n.processed = k(n.processed, e, t)), n.contextValue !== null && (n.contextValue = k(n.contextValue, e, t));
        break;
    case u.Animation:
    case u.AnimationListener:
    case u.Listener:
    case u.TwoWayListener:
        for (let s of n.handlerOps)
            te(s, e, t | M.InChildOperation);
        break;
    case u.ExtractedAttribute:
        n.expression = n.expression && k(n.expression, e, t), n.trustedValueFn = n.trustedValueFn && k(n.trustedValueFn, e, t);
        break;
    case u.RepeaterCreate:
        if (n.trackByOps === null)
            n.track = k(n.track, e, t);
        else
            for (let s of n.trackByOps)
                te(s, e, t | M.InChildOperation);
        n.trackByFn !== null && (n.trackByFn = k(n.trackByFn, e, t));
        break;
    case u.Repeater:
        n.collection = k(n.collection, e, t);
        break;
    case u.Defer:
        n.loadingConfig !== null && (n.loadingConfig = k(n.loadingConfig, e, t)), n.placeholderConfig !== null && (n.placeholderConfig = k(n.placeholderConfig, e, t)), n.resolverFn !== null && (n.resolverFn = k(n.resolverFn, e, t));
        break;
    case u.I18nMessage:
        for (let [s, r] of n.params)
            n.params.set(s, k(r, e, t));
        for (let [s, r] of n.postprocessingParams)
            n.postprocessingParams.set(s, k(r, e, t));
        break;
    case u.DeferWhen:
        n.expr = k(n.expr, e, t);
        break;
    case u.StoreLet:
        n.value = k(n.value, e, t);
        break;
    case u.ForeignComponent:
        for (let [s, r] of n.props)
            n.props.set(s, k(r, e, t));
        break;
    case u.Advance:
    case u.Container:
    case u.ContainerEnd:
    case u.ContainerStart:
    case u.DeferOn:
    case u.DisableBindings:
    case u.Element:
    case u.ElementEnd:
    case u.ElementStart:
    case u.EnableBindings:
    case u.I18n:
    case u.I18nApply:
    case u.I18nContext:
    case u.I18nEnd:
    case u.I18nStart:
    case u.IcuEnd:
    case u.IcuStart:
    case u.Namespace:
    case u.Pipe:
    case u.Projection:
    case u.ProjectionDef:
    case u.EnableIncrementalHydrationRuntime:
    case u.Template:
    case u.Content:
    case u.Text:
    case u.I18nAttributes:
    case u.IcuPlaceholder:
    case u.DeclareLet:
    case u.SourceLocation:
    case u.ConditionalCreate:
    case u.ConditionalBranchCreate:
    case u.Control:
    case u.ControlCreate: break;
    default: throw new Error(`AssertionError: transformExpressionsInOp doesn't handle ${u[n.kind]}`);
} }
function k(n, e, t) { if (n instanceof z)
    n.transformInternalExpressions(e, t);
else if (n instanceof H)
    n.lhs = k(n.lhs, e, t), n.rhs = k(n.rhs, e, t);
else if (n instanceof On)
    n.expr = k(n.expr, e, t);
else if (n instanceof We)
    n.receiver = k(n.receiver, e, t);
else if (n instanceof gt)
    n.receiver = k(n.receiver, e, t), n.index = k(n.index, e, t);
else if (n instanceof pe) {
    n.fn = k(n.fn, e, t);
    for (let s = 0; s < n.args.length; s++)
        n.args[s] = k(n.args[s], e, t);
}
else if (n instanceof Dt)
    for (let s = 0; s < n.entries.length; s++)
        n.entries[s] = k(n.entries[s], e, t);
else if (n instanceof vt)
    for (let s of n.entries)
        s instanceof on ? s.expression = k(s.expression, e, t) : s.value = k(s.value, e, t);
else if (n instanceof Nt)
    n.condition = k(n.condition, e, t), n.trueCase = k(n.trueCase, e, t), n.falseCase !== null && (n.falseCase = k(n.falseCase, e, t));
else if (n instanceof Es)
    n.expr = k(n.expr, e, t);
else if (n instanceof zi)
    n.expr = k(n.expr, e, t);
else if (n instanceof Xi)
    for (let s = 0; s < n.expressions.length; s++)
        n.expressions[s] = k(n.expressions[s], e, t);
else if (n instanceof wr)
    n.condition = k(n.condition, e, t);
else if (n instanceof mr)
    n.tag = k(n.tag, e, t), n.template.expressions = n.template.expressions.map(s => k(s, e, t));
else if (n instanceof rn)
    if (Array.isArray(n.body))
        for (let s = 0; s < n.body.length; s++)
            No(n.body[s], e, t | M.InChildOperation);
    else
        n.body = k(n.body, e, t | M.InChildOperation);
else if (!(n instanceof q)) {
    if (n instanceof vr)
        for (let s = 0; s < n.expressions.length; s++)
            n.expressions[s] = k(n.expressions[s], e, t);
    else if (n instanceof mt)
        n.expr = k(n.expr, e, t);
    else if (n instanceof Vn)
        n.expression = k(n.expression, e, t);
    else if (!(n instanceof dt || n instanceof Fn || n instanceof Ae || n instanceof xs))
        throw new Error(`Unhandled expression kind: ${n.constructor.name}`);
} return e(n, t); }
function No(n, e, t) { if (n instanceof ke)
    n.expr = k(n.expr, e, t);
else if (n instanceof fe)
    n.value = k(n.value, e, t);
else if (n instanceof ve)
    n.value !== void 0 && (n.value = k(n.value, e, t));
else if (n instanceof Zi) {
    n.condition = k(n.condition, e, t);
    for (let s of n.trueCase)
        No(s, e, t);
    for (let s of n.falseCase)
        No(s, e, t);
}
else
    throw new Error(`Unhandled statement kind: ${n.constructor.name}`); }
function uh(n) { return n instanceof Ae && typeof n.value == "string"; }
var ye = class {
    slot = null;
}, Vm = new Set([u.Element, u.ElementStart, u.Container, u.ContainerStart, u.Template, u.RepeaterCreate, u.ConditionalCreate, u.ConditionalBranchCreate]);
function dn(n) { return Vm.has(n.kind); }
function qm(n, e, t, s, r, i) { return E(E({ kind: u.ElementStart, xref: e, tag: n, handle: new ye, attributes: null, localRefs: [], nonBindable: !1, namespace: t, i18nPlaceholder: s, startSourceSpan: r, wholeSourceSpan: i }, ot), P); }
function Hm(n, e, t, s) { return E(E({ kind: u.ForeignComponent, xref: n, handle: new ye, constIndex: e, props: t, sourceSpan: s }, ot), P); }
function lu(n, e, t, s, r) { return E({ kind: u.Content, target: n, propertyName: t, view: e, startSourceSpan: s, sourceSpan: r }, P); }
function El(n, e, t, s, r, i, o, a) { return E(E({ kind: u.Template, xref: n, templateKind: e, attributes: null, tag: t, handle: new ye, functionNameSuffix: s, decls: null, vars: null, localRefs: [], nonBindable: !1, namespace: r, i18nPlaceholder: i, startSourceSpan: o, wholeSourceSpan: a }, ot), P); }
function ph(n, e, t, s, r, i, o, a) { return E(E({ kind: u.ConditionalCreate, xref: n, templateKind: e, attributes: null, tag: t, handle: new ye, functionNameSuffix: s, decls: null, vars: null, localRefs: [], nonBindable: !1, namespace: r, i18nPlaceholder: i, startSourceSpan: o, wholeSourceSpan: a }, ot), P); }
function hh(n, e, t, s, r, i, o, a) { return E(E({ kind: u.ConditionalBranchCreate, xref: n, templateKind: e, attributes: null, tag: t, handle: new ye, functionNameSuffix: s, decls: null, vars: null, localRefs: [], nonBindable: !1, namespace: r, i18nPlaceholder: i, startSourceSpan: o, wholeSourceSpan: a }, ot), P); }
function Um(n, e, t, s, r, i, o, a, c, l) { return se(E(E(E({ kind: u.RepeaterCreate, attributes: null, xref: n, handle: new ye, emptyView: e, track: s, trackByFn: null, trackByOps: null, tag: t, emptyTag: i, emptyAttributes: null, functionNameSuffix: "For", namespace: oe.HTML, nonBindable: !1, localRefs: [], decls: null, vars: null, varNames: r, usesComponentInstance: !1, i18nPlaceholder: o, emptyI18nPlaceholder: a, startSourceSpan: c, wholeSourceSpan: l }, ot), P), Ge), { numSlotsUsed: e === null ? 2 : 3 }); }
function Wm(n, e) { return E({ kind: u.ElementEnd, xref: n, sourceSpan: e }, P); }
function jm(n) { return E({ kind: u.DisableBindings, xref: n }, P); }
function zm(n) { return E({ kind: u.EnableBindings, xref: n }, P); }
function fh(n, e, t, s) { return E(E({ kind: u.Text, xref: n, handle: new ye, initialValue: e, icuPlaceholder: t, sourceSpan: s }, ot), P); }
function Gm(n, e, t, s, r, i) { return E({ kind: u.AnimationString, name: n, target: e, animationKind: t, expression: s, i18nMessage: null, securityContext: r, sanitizer: null, sourceSpan: i }, P); }
function Xm(n, e, t, s, r, i) { let o = new S; return o.push(s), E({ kind: u.Animation, name: n, target: e, animationKind: t, handlerOps: o, handlerFnName: null, i18nMessage: null, securityContext: r, sanitizer: null, sourceSpan: i }, P); }
function xl(n, e, t, s, r, i, o, a, c) { let l = new S; return l.push(r), E({ kind: u.Listener, target: n, targetSlot: e, tag: s, hostListener: a, name: t, handlerOps: l, handlerFnName: null, consumesDollarEvent: !1, isLegacyAnimationListener: i !== null, legacyAnimationPhase: i, eventTarget: o, sourceSpan: c }, P); }
function dh(n, e, t, s, r, i, o, a, c) { let l = new S; return l.push(r), E({ kind: u.AnimationListener, target: n, targetSlot: e, tag: s, hostListener: a, name: t, animationKind: i, handlerOps: l, handlerFnName: null, consumesDollarEvent: !1, eventTarget: o, sourceSpan: c }, P); }
function mh(n, e, t, s, r, i) { let o = new S; return o.push(r), E({ kind: u.TwoWayListener, target: n, targetSlot: e, tag: s, name: t, handlerOps: o, handlerFnName: null, sourceSpan: i }, P); }
function Qm(n, e, t) { return E(E({ kind: u.Pipe, xref: n, handle: e, name: t }, P), ot); }
function Ym(n) { return E({ kind: u.Namespace, active: n }, P); }
function Zm(n) { return E({ kind: u.ProjectionDef, def: n }, P); }
function Jm(n) { return E({ kind: u.EnableIncrementalHydrationRuntime, sourceSpan: n }, P); }
function Km(n, e, t, s, r) { return se(E(E({ kind: u.Projection, xref: n, handle: new ye, selector: e, i18nPlaceholder: t, fallbackView: s, projectionSlotIndex: 0, attributes: null, localRefs: [], sourceSpan: r }, P), ot), { numSlotsUsed: s === null ? 1 : 2 }); }
function ft(n, e, t, s, r, i, o, a) { return E({ kind: u.ExtractedAttribute, target: n, bindingKind: e, namespace: t, name: s, expression: r, i18nContext: i, i18nMessage: o, securityContext: a, trustedValueFn: null }, P); }
function eg(n, e, t, s, r, i) { return se(E(E({ kind: u.Defer, xref: n, handle: new ye, mainView: e, mainSlot: t, loadingView: null, loadingSlot: null, loadingConfig: null, loadingMinimumTime: null, loadingAfterTime: null, placeholderView: null, placeholderSlot: null, placeholderConfig: null, placeholderMinimumTime: null, errorView: null, errorSlot: null, ownResolverFn: s, resolverFn: r, flags: null, sourceSpan: i }, P), ot), { numSlotsUsed: 2 }); }
function Zt(n, e, t, s) { return E({ kind: u.DeferOn, defer: n, trigger: e, modifier: t, sourceSpan: s }, P); }
function tg(n, e, t) { return E(E({ kind: u.DeclareLet, xref: n, declaredName: e, sourceSpan: t, handle: new ye }, ot), P); }
function ng(n, e, t, s, r, i, o, a) { return E({ kind: u.I18nMessage, xref: n, i18nContext: e, i18nBlock: t, message: s, messagePlaceholder: r, params: i, postprocessingParams: o, needsPostprocessing: a, subMessages: [] }, P); }
function Jo(n, e, t, s) { return E(E({ kind: u.I18nStart, xref: n, handle: new ye, root: t ?? n, message: e, messageIndex: null, subTemplateIndex: null, context: null, sourceSpan: s }, P), ot); }
function Ko(n, e) { return E({ kind: u.I18nEnd, xref: n, sourceSpan: e }, P); }
function sg(n, e, t, s) { return E({ kind: u.IcuStart, xref: n, message: e, messagePlaceholder: t, context: null, sourceSpan: s }, P); }
function rg(n) { return E({ kind: u.IcuEnd, xref: n }, P); }
function ig(n, e, t) { return E({ kind: u.IcuPlaceholder, xref: n, name: e, strings: t, expressionPlaceholders: [] }, P); }
function ha(n, e, t, s, r) { if (t === null && n !== Tn.Attr)
    throw new Error("AssertionError: i18nBlock must be provided for non-attribute contexts."); return E({ kind: u.I18nContext, contextKind: n, xref: e, i18nBlock: t, message: s, sourceSpan: r, params: new Map, postprocessingParams: new Map }, P); }
function gh(n, e, t) { return E(E({ kind: u.I18nAttributes, xref: n, handle: e, target: t, i18nAttributesConfig: null }, P), ot); }
function og(n, e) { return E({ kind: u.SourceLocation, templatePath: n, locations: e }, P); }
function ag(n) { return E({ kind: u.ControlCreate, sourceSpan: n }, P); }
function cg(n, e, t, s, r, i) { return E(E({ kind: u.DomProperty, name: n, expression: e, bindingKind: t, i18nContext: s, securityContext: r, sanitizer: null, sourceSpan: i }, Ge), P); }
var vh = "CTX_REF_MARKER", C = (function (n) { return n[n.Tmpl = 0] = "Tmpl", n[n.Host = 1] = "Host", n[n.Both = 2] = "Both", n; })(C || {}), Ve = (function (n) { return n[n.Full = 0] = "Full", n[n.DomOnly = 1] = "DomOnly", n; })(Ve || {}), Do = class {
    componentName;
    pool;
    mode;
    legacyOptionalChaining;
    constructor(e, t, s, r) { this.componentName = e, this.pool = t, this.mode = s, this.legacyOptionalChaining = r; }
    kind = C.Both;
    allocateXrefId() { return this.nextXrefId++; }
    nextXrefId = 0;
}, ri = class extends Do {
    relativeContextFilePath;
    i18nUseExternalIds;
    deferMeta;
    allDeferrableDepsFn;
    relativeTemplatePath;
    enableDebugLocations;
    foreignImports;
    foreignMatcher;
    constructor(e, t, s, r, i, o, a, c, l, p, h) { if (super(e, t, s, p), this.relativeContextFilePath = r, this.i18nUseExternalIds = i, this.deferMeta = o, this.allDeferrableDepsFn = a, this.relativeTemplatePath = c, this.enableDebugLocations = l, this.foreignImports = h, this.root = new Ye(this, this.allocateXrefId(), null), this.views.set(this.root.xref, this.root), h && h.length > 0) {
        let d = new Map;
        for (let v of h)
            d.set(v.name, [v]);
        this.foreignMatcher = new fr(d);
    }
    else
        this.foreignMatcher = null; }
    getForeignComponent(e) { if (this.foreignMatcher === null)
        return null; let t = this.foreignMatcher.match(e.name); return t.length > 0 ? t[0] : null; }
    kind = C.Tmpl;
    fnSuffix = "Template";
    root;
    views = new Map;
    contentSelectors = null;
    allocateView(e) { let t = new Ye(this, this.allocateXrefId(), e); return this.views.set(t.xref, t), t; }
    get units() { return this.views.values(); }
    addConst(e, t) { for (let r = 0; r < this.consts.length; r++)
        if (this.consts[r].isEquivalent(e))
            return r; let s = this.consts.length; return this.consts.push(e), t && this.constsInitializers.push(...t), s; }
    consts = [];
    constsInitializers = [];
}, Po = class {
    xref;
    constructor(e) { this.xref = e; }
    create = new S;
    update = new S;
    functions = new Set;
    fnName = null;
    vars = null;
    *ops() { for (let e of this.functions)
        for (let t of e.ops)
            yield t; for (let e of this.create)
        if (yield e, e.kind === u.Listener || e.kind === u.Animation || e.kind === u.AnimationListener || e.kind === u.TwoWayListener)
            for (let t of e.handlerOps)
                yield t;
        else if (e.kind === u.RepeaterCreate && e.trackByOps !== null)
            for (let t of e.trackByOps)
                yield t; for (let e of this.update)
        yield e; }
}, Ye = class extends Po {
    job;
    parent;
    constructor(e, t, s) { super(t), this.job = e, this.parent = s; }
    contextVariables = new Map;
    aliases = new Set;
    decls = null;
}, Lo = class extends Do {
    constructor(e, t, s, r) { super(e, t, s, r), this.root = new hc(this); }
    kind = C.Host;
    fnSuffix = "HostBindings";
    root;
    get units() { return [this.root]; }
}, hc = class extends Po {
    job;
    constructor(e) { super(0), this.job = e; }
    attributes = null;
};
function lg(n) { for (let e of n.units)
    for (let t of e.ops())
        te(t, ug, M.None); }
function ug(n) { if (n instanceof pe && n.fn instanceof me && n.fn.name === "$any") {
    if (n.args.length !== 1)
        throw new Error("The $any builtin function expects exactly one argument.");
    return n.args[0];
} return n; }
function pg(n) { let e = new Map; for (let t of n.units)
    for (let s of t.create)
        s.kind === u.I18nContext && e.set(s.xref, s); for (let t of n.units)
    for (let s of t.update)
        s.kind === u.I18nExpression && hg(e, s) && S.insertAfter(Rm(s.i18nOwner, s.handle, null), s); }
function hg(n, e) { if (e.next?.kind !== u.I18nExpression)
    return !0; let t = n.get(e.context), s = n.get(e.next.context); if (t === void 0)
    throw new Error("AssertionError: expected an I18nContextOp to exist for the I18nExpressionOp's context"); if (s === void 0)
    throw new Error("AssertionError: expected an I18nContextOp to exist for the next I18nExpressionOp's context"); return t.i18nBlock !== null ? t.i18nBlock !== s.i18nBlock : e.i18nOwner !== e.next.i18nOwner; }
function fg(n) { for (let e of n.units) {
    let t = e.update.head, s = [], r = null;
    for (let i of e.create) {
        if (i.kind === u.I18nStart)
            r = { blockXref: i.xref, lastSlotConsumer: i.xref };
        else if (i.kind === u.I18nEnd) {
            for (let o of s)
                o.target = r.lastSlotConsumer, S.insertBefore(o, t);
            s.length = 0, r = null;
        }
        if (Os(i))
            for (r !== null && (r.lastSlotConsumer = i.xref); t.next !== null;) {
                if (r !== null && t.kind === u.I18nExpression && t.usage === Fs.I18nText && t.i18nOwner === r.blockXref) {
                    let a = t;
                    t = t.next, S.remove(a), s.push(a);
                    continue;
                }
                let o = !1;
                if (Yr(t) && t.target !== i.xref ? o = !0 : (t.kind === u.Statement || t.kind === u.Variable) && ae(t, a => { !o && Yr(a) && a.target !== i.xref && (o = !0); }), o)
                    break;
                t = t.next;
            }
    }
} }
function dg(n) { if (!(!n.enableDebugLocations || n.relativeTemplatePath === null))
    for (let e of n.units) {
        let t = [];
        for (let s of e.create)
            if (s.kind === u.ElementStart || s.kind === u.Element) {
                let r = s.startSourceSpan.start;
                t.push({ targetSlot: s.handle, offset: r.offset, line: r.line, column: r.col });
            }
        t.length > 0 && e.create.push(og(n.relativeTemplatePath, t));
    } }
function wh(n) { let e = new Map; for (let t of n.create)
    Os(t) && (e.set(t.xref, t), t.kind === u.RepeaterCreate && t.emptyView !== null && e.set(t.emptyView, t)); return e; }
function mg(n) { for (let e of n.units) {
    let t = wh(e);
    for (let s of e.ops())
        switch (s.kind) {
            case u.Attribute:
                gg(e, s, t);
                break;
            case u.Property:
                if (s.bindingKind !== _.LegacyAnimation && s.bindingKind !== _.Animation) {
                    let r;
                    s.i18nMessage !== null && s.templateKind === null ? r = _.I18n : s.isStructuralTemplateAttribute ? r = _.Template : r = _.Property, S.insertBefore(ft(s.target, r, null, s.name, null, null, null, s.securityContext), cs(t, s.target));
                }
                break;
            case u.TwoWayProperty:
                S.insertBefore(ft(s.target, _.TwoWayProperty, null, s.name, null, null, null, s.securityContext), cs(t, s.target));
                break;
            case u.StyleProp:
            case u.ClassProp:
                s.expression instanceof ni && S.insertBefore(ft(s.target, _.Property, null, s.name, null, null, null, V.STYLE), cs(t, s.target));
                break;
            case u.Listener:
                if (!s.isLegacyAnimationListener) {
                    let r = ft(s.target, _.Property, null, s.name, null, null, null, V.NONE);
                    if (n.kind === C.Host)
                        break;
                    S.insertBefore(r, cs(t, s.target));
                }
                break;
            case u.TwoWayListener:
                if (n.kind !== C.Host) {
                    let r = ft(s.target, _.Property, null, s.name, null, null, null, V.NONE);
                    S.insertBefore(r, cs(t, s.target));
                }
                break;
        }
} }
function cs(n, e) { let t = n.get(e); if (t === void 0)
    throw new Error("All attributes should have an element-like target."); return t; }
function gg(n, e, t) { if (!(e.expression instanceof ne) && e.isTextAttribute) {
    let s = ft(e.target, e.isStructuralTemplateAttribute ? _.Template : _.Attribute, e.namespace, e.name, e.expression, e.i18nContext, e.i18nMessage, e.securityContext);
    if (n.job.kind === C.Host)
        n.create.push(s);
    else {
        let r = cs(t, e.target);
        S.insertBefore(s, r);
    }
    S.remove(e);
} }
var uu = "aria-";
function Sh(n) { return n.startsWith(uu) && n.length > uu.length; }
function vg(n, e) { let t = n.get(e); if (t === void 0)
    throw new Error("All attributes should have an element-like target."); return t; }
function wg(n) { let e = new Map; for (let t of n.units)
    for (let s of t.create)
        dn(s) && e.set(s.xref, s); for (let t of n.units)
    for (let s of t.ops())
        if (s.kind === u.Binding)
            switch (s.bindingKind) {
                case _.Attribute:
                    if (s.name === "ngNonBindable") {
                        S.remove(s);
                        let r = vg(e, s.target);
                        r.nonBindable = !0;
                    }
                    else if (s.name.startsWith("animate."))
                        S.replace(s, cu(s.name, s.target, s.name === "animate.enter" ? "enter" : "leave", s.expression, s.securityContext, s.sourceSpan, 0));
                    else {
                        let [r, i] = be(s.name);
                        S.replace(s, au(s.target, r, i, s.expression, s.securityContext, s.isTextAttribute, s.isStructuralTemplateAttribute, s.templateKind, s.i18nMessage, s.sourceSpan));
                    }
                    break;
                case _.Animation:
                    S.replace(s, cu(s.name, s.target, s.name === "animate.enter" ? "enter" : "leave", s.expression, s.securityContext, s.sourceSpan, 1));
                    break;
                case _.Property:
                case _.LegacyAnimation:
                    n.mode === Ve.DomOnly && Sh(s.name) ? S.replace(s, au(s.target, null, s.name, s.expression, s.securityContext, !1, s.isStructuralTemplateAttribute, s.templateKind, s.i18nMessage, s.sourceSpan)) : n.kind === C.Host ? S.replace(s, cg(s.name, s.expression, s.bindingKind, s.i18nContext, s.securityContext, s.sourceSpan)) : S.replace(s, _m(s.target, s.name, s.expression, s.bindingKind, s.securityContext, s.isStructuralTemplateAttribute, s.templateKind, s.i18nContext, s.i18nMessage, s.sourceSpan));
                    break;
                case _.TwoWayProperty:
                    if (!(s.expression instanceof j))
                        throw new Error(`Expected value of two-way property binding "${s.name}" to be an expression`);
                    S.replace(s, Im(s.target, s.name, s.expression, s.securityContext, s.isStructuralTemplateAttribute, s.templateKind, s.i18nContext, s.i18nMessage, s.sourceSpan));
                    break;
                case _.I18n:
                case _.ClassName:
                case _.StyleProperty: throw new Error(`Unhandled binding of kind ${_[s.bindingKind]}`);
            } }
var pu = new Map([[f.ariaProperty, f.ariaProperty], [f.attribute, f.attribute], [f.classProp, f.classProp], [f.element, f.element], [f.elementContainer, f.elementContainer], [f.elementContainerEnd, f.elementContainerEnd], [f.elementContainerStart, f.elementContainerStart], [f.elementEnd, f.elementEnd], [f.elementStart, f.elementStart], [f.domProperty, f.domProperty], [f.i18nExp, f.i18nExp], [f.listener, f.listener], [f.listener, f.listener], [f.property, f.property], [f.styleProp, f.styleProp], [f.syntheticHostListener, f.syntheticHostListener], [f.syntheticHostProperty, f.syntheticHostProperty], [f.templateCreate, f.templateCreate], [f.twoWayProperty, f.twoWayProperty], [f.twoWayListener, f.twoWayListener], [f.declareLet, f.declareLet], [f.conditionalCreate, f.conditionalBranchCreate], [f.conditionalBranchCreate, f.conditionalBranchCreate], [f.domElement, f.domElement], [f.domElementStart, f.domElementStart], [f.domElementEnd, f.domElementEnd], [f.domElementContainer, f.domElementContainer], [f.domElementContainerStart, f.domElementContainerStart], [f.domElementContainerEnd, f.domElementContainerEnd], [f.domListener, f.domListener], [f.domTemplate, f.domTemplate], [f.animationEnter, f.animationEnter], [f.animationLeave, f.animationLeave], [f.animationEnterListener, f.animationEnterListener], [f.animationLeaveListener, f.animationLeaveListener]]), Sg = 256;
function Eg(n) { for (let e of n.units)
    hu(e.create), hu(e.update); }
function hu(n) { let e = null; for (let t of n) {
    if (t.kind !== u.Statement || !(t.statement instanceof ke)) {
        e = null;
        continue;
    }
    if (!(t.statement.expr instanceof pe) || !(t.statement.expr.fn instanceof Fn)) {
        e = null;
        continue;
    }
    let s = t.statement.expr.fn.value;
    if (!pu.has(s)) {
        e = null;
        continue;
    }
    if (e !== null && pu.get(e.instruction) === s && e.length < Sg) {
        let r = e.expression.callFn(t.statement.expr.args, t.statement.expr.sourceSpan, t.statement.expr.pure);
        e.expression = r, e.op.statement = r.toStmt(), e.length++, S.remove(t);
    }
    else
        e = { op: t, instruction: s, expression: t.statement.expr, length: 1 };
} }
function xg(n) { for (let e of n.units)
    for (let t of e.update)
        (t.kind === u.Attribute || t.kind === u.StyleProp || t.kind == u.StyleMap || t.kind === u.ClassMap) && t.expression instanceof ne && t.expression.strings.length === 2 && t.expression.strings.every(r => r === "") && (t.expression = t.expression.expressions[0]); }
function yg(n) { for (let e of n.units)
    for (let t of e.ops()) {
        if (t.kind !== u.Conditional)
            continue;
        let s, r = t.conditions.findIndex(a => a.expr === null);
        if (r >= 0) {
            let a = t.conditions.splice(r, 1)[0].targetSlot;
            s = new _o(a);
        }
        else
            s = g(-1);
        let i = t.test == null ? null : new $t(t.test, n.allocateXrefId()), o = null;
        for (let a = t.conditions.length - 1; a >= 0; a--) {
            let c = t.conditions[a];
            if (c.expr !== null) {
                if (i !== null) {
                    let l = a === 0 ? i : new fn(i.xref);
                    c.expr = new H(x.Identical, l, c.expr);
                }
                else
                    c.alias !== null && (o ??= n.allocateXrefId(), c.expr = new $t(c.expr, o), t.contextValue = new fn(o));
                s = new Nt(c.expr, new _o(c.targetSlot), s);
            }
        }
        t.processed = s, t.conditions = [];
    } }
var Cg = new Map([["&&", x.And], [">", x.Bigger], [">=", x.BiggerEquals], ["|", x.BitwiseOr], ["&", x.BitwiseAnd], ["/", x.Divide], ["=", x.Assign], ["==", x.Equals], ["===", x.Identical], ["<", x.Lower], ["<=", x.LowerEquals], ["-", x.Minus], ["%", x.Modulo], ["**", x.Exponentiation], ["*", x.Multiply], ["!=", x.NotEquals], ["!==", x.NotIdentical], ["??", x.NullishCoalesce], ["||", x.Or], ["+", x.Plus], ["in", x.In], ["instanceof", x.InstanceOf], ["+=", x.AdditionAssignment], ["-=", x.SubtractionAssignment], ["*=", x.MultiplicationAssignment], ["/=", x.DivisionAssignment], ["%=", x.RemainderAssignment], ["**=", x.ExponentiationAssignment], ["&&=", x.AndAssignment], ["||=", x.OrAssignment], ["??=", x.NullishCoalesceAssignment]]);
function Eh(n) { let e = new Map([["svg", oe.SVG], ["math", oe.Math]]); return n === null ? oe.HTML : e.get(n) ?? oe.HTML; }
function bg(n) { let e = new Map([["svg", oe.SVG], ["math", oe.Math]]); for (let [t, s] of e.entries())
    if (s === n)
        return t; return null; }
function Ag(n, e) { return e === oe.HTML ? n : `:${bg(e)}:${n}`; }
function Ls(n) { return Array.isArray(n) ? X(n.map(Ls)) : g(n); }
function kg(n) { let e = new Map; for (let t of n.units)
    for (let s of t.create)
        if (s.kind === u.ExtractedAttribute) {
            let r = e.get(s.target) || new fc;
            e.set(s.target, r), r.add(s.bindingKind, s.name, s.expression, s.namespace, s.trustedValueFn), S.remove(s);
        } if (n instanceof ri)
    for (let t of n.units)
        for (let s of t.create)
            if (s.kind == u.Projection) {
                let r = e.get(s.xref);
                if (r !== void 0) {
                    let i = dc(r);
                    i.entries.length > 0 && (s.attributes = n.pool.getConstLiteral(i, !0));
                }
            }
            else
                dn(s) && (s.attributes = fu(n, e, s.xref), s.kind === u.RepeaterCreate && s.emptyView !== null && (s.emptyAttributes = fu(n, e, s.emptyView)));
else if (n instanceof Lo)
    for (let [t, s] of e.entries()) {
        if (t !== n.root.xref)
            throw new Error("An attribute would be const collected into the host binding's template function, but is not associated with the root xref.");
        let r = dc(s);
        r.entries.length > 0 && (n.root.attributes = r);
    } }
function fu(n, e, t) { let s = e.get(t); if (s !== void 0) {
    let r = dc(s);
    if (r.entries.length > 0)
        return n.addConst(r);
} return null; }
var ns = Object.freeze([]), fc = class {
    known = new Map;
    byKind = new Map;
    propertyBindings = null;
    projectAs = null;
    get attributes() { return this.byKind.get(_.Attribute) ?? ns; }
    get classes() { return this.byKind.get(_.ClassName) ?? ns; }
    get styles() { return this.byKind.get(_.StyleProperty) ?? ns; }
    get bindings() { return this.propertyBindings ?? ns; }
    get template() { return this.byKind.get(_.Template) ?? ns; }
    get i18n() { return this.byKind.get(_.I18n) ?? ns; }
    isKnown(e, t) { let s = this.known.get(e) ?? new Set; return this.known.set(e, s), s.has(t) ? !0 : (s.add(t), !1); }
    add(e, t, s, r, i) { if (!(e === _.Attribute || e === _.ClassName || e === _.StyleProperty) && this.isKnown(e, t))
        return; if (t === "ngProjectAs") {
        if (s === null || !(s instanceof Ae) || s.value == null || typeof s.value?.toString() != "string")
            throw Error("ngProjectAs must have a string literal value");
        this.projectAs = s.value.toString();
    } let a = this.arrayFor(e); if (a.push(...Tg(r, t)), e === _.Attribute || e === _.StyleProperty) {
        if (s === null)
            throw Error("Attribute, i18n attribute, & style element attributes must have a value");
        i !== null && uh(s) ? a.push(Hf(i, new vr([new Gi(s.value)], []), void 0, s.sourceSpan)) : a.push(s);
    } }
    arrayFor(e) { return e === _.Property || e === _.TwoWayProperty ? (this.propertyBindings ??= [], this.propertyBindings) : (this.byKind.has(e) || this.byKind.set(e, []), this.byKind.get(e)); }
};
function Tg(n, e) { let t = g(e); return n ? [g(0), g(n), t] : [t]; }
function dc({ attributes: n, bindings: e, classes: t, i18n: s, projectAs: r, styles: i, template: o }) { let a = [...n]; if (r !== null) {
    let c = rl(r)[0];
    a.push(g(5), Ls(c));
} return t.length > 0 && a.push(g(1), ...t), i.length > 0 && a.push(g(2), ...i), e.length > 0 && a.push(g(3), ...e), o.length > 0 && a.push(g(4), ...o), s.length > 0 && a.push(g(6), ...s), X(a); }
var _g = new Map([["formField", new Set([u.Property])], ["formControl", new Set([u.Property])], ["formControlName", new Set([u.Property, u.Attribute])], ["ngModel", new Set([u.Attribute, u.Property, u.TwoWayProperty])]]);
function Ig(n) { for (let e of n.units)
    Ng(e); }
function Ng(n) { for (let e of n.update) {
    if (e.kind !== u.Property && e.kind !== u.TwoWayProperty && e.kind !== u.Attribute)
        continue;
    let t = _g.get(e.name);
    t !== void 0 && t.has(e.kind) && Bg(n, e);
} }
var Dg = new Set([u.Container, u.ContainerStart, u.ContainerEnd, u.Element, u.ElementStart, u.ElementEnd, u.Template]);
function Pg(n) { return Dg.has(n.kind); }
function Lg(n, e) { let t = null; for (let s of n.create)
    !Pg(s) || s.xref !== e || (t = s); return t; }
function Bg(n, e) { let t = Lg(n, e.target); if (t === null)
    return; let s = ag(e.sourceSpan); S.insertAfter(s, t), S.insertAfter(Om(e.target, e.sourceSpan), e); }
function $g(n, e) { let t = n.get(e); if (t === void 0)
    throw new Error("All attributes should have an element-like target."); return t; }
function Mg(n) { let e = new Map; for (let t of n.units)
    for (let s of t.create)
        dn(s) && e.set(s.xref, s); for (let t of n.units)
    for (let s of t.ops())
        if (s.kind === u.AnimationBinding) {
            let r = Rg(s);
            n.kind === C.Host ? t.create.push(r) : S.insertAfter(r, $g(e, s.target)), S.remove(s);
        } }
function Rg(n) { if (n.animationBindingKind === 0)
    return Gm(n.name, n.target, n.name === "animate.enter" ? "enter" : "leave", n.expression, n.securityContext, n.sourceSpan); {
    let e = n.expression;
    return Xm(n.name, n.target, n.name === "animate.enter" ? "enter" : "leave", [rt(new fe(e, e.sourceSpan))], n.securityContext, n.sourceSpan);
} }
function Fg(n) { let e = new Map; for (let t of n.units) {
    for (let s of t.create)
        s.kind === u.I18nAttributes && e.set(s.target, s);
    for (let s of t.update)
        switch (s.kind) {
            case u.Property:
            case u.Attribute:
                if (s.i18nContext === null || !(s.expression instanceof ne))
                    continue;
                let r = e.get(s.target);
                if (r === void 0)
                    throw new Error("AssertionError: An i18n attribute binding instruction requires the owning element to have an I18nAttributes create instruction");
                if (r.target !== s.target)
                    throw new Error("AssertionError: Expected i18nAttributes target element to match binding target element");
                let i = [];
                for (let o = 0; o < s.expression.expressions.length; o++) {
                    let a = s.expression.expressions[o];
                    if (s.expression.i18nPlaceholders.length !== s.expression.expressions.length)
                        throw new Error(`AssertionError: An i18n attribute binding instruction requires the same number of expressions and placeholders, but found ${s.expression.i18nPlaceholders.length} placeholders and ${s.expression.expressions.length} expressions`);
                    i.push(lh(s.i18nContext, r.target, r.xref, r.handle, a, null, s.expression.i18nPlaceholders[o], Qr.Creation, Fs.I18nAttribute, s.name, s.sourceSpan));
                }
                S.replaceWithMany(s, i);
                break;
        }
} }
function Og(n) { let e = new Map; for (let r of n.units)
    for (let i of r.ops())
        switch (i.kind) {
            case u.Binding:
            case u.Property:
            case u.Attribute:
            case u.ExtractedAttribute:
                if (i.i18nMessage === null)
                    continue;
                if (!e.has(i.i18nMessage)) {
                    let o = ha(Tn.Attr, n.allocateXrefId(), null, i.i18nMessage, null);
                    r.create.push(o), e.set(i.i18nMessage, o.xref);
                }
                i.i18nContext = e.get(i.i18nMessage);
                break;
        } let t = new Map; for (let r of n.units)
    for (let i of r.create)
        switch (i.kind) {
            case u.I18nStart:
                if (i.xref === i.root) {
                    let o = ha(Tn.RootI18n, n.allocateXrefId(), i.xref, i.message, null);
                    r.create.push(o), i.context = o.xref, t.set(i.xref, o);
                }
                break;
        } for (let r of n.units)
    for (let i of r.create)
        if (i.kind === u.I18nStart && i.xref !== i.root) {
            let o = t.get(i.root);
            if (o === void 0)
                throw Error("AssertionError: Root i18n block i18n context should have been created.");
            i.context = o.xref, t.set(i.xref, o);
        } let s = null; for (let r of n.units)
    for (let i of r.create)
        switch (i.kind) {
            case u.I18nStart:
                s = i;
                break;
            case u.I18nEnd:
                s = null;
                break;
            case u.IcuStart:
                if (s === null)
                    throw Error("AssertionError: Unexpected ICU outside of an i18n block.");
                if (i.message.id !== s.message.id) {
                    let o = ha(Tn.Icu, n.allocateXrefId(), s.root, i.message, null);
                    r.create.push(o), i.context = o.xref;
                }
                else
                    i.context = s.context, t.get(s.xref).contextKind = Tn.Icu;
                break;
        } }
function Vg(n) { let e = new Map; for (let t of n.units)
    for (let s of t.update.reversed())
        if (s.kind === u.Binding && s.isTextAttribute) {
            let r = e.get(s.target) || new Set;
            r.has(s.name) && (s.name === "style" || s.name === "class") && S.remove(s), r.add(s.name), e.set(s.target, r);
        } }
function qg(n) { for (let e of n.units)
    for (let t of e.create)
        t.kind === u.Defer && (t.placeholderMinimumTime !== null && (t.placeholderConfig = new si(Ls([t.placeholderMinimumTime]))), (t.loadingMinimumTime !== null || t.loadingAfterTime !== null) && (t.loadingConfig = new si(Ls([t.loadingMinimumTime, t.loadingAfterTime])))); }
function Hg(n) { for (let e of n.units)
    for (let t of e.create)
        if (t.kind === u.Defer && t.flags !== null && (t.flags & 1) !== 0) {
            S.insertBefore(Jm(t.sourceSpan), t);
            break;
        } }
function Ug(n) { let e = new Map; function t(r) { if (e.has(r.xref))
    return e.get(r.xref); let i = new Wg; for (let o of r.create)
    if (!(!dn(o) || o.localRefs === null)) {
        if (!Array.isArray(o.localRefs))
            throw new Error("LocalRefs were already processed, but were needed to resolve defer targets.");
        for (let a of o.localRefs)
            a.target === "" && i.targets.set(a.name, { xref: o.xref, slot: o.handle });
    } return e.set(r.xref, i), i; } function s(r, i, o) { let a = i.trigger.kind; switch (a) {
    case G.Idle:
    case G.Never:
    case G.Immediate:
    case G.Timer: return;
    case G.Hover:
    case G.Interaction:
    case G.Viewport:
        if (i.trigger.targetName === null) {
            if (o === null)
                throw new Error("defer on trigger with no target name must have a placeholder block");
            let p = n.views.get(o);
            if (p == null)
                throw new Error("AssertionError: could not find placeholder view for defer on trigger");
            for (let h of p.create)
                if (Os(h) && (dn(h) || h.kind === u.Projection)) {
                    i.trigger.targetXref = h.xref, i.trigger.targetView = o, i.trigger.targetSlotViewSteps = -1, i.trigger.targetSlot = h.handle;
                    return;
                }
            return;
        }
        let c = o !== null ? n.views.get(o) : r, l = o !== null ? -1 : 0;
        for (; c !== null;) {
            let p = t(c);
            if (p.targets.has(i.trigger.targetName)) {
                let { xref: h, slot: d } = p.targets.get(i.trigger.targetName);
                i.trigger.targetXref = h, i.trigger.targetView = c.xref, i.trigger.targetSlotViewSteps = l, i.trigger.targetSlot = d;
                return;
            }
            c = c.parent !== null ? n.views.get(c.parent) : null, l++;
        }
        break;
    default: {
        let p = a;
        throw new Error(`Trigger kind ${p} not handled`);
    }
} } for (let r of n.units) {
    let i = new Map;
    for (let o of r.create)
        switch (o.kind) {
            case u.Defer:
                i.set(o.xref, o);
                break;
            case u.DeferOn:
                let a = i.get(o.defer);
                s(r, o, o.modifier === "hydrate" ? a.mainView : a.placeholderView);
                break;
        }
} }
var Wg = class {
    targets = new Map;
}, jg = new Map([[u.ElementEnd, [u.ElementStart, u.Element]], [u.ContainerEnd, [u.ContainerStart, u.Container]], [u.I18nEnd, [u.I18nStart, u.I18n]]]), zg = new Set([u.Pipe]);
function Gg(n) { for (let e of n.units)
    for (let t of e.create) {
        let s = jg.get(t.kind);
        if (s === void 0)
            continue;
        let [r, i] = s, o = t.prev;
        for (; o !== null && zg.has(o.kind);)
            o = o.prev;
        o !== null && o.kind === r && (o.kind = i, S.remove(t));
    } }
function Xg(n) { for (let e of n.units)
    for (let t of e.ops())
        te(t, (s, r) => ev(s, { job: n }, r), M.None), te(t, tv, M.None); }
function Oe(n) { return n instanceof On ? Oe(n.expr) : n instanceof H ? Oe(n.lhs) || Oe(n.rhs) : n instanceof Nt ? n.falseCase && Oe(n.falseCase) ? !0 : Oe(n.condition) || Oe(n.trueCase) : n instanceof wr ? Oe(n.condition) : n instanceof $t ? Oe(n.expr) : n instanceof We ? Oe(n.receiver) : n instanceof gt ? Oe(n.receiver) || Oe(n.index) : n instanceof mt || n instanceof ti ? Oe(n.expr) : n instanceof pe || n instanceof Dt || n instanceof vt || n instanceof Zn; }
function Qg(n) { let e = new Set; return k(n, t => (t instanceof $t && e.add(t.xref), t), M.None), e; }
function Yg(n, e, t) { return k(n, s => { if (s instanceof $t && e.has(s.xref)) {
    let r = new fn(s.xref);
    return new $t(r, r.xref);
} return s; }, M.None), n; }
function ss(n, e, t) { let s; if (Oe(n)) {
    let r = t.job.allocateXrefId();
    s = [new $t(n, r), new fn(r)];
}
else
    s = [n, n.clone()], Yg(s[1], Qg(s[0])); return new Ps(s[0], e(s[1])); }
function Zg(n) { return n instanceof Pn || n instanceof Ln || n instanceof pe && n.isOptional; }
function Jg(n) { return n instanceof We || n instanceof gt || n instanceof pe && !n.isOptional; }
function xh(n) { return Zg(n) || Jg(n); }
function Kg(n) { if (xh(n) && n.receiver instanceof Ps) {
    let e = n.receiver;
    for (; e.expr instanceof Ps;)
        e = e.expr;
    return e;
} return null; }
function ev(n, e, t) { if (n instanceof ti)
    return n.expr; if (!(e.job.legacyOptionalChaining || (t & M.InSafeNavigationMigration) !== 0))
    return n instanceof Pn ? new We(n.receiver, n.name, null, n.sourceSpan, [], !0) : n instanceof Ln ? new gt(n.receiver, n.index, null, n.sourceSpan, [], !0) : n; if (!xh(n))
    return n; let r = Kg(n); if (r) {
    if (n instanceof pe && !n.isOptional)
        return r.expr = r.expr.callFn(n.args), n.receiver;
    if (n instanceof We)
        return r.expr = r.expr.prop(n.name), n.receiver;
    if (n instanceof gt)
        return r.expr = r.expr.key(n.index), n.receiver;
    if (n instanceof pe && n.isOptional)
        return r.expr = ss(r.expr, i => i.callFn(n.args), e), n.receiver;
    if (n instanceof Pn)
        return r.expr = ss(r.expr, i => i.prop(n.name), e), n.receiver;
    if (n instanceof Ln)
        return r.expr = ss(r.expr, i => i.key(n.index), e), n.receiver;
}
else {
    if (n instanceof pe && n.isOptional)
        return ss(n.receiver, i => i.callFn(n.args), e);
    if (n instanceof Pn)
        return ss(n.receiver, i => i.prop(n.name), e);
    if (n instanceof Ln)
        return ss(n.receiver, i => i.key(n.index), e);
} return n; }
function tv(n) { return n instanceof Ps ? new mt(new Nt(new H(x.Equals, n.guard, Cs), Cs, n.expr)) : n; }
var du = "\uFFFD", nv = "#", sv = "*", rv = "/", iv = ":", ov = "[", av = "]", cv = "|";
function lv(n) { let e = new Map, t = new Map, s = new Map; for (let i of n.units)
    for (let o of i.create)
        switch (o.kind) {
            case u.I18nContext:
                let a = uv(n, o);
                i.create.push(a), e.set(o.xref, a), s.set(o.xref, o);
                break;
            case u.I18nStart:
                t.set(o.xref, o);
                break;
        } let r = null; for (let i of n.units)
    for (let o of i.create)
        switch (o.kind) {
            case u.IcuStart:
                r = o, S.remove(o);
                let a = s.get(o.context);
                if (a.contextKind !== Tn.Icu)
                    continue;
                let c = t.get(a.i18nBlock);
                if (c.context === a.xref)
                    continue;
                let l = t.get(c.root), p = e.get(l.context);
                if (p === void 0)
                    throw Error("AssertionError: ICU sub-message should belong to a root message.");
                let h = e.get(a.xref);
                h.messagePlaceholder = o.messagePlaceholder, p.subMessages.push(h.xref);
                break;
            case u.IcuEnd:
                r = null, S.remove(o);
                break;
            case u.IcuPlaceholder:
                if (r === null || r.context == null)
                    throw Error("AssertionError: Unexpected ICU placeholder outside of i18n context");
                e.get(r.context).postprocessingParams.set(o.name, g(pv(o))), S.remove(o);
                break;
        } }
function uv(n, e, t) { let s = mu(e.params), r = mu(e.postprocessingParams), i = [...e.params.values()].some(o => o.length > 1); return ng(n.allocateXrefId(), e.xref, e.i18nBlock, e.message, null, s, r, i); }
function pv(n) { if (n.strings.length !== n.expressionPlaceholders.length + 1)
    throw Error(`AssertionError: Invalid ICU placeholder with ${n.strings.length} strings and ${n.expressionPlaceholders.length} expressions`); let e = n.expressionPlaceholders.map(ds); return n.strings.flatMap((t, s) => [t, e[s] || ""]).join(""); }
function mu(n) { let e = new Map; for (let [t, s] of n) {
    let r = hv(s);
    r !== null && e.set(t, g(r));
} return e; }
function hv(n) { if (n.length === 0)
    return null; let e = n.map(t => ds(t)); return e.length === 1 ? e[0] : `${ov}${e.join(cv)}${av}`; }
function ds(n) { if (n.flags & Y.ElementTag && n.flags & Y.TemplateTag) {
    if (typeof n.value != "object")
        throw Error("AssertionError: Expected i18n param value to have an element and template slot");
    let r = ds(se(E({}, n), { value: n.value.element, flags: n.flags & ~Y.TemplateTag })), i = ds(se(E({}, n), { value: n.value.template, flags: n.flags & ~Y.ElementTag }));
    return n.flags & Y.OpenTag && n.flags & Y.CloseTag ? `${i}${r}${i}` : n.flags & Y.CloseTag ? `${r}${i}` : `${i}${r}`;
} if (n.flags & Y.OpenTag && n.flags & Y.CloseTag)
    return `${ds(se(E({}, n), { flags: n.flags & ~Y.CloseTag }))}${ds(se(E({}, n), { flags: n.flags & ~Y.OpenTag }))}`; if (n.flags === Y.None)
    return `${n.value}`; let e = "", t = ""; n.flags & Y.ElementTag ? e = nv : n.flags & Y.TemplateTag && (e = sv), e !== "" && (t = n.flags & Y.CloseTag ? rv : ""); let s = n.subTemplateIndex === null ? "" : `${iv}${n.subTemplateIndex}`; return `${du}${t}${e}${n.value}${s}${du}`; }
function fv(n) { for (let e of n.units) {
    let t = new Map;
    for (let r of e.create) {
        if (Os(r)) {
            if (r.handle.slot === null)
                throw new Error("AssertionError: expected slots to have been allocated before generating advance() calls");
        }
        else
            continue;
        t.set(r.xref, r.handle.slot);
    }
    let s = 0;
    for (let r of e.update) {
        let i = null;
        if (Yr(r) ? i = r : ae(r, a => { i === null && Yr(a) && (i = a); }), i === null)
            continue;
        if (!t.has(i.target))
            throw new Error(`AssertionError: reference to unknown slot for target ${i.target}`);
        let o = t.get(i.target);
        if (s !== o) {
            let a = o - s;
            if (a < 0)
                throw new Error("AssertionError: slot counter should never need to move backwards");
            S.insertBefore(Bm(a, i.sourceSpan), r), s = o;
        }
    }
} }
function dv(n) { for (let e of n.units) {
    for (let t of e.create)
        t.kind !== u.Animation && t.kind !== u.AnimationListener && t.kind !== u.Listener && t.kind !== u.TwoWayListener && gu(e, t);
    for (let t of e.update)
        gu(e, t);
} }
function gu(n, e) { te(e, (t, s) => { if (!(t instanceof rn) || s & M.InChildOperation)
    return t; if (Array.isArray(t.body))
    throw new Error("AssertionError: unexpected multi-line arrow function"); let r = new pc(t.params, t.body); return n.functions.add(r), r; }, M.None); }
function mv(n) { for (let e of n.units)
    for (let t of e.update) {
        if (t.kind !== u.StoreLet)
            continue;
        let s = { kind: Ee.Identifier, name: null, identifier: t.declaredName, local: !0 };
        S.replace(t, tn(n.allocateXrefId(), s, new Zr(t.target, t.value, t.sourceSpan), ht.None));
    } }
function gv(n) { let t = [], s = 0; for (let r of n.units)
    for (let i of r.create)
        i.kind === u.Projection && (t.push(i.selector), i.projectionSlotIndex = s++); if (t.length > 0) {
    let r = null;
    if (t.length > 1 || t[0] !== "*") {
        let i = t.map(o => o === "*" ? o : rl(o));
        r = n.pool.getConstLiteral(Ls(i), !0);
    }
    n.contentSelectors = n.pool.getConstLiteral(Ls(t), !0), n.root.create.prepend([Zm(r)]);
} }
function vv(n) { Ks(n.root, null); }
function Ks(n, e) { let t = vu(n, e); for (let s of n.create)
    switch (s.kind) {
        case u.ConditionalCreate:
        case u.ConditionalBranchCreate:
        case u.Template:
            Ks(n.job.views.get(s.xref), t);
            break;
        case u.Projection:
            s.fallbackView !== null && Ks(n.job.views.get(s.fallbackView), t);
            break;
        case u.RepeaterCreate:
            Ks(n.job.views.get(s.xref), t), s.emptyView && Ks(n.job.views.get(s.emptyView), t), s.trackByOps !== null && s.trackByOps.prepend(ls(n, t, !1));
            break;
        case u.Animation:
        case u.AnimationListener:
        case u.Listener:
        case u.TwoWayListener:
            s.handlerOps.prepend(ls(n, t, !0));
            break;
    } n.create.prepend(ls(n, t, !1)), n.update.prepend(ls(n, t, !1)); for (let s of n.functions)
    s.ops.prepend(ls(n, vu(n, e), !0)); }
function vu(n, e) { let t = { view: n.xref, viewContextVariable: { kind: Ee.Context, name: null, view: n.xref }, contextVariables: new Map, aliases: n.aliases, references: [], letDeclarations: [], parent: e }; for (let s of n.contextVariables.keys())
    t.contextVariables.set(s, { kind: Ee.Identifier, name: null, identifier: s, local: !1 }); for (let s of n.create)
    switch (s.kind) {
        case u.ElementStart:
        case u.ConditionalCreate:
        case u.ConditionalBranchCreate:
        case u.Template:
            if (!Array.isArray(s.localRefs))
                throw new Error("AssertionError: expected localRefs to be an array");
            for (let r = 0; r < s.localRefs.length; r++)
                t.references.push({ name: s.localRefs[r].name, targetId: s.xref, targetSlot: s.handle, offset: r, variable: { kind: Ee.Identifier, name: null, identifier: s.localRefs[r].name, local: !1 } });
            break;
        case u.DeclareLet:
            t.letDeclarations.push({ targetId: s.xref, targetSlot: s.handle, variable: { kind: Ee.Identifier, name: null, identifier: s.declaredName, local: !1 } });
            break;
    } return t; }
function ls(n, e, t) { let s = []; e.view !== n.xref && s.push(tn(n.job.allocateXrefId(), e.viewContextVariable, new Ao, ht.None)); let r = n.job.views.get(e.view); for (let [i, o] of r.contextVariables) {
    let a = new pn(e.view), c;
    o === vh ? c = a : typeof o == "number" ? c = new gt(a, g(o)) : c = new We(a, o), s.push(tn(n.job.allocateXrefId(), e.contextVariables.get(i), c, ht.None));
} for (let i of r.aliases)
    s.push(tn(n.job.allocateXrefId(), i, i.expression.clone(), ht.AlwaysInline)); for (let i of e.references)
    s.push(tn(n.job.allocateXrefId(), i.variable, new bo(i.targetId, i.targetSlot, i.offset), ht.None)); if (e.view !== n.xref || t)
    for (let i of e.letDeclarations)
        s.push(tn(n.job.allocateXrefId(), i.variable, new Jr(i.targetId, i.targetSlot), ht.None)); return e.parent !== null && s.push(...ls(n, e.parent, !1)), s; }
function wv(n) { for (let e of n.units)
    for (let t of e.ops())
        te(t, s => s instanceof si ? g(n.addConst(s.expr)) : s, M.None); }
var wu = "style.", Su = "class.", Sv = "style!", Eu = "class!", xu = "!important";
function Ev(n) { for (let e of n.root.update)
    if (e.kind === u.Binding && e.bindingKind === _.Property)
        if (e.name.endsWith(xu) && (e.name = e.name.substring(0, e.name.length - xu.length)), e.name.startsWith(wu)) {
            e.bindingKind = _.StyleProperty, e.name = e.name.substring(wu.length), xv(e.name) ? e.name = al(e.name) : e.name = yv(e.name);
            let { property: t, suffix: s } = fa(e.name);
            e.name = t, e.unit = s;
        }
        else
            e.name.startsWith(Sv) ? (e.bindingKind = _.StyleProperty, e.name = "style") : e.name.startsWith(Su) ? (e.bindingKind = _.ClassName, e.name = fa(e.name.substring(Su.length)).property) : e.name.startsWith(Eu) && (e.bindingKind = _.ClassName, e.name = fa(e.name.substring(Eu.length)).property); }
function xv(n) { return n.startsWith("--"); }
function yv(n) { return n.replace(/[a-z][A-Z]/g, e => e.charAt(0) + "-" + e.charAt(1)).toLowerCase(); }
function fa(n) { let e = n.indexOf("!important"); e !== -1 && (n = e > 0 ? n.substring(0, e) : ""); let t = null, s = n, r = n.lastIndexOf("."); return r > 0 && (t = n.slice(r + 1), s = n.substring(0, r)), { property: s, suffix: t }; }
function mc(n, e = !1) { return nt(Object.keys(n).map(t => ({ key: t, quoted: e, value: n[t] }))); }
var gc = class {
    visitText(e) { return e.value; }
    visitContainer(e) { return e.children.map(t => t.visit(this)).join(""); }
    visitIcu(e) { let t = Object.keys(e.cases).map(r => `${r} {${e.cases[r].visit(this)}}`); return `{${e.expressionPlaceholder}, ${e.type}, ${t.join(" ")}}`; }
    visitTagPlaceholder(e) { return e.isVoid ? this.formatPh(e.startName) : `${this.formatPh(e.startName)}${e.children.map(t => t.visit(this)).join("")}${this.formatPh(e.closeName)}`; }
    visitPlaceholder(e) { return this.formatPh(e.name); }
    visitBlockPlaceholder(e) { return `${this.formatPh(e.startName)}${e.children.map(t => t.visit(this)).join("")}${this.formatPh(e.closeName)}`; }
    visitIcuPlaceholder(e, t) { return this.formatPh(e.name); }
    formatPh(e) { return `{${gi(e, !1)}}`; }
}, Cv = new gc;
function yh(n) { return n.visit(Cv); }
var zt = class {
    sourceSpan;
    i18n;
    constructor(e, t) { this.sourceSpan = e, this.i18n = t; }
}, Jn = class extends zt {
    value;
    tokens;
    constructor(e, t, s, r) { super(t, r), this.value = e, this.tokens = s; }
    visit(e, t) { return e.visitText(this, t); }
}, Bn = class extends zt {
    switchValue;
    type;
    cases;
    switchValueSourceSpan;
    constructor(e, t, s, r, i, o) { super(r, o), this.switchValue = e, this.type = t, this.cases = s, this.switchValueSourceSpan = i; }
    visit(e, t) { return e.visitExpansion(this, t); }
}, Bo = class {
    value;
    expression;
    sourceSpan;
    valueSourceSpan;
    expSourceSpan;
    constructor(e, t, s, r, i) { this.value = e, this.expression = t, this.sourceSpan = s, this.valueSourceSpan = r, this.expSourceSpan = i; }
    visit(e, t) { return e.visitExpansionCase(this, t); }
}, vc = class extends zt {
    name;
    value;
    keySpan;
    valueSpan;
    valueTokens;
    constructor(e, t, s, r, i, o, a) { super(s, a), this.name = e, this.value = t, this.keySpan = r, this.valueSpan = i, this.valueTokens = o; }
    visit(e, t) { return e.visitAttribute(this, t); }
}, wc = class {
    value;
    type;
    sourceSpan;
    constructor(e, t, s) { this.value = e, this.type = t, this.sourceSpan = s; }
    visit(e, t) { return e.visitStartTagComment ? e.visitStartTagComment(this, t) : void 0; }
}, ct = class extends zt {
    name;
    attrs;
    directives;
    children;
    isSelfClosing;
    startSourceSpan;
    endSourceSpan;
    isVoid;
    comments;
    constructor(e, t, s, r, i, o, a, c = null, l, p, h = []) { super(o, p), this.name = e, this.attrs = t, this.directives = s, this.children = r, this.isSelfClosing = i, this.startSourceSpan = a, this.endSourceSpan = c, this.isVoid = l, this.comments = h; }
    visit(e, t) { return e.visitElement(this, t); }
}, ii = class {
    value;
    sourceSpan;
    constructor(e, t) { this.value = e, this.sourceSpan = t; }
    visit(e, t) { return e.visitComment(this, t); }
}, ut = class extends zt {
    name;
    parameters;
    children;
    nameSpan;
    startSourceSpan;
    endSourceSpan;
    constructor(e, t, s, r, i, o, a = null, c) { super(r, c), this.name = e, this.parameters = t, this.children = s, this.nameSpan = i, this.startSourceSpan = o, this.endSourceSpan = a; }
    visit(e, t) { return e.visitBlock(this, t); }
}, Pe = class extends zt {
    componentName;
    tagName;
    fullName;
    attrs;
    directives;
    children;
    isSelfClosing;
    startSourceSpan;
    endSourceSpan;
    comments;
    constructor(e, t, s, r, i, o, a, c, l, p = null, h, d = []) { super(c, h), this.componentName = e, this.tagName = t, this.fullName = s, this.attrs = r, this.directives = i, this.children = o, this.isSelfClosing = a, this.startSourceSpan = l, this.endSourceSpan = p, this.comments = d; }
    visit(e, t) { return e.visitComponent(this, t); }
}, Sc = class {
    name;
    attrs;
    sourceSpan;
    startSourceSpan;
    endSourceSpan;
    constructor(e, t, s, r, i = null) { this.name = e, this.attrs = t, this.sourceSpan = s, this.startSourceSpan = r, this.endSourceSpan = i; }
    visit(e, t) { return e.visitDirective(this, t); }
}, $o = class {
    expression;
    sourceSpan;
    constructor(e, t) { this.expression = e, this.sourceSpan = t; }
    visit(e, t) { return e.visitBlockParameter(this, t); }
}, Mo = class {
    name;
    value;
    sourceSpan;
    nameSpan;
    valueSpan;
    constructor(e, t, s, r, i) { this.name = e, this.value = t, this.sourceSpan = s, this.nameSpan = r, this.valueSpan = i; }
    visit(e, t) { return e.visitLetDeclaration(this, t); }
};
function Z(n, e, t = null) { let s = [], r = n.visit ? i => n.visit(i, t) || i.visit(n, t) : i => i.visit(n, t); return e.forEach(i => { let o = r(i); o && s.push(o); }), s; }
var oi = { AElig: "\xC6", AMP: "&", amp: "&", Aacute: "\xC1", Abreve: "\u0102", Acirc: "\xC2", Acy: "\u0410", Afr: "\u{1D504}", Agrave: "\xC0", Alpha: "\u0391", Amacr: "\u0100", And: "\u2A53", Aogon: "\u0104", Aopf: "\u{1D538}", ApplyFunction: "\u2061", af: "\u2061", Aring: "\xC5", angst: "\xC5", Ascr: "\u{1D49C}", Assign: "\u2254", colone: "\u2254", coloneq: "\u2254", Atilde: "\xC3", Auml: "\xC4", Backslash: "\u2216", setminus: "\u2216", setmn: "\u2216", smallsetminus: "\u2216", ssetmn: "\u2216", Barv: "\u2AE7", Barwed: "\u2306", doublebarwedge: "\u2306", Bcy: "\u0411", Because: "\u2235", becaus: "\u2235", because: "\u2235", Bernoullis: "\u212C", Bscr: "\u212C", bernou: "\u212C", Beta: "\u0392", Bfr: "\u{1D505}", Bopf: "\u{1D539}", Breve: "\u02D8", breve: "\u02D8", Bumpeq: "\u224E", HumpDownHump: "\u224E", bump: "\u224E", CHcy: "\u0427", COPY: "\xA9", copy: "\xA9", Cacute: "\u0106", Cap: "\u22D2", CapitalDifferentialD: "\u2145", DD: "\u2145", Cayleys: "\u212D", Cfr: "\u212D", Ccaron: "\u010C", Ccedil: "\xC7", Ccirc: "\u0108", Cconint: "\u2230", Cdot: "\u010A", Cedilla: "\xB8", cedil: "\xB8", CenterDot: "\xB7", centerdot: "\xB7", middot: "\xB7", Chi: "\u03A7", CircleDot: "\u2299", odot: "\u2299", CircleMinus: "\u2296", ominus: "\u2296", CirclePlus: "\u2295", oplus: "\u2295", CircleTimes: "\u2297", otimes: "\u2297", ClockwiseContourIntegral: "\u2232", cwconint: "\u2232", CloseCurlyDoubleQuote: "\u201D", rdquo: "\u201D", rdquor: "\u201D", CloseCurlyQuote: "\u2019", rsquo: "\u2019", rsquor: "\u2019", Colon: "\u2237", Proportion: "\u2237", Colone: "\u2A74", Congruent: "\u2261", equiv: "\u2261", Conint: "\u222F", DoubleContourIntegral: "\u222F", ContourIntegral: "\u222E", conint: "\u222E", oint: "\u222E", Copf: "\u2102", complexes: "\u2102", Coproduct: "\u2210", coprod: "\u2210", CounterClockwiseContourIntegral: "\u2233", awconint: "\u2233", Cross: "\u2A2F", Cscr: "\u{1D49E}", Cup: "\u22D3", CupCap: "\u224D", asympeq: "\u224D", DDotrahd: "\u2911", DJcy: "\u0402", DScy: "\u0405", DZcy: "\u040F", Dagger: "\u2021", ddagger: "\u2021", Darr: "\u21A1", Dashv: "\u2AE4", DoubleLeftTee: "\u2AE4", Dcaron: "\u010E", Dcy: "\u0414", Del: "\u2207", nabla: "\u2207", Delta: "\u0394", Dfr: "\u{1D507}", DiacriticalAcute: "\xB4", acute: "\xB4", DiacriticalDot: "\u02D9", dot: "\u02D9", DiacriticalDoubleAcute: "\u02DD", dblac: "\u02DD", DiacriticalGrave: "`", grave: "`", DiacriticalTilde: "\u02DC", tilde: "\u02DC", Diamond: "\u22C4", diam: "\u22C4", diamond: "\u22C4", DifferentialD: "\u2146", dd: "\u2146", Dopf: "\u{1D53B}", Dot: "\xA8", DoubleDot: "\xA8", die: "\xA8", uml: "\xA8", DotDot: "\u20DC", DotEqual: "\u2250", doteq: "\u2250", esdot: "\u2250", DoubleDownArrow: "\u21D3", Downarrow: "\u21D3", dArr: "\u21D3", DoubleLeftArrow: "\u21D0", Leftarrow: "\u21D0", lArr: "\u21D0", DoubleLeftRightArrow: "\u21D4", Leftrightarrow: "\u21D4", hArr: "\u21D4", iff: "\u21D4", DoubleLongLeftArrow: "\u27F8", Longleftarrow: "\u27F8", xlArr: "\u27F8", DoubleLongLeftRightArrow: "\u27FA", Longleftrightarrow: "\u27FA", xhArr: "\u27FA", DoubleLongRightArrow: "\u27F9", Longrightarrow: "\u27F9", xrArr: "\u27F9", DoubleRightArrow: "\u21D2", Implies: "\u21D2", Rightarrow: "\u21D2", rArr: "\u21D2", DoubleRightTee: "\u22A8", vDash: "\u22A8", DoubleUpArrow: "\u21D1", Uparrow: "\u21D1", uArr: "\u21D1", DoubleUpDownArrow: "\u21D5", Updownarrow: "\u21D5", vArr: "\u21D5", DoubleVerticalBar: "\u2225", par: "\u2225", parallel: "\u2225", shortparallel: "\u2225", spar: "\u2225", DownArrow: "\u2193", ShortDownArrow: "\u2193", darr: "\u2193", downarrow: "\u2193", DownArrowBar: "\u2913", DownArrowUpArrow: "\u21F5", duarr: "\u21F5", DownBreve: "\u0311", DownLeftRightVector: "\u2950", DownLeftTeeVector: "\u295E", DownLeftVector: "\u21BD", leftharpoondown: "\u21BD", lhard: "\u21BD", DownLeftVectorBar: "\u2956", DownRightTeeVector: "\u295F", DownRightVector: "\u21C1", rhard: "\u21C1", rightharpoondown: "\u21C1", DownRightVectorBar: "\u2957", DownTee: "\u22A4", top: "\u22A4", DownTeeArrow: "\u21A7", mapstodown: "\u21A7", Dscr: "\u{1D49F}", Dstrok: "\u0110", ENG: "\u014A", ETH: "\xD0", Eacute: "\xC9", Ecaron: "\u011A", Ecirc: "\xCA", Ecy: "\u042D", Edot: "\u0116", Efr: "\u{1D508}", Egrave: "\xC8", Element: "\u2208", in: "\u2208", isin: "\u2208", isinv: "\u2208", Emacr: "\u0112", EmptySmallSquare: "\u25FB", EmptyVerySmallSquare: "\u25AB", Eogon: "\u0118", Eopf: "\u{1D53C}", Epsilon: "\u0395", Equal: "\u2A75", EqualTilde: "\u2242", eqsim: "\u2242", esim: "\u2242", Equilibrium: "\u21CC", rightleftharpoons: "\u21CC", rlhar: "\u21CC", Escr: "\u2130", expectation: "\u2130", Esim: "\u2A73", Eta: "\u0397", Euml: "\xCB", Exists: "\u2203", exist: "\u2203", ExponentialE: "\u2147", ee: "\u2147", exponentiale: "\u2147", Fcy: "\u0424", Ffr: "\u{1D509}", FilledSmallSquare: "\u25FC", FilledVerySmallSquare: "\u25AA", blacksquare: "\u25AA", squarf: "\u25AA", squf: "\u25AA", Fopf: "\u{1D53D}", ForAll: "\u2200", forall: "\u2200", Fouriertrf: "\u2131", Fscr: "\u2131", GJcy: "\u0403", GT: ">", gt: ">", Gamma: "\u0393", Gammad: "\u03DC", Gbreve: "\u011E", Gcedil: "\u0122", Gcirc: "\u011C", Gcy: "\u0413", Gdot: "\u0120", Gfr: "\u{1D50A}", Gg: "\u22D9", ggg: "\u22D9", Gopf: "\u{1D53E}", GreaterEqual: "\u2265", ge: "\u2265", geq: "\u2265", GreaterEqualLess: "\u22DB", gel: "\u22DB", gtreqless: "\u22DB", GreaterFullEqual: "\u2267", gE: "\u2267", geqq: "\u2267", GreaterGreater: "\u2AA2", GreaterLess: "\u2277", gl: "\u2277", gtrless: "\u2277", GreaterSlantEqual: "\u2A7E", geqslant: "\u2A7E", ges: "\u2A7E", GreaterTilde: "\u2273", gsim: "\u2273", gtrsim: "\u2273", Gscr: "\u{1D4A2}", Gt: "\u226B", NestedGreaterGreater: "\u226B", gg: "\u226B", HARDcy: "\u042A", Hacek: "\u02C7", caron: "\u02C7", Hat: "^", Hcirc: "\u0124", Hfr: "\u210C", Poincareplane: "\u210C", HilbertSpace: "\u210B", Hscr: "\u210B", hamilt: "\u210B", Hopf: "\u210D", quaternions: "\u210D", HorizontalLine: "\u2500", boxh: "\u2500", Hstrok: "\u0126", HumpEqual: "\u224F", bumpe: "\u224F", bumpeq: "\u224F", IEcy: "\u0415", IJlig: "\u0132", IOcy: "\u0401", Iacute: "\xCD", Icirc: "\xCE", Icy: "\u0418", Idot: "\u0130", Ifr: "\u2111", Im: "\u2111", image: "\u2111", imagpart: "\u2111", Igrave: "\xCC", Imacr: "\u012A", ImaginaryI: "\u2148", ii: "\u2148", Int: "\u222C", Integral: "\u222B", int: "\u222B", Intersection: "\u22C2", bigcap: "\u22C2", xcap: "\u22C2", InvisibleComma: "\u2063", ic: "\u2063", InvisibleTimes: "\u2062", it: "\u2062", Iogon: "\u012E", Iopf: "\u{1D540}", Iota: "\u0399", Iscr: "\u2110", imagline: "\u2110", Itilde: "\u0128", Iukcy: "\u0406", Iuml: "\xCF", Jcirc: "\u0134", Jcy: "\u0419", Jfr: "\u{1D50D}", Jopf: "\u{1D541}", Jscr: "\u{1D4A5}", Jsercy: "\u0408", Jukcy: "\u0404", KHcy: "\u0425", KJcy: "\u040C", Kappa: "\u039A", Kcedil: "\u0136", Kcy: "\u041A", Kfr: "\u{1D50E}", Kopf: "\u{1D542}", Kscr: "\u{1D4A6}", LJcy: "\u0409", LT: "<", lt: "<", Lacute: "\u0139", Lambda: "\u039B", Lang: "\u27EA", Laplacetrf: "\u2112", Lscr: "\u2112", lagran: "\u2112", Larr: "\u219E", twoheadleftarrow: "\u219E", Lcaron: "\u013D", Lcedil: "\u013B", Lcy: "\u041B", LeftAngleBracket: "\u27E8", lang: "\u27E8", langle: "\u27E8", LeftArrow: "\u2190", ShortLeftArrow: "\u2190", larr: "\u2190", leftarrow: "\u2190", slarr: "\u2190", LeftArrowBar: "\u21E4", larrb: "\u21E4", LeftArrowRightArrow: "\u21C6", leftrightarrows: "\u21C6", lrarr: "\u21C6", LeftCeiling: "\u2308", lceil: "\u2308", LeftDoubleBracket: "\u27E6", lobrk: "\u27E6", LeftDownTeeVector: "\u2961", LeftDownVector: "\u21C3", dharl: "\u21C3", downharpoonleft: "\u21C3", LeftDownVectorBar: "\u2959", LeftFloor: "\u230A", lfloor: "\u230A", LeftRightArrow: "\u2194", harr: "\u2194", leftrightarrow: "\u2194", LeftRightVector: "\u294E", LeftTee: "\u22A3", dashv: "\u22A3", LeftTeeArrow: "\u21A4", mapstoleft: "\u21A4", LeftTeeVector: "\u295A", LeftTriangle: "\u22B2", vartriangleleft: "\u22B2", vltri: "\u22B2", LeftTriangleBar: "\u29CF", LeftTriangleEqual: "\u22B4", ltrie: "\u22B4", trianglelefteq: "\u22B4", LeftUpDownVector: "\u2951", LeftUpTeeVector: "\u2960", LeftUpVector: "\u21BF", uharl: "\u21BF", upharpoonleft: "\u21BF", LeftUpVectorBar: "\u2958", LeftVector: "\u21BC", leftharpoonup: "\u21BC", lharu: "\u21BC", LeftVectorBar: "\u2952", LessEqualGreater: "\u22DA", leg: "\u22DA", lesseqgtr: "\u22DA", LessFullEqual: "\u2266", lE: "\u2266", leqq: "\u2266", LessGreater: "\u2276", lessgtr: "\u2276", lg: "\u2276", LessLess: "\u2AA1", LessSlantEqual: "\u2A7D", leqslant: "\u2A7D", les: "\u2A7D", LessTilde: "\u2272", lesssim: "\u2272", lsim: "\u2272", Lfr: "\u{1D50F}", Ll: "\u22D8", Lleftarrow: "\u21DA", lAarr: "\u21DA", Lmidot: "\u013F", LongLeftArrow: "\u27F5", longleftarrow: "\u27F5", xlarr: "\u27F5", LongLeftRightArrow: "\u27F7", longleftrightarrow: "\u27F7", xharr: "\u27F7", LongRightArrow: "\u27F6", longrightarrow: "\u27F6", xrarr: "\u27F6", Lopf: "\u{1D543}", LowerLeftArrow: "\u2199", swarr: "\u2199", swarrow: "\u2199", LowerRightArrow: "\u2198", searr: "\u2198", searrow: "\u2198", Lsh: "\u21B0", lsh: "\u21B0", Lstrok: "\u0141", Lt: "\u226A", NestedLessLess: "\u226A", ll: "\u226A", Map: "\u2905", Mcy: "\u041C", MediumSpace: "\u205F", Mellintrf: "\u2133", Mscr: "\u2133", phmmat: "\u2133", Mfr: "\u{1D510}", MinusPlus: "\u2213", mnplus: "\u2213", mp: "\u2213", Mopf: "\u{1D544}", Mu: "\u039C", NJcy: "\u040A", Nacute: "\u0143", Ncaron: "\u0147", Ncedil: "\u0145", Ncy: "\u041D", NegativeMediumSpace: "\u200B", NegativeThickSpace: "\u200B", NegativeThinSpace: "\u200B", NegativeVeryThinSpace: "\u200B", ZeroWidthSpace: "\u200B", NewLine: `
`, Nfr: "\u{1D511}", NoBreak: "\u2060", NonBreakingSpace: "\xA0", nbsp: "\xA0", Nopf: "\u2115", naturals: "\u2115", Not: "\u2AEC", NotCongruent: "\u2262", nequiv: "\u2262", NotCupCap: "\u226D", NotDoubleVerticalBar: "\u2226", npar: "\u2226", nparallel: "\u2226", nshortparallel: "\u2226", nspar: "\u2226", NotElement: "\u2209", notin: "\u2209", notinva: "\u2209", NotEqual: "\u2260", ne: "\u2260", NotEqualTilde: "\u2242\u0338", nesim: "\u2242\u0338", NotExists: "\u2204", nexist: "\u2204", nexists: "\u2204", NotGreater: "\u226F", ngt: "\u226F", ngtr: "\u226F", NotGreaterEqual: "\u2271", nge: "\u2271", ngeq: "\u2271", NotGreaterFullEqual: "\u2267\u0338", ngE: "\u2267\u0338", ngeqq: "\u2267\u0338", NotGreaterGreater: "\u226B\u0338", nGtv: "\u226B\u0338", NotGreaterLess: "\u2279", ntgl: "\u2279", NotGreaterSlantEqual: "\u2A7E\u0338", ngeqslant: "\u2A7E\u0338", nges: "\u2A7E\u0338", NotGreaterTilde: "\u2275", ngsim: "\u2275", NotHumpDownHump: "\u224E\u0338", nbump: "\u224E\u0338", NotHumpEqual: "\u224F\u0338", nbumpe: "\u224F\u0338", NotLeftTriangle: "\u22EA", nltri: "\u22EA", ntriangleleft: "\u22EA", NotLeftTriangleBar: "\u29CF\u0338", NotLeftTriangleEqual: "\u22EC", nltrie: "\u22EC", ntrianglelefteq: "\u22EC", NotLess: "\u226E", nless: "\u226E", nlt: "\u226E", NotLessEqual: "\u2270", nle: "\u2270", nleq: "\u2270", NotLessGreater: "\u2278", ntlg: "\u2278", NotLessLess: "\u226A\u0338", nLtv: "\u226A\u0338", NotLessSlantEqual: "\u2A7D\u0338", nleqslant: "\u2A7D\u0338", nles: "\u2A7D\u0338", NotLessTilde: "\u2274", nlsim: "\u2274", NotNestedGreaterGreater: "\u2AA2\u0338", NotNestedLessLess: "\u2AA1\u0338", NotPrecedes: "\u2280", npr: "\u2280", nprec: "\u2280", NotPrecedesEqual: "\u2AAF\u0338", npre: "\u2AAF\u0338", npreceq: "\u2AAF\u0338", NotPrecedesSlantEqual: "\u22E0", nprcue: "\u22E0", NotReverseElement: "\u220C", notni: "\u220C", notniva: "\u220C", NotRightTriangle: "\u22EB", nrtri: "\u22EB", ntriangleright: "\u22EB", NotRightTriangleBar: "\u29D0\u0338", NotRightTriangleEqual: "\u22ED", nrtrie: "\u22ED", ntrianglerighteq: "\u22ED", NotSquareSubset: "\u228F\u0338", NotSquareSubsetEqual: "\u22E2", nsqsube: "\u22E2", NotSquareSuperset: "\u2290\u0338", NotSquareSupersetEqual: "\u22E3", nsqsupe: "\u22E3", NotSubset: "\u2282\u20D2", nsubset: "\u2282\u20D2", vnsub: "\u2282\u20D2", NotSubsetEqual: "\u2288", nsube: "\u2288", nsubseteq: "\u2288", NotSucceeds: "\u2281", nsc: "\u2281", nsucc: "\u2281", NotSucceedsEqual: "\u2AB0\u0338", nsce: "\u2AB0\u0338", nsucceq: "\u2AB0\u0338", NotSucceedsSlantEqual: "\u22E1", nsccue: "\u22E1", NotSucceedsTilde: "\u227F\u0338", NotSuperset: "\u2283\u20D2", nsupset: "\u2283\u20D2", vnsup: "\u2283\u20D2", NotSupersetEqual: "\u2289", nsupe: "\u2289", nsupseteq: "\u2289", NotTilde: "\u2241", nsim: "\u2241", NotTildeEqual: "\u2244", nsime: "\u2244", nsimeq: "\u2244", NotTildeFullEqual: "\u2247", ncong: "\u2247", NotTildeTilde: "\u2249", nap: "\u2249", napprox: "\u2249", NotVerticalBar: "\u2224", nmid: "\u2224", nshortmid: "\u2224", nsmid: "\u2224", Nscr: "\u{1D4A9}", Ntilde: "\xD1", Nu: "\u039D", OElig: "\u0152", Oacute: "\xD3", Ocirc: "\xD4", Ocy: "\u041E", Odblac: "\u0150", Ofr: "\u{1D512}", Ograve: "\xD2", Omacr: "\u014C", Omega: "\u03A9", ohm: "\u03A9", Omicron: "\u039F", Oopf: "\u{1D546}", OpenCurlyDoubleQuote: "\u201C", ldquo: "\u201C", OpenCurlyQuote: "\u2018", lsquo: "\u2018", Or: "\u2A54", Oscr: "\u{1D4AA}", Oslash: "\xD8", Otilde: "\xD5", Otimes: "\u2A37", Ouml: "\xD6", OverBar: "\u203E", oline: "\u203E", OverBrace: "\u23DE", OverBracket: "\u23B4", tbrk: "\u23B4", OverParenthesis: "\u23DC", PartialD: "\u2202", part: "\u2202", Pcy: "\u041F", Pfr: "\u{1D513}", Phi: "\u03A6", Pi: "\u03A0", PlusMinus: "\xB1", plusmn: "\xB1", pm: "\xB1", Popf: "\u2119", primes: "\u2119", Pr: "\u2ABB", Precedes: "\u227A", pr: "\u227A", prec: "\u227A", PrecedesEqual: "\u2AAF", pre: "\u2AAF", preceq: "\u2AAF", PrecedesSlantEqual: "\u227C", prcue: "\u227C", preccurlyeq: "\u227C", PrecedesTilde: "\u227E", precsim: "\u227E", prsim: "\u227E", Prime: "\u2033", Product: "\u220F", prod: "\u220F", Proportional: "\u221D", prop: "\u221D", propto: "\u221D", varpropto: "\u221D", vprop: "\u221D", Pscr: "\u{1D4AB}", Psi: "\u03A8", QUOT: '"', quot: '"', Qfr: "\u{1D514}", Qopf: "\u211A", rationals: "\u211A", Qscr: "\u{1D4AC}", RBarr: "\u2910", drbkarow: "\u2910", REG: "\xAE", circledR: "\xAE", reg: "\xAE", Racute: "\u0154", Rang: "\u27EB", Rarr: "\u21A0", twoheadrightarrow: "\u21A0", Rarrtl: "\u2916", Rcaron: "\u0158", Rcedil: "\u0156", Rcy: "\u0420", Re: "\u211C", Rfr: "\u211C", real: "\u211C", realpart: "\u211C", ReverseElement: "\u220B", SuchThat: "\u220B", ni: "\u220B", niv: "\u220B", ReverseEquilibrium: "\u21CB", leftrightharpoons: "\u21CB", lrhar: "\u21CB", ReverseUpEquilibrium: "\u296F", duhar: "\u296F", Rho: "\u03A1", RightAngleBracket: "\u27E9", rang: "\u27E9", rangle: "\u27E9", RightArrow: "\u2192", ShortRightArrow: "\u2192", rarr: "\u2192", rightarrow: "\u2192", srarr: "\u2192", RightArrowBar: "\u21E5", rarrb: "\u21E5", RightArrowLeftArrow: "\u21C4", rightleftarrows: "\u21C4", rlarr: "\u21C4", RightCeiling: "\u2309", rceil: "\u2309", RightDoubleBracket: "\u27E7", robrk: "\u27E7", RightDownTeeVector: "\u295D", RightDownVector: "\u21C2", dharr: "\u21C2", downharpoonright: "\u21C2", RightDownVectorBar: "\u2955", RightFloor: "\u230B", rfloor: "\u230B", RightTee: "\u22A2", vdash: "\u22A2", RightTeeArrow: "\u21A6", map: "\u21A6", mapsto: "\u21A6", RightTeeVector: "\u295B", RightTriangle: "\u22B3", vartriangleright: "\u22B3", vrtri: "\u22B3", RightTriangleBar: "\u29D0", RightTriangleEqual: "\u22B5", rtrie: "\u22B5", trianglerighteq: "\u22B5", RightUpDownVector: "\u294F", RightUpTeeVector: "\u295C", RightUpVector: "\u21BE", uharr: "\u21BE", upharpoonright: "\u21BE", RightUpVectorBar: "\u2954", RightVector: "\u21C0", rharu: "\u21C0", rightharpoonup: "\u21C0", RightVectorBar: "\u2953", Ropf: "\u211D", reals: "\u211D", RoundImplies: "\u2970", Rrightarrow: "\u21DB", rAarr: "\u21DB", Rscr: "\u211B", realine: "\u211B", Rsh: "\u21B1", rsh: "\u21B1", RuleDelayed: "\u29F4", SHCHcy: "\u0429", SHcy: "\u0428", SOFTcy: "\u042C", Sacute: "\u015A", Sc: "\u2ABC", Scaron: "\u0160", Scedil: "\u015E", Scirc: "\u015C", Scy: "\u0421", Sfr: "\u{1D516}", ShortUpArrow: "\u2191", UpArrow: "\u2191", uarr: "\u2191", uparrow: "\u2191", Sigma: "\u03A3", SmallCircle: "\u2218", compfn: "\u2218", Sopf: "\u{1D54A}", Sqrt: "\u221A", radic: "\u221A", Square: "\u25A1", squ: "\u25A1", square: "\u25A1", SquareIntersection: "\u2293", sqcap: "\u2293", SquareSubset: "\u228F", sqsub: "\u228F", sqsubset: "\u228F", SquareSubsetEqual: "\u2291", sqsube: "\u2291", sqsubseteq: "\u2291", SquareSuperset: "\u2290", sqsup: "\u2290", sqsupset: "\u2290", SquareSupersetEqual: "\u2292", sqsupe: "\u2292", sqsupseteq: "\u2292", SquareUnion: "\u2294", sqcup: "\u2294", Sscr: "\u{1D4AE}", Star: "\u22C6", sstarf: "\u22C6", Sub: "\u22D0", Subset: "\u22D0", SubsetEqual: "\u2286", sube: "\u2286", subseteq: "\u2286", Succeeds: "\u227B", sc: "\u227B", succ: "\u227B", SucceedsEqual: "\u2AB0", sce: "\u2AB0", succeq: "\u2AB0", SucceedsSlantEqual: "\u227D", sccue: "\u227D", succcurlyeq: "\u227D", SucceedsTilde: "\u227F", scsim: "\u227F", succsim: "\u227F", Sum: "\u2211", sum: "\u2211", Sup: "\u22D1", Supset: "\u22D1", Superset: "\u2283", sup: "\u2283", supset: "\u2283", SupersetEqual: "\u2287", supe: "\u2287", supseteq: "\u2287", THORN: "\xDE", TRADE: "\u2122", trade: "\u2122", TSHcy: "\u040B", TScy: "\u0426", Tab: "	", Tau: "\u03A4", Tcaron: "\u0164", Tcedil: "\u0162", Tcy: "\u0422", Tfr: "\u{1D517}", Therefore: "\u2234", there4: "\u2234", therefore: "\u2234", Theta: "\u0398", ThickSpace: "\u205F\u200A", ThinSpace: "\u2009", thinsp: "\u2009", Tilde: "\u223C", sim: "\u223C", thicksim: "\u223C", thksim: "\u223C", TildeEqual: "\u2243", sime: "\u2243", simeq: "\u2243", TildeFullEqual: "\u2245", cong: "\u2245", TildeTilde: "\u2248", ap: "\u2248", approx: "\u2248", asymp: "\u2248", thickapprox: "\u2248", thkap: "\u2248", Topf: "\u{1D54B}", TripleDot: "\u20DB", tdot: "\u20DB", Tscr: "\u{1D4AF}", Tstrok: "\u0166", Uacute: "\xDA", Uarr: "\u219F", Uarrocir: "\u2949", Ubrcy: "\u040E", Ubreve: "\u016C", Ucirc: "\xDB", Ucy: "\u0423", Udblac: "\u0170", Ufr: "\u{1D518}", Ugrave: "\xD9", Umacr: "\u016A", UnderBar: "_", lowbar: "_", UnderBrace: "\u23DF", UnderBracket: "\u23B5", bbrk: "\u23B5", UnderParenthesis: "\u23DD", Union: "\u22C3", bigcup: "\u22C3", xcup: "\u22C3", UnionPlus: "\u228E", uplus: "\u228E", Uogon: "\u0172", Uopf: "\u{1D54C}", UpArrowBar: "\u2912", UpArrowDownArrow: "\u21C5", udarr: "\u21C5", UpDownArrow: "\u2195", updownarrow: "\u2195", varr: "\u2195", UpEquilibrium: "\u296E", udhar: "\u296E", UpTee: "\u22A5", bot: "\u22A5", bottom: "\u22A5", perp: "\u22A5", UpTeeArrow: "\u21A5", mapstoup: "\u21A5", UpperLeftArrow: "\u2196", nwarr: "\u2196", nwarrow: "\u2196", UpperRightArrow: "\u2197", nearr: "\u2197", nearrow: "\u2197", Upsi: "\u03D2", upsih: "\u03D2", Upsilon: "\u03A5", Uring: "\u016E", Uscr: "\u{1D4B0}", Utilde: "\u0168", Uuml: "\xDC", VDash: "\u22AB", Vbar: "\u2AEB", Vcy: "\u0412", Vdash: "\u22A9", Vdashl: "\u2AE6", Vee: "\u22C1", bigvee: "\u22C1", xvee: "\u22C1", Verbar: "\u2016", Vert: "\u2016", VerticalBar: "\u2223", mid: "\u2223", shortmid: "\u2223", smid: "\u2223", VerticalLine: "|", verbar: "|", vert: "|", VerticalSeparator: "\u2758", VerticalTilde: "\u2240", wr: "\u2240", wreath: "\u2240", VeryThinSpace: "\u200A", hairsp: "\u200A", Vfr: "\u{1D519}", Vopf: "\u{1D54D}", Vscr: "\u{1D4B1}", Vvdash: "\u22AA", Wcirc: "\u0174", Wedge: "\u22C0", bigwedge: "\u22C0", xwedge: "\u22C0", Wfr: "\u{1D51A}", Wopf: "\u{1D54E}", Wscr: "\u{1D4B2}", Xfr: "\u{1D51B}", Xi: "\u039E", Xopf: "\u{1D54F}", Xscr: "\u{1D4B3}", YAcy: "\u042F", YIcy: "\u0407", YUcy: "\u042E", Yacute: "\xDD", Ycirc: "\u0176", Ycy: "\u042B", Yfr: "\u{1D51C}", Yopf: "\u{1D550}", Yscr: "\u{1D4B4}", Yuml: "\u0178", ZHcy: "\u0416", Zacute: "\u0179", Zcaron: "\u017D", Zcy: "\u0417", Zdot: "\u017B", Zeta: "\u0396", Zfr: "\u2128", zeetrf: "\u2128", Zopf: "\u2124", integers: "\u2124", Zscr: "\u{1D4B5}", aacute: "\xE1", abreve: "\u0103", ac: "\u223E", mstpos: "\u223E", acE: "\u223E\u0333", acd: "\u223F", acirc: "\xE2", acy: "\u0430", aelig: "\xE6", afr: "\u{1D51E}", agrave: "\xE0", alefsym: "\u2135", aleph: "\u2135", alpha: "\u03B1", amacr: "\u0101", amalg: "\u2A3F", and: "\u2227", wedge: "\u2227", andand: "\u2A55", andd: "\u2A5C", andslope: "\u2A58", andv: "\u2A5A", ang: "\u2220", angle: "\u2220", ange: "\u29A4", angmsd: "\u2221", measuredangle: "\u2221", angmsdaa: "\u29A8", angmsdab: "\u29A9", angmsdac: "\u29AA", angmsdad: "\u29AB", angmsdae: "\u29AC", angmsdaf: "\u29AD", angmsdag: "\u29AE", angmsdah: "\u29AF", angrt: "\u221F", angrtvb: "\u22BE", angrtvbd: "\u299D", angsph: "\u2222", angzarr: "\u237C", aogon: "\u0105", aopf: "\u{1D552}", apE: "\u2A70", apacir: "\u2A6F", ape: "\u224A", approxeq: "\u224A", apid: "\u224B", apos: "'", aring: "\xE5", ascr: "\u{1D4B6}", ast: "*", midast: "*", atilde: "\xE3", auml: "\xE4", awint: "\u2A11", bNot: "\u2AED", backcong: "\u224C", bcong: "\u224C", backepsilon: "\u03F6", bepsi: "\u03F6", backprime: "\u2035", bprime: "\u2035", backsim: "\u223D", bsim: "\u223D", backsimeq: "\u22CD", bsime: "\u22CD", barvee: "\u22BD", barwed: "\u2305", barwedge: "\u2305", bbrktbrk: "\u23B6", bcy: "\u0431", bdquo: "\u201E", ldquor: "\u201E", bemptyv: "\u29B0", beta: "\u03B2", beth: "\u2136", between: "\u226C", twixt: "\u226C", bfr: "\u{1D51F}", bigcirc: "\u25EF", xcirc: "\u25EF", bigodot: "\u2A00", xodot: "\u2A00", bigoplus: "\u2A01", xoplus: "\u2A01", bigotimes: "\u2A02", xotime: "\u2A02", bigsqcup: "\u2A06", xsqcup: "\u2A06", bigstar: "\u2605", starf: "\u2605", bigtriangledown: "\u25BD", xdtri: "\u25BD", bigtriangleup: "\u25B3", xutri: "\u25B3", biguplus: "\u2A04", xuplus: "\u2A04", bkarow: "\u290D", rbarr: "\u290D", blacklozenge: "\u29EB", lozf: "\u29EB", blacktriangle: "\u25B4", utrif: "\u25B4", blacktriangledown: "\u25BE", dtrif: "\u25BE", blacktriangleleft: "\u25C2", ltrif: "\u25C2", blacktriangleright: "\u25B8", rtrif: "\u25B8", blank: "\u2423", blk12: "\u2592", blk14: "\u2591", blk34: "\u2593", block: "\u2588", bne: "=\u20E5", bnequiv: "\u2261\u20E5", bnot: "\u2310", bopf: "\u{1D553}", bowtie: "\u22C8", boxDL: "\u2557", boxDR: "\u2554", boxDl: "\u2556", boxDr: "\u2553", boxH: "\u2550", boxHD: "\u2566", boxHU: "\u2569", boxHd: "\u2564", boxHu: "\u2567", boxUL: "\u255D", boxUR: "\u255A", boxUl: "\u255C", boxUr: "\u2559", boxV: "\u2551", boxVH: "\u256C", boxVL: "\u2563", boxVR: "\u2560", boxVh: "\u256B", boxVl: "\u2562", boxVr: "\u255F", boxbox: "\u29C9", boxdL: "\u2555", boxdR: "\u2552", boxdl: "\u2510", boxdr: "\u250C", boxhD: "\u2565", boxhU: "\u2568", boxhd: "\u252C", boxhu: "\u2534", boxminus: "\u229F", minusb: "\u229F", boxplus: "\u229E", plusb: "\u229E", boxtimes: "\u22A0", timesb: "\u22A0", boxuL: "\u255B", boxuR: "\u2558", boxul: "\u2518", boxur: "\u2514", boxv: "\u2502", boxvH: "\u256A", boxvL: "\u2561", boxvR: "\u255E", boxvh: "\u253C", boxvl: "\u2524", boxvr: "\u251C", brvbar: "\xA6", bscr: "\u{1D4B7}", bsemi: "\u204F", bsol: "\\", bsolb: "\u29C5", bsolhsub: "\u27C8", bull: "\u2022", bullet: "\u2022", bumpE: "\u2AAE", cacute: "\u0107", cap: "\u2229", capand: "\u2A44", capbrcup: "\u2A49", capcap: "\u2A4B", capcup: "\u2A47", capdot: "\u2A40", caps: "\u2229\uFE00", caret: "\u2041", ccaps: "\u2A4D", ccaron: "\u010D", ccedil: "\xE7", ccirc: "\u0109", ccups: "\u2A4C", ccupssm: "\u2A50", cdot: "\u010B", cemptyv: "\u29B2", cent: "\xA2", cfr: "\u{1D520}", chcy: "\u0447", check: "\u2713", checkmark: "\u2713", chi: "\u03C7", cir: "\u25CB", cirE: "\u29C3", circ: "\u02C6", circeq: "\u2257", cire: "\u2257", circlearrowleft: "\u21BA", olarr: "\u21BA", circlearrowright: "\u21BB", orarr: "\u21BB", circledS: "\u24C8", oS: "\u24C8", circledast: "\u229B", oast: "\u229B", circledcirc: "\u229A", ocir: "\u229A", circleddash: "\u229D", odash: "\u229D", cirfnint: "\u2A10", cirmid: "\u2AEF", cirscir: "\u29C2", clubs: "\u2663", clubsuit: "\u2663", colon: ":", comma: ",", commat: "@", comp: "\u2201", complement: "\u2201", congdot: "\u2A6D", copf: "\u{1D554}", copysr: "\u2117", crarr: "\u21B5", cross: "\u2717", cscr: "\u{1D4B8}", csub: "\u2ACF", csube: "\u2AD1", csup: "\u2AD0", csupe: "\u2AD2", ctdot: "\u22EF", cudarrl: "\u2938", cudarrr: "\u2935", cuepr: "\u22DE", curlyeqprec: "\u22DE", cuesc: "\u22DF", curlyeqsucc: "\u22DF", cularr: "\u21B6", curvearrowleft: "\u21B6", cularrp: "\u293D", cup: "\u222A", cupbrcap: "\u2A48", cupcap: "\u2A46", cupcup: "\u2A4A", cupdot: "\u228D", cupor: "\u2A45", cups: "\u222A\uFE00", curarr: "\u21B7", curvearrowright: "\u21B7", curarrm: "\u293C", curlyvee: "\u22CE", cuvee: "\u22CE", curlywedge: "\u22CF", cuwed: "\u22CF", curren: "\xA4", cwint: "\u2231", cylcty: "\u232D", dHar: "\u2965", dagger: "\u2020", daleth: "\u2138", dash: "\u2010", hyphen: "\u2010", dbkarow: "\u290F", rBarr: "\u290F", dcaron: "\u010F", dcy: "\u0434", ddarr: "\u21CA", downdownarrows: "\u21CA", ddotseq: "\u2A77", eDDot: "\u2A77", deg: "\xB0", delta: "\u03B4", demptyv: "\u29B1", dfisht: "\u297F", dfr: "\u{1D521}", diamondsuit: "\u2666", diams: "\u2666", digamma: "\u03DD", gammad: "\u03DD", disin: "\u22F2", div: "\xF7", divide: "\xF7", divideontimes: "\u22C7", divonx: "\u22C7", djcy: "\u0452", dlcorn: "\u231E", llcorner: "\u231E", dlcrop: "\u230D", dollar: "$", dopf: "\u{1D555}", doteqdot: "\u2251", eDot: "\u2251", dotminus: "\u2238", minusd: "\u2238", dotplus: "\u2214", plusdo: "\u2214", dotsquare: "\u22A1", sdotb: "\u22A1", drcorn: "\u231F", lrcorner: "\u231F", drcrop: "\u230C", dscr: "\u{1D4B9}", dscy: "\u0455", dsol: "\u29F6", dstrok: "\u0111", dtdot: "\u22F1", dtri: "\u25BF", triangledown: "\u25BF", dwangle: "\u29A6", dzcy: "\u045F", dzigrarr: "\u27FF", eacute: "\xE9", easter: "\u2A6E", ecaron: "\u011B", ecir: "\u2256", eqcirc: "\u2256", ecirc: "\xEA", ecolon: "\u2255", eqcolon: "\u2255", ecy: "\u044D", edot: "\u0117", efDot: "\u2252", fallingdotseq: "\u2252", efr: "\u{1D522}", eg: "\u2A9A", egrave: "\xE8", egs: "\u2A96", eqslantgtr: "\u2A96", egsdot: "\u2A98", el: "\u2A99", elinters: "\u23E7", ell: "\u2113", els: "\u2A95", eqslantless: "\u2A95", elsdot: "\u2A97", emacr: "\u0113", empty: "\u2205", emptyset: "\u2205", emptyv: "\u2205", varnothing: "\u2205", emsp13: "\u2004", emsp14: "\u2005", emsp: "\u2003", eng: "\u014B", ensp: "\u2002", eogon: "\u0119", eopf: "\u{1D556}", epar: "\u22D5", eparsl: "\u29E3", eplus: "\u2A71", epsi: "\u03B5", epsilon: "\u03B5", epsiv: "\u03F5", straightepsilon: "\u03F5", varepsilon: "\u03F5", equals: "=", equest: "\u225F", questeq: "\u225F", equivDD: "\u2A78", eqvparsl: "\u29E5", erDot: "\u2253", risingdotseq: "\u2253", erarr: "\u2971", escr: "\u212F", eta: "\u03B7", eth: "\xF0", euml: "\xEB", euro: "\u20AC", excl: "!", fcy: "\u0444", female: "\u2640", ffilig: "\uFB03", fflig: "\uFB00", ffllig: "\uFB04", ffr: "\u{1D523}", filig: "\uFB01", fjlig: "fj", flat: "\u266D", fllig: "\uFB02", fltns: "\u25B1", fnof: "\u0192", fopf: "\u{1D557}", fork: "\u22D4", pitchfork: "\u22D4", forkv: "\u2AD9", fpartint: "\u2A0D", frac12: "\xBD", half: "\xBD", frac13: "\u2153", frac14: "\xBC", frac15: "\u2155", frac16: "\u2159", frac18: "\u215B", frac23: "\u2154", frac25: "\u2156", frac34: "\xBE", frac35: "\u2157", frac38: "\u215C", frac45: "\u2158", frac56: "\u215A", frac58: "\u215D", frac78: "\u215E", frasl: "\u2044", frown: "\u2322", sfrown: "\u2322", fscr: "\u{1D4BB}", gEl: "\u2A8C", gtreqqless: "\u2A8C", gacute: "\u01F5", gamma: "\u03B3", gap: "\u2A86", gtrapprox: "\u2A86", gbreve: "\u011F", gcirc: "\u011D", gcy: "\u0433", gdot: "\u0121", gescc: "\u2AA9", gesdot: "\u2A80", gesdoto: "\u2A82", gesdotol: "\u2A84", gesl: "\u22DB\uFE00", gesles: "\u2A94", gfr: "\u{1D524}", gimel: "\u2137", gjcy: "\u0453", glE: "\u2A92", gla: "\u2AA5", glj: "\u2AA4", gnE: "\u2269", gneqq: "\u2269", gnap: "\u2A8A", gnapprox: "\u2A8A", gne: "\u2A88", gneq: "\u2A88", gnsim: "\u22E7", gopf: "\u{1D558}", gscr: "\u210A", gsime: "\u2A8E", gsiml: "\u2A90", gtcc: "\u2AA7", gtcir: "\u2A7A", gtdot: "\u22D7", gtrdot: "\u22D7", gtlPar: "\u2995", gtquest: "\u2A7C", gtrarr: "\u2978", gvertneqq: "\u2269\uFE00", gvnE: "\u2269\uFE00", hardcy: "\u044A", harrcir: "\u2948", harrw: "\u21AD", leftrightsquigarrow: "\u21AD", hbar: "\u210F", hslash: "\u210F", planck: "\u210F", plankv: "\u210F", hcirc: "\u0125", hearts: "\u2665", heartsuit: "\u2665", hellip: "\u2026", mldr: "\u2026", hercon: "\u22B9", hfr: "\u{1D525}", hksearow: "\u2925", searhk: "\u2925", hkswarow: "\u2926", swarhk: "\u2926", hoarr: "\u21FF", homtht: "\u223B", hookleftarrow: "\u21A9", larrhk: "\u21A9", hookrightarrow: "\u21AA", rarrhk: "\u21AA", hopf: "\u{1D559}", horbar: "\u2015", hscr: "\u{1D4BD}", hstrok: "\u0127", hybull: "\u2043", iacute: "\xED", icirc: "\xEE", icy: "\u0438", iecy: "\u0435", iexcl: "\xA1", ifr: "\u{1D526}", igrave: "\xEC", iiiint: "\u2A0C", qint: "\u2A0C", iiint: "\u222D", tint: "\u222D", iinfin: "\u29DC", iiota: "\u2129", ijlig: "\u0133", imacr: "\u012B", imath: "\u0131", inodot: "\u0131", imof: "\u22B7", imped: "\u01B5", incare: "\u2105", infin: "\u221E", infintie: "\u29DD", intcal: "\u22BA", intercal: "\u22BA", intlarhk: "\u2A17", intprod: "\u2A3C", iprod: "\u2A3C", iocy: "\u0451", iogon: "\u012F", iopf: "\u{1D55A}", iota: "\u03B9", iquest: "\xBF", iscr: "\u{1D4BE}", isinE: "\u22F9", isindot: "\u22F5", isins: "\u22F4", isinsv: "\u22F3", itilde: "\u0129", iukcy: "\u0456", iuml: "\xEF", jcirc: "\u0135", jcy: "\u0439", jfr: "\u{1D527}", jmath: "\u0237", jopf: "\u{1D55B}", jscr: "\u{1D4BF}", jsercy: "\u0458", jukcy: "\u0454", kappa: "\u03BA", kappav: "\u03F0", varkappa: "\u03F0", kcedil: "\u0137", kcy: "\u043A", kfr: "\u{1D528}", kgreen: "\u0138", khcy: "\u0445", kjcy: "\u045C", kopf: "\u{1D55C}", kscr: "\u{1D4C0}", lAtail: "\u291B", lBarr: "\u290E", lEg: "\u2A8B", lesseqqgtr: "\u2A8B", lHar: "\u2962", lacute: "\u013A", laemptyv: "\u29B4", lambda: "\u03BB", langd: "\u2991", lap: "\u2A85", lessapprox: "\u2A85", laquo: "\xAB", larrbfs: "\u291F", larrfs: "\u291D", larrlp: "\u21AB", looparrowleft: "\u21AB", larrpl: "\u2939", larrsim: "\u2973", larrtl: "\u21A2", leftarrowtail: "\u21A2", lat: "\u2AAB", latail: "\u2919", late: "\u2AAD", lates: "\u2AAD\uFE00", lbarr: "\u290C", lbbrk: "\u2772", lbrace: "{", lcub: "{", lbrack: "[", lsqb: "[", lbrke: "\u298B", lbrksld: "\u298F", lbrkslu: "\u298D", lcaron: "\u013E", lcedil: "\u013C", lcy: "\u043B", ldca: "\u2936", ldrdhar: "\u2967", ldrushar: "\u294B", ldsh: "\u21B2", le: "\u2264", leq: "\u2264", leftleftarrows: "\u21C7", llarr: "\u21C7", leftthreetimes: "\u22CB", lthree: "\u22CB", lescc: "\u2AA8", lesdot: "\u2A7F", lesdoto: "\u2A81", lesdotor: "\u2A83", lesg: "\u22DA\uFE00", lesges: "\u2A93", lessdot: "\u22D6", ltdot: "\u22D6", lfisht: "\u297C", lfr: "\u{1D529}", lgE: "\u2A91", lharul: "\u296A", lhblk: "\u2584", ljcy: "\u0459", llhard: "\u296B", lltri: "\u25FA", lmidot: "\u0140", lmoust: "\u23B0", lmoustache: "\u23B0", lnE: "\u2268", lneqq: "\u2268", lnap: "\u2A89", lnapprox: "\u2A89", lne: "\u2A87", lneq: "\u2A87", lnsim: "\u22E6", loang: "\u27EC", loarr: "\u21FD", longmapsto: "\u27FC", xmap: "\u27FC", looparrowright: "\u21AC", rarrlp: "\u21AC", lopar: "\u2985", lopf: "\u{1D55D}", loplus: "\u2A2D", lotimes: "\u2A34", lowast: "\u2217", loz: "\u25CA", lozenge: "\u25CA", lpar: "(", lparlt: "\u2993", lrhard: "\u296D", lrm: "\u200E", lrtri: "\u22BF", lsaquo: "\u2039", lscr: "\u{1D4C1}", lsime: "\u2A8D", lsimg: "\u2A8F", lsquor: "\u201A", sbquo: "\u201A", lstrok: "\u0142", ltcc: "\u2AA6", ltcir: "\u2A79", ltimes: "\u22C9", ltlarr: "\u2976", ltquest: "\u2A7B", ltrPar: "\u2996", ltri: "\u25C3", triangleleft: "\u25C3", lurdshar: "\u294A", luruhar: "\u2966", lvertneqq: "\u2268\uFE00", lvnE: "\u2268\uFE00", mDDot: "\u223A", macr: "\xAF", strns: "\xAF", male: "\u2642", malt: "\u2720", maltese: "\u2720", marker: "\u25AE", mcomma: "\u2A29", mcy: "\u043C", mdash: "\u2014", mfr: "\u{1D52A}", mho: "\u2127", micro: "\xB5", midcir: "\u2AF0", minus: "\u2212", minusdu: "\u2A2A", mlcp: "\u2ADB", models: "\u22A7", mopf: "\u{1D55E}", mscr: "\u{1D4C2}", mu: "\u03BC", multimap: "\u22B8", mumap: "\u22B8", nGg: "\u22D9\u0338", nGt: "\u226B\u20D2", nLeftarrow: "\u21CD", nlArr: "\u21CD", nLeftrightarrow: "\u21CE", nhArr: "\u21CE", nLl: "\u22D8\u0338", nLt: "\u226A\u20D2", nRightarrow: "\u21CF", nrArr: "\u21CF", nVDash: "\u22AF", nVdash: "\u22AE", nacute: "\u0144", nang: "\u2220\u20D2", napE: "\u2A70\u0338", napid: "\u224B\u0338", napos: "\u0149", natur: "\u266E", natural: "\u266E", ncap: "\u2A43", ncaron: "\u0148", ncedil: "\u0146", ncongdot: "\u2A6D\u0338", ncup: "\u2A42", ncy: "\u043D", ndash: "\u2013", neArr: "\u21D7", nearhk: "\u2924", nedot: "\u2250\u0338", nesear: "\u2928", toea: "\u2928", nfr: "\u{1D52B}", nharr: "\u21AE", nleftrightarrow: "\u21AE", nhpar: "\u2AF2", nis: "\u22FC", nisd: "\u22FA", njcy: "\u045A", nlE: "\u2266\u0338", nleqq: "\u2266\u0338", nlarr: "\u219A", nleftarrow: "\u219A", nldr: "\u2025", nopf: "\u{1D55F}", not: "\xAC", notinE: "\u22F9\u0338", notindot: "\u22F5\u0338", notinvb: "\u22F7", notinvc: "\u22F6", notnivb: "\u22FE", notnivc: "\u22FD", nparsl: "\u2AFD\u20E5", npart: "\u2202\u0338", npolint: "\u2A14", nrarr: "\u219B", nrightarrow: "\u219B", nrarrc: "\u2933\u0338", nrarrw: "\u219D\u0338", nscr: "\u{1D4C3}", nsub: "\u2284", nsubE: "\u2AC5\u0338", nsubseteqq: "\u2AC5\u0338", nsup: "\u2285", nsupE: "\u2AC6\u0338", nsupseteqq: "\u2AC6\u0338", ntilde: "\xF1", nu: "\u03BD", num: "#", numero: "\u2116", numsp: "\u2007", nvDash: "\u22AD", nvHarr: "\u2904", nvap: "\u224D\u20D2", nvdash: "\u22AC", nvge: "\u2265\u20D2", nvgt: ">\u20D2", nvinfin: "\u29DE", nvlArr: "\u2902", nvle: "\u2264\u20D2", nvlt: "<\u20D2", nvltrie: "\u22B4\u20D2", nvrArr: "\u2903", nvrtrie: "\u22B5\u20D2", nvsim: "\u223C\u20D2", nwArr: "\u21D6", nwarhk: "\u2923", nwnear: "\u2927", oacute: "\xF3", ocirc: "\xF4", ocy: "\u043E", odblac: "\u0151", odiv: "\u2A38", odsold: "\u29BC", oelig: "\u0153", ofcir: "\u29BF", ofr: "\u{1D52C}", ogon: "\u02DB", ograve: "\xF2", ogt: "\u29C1", ohbar: "\u29B5", olcir: "\u29BE", olcross: "\u29BB", olt: "\u29C0", omacr: "\u014D", omega: "\u03C9", omicron: "\u03BF", omid: "\u29B6", oopf: "\u{1D560}", opar: "\u29B7", operp: "\u29B9", or: "\u2228", vee: "\u2228", ord: "\u2A5D", order: "\u2134", orderof: "\u2134", oscr: "\u2134", ordf: "\xAA", ordm: "\xBA", origof: "\u22B6", oror: "\u2A56", orslope: "\u2A57", orv: "\u2A5B", oslash: "\xF8", osol: "\u2298", otilde: "\xF5", otimesas: "\u2A36", ouml: "\xF6", ovbar: "\u233D", para: "\xB6", parsim: "\u2AF3", parsl: "\u2AFD", pcy: "\u043F", percnt: "%", period: ".", permil: "\u2030", pertenk: "\u2031", pfr: "\u{1D52D}", phi: "\u03C6", phiv: "\u03D5", straightphi: "\u03D5", varphi: "\u03D5", phone: "\u260E", pi: "\u03C0", piv: "\u03D6", varpi: "\u03D6", planckh: "\u210E", plus: "+", plusacir: "\u2A23", pluscir: "\u2A22", plusdu: "\u2A25", pluse: "\u2A72", plussim: "\u2A26", plustwo: "\u2A27", pointint: "\u2A15", popf: "\u{1D561}", pound: "\xA3", prE: "\u2AB3", prap: "\u2AB7", precapprox: "\u2AB7", precnapprox: "\u2AB9", prnap: "\u2AB9", precneqq: "\u2AB5", prnE: "\u2AB5", precnsim: "\u22E8", prnsim: "\u22E8", prime: "\u2032", profalar: "\u232E", profline: "\u2312", profsurf: "\u2313", prurel: "\u22B0", pscr: "\u{1D4C5}", psi: "\u03C8", puncsp: "\u2008", qfr: "\u{1D52E}", qopf: "\u{1D562}", qprime: "\u2057", qscr: "\u{1D4C6}", quatint: "\u2A16", quest: "?", rAtail: "\u291C", rHar: "\u2964", race: "\u223D\u0331", racute: "\u0155", raemptyv: "\u29B3", rangd: "\u2992", range: "\u29A5", raquo: "\xBB", rarrap: "\u2975", rarrbfs: "\u2920", rarrc: "\u2933", rarrfs: "\u291E", rarrpl: "\u2945", rarrsim: "\u2974", rarrtl: "\u21A3", rightarrowtail: "\u21A3", rarrw: "\u219D", rightsquigarrow: "\u219D", ratail: "\u291A", ratio: "\u2236", rbbrk: "\u2773", rbrace: "}", rcub: "}", rbrack: "]", rsqb: "]", rbrke: "\u298C", rbrksld: "\u298E", rbrkslu: "\u2990", rcaron: "\u0159", rcedil: "\u0157", rcy: "\u0440", rdca: "\u2937", rdldhar: "\u2969", rdsh: "\u21B3", rect: "\u25AD", rfisht: "\u297D", rfr: "\u{1D52F}", rharul: "\u296C", rho: "\u03C1", rhov: "\u03F1", varrho: "\u03F1", rightrightarrows: "\u21C9", rrarr: "\u21C9", rightthreetimes: "\u22CC", rthree: "\u22CC", ring: "\u02DA", rlm: "\u200F", rmoust: "\u23B1", rmoustache: "\u23B1", rnmid: "\u2AEE", roang: "\u27ED", roarr: "\u21FE", ropar: "\u2986", ropf: "\u{1D563}", roplus: "\u2A2E", rotimes: "\u2A35", rpar: ")", rpargt: "\u2994", rppolint: "\u2A12", rsaquo: "\u203A", rscr: "\u{1D4C7}", rtimes: "\u22CA", rtri: "\u25B9", triangleright: "\u25B9", rtriltri: "\u29CE", ruluhar: "\u2968", rx: "\u211E", sacute: "\u015B", scE: "\u2AB4", scap: "\u2AB8", succapprox: "\u2AB8", scaron: "\u0161", scedil: "\u015F", scirc: "\u015D", scnE: "\u2AB6", succneqq: "\u2AB6", scnap: "\u2ABA", succnapprox: "\u2ABA", scnsim: "\u22E9", succnsim: "\u22E9", scpolint: "\u2A13", scy: "\u0441", sdot: "\u22C5", sdote: "\u2A66", seArr: "\u21D8", sect: "\xA7", semi: ";", seswar: "\u2929", tosa: "\u2929", sext: "\u2736", sfr: "\u{1D530}", sharp: "\u266F", shchcy: "\u0449", shcy: "\u0448", shy: "\xAD", sigma: "\u03C3", sigmaf: "\u03C2", sigmav: "\u03C2", varsigma: "\u03C2", simdot: "\u2A6A", simg: "\u2A9E", simgE: "\u2AA0", siml: "\u2A9D", simlE: "\u2A9F", simne: "\u2246", simplus: "\u2A24", simrarr: "\u2972", smashp: "\u2A33", smeparsl: "\u29E4", smile: "\u2323", ssmile: "\u2323", smt: "\u2AAA", smte: "\u2AAC", smtes: "\u2AAC\uFE00", softcy: "\u044C", sol: "/", solb: "\u29C4", solbar: "\u233F", sopf: "\u{1D564}", spades: "\u2660", spadesuit: "\u2660", sqcaps: "\u2293\uFE00", sqcups: "\u2294\uFE00", sscr: "\u{1D4C8}", star: "\u2606", sub: "\u2282", subset: "\u2282", subE: "\u2AC5", subseteqq: "\u2AC5", subdot: "\u2ABD", subedot: "\u2AC3", submult: "\u2AC1", subnE: "\u2ACB", subsetneqq: "\u2ACB", subne: "\u228A", subsetneq: "\u228A", subplus: "\u2ABF", subrarr: "\u2979", subsim: "\u2AC7", subsub: "\u2AD5", subsup: "\u2AD3", sung: "\u266A", sup1: "\xB9", sup2: "\xB2", sup3: "\xB3", supE: "\u2AC6", supseteqq: "\u2AC6", supdot: "\u2ABE", supdsub: "\u2AD8", supedot: "\u2AC4", suphsol: "\u27C9", suphsub: "\u2AD7", suplarr: "\u297B", supmult: "\u2AC2", supnE: "\u2ACC", supsetneqq: "\u2ACC", supne: "\u228B", supsetneq: "\u228B", supplus: "\u2AC0", supsim: "\u2AC8", supsub: "\u2AD4", supsup: "\u2AD6", swArr: "\u21D9", swnwar: "\u292A", szlig: "\xDF", target: "\u2316", tau: "\u03C4", tcaron: "\u0165", tcedil: "\u0163", tcy: "\u0442", telrec: "\u2315", tfr: "\u{1D531}", theta: "\u03B8", thetasym: "\u03D1", thetav: "\u03D1", vartheta: "\u03D1", thorn: "\xFE", times: "\xD7", timesbar: "\u2A31", timesd: "\u2A30", topbot: "\u2336", topcir: "\u2AF1", topf: "\u{1D565}", topfork: "\u2ADA", tprime: "\u2034", triangle: "\u25B5", utri: "\u25B5", triangleq: "\u225C", trie: "\u225C", tridot: "\u25EC", triminus: "\u2A3A", triplus: "\u2A39", trisb: "\u29CD", tritime: "\u2A3B", trpezium: "\u23E2", tscr: "\u{1D4C9}", tscy: "\u0446", tshcy: "\u045B", tstrok: "\u0167", uHar: "\u2963", uacute: "\xFA", ubrcy: "\u045E", ubreve: "\u016D", ucirc: "\xFB", ucy: "\u0443", udblac: "\u0171", ufisht: "\u297E", ufr: "\u{1D532}", ugrave: "\xF9", uhblk: "\u2580", ulcorn: "\u231C", ulcorner: "\u231C", ulcrop: "\u230F", ultri: "\u25F8", umacr: "\u016B", uogon: "\u0173", uopf: "\u{1D566}", upsi: "\u03C5", upsilon: "\u03C5", upuparrows: "\u21C8", uuarr: "\u21C8", urcorn: "\u231D", urcorner: "\u231D", urcrop: "\u230E", uring: "\u016F", urtri: "\u25F9", uscr: "\u{1D4CA}", utdot: "\u22F0", utilde: "\u0169", uuml: "\xFC", uwangle: "\u29A7", vBar: "\u2AE8", vBarv: "\u2AE9", vangrt: "\u299C", varsubsetneq: "\u228A\uFE00", vsubne: "\u228A\uFE00", varsubsetneqq: "\u2ACB\uFE00", vsubnE: "\u2ACB\uFE00", varsupsetneq: "\u228B\uFE00", vsupne: "\u228B\uFE00", varsupsetneqq: "\u2ACC\uFE00", vsupnE: "\u2ACC\uFE00", vcy: "\u0432", veebar: "\u22BB", veeeq: "\u225A", vellip: "\u22EE", vfr: "\u{1D533}", vopf: "\u{1D567}", vscr: "\u{1D4CB}", vzigzag: "\u299A", wcirc: "\u0175", wedbar: "\u2A5F", wedgeq: "\u2259", weierp: "\u2118", wp: "\u2118", wfr: "\u{1D534}", wopf: "\u{1D568}", wscr: "\u{1D4CC}", xfr: "\u{1D535}", xi: "\u03BE", xnis: "\u22FB", xopf: "\u{1D569}", xscr: "\u{1D4CD}", yacute: "\xFD", yacy: "\u044F", ycirc: "\u0177", ycy: "\u044B", yen: "\xA5", yfr: "\u{1D536}", yicy: "\u0457", yopf: "\u{1D56A}", yscr: "\u{1D4CE}", yucy: "\u044E", yuml: "\xFF", zacute: "\u017A", zcaron: "\u017E", zcy: "\u0437", zdot: "\u017C", zeta: "\u03B6", zfr: "\u{1D537}", zhcy: "\u0436", zigrarr: "\u21DD", zopf: "\u{1D56B}", zscr: "\u{1D4CF}", zwj: "\u200D", zwnj: "\u200C" }, Ch = "\uE500";
oi.ngsp = Ch;
var Ec = class {
    tokens;
    errors;
    nonNormalizedIcuExpressions;
    constructor(e, t, s) { this.tokens = e, this.errors = t, this.nonNormalizedIcuExpressions = s; }
};
function bv(n, e, t, s = {}) { let r = new yc(new xo(n, e), t, s); return r.tokenize(), new Ec(Mv(r.tokens), r.errors, r.nonNormalizedIcuExpressions); }
var Av = /\r\n?/g;
function rs(n) { return `Unexpected character "${n === le ? "EOF" : String.fromCharCode(n)}"`; }
function yu(n) { return `Unknown entity "${n}" - use the "&#<decimal>;" or  "&#x<hex>;" syntax`; }
function kv(n, e) { return `Unable to parse entity "${e}" - ${n} character reference entities must end with ";"`; }
var xc = (function (n) { return n.HEX = "hexadecimal", n.DEC = "decimal", n; })(xc || {}), Tv = ["@if", "@else", "@for", "@switch", "@case", "@default", "@empty", "@defer", "@placeholder", "@loading", "@error", "@content"], Ws = { start: "{{", end: "}}" }, _v = /^default[^\S\r\n]+never/, Iv = /^else[^\S\r\n]+if/, yc = class {
    _getTagDefinition;
    _cursor;
    _tokenizeIcu;
    _leadingTriviaCodePoints;
    _currentTokenStart = null;
    _currentTokenType = null;
    _expansionCaseStack = [];
    _openDirectiveCount = 0;
    _inInterpolation = !1;
    _preserveLineEndings;
    _i18nNormalizeLineEndingsInICUs;
    _tokenizeBlocks;
    _tokenizeLet;
    _selectorlessEnabled;
    tokens = [];
    errors = [];
    nonNormalizedIcuExpressions = [];
    constructor(e, t, s) { this._getTagDefinition = t, this._tokenizeIcu = s.tokenizeExpansionForms || !1, this._leadingTriviaCodePoints = s.leadingTriviaChars && s.leadingTriviaChars.map(i => i.codePointAt(0) || 0); let r = s.range || { endPos: e.content.length, startPos: 0, startLine: 0, startCol: 0 }; this._cursor = s.escapedString ? new Cc(e, r) : new Ro(e, r), this._preserveLineEndings = s.preserveLineEndings || !1, this._i18nNormalizeLineEndingsInICUs = s.i18nNormalizeLineEndingsInICUs || !1, this._tokenizeBlocks = s.tokenizeBlocks ?? !0, this._tokenizeLet = s.tokenizeLet ?? !0, this._selectorlessEnabled = s.selectorlessEnabled ?? !1; try {
        this._cursor.init();
    }
    catch (i) {
        this.handleError(i);
    } }
    _processCarriageReturns(e) {
        return this._preserveLineEndings ? e : e.replace(Av, `
`);
    }
    tokenize() { for (; this._cursor.peek() !== le;) {
        let e = this._cursor.clone();
        try {
            this._attemptCharCode(ws) ? this._attemptCharCode(Za) ? this._attemptCharCode(Tt) ? this._consumeCdata(e) : this._attemptCharCode(Eo) ? this._consumeComment(e) : this._consumeDocType(e) : this._attemptCharCode(Xe) ? this._consumeTagClose(e) : this._attemptCharCode(hs) ? this._consumeProcessingInstruction(e) : this._consumeTagOpen(e) : this._tokenizeLet && this._cursor.peek() === ts && !this._inInterpolation && this._isLetStart() ? this._consumeLetDeclaration(e) : this._tokenizeBlocks && this._isBlockStart() ? this._consumeBlockStart(e) : this._tokenizeBlocks && !this._inInterpolation && !this._isInExpansionCase() && !this._isInExpansionForm() && this._attemptCharCode(Le) ? this._consumeBlockEnd(e) : this._tokenizeIcu && this._tokenizeExpansionForm() || this._consumeWithInterpolation(5, 8, () => this._isTextEnd(), () => this._isTagStart());
        }
        catch (t) {
            this.handleError(t);
        }
    } this._beginToken(43), this._endToken([]); }
    _getBlockName() { let e = !1, t = this._cursor.clone(); this._attemptCharCodeUntilFn(r => zr(r) ? !e : $v(r) ? (e = !0, !1) : !0); let s = this._cursor.getChars(t).trim(); return Iv.test(s) ? s = "else if" : _v.test(s) && (s = "default never"), s; }
    _consumeBlockStart(e) { this._requireCharCode(ts), this._beginToken(25, e); let t = this._endToken([this._getBlockName()]); if (this._cursor.peek() === Be)
        if (this._cursor.advance(), this._consumeBlockParameters(), this._attemptCharCodeUntilFn(K), this._attemptCharCode(ue))
            this._attemptCharCodeUntilFn(K);
        else {
            t.type = 29;
            return;
        } if (t.parts[0] === "default never" && this._attemptCharCode(qe)) {
        this._beginToken(26), this._endToken([]), this._beginToken(27), this._endToken([]);
        return;
    } this._attemptCharCode(pt) ? (this._beginToken(26), this._endToken([])) : this._isBlockStart() && (t.parts[0] === "case" || t.parts[0] === "default") ? (this._beginToken(26), this._endToken([]), this._beginToken(27), this._endToken([])) : t.type = 29; }
    _consumeBlockEnd(e) { this._beginToken(27, e), this._endToken([]); }
    _consumeBlockParameters() { for (this._attemptCharCodeUntilFn(bu); this._cursor.peek() !== ue && this._cursor.peek() !== le;) {
        this._beginToken(28);
        let e = this._cursor.clone(), t = null, s = 0;
        for (; this._cursor.peek() !== qe && this._cursor.peek() !== le || t !== null;) {
            let r = this._cursor.peek();
            if (r === Dn)
                this._cursor.advance();
            else if (r === t)
                t = null;
            else if (t === null && ir(r))
                t = r;
            else if (r === Be && t === null)
                s++;
            else if (r === ue && t === null) {
                if (s === 0)
                    break;
                s > 0 && s--;
            }
            this._cursor.advance();
        }
        this._endToken([this._cursor.getChars(e)]), this._attemptCharCodeUntilFn(bu);
    } }
    _consumeLetDeclaration(e) { if (this._requireStr("@let"), this._beginToken(30, e), zr(this._cursor.peek()))
        this._attemptCharCodeUntilFn(K);
    else {
        let r = this._endToken([this._cursor.getChars(e)]);
        r.type = 33;
        return;
    } let t = this._endToken([this._getLetDeclarationName()]); if (this._attemptCharCodeUntilFn(K), !this._attemptCharCode(Se)) {
        t.type = 33;
        return;
    } this._attemptCharCodeUntilFn(r => K(r) && !rr(r)), this._consumeLetDeclarationValue(), this._cursor.peek() === qe ? (this._beginToken(32), this._cursor.advance(), this._endToken([])) : (t.type = 33, t.sourceSpan = this._cursor.getSpan(e)); }
    _getLetDeclarationName() { let e = this._cursor.clone(), t = !1; return this._attemptCharCodeUntilFn(s => un(s) || s === Zo || s === vn || t && lt(s) ? (t = !0, !1) : !0), this._cursor.getChars(e).trim(); }
    _consumeLetDeclarationValue() { let e = this._cursor.clone(); this._beginToken(31, e), this._attemptUntilIgnoreQuotes(t => t === qe), this._endToken([this._cursor.getChars(e)]); }
    _tokenizeExpansionForm() { if (this.isExpansionFormStart())
        return this._consumeExpansionFormStart(), !0; if (Lv(this._cursor.peek()) && this._isInExpansionForm())
        return this._consumeExpansionCaseStart(), !0; if (this._cursor.peek() === Le) {
        if (this._isInExpansionCase())
            return this._consumeExpansionCaseEnd(), !0;
        if (this._isInExpansionForm())
            return this._consumeExpansionFormEnd(), !0;
    } return !1; }
    _beginToken(e, t = this._cursor.clone()) { this._currentTokenStart = t, this._currentTokenType = e; }
    _endToken(e, t) { if (this._currentTokenStart === null)
        throw new N(this._cursor.getSpan(t), "Programming error - attempted to end a token when there was no start to the token"); if (this._currentTokenType === null)
        throw new N(this._cursor.getSpan(this._currentTokenStart), "Programming error - attempted to end a token which has no token type"); let s = { type: this._currentTokenType, parts: e, sourceSpan: (t ?? this._cursor).getSpan(this._currentTokenStart, this._leadingTriviaCodePoints) }; return this.tokens.push(s), this._currentTokenStart = null, this._currentTokenType = null, s; }
    _createError(e, t) { this._isInExpansionForm() && (e += ` (Do you have an unescaped "{" in your template? Use "{{ '{' }}") to escape it.)`); let s = new N(t, e); return this._currentTokenStart = null, this._currentTokenType = null, s; }
    handleError(e) { if (e instanceof ai && (e = this._createError(e.msg, this._cursor.getSpan(e.cursor))), e instanceof N)
        this.errors.push(e);
    else
        throw e; }
    _attemptCharCode(e) { return this._cursor.peek() === e ? (this._cursor.advance(), !0) : !1; }
    _attemptCharCodeCaseInsensitive(e) { return Bv(this._cursor.peek(), e) ? (this._cursor.advance(), !0) : !1; }
    _requireCharCode(e) { let t = this._cursor.clone(); if (!this._attemptCharCode(e))
        throw this._createError(rs(this._cursor.peek()), this._cursor.getSpan(t)); }
    _attemptStr(e) { let t = e.length; if (this._cursor.charsLeft() < t)
        return !1; let s = this._cursor.clone(); for (let r = 0; r < t; r++)
        if (!this._attemptCharCode(e.charCodeAt(r)))
            return this._cursor = s, !1; return !0; }
    _attemptStrCaseInsensitive(e) { for (let t = 0; t < e.length; t++)
        if (!this._attemptCharCodeCaseInsensitive(e.charCodeAt(t)))
            return !1; return !0; }
    _requireStr(e) { let t = this._cursor.clone(); if (!this._attemptStr(e))
        throw this._createError(rs(this._cursor.peek()), this._cursor.getSpan(t)); }
    _attemptCharCodeUntilFn(e) { for (; !e(this._cursor.peek());)
        this._cursor.advance(); }
    _requireCharCodeUntilFn(e, t) { let s = this._cursor.clone(); if (this._attemptCharCodeUntilFn(e), this._cursor.diff(s) < t)
        throw this._createError(rs(this._cursor.peek()), this._cursor.getSpan(s)); }
    _attemptUntilChar(e) { for (; this._cursor.peek() !== e;)
        this._cursor.advance(); }
    _attemptUntilIgnoreQuotes(e) { for (; this._cursor.peek() !== le;) {
        let t = this._cursor.peek();
        if (e(t))
            break;
        ir(t) && (this._cursor.advance(), this._attemptCharCodeUntilFn(s => s === Dn ? (this._cursor.advance(), !1) : s === t)), this._cursor.advance();
    } }
    _readChar() { let e = String.fromCodePoint(this._cursor.peek()); return this._cursor.advance(), e; }
    _peekStr(e) { let t = e.length; if (this._cursor.charsLeft() < t)
        return !1; let s = this._cursor.clone(); for (let r = 0; r < t; r++) {
        if (s.peek() !== e.charCodeAt(r))
            return !1;
        s.advance();
    } return !0; }
    _isBlockStart() { return this._cursor.peek() === ts && Tv.some(e => this._peekStr(e)); }
    _isLetStart() { return this._cursor.peek() === ts && this._peekStr("@let"); }
    _consumeEntity(e) { this._beginToken(9); let t = this._cursor.clone(); if (this._cursor.advance(), this._attemptCharCode(Xp)) {
        let s = this._attemptCharCode(nh) || this._attemptCharCode(Ld), r = this._cursor.clone();
        if (this._attemptCharCodeUntilFn(Dv), this._cursor.peek() != qe) {
            this._cursor.advance();
            let o = s ? xc.HEX : xc.DEC;
            throw this._createError(kv(o, this._cursor.getChars(t)), this._cursor.getSpan());
        }
        let i = this._cursor.getChars(r);
        this._cursor.advance();
        try {
            let o = parseInt(i, s ? 16 : 10);
            this._endToken([String.fromCodePoint(o), this._cursor.getChars(t)]);
        }
        catch {
            throw this._createError(yu(this._cursor.getChars(t)), this._cursor.getSpan());
        }
    }
    else {
        let s = this._cursor.clone();
        if (this._attemptCharCodeUntilFn(Pv), this._cursor.peek() != qe)
            this._beginToken(e, t), this._cursor = s, this._endToken(["&"]);
        else {
            let r = this._cursor.getChars(s);
            this._cursor.advance();
            let i = Object.hasOwn(oi, r) && oi[r];
            if (!i)
                throw this._createError(yu(r), this._cursor.getSpan(t));
            this._endToken([i, `&${r};`]);
        }
    } }
    _consumeRawText(e, t) { this._beginToken(e ? 6 : 7); let s = []; for (;;) {
        let r = this._cursor.clone(), i = t();
        if (this._cursor = r, i)
            break;
        e && this._cursor.peek() === So ? (this._endToken([this._processCarriageReturns(s.join(""))]), s.length = 0, this._consumeEntity(6), this._beginToken(6)) : s.push(this._readChar());
    } this._endToken([this._processCarriageReturns(s.join(""))]); }
    _consumeComment(e) { this._beginToken(10, e), this._requireCharCode(Eo), this._endToken([]), this._consumeRawText(!1, () => this._attemptStr("-->")), this._beginToken(11), this._requireStr("-->"), this._endToken([]); }
    _consumeCdata(e) { this._beginToken(13, e), this._requireStr("CDATA["), this._endToken([]), this._consumeRawText(!1, () => this._attemptStr("]]>")), this._beginToken(14), this._requireStr("]]>"), this._endToken([]); }
    _consumeDocType(e) { this._beginToken(19, e); let t = this._cursor.clone(); this._attemptUntilChar(De); let s = this._cursor.getChars(t); this._cursor.advance(), this._endToken([s]); }
    _consumeProcessingInstruction(e) { this._beginToken(42, e); let t = this._cursor.clone(); this._attemptUntilIgnoreQuotes(i => i === hs || i === De); let s = this._cursor.peek(), r = this._cursor.getChars(t); this._cursor.advance(), s === hs && this._requireCharCode(De), this._endToken([r]); }
    _consumePrefixAndName(e) { let t = this._cursor.clone(), s = ""; for (; this._cursor.peek() !== bt && !Nv(this._cursor.peek());)
        this._cursor.advance(); let r; this._cursor.peek() === bt ? (s = this._cursor.getChars(t), this._cursor.advance(), r = this._cursor.clone()) : r = t, this._requireCharCodeUntilFn(e, s === "" ? 0 : 1); let i = this._cursor.getChars(r); return [s, i]; }
    _consumeSingleLineComment(e) { let t = this._cursor.clone(); this._attemptCharCodeUntilFn(i => rr(i) || i === le); let s = this._cursor.clone(), r = s.getChars(t); this._beginToken(12, e), this._endToken([r, "single"], s), this._attemptCharCodeUntilFn(K); }
    _consumeMultiLineComment(e) { let t = this._cursor.clone(); this._attemptCharCodeUntilFn(o => { if (o === le)
        return !0; if (o === Ja) {
        let a = this._cursor.clone();
        return a.advance(), a.peek() === Xe;
    } return !1; }); let s = this._cursor.clone(), r = s.getChars(t), i = s; this._attemptStr("*/") && (i = this._cursor.clone(), this._attemptCharCodeUntilFn(K)), this._beginToken(12, e), this._endToken([r, "multi"], i); }
    _consumeTagOpen(e) { let t, s, r, i; try {
        if (this._selectorlessEnabled && Ci(this._cursor.peek()))
            i = this._consumeComponentOpenStart(e), [r, s, t] = i.parts, s && (r += `:${s}`), t && (r += `:${t}`), this._attemptCharCodeUntilFn(K);
        else {
            if (!un(this._cursor.peek()))
                throw this._createError(rs(this._cursor.peek()), this._cursor.getSpan(e));
            i = this._consumeTagOpenStart(e), s = i.parts[0], t = r = i.parts[1], this._attemptCharCodeUntilFn(K);
        }
        for (;;) {
            let a = this._cursor.clone();
            if (this._attemptStr("//")) {
                this._consumeSingleLineComment(a);
                continue;
            }
            if (this._attemptStr("/*")) {
                this._consumeMultiLineComment(a);
                continue;
            }
            if (ku(this._cursor.peek()))
                break;
            if (this._selectorlessEnabled && this._cursor.peek() === ts) {
                let c = this._cursor.clone(), l = c.clone();
                l.advance(), Ci(l.peek()) && this._consumeDirective(c, l);
            }
            else
                this._consumeAttribute();
        }
        i.type === 34 ? this._consumeComponentOpenEnd() : this._consumeTagOpenEnd();
    }
    catch (a) {
        if (a instanceof N) {
            i ? i.type = i.type === 34 ? 38 : 4 : (this._beginToken(5, e), this._endToken(["<"]));
            return;
        }
        throw a;
    } let o = this._getTagDefinition(t).getContentType(s); o === Ct.RAW_TEXT ? this._consumeRawTextWithTagClose(i, r, !1) : o === Ct.ESCAPABLE_RAW_TEXT && this._consumeRawTextWithTagClose(i, r, !0); }
    _consumeRawTextWithTagClose(e, t, s) { this._consumeRawText(s, () => !this._attemptCharCode(ws) || !this._attemptCharCode(Xe) || (this._attemptCharCodeUntilFn(K), !this._attemptStrCaseInsensitive(t)) ? !1 : (this._attemptCharCodeUntilFn(K), this._attemptCharCode(De))), this._beginToken(e.type === 34 ? 37 : 3), this._requireCharCodeUntilFn(r => r === De, 3), this._cursor.advance(), this._endToken(e.parts); }
    _consumeTagOpenStart(e) { this._beginToken(0, e); let t = this._consumePrefixAndName(Sn); return this._endToken(t); }
    _consumeComponentOpenStart(e) { this._beginToken(34, e); let t = this._consumeComponentName(); return this._endToken(t); }
    _consumeComponentName() { let e = this._cursor.clone(); for (; Au(this._cursor.peek());)
        this._cursor.advance(); let t = this._cursor.getChars(e), s = "", r = ""; return this._cursor.peek() === bt && (this._cursor.advance(), [s, r] = this._consumePrefixAndName(Sn)), [t, s, r]; }
    _consumeAttribute() { this._consumeAttributeName(), this._attemptCharCodeUntilFn(K), this._attemptCharCode(Se) && (this._attemptCharCodeUntilFn(K), this._consumeAttributeValue()), this._attemptCharCodeUntilFn(K); }
    _consumeAttributeName() { let e = this._cursor.peek(); if (e === jr || e === Wr)
        throw this._createError(rs(e), this._cursor.getSpan()); this._beginToken(15); let t; if (this._openDirectiveCount > 0) {
        let r = 0;
        t = i => { if (this._openDirectiveCount > 0) {
            if (i === Be)
                r++;
            else if (i === ue) {
                if (r === 0)
                    return !0;
                r--;
            }
        } return Sn(i); };
    }
    else if (e === Tt) {
        let r = 0;
        t = i => (i === Tt ? r++ : i === Ft && r--, r <= 0 ? Sn(i) : rr(i));
    }
    else
        t = Sn; let s = this._consumePrefixAndName(t); this._endToken(s); }
    _consumeAttributeValue() { if (this._cursor.peek() === jr || this._cursor.peek() === Wr) {
        let e = this._cursor.peek();
        this._consumeQuote(e);
        let t = () => this._cursor.peek() === e;
        this._consumeWithInterpolation(17, 18, t, t), this._consumeQuote(e);
    }
    else {
        let e = () => Sn(this._cursor.peek());
        this._consumeWithInterpolation(17, 18, e, e);
    } }
    _consumeQuote(e) { this._beginToken(16), this._requireCharCode(e), this._endToken([String.fromCodePoint(e)]); }
    _consumeTagOpenEnd() { let e = this._attemptCharCode(Xe) ? 2 : 1; this._beginToken(e), this._requireCharCode(De), this._endToken([]); }
    _consumeComponentOpenEnd() { let e = this._attemptCharCode(Xe) ? 36 : 35; this._beginToken(e), this._requireCharCode(De), this._endToken([]); }
    _consumeTagClose(e) { if (this._selectorlessEnabled) {
        let s = e.clone();
        for (; s.peek() !== De && !Ci(s.peek());)
            s.advance();
        if (Ci(s.peek())) {
            this._beginToken(37, e);
            let r = this._consumeComponentName();
            this._attemptCharCodeUntilFn(K), this._requireCharCode(De), this._endToken(r);
            return;
        }
    } this._beginToken(3, e), this._attemptCharCodeUntilFn(K); let t = this._consumePrefixAndName(Sn); this._attemptCharCodeUntilFn(K), this._requireCharCode(De), this._endToken(t); }
    _consumeExpansionFormStart() { this._beginToken(20), this._requireCharCode(pt), this._endToken([]), this._expansionCaseStack.push(20), this._beginToken(7); let e = this._readUntil(_e), t = this._processCarriageReturns(e); if (this._i18nNormalizeLineEndingsInICUs)
        this._endToken([t]);
    else {
        let r = this._endToken([e]);
        t !== e && this.nonNormalizedIcuExpressions.push(r);
    } this._requireCharCode(_e), this._attemptCharCodeUntilFn(K), this._beginToken(7); let s = this._readUntil(_e); this._endToken([s]), this._requireCharCode(_e), this._attemptCharCodeUntilFn(K); }
    _consumeExpansionCaseStart() { this._beginToken(21); let e = this._readUntil(pt).trim(); this._endToken([e]), this._attemptCharCodeUntilFn(K), this._beginToken(22), this._requireCharCode(pt), this._endToken([]), this._attemptCharCodeUntilFn(K), this._expansionCaseStack.push(22); }
    _consumeExpansionCaseEnd() { this._beginToken(23), this._requireCharCode(Le), this._endToken([]), this._attemptCharCodeUntilFn(K), this._expansionCaseStack.pop(); }
    _consumeExpansionFormEnd() { this._beginToken(24), this._requireCharCode(Le), this._endToken([]), this._expansionCaseStack.pop(); }
    _consumeWithInterpolation(e, t, s, r) { this._beginToken(e); let i = []; for (; !s();) {
        let o = this._cursor.clone();
        this._attemptStr(Ws.start) ? (this._endToken([this._processCarriageReturns(i.join(""))], o), i.length = 0, this._consumeInterpolation(t, o, r), this._beginToken(e)) : this._cursor.peek() === So ? (this._endToken([this._processCarriageReturns(i.join(""))]), i.length = 0, this._consumeEntity(e), this._beginToken(e)) : i.push(this._readChar());
    } this._inInterpolation = !1, this._endToken([this._processCarriageReturns(i.join(""))]); }
    _consumeInterpolation(e, t, s) { let r = []; this._beginToken(e, t), r.push(Ws.start); let i = this._cursor.clone(), o = null, a = !1; for (; this._cursor.peek() !== le && (s === null || !s());) {
        let c = this._cursor.clone();
        if (this._isTagStart()) {
            this._cursor = c, r.push(this._getProcessedChars(i, c)), this._endToken(r);
            return;
        }
        if (o === null)
            if (this._attemptStr(Ws.end)) {
                r.push(this._getProcessedChars(i, c)), r.push(Ws.end), this._endToken(r);
                return;
            }
            else
                this._attemptStr("//") && (a = !0);
        let l = this._cursor.peek();
        this._cursor.advance(), l === Dn ? this._cursor.advance() : l === o ? o = null : !a && o === null && ir(l) && (o = l);
    } r.push(this._getProcessedChars(i, this._cursor)), this._endToken(r); }
    _consumeDirective(e, t) { for (this._requireCharCode(ts), this._cursor.advance(); Au(this._cursor.peek());)
        this._cursor.advance(); this._beginToken(39, e); let s = this._cursor.getChars(t); if (this._endToken([s]), this._attemptCharCodeUntilFn(K), this._cursor.peek() === Be) {
        for (this._openDirectiveCount++, this._beginToken(40), this._cursor.advance(), this._endToken([]), this._attemptCharCodeUntilFn(K); !ku(this._cursor.peek()) && this._cursor.peek() !== ue;)
            this._consumeAttribute();
        if (this._attemptCharCodeUntilFn(K), this._openDirectiveCount--, this._cursor.peek() !== ue) {
            if (this._cursor.peek() === De || this._cursor.peek() === Xe)
                return;
            throw this._createError(rs(this._cursor.peek()), this._cursor.getSpan(e));
        }
        this._beginToken(41), this._cursor.advance(), this._endToken([]), this._attemptCharCodeUntilFn(K);
    } }
    _getProcessedChars(e, t) { return this._processCarriageReturns(t.getChars(e)); }
    _isTextEnd() { return !!(this._isTagStart() || this._cursor.peek() === le || this._tokenizeIcu && !this._inInterpolation && (this.isExpansionFormStart() || this._cursor.peek() === Le && this._isInExpansionCase()) || this._tokenizeBlocks && !this._inInterpolation && !this._isInExpansion() && (this._isBlockStart() || this._isLetStart() || this._cursor.peek() === Le)); }
    _isTagStart() { if (this._cursor.peek() === ws) {
        let e = this._cursor.clone();
        e.advance();
        let t = e.peek();
        if (Gn <= t && t <= vi || gn <= t && t <= Rs || t === Xe || t === Za || t === hs)
            return !0;
    } return !1; }
    _readUntil(e) { let t = this._cursor.clone(); return this._attemptUntilChar(e), this._cursor.getChars(t); }
    _isInExpansion() { return this._isInExpansionCase() || this._isInExpansionForm(); }
    _isInExpansionCase() { return this._expansionCaseStack.length > 0 && this._expansionCaseStack[this._expansionCaseStack.length - 1] === 22; }
    _isInExpansionForm() { return this._expansionCaseStack.length > 0 && this._expansionCaseStack[this._expansionCaseStack.length - 1] === 20; }
    isExpansionFormStart() { if (this._cursor.peek() !== pt)
        return !1; let e = this._cursor.clone(), t = this._attemptStr(Ws.start); return this._cursor = e, !t; }
};
function K(n) { return !zr(n) || n === le; }
function Sn(n) { return zr(n) || n === De || n === ws || n === Xe || n === jr || n === Wr || n === Se || n === le; }
function Nv(n) { return (n < Gn || vi < n) && (n < gn || Rs < n) && (n < ml || n > Yp); }
function Dv(n) { return n === qe || n === le || !Rd(n); }
function Pv(n) { return n === qe || n === le || !(un(n) || lt(n)); }
function Lv(n) { return n !== Le; }
function Bv(n, e) { return Cu(n) === Cu(e); }
function Cu(n) { return n >= Gn && n <= vi ? n - Gn + gn : n; }
function $v(n) { return un(n) || lt(n) || n === vn; }
function bu(n) { return n !== qe && K(n); }
function Ci(n) { return n === vn || n >= gn && n <= Rs; }
function Au(n) { return un(n) || lt(n) || n === vn; }
function ku(n) { return n === Xe || n === De || n === ws || n === le; }
function Mv(n) { let e = [], t; for (let s = 0; s < n.length; s++) {
    let r = n[s];
    t && t.type === 5 && r.type === 5 || t && t.type === 17 && r.type === 17 ? (t.parts[0] += r.parts[0], t.sourceSpan.end = r.sourceSpan.end) : (t = r, e.push(t));
} return e; }
var Ro = class n {
    state;
    file;
    input;
    end;
    constructor(e, t) { if (e instanceof n) {
        this.file = e.file, this.input = e.input, this.end = e.end;
        let s = e.state;
        this.state = { peek: s.peek, offset: s.offset, line: s.line, column: s.column };
    }
    else {
        if (!t)
            throw new Error("Programming error: the range argument must be provided with a file argument.");
        this.file = e, this.input = e.content, this.end = t.endPos, this.state = { peek: -1, offset: t.startPos, line: t.startLine, column: t.startCol };
    } }
    clone() { return new n(this); }
    peek() { return this.state.peek; }
    charsLeft() { return this.end - this.state.offset; }
    diff(e) { return this.state.offset - e.state.offset; }
    advance() { this.advanceState(this.state); }
    init() { this.updatePeek(this.state); }
    getSpan(e, t) { e = e || this; let s = e; if (t)
        for (; this.diff(e) > 0 && t.indexOf(e.peek()) !== -1;)
            s === e && (e = e.clone()), e.advance(); let r = this.locationFromCursor(e), i = this.locationFromCursor(this), o = s !== e ? this.locationFromCursor(s) : r; return new D(r, i, o); }
    getChars(e) { return this.input.substring(e.state.offset, this.state.offset); }
    charAt(e) { return this.input.charCodeAt(e); }
    advanceState(e) { if (e.offset >= this.end)
        throw this.state = e, new ai('Unexpected character "EOF"', this); let t = this.charAt(e.offset); t === Nn ? (e.line++, e.column = 0) : rr(t) || e.column++, e.offset++, this.updatePeek(e); }
    updatePeek(e) { e.peek = e.offset >= this.end ? le : this.charAt(e.offset); }
    locationFromCursor(e) { return new Gr(e.file, e.state.offset, e.state.line, e.state.column); }
}, Cc = class n extends Ro {
    internalState;
    constructor(e, t) { e instanceof n ? (super(e), this.internalState = E({}, e.internalState)) : (super(e, t), this.internalState = this.state); }
    advance() { this.state = this.internalState, super.advance(), this.processEscapeSequence(); }
    init() { super.init(), this.processEscapeSequence(); }
    clone() { return new n(this); }
    getChars(e) { let t = e.clone(), s = ""; for (; t.internalState.offset < this.internalState.offset;)
        s += String.fromCodePoint(t.peek()), t.advance(); return s; }
    processEscapeSequence() { let e = () => this.internalState.peek; if (e() === Dn)
        if (this.internalState = E({}, this.state), this.advanceState(this.internalState), e() === Zp)
            this.state.peek = Nn;
        else if (e() === Jp)
            this.state.peek = dl;
        else if (e() === th)
            this.state.peek = jp;
        else if (e() === Kp)
            this.state.peek = fl;
        else if (e() === $d)
            this.state.peek = _d;
        else if (e() === gl)
            this.state.peek = zp;
        else if (e() === eh)
            if (this.advanceState(this.internalState), e() === pt) {
                this.advanceState(this.internalState);
                let t = this.clone(), s = 0;
                for (; e() !== Le;)
                    this.advanceState(this.internalState), s++;
                this.state.peek = this.decodeHexDigits(t, s);
            }
            else {
                let t = this.clone();
                this.advanceState(this.internalState), this.advanceState(this.internalState), this.advanceState(this.internalState), this.state.peek = this.decodeHexDigits(t, 4);
            }
        else if (e() === nh) {
            this.advanceState(this.internalState);
            let t = this.clone();
            this.advanceState(this.internalState), this.state.peek = this.decodeHexDigits(t, 2);
        }
        else if (Kl(e())) {
            let t = "", s = 0, r = this.clone();
            for (; Kl(e()) && s < 3;)
                r = this.clone(), t += String.fromCodePoint(e()), this.advanceState(this.internalState), s++;
            this.state.peek = parseInt(t, 8), this.internalState = r.internalState;
        }
        else
            rr(this.internalState.peek) ? (this.advanceState(this.internalState), this.state = this.internalState) : this.state.peek = this.internalState.peek; }
    decodeHexDigits(e, t) { let s = this.input.slice(e.internalState.offset, e.internalState.offset + t), r = parseInt(s, 16); if (isNaN(r))
        throw e.state = e.internalState, new ai("Invalid hexadecimal escape sequence", e); return r; }
}, ai = class extends Error {
    msg;
    cursor;
    constructor(e, t) { super(e), this.msg = e, this.cursor = t, Object.setPrototypeOf(this, new.target.prototype); }
}, re = class n extends N {
    elementName;
    static create(e, t, s) { return new n(e, t, s); }
    constructor(e, t, s) { super(t, s), this.elementName = e; }
}, Fo = class {
    rootNodes;
    errors;
    constructor(e, t) { this.rootNodes = e, this.errors = t; }
}, Rv = class {
    getTagDefinition;
    constructor(e) { this.getTagDefinition = e; }
    parse(e, t, s) { let r = bv(e, t, this.getTagDefinition, s), i = new bc(r.tokens, this.getTagDefinition); return i.build(), new Fo(i.rootNodes, [...r.errors, ...i.errors]); }
}, bc = class n {
    tokens;
    tagDefinitionResolver;
    _index = -1;
    _peek;
    _containerStack = [];
    rootNodes = [];
    errors = [];
    constructor(e, t) { this.tokens = e, this.tagDefinitionResolver = t, this._advance(); }
    build() { for (; this._peek.type !== 43;)
        this._peek.type === 0 || this._peek.type === 4 ? this._consumeElementStartTag(this._advance()) : this._peek.type === 3 ? this._consumeElementEndTag(this._advance()) : this._peek.type === 13 ? (this._closeVoidElement(), this._consumeCdata(this._advance())) : this._peek.type === 10 ? (this._closeVoidElement(), this._consumeComment(this._advance())) : this._peek.type === 5 || this._peek.type === 7 || this._peek.type === 6 ? (this._closeVoidElement(), this._consumeText(this._advance())) : this._peek.type === 20 ? this._consumeExpansion(this._advance()) : this._peek.type === 25 ? (this._closeVoidElement(), this._consumeBlockOpen(this._advance())) : this._peek.type === 27 ? (this._closeVoidElement(), this._consumeBlockClose(this._advance())) : this._peek.type === 29 ? (this._closeVoidElement(), this._consumeIncompleteBlock(this._advance())) : this._peek.type === 30 ? (this._closeVoidElement(), this._consumeLet(this._advance())) : this._peek.type === 33 ? (this._closeVoidElement(), this._consumeIncompleteLet(this._advance())) : this._peek.type === 34 || this._peek.type === 38 ? this._consumeComponentStartTag(this._advance()) : this._peek.type === 37 ? this._consumeComponentEndTag(this._advance()) : this._advance(); for (let e of this._containerStack)
        e instanceof ut && this.errors.push(re.create(e.name, e.sourceSpan, `Unclosed block "${e.name}"`)); }
    _advance() { let e = this._peek; return this._index < this.tokens.length - 1 && this._index++, this._peek = this.tokens[this._index], e; }
    _advanceIf(e) { return this._peek.type === e ? this._advance() : null; }
    _consumeCdata(e) { this._consumeText(this._advance()), this._advanceIf(14); }
    _consumeComment(e) { let t = this._advanceIf(7), s = this._advanceIf(11), r = t != null ? t.parts[0].trim() : null, i = s == null ? e.sourceSpan : new D(e.sourceSpan.start, s.sourceSpan.end, e.sourceSpan.fullStart); this._addToParent(new ii(r, i)); }
    _consumeExpansion(e) { let t = this._advance(), s = this._advance(), r = []; for (; this._peek.type === 21;) {
        let o = this._parseExpansionCase();
        if (!o)
            return;
        r.push(o);
    } if (this._peek.type !== 24) {
        this.errors.push(re.create(null, this._peek.sourceSpan, "Invalid ICU message. Missing '}'."));
        return;
    } let i = new D(e.sourceSpan.start, this._peek.sourceSpan.end, e.sourceSpan.fullStart); this._addToParent(new Bn(t.parts[0], s.parts[0], r, i, t.sourceSpan)), this._advance(); }
    _parseExpansionCase() { let e = this._advance(); if (this._peek.type !== 22)
        return this.errors.push(re.create(null, this._peek.sourceSpan, "Invalid ICU message. Missing '{'.")), null; let t = this._advance(), s = this._collectExpansionExpTokens(t); if (!s)
        return null; let r = this._advance(); s.push({ type: 43, parts: [], sourceSpan: r.sourceSpan }); let i = new n(s, this.tagDefinitionResolver); if (i.build(), i.errors.length > 0)
        return this.errors = this.errors.concat(i.errors), null; let o = new D(e.sourceSpan.start, r.sourceSpan.end, e.sourceSpan.fullStart), a = new D(t.sourceSpan.start, r.sourceSpan.end, t.sourceSpan.fullStart); return new Bo(e.parts[0], i.rootNodes, o, e.sourceSpan, a); }
    _collectExpansionExpTokens(e) { let t = [], s = [22]; for (;;) {
        if ((this._peek.type === 20 || this._peek.type === 22) && s.push(this._peek.type), this._peek.type === 23)
            if (Tu(s, 22)) {
                if (s.pop(), s.length === 0)
                    return t;
            }
            else
                return this.errors.push(re.create(null, e.sourceSpan, "Invalid ICU message. Missing '}'.")), null;
        if (this._peek.type === 24)
            if (Tu(s, 20))
                s.pop();
            else
                return this.errors.push(re.create(null, e.sourceSpan, "Invalid ICU message. Missing '}'.")), null;
        if (this._peek.type === 43)
            return this.errors.push(re.create(null, e.sourceSpan, "Invalid ICU message. Missing '}'.")), null;
        t.push(this._advance());
    } }
    _consumeText(e) {
        let t = [e], s = e.sourceSpan, r = e.parts[0];
        if (r.length > 0 && r[0] === `
`) {
            let i = this._getContainer();
            i != null && i.children.length === 0 && this._getTagDefinition(i)?.ignoreFirstLf && (r = r.substring(1), t[0] = { type: e.type, sourceSpan: e.sourceSpan, parts: [r] });
        }
        for (; this._peek.type === 8 || this._peek.type === 5 || this._peek.type === 9;)
            e = this._advance(), t.push(e), e.type === 8 ? r += e.parts.join("").replace(/&([^;]+);/g, _u) : e.type === 9 ? r += e.parts[0] : r += e.parts.join("");
        if (r.length > 0) {
            let i = e.sourceSpan;
            this._addToParent(new Jn(r, new D(s.start, i.end, s.fullStart, s.details), t));
        }
    }
    _closeVoidElement() { let e = this._getContainer(); e !== null && this._getTagDefinition(e)?.isVoid && this._containerStack.pop(); }
    _consumeElementStartTag(e) { let t = [], s = [], r = []; this._consumeAttributesAndDirectives(t, s, r); let i = this._getElementFullName(e, this._getClosestElementLikeParent()), o = this._getTagDefinition(i), a = !1; this._peek.type === 2 ? (this._advance(), a = !0, o?.canSelfClose || Oa(i) !== null || o?.isVoid || this.errors.push(re.create(i, e.sourceSpan, `Only void, custom and foreign elements can be self closed "${e.parts[1]}"`))) : this._peek.type === 1 && (this._advance(), a = !1); let c = this._peek.sourceSpan.fullStart, l = new D(e.sourceSpan.start, c, e.sourceSpan.fullStart), p = new D(e.sourceSpan.start, c, e.sourceSpan.fullStart), h = new ct(i, t, s, [], a, l, p, void 0, o?.isVoid ?? !1, void 0, r), d = this._getContainer(), v = d !== null && !!this._getTagDefinition(d)?.isClosedByChild(h.name); this._pushContainer(h, v), a ? this._popContainer(i, ct, l) : e.type === 4 && (this._popContainer(i, ct, null), this.errors.push(re.create(i, l, `Opening tag "${i}" not terminated.`))); }
    _consumeComponentStartTag(e) { let t = e.parts[0], s = [], r = [], i = []; this._consumeAttributesAndDirectives(s, r, i); let o = this._getClosestElementLikeParent(), a = this._getComponentTagName(e, o), c = this._getComponentFullName(e, o), l = this._peek.type === 36; this._advance(); let p = this._peek.sourceSpan.fullStart, h = new D(e.sourceSpan.start, p, e.sourceSpan.fullStart), d = new D(e.sourceSpan.start, p, e.sourceSpan.fullStart), v = new Pe(t, a, c, s, r, [], l, h, d, void 0, void 0, i), w = this._getContainer(), y = w !== null && v.tagName !== null && !!this._getTagDefinition(w)?.isClosedByChild(v.tagName); this._pushContainer(v, y), l ? this._popContainer(c, Pe, h) : e.type === 38 && (this._popContainer(c, Pe, null), this.errors.push(re.create(c, h, `Opening tag "${c}" not terminated.`))); }
    _consumeAttributesAndDirectives(e, t, s) { for (; this._peek.type === 15 || this._peek.type === 39 || this._peek.type === 12;)
        if (this._peek.type === 39)
            t.push(this._consumeDirective(this._peek));
        else if (this._peek.type === 15)
            e.push(this._consumeAttr(this._advance()));
        else {
            let r = this._advance();
            s.push(new wc(r.parts[0], r.parts[1], r.sourceSpan));
        } }
    _consumeComponentEndTag(e) { let t = this._getComponentFullName(e, this._getClosestElementLikeParent()); if (!this._popContainer(t, Pe, e.sourceSpan)) {
        let s = this._containerStack[this._containerStack.length - 1], r;
        s instanceof Pe && s.componentName === e.parts[0] ? r = `, did you mean "${s.fullName}"?` : r = ". It may happen when the tag has already been closed by another tag.";
        let i = `Unexpected closing tag "${t}"${r}`;
        this.errors.push(re.create(t, e.sourceSpan, i));
    } }
    _getTagDefinition(e) { return typeof e == "string" ? this.tagDefinitionResolver(e) : e instanceof ct ? this.tagDefinitionResolver(e.name) : e instanceof Pe && e.tagName !== null ? this.tagDefinitionResolver(e.tagName) : null; }
    _pushContainer(e, t) { t && this._containerStack.pop(), this._addToParent(e), this._containerStack.push(e); }
    _consumeElementEndTag(e) { let t = this._getElementFullName(e, this._getClosestElementLikeParent()); if (this._getTagDefinition(t)?.isVoid)
        this.errors.push(re.create(t, e.sourceSpan, `Void elements do not have end tags "${e.parts[1]}"`));
    else if (!this._popContainer(t, ct, e.sourceSpan)) {
        let s = `Unexpected closing tag "${t}". It may happen when the tag has already been closed by another tag. For more info see https://www.w3.org/TR/html5/syntax.html#closing-elements-that-have-implied-end-tags`;
        this.errors.push(re.create(t, e.sourceSpan, s));
    } }
    _popContainer(e, t, s) { let r = !1; for (let i = this._containerStack.length - 1; i >= 0; i--) {
        let o = this._containerStack[i];
        if (((o instanceof Pe ? o.fullName : o.name) === e || e === null) && o instanceof t)
            return o.endSourceSpan = s, o.sourceSpan.end = s !== null ? s.end : o.sourceSpan.end, this._containerStack.splice(i, this._containerStack.length - i), !r;
        (o instanceof ut || !this._getTagDefinition(o)?.closedByParent) && (r = !0);
    } return !1; }
    _consumeAttr(e) { let t = Ri(e.parts[0], e.parts[1]), s = e.sourceSpan.end; this._peek.type === 16 && this._advance(); let r = "", i = [], o, a; if (this._peek.type === 17)
        for (o = this._peek.sourceSpan, a = this._peek.sourceSpan.end; this._peek.type === 17 || this._peek.type === 18 || this._peek.type === 9;) {
            let p = this._advance();
            i.push(p), p.type === 18 ? r += p.parts.join("").replace(/&([^;]+);/g, _u) : p.type === 9 ? r += p.parts[0] : r += p.parts.join(""), a = s = p.sourceSpan.end;
        } this._peek.type === 16 && (s = this._advance().sourceSpan.end); let l = o && a && new D(o.start, a, o.fullStart); return new vc(t, r, new D(e.sourceSpan.start, s, e.sourceSpan.fullStart), e.sourceSpan, l, i.length > 0 ? i : void 0, void 0); }
    _consumeDirective(e) { let t = [], s = e.sourceSpan.end, r = null; if (this._advance(), this._peek.type === 40) {
        for (s = this._peek.sourceSpan.end, this._advance(); this._peek.type === 15;)
            t.push(this._consumeAttr(this._advance()));
        this._peek.type === 41 ? (r = this._peek.sourceSpan, this._advance()) : this.errors.push(re.create(null, e.sourceSpan, "Unterminated directive definition"));
    } let i = new D(e.sourceSpan.start, s, e.sourceSpan.fullStart), o = new D(i.start, r === null ? e.sourceSpan.end : r.end, i.fullStart); return new Sc(e.parts[0], t, o, i, r); }
    _consumeBlockOpen(e) { let t = []; for (; this._peek.type === 28;) {
        let a = this._advance();
        t.push(new $o(a.parts[0], a.sourceSpan));
    } this._peek.type === 26 && this._advance(); let s = this._peek.sourceSpan.fullStart, r = new D(e.sourceSpan.start, s, e.sourceSpan.fullStart), i = new D(e.sourceSpan.start, s, e.sourceSpan.fullStart), o = new ut(e.parts[0], t, [], r, e.sourceSpan, i); this._pushContainer(o, !1); }
    _consumeBlockClose(e) { let t = this._containerStack.length, s = this._containerStack[t - 1]; if (!this._popContainer(null, ut, e.sourceSpan)) {
        if (this._containerStack.length < t) {
            let r = s instanceof Pe ? s.fullName : s.name;
            this.errors.push(re.create(null, e.sourceSpan, `Unexpected closing block. The block may have been closed earlier. Did you forget to close the <${r}> element? If you meant to write the \`}\` character, you should use the "&#125;" HTML entity instead.`));
            return;
        }
        this.errors.push(re.create(null, e.sourceSpan, 'Unexpected closing block. The block may have been closed earlier. If you meant to write the `}` character, you should use the "&#125;" HTML entity instead.'));
    } }
    _consumeIncompleteBlock(e) { let t = []; for (; this._peek.type === 28;) {
        let a = this._advance();
        t.push(new $o(a.parts[0], a.sourceSpan));
    } let s = this._peek.sourceSpan.fullStart, r = new D(e.sourceSpan.start, s, e.sourceSpan.fullStart), i = new D(e.sourceSpan.start, s, e.sourceSpan.fullStart), o = new ut(e.parts[0], t, [], r, e.sourceSpan, i); this._pushContainer(o, !1), this._popContainer(null, ut, null), this.errors.push(re.create(e.parts[0], r, `Incomplete block "${e.parts[0]}". If you meant to write the @ character, you should use the "&#64;" HTML entity instead.`)); }
    _consumeLet(e) { let t = e.parts[0], s, r; if (this._peek.type !== 31) {
        this.errors.push(re.create(e.parts[0], e.sourceSpan, `Invalid @let declaration "${t}". Declaration must have a value.`));
        return;
    }
    else
        s = this._advance(); if (this._peek.type !== 32) {
        this.errors.push(re.create(e.parts[0], e.sourceSpan, `Unterminated @let declaration "${t}". Declaration must be terminated with a semicolon.`));
        return;
    }
    else
        r = this._advance(); let i = r.sourceSpan.end, o = new D(e.sourceSpan.start, i, e.sourceSpan.fullStart), a = e.sourceSpan.toString().lastIndexOf(t), c = e.sourceSpan.start.moveBy(a), l = new D(c, e.sourceSpan.end), p = new Mo(t, s.parts[0], o, l, s.sourceSpan); this._addToParent(p); }
    _consumeIncompleteLet(e) { let t = e.parts[0] ?? "", s = t ? ` "${t}"` : ""; if (t.length > 0) {
        let r = e.sourceSpan.toString().lastIndexOf(t), i = e.sourceSpan.start.moveBy(r), o = new D(i, e.sourceSpan.end), a = new D(e.sourceSpan.start, e.sourceSpan.start.moveBy(0)), c = new Mo(t, "", e.sourceSpan, o, a);
        this._addToParent(c);
    } this.errors.push(re.create(e.parts[0], e.sourceSpan, `Incomplete @let declaration${s}. @let declarations must be written as \`@let <name> = <value>;\``)); }
    _getContainer() { return this._containerStack.length > 0 ? this._containerStack[this._containerStack.length - 1] : null; }
    _getClosestElementLikeParent() { for (let e = this._containerStack.length - 1; e > -1; e--) {
        let t = this._containerStack[e];
        if (t instanceof ct || t instanceof Pe)
            return t;
    } return null; }
    _addToParent(e) { let t = this._getContainer(); t === null ? this.rootNodes.push(e) : t.children.push(e); }
    _getElementFullName(e, t) { let s = this._getPrefix(e, t); return Ri(s, e.parts[1]); }
    _getComponentFullName(e, t) { let s = e.parts[0], r = this._getComponentTagName(e, t); return r === null ? s : r.startsWith(":") ? s + r : `${s}:${r}`; }
    _getComponentTagName(e, t) { let s = this._getPrefix(e, t), r = e.parts[2]; return !s && !r ? null : !s && r ? r : Ri(s, r || "ng-component"); }
    _getPrefix(e, t) { let s, r; if (e.type === 34 || e.type === 38 || e.type === 37 ? (s = e.parts[1], r = e.parts[2]) : (s = e.parts[0], r = e.parts[1]), s = s || this._getTagDefinition(r)?.implicitNamespacePrefix || "", !s && t) {
        let i = t instanceof ct ? t.name : t.tagName;
        if (i !== null) {
            let o = be(i)[1], a = this._getTagDefinition(o);
            a !== null && !a.preventNamespaceInheritance && (s = Oa(i));
        }
    } return s; }
};
function Tu(n, e) { return n.length > 0 && n[n.length - 1] === e; }
function _u(n, e) { return oi[e] !== void 0 ? oi[e] || n : /^#x[a-f0-9]+$/i.test(e) ? String.fromCodePoint(parseInt(e.slice(2), 16)) : /^#\d+$/.test(e) ? String.fromCodePoint(parseInt(e.slice(1), 10)) : n; }
var bh = "ngPreserveWhitespaces", Iu = new Set(["pre", "template", "textarea", "script", "style"]), Ah = ` \f
\r	\v\u1680\u180E\u2000-\u200A\u2028\u2029\u202F\u205F\u3000\uFEFF`, Fv = new RegExp(`[^${Ah}]`), Ov = new RegExp(`[${Ah}]{2,}`, "g");
function Nu(n) { return n.some(e => e.name === bh); }
function kh(n) { return n.replace(new RegExp(Ch, "g"), " "); }
var Oo = class {
    preserveSignificantWhitespace;
    originalNodeMap;
    requireContext;
    icuExpansionDepth = 0;
    constructor(e, t, s = !0) { this.preserveSignificantWhitespace = e, this.originalNodeMap = t, this.requireContext = s; }
    visitElement(e, t) { if (Iu.has(e.name) || Nu(e.attrs)) {
        let r = new ct(e.name, Et(this, e.attrs), Et(this, e.directives), e.children, e.isSelfClosing, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, e.isVoid, e.i18n, e.comments);
        return this.originalNodeMap?.set(r, e), r;
    } let s = new ct(e.name, e.attrs, e.directives, Et(this, e.children), e.isSelfClosing, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, e.isVoid, e.i18n, e.comments); return this.originalNodeMap?.set(s, e), s; }
    visitAttribute(e, t) { return e.name !== bh ? e : null; }
    visitText(e, t) { let s = e.value.match(Fv), r = t && (t.prev instanceof Bn || t.next instanceof Bn); if (this.icuExpansionDepth > 0 && this.preserveSignificantWhitespace)
        return e; if (s || r) {
        let o = e.tokens.map(p => p.type === 5 ? Uv(p) : p);
        if (!this.preserveSignificantWhitespace && o.length > 0) {
            let p = o[0];
            o.splice(0, 1, Vv(p, t));
            let h = o[o.length - 1];
            o.splice(o.length - 1, 1, qv(h, t));
        }
        let a = _h(e.value), c = this.preserveSignificantWhitespace ? a : Hv(a, t), l = new Jn(c, e.sourceSpan, o, e.i18n);
        return this.originalNodeMap?.set(l, e), l;
    } return null; }
    visitComment(e, t) { return e; }
    visitExpansion(e, t) { this.icuExpansionDepth++; let s; try {
        s = new Bn(e.switchValue, e.type, Et(this, e.cases), e.sourceSpan, e.switchValueSourceSpan, e.i18n);
    }
    finally {
        this.icuExpansionDepth--;
    } return this.originalNodeMap?.set(s, e), s; }
    visitExpansionCase(e, t) { let s = new Bo(e.value, Et(this, e.expression), e.sourceSpan, e.valueSourceSpan, e.expSourceSpan); return this.originalNodeMap?.set(s, e), s; }
    visitBlock(e, t) { let s = new ut(e.name, e.parameters, Et(this, e.children), e.sourceSpan, e.nameSpan, e.startSourceSpan, e.endSourceSpan); return this.originalNodeMap?.set(s, e), s; }
    visitBlockParameter(e, t) { return e; }
    visitLetDeclaration(e, t) { return e; }
    visitComponent(e, t) { if (e.tagName && Iu.has(e.tagName) || Nu(e.attrs)) {
        let r = new Pe(e.componentName, e.tagName, e.fullName, Et(this, e.attrs), Et(this, e.directives), e.children, e.isSelfClosing, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, e.i18n, e.comments);
        return this.originalNodeMap?.set(r, e), r;
    } let s = new Pe(e.componentName, e.tagName, e.fullName, e.attrs, e.directives, Et(this, e.children), e.isSelfClosing, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, e.i18n, e.comments); return this.originalNodeMap?.set(s, e), s; }
    visitDirective(e, t) { return e; }
    visit(e, t) { if (this.requireContext && !t)
        throw new Error("WhitespaceVisitor requires context. Visit via `visitAllWithSiblings` to get this context."); return !1; }
};
function Vv(n, e) { return n.type !== 5 || !!e?.prev ? n : Th(n, s => s.trimStart()); }
function qv(n, e) { return n.type !== 5 || !!e?.next ? n : Th(n, s => s.trimEnd()); }
function Hv(n, e) { let t = !e?.prev, s = !e?.next, r = t ? n.trimStart() : n; return s ? r.trimEnd() : r; }
function Uv({ type: n, parts: e, sourceSpan: t }) { return { type: n, parts: [_h(e[0])], sourceSpan: t }; }
function Th({ type: n, parts: e, sourceSpan: t }, s) { return { type: n, parts: [s(e[0])], sourceSpan: t }; }
function _h(n) { return kh(n).replace(Ov, " "); }
function Et(n, e) { let t = []; return e.forEach((s, r) => { let i = { prev: e[r - 1], next: e[r + 1] }, o = s.visit(n, i); o && t.push(o); }), t; }
var L = (function (n) { return n[n.Character = 0] = "Character", n[n.Identifier = 1] = "Identifier", n[n.PrivateIdentifier = 2] = "PrivateIdentifier", n[n.Keyword = 3] = "Keyword", n[n.String = 4] = "String", n[n.Operator = 5] = "Operator", n[n.Number = 6] = "Number", n[n.RegExpBody = 7] = "RegExpBody", n[n.RegExpFlags = 8] = "RegExpFlags", n[n.Error = 9] = "Error", n; })(L || {}), $n = (function (n) { return n[n.Plain = 0] = "Plain", n[n.TemplateLiteralPart = 1] = "TemplateLiteralPart", n[n.TemplateLiteralEnd = 2] = "TemplateLiteralEnd", n; })($n || {}), Wv = ["var", "let", "as", "null", "undefined", "true", "false", "if", "else", "this", "typeof", "void", "in", "instanceof"], ci = class {
    tokenize(e) { return new Ac(e).scan(); }
}, it = class {
    index;
    end;
    type;
    numValue;
    strValue;
    constructor(e, t, s, r, i) { this.index = e, this.end = t, this.type = s, this.numValue = r, this.strValue = i; }
    isCharacter(e) { return this.type === L.Character && this.numValue === e; }
    isNumber() { return this.type === L.Number; }
    isString() { return this.type === L.String; }
    isOperator(e) { return this.type === L.Operator && this.strValue === e; }
    isIdentifier() { return this.type === L.Identifier; }
    isPrivateIdentifier() { return this.type === L.PrivateIdentifier; }
    isKeyword() { return this.type === L.Keyword; }
    isKeywordLet() { return this.type === L.Keyword && this.strValue === "let"; }
    isKeywordAs() { return this.type === L.Keyword && this.strValue === "as"; }
    isKeywordNull() { return this.type === L.Keyword && this.strValue === "null"; }
    isKeywordUndefined() { return this.type === L.Keyword && this.strValue === "undefined"; }
    isKeywordTrue() { return this.type === L.Keyword && this.strValue === "true"; }
    isKeywordFalse() { return this.type === L.Keyword && this.strValue === "false"; }
    isKeywordThis() { return this.type === L.Keyword && this.strValue === "this"; }
    isKeywordTypeof() { return this.type === L.Keyword && this.strValue === "typeof"; }
    isKeywordVoid() { return this.type === L.Keyword && this.strValue === "void"; }
    isKeywordIn() { return this.type === L.Keyword && this.strValue === "in"; }
    isKeywordInstanceOf() { return this.type === L.Keyword && this.strValue === "instanceof"; }
    isError() { return this.type === L.Error; }
    isRegExpBody() { return this.type === L.RegExpBody; }
    isRegExpFlags() { return this.type === L.RegExpFlags; }
    toNumber() { return this.type === L.Number ? this.numValue : -1; }
    isTemplateLiteralPart() { return this.isString() && this.kind === $n.TemplateLiteralPart; }
    isTemplateLiteralEnd() { return this.isString() && this.kind === $n.TemplateLiteralEnd; }
    isTemplateLiteralInterpolationStart() { return this.isOperator("${"); }
    toString() { switch (this.type) {
        case L.Character:
        case L.Identifier:
        case L.Keyword:
        case L.Operator:
        case L.PrivateIdentifier:
        case L.String:
        case L.Error:
        case L.RegExpBody:
        case L.RegExpFlags: return this.strValue;
        case L.Number: return this.numValue.toString();
        default: return null;
    } }
}, or = class extends it {
    kind;
    constructor(e, t, s, r) { super(e, t, L.String, 0, s), this.kind = r; }
};
function js(n, e, t) { return new it(n, e, L.Character, t, String.fromCharCode(t)); }
function jv(n, e, t) { return new it(n, e, L.Identifier, 0, t); }
function zv(n, e, t) { return new it(n, e, L.PrivateIdentifier, 0, t); }
function Gv(n, e, t) { return new it(n, e, L.Keyword, 0, t); }
function Xt(n, e, t) { return new it(n, e, L.Operator, 0, t); }
function Xv(n, e, t) { return new it(n, e, L.Number, t, ""); }
function Qv(n, e, t) { return new it(n, e, L.Error, 0, t); }
function Yv(n, e, t) { return new it(n, e, L.RegExpBody, 0, t); }
function Zv(n, e, t) { return new it(n, e, L.RegExpFlags, 0, t); }
var zs = new it(-1, -1, L.Character, 0, ""), Ac = class {
    input;
    tokens = [];
    length;
    peek = 0;
    index = -1;
    braceStack = [];
    constructor(e) { this.input = e, this.length = e.length, this.advance(); }
    scan() { let e = this.scanToken(); for (; e !== null;)
        this.tokens.push(e), e = this.scanToken(); return this.tokens; }
    advance() { this.peek = ++this.index >= this.length ? le : this.input.charCodeAt(this.index); }
    scanToken() { let e = this.input, t = this.length, s = this.peek, r = this.index; for (; s <= Gp;)
        if (++r >= t) {
            s = le;
            break;
        }
        else
            s = e.charCodeAt(r); if (this.peek = s, this.index = r, r >= t)
        return null; if (Du(s))
        return this.scanIdentifier(); if (lt(s))
        return this.scanNumber(r); let i = r; switch (s) {
        case En: return this.advance(), lt(this.peek) ? this.scanNumber(i) : this.peek !== En ? js(i, this.index, En) : (this.advance(), this.peek === En ? (this.advance(), Xt(i, this.index, "...")) : this.error(`Unexpected character [${String.fromCharCode(s)}]`, 0));
        case Be:
        case ue:
        case Tt:
        case Ft:
        case _e:
        case bt:
        case qe: return this.scanCharacter(i, s);
        case pt: return this.scanOpenBrace(i, s);
        case Le: return this.scanCloseBrace(i, s);
        case jr:
        case Wr: return this.scanString();
        case Ka: return this.advance(), this.scanTemplateLiteralPart(i);
        case Xp: return this.scanPrivateIdentifier();
        case Qp: return this.scanComplexOperator(i, "+", Se, "=");
        case Eo: return this.scanComplexOperator(i, "-", Se, "=");
        case Xe: return this.isStartOfRegex() ? this.scanRegex(r) : this.scanComplexOperator(i, "/", Se, "=");
        case Id: return this.scanComplexOperator(i, "%", Se, "=");
        case Bd: return this.scanOperator(i, "^");
        case Ja: return this.scanStar(i);
        case hs: return this.scanQuestion(i);
        case ws:
        case De: return this.scanComplexOperator(i, String.fromCharCode(s), Se, "=");
        case Za: return this.scanComplexOperator(i, "!", Se, "=", Se, "=");
        case Se: return this.scanEquals(i);
        case So: return this.scanComplexOperator(i, "&", So, "&", Se, "=");
        case Jl: return this.scanComplexOperator(i, "|", Jl, "|", Se, "=");
        case sh:
            for (; zr(this.peek);)
                this.advance();
            return this.scanToken();
    } return this.advance(), this.error(`Unexpected character [${String.fromCharCode(s)}]`, 0); }
    scanCharacter(e, t) { return this.advance(), js(e, this.index, t); }
    scanOperator(e, t) { return this.advance(), Xt(e, this.index, t); }
    scanOpenBrace(e, t) { return this.braceStack.push("expression"), this.advance(), js(e, this.index, t); }
    scanCloseBrace(e, t) { return this.advance(), this.braceStack.pop() === "interpolation" ? (this.tokens.push(js(e, this.index, Le)), this.scanTemplateLiteralPart(this.index)) : js(e, this.index, t); }
    scanComplexOperator(e, t, s, r, i, o) { this.advance(); let a = t; return this.peek == s && (this.advance(), a += r), i != null && this.peek == i && (this.advance(), a += o), Xt(e, this.index, a); }
    scanEquals(e) { this.advance(); let t = "="; if (this.peek === Se)
        this.advance(), t += "=";
    else if (this.peek === De)
        return this.advance(), t += ">", Xt(e, this.index, t); return this.peek === Se && (this.advance(), t += "="), Xt(e, this.index, t); }
    scanIdentifier() { let e = this.index; for (this.advance(); Pu(this.peek);)
        this.advance(); let t = this.input.substring(e, this.index); return Wv.indexOf(t) > -1 ? Gv(e, this.index, t) : jv(e, this.index, t); }
    scanPrivateIdentifier() { let e = this.index; if (this.advance(), !Du(this.peek))
        return this.error("Invalid character [#]", -1); for (; Pu(this.peek);)
        this.advance(); let t = this.input.substring(e, this.index); return zv(e, this.index, t); }
    scanNumber(e) { let t = this.index === e, s = !1; for (this.advance();;) {
        if (!lt(this.peek))
            if (this.peek === vn) {
                if (!lt(this.input.charCodeAt(this.index - 1)) || !lt(this.input.charCodeAt(this.index + 1)))
                    return this.error("Invalid numeric separator", 0);
                s = !0;
            }
            else if (this.peek === En)
                t = !1;
            else if (Jv(this.peek)) {
                if (this.advance(), Kv(this.peek) && this.advance(), !lt(this.peek))
                    return this.error("Invalid exponent", -1);
                t = !1;
            }
            else
                break;
        this.advance();
    } let r = this.input.substring(e, this.index); s && (r = r.replace(/_/g, "")); let i = t ? tw(r) : parseFloat(r); return Xv(e, this.index, i); }
    scanString() { let e = this.index, t = this.peek; this.advance(); let s = "", r = this.index, i = this.input; for (; this.peek != t;)
        if (this.peek == Dn) {
            let a = this.scanStringBackslash(s, r);
            if (typeof a != "string")
                return a;
            s = a, r = this.index;
        }
        else {
            if (this.peek == le)
                return this.error("Unterminated quote", 0);
            this.advance();
        } let o = i.substring(r, this.index); return this.advance(), new or(e, this.index, s + o, $n.Plain); }
    scanQuestion(e) { this.advance(); let t = "?"; return this.peek === hs ? (t += "?", this.advance(), this.peek === Se && (t += "=", this.advance())) : this.peek === En && (t += ".", this.advance()), Xt(e, this.index, t); }
    scanTemplateLiteralPart(e) { let t = "", s = this.index; for (; this.peek !== Ka;)
        if (this.peek === Dn) {
            let i = this.scanStringBackslash(t, s);
            if (typeof i != "string")
                return i;
            t = i, s = this.index;
        }
        else if (this.peek === Zo) {
            let i = this.index;
            if (this.advance(), this.peek === pt)
                return this.braceStack.push("interpolation"), this.tokens.push(new or(e, i, t + this.input.substring(s, i), $n.TemplateLiteralPart)), this.advance(), Xt(i, this.index, this.input.substring(i, this.index));
        }
        else {
            if (this.peek === le)
                return this.error("Unterminated template literal", 0);
            this.advance();
        } let r = this.input.substring(s, this.index); return this.advance(), new or(e, this.index, t + r, $n.TemplateLiteralEnd); }
    error(e, t) { let s = this.index + t; return Qv(s, this.index, `Lexer Error: ${e} at column ${s} in expression [${this.input}]`); }
    scanStringBackslash(e, t) { e += this.input.substring(t, this.index); let s; if (this.advance(), this.peek === eh) {
        let r = this.input.substring(this.index + 1, this.index + 5);
        if (/^[0-9a-f]+$/i.test(r))
            s = parseInt(r, 16);
        else
            return this.error(`Invalid unicode escape [\\u${r}]`, 0);
        for (let i = 0; i < 5; i++)
            this.advance();
    }
    else
        s = ew(this.peek), this.advance(); return e += String.fromCharCode(s), e; }
    scanStar(e) { this.advance(); let t = "*"; return this.peek === Ja ? (t += "*", this.advance(), this.peek === Se && (t += "=", this.advance())) : this.peek === Se && (t += "=", this.advance()), Xt(e, this.index, t); }
    isStartOfRegex() { if (this.tokens.length === 0)
        return !0; let e = this.tokens[this.tokens.length - 1]; if (e.isOperator("!")) {
        let t = this.tokens.length > 1 ? this.tokens[this.tokens.length - 2] : null;
        return t === null || t.type !== L.Identifier && !t.isCharacter(ue) && !t.isCharacter(Ft);
    } return e.type === L.Operator || e.isCharacter(Be) || e.isCharacter(Tt) || e.isCharacter(_e) || e.isCharacter(bt); }
    scanRegex(e) { this.advance(); let t = this.index, s = !1, r = !1; for (;;) {
        let c = this.peek;
        if (c === le)
            return this.error("Unterminated regular expression", 0);
        if (s)
            s = !1;
        else if (c === Dn)
            s = !0;
        else if (c === Tt)
            r = !0;
        else if (c === Ft)
            r = !1;
        else if (c === Xe && !r)
            break;
        this.advance();
    } let i = this.input.substring(t, this.index); this.advance(); let o = Yv(e, this.index, i), a = this.scanRegexFlags(this.index); return a !== null ? (this.tokens.push(o), a) : o; }
    scanRegexFlags(e) { if (!un(this.peek))
        return null; for (; un(this.peek);)
        this.advance(); return Zv(e, this.index, this.input.substring(e, this.index)); }
};
function Du(n) { return Gn <= n && n <= vi || gn <= n && n <= Rs || n == vn || n == Zo; }
function Pu(n) { return un(n) || lt(n) || n == vn || n == Zo; }
function Jv(n) { return n == Md || n == Dd; }
function Kv(n) { return n == Eo || n == Qp; }
function ew(n) { switch (n) {
    case Zp: return Nn;
    case gl: return zp;
    case Jp: return dl;
    case Kp: return fl;
    case th: return jp;
    default: return n;
} }
function tw(n) { let e = parseInt(n); if (isNaN(e))
    throw new Error("Invalid integer literal when parsing " + n); return e; }
var kc = class {
    strings;
    expressions;
    offsets;
    constructor(e, t, s) { this.strings = e, this.expressions = t, this.offsets = s; }
}, Tc = class {
    templateBindings;
    warnings;
    errors;
    constructor(e, t, s) { this.templateBindings = e, this.warnings = t, this.errors = s; }
};
function Kt(n) { return n.start.toString() || "(unknown)"; }
var Vo = class {
    _lexer;
    _supportsDirectPipeReferences;
    constructor(e, t = !1) { this._lexer = e, this._supportsDirectPipeReferences = t; }
    parseAction(e, t, s) { let r = []; this._checkNoInterpolation(r, e, t); let { stripped: i } = this._stripComments(e), o = this._lexer.tokenize(i), a = new Cn(e, t, s, o, 1, r, 0, this._supportsDirectPipeReferences).parseChain(); return new Ue(a, e, Kt(t), s, r); }
    parseBinding(e, t, s) { let r = [], i = this._parseBindingAst(e, t, s, r); return new Ue(i, e, Kt(t), s, r); }
    checkSimpleExpression(e) { let t = new _c; return e.visit(t), t.errors; }
    parseSimpleBinding(e, t, s) { let r = [], i = this._parseBindingAst(e, t, s, r), o = this.checkSimpleExpression(i); return o.length > 0 && r.push(ms(`Host binding expression cannot contain ${o.join(" ")}`, e, "", t)), new Ue(i, e, Kt(t), s, r); }
    _parseBindingAst(e, t, s, r) { this._checkNoInterpolation(r, e, t); let { stripped: i } = this._stripComments(e), o = this._lexer.tokenize(i); return new Cn(e, t, s, o, 0, r, 0, this._supportsDirectPipeReferences).parseChain(); }
    parseTemplateBindings(e, t, s, r, i) { let o = this._lexer.tokenize(t), a = []; return new Cn(t, s, i, o, 0, a, 0, this._supportsDirectPipeReferences).parseTemplateBindings({ source: e, span: new Ke(r, r + e.length) }); }
    parseInterpolation(e, t, s, r) { let i = [], { strings: o, expressions: a, offsets: c } = this.splitInterpolation(e, t, i, r); if (a.length === 0)
        return null; let l = []; for (let p = 0; p < a.length; ++p) {
        let h = r?.[p * 2 + 1]?.sourceSpan, d = a[p].text, { stripped: v, hasComments: w } = this._stripComments(d), y = this._lexer.tokenize(v);
        if (w && v.trim().length === 0 && y.length === 0) {
            i.push(ms("Interpolation expression cannot only contain a comment", e, `at column ${a[p].start} in`, t));
            continue;
        }
        let b = new Cn(h ? d : e, h || t, s, y, 0, i, c[p], this._supportsDirectPipeReferences).parseChain();
        l.push(b);
    } return this.createInterpolationAst(o.map(p => p.text), l, e, Kt(t), s, i); }
    parseInterpolationExpression(e, t, s) { let { stripped: r } = this._stripComments(e), i = this._lexer.tokenize(r), o = [], a = new Cn(e, t, s, i, 0, o, 0, this._supportsDirectPipeReferences).parseChain(), c = ["", ""]; return this.createInterpolationAst(c, [a], e, Kt(t), s, o); }
    createInterpolationAst(e, t, s, r, i, o) { let a = new Hn(0, s.length), c = new mi(a, a.toAbsolute(i), e, t); return new Ue(c, s, r, i, o); }
    splitInterpolation(e, t, s, r) { let i = [], o = [], a = [], c = r ? nw(r) : null, l = 0, p = !1, h = !1, d = "{{", v = "}}"; for (; l < e.length;)
        if (p) {
            let w = l, y = w + d.length, b = this._getInterpolationEndIndex(e, v, y);
            if (b === -1) {
                p = !1, h = !0;
                break;
            }
            let T = b + v.length, $ = e.substring(y, b);
            $.trim().length === 0 && s.push(ms("Blank expressions are not allowed in interpolated strings", e, `at column ${l} in`, t)), o.push({ text: $, start: w, end: T });
            let J = (c?.get(w) ?? w) + d.length;
            a.push(J), l = T, p = !1;
        }
        else {
            let w = l;
            l = e.indexOf(d, l), l === -1 && (l = e.length);
            let y = e.substring(w, l);
            i.push({ text: y, start: w, end: l }), p = !0;
        } if (!p)
        if (h) {
            let w = i[i.length - 1];
            w.text += e.substring(l), w.end = e.length;
        }
        else
            i.push({ text: e.substring(l), start: l, end: e.length }); return new kc(i, o, a); }
    wrapLiteralPrimitive(e, t, s) { let r = new Hn(0, e == null ? 0 : e.length); return new Ue(new Qe(r, r.toAbsolute(s), e), e, typeof t == "string" ? t : Kt(t), s, []); }
    _stripComments(e) { let t = this._commentStart(e); return t != null ? { stripped: e.substring(0, t), hasComments: !0 } : { stripped: e, hasComments: !1 }; }
    _commentStart(e) { let t = null; for (let s = 0; s < e.length - 1; s++) {
        let r = e.charCodeAt(s), i = e.charCodeAt(s + 1);
        if (r === Xe && i == Xe && t == null)
            return s;
        t === r ? t = null : t == null && ir(r) && (t = r);
    } return null; }
    _checkNoInterpolation(e, t, s) { let r = -1, i = -1; for (let o of this._forEachUnquotedChar(t, 0))
        if (r === -1)
            t.startsWith("{{") && (r = o);
        else if (i = this._getInterpolationEndIndex(t, "}}", o), i > -1)
            break; r > -1 && i > -1 && e.push(ms("Got interpolation ({{}}) where expression was expected", t, `at column ${r} in`, s)); }
    _getInterpolationEndIndex(e, t, s) { for (let r of this._forEachUnquotedChar(e, s)) {
        if (e.startsWith(t, r))
            return r;
        if (e.startsWith("//", r))
            return e.indexOf(t, r);
    } return -1; }
    *_forEachUnquotedChar(e, t) { let s = null, r = 0; for (let i = t; i < e.length; i++) {
        let o = e[i];
        ir(e.charCodeAt(i)) && (s === null || s === o) && r % 2 === 0 ? s = s === null ? o : null : s === null && (yield i), r = o === "\\" ? r + 1 : 0;
    } }
}, er = (function (n) { return n[n.None = 0] = "None", n[n.Writable = 1] = "Writable", n; })(er || {}), Lu = new Set(["d", "g", "i", "m", "s", "u", "v", "y"]), Cn = class {
    input;
    parseSourceSpan;
    absoluteOffset;
    tokens;
    parseFlags;
    errors;
    offset;
    supportsDirectPipeReferences;
    rparensExpected = 0;
    rbracketsExpected = 0;
    rbracesExpected = 0;
    context = er.None;
    sourceSpanCache = new Map;
    index = 0;
    constructor(e, t, s, r, i, o, a, c) { this.input = e, this.parseSourceSpan = t, this.absoluteOffset = s, this.tokens = r, this.parseFlags = i, this.errors = o, this.offset = a, this.supportsDirectPipeReferences = c; }
    peek(e) { let t = this.index + e; return t < this.tokens.length ? this.tokens[t] : zs; }
    get next() { return this.peek(0); }
    get atEOF() { return this.index >= this.tokens.length; }
    get inputIndex() { return this.atEOF ? this.currentEndIndex : this.next.index + this.offset; }
    get currentEndIndex() { return this.index > 0 ? this.peek(-1).end + this.offset : this.tokens.length === 0 ? this.input.length + this.offset : this.next.index + this.offset; }
    get currentAbsoluteOffset() { return this.absoluteOffset + this.inputIndex; }
    span(e, t) { let s = this.currentEndIndex; if (t !== void 0 && t > this.currentEndIndex && (s = t), e > s) {
        let r = s;
        s = e, e = r;
    } return new Hn(e, s); }
    sourceSpan(e, t) { let s = `${e}@${this.inputIndex}:${t}`; return this.sourceSpanCache.has(s) || this.sourceSpanCache.set(s, this.span(e, t).toAbsolute(this.absoluteOffset)), this.sourceSpanCache.get(s); }
    advance() { this.index++; }
    withContext(e, t) { this.context |= e; let s = t(); return this.context ^= e, s; }
    consumeOptionalCharacter(e) { return this.next.isCharacter(e) ? (this.advance(), !0) : !1; }
    peekKeywordLet() { return this.next.isKeywordLet(); }
    peekKeywordAs() { return this.next.isKeywordAs(); }
    expectCharacter(e) { this.consumeOptionalCharacter(e) || this.error(`Missing expected ${String.fromCharCode(e)}`); }
    consumeOptionalOperator(e) { return this.next.isOperator(e) ? (this.advance(), !0) : !1; }
    isAssignmentOperator(e) { return e.type === L.Operator && Ne.isAssignmentOperation(e.strValue); }
    expectOperator(e) { this.consumeOptionalOperator(e) || this.error(`Missing expected operator ${e}`); }
    prettyPrintToken(e) { return e === zs ? "end of input" : `token ${e}`; }
    expectIdentifierOrKeyword() { let e = this.next; return !e.isIdentifier() && !e.isKeyword() ? (e.isPrivateIdentifier() ? this._reportErrorForPrivateIdentifier(e, "expected identifier or keyword") : this.error(`Unexpected ${this.prettyPrintToken(e)}, expected identifier or keyword`), null) : (this.advance(), e.toString()); }
    expectIdentifierOrKeywordOrString() { let e = this.next; return !e.isIdentifier() && !e.isKeyword() && !e.isString() ? (e.isPrivateIdentifier() ? this._reportErrorForPrivateIdentifier(e, "expected identifier, keyword or string") : this.error(`Unexpected ${this.prettyPrintToken(e)}, expected identifier, keyword, or string`), "") : (this.advance(), e.toString()); }
    parseChain() { let e = [], t = this.inputIndex; for (; this.index < this.tokens.length;) {
        let s = this.parsePipe();
        if (e.push(s), this.consumeOptionalCharacter(qe))
            for (this.parseFlags & 1 || this.error("Binding expression cannot contain chained expression"); this.consumeOptionalCharacter(qe);)
                ;
        else if (this.index < this.tokens.length) {
            let r = this.index;
            if (this.error(`Unexpected token '${this.next}'`), this.index === r)
                break;
        }
    } if (e.length === 0) {
        let s = this.offset, r = this.offset + this.input.length;
        return new Te(this.span(s, r), this.sourceSpan(s, r));
    } return e.length == 1 ? e[0] : new bs(this.span(t), this.sourceSpan(t), e); }
    parsePipe() { let e = this.inputIndex, t = this.parseExpression(); if (this.consumeOptionalOperator("|")) {
        this.parseFlags & 1 && this.error("Cannot have a pipe in an action expression");
        do {
            let s = this.inputIndex, r = this.expectIdentifierOrKeyword(), i, o;
            r !== null ? i = this.sourceSpan(s) : (r = "", o = this.next.index !== -1 ? this.next.index : this.input.length + this.offset, i = new Hn(o, o).toAbsolute(this.absoluteOffset));
            let a = [];
            for (; this.consumeOptionalCharacter(bt);)
                a.push(this.parseExpression());
            let c;
            if (this.supportsDirectPipeReferences) {
                let l = r.charCodeAt(0);
                c = l === vn || l >= gn && l <= Rs ? Mi.ReferencedDirectly : Mi.ReferencedByName;
            }
            else
                c = Mi.ReferencedByName;
            t = new so(this.span(e), this.sourceSpan(e, o), t, r, a, c, i);
        } while (this.consumeOptionalOperator("|"));
    } return t; }
    parseExpression() { return this.parseConditional(); }
    parseConditional() { let e = this.inputIndex, t = this.parseLogicalOr(); if (this.consumeOptionalOperator("?")) {
        let s = this.parsePipe(), r;
        if (this.consumeOptionalCharacter(bt))
            r = this.parsePipe();
        else {
            let i = this.inputIndex, o = this.input.substring(e, i);
            this.error(`Conditional expression ${o} requires all 3 expressions`), r = new Te(this.span(e), this.sourceSpan(e));
        }
        return new no(this.span(e), this.sourceSpan(e), t, s, r);
    }
    else
        return t; }
    parseLogicalOr() { let e = this.inputIndex, t = this.parseLogicalAnd(); for (; this.consumeOptionalOperator("||");) {
        let s = this.parseLogicalAnd();
        t = new Ne(this.span(e), this.sourceSpan(e), "||", t, s);
    } return t; }
    parseLogicalAnd() { let e = this.inputIndex, t = this.parseNullishCoalescing(); for (; this.consumeOptionalOperator("&&");) {
        let s = this.parseNullishCoalescing();
        t = new Ne(this.span(e), this.sourceSpan(e), "&&", t, s);
    } return t; }
    parseNullishCoalescing() { let e = this.inputIndex, t = this.parseEquality(); for (; this.consumeOptionalOperator("??");) {
        let s = this.parseEquality();
        t = new Ne(this.span(e), this.sourceSpan(e), "??", t, s);
    } return t; }
    parseEquality() { let e = this.inputIndex, t = this.parseRelational(); for (; this.next.type == L.Operator;) {
        let s = this.next.strValue;
        switch (s) {
            case "==":
            case "===":
            case "!=":
            case "!==":
                this.advance();
                let r = this.parseRelational();
                t = new Ne(this.span(e), this.sourceSpan(e), s, t, r);
                continue;
        }
        break;
    } return t; }
    parseRelational() { let e = this.inputIndex, t = this.parseAdditive(); for (; this.next.type == L.Operator || this.next.isKeywordIn() || this.next.isKeywordInstanceOf();) {
        let s = this.next.strValue;
        switch (s) {
            case "<":
            case ">":
            case "<=":
            case ">=":
            case "in":
            case "instanceof":
                this.advance();
                let r = this.parseAdditive();
                t = new Ne(this.span(e), this.sourceSpan(e), s, t, r);
                continue;
        }
        break;
    } return t; }
    parseAdditive() { let e = this.inputIndex, t = this.parseMultiplicative(); for (; this.next.type == L.Operator;) {
        let s = this.next.strValue;
        switch (s) {
            case "+":
            case "-":
                this.advance();
                let r = this.parseMultiplicative();
                t = new Ne(this.span(e), this.sourceSpan(e), s, t, r);
                continue;
        }
        break;
    } return t; }
    parseMultiplicative() { let e = this.inputIndex, t = this.parseExponentiation(); for (; this.next.type == L.Operator;) {
        let s = this.next.strValue;
        switch (s) {
            case "*":
            case "%":
            case "/":
                this.advance();
                let r = this.parseExponentiation();
                t = new Ne(this.span(e), this.sourceSpan(e), s, t, r);
                continue;
        }
        break;
    } return t; }
    parseExponentiation() { let e = this.inputIndex, t = this.parsePrefix(); for (; this.next.type == L.Operator && this.next.strValue === "**";) {
        (t instanceof vs || t instanceof Tr || t instanceof _r || t instanceof Ir) && this.error("Unary operator used immediately before exponentiation expression. Parenthesis must be used to disambiguate operator precedence"), this.advance();
        let s = this.parseExponentiation();
        t = new Ne(this.span(e), this.sourceSpan(e), "**", t, s);
    } return t; }
    parsePrefix() { if (this.next.type == L.Operator) {
        let e = this.inputIndex, t = this.next.strValue, s;
        switch (t) {
            case "+": return this.advance(), s = this.parsePrefix(), vs.createPlus(this.span(e), this.sourceSpan(e), s);
            case "-": return this.advance(), s = this.parsePrefix(), vs.createMinus(this.span(e), this.sourceSpan(e), s);
            case "!": return this.advance(), s = this.parsePrefix(), new Tr(this.span(e), this.sourceSpan(e), s);
        }
    }
    else if (this.next.isKeywordTypeof()) {
        let e = this.inputIndex;
        this.advance();
        let t = this.parsePrefix();
        return new _r(this.span(e), this.sourceSpan(e), t);
    }
    else if (this.next.isKeywordVoid()) {
        let e = this.inputIndex;
        this.advance();
        let t = this.parsePrefix();
        return new Ir(this.span(e), this.sourceSpan(e), t);
    } return this.parseCallChain(); }
    parseCallChain() { let e = this.inputIndex, t = this.parsePrimary(); for (;;)
        if (this.consumeOptionalCharacter(En))
            t = this.parseAccessMember(t, e, !1);
        else if (this.consumeOptionalOperator("?."))
            this.consumeOptionalCharacter(Be) ? t = this.parseCall(t, e, !0) : t = this.consumeOptionalCharacter(Tt) ? this.parseKeyedReadOrWrite(t, e, !0) : this.parseAccessMember(t, e, !0);
        else if (this.consumeOptionalCharacter(Tt))
            t = this.parseKeyedReadOrWrite(t, e, !1);
        else if (this.consumeOptionalCharacter(Be))
            t = this.parseCall(t, e, !1);
        else if (this.consumeOptionalOperator("!"))
            t = new Nr(this.span(e), this.sourceSpan(e), t);
        else if (this.next.isTemplateLiteralEnd())
            t = this.parseNoInterpolationTaggedTemplateLiteral(t, e);
        else if (this.next.isTemplateLiteralPart())
            t = this.parseTaggedTemplateLiteral(t, e);
        else
            return t; }
    parsePrimary() { let e = this.inputIndex; if (this.isArrowFunction())
        return this.parseArrowFunction(e); if (this.consumeOptionalCharacter(Be)) {
        this.rparensExpected++;
        let t = this.parsePipe();
        return this.consumeOptionalCharacter(ue) || (this.error("Missing closing parentheses"), this.consumeOptionalCharacter(ue)), this.rparensExpected--, new Lr(this.span(e), this.sourceSpan(e), t);
    }
    else {
        if (this.next.isKeywordNull())
            return this.advance(), new Qe(this.span(e), this.sourceSpan(e), null);
        if (this.next.isKeywordUndefined())
            return this.advance(), new Qe(this.span(e), this.sourceSpan(e), void 0);
        if (this.next.isKeywordTrue())
            return this.advance(), new Qe(this.span(e), this.sourceSpan(e), !0);
        if (this.next.isKeywordFalse())
            return this.advance(), new Qe(this.span(e), this.sourceSpan(e), !1);
        if (this.next.isKeywordThis())
            return this.advance(), new Cr(this.span(e), this.sourceSpan(e));
        if (this.consumeOptionalCharacter(Tt))
            return this.parseLiteralArray(e);
        if (this.next.isCharacter(pt))
            return this.parseLiteralMap();
        if (this.next.isIdentifier())
            return this.parseAccessMember(new Pt(this.span(e), this.sourceSpan(e)), e, !1);
        if (this.next.isNumber()) {
            let t = this.next.toNumber();
            return this.advance(), new Qe(this.span(e), this.sourceSpan(e), t);
        }
        else {
            if (this.next.isTemplateLiteralEnd())
                return this.parseNoInterpolationTemplateLiteral();
            if (this.next.isTemplateLiteralPart())
                return this.parseTemplateLiteral();
            if (this.next.isString() && this.next.kind === $n.Plain) {
                let t = this.next.toString();
                return this.advance(), new Qe(this.span(e), this.sourceSpan(e), t);
            }
            else
                return this.next.isPrivateIdentifier() ? (this._reportErrorForPrivateIdentifier(this.next, null), new Te(this.span(e), this.sourceSpan(e))) : this.next.isRegExpBody() ? this.parseRegularExpressionLiteral() : this.index >= this.tokens.length ? (this.error(`Unexpected end of expression: ${this.input}`), new Te(this.span(e), this.sourceSpan(e))) : (this.error(`Unexpected token ${this.next}`), new Te(this.span(e), this.sourceSpan(e)));
        }
    } }
    parseLiteralArray(e) { this.rbracketsExpected++; let t = []; do
        if (this.next.isOperator("..."))
            t.push(this.parseSpreadElement());
        else if (!this.next.isCharacter(Ft))
            t.push(this.parsePipe());
        else
            break;
    while (this.consumeOptionalCharacter(_e)); return this.rbracketsExpected--, this.expectCharacter(Ft), new kr(this.span(e), this.sourceSpan(e), t); }
    parseLiteralMap() { let e = [], t = [], s = this.inputIndex; if (this.expectCharacter(pt), !this.consumeOptionalCharacter(Le)) {
        this.rbracesExpected++;
        do {
            let r = this.inputIndex;
            if (this.next.isOperator("...")) {
                this.advance(), e.push({ kind: "spread", span: this.span(r), sourceSpan: this.sourceSpan(r) }), t.push(this.parsePipe());
                continue;
            }
            let i = this.next.isString(), o = this.expectIdentifierOrKeywordOrString(), a = this.span(r), c = this.sourceSpan(r), l = { kind: "property", key: o, quoted: i, span: a, sourceSpan: c };
            e.push(l), i ? (this.expectCharacter(bt), t.push(this.parsePipe())) : this.consumeOptionalCharacter(bt) ? t.push(this.parsePipe()) : (l.isShorthandInitialized = !0, t.push(new kt(a, c, c, new Pt(a, c), o)));
        } while (this.consumeOptionalCharacter(_e) && !this.next.isCharacter(Le));
        this.rbracesExpected--, this.expectCharacter(Le);
    } return new Wn(this.span(s), this.sourceSpan(s), e, t); }
    parseAccessMember(e, t, s) { let r = this.inputIndex, i = this.withContext(er.Writable, () => { let a = this.expectIdentifierOrKeyword() ?? ""; return a.length === 0 && this.error("Expected identifier for property access", e.span.end), a; }), o = this.sourceSpan(r); if (s)
        return this.isAssignmentOperator(this.next) ? (this.advance(), this.error("The '?.' operator cannot be used in the assignment"), new Te(this.span(t), this.sourceSpan(t))) : new br(this.span(t), this.sourceSpan(t), o, e, i); if (this.isAssignmentOperator(this.next)) {
        let a = this.next.strValue;
        if (!(this.parseFlags & 1))
            return this.advance(), this.error("Bindings cannot contain assignments"), new Te(this.span(t), this.sourceSpan(t));
        let c = new kt(this.span(t), this.sourceSpan(t), o, e, i);
        this.advance();
        let l = this.parseConditional();
        return new Ne(this.span(t), this.sourceSpan(t), a, c, l);
    }
    else
        return new kt(this.span(t), this.sourceSpan(t), o, e, i); }
    parseCall(e, t, s) { let r = this.inputIndex; this.rparensExpected++; let i = this.parseCallArguments(), o = this.span(r, this.inputIndex).toAbsolute(this.absoluteOffset); this.expectCharacter(ue), this.rparensExpected--; let a = this.span(t), c = this.sourceSpan(t); return s ? new io(a, c, e, i, o) : new jn(a, c, e, i, o); }
    parseCallArguments() { if (this.next.isCharacter(ue))
        return []; let e = []; do
        e.push(this.next.isOperator("...") ? this.parseSpreadElement() : this.parsePipe());
    while (this.consumeOptionalCharacter(_e)); return e; }
    parseSpreadElement() { this.next.isOperator("...") || this.error("Spread element must start with '...' operator"); let e = this.inputIndex; this.advance(); let t = this.parsePipe(), s = this.span(e), r = this.sourceSpan(e); return new ro(s, r, t); }
    expectTemplateBindingKey() { let e = "", t = !1, s = this.currentAbsoluteOffset; do
        e += this.expectIdentifierOrKeywordOrString(), t = this.consumeOptionalOperator("-"), t && (e += "-");
    while (t); return { source: e, span: new Ke(s, s + e.length) }; }
    parseTemplateBindings(e) { let t = []; for (t.push(...this.parseDirectiveKeywordBindings(e)); this.index < this.tokens.length;) {
        let s = this.parseLetBinding();
        if (s)
            t.push(s);
        else {
            let r = this.expectTemplateBindingKey(), i = this.parseAsBinding(r);
            i ? t.push(i) : (r.source = e.source + r.source.charAt(0).toUpperCase() + r.source.substring(1), t.push(...this.parseDirectiveKeywordBindings(r)));
        }
        this.consumeStatementTerminator();
    } return new Tc(t, [], this.errors); }
    parseKeyedReadOrWrite(e, t, s) { return this.withContext(er.Writable, () => { this.rbracketsExpected++; let r = this.parsePipe(); if (r instanceof Te && this.error("Key access cannot be empty"), this.rbracketsExpected--, this.expectCharacter(Ft), this.isAssignmentOperator(this.next)) {
        let i = this.next.strValue;
        if (s)
            this.advance(), this.error("The '?.' operator cannot be used in the assignment");
        else {
            let o = new Un(this.span(t), this.sourceSpan(t), e, r);
            this.advance();
            let a = this.parseConditional();
            return new Ne(this.span(t), this.sourceSpan(t), i, o, a);
        }
    }
    else
        return s ? new Ar(this.span(t), this.sourceSpan(t), e, r) : new Un(this.span(t), this.sourceSpan(t), e, r); return new Te(this.span(t), this.sourceSpan(t)); }); }
    parseDirectiveKeywordBindings(e) { let t = []; this.consumeOptionalCharacter(bt); let s = this.getDirectiveBoundTarget(), r = this.currentAbsoluteOffset, i = this.parseAsBinding(e); i || (this.consumeStatementTerminator(), r = this.currentAbsoluteOffset); let o = new Ke(e.span.start, r); return t.push(new Ma(o, e, s)), i && t.push(i), t; }
    getDirectiveBoundTarget() { if (this.next === zs || this.peekKeywordAs() || this.peekKeywordLet())
        return null; let e = this.parsePipe(), { start: t, end: s } = e.span, r = this.input.substring(t, s); return new Ue(e, r, Kt(this.parseSourceSpan), this.absoluteOffset + t, this.errors); }
    parseAsBinding(e) { if (!this.peekKeywordAs())
        return null; this.advance(); let t = this.expectTemplateBindingKey(); this.consumeStatementTerminator(); let s = new Ke(e.span.start, this.currentAbsoluteOffset); return new Br(s, t, e); }
    parseLetBinding() { if (!this.peekKeywordLet())
        return null; let e = this.currentAbsoluteOffset; this.advance(); let t = this.expectTemplateBindingKey(), s = null; this.consumeOptionalOperator("=") && (s = this.expectTemplateBindingKey()), this.consumeStatementTerminator(); let r = new Ke(e, this.currentAbsoluteOffset); return new Br(r, t, s); }
    parseNoInterpolationTaggedTemplateLiteral(e, t) { let s = this.parseNoInterpolationTemplateLiteral(); return new Dr(this.span(t), this.sourceSpan(t), e, s); }
    parseNoInterpolationTemplateLiteral() { let e = this.next.strValue, t = this.inputIndex; this.advance(); let s = this.span(t), r = this.sourceSpan(t); return new Pr(s, r, [new oo(s, r, e)], []); }
    parseTaggedTemplateLiteral(e, t) { let s = this.parseTemplateLiteral(); return new Dr(this.span(t), this.sourceSpan(t), e, s); }
    parseTemplateLiteral() { let e = [], t = [], s = this.inputIndex; for (; this.next !== zs;) {
        let r = this.next;
        if (r.isTemplateLiteralPart() || r.isTemplateLiteralEnd()) {
            let i = this.inputIndex;
            if (this.advance(), e.push(new oo(this.span(i), this.sourceSpan(i), r.strValue)), r.isTemplateLiteralEnd())
                break;
        }
        else if (r.isTemplateLiteralInterpolationStart()) {
            this.advance(), this.rbracesExpected++;
            let i = this.parsePipe();
            i instanceof Te && this.error("Template literal interpolation cannot be empty"), t.push(i), this.rbracesExpected--;
        }
        else
            this.advance();
    } return new Pr(this.span(s), this.sourceSpan(s), e, t); }
    parseRegularExpressionLiteral() { let e = this.next; if (this.advance(), !e.isRegExpBody())
        return new Te(this.span(this.inputIndex), this.sourceSpan(this.inputIndex)); let t = null; if (this.next.isRegExpFlags()) {
        t = this.next, this.advance();
        let i = new Set;
        for (let o = 0; o < t.strValue.length; o++) {
            let a = t.strValue[o];
            Lu.has(a) ? i.has(a) ? this.error(`Duplicate regular expression flag "${a}"`, t.index + o) : i.add(a) : this.error(`Unsupported regular expression flag "${a}". The supported flags are: ` + Array.from(Lu, c => `"${c}"`).join(", "), t.index + o);
        }
    } let s = e.index, r = t ? t.end : e.end; return new co(this.span(s, r), this.sourceSpan(s, r), e.strValue, t ? t.strValue : null); }
    parseArrowFunction(e) { let t; if (this.next.isIdentifier()) {
        let r = this.next;
        this.advance(), t = [this.getArrowFunctionIdentifierArg(r)];
    }
    else
        this.next.isCharacter(Be) ? (this.rparensExpected++, this.advance(), t = this.parseArrowFunctionParameters(), this.rparensExpected--) : (t = [], this.error(`Unexpected token ${this.next}`)); this.expectOperator("=>"); let s; if (this.next.isCharacter(pt))
        this.error("Multi-line arrow functions are not supported. If you meant to return an object literal, wrap it with parentheses."), s = new Te(this.span(e), this.sourceSpan(e));
    else {
        let r = this.parseFlags;
        this.parseFlags = 1, s = this.parseExpression(), this.parseFlags = r;
    } return new ao(this.span(e), this.sourceSpan(e), t, s); }
    parseArrowFunctionParameters() { let e = []; if (!this.consumeOptionalCharacter(ue))
        for (; this.next !== zs;)
            if (this.next.isIdentifier()) {
                let t = this.next;
                if (this.advance(), e.push(this.getArrowFunctionIdentifierArg(t)), this.consumeOptionalCharacter(ue))
                    break;
                this.expectCharacter(_e);
            }
            else {
                this.error(`Unexpected token ${this.next}`);
                break;
            } return e; }
    getArrowFunctionIdentifierArg(e) { return new $a(e.strValue, this.span(e.index), this.sourceSpan(e.index)); }
    isArrowFunction() { let e = this.index, t = this.tokens; if (e > t.length - 2)
        return !1; if (t[e].isIdentifier() && t[e + 1].isOperator("=>"))
        return !0; if (t[e].isCharacter(Be)) {
        let s = e + 1;
        for (s; s < t.length && !(!t[s].isIdentifier() && !t[s].isCharacter(_e)); s++)
            ;
        return s < t.length - 1 && t[s].isCharacter(ue) && t[s + 1].isOperator("=>");
    } return !1; }
    consumeStatementTerminator() { this.consumeOptionalCharacter(qe) || this.consumeOptionalCharacter(_e); }
    error(e, t = this.index) { this.errors.push(ms(e, this.input, this.getErrorLocationText(t), this.parseSourceSpan)), this.skip(); }
    getErrorLocationText(e) { return e < this.tokens.length ? `at column ${this.tokens[e].index + 1} in` : "at the end of the expression"; }
    _reportErrorForPrivateIdentifier(e, t) { let s = `Private identifiers are not supported. Unexpected private identifier: ${e}`; t !== null && (s += `, ${t}`), this.error(s); }
    skip() { let e = this.next; for (; this.index < this.tokens.length && !e.isCharacter(qe) && !e.isOperator("|") && (this.rparensExpected <= 0 || !e.isCharacter(ue)) && (this.rbracesExpected <= 0 || !e.isCharacter(Le)) && (this.rbracketsExpected <= 0 || !e.isCharacter(Ft)) && (!(this.context & er.Writable) || !this.isAssignmentOperator(e));)
        this.next.isError() && this.errors.push(ms(this.next.toString(), this.input, this.getErrorLocationText(this.next.index), this.parseSourceSpan)), this.advance(), e = this.next; }
};
function ms(n, e, t, s) { t.length > 0 && (t = ` ${t} `); let r = Kt(s), i = `Parser Error: ${n}${t}[${e}] in ${r}`; return new N(s, i); }
var _c = class extends As {
    errors = [];
    visitPipe() { this.errors.push("pipes"); }
};
function nw(n) { let e = new Map, t = 0, s = 0, r = 0; for (; r < n.length;) {
    let i = n[r];
    if (i.type === 9) {
        let [o, a] = i.parts;
        t += a.length, s += o.length;
    }
    else {
        let o = i.parts.reduce((a, c) => a + c.length, 0);
        s += o, t += o;
    }
    e.set(s, t), r++;
} return e; }
function sw(n) { return n.visit(new Ic); }
var Ic = class {
    visitUnary(e, t) { return `${e.operator}${e.expr.visit(this, t)}`; }
    visitBinary(e, t) { return `${e.left.visit(this, t)} ${e.operation} ${e.right.visit(this, t)}`; }
    visitChain(e, t) { return e.expressions.map(s => s.visit(this, t)).join("; "); }
    visitConditional(e, t) { return `${e.condition.visit(this, t)} ? ${e.trueExp.visit(this, t)} : ${e.falseExp.visit(this, t)}`; }
    visitThisReceiver() { return "this"; }
    visitImplicitReceiver() { return ""; }
    visitInterpolation(e, t) { return iw(e.strings, e.expressions.map(s => s.visit(this, t))).join(""); }
    visitKeyedRead(e, t) { return `${e.receiver.visit(this, t)}[${e.key.visit(this, t)}]`; }
    visitLiteralArray(e, t) { return `[${e.expressions.map(s => s.visit(this, t)).join(", ")}]`; }
    visitLiteralMap(e, t) { return `{${rw(e.keys.map(s => s.kind === "spread" ? "..." : s.quoted ? `'${s.key}'` : s.key), e.values.map(s => s.visit(this, t))).map(([s, r]) => `${s}: ${r}`).join(", ")}}`; }
    visitLiteralPrimitive(e) { if (e.value === null)
        return "null"; switch (typeof e.value) {
        case "number":
        case "boolean": return e.value.toString();
        case "undefined": return "undefined";
        case "string": return `'${e.value.replace(/'/g, "\\'")}'`;
        default: throw new Error(`Unsupported primitive type: ${e.value}`);
    } }
    visitPipe(e, t) { return `${e.exp.visit(this, t)} | ${e.name}`; }
    visitPrefixNot(e, t) { return `!${e.expression.visit(this, t)}`; }
    visitNonNullAssert(e, t) { return `${e.expression.visit(this, t)}!`; }
    visitPropertyRead(e, t) { return e.receiver instanceof Pt || e.receiver instanceof Cr ? e.name : `${e.receiver.visit(this, t)}.${e.name}`; }
    visitSafePropertyRead(e, t) { return `${e.receiver.visit(this, t)}?.${e.name}`; }
    visitSafeKeyedRead(e, t) { return `${e.receiver.visit(this, t)}?.[${e.key.visit(this, t)}]`; }
    visitCall(e, t) { return `${e.receiver.visit(this, t)}(${e.args.map(s => s.visit(this, t)).join(", ")})`; }
    visitSafeCall(e, t) { return `${e.receiver.visit(this, t)}?.(${e.args.map(s => s.visit(this, t)).join(", ")})`; }
    visitTypeofExpression(e, t) { return `typeof ${e.expression.visit(this, t)}`; }
    visitVoidExpression(e, t) { return `void ${e.expression.visit(this, t)}`; }
    visitRegularExpressionLiteral(e, t) { return `/${e.body}/${e.flags || ""}`; }
    visitArrowFunction(e, t) { let s; return e.parameters.length === 1 ? s = e.parameters[0].name : s = `(${e.parameters.map(r => r.name).join(", ")})`, `${s} => ${e.body.visit(this, t)}`; }
    visitASTWithSource(e, t) { return e.ast.visit(this, t); }
    visitTemplateLiteral(e, t) { let s = ""; for (let r = 0; r < e.elements.length; r++) {
        s += e.elements[r].visit(this, t);
        let i = r < e.expressions.length ? e.expressions[r] : null;
        i !== null && (s += "${" + i.visit(this, t) + "}");
    } return "`" + s + "`"; }
    visitTemplateLiteralElement(e, t) { return e.text; }
    visitTaggedTemplateLiteral(e, t) { return e.tag.visit(this, t) + e.template.visit(this, t); }
    visitSpreadElement(e, t) { return `...${e.expression.visit(this, t)}`; }
    visitParenthesizedExpression(e, t) { return "(" + e.expression.visit(this, t) + ")"; }
};
function rw(n, e) { if (n.length !== e.length)
    throw new Error("Array lengths must match"); return n.map((t, s) => [t, e[s]]); }
function iw(n, e) { let t = []; for (let s = 0; s < Math.max(n.length, e.length); s++)
    s < n.length && t.push(n[s]), s < e.length && t.push(e[s]); return t; }
var ea = "svg", ta = "math", Nc = class {
}, ow = "boolean", aw = "number", cw = "string", lw = "object";
function bi(n) { let e = n.toLowerCase(), [t, s] = be(e, !1); return t === ea || t === ta ? `:${t}:${s}` : s; }
var uw = ["[Element]|textContent,%ariaActiveDescendantElement,%ariaAtomic,%ariaAutoComplete,%ariaBusy,%ariaChecked,%ariaColCount,%ariaColIndex,%ariaColIndexText,%ariaColSpan,%ariaControlsElements,%ariaCurrent,%ariaDescribedByElements,%ariaDescription,%ariaDetailsElements,%ariaDisabled,%ariaErrorMessageElements,%ariaExpanded,%ariaFlowToElements,%ariaHasPopup,%ariaHidden,%ariaInvalid,%ariaKeyShortcuts,%ariaLabel,%ariaLabelledByElements,%ariaLevel,%ariaLive,%ariaModal,%ariaMultiLine,%ariaMultiSelectable,%ariaOrientation,%ariaOwnsElements,%ariaPlaceholder,%ariaPosInSet,%ariaPressed,%ariaReadOnly,%ariaRelevant,%ariaRequired,%ariaRoleDescription,%ariaRowCount,%ariaRowIndex,%ariaRowIndexText,%ariaRowSpan,%ariaSelected,%ariaSetSize,%ariaSort,%ariaValueMax,%ariaValueMin,%ariaValueNow,%ariaValueText,%classList,className,elementTiming,id,innerHTML,*beforecopy,*beforecut,*beforepaste,*fullscreenchange,*fullscreenerror,*search,*webkitfullscreenchange,*webkitfullscreenerror,outerHTML,%part,#scrollLeft,#scrollTop,slot,*message,*mozfullscreenchange,*mozfullscreenerror,*mozpointerlockchange,*mozpointerlockerror,*webglcontextcreationerror,*webglcontextlost,*webglcontextrestored", "[HTMLElement]^[Element]|accessKey,autocapitalize,!autofocus,contentEditable,dir,!draggable,enterKeyHint,!hidden,!inert,innerText,inputMode,lang,nonce,*abort,*animationend,*animationiteration,*animationstart,*auxclick,*beforexrselect,*blur,*cancel,*canplay,*canplaythrough,*change,*click,*close,*contextmenu,*copy,*cuechange,*cut,*dblclick,*drag,*dragend,*dragenter,*dragleave,*dragover,*dragstart,*drop,*durationchange,*emptied,*ended,*error,*focus,*formdata,*gotpointercapture,*input,*invalid,*keydown,*keypress,*keyup,*load,*loadeddata,*loadedmetadata,*loadstart,*lostpointercapture,*mousedown,*mouseenter,*mouseleave,*mousemove,*mouseout,*mouseover,*mouseup,*mousewheel,*paste,*pause,*play,*playing,*pointercancel,*pointerdown,*pointerenter,*pointerleave,*pointermove,*pointerout,*pointerover,*pointerrawupdate,*pointerup,*progress,*ratechange,*reset,*resize,*scroll,*securitypolicyviolation,*seeked,*seeking,*select,*selectionchange,*selectstart,*slotchange,*stalled,*submit,*suspend,*timeupdate,*toggle,*transitioncancel,*transitionend,*transitionrun,*transitionstart,*volumechange,*waiting,*webkitanimationend,*webkitanimationiteration,*webkitanimationstart,*webkittransitionend,*wheel,outerText,!spellcheck,%style,#tabIndex,title,!translate,virtualKeyboardPolicy", "abbr,address,article,aside,b,bdi,bdo,cite,content,code,dd,dfn,dt,em,figcaption,figure,footer,header,hgroup,i,kbd,main,mark,nav,noscript,rb,rp,rt,rtc,ruby,s,samp,search,section,small,strong,sub,sup,u,var,wbr^[HTMLElement]|accessKey,autocapitalize,!autofocus,contentEditable,dir,!draggable,enterKeyHint,!hidden,innerText,inputMode,lang,nonce,*abort,*animationend,*animationiteration,*animationstart,*auxclick,*beforexrselect,*blur,*cancel,*canplay,*canplaythrough,*change,*click,*close,*contextmenu,*copy,*cuechange,*cut,*dblclick,*drag,*dragend,*dragenter,*dragleave,*dragover,*dragstart,*drop,*durationchange,*emptied,*ended,*error,*focus,*formdata,*gotpointercapture,*input,*invalid,*keydown,*keypress,*keyup,*load,*loadeddata,*loadedmetadata,*loadstart,*lostpointercapture,*mousedown,*mouseenter,*mouseleave,*mousemove,*mouseout,*mouseover,*mouseup,*mousewheel,*paste,*pause,*play,*playing,*pointercancel,*pointerdown,*pointerenter,*pointerleave,*pointermove,*pointerout,*pointerover,*pointerrawupdate,*pointerup,*progress,*ratechange,*reset,*resize,*scroll,*securitypolicyviolation,*seeked,*seeking,*select,*selectionchange,*selectstart,*slotchange,*stalled,*submit,*suspend,*timeupdate,*toggle,*transitioncancel,*transitionend,*transitionrun,*transitionstart,*volumechange,*waiting,*webkitanimationend,*webkitanimationiteration,*webkitanimationstart,*webkittransitionend,*wheel,outerText,!spellcheck,%style,#tabIndex,title,!translate,virtualKeyboardPolicy", "media^[HTMLElement]|!autoplay,!controls,%controlsList,%crossOrigin,#currentTime,!defaultMuted,#defaultPlaybackRate,!disableRemotePlayback,!loop,!muted,*encrypted,*waitingforkey,#playbackRate,preload,!preservesPitch,src,%srcObject,#volume", ":svg:^[HTMLElement]|!autofocus,nonce,*abort,*animationend,*animationiteration,*animationstart,*auxclick,*beforexrselect,*blur,*cancel,*canplay,*canplaythrough,*change,*click,*close,*contextmenu,*copy,*cuechange,*cut,*dblclick,*drag,*dragend,*dragenter,*dragleave,*dragover,*dragstart,*drop,*durationchange,*emptied,*ended,*error,*focus,*formdata,*gotpointercapture,*input,*invalid,*keydown,*keypress,*keyup,*load,*loadeddata,*loadedmetadata,*loadstart,*lostpointercapture,*mousedown,*mouseenter,*mouseleave,*mousemove,*mouseout,*mouseover,*mouseup,*mousewheel,*paste,*pause,*play,*playing,*pointercancel,*pointerdown,*pointerenter,*pointerleave,*pointermove,*pointerout,*pointerover,*pointerrawupdate,*pointerup,*progress,*ratechange,*reset,*resize,*scroll,*securitypolicyviolation,*seeked,*seeking,*select,*selectionchange,*selectstart,*slotchange,*stalled,*submit,*suspend,*timeupdate,*toggle,*transitioncancel,*transitionend,*transitionrun,*transitionstart,*volumechange,*waiting,*webkitanimationend,*webkitanimationiteration,*webkitanimationstart,*webkittransitionend,*wheel,%style,#tabIndex", ":svg:graphics^:svg:|", ":svg:animation^:svg:|*begin,*end,*repeat", ":svg:geometry^:svg:|", ":svg:componentTransferFunction^:svg:|", ":svg:gradient^:svg:|", ":svg:textContent^:svg:graphics|", ":svg:textPositioning^:svg:textContent|", "a^[HTMLElement]|charset,coords,download,hash,host,hostname,href,hreflang,name,password,pathname,ping,port,protocol,referrerPolicy,rel,%relList,rev,search,shape,target,text,type,username", "area^[HTMLElement]|alt,coords,download,hash,host,hostname,href,!noHref,password,pathname,ping,port,protocol,referrerPolicy,rel,%relList,search,shape,target,username", "audio^media|", "br^[HTMLElement]|clear", "base^[HTMLElement]|href,target", "body^[HTMLElement]|aLink,background,bgColor,link,*afterprint,*beforeprint,*beforeunload,*blur,*error,*focus,*hashchange,*languagechange,*load,*message,*messageerror,*offline,*online,*pagehide,*pageshow,*popstate,*rejectionhandled,*resize,*scroll,*storage,*unhandledrejection,*unload,text,vLink", "button^[HTMLElement]|!disabled,formAction,formEnctype,formMethod,!formNoValidate,formTarget,name,type,value", "canvas^[HTMLElement]|#height,#width", "content^[HTMLElement]|select", "dl^[HTMLElement]|!compact", "data^[HTMLElement]|value", "datalist^[HTMLElement]|", "details^[HTMLElement]|!open", "dialog^[HTMLElement]|!open,returnValue", "dir^[HTMLElement]|!compact", "div^[HTMLElement]|align", "embed^[HTMLElement]|align,height,name,src,type,width", "fieldset^[HTMLElement]|!disabled,name", "font^[HTMLElement]|color,face,size", "form^[HTMLElement]|acceptCharset,action,autocomplete,encoding,enctype,method,name,!noValidate,target", "frame^[HTMLElement]|frameBorder,longDesc,marginHeight,marginWidth,name,!noResize,scrolling,src", "frameset^[HTMLElement]|cols,*afterprint,*beforeprint,*beforeunload,*blur,*error,*focus,*hashchange,*languagechange,*load,*message,*messageerror,*offline,*online,*pagehide,*pageshow,*popstate,*rejectionhandled,*resize,*scroll,*storage,*unhandledrejection,*unload,rows", "geolocation^[HTMLElement]|accuracymode,!autolocate,*location,*promptaction,*promptdismiss,*validationstatuschange,!watch", "hr^[HTMLElement]|align,color,!noShade,size,width", "head^[HTMLElement]|", "h1,h2,h3,h4,h5,h6^[HTMLElement]|align", "html^[HTMLElement]|version", "iframe^[HTMLElement]|align,allow,!allowFullscreen,!allowPaymentRequest,csp,!credentialless,frameBorder,height,loading,longDesc,marginHeight,marginWidth,name,referrerPolicy,%sandbox,scrolling,src,srcdoc,width", "img^[HTMLElement]|align,alt,border,%crossOrigin,decoding,#height,#hspace,!isMap,loading,longDesc,lowsrc,name,referrerPolicy,sizes,src,srcset,useMap,#vspace,#width", "input^[HTMLElement]|accept,align,alt,autocomplete,!checked,!defaultChecked,defaultValue,dirName,!disabled,%files,formAction,formEnctype,formMethod,!formNoValidate,formTarget,#height,!incremental,!indeterminate,max,#maxLength,min,#minLength,!multiple,name,pattern,placeholder,!readOnly,!required,selectionDirection,#selectionEnd,#selectionStart,#size,src,step,type,useMap,value,%valueAsDate,#valueAsNumber,#width", "li^[HTMLElement]|type,#value", "label^[HTMLElement]|htmlFor", "legend^[HTMLElement]|align", "link^[HTMLElement]|as,charset,%crossOrigin,!disabled,href,hreflang,imageSizes,imageSrcset,integrity,media,referrerPolicy,rel,%relList,rev,%sizes,target,type", "map^[HTMLElement]|name", "marquee^[HTMLElement]|behavior,bgColor,direction,height,#hspace,#loop,#scrollAmount,#scrollDelay,!trueSpeed,#vspace,width", "menu^[HTMLElement]|!compact", "meta^[HTMLElement]|content,httpEquiv,media,name,scheme", "meter^[HTMLElement]|#high,#low,#max,#min,#optimum,#value", "ins,del^[HTMLElement]|cite,dateTime", "ol^[HTMLElement]|!compact,!reversed,#start,type", "object^[HTMLElement]|align,archive,border,code,codeBase,codeType,data,!declare,height,#hspace,name,standby,type,useMap,#vspace,width", "optgroup^[HTMLElement]|!disabled,label", "option^[HTMLElement]|!defaultSelected,!disabled,label,!selected,text,value", "output^[HTMLElement]|defaultValue,%htmlFor,name,value", "p^[HTMLElement]|align", "param^[HTMLElement]|name,type,value,valueType", "picture^[HTMLElement]|", "pre^[HTMLElement]|#width", "progress^[HTMLElement]|#max,#value", "q,blockquote,cite^[HTMLElement]|", "script^[HTMLElement]|!async,charset,%crossOrigin,!defer,event,htmlFor,integrity,!noModule,%referrerPolicy,src,text,type", "select^[HTMLElement]|autocomplete,!disabled,#length,!multiple,name,!required,#selectedIndex,#size,value", "selectedcontent^[HTMLElement]|", "slot^[HTMLElement]|name", "source^[HTMLElement]|#height,media,sizes,src,srcset,type,#width", "span^[HTMLElement]|", "style^[HTMLElement]|!disabled,media,type", "search^[HTMLELement]|", "caption^[HTMLElement]|align", "th,td^[HTMLElement]|abbr,align,axis,bgColor,ch,chOff,#colSpan,headers,height,!noWrap,#rowSpan,scope,vAlign,width", "col,colgroup^[HTMLElement]|align,ch,chOff,#span,vAlign,width", "table^[HTMLElement]|align,bgColor,border,%caption,cellPadding,cellSpacing,frame,rules,summary,%tFoot,%tHead,width", "tr^[HTMLElement]|align,bgColor,ch,chOff,vAlign", "tfoot,thead,tbody^[HTMLElement]|align,ch,chOff,vAlign", "template^[HTMLElement]|", "textarea^[HTMLElement]|autocomplete,#cols,defaultValue,dirName,!disabled,#maxLength,#minLength,name,placeholder,!readOnly,!required,#rows,selectionDirection,#selectionEnd,#selectionStart,value,wrap", "time^[HTMLElement]|dateTime", "title^[HTMLElement]|text", "track^[HTMLElement]|!default,kind,label,src,srclang", "ul^[HTMLElement]|!compact,type", "unknown^[HTMLElement]|", "video^media|!disablePictureInPicture,#height,*enterpictureinpicture,*leavepictureinpicture,!playsInline,poster,#width", ":svg:a^:svg:graphics|", ":svg:animate^:svg:animation|", ":svg:animateMotion^:svg:animation|", ":svg:animateTransform^:svg:animation|", ":svg:circle^:svg:geometry|", ":svg:clipPath^:svg:graphics|", ":svg:defs^:svg:graphics|", ":svg:desc^:svg:|", ":svg:discard^:svg:|", ":svg:ellipse^:svg:geometry|", ":svg:feBlend^:svg:|", ":svg:feColorMatrix^:svg:|", ":svg:feComponentTransfer^:svg:|", ":svg:feComposite^:svg:|", ":svg:feConvolveMatrix^:svg:|", ":svg:feDiffuseLighting^:svg:|", ":svg:feDisplacementMap^:svg:|", ":svg:feDistantLight^:svg:|", ":svg:feDropShadow^:svg:|", ":svg:feFlood^:svg:|", ":svg:feFuncA^:svg:componentTransferFunction|", ":svg:feFuncB^:svg:componentTransferFunction|", ":svg:feFuncG^:svg:componentTransferFunction|", ":svg:feFuncR^:svg:componentTransferFunction|", ":svg:feGaussianBlur^:svg:|", ":svg:feImage^:svg:|", ":svg:feMerge^:svg:|", ":svg:feMergeNode^:svg:|", ":svg:feMorphology^:svg:|", ":svg:feOffset^:svg:|", ":svg:fePointLight^:svg:|", ":svg:feSpecularLighting^:svg:|", ":svg:feSpotLight^:svg:|", ":svg:feTile^:svg:|", ":svg:feTurbulence^:svg:|", ":svg:filter^:svg:|", ":svg:foreignObject^:svg:graphics|", ":svg:g^:svg:graphics|", ":svg:image^:svg:graphics|decoding", ":svg:line^:svg:geometry|", ":svg:linearGradient^:svg:gradient|", ":svg:mpath^:svg:|", ":svg:marker^:svg:|", ":svg:mask^:svg:|", ":svg:metadata^:svg:|", ":svg:path^:svg:geometry|", ":svg:pattern^:svg:|", ":svg:polygon^:svg:geometry|", ":svg:polyline^:svg:geometry|", ":svg:radialGradient^:svg:gradient|", ":svg:rect^:svg:geometry|", ":svg:svg^:svg:graphics|#currentScale,#zoomAndPan", ":svg:script^:svg:|type", ":svg:set^:svg:animation|", ":svg:stop^:svg:|", ":svg:style^:svg:|!disabled,media,title,type", ":svg:switch^:svg:graphics|", ":svg:symbol^:svg:|", ":svg:tspan^:svg:textPositioning|", ":svg:text^:svg:textPositioning|", ":svg:textPath^:svg:textContent|", ":svg:title^:svg:|", ":svg:use^:svg:graphics|", ":svg:view^:svg:|#zoomAndPan", "data^[HTMLElement]|value", "keygen^[HTMLElement]|!autofocus,challenge,!disabled,form,keytype,name", "menuitem^[HTMLElement]|type,label,icon,!disabled,!checked,radiogroup,!default", "summary^[HTMLElement]|", "time^[HTMLElement]|dateTime", ":svg:cursor^:svg:|", ":math:^[HTMLElement]|!autofocus,nonce,*abort,*animationend,*animationiteration,*animationstart,*auxclick,*beforeinput,*beforematch,*beforetoggle,*beforexrselect,*blur,*cancel,*canplay,*canplaythrough,*change,*click,*close,*contentvisibilityautostatechange,*contextlost,*contextmenu,*contextrestored,*copy,*cuechange,*cut,*dblclick,*drag,*dragend,*dragenter,*dragleave,*dragover,*dragstart,*drop,*durationchange,*emptied,*ended,*error,*focus,*formdata,*gotpointercapture,*input,*invalid,*keydown,*keypress,*keyup,*load,*loadeddata,*loadedmetadata,*loadstart,*lostpointercapture,*mousedown,*mouseenter,*mouseleave,*mousemove,*mouseout,*mouseover,*mouseup,*mousewheel,*paste,*pause,*play,*playing,*pointercancel,*pointerdown,*pointerenter,*pointerleave,*pointermove,*pointerout,*pointerover,*pointerrawupdate,*pointerup,*progress,*ratechange,*reset,*resize,*scroll,*scrollend,*securitypolicyviolation,*seeked,*seeking,*select,*selectionchange,*selectstart,*slotchange,*stalled,*submit,*suspend,*timeupdate,*toggle,*transitioncancel,*transitionend,*transitionrun,*transitionstart,*volumechange,*waiting,*webkitanimationend,*webkitanimationiteration,*webkitanimationstart,*webkittransitionend,*wheel,%style,#tabIndex", ":math:math^:math:|", ":math:maction^:math:|", ":math:menclose^:math:|", ":math:merror^:math:|", ":math:mfenced^:math:|", ":math:mfrac^:math:|", ":math:mi^:math:|", ":math:mmultiscripts^:math:|", ":math:mn^:math:|", ":math:mo^:math:|", ":math:mover^:math:|", ":math:mpadded^:math:|", ":math:mphantom^:math:|", ":math:mroot^:math:|", ":math:mrow^:math:|", ":math:ms^:math:|", ":math:mspace^:math:|", ":math:msqrt^:math:|", ":math:mstyle^:math:|", ":math:msub^:math:|", ":math:msubsup^:math:|", ":math:msup^:math:|", ":math:mtable^:math:|", ":math:mtd^:math:|", ":math:mtext^:math:|", ":math:mtr^:math:|", ":math:munder^:math:|", ":math:munderover^:math:|", ":math:semantics^:math:|"], Ih = new Map(Object.entries({ class: "className", for: "htmlFor", formaction: "formAction", innerHtml: "innerHTML", readonly: "readOnly", tabindex: "tabIndex", "aria-activedescendant": "ariaActiveDescendantElement", "aria-atomic": "ariaAtomic", "aria-autocomplete": "ariaAutoComplete", "aria-busy": "ariaBusy", "aria-checked": "ariaChecked", "aria-colcount": "ariaColCount", "aria-colindex": "ariaColIndex", "aria-colindextext": "ariaColIndexText", "aria-colspan": "ariaColSpan", "aria-controls": "ariaControlsElements", "aria-current": "ariaCurrent", "aria-describedby": "ariaDescribedByElements", "aria-description": "ariaDescription", "aria-details": "ariaDetailsElements", "aria-disabled": "ariaDisabled", "aria-errormessage": "ariaErrorMessageElements", "aria-expanded": "ariaExpanded", "aria-flowto": "ariaFlowToElements", "aria-haspopup": "ariaHasPopup", "aria-hidden": "ariaHidden", "aria-invalid": "ariaInvalid", "aria-keyshortcuts": "ariaKeyShortcuts", "aria-label": "ariaLabel", "aria-labelledby": "ariaLabelledByElements", "aria-level": "ariaLevel", "aria-live": "ariaLive", "aria-modal": "ariaModal", "aria-multiline": "ariaMultiLine", "aria-multiselectable": "ariaMultiSelectable", "aria-orientation": "ariaOrientation", "aria-owns": "ariaOwnsElements", "aria-placeholder": "ariaPlaceholder", "aria-posinset": "ariaPosInSet", "aria-pressed": "ariaPressed", "aria-readonly": "ariaReadOnly", "aria-required": "ariaRequired", "aria-roledescription": "ariaRoleDescription", "aria-rowcount": "ariaRowCount", "aria-rowindex": "ariaRowIndex", "aria-rowindextext": "ariaRowIndexText", "aria-rowspan": "ariaRowSpan", "aria-selected": "ariaSelected", "aria-setsize": "ariaSetSize", "aria-sort": "ariaSort", "aria-valuemax": "ariaValueMax", "aria-valuemin": "ariaValueMin", "aria-valuenow": "ariaValueNow", "aria-valuetext": "ariaValueText" })), pw = Array.from(Ih).reduce((n, [e, t]) => (n.set(e, t), n), new Map), mn = class extends Nc {
    _schema = new Map;
    _eventSchema = new Map;
    constructor() { super(), uw.forEach(e => { let t = new Map, s = new Set, [r, i] = e.split("|"), o = i.split(","), [a, c] = r.split("^"); a.split(",").forEach(p => { this._schema.set(p.toLowerCase(), t), this._eventSchema.set(p.toLowerCase(), s); }); let l = c && this._schema.get(c.toLowerCase()); if (l) {
        for (let [p, h] of l)
            t.set(p, h);
        for (let p of this._eventSchema.get(c.toLowerCase()))
            s.add(p);
    } o.forEach(p => { if (p.length > 0)
        switch (p[0]) {
            case "*":
                s.add(p.substring(1));
                break;
            case "!":
                t.set(p.substring(1), ow);
                break;
            case "#":
                t.set(p.substring(1), aw);
                break;
            case "%":
                t.set(p.substring(1), lw);
                break;
            default: t.set(p, cw);
        } }); }); }
    hasProperty(e, t, s) { if (s.some(o => o.name === Rl.name))
        return !0; let r = bi(e); if (r.includes("-")) {
        if (Xl(r) || Fa(r))
            return !1;
        if (s.some(o => o.name === Ml.name))
            return !0;
    } return (this._schema.get(r) || this._schema.get("unknown")).has(t); }
    hasElement(e, t) { if (t.some(r => r.name === Rl.name))
        return !0; let s = bi(e); return s.includes("-") && (Xl(s) || Fa(s) || t.some(r => r.name === Ml.name)) ? !0 : this._schema.has(s); }
    securityContext(e, t, s) { s && (t = this.getMappedPropName(t)); let [r, i] = be(e, !1); return Sf(i, t, r); }
    getMappedPropName(e) { return Ih.get(e) ?? e; }
    getDefaultComponentElementName() { return "ng-component"; }
    validateProperty(e) {
        return e.toLowerCase().startsWith("on") ? { error: !0, msg: `Binding to event property '${e}' is disallowed for security reasons, please use (${e.slice(2)})=...
If '${e}' is a directive input, make sure the directive is imported by the current module.` } : { error: !1 };
    }
    validateAttribute(e) { return e.toLowerCase().startsWith("on") ? { error: !0, msg: `Binding to event attribute '${e}' is disallowed for security reasons, please use (${e.slice(2)})=...` } : { error: !1 }; }
    allKnownElementNames() { return Array.from(this._schema.keys()); }
    allKnownAttributesOfElement(e) { let t = bi(e), s = this._schema.get(t) || this._schema.get("unknown"); return Array.from(s.keys()).map(r => pw.get(r) ?? r); }
    allKnownEventsOfElement(e) { let t = bi(e); return Array.from(this._eventSchema.get(t) ?? []); }
    normalizeAnimationStyleProperty(e) { return Qf(e); }
    normalizeAnimationStyleValue(e, t, s) { let r = "", i = s.toString().trim(), o = null; if (hw(e) && s !== 0 && s !== "0")
        if (typeof s == "number")
            r = "px";
        else {
            let a = s.match(/^[+-]?[\d\.]+([a-z]*)$/);
            a && a[1].length == 0 && (o = `Please provide a CSS unit value for ${t}:${s}`);
        } return { error: o, value: i + r }; }
};
function hw(n) { switch (n) {
    case "width":
    case "height":
    case "minWidth":
    case "minHeight":
    case "maxWidth":
    case "maxHeight":
    case "left":
    case "top":
    case "bottom":
    case "right":
    case "fontSize":
    case "outlineWidth":
    case "outlineOffset":
    case "paddingTop":
    case "paddingLeft":
    case "paddingBottom":
    case "paddingRight":
    case "marginTop":
    case "marginLeft":
    case "marginBottom":
    case "marginRight":
    case "borderRadius":
    case "borderWidth":
    case "borderTopWidth":
    case "borderLeftWidth":
    case "borderRightWidth":
    case "borderBottomWidth":
    case "textIndent": return !0;
    default: return !1;
} }
var O = class {
    closedByChildren = {};
    contentType;
    closedByParent = !1;
    implicitNamespacePrefix;
    isVoid;
    ignoreFirstLf;
    canSelfClose;
    preventNamespaceInheritance;
    constructor({ closedByChildren: e, implicitNamespacePrefix: t, contentType: s = Ct.PARSABLE_DATA, closedByParent: r = !1, isVoid: i = !1, ignoreFirstLf: o = !1, preventNamespaceInheritance: a = !1, canSelfClose: c = !1 } = {}) { e && e.length > 0 && e.forEach(l => this.closedByChildren[l] = !0), this.isVoid = i, this.closedByParent = r || i, this.implicitNamespacePrefix = t || null, this.contentType = s, this.ignoreFirstLf = o, this.preventNamespaceInheritance = a, this.canSelfClose = c ?? i; }
    isClosedByChild(e) { return this.isVoid || e.toLowerCase() in this.closedByChildren; }
    getContentType(e) { return typeof this.contentType == "object" ? (e === void 0 ? void 0 : this.contentType[e]) ?? this.contentType.default : this.contentType; }
}, Bu, is;
function Dc(n) { return is || (Bu = new O({ canSelfClose: !0 }), is = Object.assign(Object.create(null), { base: new O({ isVoid: !0 }), meta: new O({ isVoid: !0 }), area: new O({ isVoid: !0 }), embed: new O({ isVoid: !0 }), link: new O({ isVoid: !0 }), img: new O({ isVoid: !0 }), input: new O({ isVoid: !0 }), param: new O({ isVoid: !0 }), hr: new O({ isVoid: !0 }), br: new O({ isVoid: !0 }), source: new O({ isVoid: !0 }), track: new O({ isVoid: !0 }), wbr: new O({ isVoid: !0 }), p: new O({ closedByChildren: ["address", "article", "aside", "blockquote", "div", "dl", "fieldset", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "hr", "main", "nav", "ol", "p", "pre", "section", "table", "ul"], closedByParent: !0 }), thead: new O({ closedByChildren: ["tbody", "tfoot"] }), tbody: new O({ closedByChildren: ["tbody", "tfoot"], closedByParent: !0 }), tfoot: new O({ closedByChildren: ["tbody"], closedByParent: !0 }), tr: new O({ closedByChildren: ["tr"], closedByParent: !0 }), td: new O({ closedByChildren: ["td", "th"], closedByParent: !0 }), th: new O({ closedByChildren: ["td", "th"], closedByParent: !0 }), col: new O({ isVoid: !0 }), svg: new O({ implicitNamespacePrefix: "svg" }), foreignObject: new O({ implicitNamespacePrefix: "svg", preventNamespaceInheritance: !0 }), math: new O({ implicitNamespacePrefix: "math" }), li: new O({ closedByChildren: ["li"], closedByParent: !0 }), dt: new O({ closedByChildren: ["dt", "dd"] }), dd: new O({ closedByChildren: ["dt", "dd"], closedByParent: !0 }), rb: new O({ closedByChildren: ["rb", "rt", "rtc", "rp"], closedByParent: !0 }), rt: new O({ closedByChildren: ["rb", "rt", "rtc", "rp"], closedByParent: !0 }), rtc: new O({ closedByChildren: ["rb", "rtc", "rp"], closedByParent: !0 }), rp: new O({ closedByChildren: ["rb", "rt", "rtc", "rp"], closedByParent: !0 }), optgroup: new O({ closedByChildren: ["optgroup"], closedByParent: !0 }), option: new O({ closedByChildren: ["option", "optgroup"], closedByParent: !0 }), pre: new O({ ignoreFirstLf: !0 }), listing: new O({ ignoreFirstLf: !0 }), style: new O({ contentType: Ct.RAW_TEXT }), script: new O({ contentType: Ct.RAW_TEXT }), title: new O({ contentType: { default: Ct.ESCAPABLE_RAW_TEXT, svg: Ct.PARSABLE_DATA } }), textarea: new O({ contentType: Ct.ESCAPABLE_RAW_TEXT, ignoreFirstLf: !0 }) }), new mn().allKnownElementNames().forEach(e => { !is[e] && Oa(e) === null && (is[e] = new O({ canSelfClose: !1 })); })), is[n] ?? is[n.toLowerCase()] ?? Bu; }
var $u = { A: "LINK", B: "BOLD_TEXT", BR: "LINE_BREAK", EM: "EMPHASISED_TEXT", H1: "HEADING_LEVEL1", H2: "HEADING_LEVEL2", H3: "HEADING_LEVEL3", H4: "HEADING_LEVEL4", H5: "HEADING_LEVEL5", H6: "HEADING_LEVEL6", HR: "HORIZONTAL_RULE", I: "ITALIC_TEXT", LI: "LIST_ITEM", LINK: "MEDIA_LINK", OL: "ORDERED_LIST", P: "PARAGRAPH", Q: "QUOTATION", S: "STRIKETHROUGH_TEXT", SMALL: "SMALL_TEXT", SUB: "SUBSTRIPT", SUP: "SUPERSCRIPT", TBODY: "TABLE_BODY", TD: "TABLE_CELL", TFOOT: "TABLE_FOOTER", TH: "TABLE_HEADER_CELL", THEAD: "TABLE_HEADER", TR: "TABLE_ROW", TT: "MONOSPACED_TEXT", U: "UNDERLINED_TEXT", UL: "UNORDERED_LIST" }, Pc = class {
    _placeHolderNameCounts = {};
    _signatureToName = {};
    getStartTagPlaceholderName(e, t, s) { let r = this._hashTag(e, t, s); if (this._signatureToName[r])
        return this._signatureToName[r]; let i = e.toUpperCase(), o = $u[i] || `TAG_${i}`, a = this._generateUniqueName(s ? o : `START_${o}`); return this._signatureToName[r] = a, a; }
    getCloseTagPlaceholderName(e) { let t = this._hashClosingTag(e); if (this._signatureToName[t])
        return this._signatureToName[t]; let s = e.toUpperCase(), r = $u[s] || `TAG_${s}`, i = this._generateUniqueName(`CLOSE_${r}`); return this._signatureToName[t] = i, i; }
    getPlaceholderName(e, t) { let s = e.toUpperCase(), r = `PH: ${s}=${t}`; if (this._signatureToName[r])
        return this._signatureToName[r]; let i = this._generateUniqueName(s); return this._signatureToName[r] = i, i; }
    getUniquePlaceholder(e) { return this._generateUniqueName(e.toUpperCase()); }
    getStartBlockPlaceholderName(e, t) { let s = this._hashBlock(e, t); if (this._signatureToName[s])
        return this._signatureToName[s]; let r = this._generateUniqueName(`START_BLOCK_${this._toSnakeCase(e)}`); return this._signatureToName[s] = r, r; }
    getCloseBlockPlaceholderName(e) { let t = this._hashClosingBlock(e); if (this._signatureToName[t])
        return this._signatureToName[t]; let s = this._generateUniqueName(`CLOSE_BLOCK_${this._toSnakeCase(e)}`); return this._signatureToName[t] = s, s; }
    _hashTag(e, t, s) { let r = `<${e}`, i = Object.keys(t).sort().map(a => ` ${a}=${t[a]}`).join(""), o = s ? "/>" : `></${e}>`; return r + i + o; }
    _hashClosingTag(e) { return this._hashTag(`/${e}`, {}, !1); }
    _hashBlock(e, t) { let s = t.length === 0 ? "" : ` (${t.sort().join("; ")})`; return `@${e}${s} {}`; }
    _hashClosingBlock(e) { return this._hashBlock(`close_${e}`, []); }
    _toSnakeCase(e) { return e.toUpperCase().replace(/[^A-Z0-9]/g, "_"); }
    _generateUniqueName(e) { if (!Object.hasOwn(this._placeHolderNameCounts, e))
        return this._placeHolderNameCounts[e] = 1, e; let s = this._placeHolderNameCounts[e]; return this._placeHolderNameCounts[e] = s + 1, `${e}_${s}`; }
}, fw = new Vo(new ci);
function dw(n, e) { let t = new Lc(fw, n, e); return (s, r, i, o, a) => t.toI18nMessage(s, r, i, o, a); }
function mw(n, e) { return e; }
var Lc = class {
    _expressionParser;
    _retainEmptyTokens;
    _preserveExpressionWhitespace;
    constructor(e, t, s) { this._expressionParser = e, this._retainEmptyTokens = t, this._preserveExpressionWhitespace = s; }
    toI18nMessage(e, t = "", s = "", r = "", i) { let o = { isIcu: e.length == 1 && e[0] instanceof Bn, icuDepth: 0, placeholderRegistry: new Pc, placeholderToContent: {}, placeholderToMessage: {}, visitNodeFn: i || mw }, a = Z(this, e, o); return new Me(a, o.placeholderToContent, o.placeholderToMessage, t, s, r); }
    visitElement(e, t) { return this._visitElementLike(e, t); }
    visitComponent(e, t) { return this._visitElementLike(e, t); }
    visitDirective(e, t) { throw new Error("Unreachable code"); }
    visitAttribute(e, t) { let s = e.valueTokens === void 0 || e.valueTokens.length === 1 ? new Hs(e.value, e.valueSpan || e.sourceSpan) : this._visitTextWithInterpolation(e.valueTokens, e.valueSpan || e.sourceSpan, t, e.i18n); return t.visitNodeFn(e, s); }
    visitText(e, t) { let s = e.tokens.length === 1 ? new Hs(e.value, e.sourceSpan) : this._visitTextWithInterpolation(e.tokens, e.sourceSpan, t, e.i18n); return t.visitNodeFn(e, s); }
    visitComment(e, t) { return null; }
    visitExpansion(e, t) { t.icuDepth++; let s = {}, r = new wo(e.switchValue, e.type, s, e.sourceSpan); if (e.cases.forEach(a => { s[a.value] = new qt(a.expression.map(c => c.visit(this, t)), a.expSourceSpan); }), t.icuDepth--, t.isIcu || t.icuDepth > 0) {
        let a = t.placeholderRegistry.getUniquePlaceholder(`VAR_${e.type}`);
        return r.expressionPlaceholder = a, t.placeholderToContent[a] = { text: e.switchValue, sourceSpan: e.switchValueSourceSpan }, t.visitNodeFn(e, r);
    } let i = t.placeholderRegistry.getPlaceholderName("ICU", e.sourceSpan.toString()); t.placeholderToMessage[i] = this.toI18nMessage([e], "", "", "", void 0); let o = new Ds(r, i, e.sourceSpan); return t.visitNodeFn(e, o); }
    visitExpansionCase(e, t) { throw new Error("Unreachable code"); }
    visitBlock(e, t) { let s = Z(this, e.children, t); if (e.name === "switch")
        return new qt(s, e.sourceSpan); let r = e.parameters.map(c => c.expression), i = t.placeholderRegistry.getStartBlockPlaceholderName(e.name, r), o = t.placeholderRegistry.getCloseBlockPlaceholderName(e.name); t.placeholderToContent[i] = { text: e.startSourceSpan.toString(), sourceSpan: e.startSourceSpan }, t.placeholderToContent[o] = { text: e.endSourceSpan ? e.endSourceSpan.toString() : "}", sourceSpan: e.endSourceSpan ?? e.sourceSpan }; let a = new ln(e.name, r, i, o, s, e.sourceSpan, e.startSourceSpan, e.endSourceSpan); return t.visitNodeFn(e, a); }
    visitBlockParameter(e, t) { throw new Error("Unreachable code"); }
    visitLetDeclaration(e, t) { return null; }
    _visitElementLike(e, t) { let s = Z(this, e.children, t), r = {}, i = h => { r[h.name] = h.value; }, o, a; e instanceof ct ? (o = e.name, a = Dc(e.name).isVoid) : (o = e.fullName, a = e.tagName ? Dc(e.tagName).isVoid : !1), e.attrs.forEach(i), e.directives.forEach(h => h.attrs.forEach(i)); let c = t.placeholderRegistry.getStartTagPlaceholderName(o, r, a); t.placeholderToContent[c] = { text: e.startSourceSpan.toString(), sourceSpan: e.startSourceSpan }; let l = ""; a || (l = t.placeholderRegistry.getCloseTagPlaceholderName(o), t.placeholderToContent[l] = { text: `</${o}>`, sourceSpan: e.endSourceSpan ?? e.sourceSpan }); let p = new cn(o, r, c, l, s, a, e.sourceSpan, e.startSourceSpan, e.endSourceSpan); return t.visitNodeFn(e, p); }
    _visitTextWithInterpolation(e, t, s, r) { let i = [], o = !1; for (let a of e)
        switch (a.type) {
            case 8:
            case 18:
                o = !0;
                let [c, l, p] = a.parts, h = Ew(l) || "INTERPOLATION", d = s.placeholderRegistry.getPlaceholderName(h, l);
                if (this._preserveExpressionWhitespace)
                    s.placeholderToContent[d] = { text: a.parts.join(""), sourceSpan: a.sourceSpan }, i.push(new Ur(l, d, a.sourceSpan));
                else {
                    let v = this.normalizeExpression(a);
                    s.placeholderToContent[d] = { text: `${c}${v}${p}`, sourceSpan: a.sourceSpan }, i.push(new Ur(v, d, a.sourceSpan));
                }
                break;
            default:
                if (a.parts[0].length > 0 || this._retainEmptyTokens) {
                    let v = i[i.length - 1];
                    v instanceof Hs ? (v.value += a.parts[0], v.sourceSpan = new D(v.sourceSpan.start, a.sourceSpan.end, v.sourceSpan.fullStart, v.sourceSpan.details)) : i.push(new Hs(a.parts[0], a.sourceSpan));
                }
                else
                    this._retainEmptyTokens && i.push(new Hs(a.parts[0], a.sourceSpan));
                break;
        } return o ? (gw(i, r), new qt(i, t)) : i[0]; }
    normalizeExpression(e) { let t = e.parts[1], s = this._expressionParser.parseBinding(t, e.sourceSpan, e.sourceSpan.start.offset); return sw(s); }
};
function gw(n, e) { if (e instanceof Me && (vw(e), e = e.nodes[0]), e instanceof qt) {
    ww(e.children, n);
    for (let t = 0; t < n.length; t++)
        n[t].sourceSpan = e.children[t].sourceSpan;
} }
function vw(n) { let e = n.nodes; if (e.length !== 1 || !(e[0] instanceof qt))
    throw new Error("Unexpected previous i18n message - expected it to consist of only a single `Container` node."); }
function ww(n, e) {
    if (n.length !== e.length)
        throw new Error(`
The number of i18n message children changed between first and second pass.

First pass (${n.length} tokens):
${n.map(t => `"${t.sourceSpan.toString()}"`).join(`
`)}

Second pass (${e.length} tokens):
${e.map(t => `"${t.sourceSpan.toString()}"`).join(`
`)}
    `.trim());
    if (n.some((t, s) => e[s].constructor !== t.constructor))
        throw new Error("The types of the i18n message children changed between first and second pass.");
}
var Sw = /\/\/[\s\S]*i18n[\s\S]*\([\s\S]*ph[\s\S]*=[\s\S]*("|')([\s\S]*?)\1[\s\S]*\)/g;
function Ew(n) { return n.split(Sw)[2]; }
var Mu = new Set(["iframe|srcdoc", "*|innerhtml", "*|outerhtml", "embed|src", "iframe|src", "object|codebase", "object|data"]);
function Ru(n, e) { return n = n.toLowerCase(), e = e.toLowerCase(), Mu.has(n + "|" + e) || Mu.has("*|" + e); }
var xw = n => (e, t) => { let s = n.get(e) ?? e; return s instanceof zt && (t instanceof Ds && s.i18n instanceof Me && (t.previousMessage = s.i18n), s.i18n = t), t; }, qo = class {
    keepI18nAttrs;
    enableI18nLegacyMessageIdFormat;
    preserveSignificantWhitespace;
    retainEmptyTokens;
    hasI18nMeta = !1;
    _errors = [];
    constructor(e = !1, t = !1, s = !0, r = !s) { this.keepI18nAttrs = e, this.enableI18nLegacyMessageIdFormat = t, this.preserveSignificantWhitespace = s, this.retainEmptyTokens = r; }
    _generateI18nMessage(e, t = "", s) { let { meaning: r, description: i, customId: o } = this._parseMetadata(t), c = dw(this.retainEmptyTokens, this.preserveSignificantWhitespace)(e, r, i, o, s); return this._setMessageId(c, t), this._setLegacyIds(c, t), c; }
    visitAllWithErrors(e) { let t = e.map(s => s.visit(this, null)); return new Fo(t, this._errors); }
    visitElement(e) { return this._visitElementLike(e), e; }
    visitComponent(e, t) { return this._visitElementLike(e), e; }
    visitExpansion(e, t) { let s, r = e.i18n; if (this.hasI18nMeta = !0, r instanceof Ds) {
        let i = r.name;
        s = this._generateI18nMessage([e], r);
        let o = qp(s);
        o.name = i, t !== null && (t.placeholderToMessage[i] = s);
    }
    else
        s = this._generateI18nMessage([e], t || r); return e.i18n = s, e; }
    visitText(e) { return e; }
    visitAttribute(e) { return e; }
    visitComment(e) { return e; }
    visitExpansionCase(e) { return e; }
    visitBlock(e, t) { return Z(this, e.children, t), e; }
    visitBlockParameter(e, t) { return e; }
    visitLetDeclaration(e, t) { return e; }
    visitDirective(e, t) { return e; }
    _visitElementLike(e) { let t; if (Ad(e)) {
        this.hasI18nMeta = !0;
        let s = [], r = {};
        for (let i of e.attrs)
            if (i.name === Op) {
                let o = e.i18n || i.value, a = new Map, c = this.preserveSignificantWhitespace ? e.children : Et(new Oo(!1, a), e.children);
                t = this._generateI18nMessage(c, o, xw(a)), t.nodes.length === 0 && (t = void 0), e.i18n = t;
            }
            else if (i.name.startsWith(Qa)) {
                let o = i.name.slice(Qa.length), a;
                e instanceof Pe ? a = e.tagName === null ? !1 : Ru(e.tagName, o) : a = Ru(e.name, o), a || kw(o) ? this._reportError(i, `Translating attribute '${o}' is disallowed for security reasons.`) : r[o] = i.value;
            }
            else
                s.push(i);
        if (Object.keys(r).length)
            for (let i of s) {
                let o = r[i.name];
                o !== void 0 && i.value && (i.i18n = this._generateI18nMessage([i], i.i18n || o));
            }
        this.keepI18nAttrs || (e.attrs = s);
    } Z(this, e.children, t); }
    _parseMetadata(e) { return typeof e == "string" ? bw(e) : e instanceof Me ? e : {}; }
    _setMessageId(e, t) { e.id || (e.id = t instanceof Me && t.id || bf(e)); }
    _setLegacyIds(e, t) { if (this.enableI18nLegacyMessageIdFormat)
        e.legacyIds = [Cf(e), _p(e)];
    else if (typeof t != "string") {
        let s = t instanceof Me ? t : t instanceof Ds ? t.previousMessage : void 0;
        e.legacyIds = s ? s.legacyIds : [];
    } }
    _reportError(e, t) { this._errors.push(new N(e.sourceSpan, t)); }
}, yw = "|", Cw = "@@";
function bw(n = "") { let e, t, s; if (n = n.trim(), n) {
    let r = n.indexOf(Cw), i = n.indexOf(yw), o;
    [o, e] = r > -1 ? [n.slice(0, r), n.slice(r + 2)] : [n, ""], [t, s] = i > -1 ? [o.slice(0, i), o.slice(i + 1)] : ["", o];
} return { customId: e, meaning: t, description: s }; }
function Aw(n) { let e = []; return n.description ? e.push({ tagName: "desc", text: n.description }) : e.push({ tagName: "suppress", text: "{msgDescriptions}" }), n.meaning && e.push({ tagName: "meaning", text: n.meaning }), Vf(e); }
function kw(n) { let e = n.toLowerCase(); return e.length > 2 && e !== "only" && e.startsWith("on"); }
function Tw(n, e, t, s) { let r = Iw(e), i = [g(r)]; Object.keys(s).length && (i.push(mc(pl(s, !0), !0)), i.push(mc({ original_code: nt(Object.keys(s).map(c => ({ key: gi(c), quoted: !0, value: e.placeholders[c] ? g(e.placeholders[c].sourceSpan.toString()) : g(e.placeholderToMessage[c].nodes.map(l => l.sourceSpan.toString()).join("")) }))) }))); let o = new ve(t.name, F("goog").prop("getMsg").callFn(i, null, void 0, [xr()]), It, xe.Final); o.addLeadingComment(Aw(e)); let a = new ke(n.set(t)); return [o, a]; }
var Bc = class {
    formatPh(e) { return `{$${gi(e)}}`; }
    visitText(e) { return e.value; }
    visitContainer(e) { return e.children.map(t => t.visit(this)).join(""); }
    visitIcu(e) { return yh(e); }
    visitTagPlaceholder(e) { return e.isVoid ? this.formatPh(e.startName) : `${this.formatPh(e.startName)}${e.children.map(t => t.visit(this)).join("")}${this.formatPh(e.closeName)}`; }
    visitPlaceholder(e) { return this.formatPh(e.name); }
    visitBlockPlaceholder(e) { return `${this.formatPh(e.startName)}${e.children.map(t => t.visit(this)).join("")}${this.formatPh(e.closeName)}`; }
    visitIcuPlaceholder(e, t) { return this.formatPh(e.name); }
}, _w = new Bc;
function Iw(n) { return n.nodes.map(e => e.visit(_w, null)).join(""); }
function Nw(n, e, t) { let { messageParts: s, placeHolders: r } = Dw(e), i = Pw(e), o = r.map(l => t[l.text]), a = Uf(e, s, r, o, i), c = n.set(a); return [new ke(c, null, [xr()])]; }
var $c = class {
    placeholderToMessage;
    pieces;
    constructor(e, t) { this.placeholderToMessage = e, this.pieces = t; }
    visitText(e) { if (this.pieces[this.pieces.length - 1] instanceof _n)
        this.pieces[this.pieces.length - 1].text += e.value;
    else {
        let t = new D(e.sourceSpan.fullStart, e.sourceSpan.end, e.sourceSpan.fullStart, e.sourceSpan.details);
        this.pieces.push(new _n(e.value, t));
    } }
    visitContainer(e) { e.children.forEach(t => t.visit(this)); }
    visitIcu(e) { this.pieces.push(new _n(yh(e), e.sourceSpan)); }
    visitTagPlaceholder(e) { this.pieces.push(this.createPlaceholderPiece(e.startName, e.startSourceSpan ?? e.sourceSpan)), e.isVoid || (e.children.forEach(t => t.visit(this)), this.pieces.push(this.createPlaceholderPiece(e.closeName, e.endSourceSpan ?? e.sourceSpan))); }
    visitPlaceholder(e) { this.pieces.push(this.createPlaceholderPiece(e.name, e.sourceSpan)); }
    visitBlockPlaceholder(e) { this.pieces.push(this.createPlaceholderPiece(e.startName, e.startSourceSpan ?? e.sourceSpan)), e.children.forEach(t => t.visit(this)), this.pieces.push(this.createPlaceholderPiece(e.closeName, e.endSourceSpan ?? e.sourceSpan)); }
    visitIcuPlaceholder(e) { this.pieces.push(this.createPlaceholderPiece(e.name, e.sourceSpan, this.placeholderToMessage[e.name])); }
    createPlaceholderPiece(e, t, s) { return new gs(gi(e, !1), t, s); }
};
function Dw(n) { let e = [], t = new $c(n.placeholderToMessage, e); return n.nodes.forEach(s => s.visit(t)), Lw(e); }
function Pw(n) { let e = n.nodes[0], t = n.nodes[n.nodes.length - 1]; return new D(e.sourceSpan.fullStart, t.sourceSpan.end, e.sourceSpan.fullStart, e.sourceSpan.details); }
function Lw(n) { let e = [], t = []; n[0] instanceof gs && e.push(da(n[0].sourceSpan.start)); for (let s = 0; s < n.length; s++) {
    let r = n[s];
    r instanceof _n ? e.push(r) : (t.push(r), n[s - 1] instanceof gs && e.push(da(n[s - 1].sourceSpan.end)));
} return n[n.length - 1] instanceof gs && e.push(da(n[n.length - 1].sourceSpan.end)), { messageParts: e, placeHolders: t }; }
function da(n) { return new _n("", new D(n, n)); }
var Fu = "ngI18nClosureMode", Bw = "i18n_", $w = "I18N_EXP_", Ou = "\uFFFD", Mw = "MSG_";
function Vu(n) { return `${Mw}${n}`.toUpperCase(); }
function Rw(n) { return new ve(n.name, void 0, It, void 0, n.sourceSpan); }
function Fw(n) { let e = n.relativeContextFilePath.replace(/[^A-Za-z0-9]/g, "_").toUpperCase() + "_", t = new Map, s = new Map, r = new Map, i = new Map; for (let c of n.units)
    for (let l of c.ops())
        if (l.kind === u.ExtractedAttribute && l.i18nContext !== null) {
            let p = t.get(l.i18nContext) ?? [];
            p.push(l), t.set(l.i18nContext, p);
        }
        else if (l.kind === u.I18nAttributes)
            s.set(l.target, l);
        else if (l.kind === u.I18nExpression && l.usage === Fs.I18nAttribute) {
            let p = r.get(l.target) ?? [];
            p.push(l), r.set(l.target, p);
        }
        else
            l.kind === u.I18nMessage && i.set(l.xref, l); let o = new Map, a = new Map; for (let c of n.units)
    for (let l of c.create)
        if (l.kind === u.I18nMessage) {
            if (l.messagePlaceholder === null) {
                let { mainVar: p, statements: h } = Nh(n, e, i, l);
                if (l.i18nBlock !== null) {
                    let d = n.addConst(p, h);
                    a.set(l.i18nBlock, d);
                }
                else {
                    n.constsInitializers.push(...h), o.set(l.i18nContext, p);
                    let d = t.get(l.i18nContext);
                    if (d !== void 0)
                        for (let v of d)
                            v.expression = p.clone();
                }
            }
            S.remove(l);
        } for (let c of n.units)
    for (let l of c.create)
        if (dn(l)) {
            let p = s.get(l.xref);
            if (p === void 0)
                continue;
            let h = r.get(l.xref);
            if (h === void 0)
                throw new Error("AssertionError: Could not find any i18n expressions associated with an I18nAttributes instruction");
            let d = new Set;
            h = h.filter(w => { let y = d.has(w.name); return d.add(w.name), !y; });
            let v = h.flatMap(w => { let y = o.get(w.context); if (y === void 0)
                throw new Error("AssertionError: Could not find i18n expression's value"); return [g(w.name), y]; });
            p.i18nAttributesConfig = n.addConst(new Dt(v));
        } for (let c of n.units)
    for (let l of c.create)
        if (l.kind === u.I18nStart) {
            let p = a.get(l.root);
            if (p === void 0)
                throw new Error("AssertionError: Could not find corresponding i18n block index for an i18n message op; was an i18n message incorrectly assumed to correspond to an attribute?");
            l.messageIndex = p;
        } }
function Nh(n, e, t, s) { let r = [], i = new Map; for (let l of s.subMessages) {
    let p = t.get(l), { mainVar: h, statements: d } = Nh(n, e, t, p);
    r.push(...d);
    let v = i.get(p.messagePlaceholder) ?? [];
    v.push(h), i.set(p.messagePlaceholder, v);
} Ow(s, i), s.params = new Map([...s.params.entries()].sort()); let o = F(n.pool.uniqueName(Bw), ge), a = Hw(n.pool, s.message.id, e, n.i18nUseExternalIds), c; if (s.needsPostprocessing || s.postprocessingParams.size > 0) {
    let l = Object.fromEntries([...s.postprocessingParams.entries()].sort()), p = pl(l, !1), h = [];
    s.postprocessingParams.size > 0 && h.push(mc(p, !0)), c = d => A(f.i18nPostprocess).callFn([d, ...h]);
} return r.push(...Vw(s.message, o, a, s.params, c)), { mainVar: o, statements: r }; }
function Ow(n, e) { for (let [t, s] of e)
    s.length === 1 ? n.params.set(t, s[0]) : (n.params.set(t, g(`${Ou}${$w}${t}${Ou}`)), n.postprocessingParams.set(t, X(s))); }
function Vw(n, e, t, s, r) { let i = Object.fromEntries(s), o = [Rw(e), Qo(qw(), Tw(e, n, t, i), Nw(e, n, pl(i, !1)))]; return r && o.push(new ke(e.set(r(e)))), o; }
function qw() { return di(F(Fu)).notIdentical(g("undefined", ol)).and(F(Fu)); }
function Hw(n, e, t, s) { let r, i = t; if (s) {
    let o = Vu("EXTERNAL_"), a = n.uniqueName(i);
    r = `${o}${yn(e)}$$${a}`;
}
else {
    let o = Vu(i);
    r = n.uniqueName(o);
} return F(r); }
function Uw(n) { for (let e of n.units) {
    let t = null, s = null, r = new Map, i = new Map, o = new Map;
    for (let a of e.create)
        switch (a.kind) {
            case u.I18nStart:
                if (a.context === null)
                    throw Error("I18n op should have its context set.");
                t = a;
                break;
            case u.I18nEnd:
                t = null;
                break;
            case u.IcuStart:
                if (a.context === null)
                    throw Error("Icu op should have its context set.");
                s = a;
                break;
            case u.IcuEnd:
                s = null;
                break;
            case u.Text:
                if (t !== null)
                    if (r.set(a.xref, t), i.set(a.xref, s), a.icuPlaceholder !== null) {
                        let c = ig(n.allocateXrefId(), a.icuPlaceholder, [a.initialValue]);
                        S.replace(a, c), o.set(a.xref, c);
                    }
                    else
                        S.remove(a);
                break;
        }
    for (let a of e.update)
        switch (a.kind) {
            case u.InterpolateText:
                if (!r.has(a.target))
                    continue;
                let c = r.get(a.target), l = i.get(a.target), p = o.get(a.target), h = l ? l.context : c.context, d = l ? Qr.Postproccessing : Qr.Creation, v = [];
                for (let w = 0; w < a.interpolation.expressions.length; w++) {
                    let y = a.interpolation.expressions[w];
                    v.push(lh(h, c.xref, c.xref, c.handle, y, p?.xref ?? null, a.interpolation.i18nPlaceholders[w] ?? null, d, Fs.I18nText, "", y.sourceSpan ?? a.sourceSpan));
                }
                S.replaceWithMany(a, v), p !== void 0 && (p.strings = a.interpolation.strings);
                break;
        }
} }
function Ww(n) { for (let e of n.units)
    for (let t of e.create)
        switch (t.kind) {
            case u.ElementStart:
            case u.ConditionalCreate:
            case u.ConditionalBranchCreate:
            case u.Template:
                if (!Array.isArray(t.localRefs))
                    throw new Error("AssertionError: expected localRefs to be an array still");
                if (t.numSlotsUsed += t.localRefs.length, t.localRefs.length > 0) {
                    let s = jw(t.localRefs);
                    t.localRefs = n.addConst(s);
                }
                else
                    t.localRefs = null;
                break;
        } }
function jw(n) { let e = []; for (let t of n)
    e.push(g(t.name), g(t.target)); return X(e); }
function zw(n) { for (let e of n.units) {
    let t = oe.HTML;
    for (let s of e.create)
        s.kind === u.ElementStart && s.namespace !== t && (S.insertBefore(Ym(s.namespace), s), t = s.namespace);
} }
function Gw(n) { let e = [], t = 0, s = 0, r = 0, i = 0, o = 0, a = null; for (; t < n.length;)
    switch (n.charCodeAt(t++)) {
        case 40:
            s++;
            break;
        case 41:
            s--;
            break;
        case 39:
            r === 0 ? r = 39 : r === 39 && n.charCodeAt(t - 1) !== 92 && (r = 0);
            break;
        case 34:
            r === 0 ? r = 34 : r === 34 && n.charCodeAt(t - 1) !== 92 && (r = 0);
            break;
        case 58:
            !a && s === 0 && r === 0 && (a = Dh(n.substring(o, t - 1).trim()), i = t);
            break;
        case 59:
            if (a && i > 0 && s === 0 && r === 0) {
                let l = n.substring(i, t - 1).trim();
                e.push(a, l), o = t, i = 0, a = null;
            }
            break;
    } if (a && i) {
    let c = n.slice(i).trim();
    e.push(a, c);
} return e; }
function Dh(n) { return n.replace(/[a-z][A-Z]/g, e => e.charAt(0) + "-" + e.charAt(1)).toLowerCase(); }
function Xw(n) { let e = new Map; for (let t of n.units)
    for (let s of t.create)
        dn(s) && e.set(s.xref, s); for (let t of n.units)
    for (let s of t.create)
        if (s.kind === u.ExtractedAttribute && s.bindingKind === _.Attribute && uh(s.expression)) {
            let r = e.get(s.target);
            if (r !== void 0 && (r.kind === u.Template || r.kind === u.ConditionalCreate || r.kind === u.ConditionalBranchCreate) && r.templateKind === Re.Structural)
                continue;
            if (s.name === "style") {
                let i = Gw(s.expression.value);
                for (let o = 0; o < i.length - 1; o += 2)
                    S.insertBefore(ft(s.target, _.StyleProperty, null, i[o], g(i[o + 1]), null, null, V.STYLE), s);
                S.remove(s);
            }
            else if (s.name === "class") {
                let i = s.expression.value.trim().split(/\s+/g);
                for (let o of i)
                    S.insertBefore(ft(s.target, _.ClassName, null, o, null, null, null, V.NONE), s);
                S.remove(s);
            }
        } }
function Qw(n) { tr(n.root, n.componentName, { index: 0 }); }
function tr(n, e, t) { n.fnName === null && (n.fnName = n.job.pool.uniqueName(yn(`${e}_${n.job.fnSuffix}`), !1)); let s = new Map; for (let r of n.ops())
    switch (r.kind) {
        case u.Property:
        case u.DomProperty:
            r.bindingKind === _.LegacyAnimation && (r.name = "@" + r.name);
            break;
        case u.Animation:
            if (r.handlerFnName === null) {
                let l = r.name.replace(".", "");
                r.handlerFnName = `${n.fnName}_${l}_cb`, r.handlerFnName = yn(r.handlerFnName);
            }
            break;
        case u.AnimationListener:
            if (r.handlerFnName !== null)
                break;
            if (!r.hostListener && r.targetSlot.slot === null)
                throw new Error("Expected a slot to be assigned");
            let i = r.name.replace(".", "");
            r.hostListener ? r.handlerFnName = `${e}_${i}_HostBindingHandler` : r.handlerFnName = `${n.fnName}_${r.tag.replace("-", "_")}_${i}_${r.targetSlot.slot}_listener`, r.handlerFnName = yn(r.handlerFnName);
            break;
        case u.Listener:
            if (r.handlerFnName !== null)
                break;
            if (!r.hostListener && r.targetSlot.slot === null)
                throw new Error("Expected a slot to be assigned");
            let o = "";
            r.isLegacyAnimationListener && (r.name = `@${r.name}.${r.legacyAnimationPhase}`, o = "animation"), r.hostListener ? r.handlerFnName = `${e}_${o}${r.name}_HostBindingHandler` : r.handlerFnName = `${n.fnName}_${r.tag.replace("-", "_")}_${o}${r.name}_${r.targetSlot.slot}_listener`, r.handlerFnName = yn(r.handlerFnName);
            break;
        case u.TwoWayListener:
            if (r.handlerFnName !== null)
                break;
            if (r.targetSlot.slot === null)
                throw new Error("Expected a slot to be assigned");
            r.handlerFnName = yn(`${n.fnName}_${r.tag.replace("-", "_")}_${r.name}_${r.targetSlot.slot}_listener`);
            break;
        case u.Variable:
            s.set(r.xref, Yw(r.variable, t));
            break;
        case u.RepeaterCreate:
            if (!(n instanceof Ye))
                throw new Error("AssertionError: must be compiling a component");
            if (r.handle.slot === null)
                throw new Error("Expected slot to be assigned");
            if (r.emptyView !== null) {
                let l = n.job.views.get(r.emptyView);
                tr(l, `${e}_${r.functionNameSuffix}Empty_${r.handle.slot + 2}`, t);
            }
            tr(n.job.views.get(r.xref), `${e}_${r.functionNameSuffix}_${r.handle.slot + 1}`, t);
            break;
        case u.Projection:
            if (!(n instanceof Ye))
                throw new Error("AssertionError: must be compiling a component");
            if (r.handle.slot === null)
                throw new Error("Expected slot to be assigned");
            if (r.fallbackView !== null) {
                let l = n.job.views.get(r.fallbackView);
                tr(l, `${e}_ProjectionFallback_${r.handle.slot}`, t);
            }
            break;
        case u.ConditionalCreate:
        case u.ConditionalBranchCreate:
        case u.Template:
            if (!(n instanceof Ye))
                throw new Error("AssertionError: must be compiling a component");
            let a = n.job.views.get(r.xref);
            if (r.handle.slot === null)
                throw new Error("Expected slot to be assigned");
            let c = r.functionNameSuffix.length === 0 ? "" : `_${r.functionNameSuffix}`;
            tr(a, `${e}${c}_${r.handle.slot}`, t);
            break;
        case u.StyleProp:
            r.name = qu(Zw(r.name));
            break;
        case u.ClassProp:
            r.name = qu(r.name);
            break;
    } for (let r of n.ops())
    ae(r, i => { if (!(!(i instanceof Ht) || i.name !== null)) {
        if (!s.has(i.xref))
            throw new Error(`Variable ${i.xref} not yet named`);
        i.name = s.get(i.xref);
    } }); }
function Yw(n, e) { if (n.name === null)
    switch (n.kind) {
        case Ee.Context:
            n.name = `ctx_r${e.index++}`;
            break;
        case Ee.Identifier:
            let t = n.identifier === st ? "i" : "";
            n.name = `${n.identifier}_${t}r${++e.index}`;
            break;
        default:
            n.name = `_r${++e.index}`;
            break;
    } return n.name; }
function Zw(n) { return n.startsWith("--") ? n : Dh(n); }
function qu(n) { let e = n.indexOf("!important"); return e > -1 ? n.substring(0, e) : n; }
function Jw(n) { for (let e of n.units) {
    for (let t of e.functions)
        Ai(t.ops);
    for (let t of e.create)
        (t.kind === u.Listener || t.kind === u.Animation || t.kind === u.AnimationListener || t.kind === u.TwoWayListener) && Ai(t.handlerOps);
    Ai(e.create), Ai(e.update);
} }
function Ai(n) { for (let e of n) {
    if (e.kind !== u.Statement || !(e.statement instanceof ke) || !(e.statement.expr instanceof Ao))
        continue;
    let t = e.statement.expr.steps, s = !0;
    for (let r = e.next; r.kind !== u.ListEnd && s; r = r.next)
        ae(r, (i, o) => { if (!Bt(i))
            return i; if (s && !(o & M.InChildOperation))
            switch (i.kind) {
                case I.NextContext:
                    i.steps += t, S.remove(e), s = !1;
                    break;
                case I.GetCurrentView:
                case I.Reference:
                case I.ContextLetReference:
                    s = !1;
                    break;
            } });
} }
var Kw = "ng-container";
function eS(n) { for (let e of n.units) {
    let t = new Set;
    for (let s of e.create)
        s.kind === u.ElementStart && s.tag === Kw && (s.kind = u.ContainerStart, t.add(s.xref)), s.kind === u.ElementEnd && t.has(s.xref) && (s.kind = u.ContainerEnd);
} }
function tS(n, e) { let t = n.get(e); if (t === void 0)
    throw new Error("All attributes should have an element-like target."); return t; }
function nS(n) { let e = new Map; for (let t of n.units)
    for (let s of t.create)
        dn(s) && e.set(s.xref, s); for (let t of n.units)
    for (let s of t.create)
        (s.kind === u.ElementStart || s.kind === u.ContainerStart) && s.nonBindable && S.insertAfter(jm(s.xref), s), (s.kind === u.ElementEnd || s.kind === u.ContainerEnd) && tS(e, s.xref).nonBindable && S.insertBefore(zm(s.xref), s); }
function At(n) { return e => e.kind === n; }
function ar(n, e) { return t => t.kind === n && e === t.expression instanceof ne; }
function sS(n) { return n.kind === u.Listener && !(n.hostListener && n.isLegacyAnimationListener) || n.kind === u.TwoWayListener || n.kind === u.Animation || n.kind === u.AnimationListener; }
function rS(n) { return (n.kind === u.Property || n.kind === u.TwoWayProperty) && !(n.expression instanceof ne); }
var iS = [{ test: n => n.kind === u.Listener && n.hostListener && n.isLegacyAnimationListener }, { test: sS }], oS = [{ test: At(u.StyleMap), transform: Ho }, { test: At(u.ClassMap), transform: Ho }, { test: At(u.StyleProp) }, { test: At(u.ClassProp) }, { test: ar(u.Attribute, !0) }, { test: ar(u.Property, !0) }, { test: rS }, { test: ar(u.Attribute, !1) }, { test: At(u.Control) }], aS = [{ test: ar(u.DomProperty, !0) }, { test: ar(u.DomProperty, !1) }, { test: At(u.Attribute) }, { test: At(u.StyleMap), transform: Ho }, { test: At(u.ClassMap), transform: Ho }, { test: At(u.StyleProp) }, { test: At(u.ClassProp) }], Hu = new Set([u.Listener, u.TwoWayListener, u.AnimationListener, u.StyleMap, u.ClassMap, u.StyleProp, u.ClassProp, u.Property, u.TwoWayProperty, u.DomProperty, u.Attribute, u.Animation, u.Control]);
function cS(n) { for (let e of n.units) {
    Uu(e.create, iS);
    let t = e.job.kind === C.Host ? aS : oS;
    Uu(e.update, t);
} }
function Uu(n, e) { let t = [], s = null; for (let r of n) {
    let i = Yr(r) ? r.target : null;
    (!Hu.has(r.kind) || i !== s && s !== null && i !== null) && (S.insertBefore(Wu(t, e), r), t = [], s = null), Hu.has(r.kind) && (t.push(r), S.remove(r), s = i ?? s);
} n.push(Wu(t, e)); }
function Wu(n, e) { let t = Array.from(e, () => new Array); for (let s of n) {
    let r = e.findIndex(i => i.test(s));
    t[r].push(s);
} return t.flatMap((s, r) => { let i = e[r].transform; return i ? i(s) : s; }); }
function Ho(n) { return n.slice(n.length - 1); }
function lS(n) { for (let e of n.units) {
    let t = wh(e);
    for (let s of e.ops())
        if (s.kind === u.Binding) {
            let r = pS(t, s.target);
            uS(s.name) && r.kind === u.Projection && S.remove(s);
        }
} }
function uS(n) { return n.toLowerCase() === "select"; }
function pS(n, e) { let t = n.get(e); if (t === void 0)
    throw new Error("All attributes should have an slottable target."); return t; }
function hS(n) { for (let e of n.units)
    fS(e); }
function fS(n) { for (let e of n.update)
    ae(e, (t, s) => { if (!Bt(t) || t.kind !== I.PipeBinding)
        return; if (s & M.InChildOperation)
        throw new Error("AssertionError: pipe bindings should not appear in child expressions"); let r = e.target; if (r == null)
        throw new Error("AssertionError: expected slot handle to be assigned for pipe creation"); dS(n, r, t); }); }
function dS(n, e, t) { for (let s = n.create.head.next; s.kind !== u.ListEnd; s = s.next) {
    if (!Os(s) || s.xref !== e)
        continue;
    for (; s.next.kind === u.Pipe;)
        s = s.next;
    let r = Qm(t.target, t.targetSlot, t.name);
    S.insertBefore(r, s.next);
    return;
} throw new Error(`AssertionError: unable to find insertion point for pipe ${t.name}`); }
function mS(n) { for (let e of n.units)
    for (let t of e.update)
        te(t, s => !(s instanceof Zn) || s.args.length <= 4 ? s : new ei(s.target, s.targetSlot, s.name, X(s.args), s.args.length), M.None); }
function gS(n) { Ph(n.root, 0); }
function Ph(n, e) { let t = null; for (let s of n.create)
    switch (s.kind) {
        case u.I18nStart:
            s.subTemplateIndex = e === 0 ? null : e, t = s;
            break;
        case u.I18nEnd:
            t.subTemplateIndex === null && (e = 0), t = null;
            break;
        case u.ConditionalCreate:
        case u.ConditionalBranchCreate:
        case u.Template:
            e = ki(n.job.views.get(s.xref), t, s.i18nPlaceholder, e);
            break;
        case u.RepeaterCreate:
            let r = n.job.views.get(s.xref);
            e = ki(r, t, s.i18nPlaceholder, e), s.emptyView !== null && (e = ki(n.job.views.get(s.emptyView), t, s.emptyI18nPlaceholder, e));
            break;
        case u.Projection:
            s.fallbackView !== null && (e = ki(n.job.views.get(s.fallbackView), t, s.fallbackViewI18nPlaceholder, e));
            break;
    } return e; }
function ki(n, e, t, s) { if (t !== void 0) {
    if (e === null)
        throw Error("Expected template with i18n placeholder to be in an i18n block.");
    s++, vS(n, e);
} return Ph(n, s); }
function vS(n, e) { if (n.create.head.next?.kind !== u.I18nStart) {
    let t = n.job.allocateXrefId();
    S.insertAfter(Jo(t, e.message, e.root, null), n.create.head), S.insertBefore(Ko(t, null), n.create.tail);
} }
function wS(n) { for (let e of n.units)
    for (let t of e.ops())
        ae(t, s => { if (!(s instanceof Yn) || s.body === null)
            return; let r = new Mc(s.args.length); s.fn = n.pool.getSharedConstant(r, s.body), s.body = null; }); }
var Mc = class extends Er {
    numArgs;
    constructor(e) { super(), this.numArgs = e; }
    keyOf(e) { return e instanceof hn ? `param(${e.index})` : super.keyOf(e); }
    toSharedConstantDeclaration(e, t) { let s = []; for (let i = 0; i < this.numArgs; i++)
        s.push(new he("a" + i, ge)); let r = k(t, i => i instanceof hn ? F("a" + i.index) : i, M.None); return new ve(e, new rn(s, r), void 0, xe.Final); }
};
function SS(n) { for (let e of n.units)
    for (let t of e.update)
        te(t, (s, r) => r & M.InChildOperation ? s : s instanceof Dt ? ES(s) : s instanceof vt ? xS(s) : s, M.None); }
function ES(n) { let e = [], t = []; for (let s of n.entries) {
    if (s instanceof Vn) {
        if (s.expression.isConstant())
            e.push(s);
        else {
            let r = t.length;
            t.push(s.expression), e.push(new Vn(new hn(r)));
        }
        continue;
    }
    if (s.isConstant())
        e.push(s);
    else {
        let r = t.length;
        t.push(s), e.push(new hn(r));
    }
} return new Yn(X(e), t); }
function xS(n) { let e = [], t = []; for (let s of n.entries) {
    if (s instanceof on) {
        if (s.expression.isConstant())
            e.push(s);
        else {
            let r = t.length;
            t.push(s.expression), e.push(new on(new hn(r)));
        }
        continue;
    }
    if (s.value.isConstant())
        e.push(s);
    else {
        let r = t.length;
        t.push(s.value), e.push(new ys(s.key, new hn(r), s.quoted));
    }
} return new Yn(new vt(e), t); }
var yS = new Set(["d", "i", "m", "s", "u", "v"]);
function CS(n) { for (let e of n.units)
    for (let t of e.ops())
        te(t, s => s instanceof xs && bS(s) ? n.pool.getSharedConstant(new Rc, s) : s, M.None); }
function bS(n) { if (!n.flags)
    return !0; for (let e = 0; e < n.flags.length; e++)
    if (!yS.has(n.flags[e]))
        return !1; return !0; }
var Rc = class extends Er {
    toSharedConstantDeclaration(e, t) { return new ve(e, t, void 0, xe.Final); }
};
function AS(n, e, t, s, r) { return wn(f.element, n, e, t, s, r); }
function kS(n, e, t, s, r) { return wn(f.elementStart, n, e, t, s, r); }
function TS(n, e, t, s) { let r = [g(n), e]; return t !== null && r.push(t), B(f.foreignComponent, r, s); }
function _S(n, e, t) { return A(t ? f.foreignContentFn : f.foreignContent).callFn([g(n), g(e)]); }
function wn(n, e, t, s, r, i) { let o = [g(e)]; return t !== null && o.push(g(t)), r !== null ? o.push(g(s), g(r)) : s !== null && o.push(g(s)), B(n, o, i); }
function Lh(n, e, t, s, r, i, o, a, c) { let l = [g(e), t, g(s), g(r), g(i), g(o)]; for (a !== null && (l.push(g(a)), l.push(A(f.templateRefExtractor))); l[l.length - 1].isEquivalent(Cs);)
    l.pop(); return B(n, l, c); }
function yl(n, e, t, s, r) { let i = [g(e)]; return t instanceof ne ? i.push(Vs(t, r)) : i.push(t), s !== null && i.push(s), B(n, i, r); }
function IS(n) { return B(f.elementEnd, [], n); }
function NS(n, e, t, s) { return wn(f.elementContainerStart, n, null, e, t, s); }
function DS(n, e, t, s) { return wn(f.elementContainer, n, null, e, t, s); }
function PS() { return B(f.elementContainerEnd, [], null); }
function LS(n, e, t, s, r, i, o, a) { return Lh(f.templateCreate, n, e, t, s, r, i, o, a); }
function BS() { return B(f.disableBindings, [], null); }
function $S() { return B(f.enableBindings, [], null); }
function MS(n, e, t, s, r) { let i = [g(n), e]; return t !== null && i.push(A(t)), B(s ? f.syntheticHostListener : f.listener, i, r); }
function ju(n, e) { return A(f.twoWayBindingSet).callFn([n, e]); }
function RS(n, e, t) { return B(f.twoWayListener, [g(n), e], t); }
function FS(n, e) { return B(f.pipe, [g(n), g(e)], null); }
function OS() { return B(f.namespaceHTML, [], null); }
function VS() { return B(f.namespaceSVG, [], null); }
function qS() { return B(f.namespaceMathML, [], null); }
function HS(n, e) { return B(f.advance, n > 1 ? [g(n)] : [], e); }
function US(n) { return A(f.reference).callFn([g(n)]); }
function WS(n) { return A(f.nextContext).callFn(n === 1 ? [] : [g(n)]); }
function jS() { return A(f.getCurrentView).callFn([]); }
function zS(n) { return A(f.restoreView).callFn([n]); }
function GS(n) { return A(f.resetView).callFn([n]); }
function XS(n, e, t) { let s = [g(n, null)]; return e !== "" && s.push(g(e)), B(f.text, s, t); }
function QS(n, e, t, s, r, i, o, a, c, l, p) { let h = [g(n), g(e), t ?? g(null), g(s), g(r), g(i), o ?? g(null), a ?? g(null), c ? A(f.deferEnableTimerScheduling) : g(null), g(p)], d; for (; (d = h[h.length - 1]) !== null && d instanceof Ae && d.value === null;)
    h.pop(); return B(f.defer, h, l); }
function YS(n) { return B(f.enableIncrementalHydrationRuntime, [], n); }
var ZS = new Map([[G.Idle, { none: f.deferOnIdle, prefetch: f.deferPrefetchOnIdle, hydrate: f.deferHydrateOnIdle }], [G.Immediate, { none: f.deferOnImmediate, prefetch: f.deferPrefetchOnImmediate, hydrate: f.deferHydrateOnImmediate }], [G.Timer, { none: f.deferOnTimer, prefetch: f.deferPrefetchOnTimer, hydrate: f.deferHydrateOnTimer }], [G.Hover, { none: f.deferOnHover, prefetch: f.deferPrefetchOnHover, hydrate: f.deferHydrateOnHover }], [G.Interaction, { none: f.deferOnInteraction, prefetch: f.deferPrefetchOnInteraction, hydrate: f.deferHydrateOnInteraction }], [G.Viewport, { none: f.deferOnViewport, prefetch: f.deferPrefetchOnViewport, hydrate: f.deferHydrateOnViewport }], [G.Never, { none: f.deferHydrateNever, prefetch: f.deferHydrateNever, hydrate: f.deferHydrateNever }]]);
function JS(n, e, t, s) { let r = ZS.get(n)?.[t]; if (r === void 0)
    throw new Error(`Unable to determine instruction for trigger ${n}`); return B(r, e, s); }
function KS(n) { return B(f.projectionDef, n ? [n] : [], null); }
function eE(n, e, t, s, r, i, o) { let a = [g(n)]; return (e !== 0 || t !== null || s !== null) && (a.push(g(e)), t !== null && a.push(t), s !== null && (t === null && a.push(g(null)), a.push(F(s), g(r), g(i)))), B(f.projection, a, o); }
function tE(n, e, t, s) { let r = [g(n), g(e)]; return t !== null && r.push(g(t)), B(f.i18nStart, r, s); }
function nE(n, e, t, s, r, i, o, a) { let c = [g(n), e, g(t), g(s), g(r), g(i)]; for (o !== null && (c.push(g(o)), c.push(A(f.templateRefExtractor))); c[c.length - 1].isEquivalent(Cs);)
    c.pop(); return B(f.conditionalCreate, c, a); }
function sE(n, e, t, s, r, i, o, a) { let c = [g(n), e, g(t), g(s), g(r), g(i)]; for (o !== null && (c.push(g(o)), c.push(A(f.templateRefExtractor))); c[c.length - 1].isEquivalent(Cs);)
    c.pop(); return B(f.conditionalBranchCreate, c, a); }
function rE(n, e, t, s, r, i, o, a, c, l, p, h, d, v) { let w = [g(n), F(e), g(t), g(s), g(r), g(i), o]; return (a || c !== null) && (w.push(g(a)), c !== null && (w.push(F(c), g(l), g(p)), (h !== null || d !== null) && w.push(g(h)), d !== null && w.push(g(d)))), B(f.repeaterCreate, w, v); }
function iE(n, e) { return B(f.repeater, [n], e); }
function oE(n, e, t) { return n === "prefetch" ? B(f.deferPrefetchWhen, [e], t) : n === "hydrate" ? B(f.deferHydrateWhen, [e], t) : B(f.deferWhen, [e], t); }
function aE(n, e) { return B(f.declareLet, [g(n)], e); }
function cE(n, e) { return A(f.storeLet).callFn([n], e); }
function lE(n) { return A(f.readContextLet).callFn([g(n)]); }
function uE(n, e, t, s) { let r = [g(n), g(e)]; return t && r.push(g(t)), B(f.i18n, r, s); }
function pE(n) { return B(f.i18nEnd, [], n); }
function hE(n, e) { let t = [g(n), g(e)]; return B(f.i18nAttributes, t, null); }
function fE(n, e, t) { return yl(f.ariaProperty, n, e, null, t); }
function dE(n, e, t, s) { return yl(f.property, n, e, t, s); }
function mE(n) { return B(f.control, [], n); }
function gE(n) { return B(f.controlCreate, [], n); }
function vE(n, e, t, s) { let r = [g(n), e]; return t !== null && r.push(t), B(f.twoWayProperty, r, s); }
function wE(n, e, t, s, r) { let i = [g(n)]; return e instanceof ne ? i.push(Vs(e, r)) : i.push(e), (t !== null || s !== null) && i.push(t ?? g(null)), s !== null && i.push(g(s)), B(f.attribute, i, null); }
function SE(n, e, t, s) { let r = [g(n)]; return e instanceof ne ? r.push(Vs(e, s)) : r.push(e), t !== null && r.push(g(t)), B(f.styleProp, r, s); }
function EE(n, e, t) { return B(f.classProp, [g(n), e], t); }
function xE(n, e) { let t = n instanceof ne ? Vs(n, e) : n; return B(f.styleMap, [t], e); }
function yE(n, e) { let t = n instanceof ne ? Vs(n, e) : n; return B(f.classMap, [t], e); }
function CE(n, e, t, s, r) { return wn(f.domElement, n, e, t, s, r); }
function bE(n, e, t, s, r) { return wn(f.domElementStart, n, e, t, s, r); }
function AE(n) { return B(f.domElementEnd, [], n); }
function kE(n, e, t, s) { return wn(f.domElementContainerStart, n, null, e, t, s); }
function TE(n, e, t, s) { return wn(f.domElementContainer, n, null, e, t, s); }
function _E() { return B(f.domElementContainerEnd, [], null); }
function IE(n, e, t, s) { let r = [g(n), e]; return t !== null && r.push(A(t)), B(f.domListener, r, s); }
function NE(n, e, t, s, r, i, o, a) { return Lh(f.domTemplate, n, e, t, s, r, i, o, a); }
var zu = [f.pipeBind1, f.pipeBind2, f.pipeBind3, f.pipeBind4];
function DE(n, e, t) { if (t.length < 1 || t.length > zu.length)
    throw new Error("pipeBind() argument count out of bounds"); let s = zu[t.length - 1]; return A(s).callFn([g(n), g(e), ...t]); }
function PE(n, e, t) { return A(f.pipeBindV).callFn([g(n), g(e), t]); }
function LE(n, e, t) { let s = Bh(n, e); return XE(jE, [], s, t); }
function BE(n, e) { return B(f.i18nExp, [n], e); }
function $E(n, e) { return B(f.i18nApply, [g(n)], e); }
function ME(n, e, t, s) { return yl(f.domProperty, n, e, t, s); }
function RE(n, e, t, s) { let r = [e]; t !== null && r.push(t); let i = n === "enter" ? f.animationEnter : f.animationLeave; return B(i, r, s); }
function FE(n, e, t, s) { let i = [e instanceof ne ? Vs(e, s) : e]; t !== null && i.push(t); let o = n === "enter" ? f.animationEnter : f.animationLeave; return B(o, i, s); }
function OE(n, e, t, s) { let r = [e], i = n === "enter" ? f.animationEnterListener : f.animationLeaveListener; return B(i, r, s); }
function VE(n, e, t) { return B(f.syntheticHostProperty, [g(n), e], t); }
function qE(n, e, t) { return Cl(GE, [g(n), e], t, null); }
function HE(n, e) { return B(f.attachSourceLocations, [g(n), e], null); }
function UE(n, e, t) { return A(f.arrowFunction).callFn([g(n), e, t]); }
function Bh(n, e) { if (n.length < 1 || e.length !== n.length - 1)
    throw new Error("AssertionError: expected specific shape of args for strings/expressions in interpolation"); let t = []; if (e.length === 1 && n[0] === "" && n[1] === "")
    t.push(e[0]);
else {
    let s;
    for (s = 0; s < e.length; s++)
        t.push(g(n[s]), e[s]);
    t.push(g(n[s]));
} return t; }
function Vs(n, e) { let t = Bh(n.strings, n.expressions); return Cl(zE, [], t, e); }
function B(n, e, t) { let s = A(n).callFn(e, t); return rt(new ke(s, t)); }
function WE(n, e, t) { let s = [n]; return e !== null && s.push(e), B(f.conditional, s, t); }
var jE = { constant: [f.textInterpolate, f.textInterpolate1, f.textInterpolate2, f.textInterpolate3, f.textInterpolate4, f.textInterpolate5, f.textInterpolate6, f.textInterpolate7, f.textInterpolate8], variable: f.textInterpolateV, mapping: n => { if (n % 2 === 0)
        throw new Error("Expected odd number of arguments"); return (n - 1) / 2; } }, zE = { constant: [f.interpolate, f.interpolate1, f.interpolate2, f.interpolate3, f.interpolate4, f.interpolate5, f.interpolate6, f.interpolate7, f.interpolate8], variable: f.interpolateV, mapping: n => { if (n % 2 === 0)
        throw new Error("Expected odd number of arguments"); return (n - 1) / 2; } }, GE = { constant: [f.pureFunction0, f.pureFunction1, f.pureFunction2, f.pureFunction3, f.pureFunction4, f.pureFunction5, f.pureFunction6, f.pureFunction7, f.pureFunction8], variable: f.pureFunctionV, mapping: n => n };
function Cl(n, e, t, s) { let r = n.mapping(t.length), i = t.at(-1); if (t.length > 1 && i instanceof Ae && i.value === "" && t.pop(), r < n.constant.length)
    return A(n.constant[r]).callFn([...e, ...t], s); if (n.variable !== null)
    return A(n.variable).callFn([...e, X(t)], s); throw new Error("AssertionError: unable to call variadic function"); }
function XE(n, e, t, s) { return rt(Cl(n, e, t, s).toStmt()); }
var QE = new Map([["window", f.resolveWindow], ["document", f.resolveDocument], ["body", f.resolveBody]]), YE = new Map([["class", "className"], ["for", "htmlFor"], ["formaction", "formAction"], ["innerHtml", "innerHTML"], ["readonly", "readOnly"], ["tabindex", "tabIndex"]]);
function ZE(n) { for (let e of n.units)
    JE(e, e.create), na(e, e.update); }
function JE(n, e) { for (let t of e)
    switch (te(t, s => $h(n, s), M.None), t.kind) {
        case u.Text:
            S.replace(t, XS(t.handle.slot, t.initialValue, t.sourceSpan));
            break;
        case u.ElementStart:
            S.replace(t, n.job.mode === Ve.DomOnly ? bE(t.handle.slot, t.tag, t.attributes, t.localRefs, t.startSourceSpan) : kS(t.handle.slot, t.tag, t.attributes, t.localRefs, t.startSourceSpan));
            break;
        case u.Element:
            S.replace(t, n.job.mode === Ve.DomOnly ? CE(t.handle.slot, t.tag, t.attributes, t.localRefs, t.wholeSourceSpan) : AS(t.handle.slot, t.tag, t.attributes, t.localRefs, t.wholeSourceSpan));
            break;
        case u.ForeignComponent:
            let s = t.props.size > 0 ? nt(Array.from(t.props.entries()).map(([ee, ra]) => ({ key: ee, value: ra, quoted: Mp(ee) }))) : null;
            S.replace(t, TS(t.handle.slot, g(t.constIndex), s, t.sourceSpan));
            break;
        case u.ElementEnd:
            S.replace(t, n.job.mode === Ve.DomOnly ? AE(t.sourceSpan) : IS(t.sourceSpan));
            break;
        case u.ContainerStart:
            S.replace(t, n.job.mode === Ve.DomOnly ? kE(t.handle.slot, t.attributes, t.localRefs, t.startSourceSpan) : NS(t.handle.slot, t.attributes, t.localRefs, t.startSourceSpan));
            break;
        case u.Container:
            S.replace(t, n.job.mode === Ve.DomOnly ? TE(t.handle.slot, t.attributes, t.localRefs, t.wholeSourceSpan) : DS(t.handle.slot, t.attributes, t.localRefs, t.wholeSourceSpan));
            break;
        case u.ContainerEnd:
            S.replace(t, n.job.mode === Ve.DomOnly ? _E() : PS());
            break;
        case u.I18nStart:
            S.replace(t, tE(t.handle.slot, t.messageIndex, t.subTemplateIndex, t.sourceSpan));
            break;
        case u.I18nEnd:
            S.replace(t, pE(t.sourceSpan));
            break;
        case u.I18n:
            S.replace(t, uE(t.handle.slot, t.messageIndex, t.subTemplateIndex, t.sourceSpan));
            break;
        case u.I18nAttributes:
            if (t.i18nAttributesConfig === null)
                throw new Error("AssertionError: i18nAttributesConfig was not set");
            S.replace(t, hE(t.handle.slot, t.i18nAttributesConfig));
            break;
        case u.Template:
            if (!(n instanceof Ye))
                throw new Error("AssertionError: must be compiling a component");
            if (Array.isArray(t.localRefs))
                throw new Error("AssertionError: local refs array should have been extracted into a constant");
            let r = n.job.views.get(t.xref);
            S.replace(t, t.templateKind === Re.Block || n.job.mode === Ve.DomOnly ? NE(t.handle.slot, F(r.fnName), r.decls, r.vars, t.tag, t.attributes, t.localRefs, t.startSourceSpan) : LS(t.handle.slot, F(r.fnName), r.decls, r.vars, t.tag, t.attributes, t.localRefs, t.startSourceSpan));
            break;
        case u.DisableBindings:
            S.replace(t, BS());
            break;
        case u.EnableBindings:
            S.replace(t, $S());
            break;
        case u.Pipe:
            S.replace(t, FS(t.handle.slot, t.name));
            break;
        case u.DeclareLet:
            S.replace(t, aE(t.handle.slot, t.sourceSpan));
            break;
        case u.AnimationString:
            S.replace(t, FE(t.animationKind, t.expression, t.sanitizer, t.sourceSpan));
            break;
        case u.Animation:
            let i = Ti(n, t.handlerFnName, t.handlerOps, !1);
            S.replace(t, RE(t.animationKind, i, t.sanitizer, t.sourceSpan));
            break;
        case u.AnimationListener:
            let o = Ti(n, t.handlerFnName, t.handlerOps, t.consumesDollarEvent);
            S.replace(t, OE(t.animationKind, o, null, t.sourceSpan));
            break;
        case u.Listener:
            let a = Ti(n, t.handlerFnName, t.handlerOps, t.consumesDollarEvent), c = t.eventTarget ? QE.get(t.eventTarget) : null;
            if (c === void 0)
                throw new Error(`Unexpected global target '${t.eventTarget}' defined for '${t.name}' event. Supported list of global targets: window,document,body.`);
            S.replace(t, n.job.mode === Ve.DomOnly && !t.hostListener && !t.isLegacyAnimationListener ? IE(t.name, a, c, t.sourceSpan) : MS(t.name, a, c, t.hostListener && t.isLegacyAnimationListener, t.sourceSpan));
            break;
        case u.TwoWayListener:
            S.replace(t, RS(t.name, Ti(n, t.handlerFnName, t.handlerOps, !0), t.sourceSpan));
            break;
        case u.Variable:
            if (t.variable.name === null)
                throw new Error(`AssertionError: unnamed variable ${t.xref}`);
            S.replace(t, rt(new ve(t.variable.name, t.initializer, ge, xe.Final)));
            break;
        case u.Namespace:
            switch (t.active) {
                case oe.HTML:
                    S.replace(t, OS());
                    break;
                case oe.SVG:
                    S.replace(t, VS());
                    break;
                case oe.Math:
                    S.replace(t, qS());
                    break;
            }
            break;
        case u.Defer:
            let l = !!t.loadingMinimumTime || !!t.loadingAfterTime || !!t.placeholderMinimumTime;
            S.replace(t, QS(t.handle.slot, t.mainSlot.slot, t.resolverFn, t.loadingSlot?.slot ?? null, t.placeholderSlot?.slot ?? null, t.errorSlot?.slot ?? null, t.loadingConfig, t.placeholderConfig, l, t.sourceSpan, t.flags));
            break;
        case u.DeferOn:
            let p = [], h = t.trigger.kind;
            switch (h) {
                case G.Never:
                case G.Immediate: break;
                case G.Idle:
                    t.trigger.timeout != null && (p = [g(t.trigger.timeout)]);
                    break;
                case G.Timer:
                    p = [g(t.trigger.delay)];
                    break;
                case G.Viewport:
                    t.modifier === "hydrate" ? p = t.trigger.options ? [t.trigger.options] : [] : (p = [g(t.trigger.targetSlot?.slot ?? null)], t.trigger.targetSlotViewSteps !== 0 ? p.push(g(t.trigger.targetSlotViewSteps)) : t.trigger.options && p.push(g(null)), t.trigger.options && p.push(t.trigger.options));
                    break;
                case G.Interaction:
                case G.Hover:
                    t.modifier === "hydrate" ? p = [] : (p = [g(t.trigger.targetSlot?.slot ?? null)], t.trigger.targetSlotViewSteps !== 0 && p.push(g(t.trigger.targetSlotViewSteps)));
                    break;
                default: {
                    let ee = h;
                    throw new Error(`AssertionError: Unsupported reification of defer trigger kind ${ee}`);
                }
            }
            S.replace(t, JS(t.trigger.kind, p, t.modifier, t.sourceSpan));
            break;
        case u.ProjectionDef:
            S.replace(t, KS(t.def));
            break;
        case u.EnableIncrementalHydrationRuntime:
            S.replace(t, YS(t.sourceSpan));
            break;
        case u.Projection:
            if (t.handle.slot === null)
                throw new Error("No slot was assigned for project instruction");
            let d = null, v = null, w = null;
            if (t.fallbackView !== null) {
                if (!(n instanceof Ye))
                    throw new Error("AssertionError: must be compiling a component");
                let ee = n.job.views.get(t.fallbackView);
                if (ee === void 0)
                    throw new Error("AssertionError: projection had fallback view xref, but fallback view was not found");
                if (ee.fnName === null || ee.decls === null || ee.vars === null)
                    throw new Error("AssertionError: expected projection fallback view to have been named and counted");
                d = ee.fnName, v = ee.decls, w = ee.vars;
            }
            S.replace(t, eE(t.handle.slot, t.projectionSlotIndex, t.attributes, d, v, w, t.sourceSpan));
            break;
        case u.ConditionalCreate:
            if (!(n instanceof Ye))
                throw new Error("AssertionError: must be compiling a component");
            if (Array.isArray(t.localRefs))
                throw new Error("AssertionError: local refs array should have been extracted into a constant");
            let y = n.job.views.get(t.xref);
            S.replace(t, nE(t.handle.slot, F(y.fnName), y.decls, y.vars, t.tag, t.attributes, t.localRefs, t.startSourceSpan));
            break;
        case u.ConditionalBranchCreate:
            if (!(n instanceof Ye))
                throw new Error("AssertionError: must be compiling a component");
            if (Array.isArray(t.localRefs))
                throw new Error("AssertionError: local refs array should have been extracted into a constant");
            let b = n.job.views.get(t.xref);
            S.replace(t, sE(t.handle.slot, F(b.fnName), b.decls, b.vars, t.tag, t.attributes, t.localRefs, t.startSourceSpan));
            break;
        case u.RepeaterCreate:
            if (t.handle.slot === null)
                throw new Error("No slot was assigned for repeater instruction");
            if (!(n instanceof Ye))
                throw new Error("AssertionError: must be compiling a component");
            let T = n.job.views.get(t.xref);
            if (T.fnName === null)
                throw new Error("AssertionError: expected repeater primary view to have been named");
            let $ = null, W = null, J = null;
            if (t.emptyView !== null) {
                let ee = n.job.views.get(t.emptyView);
                if (ee === void 0)
                    throw new Error("AssertionError: repeater had empty view xref, but empty view was not found");
                if (ee.fnName === null || ee.decls === null || ee.vars === null)
                    throw new Error("AssertionError: expected repeater empty view to have been named and counted");
                $ = ee.fnName, W = ee.decls, J = ee.vars;
            }
            S.replace(t, rE(t.handle.slot, T.fnName, t.decls, t.vars, t.tag, t.attributes, tx(n, t), t.usesComponentInstance, $, W, J, t.emptyTag, t.emptyAttributes, t.wholeSourceSpan));
            break;
        case u.SourceLocation:
            let Mt = X(t.locations.map(({ targetSlot: ee, offset: ra, line: uf, column: pf }) => { if (ee.slot === null)
                throw new Error("No slot was assigned for source location"); return X([g(ee.slot), g(ra), g(uf), g(pf)]); }));
            S.replace(t, HE(t.templatePath, Mt));
            break;
        case u.ControlCreate:
            S.replace(t, gE(t.sourceSpan));
            break;
        case u.Statement: break;
        default: throw new Error(`AssertionError: Unsupported reification of create op ${u[t.kind]}`);
    } }
function na(n, e) { for (let t of e)
    switch (te(t, s => $h(n, s), M.None), t.kind) {
        case u.Advance:
            S.replace(t, HS(t.delta, t.sourceSpan));
            break;
        case u.Property:
            S.replace(t, n.job.mode === Ve.DomOnly && t.bindingKind !== _.LegacyAnimation && t.bindingKind !== _.Animation ? Gu(t) : KE(t));
            break;
        case u.Control:
            S.replace(t, ex(t));
            break;
        case u.TwoWayProperty:
            S.replace(t, vE(t.name, t.expression, t.sanitizer, t.sourceSpan));
            break;
        case u.StyleProp:
            S.replace(t, SE(t.name, t.expression, t.unit, t.sourceSpan));
            break;
        case u.ClassProp:
            S.replace(t, EE(t.name, t.expression, t.sourceSpan));
            break;
        case u.StyleMap:
            S.replace(t, xE(t.expression, t.sourceSpan));
            break;
        case u.ClassMap:
            S.replace(t, yE(t.expression, t.sourceSpan));
            break;
        case u.I18nExpression:
            S.replace(t, BE(t.expression, t.sourceSpan));
            break;
        case u.I18nApply:
            S.replace(t, $E(t.handle.slot, t.sourceSpan));
            break;
        case u.InterpolateText:
            S.replace(t, LE(t.interpolation.strings, t.interpolation.expressions, t.sourceSpan));
            break;
        case u.Attribute:
            S.replace(t, wE(t.name, t.expression, t.sanitizer, t.namespace, t.sourceSpan));
            break;
        case u.DomProperty:
            if (t.expression instanceof ne)
                throw new Error("not yet handled");
            t.bindingKind === _.LegacyAnimation || t.bindingKind === _.Animation ? S.replace(t, VE(t.name, t.expression, t.sourceSpan)) : S.replace(t, Gu(t));
            break;
        case u.Variable:
            if (t.variable.name === null)
                throw new Error(`AssertionError: unnamed variable ${t.xref}`);
            S.replace(t, rt(new ve(t.variable.name, t.initializer, ge, xe.Final)));
            break;
        case u.Conditional:
            if (t.processed === null)
                throw new Error("Conditional test was not set.");
            S.replace(t, WE(t.processed, t.contextValue, t.sourceSpan));
            break;
        case u.Repeater:
            S.replace(t, iE(t.collection, t.sourceSpan));
            break;
        case u.DeferWhen:
            S.replace(t, oE(t.modifier, t.expr, t.sourceSpan));
            break;
        case u.StoreLet: throw new Error(`AssertionError: unexpected storeLet ${t.declaredName}`);
        case u.Statement: break;
        default: throw new Error(`AssertionError: Unsupported reification of update op ${u[t.kind]}`);
    } }
function Gu(n) { return ME(YE.get(n.name) ?? n.name, n.expression, n.sanitizer, n.sourceSpan); }
function KE(n) { return Sh(n.name) ? fE(n.name, n.expression, n.sourceSpan) : dE(n.name, n.expression, n.sanitizer, n.sourceSpan); }
function ex(n) { return mE(n.sourceSpan); }
function $h(n, e) { if (!Bt(e))
    return e; switch (e.kind) {
    case I.NextContext: return WS(e.steps);
    case I.Reference: return US(e.targetSlot.slot + 1 + e.offset);
    case I.ForeignContent:
        if (!(n instanceof Ye))
            throw new Error("AssertionError: must be compiling a component");
        let t = n.job.views.get(e.childrenViewXref).contextVariables.size > 0;
        return _S(e.childrenViewHandle.slot, e.foreignComponentConstIndex, t);
    case I.LexicalRead: throw new Error(`AssertionError: unresolved LexicalRead of ${e.name}`);
    case I.TwoWayBindingSet: throw new Error("AssertionError: unresolved TwoWayBindingSet");
    case I.RestoreView:
        if (typeof e.view == "number")
            throw new Error("AssertionError: unresolved RestoreView");
        return zS(e.view);
    case I.ResetView: return GS(e.expr);
    case I.GetCurrentView: return jS();
    case I.ReadVariable:
        if (e.name === null)
            throw new Error(`Read of unnamed variable ${e.xref}`);
        return F(e.name);
    case I.ReadTemporaryExpr:
        if (e.name === null)
            throw new Error(`Read of unnamed temporary ${e.xref}`);
        return F(e.name);
    case I.AssignTemporaryExpr:
        if (e.name === null)
            throw new Error(`Assign of unnamed temporary ${e.xref}`);
        return F(e.name).set(e.expr);
    case I.PureFunctionExpr:
        if (e.fn === null)
            throw new Error("AssertionError: expected PureFunctions to have been extracted");
        return qE(e.varOffset, e.fn, e.args);
    case I.PureFunctionParameterExpr: throw new Error("AssertionError: expected PureFunctionParameterExpr to have been extracted");
    case I.PipeBinding: return DE(e.targetSlot.slot, e.varOffset, e.args);
    case I.PipeBindingVariadic: return PE(e.targetSlot.slot, e.varOffset, e.args);
    case I.SlotLiteralExpr: return g(e.slot.slot);
    case I.ContextLetReference: return lE(e.targetSlot.slot);
    case I.StoreLet: return cE(e.value, e.sourceSpan);
    case I.TrackContext: return F("this");
    case I.ArrowFunction:
        if (e.varOffset === null)
            throw new Error("AssertionError: variable offset was not assigned to arrow function");
        return UE(e.varOffset, n.job.pool.getSharedFunctionReference(nx(n, e), "arrowFn"), F(st));
    default: throw new Error(`AssertionError: Unsupported reification of ir.Expression kind: ${I[e.kind]}`);
} }
function Ti(n, e, t, s) { na(n, t); let r = []; for (let o of t) {
    if (o.kind !== u.Statement)
        throw new Error(`AssertionError: expected reified statements, but found op ${u[o.kind]}`);
    r.push(o.statement);
} let i = []; return s && i.push(new he("$event", ge)), an(i, r, void 0, void 0, e); }
function tx(n, e) { if (e.trackByFn !== null)
    return e.trackByFn; let t = [new he("$index", Rn), new he("$item", ge)], s; if (e.trackByOps === null)
    s = e.usesComponentInstance ? an(t, [new fe(e.track)]) : je(t, e.track);
else {
    na(n, e.trackByOps);
    let r = [];
    for (let i of e.trackByOps) {
        if (i.kind !== u.Statement)
            throw new Error(`AssertionError: expected reified statements, but found op ${u[i.kind]}`);
        r.push(i.statement);
    }
    s = e.usesComponentInstance || r.length !== 1 || !(r[0] instanceof fe) ? an(t, r) : je(t, r[0].value);
} return e.trackByFn = n.job.pool.getSharedFunctionReference(s, "_forTrack"), e.trackByFn; }
function nx(n, e) { na(n, e.ops); let t = []; for (let r of e.ops) {
    if (r.kind !== u.Statement)
        throw new Error(`AssertionError: expected reified statements, but found op ${u[r.kind]}`);
    t.push(r.statement);
} let s = t.length === 1 && t[0] instanceof fe ? t[0].value : t; return je([new he(e.contextName, ge), new he(e.currentViewName, ge)], je(e.parameters, s)); }
function sx(n) { for (let e of n.units)
    for (let t of e.update)
        switch (t.kind) {
            case u.Attribute:
            case u.Binding:
            case u.ClassProp:
            case u.ClassMap:
            case u.Property:
            case u.StyleProp:
            case u.StyleMap:
                t.expression instanceof ni && S.remove(t);
                break;
        } }
function rx(n) { for (let e of n.units)
    for (let t of e.create)
        switch (t.kind) {
            case u.I18nContext:
                S.remove(t);
                break;
            case u.I18nStart:
                t.context = null;
                break;
        } }
function ix(n) { for (let e of n.units)
    for (let t of e.update) {
        if (t.kind !== u.Variable || t.variable.kind !== Ee.Identifier || !(t.initializer instanceof Zr))
            continue;
        let s = t.variable.identifier, r = t;
        for (; r && r.kind !== u.ListEnd;)
            te(r, i => i instanceof me && i.name === s ? g(void 0) : i, M.None), r = r.prev;
    } }
function ox(n) { for (let e of n.units) {
    let t = new Set;
    for (let s of e.update)
        s.kind === u.I18nExpression && t.add(s.i18nOwner);
    for (let s of e.create)
        switch (s.kind) {
            case u.I18nAttributes:
                if (t.has(s.xref))
                    continue;
                S.remove(s);
        }
} }
function ax(n) { for (let e of n.units) {
    for (let t of e.functions)
        cr(e, t.ops);
    cr(e, e.create), cr(e, e.update);
} }
function cr(n, e) { let t = new Map; t.set(n.xref, F(st)); for (let s of e)
    switch (s.kind) {
        case u.Variable:
            s.variable.kind === Ee.Context && t.set(s.variable.view, new Ht(s.xref));
            break;
        case u.Animation:
        case u.AnimationListener:
        case u.Listener:
        case u.TwoWayListener:
            cr(n, s.handlerOps);
            break;
        case u.RepeaterCreate:
            s.trackByOps !== null && cr(n, s.trackByOps);
            break;
    } n === n.job.root && t.set(n.xref, F(st)); for (let s of e)
    te(s, r => { if (r instanceof pn) {
        if (!t.has(r.view))
            throw new Error(`No context found for reference to view ${r.view} from view ${n.xref}`);
        return t.get(r.view);
    }
    else
        return r; }, M.None); }
function cx(n) { for (let e of n.units)
    for (let t of e.create)
        if (t.kind === u.Defer) {
            if (t.resolverFn !== null)
                continue;
            if (t.ownResolverFn !== null) {
                if (t.handle.slot === null)
                    throw new Error("AssertionError: slot must be assigned before extracting defer deps functions");
                let s = e.fnName?.replace("_Template", "");
                t.resolverFn = n.pool.getSharedFunctionReference(t.ownResolverFn, `${s}_Defer_${t.handle.slot}_DepsFn`, !1);
            }
        } }
function lx(n) { for (let e of n.units)
    Xu(e.create), Xu(e.update); }
function Xu(n) { for (let e of n)
    (e.kind === u.Listener || e.kind === u.TwoWayListener || e.kind === u.AnimationListener) && te(e, t => t instanceof me && t.name === "$event" ? ((e.kind === u.Listener || e.kind === u.AnimationListener) && (e.consumesDollarEvent = !0), new dt(t.name)) : t, M.InChildOperation); }
function ux(n) { for (let e of n.units) {
    let t = new Map;
    for (let s of e.create)
        s.kind === u.ForeignComponent && t.set(s.xref, s);
    for (let s of e.create) {
        if (s.kind !== u.Content)
            continue;
        let r = t.get(s.target);
        if (r === void 0)
            throw new Error("AssertionError: ContentOp target not found");
        let i = s.propertyName.charAt(0).toUpperCase() + s.propertyName.slice(1), o = El(s.view, Re.NgTemplate, null, i, oe.HTML, void 0, s.startSourceSpan, s.sourceSpan);
        S.replace(s, o);
        let a = new cc(o.xref, o.handle, r.constIndex);
        r.props.set(s.propertyName, a);
    }
} }
function px(n) { let e = new Map, t = new Map; for (let s of n.units)
    for (let r of s.create)
        switch (r.kind) {
            case u.I18nContext:
                e.set(r.xref, r);
                break;
            case u.ElementStart:
                t.set(r.xref, r);
                break;
        } xt(n, n.root, e, t); }
function xt(n, e, t, s, r) { let i = null, o = new Map; for (let a of e.create)
    switch (a.kind) {
        case u.I18nStart:
            if (!a.context)
                throw Error("Could not find i18n context for i18n op");
            i = { i18nBlock: a, i18nContext: t.get(a.context) };
            break;
        case u.I18nEnd:
            i = null;
            break;
        case u.ElementStart:
            if (a.i18nPlaceholder !== void 0) {
                if (i === null)
                    throw Error("i18n tag placeholder should only occur inside an i18n block");
                Qu(a, i.i18nContext, i.i18nBlock, r), r && a.i18nPlaceholder.closeName && o.set(a.xref, r), r = void 0;
            }
            break;
        case u.ElementEnd:
            let c = s.get(a.xref);
            if (c && c.i18nPlaceholder !== void 0) {
                if (i === null)
                    throw Error("AssertionError: i18n tag placeholder should only occur inside an i18n block");
                Yu(c, i.i18nContext, i.i18nBlock, o.get(a.xref)), o.delete(a.xref);
            }
            break;
        case u.Projection:
            if (a.i18nPlaceholder !== void 0) {
                if (i === null)
                    throw Error("i18n tag placeholder should only occur inside an i18n block");
                Qu(a, i.i18nContext, i.i18nBlock, r), Yu(a, i.i18nContext, i.i18nBlock, r), r = void 0;
            }
            if (a.fallbackView !== null) {
                let d = n.views.get(a.fallbackView);
                if (a.fallbackViewI18nPlaceholder === void 0)
                    xt(n, d, t, s);
                else {
                    if (i === null)
                        throw Error("i18n tag placeholder should only occur inside an i18n block");
                    _i(n, d, a.handle.slot, a.fallbackViewI18nPlaceholder, i.i18nContext, i.i18nBlock, r), xt(n, d, t, s), Ii(n, d, a.handle.slot, a.fallbackViewI18nPlaceholder, i.i18nContext, i.i18nBlock, r), r = void 0;
                }
            }
            break;
        case u.ConditionalCreate:
        case u.ConditionalBranchCreate:
        case u.Template:
            let l = n.views.get(a.xref);
            if (a.i18nPlaceholder === void 0)
                xt(n, l, t, s);
            else {
                if (i === null)
                    throw Error("i18n tag placeholder should only occur inside an i18n block");
                a.templateKind === Re.Structural ? xt(n, l, t, s, a) : (_i(n, l, a.handle.slot, a.i18nPlaceholder, i.i18nContext, i.i18nBlock, r), xt(n, l, t, s), Ii(n, l, a.handle.slot, a.i18nPlaceholder, i.i18nContext, i.i18nBlock, r), r = void 0);
            }
            break;
        case u.RepeaterCreate:
            if (r !== void 0)
                throw Error("AssertionError: Unexpected structural directive associated with @for block");
            let p = a.handle.slot + 1, h = n.views.get(a.xref);
            if (a.i18nPlaceholder === void 0)
                xt(n, h, t, s);
            else {
                if (i === null)
                    throw Error("i18n tag placeholder should only occur inside an i18n block");
                _i(n, h, p, a.i18nPlaceholder, i.i18nContext, i.i18nBlock, r), xt(n, h, t, s), Ii(n, h, p, a.i18nPlaceholder, i.i18nContext, i.i18nBlock, r), r = void 0;
            }
            if (a.emptyView !== null) {
                let d = a.handle.slot + 2, v = n.views.get(a.emptyView);
                if (a.emptyI18nPlaceholder === void 0)
                    xt(n, v, t, s);
                else {
                    if (i === null)
                        throw Error("i18n tag placeholder should only occur inside an i18n block");
                    _i(n, v, d, a.emptyI18nPlaceholder, i.i18nContext, i.i18nBlock, r), xt(n, v, t, s), Ii(n, v, d, a.emptyI18nPlaceholder, i.i18nContext, i.i18nBlock, r), r = void 0;
                }
            }
            break;
    } }
function Qu(n, e, t, s) { let { startName: r, closeName: i } = n.i18nPlaceholder, o = Y.ElementTag | Y.OpenTag, a = n.handle.slot; s !== void 0 && (o |= Y.TemplateTag, a = { element: a, template: s.handle.slot }), i || (o |= Y.CloseTag), Bs(e.params, r, a, t.subTemplateIndex, o); }
function Yu(n, e, t, s) { let { closeName: r } = n.i18nPlaceholder; if (r) {
    let i = Y.ElementTag | Y.CloseTag, o = n.handle.slot;
    s !== void 0 && (i |= Y.TemplateTag, o = { element: o, template: s.handle.slot }), Bs(e.params, r, o, t.subTemplateIndex, i);
} }
function _i(n, e, t, s, r, i, o) { let { startName: a, closeName: c } = s, l = Y.TemplateTag | Y.OpenTag; c || (l |= Y.CloseTag), o !== void 0 && Bs(r.params, a, o.handle.slot, i.subTemplateIndex, l), Bs(r.params, a, t, Mh(n, i, e), l); }
function Ii(n, e, t, s, r, i, o) { let { closeName: a } = s, c = Y.TemplateTag | Y.CloseTag; a && (Bs(r.params, a, t, Mh(n, i, e), c), o !== void 0 && Bs(r.params, a, o.handle.slot, i.subTemplateIndex, c)); }
function Mh(n, e, t) { for (let s of t.create)
    if (s.kind === u.I18nStart)
        return s.subTemplateIndex; return e.subTemplateIndex; }
function Bs(n, e, t, s, r) { let i = n.get(e) ?? []; i.push({ value: t, subTemplateIndex: s, flags: r }), n.set(e, i); }
function hx(n) { let e = new Map, t = new Map, s = new Map; for (let o of n.units)
    for (let a of o.create)
        switch (a.kind) {
            case u.I18nStart:
                e.set(a.xref, a.subTemplateIndex);
                break;
            case u.I18nContext:
                t.set(a.xref, a);
                break;
            case u.IcuPlaceholder:
                s.set(a.xref, a);
                break;
        } let r = new Map, i = o => o.usage === Fs.I18nText ? o.i18nOwner : o.context; for (let o of n.units)
    for (let a of o.update)
        if (a.kind === u.I18nExpression) {
            let c = r.get(i(a)) || 0, l = e.get(a.i18nOwner) ?? null, p = { value: c, subTemplateIndex: l, flags: Y.ExpressionIndex };
            fx(a, p, t, s), r.set(i(a), c + 1);
        } }
function fx(n, e, t, s) { if (n.i18nPlaceholder !== null) {
    let r = t.get(n.context), i = n.resolutionTime === Qr.Creation ? r.params : r.postprocessingParams, o = i.get(n.i18nPlaceholder) || [];
    o.push(e), i.set(n.i18nPlaceholder, o);
} n.icuPlaceholder !== null && s.get(n.icuPlaceholder)?.expressionPlaceholders.push(e); }
function dx(n) { let e = new Map; for (let t of n.units)
    for (let s of t.ops())
        if (s.kind === u.ElementStart || s.kind === u.Template) {
            let r = s.tag ?? "";
            switch (s.namespace) {
                case oe.SVG:
                    r = `:${ea}:${r}`;
                    break;
                case oe.Math:
                    r = `:${ta}:${r}`;
                    break;
            }
            e.set(s.xref, r);
        } for (let t of n.units)
    for (let s of t.create)
        if (s.kind === u.ExtractedAttribute && s.i18nContext !== null && s.expression !== null) {
            let r = e.get(s.target) ?? "", i = s.expression;
            switch (s.securityContext) {
                case V.HTML:
                    i = A(f.sanitizeHtml).callFn([i]);
                    break;
                case V.STYLE:
                    i = A(f.sanitizeStyle).callFn([i]);
                    break;
                case V.SCRIPT:
                    i = A(f.sanitizeScript).callFn([i]);
                    break;
                case V.URL:
                    i = A(f.sanitizeUrl).callFn([i]);
                    break;
                case V.RESOURCE_URL:
                    i = A(f.sanitizeResourceUrl).callFn([i]);
                    break;
                case V.ATTRIBUTE_NO_BINDING:
                    i = A(f.validateAttribute).callFn([i, g(r), g(s.name)]);
                    break;
            }
            s.expression = i;
        } }
function mx(n) { for (let e of n.units) {
    for (let t of e.functions)
        lr(e, t.ops, null);
    lr(e, e.create, null), lr(e, e.update, null);
} }
function lr(n, e, t) { let s = new Map, r = new Map; for (let i of e)
    switch (i.kind) {
        case u.Variable:
            switch (i.variable.kind) {
                case Ee.Identifier:
                    if (i.variable.local) {
                        if (r.has(i.variable.identifier))
                            continue;
                        r.set(i.variable.identifier, i.xref);
                    }
                    else if (s.has(i.variable.identifier))
                        continue;
                    s.set(i.variable.identifier, i.xref);
                    break;
                case Ee.Alias:
                    if (s.has(i.variable.identifier))
                        continue;
                    s.set(i.variable.identifier, i.xref);
                    break;
                case Ee.SavedView:
                    t = { view: i.variable.view, variable: i.xref };
                    break;
            }
            break;
        case u.Animation:
        case u.AnimationListener:
        case u.Listener:
        case u.TwoWayListener:
            lr(n, i.handlerOps, t);
            break;
        case u.RepeaterCreate:
            i.trackByOps !== null && lr(n, i.trackByOps, t);
            break;
    } for (let i of e)
    i.kind === u.Listener || i.kind === u.TwoWayListener || i.kind === u.Animation || i.kind === u.AnimationListener || te(i, o => { if (o instanceof me)
        return r.has(o.name) ? new Ht(r.get(o.name)) : s.has(o.name) ? new Ht(s.get(o.name)) : new We(new pn(n.job.root.xref), o.name); if (o instanceof Kr && typeof o.view == "number") {
        if (t === null || t.view !== o.view)
            throw new Error(`AssertionError: no saved view ${o.view} from view ${n.xref}`);
        return o.view = new Ht(t.variable), o;
    }
    else
        return o; }, M.None); for (let i of e)
    ae(i, o => { if (o instanceof me)
        throw new Error(`AssertionError: no lexical reads should remain, but found read of ${o.name}`); }); }
var gx = new Map([[V.HTML, f.sanitizeHtml], [V.RESOURCE_URL, f.sanitizeResourceUrl], [V.SCRIPT, f.sanitizeScript], [V.STYLE, f.sanitizeStyle], [V.URL, f.sanitizeUrl], [V.ATTRIBUTE_NO_BINDING, f.validateAttribute]]), vx = new Map([[V.HTML, f.trustConstantHtml], [V.RESOURCE_URL, f.trustConstantResourceUrl]]);
function wx(n) { for (let e of n.units) {
    if (n.kind !== C.Host) {
        for (let t of e.create)
            if (t.kind === u.ExtractedAttribute) {
                let s = vx.get(Zu(t.securityContext)) ?? null;
                t.trustedValueFn = s !== null ? A(s) : null;
            }
    }
    for (let t of e.update)
        switch (t.kind) {
            case u.Property:
            case u.Attribute:
            case u.DomProperty:
            case u.TwoWayProperty:
                let s = null;
                Array.isArray(t.securityContext) && Sx(t.securityContext) ? s = f.sanitizeUrlOrResourceUrl : s = gx.get(Zu(t.securityContext)) ?? null, t.sanitizer = s !== null ? A(s) : null;
                break;
        }
} }
function Sx(n) { let e = !1, t = !1, s = !1; for (let r of n)
    switch (r) {
        case V.URL:
            e = !0;
            break;
        case V.RESOURCE_URL:
            t = !0;
            break;
        case V.NONE:
            s = !0;
            break;
        default: return !1;
    } return (e || t) && s || e && t; }
function Zu(n) { if (!Array.isArray(n))
    return n; if (n.length < 2)
    return n[0] ?? V.NONE; let e = n.filter(t => t !== V.NONE); if (e.length > 1)
    throw Error("AssertionError: Ambiguous security context"); return e[0] ?? V.NONE; }
function Ex(n) { for (let e of n.units)
    for (let t of e.ops())
        te(t, s => xx(s), M.None); }
function xx(n) { if (n instanceof pe && n.fn instanceof me && n.fn.name === "$safeNavigationMigration") {
    if (n.args.length !== 1)
        throw new Error("The $safeNavigationMigration builtin function expects exactly one argument.");
    return new ti(n.args[0]);
} return n; }
function yx(n) { for (let e of n.units) {
    for (let t of e.functions)
        Ju(n, e, t.ops) && Ku(e, t.ops, F(t.currentViewName));
    e.create.prepend([tn(e.job.allocateXrefId(), { kind: Ee.SavedView, name: null, view: e.xref }, new uc, ht.None)]);
    for (let t of e.create)
        (t.kind === u.Listener || t.kind === u.TwoWayListener || t.kind === u.Animation || t.kind === u.AnimationListener) && Ju(n, e, t.handlerOps) && Ku(e, t.handlerOps, e.xref);
} }
function Ju(n, e, t) { let s = e !== n.root; if (!s)
    for (let r of t)
        ae(r, i => { (i instanceof bo || i instanceof Jr) && (s = !0); }); return s; }
function Ku(n, e, t) { e.prepend([tn(n.job.allocateXrefId(), { kind: Ee.Context, name: null, view: n.xref }, new Kr(t), ht.None)]); for (let s of e)
    s.kind === u.Statement && s.statement instanceof fe && (s.statement.value = new ko(s.statement.value)); }
function Cx(n) { let e = new Map; for (let t of n.units) {
    let s = 0;
    for (let r of t.create)
        Os(r) && (r.handle.slot = s, e.set(r.xref, r.handle.slot), s += r.numSlotsUsed);
    t.decls = s;
} for (let t of n.units)
    for (let s of t.ops())
        if (s.kind === u.Template || s.kind === u.ConditionalCreate || s.kind === u.ConditionalBranchCreate || s.kind === u.RepeaterCreate) {
            let r = n.views.get(s.xref);
            s.decls = r.decls;
        } }
function bx(n) { let e = new Set, t = new Map; for (let s of n.units)
    for (let r of s.ops())
        r.kind === u.DeclareLet && t.set(r.xref, r), ae(r, i => { i instanceof Jr && e.add(i.target); }); for (let s of n.units)
    for (let r of s.update)
        te(r, i => i instanceof Zr && !e.has(i.target) ? (Ax(i) || S.remove(t.get(i.target)), i.value) : i, M.None); }
function Ax(n) { let e = !1; return k(n, t => ((t instanceof Zn || t instanceof ei) && (e = !0), t), M.None), e; }
function kx(n) { let e = new Set; for (let t of n.units)
    for (let s of t.ops())
        ae(s, r => { if (r instanceof H)
            switch (r.operator) {
                case x.Exponentiation:
                    Tx(r, e);
                    break;
                case x.NullishCoalesce:
                    _x(r, e);
                    break;
                case x.And:
                case x.Or: Ix(r, e);
            } }); for (let t of n.units)
    for (let s of t.ops())
        te(s, r => r instanceof mt ? e.has(r) ? r : r.expr : r, M.None); }
function Tx(n, e) { n.lhs instanceof mt && n.lhs.expr instanceof On && e.add(n.lhs); }
function _x(n, e) { n.lhs instanceof mt && (ep(n.lhs.expr) || n.lhs.expr instanceof Nt) && e.add(n.lhs), n.rhs instanceof mt && (ep(n.rhs.expr) || n.rhs.expr instanceof Nt) && e.add(n.rhs); }
function Ix(n, e) { n.lhs instanceof mt && n.lhs.expr instanceof H && n.lhs.expr.operator === x.NullishCoalesce && e.add(n.lhs); }
function ep(n) { return n instanceof H && (n.operator === x.And || n.operator === x.Or); }
function Nx(n) { for (let e of n.units)
    for (let t of e.update)
        if (t.kind === u.Binding)
            switch (t.bindingKind) {
                case _.ClassName:
                    if (t.expression instanceof ne)
                        throw new Error("Unexpected interpolation in ClassName binding");
                    S.replace(t, Dm(t.target, t.name, t.expression, t.sourceSpan));
                    break;
                case _.StyleProperty:
                    S.replace(t, Nm(t.target, t.name, t.expression, t.unit, t.sourceSpan));
                    break;
                case _.Property:
                case _.Template:
                    t.name === "style" ? S.replace(t, Pm(t.target, t.expression, t.sourceSpan)) : t.name === "class" && S.replace(t, Lm(t.target, t.expression, t.sourceSpan));
                    break;
            } }
function Dx(n) { for (let e of n.units) {
    e.create.prepend(ur(e.create)), e.update.prepend(ur(e.update));
    for (let t of e.functions)
        t.ops.prepend(ur(t.ops));
} }
function ur(n) { let e = 0, t = []; for (let s of n) {
    let r = new Map;
    ae(s, (l, p) => { p & M.InChildOperation || l instanceof fn && r.set(l.xref, l); });
    let i = 0, o = new Set, a = new Set, c = new Map;
    ae(s, (l, p) => { p & M.InChildOperation || (l instanceof $t ? (o.has(l.xref) || (o.add(l.xref), c.set(l.xref, `tmp_${e}_${i++}`)), tp(c, l)) : l instanceof fn && (r.get(l.xref) === l && (a.add(l.xref), i--), tp(c, l))); }), t.push(...Array.from(new Set(c.values())).map(l => rt(new ve(l)))), e++, s.kind === u.Listener || s.kind === u.Animation || s.kind === u.AnimationListener || s.kind === u.TwoWayListener ? s.handlerOps.prepend(ur(s.handlerOps)) : s.kind === u.RepeaterCreate && s.trackByOps !== null && s.trackByOps.prepend(ur(s.trackByOps));
} return t; }
function tp(n, e) { let t = n.get(e.xref); if (t === void 0)
    throw new Error(`Found xref with unassigned name: ${e.xref}`); e.name = t; }
function Px(n) { for (let e of n.units)
    for (let t of e.create)
        if (t.kind === u.RepeaterCreate)
            if (t.track instanceof dt && t.track.name === "$index")
                t.trackByFn = A(f.repeaterTrackByIndex);
            else if (t.track instanceof dt && t.track.name === "$item")
                t.trackByFn = A(f.repeaterTrackByIdentity);
            else if (Lx(n.root.xref, t.track))
                t.usesComponentInstance = !0, t.track.receiver.receiver.view === e.xref ? t.trackByFn = t.track.receiver : (t.trackByFn = A(f.componentInstance).callFn([]).prop(t.track.receiver.name), t.track = t.trackByFn);
            else {
                t.track = k(t.track, r => { if (r instanceof Zn || r instanceof ei)
                    throw new Error("Illegal State: Pipes are not allowed in this context"); return r instanceof pn ? (t.usesComponentInstance = !0, new lc(r.view)) : r; }, M.None);
                let s = new S;
                s.push(rt(new fe(t.track, t.track.sourceSpan, [xr()]))), t.trackByOps = s;
            } }
function Lx(n, e) { if (!(e instanceof pe) || e.args.length === 0 || e.args.length > 2 || !(e.receiver instanceof We && e.receiver.receiver instanceof pn) || e.receiver.receiver.view !== n)
    return !1; let [t, s] = e.args; return !(t instanceof dt) || t.name !== "$index" ? !1 : e.args.length === 1 ? !0 : !(!(s instanceof dt) || s.name !== "$item"); }
function Bx(n) { for (let e of n.units)
    for (let t of e.create)
        t.kind === u.RepeaterCreate && (t.track = k(t.track, s => { if (s instanceof me) {
            if (t.varNames.$index.has(s.name))
                return F("$index");
            if (s.name === t.varNames.$implicit)
                return F("$item");
        } return s; }, M.None)); }
function $x(n) { for (let e of n.units)
    for (let t of e.create)
        t.kind === u.TwoWayListener && te(t, s => { if (!(s instanceof To))
            return s; let { target: r, value: i } = s; if (r instanceof We || r instanceof gt)
            return ju(r, i).or(r.set(i)); if (r instanceof Ht)
            return ju(r, i); throw new Error("Unsupported expression in two-way action binding."); }, M.InChildOperation); }
function Mx(n) { for (let e of n.units) {
    let t = 0;
    for (let i of e.ops())
        ua(i) && (t += Rx(i));
    let s = i => { Bt(i) && (i instanceof Yn || (ou(i) && (i.varOffset = t), ua(i) && (t += np(i)))); }, r = i => { !Bt(i) || !(i instanceof Yn) || (ou(i) && (i.varOffset = t), ua(i) && (t += np(i))); };
    for (let i of e.create)
        ae(i, s);
    for (let i of e.update)
        ae(i, s);
    for (let i of e.create)
        ae(i, r);
    for (let i of e.update)
        ae(i, r);
    e.vars = t;
} if (n instanceof ri)
    for (let e of n.units)
        for (let t of e.create) {
            if (t.kind !== u.Template && t.kind !== u.RepeaterCreate && t.kind !== u.ConditionalCreate && t.kind !== u.ConditionalBranchCreate)
                continue;
            let s = n.views.get(t.xref);
            t.vars = s.vars;
        } }
function Rx(n) { let e; switch (n.kind) {
    case u.Attribute: return e = 1, n.expression instanceof ne && !Fx(n.expression) && (e += n.expression.expressions.length), e;
    case u.Property:
    case u.DomProperty: return e = 1, n.expression instanceof ne && (e += n.expression.expressions.length), e;
    case u.Control: return 2;
    case u.TwoWayProperty: return 1;
    case u.StyleProp:
    case u.ClassProp:
    case u.StyleMap:
    case u.ClassMap: return e = 2, n.expression instanceof ne && (e += n.expression.expressions.length), e;
    case u.InterpolateText: return n.interpolation.expressions.length;
    case u.I18nExpression:
    case u.Conditional:
    case u.DeferWhen:
    case u.StoreLet: return 1;
    case u.RepeaterCreate: return n.emptyView ? 1 : 0;
    default: throw new Error(`Unhandled op: ${u[n.kind]}`);
} }
function np(n) { switch (n.kind) {
    case I.PureFunctionExpr: return 1 + n.args.length;
    case I.PipeBinding: return 1 + n.args.length;
    case I.PipeBindingVariadic: return 1 + n.numArgs;
    case I.StoreLet:
    case I.ArrowFunction: return 1;
    default: throw new Error(`AssertionError: unhandled ConsumesVarsTrait expression ${n.constructor.name}`);
} }
function Fx(n) { return !(n.expressions.length !== 1 || n.strings.length !== 2 || n.strings[0] !== "" || n.strings[1] !== ""); }
function Ox(n) { for (let e of n.units) {
    for (let t of e.functions)
        Gs(t.ops);
    Gs(e.create), Gs(e.update);
    for (let t of e.create)
        t.kind === u.Listener || t.kind === u.Animation || t.kind === u.AnimationListener || t.kind === u.TwoWayListener ? Gs(t.handlerOps) : t.kind === u.RepeaterCreate && t.trackByOps !== null && Gs(t.trackByOps);
    for (let t of e.functions)
        Xs(t.ops, null), sp(t.ops);
    for (let t of e.create)
        t.kind === u.Listener || t.kind === u.Animation || t.kind === u.AnimationListener || t.kind === u.TwoWayListener ? (Xs(t.handlerOps, Ni), sp(t.handlerOps)) : t.kind === u.RepeaterCreate && t.trackByOps !== null && Xs(t.trackByOps, Ni);
    Xs(e.create, Ni), Xs(e.update, Ni);
} }
var de = (function (n) { return n[n.None = 0] = "None", n[n.ViewContextRead = 1] = "ViewContextRead", n[n.ViewContextWrite = 2] = "ViewContextWrite", n[n.SideEffectful = 4] = "SideEffectful", n; })(de || {});
function Ni(n) { return !(n & M.InArrowFunctionOperation); }
function Gs(n) { let e = new Map; for (let t of n)
    t.kind === u.Variable && t.flags & ht.AlwaysInline && (ae(t, s => { if (Bt(s) && bl(s) !== de.None)
        throw new Error("AssertionError: A context-sensitive variable was marked AlwaysInline"); }), e.set(t.xref, t)), te(t, s => s instanceof Ht && e.has(s.xref) ? e.get(s.xref).initializer.clone() : s, M.None); for (let t of e.values())
    S.remove(t); }
function Xs(n, e) { let t = new Map, s = new Map, r = new Set, i = new Map; for (let l of n) {
    if (l.kind === u.Variable) {
        if (t.has(l.xref) || s.has(l.xref))
            throw new Error(`Should not see two declarations of the same variable: ${l.xref}`);
        t.set(l.xref, l), s.set(l.xref, 0);
    }
    i.set(l, Vx(l, e)), qx(l, s, r, e);
} let o = !1; for (let l of n.reversed()) {
    let p = i.get(l);
    if (l.kind === u.Variable && s.get(l.xref) === 0) {
        if (o && p.fences & de.ViewContextWrite || p.fences & de.SideEffectful) {
            let h = rt(l.initializer.toStmt());
            i.set(h, p), S.replace(l, h);
        }
        else
            Hx(l, s), S.remove(l);
        i.delete(l), t.delete(l.xref), s.delete(l.xref);
        continue;
    }
    p.fences & de.ViewContextRead && (o = !0);
} let a = []; for (let [l, p] of s) {
    let d = !!(t.get(l).flags & ht.AlwaysInline);
    p !== 1 || d || r.has(l) || a.push(l);
} let c; for (; c = a.pop();) {
    let l = t.get(c), p = i.get(l);
    if (!!(l.flags & ht.AlwaysInline))
        throw new Error("AssertionError: Found an 'AlwaysInline' variable after the always inlining pass.");
    for (let d = l.next; d.kind !== u.ListEnd; d = d.next) {
        let v = i.get(d);
        if (v.variablesUsed.has(c)) {
            if (!Wx(l, d))
                break;
            if (Ux(c, l.initializer, d, p.fences)) {
                v.variablesUsed.delete(c);
                for (let w of p.variablesUsed)
                    v.variablesUsed.add(w);
                v.fences |= p.fences, t.delete(c), s.delete(c), i.delete(l), S.remove(l);
            }
            break;
        }
        if (!Rh(v.fences, p.fences))
            break;
    }
} }
function bl(n) { switch (n.kind) {
    case I.NextContext: return de.ViewContextRead | de.ViewContextWrite;
    case I.RestoreView: return de.ViewContextRead | de.ViewContextWrite | de.SideEffectful;
    case I.StoreLet: return de.SideEffectful;
    case I.Reference:
    case I.ContextLetReference: return de.ViewContextRead;
    default: return de.None;
} }
function Vx(n, e) { let t = de.None, s = new Set; return ae(n, (r, i) => { !Bt(r) || e !== null && !e(i) || (r.kind === I.ReadVariable ? s.add(r.xref) : i & M.InChildOperation || (t |= bl(r))); }), { fences: t, variablesUsed: s }; }
function qx(n, e, t, s) { ae(n, (r, i) => { if (!Bt(r) || s !== null && !s(i) || r.kind !== I.ReadVariable)
    return; let o = e.get(r.xref); o !== void 0 && (e.set(r.xref, o + 1), i & M.InChildOperation && t.add(r.xref)); }); }
function Hx(n, e) { ae(n, t => { if (!Bt(t) || t.kind !== I.ReadVariable)
    return; let s = e.get(t.xref); if (s !== void 0) {
    if (s === 0)
        throw new Error(`Inaccurate variable count: ${t.xref} - found another read but count is already 0`);
    e.set(t.xref, s - 1);
} }); }
function Rh(n, e) { if (n & de.ViewContextWrite) {
    if (e & de.ViewContextRead)
        return !1;
}
else if (n & de.ViewContextRead && e & de.ViewContextWrite)
    return !1; return !0; }
function Ux(n, e, t, s) { let r = !1, i = !0; return te(t, (o, a) => { if (!Bt(o) || r || !i)
    return o; if (a & M.InChildOperation && s & de.ViewContextRead)
    return o; switch (o.kind) {
    case I.ReadVariable:
        if (o.xref === n)
            return r = !0, e;
        break;
    default:
        let c = bl(o);
        i = i && Rh(c, s);
        break;
} return o; }, M.None), r; }
function Wx(n, e) { switch (n.variable.kind) {
    case Ee.Identifier: return n.initializer instanceof dt && n.initializer.name === st;
    case Ee.Context: return e.kind === u.Variable;
    default: return !0;
} }
function sp(n) { let e = n.head.next, t = n.tail.prev; e !== null && t !== null && e.next === t && e.kind === u.Statement && e.statement instanceof ke && e.statement.expr instanceof Kr && t.kind === u.Statement && t.statement instanceof fe && t.statement.value instanceof ko && (S.remove(e), t.statement.value = t.statement.value.expr); }
function jx(n) { for (let e of n.units) {
    let t = null, s = null;
    for (let r of e.create)
        switch (r.kind) {
            case u.I18nStart:
                t = r;
                break;
            case u.I18nEnd:
                t = null;
                break;
            case u.IcuStart:
                t === null && (s = n.allocateXrefId(), S.insertBefore(Jo(s, r.message, void 0, null), r));
                break;
            case u.IcuEnd:
                s !== null && (S.insertAfter(Ko(s, null), r), s = null);
                break;
        }
} }
var zx = [{ kind: C.Tmpl, fn: ux }, { kind: C.Tmpl, fn: lS }, { kind: C.Both, fn: CS }, { kind: C.Host, fn: Ev }, { kind: C.Tmpl, fn: zw }, { kind: C.Tmpl, fn: gS }, { kind: C.Tmpl, fn: jx }, { kind: C.Both, fn: Vg }, { kind: C.Both, fn: Nx }, { kind: C.Both, fn: wg }, { kind: C.Tmpl, fn: Ig }, { kind: C.Both, fn: Mg }, { kind: C.Both, fn: mg }, { kind: C.Tmpl, fn: Og }, { kind: C.Both, fn: Xw }, { kind: C.Tmpl, fn: sx }, { kind: C.Both, fn: xg }, { kind: C.Both, fn: cS }, { kind: C.Tmpl, fn: yg }, { kind: C.Tmpl, fn: hS }, { kind: C.Tmpl, fn: qg }, { kind: C.Tmpl, fn: Hg }, { kind: C.Tmpl, fn: mS }, { kind: C.Both, fn: dv }, { kind: C.Both, fn: SS }, { kind: C.Tmpl, fn: gv }, { kind: C.Tmpl, fn: mv }, { kind: C.Tmpl, fn: vv }, { kind: C.Tmpl, fn: yx }, { kind: C.Both, fn: lg }, { kind: C.Both, fn: Ex }, { kind: C.Both, fn: lx }, { kind: C.Tmpl, fn: Bx }, { kind: C.Tmpl, fn: ix }, { kind: C.Both, fn: mx }, { kind: C.Tmpl, fn: Ug }, { kind: C.Tmpl, fn: $x }, { kind: C.Tmpl, fn: Px }, { kind: C.Both, fn: ax }, { kind: C.Both, fn: wx }, { kind: C.Tmpl, fn: Ww }, { kind: C.Both, fn: Xg }, { kind: C.Both, fn: kx }, { kind: C.Both, fn: Dx }, { kind: C.Both, fn: Ox }, { kind: C.Both, fn: bx }, { kind: C.Tmpl, fn: Uw }, { kind: C.Tmpl, fn: Fg }, { kind: C.Tmpl, fn: ox }, { kind: C.Tmpl, fn: fg }, { kind: C.Tmpl, fn: pg }, { kind: C.Tmpl, fn: Cx }, { kind: C.Tmpl, fn: px }, { kind: C.Tmpl, fn: hx }, { kind: C.Tmpl, fn: lv }, { kind: C.Tmpl, fn: Fw }, { kind: C.Tmpl, fn: dx }, { kind: C.Tmpl, fn: wv }, { kind: C.Both, fn: kg }, { kind: C.Tmpl, fn: rx }, { kind: C.Both, fn: Mx }, { kind: C.Tmpl, fn: fv }, { kind: C.Both, fn: Qw }, { kind: C.Tmpl, fn: cx }, { kind: C.Tmpl, fn: Jw }, { kind: C.Tmpl, fn: eS }, { kind: C.Tmpl, fn: Gg }, { kind: C.Tmpl, fn: dg }, { kind: C.Tmpl, fn: nS }, { kind: C.Both, fn: wS }, { kind: C.Both, fn: ZE }, { kind: C.Both, fn: Eg }];
function Fh(n, e) { for (let t of zx)
    (t.kind === e || t.kind === C.Both) && t.fn(n); }
function Gx(n, e) { let t = Vh(n.root); return Oh(n.root, e), t; }
function Oh(n, e) { for (let t of n.job.units) {
    if (t.parent !== n.xref)
        continue;
    Oh(t, e);
    let s = Vh(t);
    e.statements.push(s.toDeclStmt(s.name));
} }
function Vh(n) { if (n.fnName === null)
    throw new Error(`AssertionError: view ${n.xref} is unnamed`); let e = []; for (let i of n.create) {
    if (i.kind !== u.Statement)
        throw new Error(`AssertionError: expected all create ops to have been compiled, but got ${u[i.kind]}`);
    e.push(i.statement);
} let t = []; for (let i of n.update) {
    if (i.kind !== u.Statement)
        throw new Error(`AssertionError: expected all update ops to have been compiled, but got ${u[i.kind]}`);
    t.push(i.statement);
} let s = Uo(1, e), r = Uo(2, t); return an([new he(Ms, Rn), new he(st, ge)], [...s, ...r], void 0, void 0, n.fnName); }
function Uo(n, e) { return e.length === 0 ? [] : [Qo(new H(x.BitwiseAnd, F(Ms), g(n)), e)]; }
function Xx(n) { if (n.root.fnName === null)
    throw new Error("AssertionError: host binding function is unnamed"); let e = []; for (let i of n.root.create) {
    if (i.kind !== u.Statement)
        throw new Error(`AssertionError: expected all create ops to have been compiled, but got ${u[i.kind]}`);
    e.push(i.statement);
} let t = []; for (let i of n.root.update) {
    if (i.kind !== u.Statement)
        throw new Error(`AssertionError: expected all update ops to have been compiled, but got ${u[i.kind]}`);
    t.push(i.statement);
} if (e.length === 0 && t.length === 0)
    return null; let s = Uo(1, e), r = Uo(2, t); return an([new he(Ms, Rn), new he(st, ge)], [...s, ...r], void 0, void 0, n.root.fnName); }
var Di = ".", Qx = "attr", ma = "animate", Yx = "class", Zx = "style", Jx = "*", ga = "animate-", Fc = class {
    _exprParser;
    _schemaRegistry;
    errors;
    constructor(e, t, s) { this._exprParser = e, this._schemaRegistry = t, this.errors = s; }
    createBoundHostProperties(e, t) { let s = []; for (let r of Object.keys(e)) {
        let i = e[r];
        typeof i == "string" ? this.parsePropertyBinding(r, i, !0, !1, t, t.start.offset, void 0, [], s, t) : this._reportError(`Value of the host property binding "${r}" needs to be a string representing an expression but got "${i}" (${typeof i})`, t);
    } return s; }
    createDirectiveHostEventAsts(e, t) { let s = []; for (let r of Object.keys(e)) {
        let i = e[r];
        typeof i == "string" ? this.parseEvent(r, i, !1, t, t, [], s, t) : this._reportError(`Value of the host listener "${r}" needs to be a string representing an expression but got "${i}" (${typeof i})`, t);
    } return s; }
    parseInterpolation(e, t, s) { let r = t.fullStart.offset; try {
        let i = this._exprParser.parseInterpolation(e, t, r, s);
        return i && this.errors.push(...i.errors), i;
    }
    catch (i) {
        return this._reportError(`${i}`, t), this._exprParser.wrapLiteralPrimitive("ERROR", t, r);
    } }
    parseInterpolationExpression(e, t) { let s = t.start.offset; try {
        let r = this._exprParser.parseInterpolationExpression(e, t, s);
        return r && this.errors.push(...r.errors), r;
    }
    catch (r) {
        return this._reportError(`${r}`, t), this._exprParser.wrapLiteralPrimitive("ERROR", t, s);
    } }
    parseInlineTemplateBinding(e, t, s, r, i, o, a, c) { let l = s.start.offset + Jx.length, p = this._parseTemplateBindings(e, t, s, l, r); for (let h of p) {
        let d = Qt(s, h.sourceSpan), v = h.key.source, w = Qt(s, h.key.span);
        if (h instanceof Br) {
            let y = h.value ? h.value.source : "$implicit", b = h.value ? Qt(s, h.value.span) : void 0;
            a.push(new Ra(v, y, d, w, b));
        }
        else if (h.value) {
            let y = c ? d : s, b = Qt(s, h.value.ast.sourceSpan);
            this._parsePropertyAst(v, h.value, !1, y, w, b, i, o);
        }
        else
            i.push([v, ""]), this.parseLiteralAttr(v, null, w, r, void 0, i, o, w);
    } }
    _parseTemplateBindings(e, t, s, r, i) { try {
        let o = this._exprParser.parseTemplateBindings(e, t, s, r, i);
        return o.errors.forEach(a => this.errors.push(a)), o.warnings.forEach(a => { this._reportError(a, s, sn.WARNING); }), o.templateBindings;
    }
    catch (o) {
        return this._reportError(`${o}`, s), [];
    } }
    parseLiteralAttr(e, t, s, r, i, o, a, c) { va(e) ? (e = e.substring(1), c !== void 0 && (c = Qt(c, new Ke(c.start.offset + 1, c.end.offset))), t && this._reportError('Assigning animation triggers via @prop="exp" attributes with an expression is invalid. Use property bindings (e.g. [@prop]="exp") or use an attribute without a value (e.g. @prop) instead.', s, sn.ERROR), this._parseLegacyAnimation(e, t, s, r, c, i, o, a)) : a.push(new us(e, this._exprParser.wrapLiteralPrimitive(t, "", r), yt.LITERAL_ATTR, s, c, i)); }
    parsePropertyBinding(e, t, s, r, i, o, a, c, l, p) { e.length === 0 && this._reportError("Property name is missing in binding", i); let h = !1; e.startsWith(ga) ? (h = !0, e = e.substring(ga.length), p !== void 0 && (p = Qt(p, new Ke(p.start.offset + ga.length, p.end.offset)))) : va(e) && (h = !0, e = e.substring(1), p !== void 0 && (p = Qt(p, new Ke(p.start.offset + 1, p.end.offset)))), h ? this._parseLegacyAnimation(e, t, i, o, p, a, c, l) : e.startsWith(`${ma}${Di}`) ? this._parseAnimation(e, this.parseBinding(t, s, a || i, o), i, p, a, c, l) : this._parsePropertyAst(e, this.parseBinding(t, s, a || i, o), r, i, p, a, c, l); }
    parsePropertyInterpolation(e, t, s, r, i, o, a, c) { let l = this.parseInterpolation(t, r || s, c); return l ? (this._parsePropertyAst(e, l, !1, s, a, r, i, o), !0) : !1; }
    _parsePropertyAst(e, t, s, r, i, o, a, c) { a.push([e, t.source]), c.push(new us(e, t, s ? yt.TWO_WAY : yt.DEFAULT, r, i, o)); }
    _parseAnimation(e, t, s, r, i, o, a) { o.push([e, t.source]), a.push(new us(e, t, yt.ANIMATION, s, r, i)); }
    _parseLegacyAnimation(e, t, s, r, i, o, a, c) { e.length === 0 && this._reportError("Animation trigger is missing", s); let l = this.parseBinding(t || "undefined", !1, o || s, r); a.push([e, l.source]), c.push(new us(e, l, yt.LEGACY_ANIMATION, s, i, o)); }
    parseBinding(e, t, s, r) { try {
        let i = t ? this._exprParser.parseSimpleBinding(e, s, r) : this._exprParser.parseBinding(e, s, r);
        return i && this.errors.push(...i.errors), i;
    }
    catch (i) {
        return this._reportError(`${i}`, s), this._exprParser.wrapLiteralPrimitive("ERROR", s, r);
    } }
    createBoundElementProperty(e, t, s = !1, r = !0) { if (t.isLegacyAnimation)
        return new uo(t.name, U.LegacyAnimation, V.NONE, t.expression, null, t.sourceSpan, t.keySpan, t.valueSpan); let i = null, o, a = null, c = t.name.split(Di), l; if (c.length > 1)
        if (c[0] == Qx) {
            a = c.slice(1).join(Di), s || this._validatePropertyOrAttributeName(a, t.sourceSpan, !0), l = Fi(this._schemaRegistry, e, a, !0);
            let p = a.indexOf(":");
            if (p > -1) {
                let h = a.substring(0, p), d = a.substring(p + 1);
                a = Ri(h, d);
            }
            o = U.Attribute;
        }
        else if (c[0] == Yx)
            a = c[1], o = U.Class, l = [V.NONE];
        else if (c[0] == Zx) {
            i = c.length > 2 ? c[2] : null;
            let p = c[1];
            if (!p.startsWith("--"))
                a = p;
            else
                try {
                    a = al(p);
                }
                catch (h) {
                    this._reportError(h.message, t.sourceSpan);
                }
            o = U.Style, l = [V.STYLE];
        }
        else
            c[0] == ma && (a = t.name, o = U.Animation, l = [V.NONE]); if (a === null) {
        let p = this._schemaRegistry.getMappedPropName(t.name);
        a = r ? p : t.name, l = Fi(this._schemaRegistry, e, p, !1), o = t.type === yt.TWO_WAY ? U.TwoWay : U.Property, s || this._validatePropertyOrAttributeName(p, t.sourceSpan, !1);
    } return new uo(a, o, l[0], t.expression, i, t.sourceSpan, t.keySpan, t.valueSpan); }
    parseEvent(e, t, s, r, i, o, a, c) { e.length === 0 && this._reportError("Event name is missing in binding", r), va(e) ? (e = e.slice(1), c !== void 0 && (c = Qt(c, new Ke(c.start.offset + 1, c.end.offset))), this._parseLegacyAnimationEvent(e, t, r, i, a, c)) : this._parseRegularEvent(e, t, s, r, i, o, a, c); }
    calcPossibleSecurityContexts(e, t, s) { let r = this._schemaRegistry.getMappedPropName(t); return Fi(this._schemaRegistry, e, r, s); }
    parseEventListenerName(e) { let [t, s] = Yf(e, [null, e]); return { eventName: s, target: t }; }
    parseLegacyAnimationEventName(e) { let t = Zf(e, [e, null]); return { eventName: t[0], phase: t[1] === null ? null : t[1].toLowerCase() }; }
    _parseLegacyAnimationEvent(e, t, s, r, i, o) { let { eventName: a, phase: c } = this.parseLegacyAnimationEventName(e), l = this._parseAction(t, r); i.push(new lo(a, c, $e.LegacyAnimation, l, s, r, o)), a.length === 0 && this._reportError("Animation event name is missing in binding", s), c ? c !== "start" && c !== "done" && this._reportError(`The provided animation output phase value "${c}" for "@${a}" is not supported (use start or done)`, s) : this._reportError(`The animation trigger output event (@${a}) is missing its phase value name (start or done are currently supported)`, s); }
    _parseRegularEvent(e, t, s, r, i, o, a, c) { let { eventName: l, target: p } = this.parseEventListenerName(e), h = this.errors.length, d = this._parseAction(t, i), v = this.errors.length === h; o.push([e, d.source]), s && v && !this._isAllowedAssignmentEvent(d) && this._reportError("Unsupported expression in a two-way binding", r); let w = $e.Regular; s && (w = $e.TwoWay), e.startsWith(`${ma}${Di}`) && (w = $e.Animation), a.push(new lo(l, p, w, d, r, i, c)); }
    _parseAction(e, t) { let s = t && t.start ? t.start.offset : 0; try {
        let r = this._exprParser.parseAction(e, t, s);
        return r && this.errors.push(...r.errors), !r || r.ast instanceof Te ? (this._reportError("Empty expressions are not allowed", t), this._exprParser.wrapLiteralPrimitive("ERROR", t, s)) : r;
    }
    catch (r) {
        return this._reportError(`${r}`, t), this._exprParser.wrapLiteralPrimitive("ERROR", t, s);
    } }
    _reportError(e, t, s = sn.ERROR) { this.errors.push(new N(t, e, s)); }
    _validatePropertyOrAttributeName(e, t, s) { let r = s ? this._schemaRegistry.validateAttribute(e) : this._schemaRegistry.validateProperty(e); r.error && this._reportError(r.msg, t, sn.ERROR); }
    _isAllowedAssignmentEvent(e) { return e instanceof Ue ? this._isAllowedAssignmentEvent(e.ast) : e instanceof Nr ? this._isAllowedAssignmentEvent(e.expression) : e instanceof jn && e.args.length === 1 && e.receiver instanceof kt && e.receiver.name === "$any" && e.receiver.receiver instanceof Pt ? this._isAllowedAssignmentEvent(e.args[0]) : (e instanceof kt || e instanceof Un) && !Oc(e); }
};
function Oc(n) { return n instanceof br || n instanceof Ar ? !0 : n instanceof Lr ? Oc(n.expression) : n instanceof kt || n instanceof Un || n instanceof jn ? Oc(n.receiver) : !1; }
function va(n) { return n[0] == "@"; }
function Fi(n, e, t, s) { let r, [i, o] = e ? be(e, !1) : [null, e], a = l => { let [p, h] = be(l, !1), d = p ?? i, v = d ? `:${d}:${h}` : h; return n.securityContext(v, t, s); }, c = n.allKnownElementNames(); return o === null ? r = c.map(a) : (r = [], hr.parse(o).forEach(l => { let p = l.element ? [l.element] : c; if (l.element && !n.hasElement(l.element, [])) {
    let v = `:${ea}:${l.element}`, w = `:${ta}:${l.element}`;
    n.hasElement(v, []) ? p = [v] : n.hasElement(w, []) && (p = [w]);
} let h = new Set(l.notSelectors.filter(v => v.isElementSelector()).map(v => v.element?.toLowerCase())), d = p.filter(v => { let w = v.toLowerCase(); return !h.has(w) && !h.has(be(w)[1]); }); r.push(...d.map(a)); })), r.length === 0 ? [V.NONE] : Array.from(new Set(r)).sort(); }
function Qt(n, e) { let t = e.start - n.start.offset, s = e.end - n.end.offset; return new D(n.start.moveBy(t), n.end.moveBy(s), n.fullStart.moveBy(t), n.details); }
var Ut = new mn, Mn = "ng-template", Kx = "animate.";
function Oi(n) { return n instanceof Me; }
function ey(n) { return Oi(n) && n.nodes.length === 1 && n.nodes[0] instanceof wo; }
function ty(n, e, t, s, r, i, o, a, c, l, p, h) { let d = new ri(n, t, s, r, i, o, a, c, l, p, h); return St(d.root, e), d; }
function ny(n, e, t) { let s = new Lo(n.componentName, t, Ve.DomOnly, n.legacyOptionalChaining); for (let r of n.properties ?? []) {
    let i = _.Property;
    r.name.startsWith("attr.") && (r.name = r.name.substring(5), i = _.Attribute), r.isLegacyAnimation && (i = _.LegacyAnimation), r.isAnimation && (i = _.Animation);
    let o = rp(e, n.componentSelector, r.name, i === _.Attribute);
    sy(s, r, i, o);
} for (let [r, i] of Object.entries(n.attributes) ?? []) {
    let o = rp(e, n.componentSelector, r, !0);
    ry(s, r, i, o);
} for (let r of n.events ?? [])
    iy(s, r); return s; }
function rp(n, e, t, s) { let r = n.calcPossibleSecurityContexts(e, t, s), i = Fi(Ut, null, Ut.getMappedPropName(t), s), o = i.filter(l => l !== V.NONE), a = o.length; return a !== i.length && a > 0 || o.some(l => !r.includes(l)) ? i : r.filter(l => l !== V.NONE); }
function sy(n, e, t, s) { let r, i = e.expression.ast; i instanceof mi ? r = new ne(i.strings, i.expressions.map(o => R(o, n, e.sourceSpan)), []) : r = R(i, n, e.sourceSpan), n.root.update.push(Qn(n.root.xref, t, e.name, r, null, s, !1, !1, null, null, e.sourceSpan)); }
function ry(n, e, t, s) { let r = Qn(n.root.xref, _.Attribute, e, t, null, s, !0, !1, null, null, t.sourceSpan); n.root.update.push(r); }
function iy(n, e) { let t; if (e.type === $e.Animation)
    t = dh(n.root.xref, new ye, e.name, null, li(n.root, e.handler, e.handlerSpan), e.name.endsWith("enter") ? "enter" : "leave", e.targetOrPhase, !0, e.sourceSpan);
else {
    let [s, r] = e.type !== $e.LegacyAnimation ? [null, e.targetOrPhase] : [e.targetOrPhase, null];
    t = xl(n.root.xref, new ye, e.name, null, li(n.root, e.handler, e.handlerSpan), s, r, !0, e.sourceSpan);
} n.root.create.push(t); }
function St(n, e) { for (let t of e)
    if (t instanceof wt)
        oy(n, t);
    else if (t instanceof et)
        cy(n, t);
    else if (t instanceof Ns)
        ly(n, t);
    else if (t instanceof kn)
        qh(n, t, null);
    else if (t instanceof ks)
        Hh(n, t, null);
    else if (t instanceof go)
        uy(n, t);
    else if (t instanceof mo)
        py(n, t);
    else if (t instanceof zn)
        hy(n, t);
    else if (t instanceof Fp)
        dy(n, t);
    else if (t instanceof Is)
        my(n, t);
    else if (t instanceof ul)
        vy(n, t);
    else if (!(t instanceof sr))
        throw new Error(`Unsupported template node: ${t.constructor.name}`); }
function oy(n, e) { if (e.i18n !== void 0 && !(e.i18n instanceof Me || e.i18n instanceof cn))
    throw Error(`Unhandled i18n metadata type for element: ${e.i18n.constructor.name}`); let t = n.job.allocateXrefId(), s = n.job.getForeignComponent(e); if (s) {
    ay(n, t, e, s);
    return;
} let [r, i] = be(e.name), o = qm(i, t, Eh(r), e.i18n instanceof cn ? e.i18n : void 0, e.startSourceSpan, e.sourceSpan); n.create.push(o), Sy(n, o, e), jh(o, e); let a = null; e.i18n instanceof Me && (a = n.job.allocateXrefId(), n.create.push(Jo(a, e.i18n, void 0, e.startSourceSpan))), St(n, e.children); let c = Wm(t, e.endSourceSpan ?? e.startSourceSpan); n.create.push(c), a !== null && S.insertBefore(Ko(a, e.endSourceSpan ?? e.startSourceSpan), c); }
function ay(n, e, t, s) { let r = new Map; for (let c of t.attributes)
    r.set(c.name, g(c.value)); for (let c of t.inputs)
    r.set(c.name, R(c.value, n.job, c.sourceSpan)); let i = [], o = []; for (let c of t.children)
    c instanceof _s ? i.push(c) : o.push(c); for (let c of i) {
    let l = n.job.allocateView(n.xref);
    for (let p = 0; p < c.variables.length; p++)
        l.contextVariables.set(c.variables[p].name, p);
    St(l, c.children), n.create.push(lu(e, l.xref, c.name, c.startSourceSpan, c.sourceSpan));
} if (o.length > 0) {
    let c = n.job.allocateView(n.xref);
    St(c, o), n.create.push(lu(e, c.xref, "children", t.startSourceSpan, t.sourceSpan));
} let a = n.job.addConst(s.component); n.create.push(Hm(e, a, r, t.startSourceSpan)); }
function cy(n, e) { if (e.i18n !== void 0 && !(e.i18n instanceof Me || e.i18n instanceof cn))
    throw Error(`Unhandled i18n metadata type for template: ${e.i18n.constructor.name}`); let t = n.job.allocateView(n.xref), s = e.tagName, r = ""; e.tagName && ([r, s] = be(e.tagName)); let i = e.i18n instanceof cn ? e.i18n : void 0, o = Eh(r), a = s === null ? "" : Ag(s, o), c = wy(e) ? Re.NgTemplate : Re.Structural, l = El(t.xref, c, s, a, o, i, e.startSourceSpan, e.sourceSpan); n.create.push(l), Ey(n, l, e, c), jh(l, e), St(t, e.children); for (let { name: p, value: h } of e.variables)
    t.contextVariables.set(p, h !== "" ? h : "$implicit"); if (c === Re.NgTemplate && e.i18n instanceof Me) {
    let p = n.job.allocateXrefId();
    S.insertAfter(Jo(p, e.i18n, void 0, e.startSourceSpan), t.create.head), S.insertBefore(Ko(p, e.endSourceSpan ?? e.startSourceSpan), t.create.tail);
} }
function ly(n, e) { if (e.i18n !== void 0 && !(e.i18n instanceof cn))
    throw Error(`Unhandled i18n metadata type for element: ${e.i18n.constructor.name}`); let t = null; e.children.some(i => !(i instanceof An) && (!(i instanceof kn) || i.value.trim().length > 0)) && (t = n.job.allocateView(n.xref), St(t, e.children)); let s = n.job.allocateXrefId(), r = Km(s, e.selector, e.i18n, t?.xref ?? null, e.sourceSpan); for (let i of e.attributes) {
    let o = Ut.securityContext(e.name, i.name, !0);
    n.update.push(Qn(r.xref, _.Attribute, i.name, g(i.value), null, o, !0, !1, null, Ot(i.i18n), i.sourceSpan));
} n.create.push(r); }
function qh(n, e, t) { n.create.push(fh(n.job.allocateXrefId(), e.value, t, e.sourceSpan)); }
function Hh(n, e, t) { let s = e.value; if (s instanceof Ue && (s = s.ast), !(s instanceof mi))
    throw new Error(`AssertionError: expected Interpolation for BoundText node, got ${s.constructor.name}`); if (e.i18n !== void 0 && !(e.i18n instanceof qt))
    throw Error(`Unhandled i18n metadata type for text interpolation: ${e.i18n?.constructor.name}`); let r = e.i18n instanceof qt ? e.i18n.children.filter(o => o instanceof Ur).map(o => o.name) : []; if (r.length > 0 && r.length !== s.expressions.length)
    throw Error(`Unexpected number of i18n placeholders (${s.expressions.length}) for BoundText with ${s.expressions.length} expressions`); let i = n.job.allocateXrefId(); n.create.push(fh(i, "", t, e.sourceSpan)), n.update.push(Tm(i, new ne(s.strings, s.expressions.map(o => R(o, n.job, null)), r), e.sourceSpan)); }
function uy(n, e) { let t = null, s = []; for (let r = 0; r < e.branches.length; r++) {
    let i = e.branches[r], o = n.job.allocateView(n.xref), a = Wo(n, o.xref, i);
    i.expressionAlias !== null && o.contextVariables.set(i.expressionAlias.name, vh);
    let c;
    if (i.i18n !== void 0) {
        if (!(i.i18n instanceof ln))
            throw Error(`Unhandled i18n metadata type for if block: ${i.i18n?.constructor.name}`);
        c = i.i18n;
    }
    let p = (r === 0 ? ph : hh)(o.xref, Re.Block, a, "Conditional", oe.HTML, c, i.startSourceSpan, i.sourceSpan);
    n.create.push(p), t === null && (t = o.xref);
    let h = i.expression ? R(i.expression, n.job, null) : null, d = new Io(h, p.xref, p.handle, i.expressionAlias);
    s.push(d), St(o, i.children);
} n.update.push(ch(t, null, s, e.sourceSpan)); }
function py(n, e) { if (e.groups.length === 0)
    return; let t = null, s = []; for (let r = 0; r < e.groups.length; r++) {
    let i = e.groups[r], o = n.job.allocateView(n.xref), a = Wo(n, o.xref, i), c;
    if (i.i18n !== void 0) {
        if (!(i.i18n instanceof ln))
            throw Error(`Unhandled i18n metadata type for switch block: ${i.i18n?.constructor.name}`);
        c = i.i18n;
    }
    let p = (r === 0 ? ph : hh)(o.xref, Re.Block, a, "Case", oe.HTML, c, i.startSourceSpan, i.sourceSpan);
    n.create.push(p), t === null && (t = o.xref);
    for (let h of i.cases) {
        let d = h.expression ? R(h.expression, n.job, e.startSourceSpan) : null, v = new Io(d, p.xref, p.handle);
        s.push(v);
    }
    St(o, i.children);
} n.update.push(ch(t, R(e.expression, n.job, null), s, e.sourceSpan)); }
function Pi(n, e, t, s, r) { if (t !== void 0 && !(t instanceof ln))
    throw Error("Unhandled i18n metadata type for defer block"); if (s === void 0)
    return null; let i = n.job.allocateView(n.xref); St(i, s); let o = El(i.xref, Re.Block, null, `Defer${e}`, oe.HTML, t, r, r); return n.create.push(o), o; }
function hy(n, e) { let t = null; if (n.job.deferMeta.mode === 0) {
    if (!n.job.deferMeta.blocks.has(e))
        throw new Error("AssertionError: unable to find a dependency function for this deferred block");
    t = n.job.deferMeta.blocks.get(e) ?? null;
} let s = Pi(n, "", e.i18n, e.children, e.sourceSpan), r = Pi(n, "Loading", e.loading?.i18n, e.loading?.children, e.loading?.sourceSpan), i = Pi(n, "Placeholder", e.placeholder?.i18n, e.placeholder?.children, e.placeholder?.sourceSpan), o = Pi(n, "Error", e.error?.i18n, e.error?.children, e.error?.sourceSpan), a = n.job.allocateXrefId(), c = eg(a, s.xref, s.handle, t, n.job.allDeferrableDepsFn, e.sourceSpan); c.placeholderView = i?.xref ?? null, c.placeholderSlot = i?.handle ?? null, c.loadingSlot = r?.handle ?? null, c.errorSlot = o?.handle ?? null, c.placeholderMinimumTime = e.placeholder?.minimumTime ?? null, c.loadingMinimumTime = e.loading?.minimumTime ?? null, c.loadingAfterTime = e.loading?.afterTime ?? null, c.flags = fy(e), n.create.push(c); let l = [], p = []; wa("hydrate", e.hydrateTriggers, l, p, n, a), wa("none", e.triggers, l, p, n, a), wa("prefetch", e.prefetchTriggers, l, p, n, a), l.some(d => d.modifier === "none") || p.some(d => d.modifier === "none") || l.push(Zt(a, { kind: G.Idle, timeout: null }, "none", null)), n.create.push(l), n.update.push(p); }
function fy(n) { return Object.keys(n.hydrateTriggers).length > 0 ? 1 : null; }
function wa(n, e, t, s, r, i) { if (e.idle !== void 0) {
    let o = Zt(i, { kind: G.Idle, timeout: e.idle.timeout ?? null }, n, e.idle.sourceSpan);
    t.push(o);
} if (e.immediate !== void 0) {
    let o = Zt(i, { kind: G.Immediate }, n, e.immediate.sourceSpan);
    t.push(o);
} if (e.timer !== void 0) {
    let o = Zt(i, { kind: G.Timer, delay: e.timer.delay }, n, e.timer.sourceSpan);
    t.push(o);
} if (e.hover !== void 0) {
    let o = Zt(i, { kind: G.Hover, targetName: e.hover.reference, targetXref: null, targetSlot: null, targetView: null, targetSlotViewSteps: null }, n, e.hover.sourceSpan);
    t.push(o);
} if (e.interaction !== void 0) {
    let o = Zt(i, { kind: G.Interaction, targetName: e.interaction.reference, targetXref: null, targetSlot: null, targetView: null, targetSlotViewSteps: null }, n, e.interaction.sourceSpan);
    t.push(o);
} if (e.viewport !== void 0) {
    let o = Zt(i, { kind: G.Viewport, targetName: e.viewport.reference, targetXref: null, targetSlot: null, targetView: null, targetSlotViewSteps: null, options: e.viewport.options ? R(e.viewport.options, r.job, e.viewport.sourceSpan) : null }, n, e.viewport.sourceSpan);
    t.push(o);
} if (e.never !== void 0) {
    let o = Zt(i, { kind: G.Never }, n, e.never.sourceSpan);
    t.push(o);
} if (e.when !== void 0) {
    if (e.when.value instanceof mi)
        throw new Error("Unexpected interpolation in defer block when trigger");
    let o = Mm(i, R(e.when.value, r.job, e.when.sourceSpan), n, e.when.sourceSpan);
    s.push(o);
} }
function dy(n, e) { if (e.i18n instanceof Me && ey(e.i18n)) {
    let t = n.job.allocateXrefId();
    n.create.push(sg(t, e.i18n, qp(e.i18n).name, null));
    for (let [s, r] of Object.entries(E(E({}, e.vars), e.placeholders)))
        r instanceof ks ? Hh(n, r, s) : qh(n, r, s);
    n.create.push(rg(t));
}
else
    throw Error(`Unhandled i18n metadata type for ICU: ${e.i18n?.constructor.name}`); }
function my(n, e) { let t = n.job.allocateView(n.xref), s = `\u0275$index_${t.xref}`, r = `\u0275$count_${t.xref}`, i = new Set; t.contextVariables.set(e.item.name, e.item.value); for (let b of e.contextVariables)
    b.value === "$index" && i.add(b.name), b.name === "$index" ? t.contextVariables.set("$index", b.value).set(s, b.value) : b.name === "$count" ? t.contextVariables.set("$count", b.value).set(r, b.value) : t.aliases.add({ kind: Ee.Alias, name: null, identifier: b.name, expression: gy(b, s, r) }); let o; e.trackBy === null ? o = F("$index") : o = R(e.trackBy, n.job, ce(e.trackBy.span, e.sourceSpan)), St(t, e.children); let a = null, c = null; e.empty !== null && (a = n.job.allocateView(n.xref), St(a, e.empty.children), c = Wo(n, a.xref, e.empty)); let l = { $index: i, $implicit: e.item.name }; if (e.i18n !== void 0 && !(e.i18n instanceof ln))
    throw Error("AssertionError: Unhandled i18n metadata type or @for"); if (e.empty?.i18n !== void 0 && !(e.empty.i18n instanceof ln))
    throw Error("AssertionError: Unhandled i18n metadata type or @empty"); let p = e.i18n, h = e.empty?.i18n, d = Wo(n, t.xref, e), v = Um(t.xref, a?.xref ?? null, d, o, l, c, p, h, e.startSourceSpan, e.sourceSpan); n.create.push(v); let w = R(e.expression, n.job, ce(e.expression.span, e.sourceSpan)), y = $m(v.xref, v.handle, w, e.sourceSpan); n.update.push(y); }
function gy(n, e, t) { switch (n.value) {
    case "$index": return new me(e);
    case "$count": return new me(t);
    case "$first": return new me(e).identical(g(0));
    case "$last": return new me(e).identical(new me(t).minus(g(1)));
    case "$even": return new me(e).modulo(g(2)).identical(g(0));
    case "$odd": return new me(e).modulo(g(2)).notIdentical(g(0));
    default: throw new Error(`AssertionError: unknown @for loop variable ${n.value}`);
} }
function vy(n, e) { let t = n.job.allocateXrefId(); n.create.push(tg(t, e.name, e.sourceSpan)), n.update.push(Fm(t, e.name, R(e.value, n.job, e.valueSpan), e.sourceSpan)); }
function R(n, e, t) { if (n instanceof Ue)
    return R(n.ast, e, t); if (n instanceof kt)
    return n.receiver instanceof Pt ? new me(n.name) : new We(R(n.receiver, e, t), n.name, null, ce(n.span, t)); if (n instanceof jn) {
    if (n.receiver instanceof Pt)
        throw new Error("Unexpected ImplicitReceiver");
    return new pe(R(n.receiver, e, t), n.args.map(s => R(s, e, t)), void 0, ce(n.span, t));
}
else {
    if (n instanceof Qe)
        return g(n.value, void 0, ce(n.span, t));
    if (n instanceof vs)
        switch (n.operator) {
            case "+": return new On(dr.Plus, R(n.expr, e, t), void 0, ce(n.span, t));
            case "-": return new On(dr.Minus, R(n.expr, e, t), void 0, ce(n.span, t));
            default: throw new Error(`AssertionError: unknown unary operator ${n.operator}`);
        }
    else if (n instanceof Ne) {
        let s = Cg.get(n.operation);
        if (s === void 0)
            throw new Error(`AssertionError: unknown binary operator ${n.operation}`);
        return new H(s, R(n.left, e, t), R(n.right, e, t), void 0, ce(n.span, t));
    }
    else {
        if (n instanceof Cr)
            return new pn(e.root.xref);
        if (n instanceof Un)
            return new gt(R(n.receiver, e, t), R(n.key, e, t), void 0, ce(n.span, t));
        if (n instanceof bs)
            throw new Error("AssertionError: Chain in unknown context");
        if (n instanceof Wn) {
            let s = n.keys.map((r, i) => { let o = R(n.values[i], e, t); return r.kind === "spread" ? new on(o) : new ys(r.key, o, r.quoted); });
            return new vt(s, void 0, ce(n.span, t));
        }
        else {
            if (n instanceof kr)
                return new Dt(n.expressions.map(s => R(s, e, t)));
            if (n instanceof no)
                return new Nt(R(n.condition, e, t), R(n.trueExp, e, t), R(n.falseExp, e, t), void 0, ce(n.span, t));
            if (n instanceof Nr)
                return R(n.expression, e, t);
            if (n instanceof so)
                return new Zn(e.allocateXrefId(), new ye, n.name, [R(n.exp, e, t), ...n.args.map(s => R(s, e, t))]);
            if (n instanceof Ar)
                return new Ln(R(n.receiver, e, t), R(n.key, e, t), ce(n.span, t));
            if (n instanceof br)
                return new Pn(R(n.receiver, e, t), n.name);
            if (n instanceof io)
                return new pe(R(n.receiver, e, t), n.args.map(s => R(s, e, t)), null, ce(n.span, t), !1, [], !0);
            if (n instanceof Te)
                return new ni(ce(n.span, t));
            if (n instanceof Tr)
                return qf(R(n.expression, e, t), ce(n.span, t));
            if (n instanceof _r)
                return di(R(n.expression, e, t));
            if (n instanceof Ir)
                return new zi(R(n.expression, e, t), void 0, ce(n.span, t));
            if (n instanceof Pr)
                return ip(n, e, t);
            if (n instanceof Dr)
                return new mr(R(n.tag, e, t), ip(n.template, e, t), void 0, ce(n.span, t));
            if (n instanceof Lr)
                return new mt(R(n.expression, e, t), void 0, ce(n.span, t));
            if (n instanceof co)
                return new xs(n.body, n.flags, t);
            if (n instanceof ro)
                return new Vn(R(n.expression, e, t));
            if (n instanceof ao)
                return yy(je(n.parameters.map(s => new he(s.name, ge)), R(n.body, e, t)));
            throw new Error(`Unhandled expression type "${n.constructor.name}" in file "${t?.start.file.url}"`);
        }
    }
} }
function ip(n, e, t) { return new vr(n.elements.map(s => new Gi(s.text, ce(s.span, t))), n.expressions.map(s => R(s, e, t)), ce(n.span, t)); }
function Vc(n, e, t, s) { let r; return e instanceof mi ? r = new ne(e.strings, e.expressions.map(i => R(i, n, null)), Object.keys(Ot(t)?.placeholders ?? {})) : e instanceof Q ? r = R(e, n, null) : r = g(e), r; }
var Uh = new Map([[U.Property, _.Property], [U.TwoWay, _.TwoWayProperty], [U.Attribute, _.Attribute], [U.Class, _.ClassName], [U.Style, _.StyleProperty], [U.LegacyAnimation, _.LegacyAnimation], [U.Animation, _.Animation]]);
function wy(n) { return be(n.tagName ?? "")[1] === Mn; }
function Ot(n) { if (n == null)
    return null; if (!(n instanceof Me))
    throw Error(`Expected i18n meta to be a Message, but got: ${n.constructor.name}`); return n; }
function Sy(n, e, t) { let s = new Array, r = new Set; for (let i of t.attributes) {
    let [o, a] = be(t.name), c = o;
    if (!o)
        switch (e.namespace) {
            case oe.SVG:
                c = ea;
                break;
            case oe.Math:
                c = ta;
                break;
        }
    let l = Ut.securityContext(c ? `:${c}:${a}` : a, i.name, !0);
    s.push(Qn(e.xref, _.Attribute, i.name, Vc(n.job, i.value, i.i18n), null, l, !0, !1, null, Ot(i.i18n), i.sourceSpan)), i.i18n && r.add(i.name);
} for (let i of t.inputs)
    r.has(i.name) && console.error(`On component ${n.job.componentName}, the binding ${i.name} is both an i18n attribute and a property. You may want to remove the property binding. This will become a compilation error in future versions of Angular.`), s.push(Qn(e.xref, Uh.get(i.type), i.name, Vc(n.job, ui(i.value), i.i18n), i.unit, i.securityContext, !1, !1, null, Ot(i.i18n) ?? null, i.sourceSpan)); n.create.push(s.filter(i => i?.kind === u.ExtractedAttribute)), n.update.push(s.filter(i => i?.kind === u.Binding)); for (let i of t.outputs) {
    if (i.type === $e.LegacyAnimation && i.phase === null)
        throw Error("Animation listener should have a phase");
    i.type === $e.TwoWay ? n.create.push(mh(e.xref, e.handle, i.name, e.tag, Wh(n, i.handler, i.handlerSpan), i.sourceSpan)) : i.type === $e.Animation ? n.create.push(dh(e.xref, e.handle, i.name, e.tag, li(n, i.handler, i.handlerSpan), i.name.endsWith("enter") ? "enter" : "leave", i.target, !1, i.sourceSpan)) : n.create.push(xl(e.xref, e.handle, i.name, e.tag, li(n, i.handler, i.handlerSpan), i.phase, i.target, !1, i.sourceSpan));
} s.some(i => i?.i18nMessage) !== null && n.create.push(gh(n.job.allocateXrefId(), new ye, e.xref)); }
function Ey(n, e, t, s) { let r = new Array; for (let i of t.templateAttrs)
    if (i instanceof Ts) {
        let o = Ut.securityContext(Mn, i.name, !0);
        r.push(Li(n, e.xref, U.Attribute, i.name, i.value, null, o, !0, s, Ot(i.i18n), i.sourceSpan));
    }
    else
        r.push(Li(n, e.xref, i.type, i.name, ui(i.value), i.unit, i.securityContext, !0, s, Ot(i.i18n), i.sourceSpan)); for (let i of t.attributes) {
    let o = Ut.securityContext(Mn, i.name, !0);
    r.push(Li(n, e.xref, U.Attribute, i.name, i.value, null, o, !1, s, Ot(i.i18n), i.sourceSpan));
} for (let i of t.inputs)
    r.push(Li(n, e.xref, i.type, i.name, ui(i.value), i.unit, i.securityContext, !1, s, Ot(i.i18n), i.sourceSpan)); n.create.push(r.filter(i => i?.kind === u.ExtractedAttribute)), n.update.push(r.filter(i => i?.kind === u.Binding)); for (let i of t.outputs) {
    if (i.type === $e.LegacyAnimation && i.phase === null)
        throw Error("Animation listener should have a phase");
    if (s === Re.NgTemplate && (i.type === $e.TwoWay ? n.create.push(mh(e.xref, e.handle, i.name, e.tag, Wh(n, i.handler, i.handlerSpan), i.sourceSpan)) : n.create.push(xl(e.xref, e.handle, i.name, e.tag, li(n, i.handler, i.handlerSpan), i.phase, i.target, !1, i.sourceSpan))), s === Re.Structural && i.type !== $e.LegacyAnimation) {
        let o = Ut.securityContext(Mn, i.name, !1);
        n.create.push(ft(e.xref, _.Property, null, i.name, null, null, null, o));
    }
} r.some(i => i?.i18nMessage) !== null && n.create.push(gh(n.job.allocateXrefId(), new ye, e.xref)); }
function Li(n, e, t, s, r, i, o, a, c, l, p) { let h = typeof r == "string"; if (c === Re.Structural) {
    if (!a)
        switch (t) {
            case U.Property:
            case U.Class:
            case U.Style: return ft(e, _.Property, null, s, null, null, l, o);
            case U.TwoWay: return ft(e, _.TwoWayProperty, null, s, null, null, l, o);
        }
    if (!h && (t === U.Attribute || t === U.LegacyAnimation || t === U.Animation))
        return null;
} let d = Uh.get(t); return c === Re.NgTemplate && (t === U.Class || t === U.Style || t === U.Attribute && !h) && (d = _.Property), Qn(e, d, s, Vc(n.job, r, l), i, o, h, a, c, l, p); }
function li(n, e, t) { e = ui(e); let s = new Array, r = e instanceof bs ? e.expressions : [e]; if (r.length === 0)
    throw new Error("Expected listener to have non-empty expression list."); let i = r.map(a => R(a, n.job, t)), o = i.pop(); return s.push(...i.map(a => rt(new ke(a, a.sourceSpan)))), s.push(rt(new fe(o, o.sourceSpan))), s; }
function Wh(n, e, t) { e = ui(e); let s = new Array; if (e instanceof bs)
    if (e.expressions.length === 1)
        e = e.expressions[0];
    else
        throw new Error("Expected two-way listener to have a single expression."); let r = R(e, n.job, t), i = new me("$event"), o = new To(r, i); return s.push(rt(new ke(o))), s.push(rt(new fe(i))), s; }
function ui(n) { return n instanceof Ue ? n.ast : n; }
function jh(n, e) { xy(n.localRefs); for (let { name: t, value: s } of e.references)
    n.localRefs.push({ name: t, target: s }); }
function xy(n) { if (!Array.isArray(n))
    throw new Error("AssertionError: expected an array"); }
function ce(n, e) { if (e === null)
    return null; let t = e.start.moveBy(n.start), s = e.start.moveBy(n.end), r = e.fullStart.moveBy(n.start); return new D(t, s, r); }
function Wo(n, e, t) { let s = null; for (let r of t.children)
    if (!(r instanceof An || r instanceof ul)) {
        if (s !== null)
            return null;
        if (r instanceof wt && n.job.getForeignComponent(r) === null || r instanceof et && r.tagName !== null)
            s = r;
        else
            return null;
    } if (s !== null) {
    for (let i of s.attributes)
        if (!i.name.startsWith(Kx)) {
            let o = Ut.securityContext(Mn, i.name, !0);
            n.update.push(Qn(e, _.Attribute, i.name, g(i.value), null, o, !0, !1, null, Ot(i.i18n), i.sourceSpan));
        }
    for (let i of s.inputs)
        if (i.type !== U.LegacyAnimation && i.type !== U.Animation && i.type !== U.Attribute) {
            let o = Ut.securityContext(Mn, i.name, !0);
            n.create.push(ft(e, _.Property, null, i.name, null, null, null, o));
        }
    let r = s instanceof wt ? s.name : s.tagName;
    return r === Mn ? null : r;
} return null; }
function yy(n) { let e = new Set(n.params.map(t => t.name)); return k(n, t => { if (t instanceof rn)
    for (let s of t.params)
        e.add(s.name);
else if (t instanceof me && e.has(t.name))
    return F(t.name); return t; }, M.None); }
var Cy = !1;
function jo(n, e) { return Qo(F(Ms).bitwiseAnd(g(n), null), e); }
function by(n) { return (n.descendants ? 1 : 0) | (n.static ? 2 : 0) | (n.emitDistinctChangesOnly ? 4 : 0); }
function Ay(n, e) { if (Array.isArray(n.predicate)) {
    let t = [];
    return n.predicate.forEach(s => { let r = s.split(",").map(i => g(i.trim())); t.push(...r); }), e.getConstLiteral(X(t), !0);
}
else
    switch (n.predicate.forwardRef) {
        case 0:
        case 2: return n.predicate.expression;
        case 1: return A(f.resolveForwardRef).callFn([n.predicate.expression]);
    } }
function zh(n, e, t) { let s = []; return t !== void 0 && s.push(...t), n.isSignal && s.push(new We(F(st), n.propertyName)), s.push(Ay(n, e), g(by(n))), n.read && s.push(n.read), s; }
var Al = Symbol("queryAdvancePlaceholder");
function Gh(n) { let e = [], t = 0, s = () => { t > 0 && (e.unshift(A(f.queryAdvance).callFn(t === 1 ? [] : [g(t)]).toStmt()), t = 0); }; for (let r = n.length - 1; r >= 0; r--) {
    let i = n[r];
    i === Al ? t++ : (s(), e.unshift(i));
} return s(), e; }
function ky(n, e, t) { let s = [], r = [], i = Hp(l => r.push(l), hl), o = null, a = null; n.forEach(l => { let p = zh(l, e); if (l.isSignal ? (o ??= A(f.viewQuerySignal), o = o.callFn(p)) : (a ??= A(f.viewQuery), a = a.callFn(p)), l.isSignal) {
    r.push(Al);
    return;
} let h = i(), d = A(f.loadQuery).callFn([]), v = A(f.queryRefresh).callFn([h.set(d)]), w = F(st).prop(l.propertyName).set(l.first ? h.prop("first") : h); r.push(v.and(w).toStmt()); }), o !== null && s.push(new ke(o)), a !== null && s.push(new ke(a)); let c = t ? `${t}_Query` : null; return an([new he(Ms, Rn), new he(st, ge)], [jo(1, s), jo(2, Gh(r))], It, null, c); }
function Ty(n, e, t) { let s = [], r = [], i = Hp(l => r.push(l), hl), o = null, a = null; for (let l of n) {
    let p = zh(l, e, [F("dirIndex")]);
    if (l.isSignal ? (o ??= A(f.contentQuerySignal), o = o.callFn(p)) : (a ??= A(f.contentQuery), a = a.callFn(p)), l.isSignal) {
        r.push(Al);
        continue;
    }
    let h = i(), d = A(f.loadQuery).callFn([]), v = A(f.queryRefresh).callFn([h.set(d)]), w = F(st).prop(l.propertyName).set(l.first ? h.prop("first") : h);
    r.push(v.and(w).toStmt());
} o !== null && s.push(new ke(o)), a !== null && s.push(new ke(a)); let c = t ? `${t}_ContentQueries` : null; return an([new he(Ms, Rn), new he(st, ge), new he("dirIndex", Rn)], [jo(1, s), jo(2, Gh(r))], It, null, c); }
var qc = class extends Rv {
    constructor() { super(Dc); }
    parse(e, t, s) { return super.parse(e, t, s); }
};
function _y(n) { if (n == null || n.length === 0 || n[0] == "/")
    return !1; let e = n.match(Iy); return e === null || e[1] == "package" || e[1] == "asset"; }
var Iy = /^([^:/?#]+):/, Ny = "select", Dy = "link", Py = "rel", Ly = "href", By = "stylesheet", $y = "style", My = new Set([":math:script", ":svg:script", "script"]), Ry = "ngNonBindable", Fy = "ngProjectAs";
function Xh(n) { let e = null, t = null, s = null, r = !1, i = ""; for (let c of n.attrs) {
    let l = c.name.toLowerCase();
    l == Ny ? e = c.value : l == Ly ? t = c.value : l == Py ? s = c.value : c.name == Ry ? r = !0 : c.name == Fy && c.value.length > 0 && (i = c.value);
} e ||= "*"; let o = n.name.toLowerCase(), a = Ze.OTHER; return Fa(o) ? a = Ze.NG_CONTENT : $y === o ? a = Ze.STYLE : My.has(o) ? a = Ze.SCRIPT : o == Dy && s == By && (a = Ze.STYLESHEET), new Hc(a, e, t, r, i); }
var Ze = (function (n) { return n[n.NG_CONTENT = 0] = "NG_CONTENT", n[n.STYLE = 1] = "STYLE", n[n.STYLESHEET = 2] = "STYLESHEET", n[n.SCRIPT = 3] = "SCRIPT", n[n.OTHER = 4] = "OTHER", n; })(Ze || {}), Hc = class {
    type;
    selectAttr;
    hrefAttr;
    nonBindable;
    projectAs;
    constructor(e, t, s, r, i) { this.type = e, this.selectAttr = t, this.hrefAttr = s, this.nonBindable = r, this.projectAs = i; }
};
function Oy(n, e) { let t = []; if (n.parameters.length < 1 || n.parameters.length > 2)
    return t.push(new N(n.startSourceSpan, '@content block must have one or two parameters, e.g. "@content(header)" or "@content(items; let item, index)"')), { node: null, errors: t }; let s = n.parameters[0], r = s.expression.trim(); if (r.includes(","))
    return t.push(new N(n.startSourceSpan, "@content block must have exactly one name parameter")), { node: null, errors: t }; if (!cl.test(r))
    return t.push(new N(s.sourceSpan, "@content name must be a valid JavaScript identifier")), { node: null, errors: t }; let i = Vy(n, t); return i === null ? { node: null, errors: t } : { node: new _s(r, i, Z(e, n.children, n.children), n.nameSpan, n.sourceSpan, n.startSourceSpan, n.endSourceSpan, n.i18n), errors: t }; }
function Vy(n, e) { let t = []; if (n.parameters.length < 2)
    return t; let s = n.parameters[1], i = s.expression.trim().match($p); if (!i)
    return e.push(new N(s.sourceSpan, '@content block variables must start with "let", e.g. "let item, index"')), null; let o = i[1].split(",").map(h => h.trim()), a = i[1], c = s.expression.indexOf(a), l = s.sourceSpan.start.moveBy(c), p = 0; for (let h of o) {
    if (h === "") {
        e.push(new N(s.sourceSpan, "Invalid variable name in @content block"));
        continue;
    }
    let d, v = a.indexOf(h, p), w = l.moveBy(v);
    if (h.includes("=")) {
        let y = h.indexOf("="), b = h.substring(0, y).trim(), T = new D(w, w.moveBy(h.length));
        e.push(new N(T, "@content block variables cannot be assigned a value")), h = b, d = new D(w, w.moveBy(h.length));
    }
    else
        d = new D(w, w.moveBy(h.length));
    if (!cl.test(h)) {
        e.push(new N(d, `Variable name "${h}" must be a valid JavaScript identifier`)), p = v + h.length;
        continue;
    }
    if (t.some(y => y.name === h)) {
        e.push(new N(d, `Duplicate variable name "${h}" in @content block`)), p = v + h.length;
        continue;
    }
    t.push(new Wt(h, "", d, d)), p = v + h.length;
} return t; }
var qy = /^\s*([0-9A-Za-z_$]*)\s+of\s+([\S\s]*)/, Hy = /^track\s+([\S\s]*)/, Uy = /^(as\s+)(.*)/, op = /(\s*)(\S+)(\s*)/, pr = new Set(["$index", "$first", "$last", "$even", "$odd", "$count"]);
function ap(n) { return n === "empty"; }
function cp(n) { return n === "else" || n === "else if"; }
function Wy(n, e, t, s) { let r = Yy(e), i = [], o = lp(n, r, s); o !== null && i.push(new In(o.expression, Z(t, n.children, n.children), o.expressionAlias, n.sourceSpan, n.startSourceSpan, n.endSourceSpan, n.nameSpan, n.i18n)); for (let h of e)
    if (h.name === "else if") {
        let d = lp(h, r, s);
        if (d !== null) {
            let v = Z(t, h.children, h.children);
            i.push(new In(d.expression, v, d.expressionAlias, h.sourceSpan, h.startSourceSpan, h.endSourceSpan, h.nameSpan, h.i18n));
        }
    }
    else if (h.name === "else") {
        let d = Z(t, h.children, h.children);
        i.push(new In(null, d, null, h.sourceSpan, h.startSourceSpan, h.endSourceSpan, h.nameSpan, h.i18n));
    } let a = i.length > 0 ? i[0].startSourceSpan : n.startSourceSpan, c = i.length > 0 ? i[i.length - 1].endSourceSpan : n.endSourceSpan, l = n.sourceSpan, p = i[i.length - 1]; return p !== void 0 && (l = new D(a.start, p.sourceSpan.end)), { node: new go(i, l, n.startSourceSpan, c, n.nameSpan), errors: r }; }
function jy(n, e, t, s) { let r = [], i = Gy(n, r, s), o = null, a = null; for (let c of e)
    c.name === "empty" ? a !== null ? r.push(new N(c.sourceSpan, "@for loop can only have one @empty block")) : c.parameters.length > 0 ? r.push(new N(c.sourceSpan, "@empty block cannot have parameters")) : a = new Vr(Z(t, c.children, c.children), c.sourceSpan, c.startSourceSpan, c.endSourceSpan, c.nameSpan, c.i18n) : r.push(new N(c.sourceSpan, `Unrecognized @for loop block "${c.name}"`)); if (i !== null) {
    let c = a?.endSourceSpan ?? n.endSourceSpan, l = new D(n.sourceSpan.start, c?.end ?? n.sourceSpan.end), p, h;
    i.trackBy === null ? (p = h = null, r.push(new N(n.startSourceSpan, '@for loop must have a "track" expression'))) : (p = i.trackBy.expression, h = i.trackBy.keywordSpan, Xy(i.trackBy.expression, i.trackBy.keywordSpan, r)), o = new Is(i.itemName, i.expression, p, h, i.context, Z(t, n.children, n.children), a, l, n.sourceSpan, n.startSourceSpan, c, n.nameSpan, n.i18n);
} return { node: o, errors: r }; }
function zy(n, e, t) { let s = Zy(n), r = n.parameters.length > 0 ? Ss(n.parameters[0], t) : t.parseBinding("", !1, n.sourceSpan, 0), i = [], o = [], a = [], c = null, l = null; for (let h of n.children) {
    if (!(h instanceof ut))
        continue;
    if ((h.name !== "case" || h.parameters.length === 0) && h.name !== "default" && h.name !== "default never") {
        o.push(new vo(h.name, h.sourceSpan, h.nameSpan));
        continue;
    }
    l !== null && s.push(new N(h.sourceSpan, '@default block with "never" parameter must be the last case in a switch'));
    let d = h.name === "case", v = null;
    if (d)
        v = Ss(h.parameters[0], t);
    else if (h.name === "default never") {
        h.parameters.length > 0 && (v = Ss(h.parameters[0], t)), (h.children.length > 0 || h.endSourceSpan !== null && h.endSourceSpan.start.offset !== h.endSourceSpan.end.offset) && s.push(new N(h.sourceSpan, '@default block with "never" parameter cannot have a body')), a.length > 0 && s.push(new N(h.sourceSpan, 'A @case block with no body cannot be followed by a @default block with "never" parameter')), l = new Ga(v, h.sourceSpan, h.startSourceSpan, h.endSourceSpan, h.nameSpan);
        continue;
    }
    let w = new za(v, h.sourceSpan, h.startSourceSpan, h.endSourceSpan, h.nameSpan);
    if (a.push(w), h.children.length === 0 && h.endSourceSpan !== null && h.endSourceSpan.start.offset === h.endSourceSpan.end.offset) {
        c === null && (c = h.sourceSpan);
        continue;
    }
    let b = h.sourceSpan, T = h.startSourceSpan;
    c !== null && (b = new D(c.start, h.sourceSpan.end), T = new D(c.start, h.startSourceSpan.end), c = null);
    let $ = new Or(a, Z(e, h.children, h.children), b, T, h.endSourceSpan, h.nameSpan, h.i18n);
    i.push($), a = [];
} return { node: new mo(r, i, o, l, n.sourceSpan, n.startSourceSpan, n.endSourceSpan, n.nameSpan), errors: s }; }
function Gy(n, e, t) { if (n.parameters.length === 0)
    return e.push(new N(n.startSourceSpan, "@for loop does not have an expression")), null; let [s, ...r] = n.parameters, i = Jy(s, e)?.match(qy); if (!i || i[2].trim().length === 0)
    return e.push(new N(s.sourceSpan, 'Cannot parse expression. @for loop expression must match the pattern "<identifier> of <expression>"')), null; let [, o, a] = i; pr.has(o) && e.push(new N(s.sourceSpan, `@for loop item name cannot be one of ${Array.from(pr).join(", ")}.`)); let c = s.expression.split(" ")[0], l = new D(s.sourceSpan.start, s.sourceSpan.start.moveBy(c.length)), p = { itemName: new Wt(o, "$implicit", l, l), trackBy: null, expression: Ss(s, t, a), context: Array.from(pr, h => { let d = new D(n.startSourceSpan.end, n.startSourceSpan.end); return new Wt(h, h, d, d); }) }; for (let h of r) {
    let d = h.expression.match($p);
    if (d !== null) {
        let w = new D(h.sourceSpan.start.moveBy(d[0].length - d[1].length), h.sourceSpan.end);
        Qy(h.sourceSpan, d[1], w, o, p.context, e);
        continue;
    }
    let v = h.expression.match(Hy);
    if (v !== null) {
        if (p.trackBy !== null)
            e.push(new N(h.sourceSpan, '@for loop can only have one "track" expression'));
        else {
            let w = Ss(h, t, v[1]);
            w.ast instanceof Te && e.push(new N(n.startSourceSpan, '@for loop must have a "track" expression'));
            let y = new D(h.sourceSpan.start, h.sourceSpan.start.moveBy(5));
            p.trackBy = { expression: w, keywordSpan: y };
        }
        continue;
    }
    e.push(new N(h.sourceSpan, `Unrecognized @for loop parameter "${h.expression}"`));
} return p; }
function Xy(n, e, t) { let s = new Uc; n.ast.visit(s), s.hasPipe && t.push(new N(e, "Cannot use pipes in track expressions")); }
function Qy(n, e, t, s, r, i) { let o = e.split(","), a = t.start; for (let c of o) {
    let l = c.split("="), p = l.length === 2 ? l[0].trim() : "", h = l.length === 2 ? l[1].trim() : "";
    if (p.length === 0 || h.length === 0)
        i.push(new N(n, 'Invalid @for loop "let" parameter. Parameter should match the pattern "<name> = <variable name>"'));
    else if (!pr.has(h))
        i.push(new N(n, `Unknown "let" parameter variable "${h}". The allowed variables are: ${Array.from(pr).join(", ")}`));
    else if (p === s)
        i.push(new N(n, `Invalid @for loop "let" parameter. Variable cannot be called "${s}"`));
    else if (r.some(d => d.name === p))
        i.push(new N(n, `Duplicate "let" parameter variable "${h}"`));
    else {
        let [, d, v] = l[0].match(op) ?? [], w = d !== void 0 && l.length === 2 ? new D(a.moveBy(d.length), a.moveBy(d.length + v.length)) : t, y;
        if (l.length === 2) {
            let [, T, $] = l[1].match(op) ?? [];
            y = T !== void 0 ? new D(a.moveBy(l[0].length + 1 + T.length), a.moveBy(l[0].length + 1 + T.length + $.length)) : void 0;
        }
        let b = new D(w.start, y?.end ?? w.end);
        r.push(new Wt(p, h, b, w, y));
    }
    a = a.moveBy(c.length + 1);
} }
function Yy(n) { let e = [], t = !1; for (let s = 0; s < n.length; s++) {
    let r = n[s];
    r.name === "else" ? (t ? e.push(new N(r.startSourceSpan, "Conditional can only have one @else block")) : n.length > 1 && s < n.length - 1 ? e.push(new N(r.startSourceSpan, "@else block must be last inside the conditional")) : r.parameters.length > 0 && e.push(new N(r.startSourceSpan, "@else block cannot have parameters")), t = !0) : r.name !== "else if" && e.push(new N(r.startSourceSpan, `Unrecognized conditional block @${r.name}`));
} return e; }
function Zy(n) { let e = [], t = !1; if (n.parameters.length !== 1)
    return e.push(new N(n.startSourceSpan, "@switch block must have exactly one parameter")), e; for (let s of n.children)
    if (!(s instanceof ii || s instanceof Jn && s.value.trim().length === 0)) {
        if (!(s instanceof ut) || s.name !== "case" && s.name !== "default" && s.name !== "default never") {
            e.push(new N(s.sourceSpan, "@switch block can only contain @case and @default blocks"));
            continue;
        }
        s.name === "default never" ? (t && e.push(new N(s.startSourceSpan, "@switch block can only have one @default block")), t = !0) : s.name === "default" ? (t ? e.push(new N(s.startSourceSpan, "@switch block can only have one @default block")) : s.parameters.length > 0 && e.push(new N(s.startSourceSpan, "@default block cannot have parameters")), t = !0) : s.name === "case" && s.parameters.length !== 1 && e.push(new N(s.startSourceSpan, "@case block must have exactly one parameter"));
    } return e; }
function Ss(n, e, t) { let s, r; return typeof t == "string" ? (s = Math.max(0, n.expression.lastIndexOf(t)), r = s + t.length) : (s = 0, r = n.expression.length), e.parseBinding(n.expression.slice(s, r), !1, n.sourceSpan, n.sourceSpan.start.offset + s); }
function lp(n, e, t) { if (n.parameters.length === 0)
    return e.push(new N(n.startSourceSpan, "Conditional block does not have an expression")), null; let s = Ss(n.parameters[0], t), r = null; for (let i = 1; i < n.parameters.length; i++) {
    let o = n.parameters[i], a = o.expression.match(Uy);
    if (a === null)
        e.push(new N(o.sourceSpan, `Unrecognized conditional parameter "${o.expression}"`));
    else if (n.name !== "if" && n.name !== "else if")
        e.push(new N(o.sourceSpan, '"as" expression is only allowed on `@if` and `@else if` blocks'));
    else if (r !== null)
        e.push(new N(o.sourceSpan, 'Conditional can only have one "as" expression'));
    else {
        let c = a[2].trim();
        if (cl.test(c)) {
            let l = o.sourceSpan.start.moveBy(a[1].length), p = new D(l, l.moveBy(c.length));
            r = new Wt(c, c, p, p);
        }
        else
            e.push(new N(o.sourceSpan, '"as" expression must be a valid JavaScript identifier'));
    }
} return { expression: s, expressionAlias: r }; }
function Jy(n, e) { let t = n.expression, s = /^\s$/, r = 0, i = 0, o = t.length - 1; for (let a = 0; a < t.length; a++) {
    let c = t[a];
    if (c === "(")
        i = a + 1, r++;
    else {
        if (s.test(c))
            continue;
        break;
    }
} if (r === 0)
    return t; for (let a = t.length - 1; a > -1; a--) {
    let c = t[a];
    if (c === ")") {
        if (o = a, r--, r === 0)
            break;
    }
    else {
        if (s.test(c))
            continue;
        break;
    }
} return r !== 0 ? (e.push(new N(n.sourceSpan, "Unclosed parentheses in expression")), null) : t.slice(i, o); }
var Uc = class extends As {
    hasPipe = !1;
    visitPipe() { this.hasPipe = !0; }
}, Ky = /^\d+\.?\d*(ms|s)?$/, eC = /^\s$/, up = new Map([[pt, Le], [Tt, Ft], [Be, ue]]), Ie = (function (n) { return n.IDLE = "idle", n.TIMER = "timer", n.INTERACTION = "interaction", n.IMMEDIATE = "immediate", n.HOVER = "hover", n.VIEWPORT = "viewport", n.NEVER = "never", n; })(Ie || {});
function tC({ expression: n, sourceSpan: e }, t, s) { let r = n.indexOf("never"), i = new D(e.start.moveBy(r), e.start.moveBy(r + 5)), o = kl(n, e), a = Tl(n, e); r === -1 ? s.push(new N(e, 'Could not find "never" keyword in expression')) : _l("never", t, s, new Ha(i, e, o, null, a)); }
function Sa({ expression: n, sourceSpan: e }, t, s, r) { let i = n.indexOf("when"), o = new D(e.start.moveBy(i), e.start.moveBy(i + 4)), a = kl(n, e), c = Tl(n, e); if (i === -1)
    r.push(new N(e, 'Could not find "when" keyword in expression'));
else {
    let l = pi(n, i + 1), p = t.parseBinding(n.slice(l), !1, e, e.start.offset + l);
    _l("when", s, r, new po(p, e, a, o, c));
} }
function Ea({ expression: n, sourceSpan: e }, t, s, r, i) { let o = n.indexOf("on"), a = new D(e.start.moveBy(o), e.start.moveBy(o + 2)), c = kl(n, e), l = Tl(n, e); if (o === -1)
    r.push(new N(e, 'Could not find "on" keyword in expression'));
else {
    let p = pi(n, o + 1), h = n.startsWith("hydrate");
    new Wc(n, t, p, e, s, r, h ? lC : cC, h, c, a, l).parse();
} }
function kl(n, e) { return n.startsWith("prefetch") ? new D(e.start, e.start.moveBy(8)) : null; }
function Tl(n, e) { return n.startsWith("hydrate") ? new D(e.start, e.start.moveBy(7)) : null; }
var Wc = class {
    expression;
    bindingParser;
    start;
    span;
    triggers;
    errors;
    validator;
    isHydrationTrigger;
    prefetchSpan;
    onSourceSpan;
    hydrateSpan;
    index = 0;
    tokens;
    constructor(e, t, s, r, i, o, a, c, l, p, h) { this.expression = e, this.bindingParser = t, this.start = s, this.span = r, this.triggers = i, this.errors = o, this.validator = a, this.isHydrationTrigger = c, this.prefetchSpan = l, this.onSourceSpan = p, this.hydrateSpan = h, this.tokens = new ci().tokenize(e.slice(s)); }
    parse() { for (; this.tokens.length > 0 && this.index < this.tokens.length;) {
        let e = this.token();
        if (!e.isIdentifier()) {
            this.unexpectedToken(e);
            break;
        }
        if (this.isFollowedByOrLast(_e))
            this.consumeTrigger(e, []), this.advance();
        else if (this.isFollowedByOrLast(Be)) {
            this.advance();
            let t = this.errors.length, s = this.consumeParameters();
            if (this.errors.length !== t)
                break;
            this.consumeTrigger(e, s), this.advance();
        }
        else
            this.index < this.tokens.length - 1 && this.unexpectedToken(this.tokens[this.index + 1]);
        this.advance();
    } }
    advance() { this.index++; }
    isFollowedByOrLast(e) { return this.index === this.tokens.length - 1 ? !0 : this.tokens[this.index + 1].isCharacter(e); }
    token() { return this.tokens[Math.min(this.index, this.tokens.length - 1)]; }
    consumeTrigger(e, t) { let s = this.span.start.moveBy(this.start + e.index - this.tokens[0].index), r = new D(s, s.moveBy(e.strValue.length)), i = s.moveBy(this.token().end - e.index), o = e.index === 0, a = o ? this.onSourceSpan : null, c = o ? this.prefetchSpan : null, l = o ? this.hydrateSpan : null, p = new D(o ? this.span.start : s, i); try {
        switch (e.toString()) {
            case Ie.IDLE:
                this.trackTrigger("idle", nC(t, r, p, c, a, l));
                break;
            case Ie.TIMER:
                this.trackTrigger("timer", sC(t, r, p, this.prefetchSpan, this.onSourceSpan, this.hydrateSpan));
                break;
            case Ie.INTERACTION:
                this.trackTrigger("interaction", oC(t, r, p, this.prefetchSpan, this.onSourceSpan, this.hydrateSpan, this.validator));
                break;
            case Ie.IMMEDIATE:
                this.trackTrigger("immediate", rC(t, r, p, this.prefetchSpan, this.onSourceSpan, this.hydrateSpan));
                break;
            case Ie.HOVER:
                this.trackTrigger("hover", iC(t, r, p, this.prefetchSpan, this.onSourceSpan, this.hydrateSpan, this.validator));
                break;
            case Ie.VIEWPORT:
                this.trackTrigger("viewport", aC(this.start, this.isHydrationTrigger, this.bindingParser, t, r, p, this.prefetchSpan, this.onSourceSpan, this.hydrateSpan, this.validator));
                break;
            default: throw new Error(`Unrecognized trigger type "${e}"`);
        }
    }
    catch (h) {
        this.error(e, h.message);
    } }
    consumeParameters() { let e = []; if (!this.token().isCharacter(Be))
        return this.unexpectedToken(this.token()), e; this.advance(); let t = [], s = []; for (; this.index < this.tokens.length;) {
        let r = this.token();
        if (r.isCharacter(ue) && t.length === 0) {
            s.length && e.push({ expression: this.tokenRangeText(s), start: s[0].index });
            break;
        }
        if (r.type === L.Character && up.has(r.numValue) && t.push(up.get(r.numValue)), t.length > 0 && r.isCharacter(t[t.length - 1]) && t.pop(), t.length === 0 && r.isCharacter(_e) && s.length > 0) {
            e.push({ expression: this.tokenRangeText(s), start: s[0].index }), this.advance(), s = [];
            continue;
        }
        s.push(r), this.advance();
    } return (!this.token().isCharacter(ue) || t.length > 0) && this.error(this.token(), "Unexpected end of expression"), this.index < this.tokens.length - 1 && !this.tokens[this.index + 1].isCharacter(_e) && this.unexpectedToken(this.tokens[this.index + 1]), e; }
    tokenRangeText(e) { return e.length === 0 ? "" : this.expression.slice(this.start + e[0].index, this.start + e[e.length - 1].end); }
    trackTrigger(e, t) { _l(e, this.triggers, this.errors, t); }
    error(e, t) { let s = this.span.start.moveBy(this.start + e.index), r = s.moveBy(e.end - e.index); this.errors.push(new N(new D(s, r), t)); }
    unexpectedToken(e) { this.error(e, `Unexpected token "${e}"`); }
};
function _l(n, e, t, s) { e[n] ? t.push(new N(s.sourceSpan, `Duplicate "${n}" trigger is not allowed`)) : e[n] = s; }
function nC(n, e, t, s, r, i) { if (n.length > 1)
    throw new Error(`"${Ie.IDLE}" trigger can only have zero or one parameters`); let o = null; if (n[0] && (o = hi(n[0].expression), o === null))
    throw new Error(`Could not parse time value of trigger "${Ie.IDLE}"`); return new Ua(e, t, s, r, i, o); }
function sC(n, e, t, s, r, i) { if (n.length !== 1)
    throw new Error(`"${Ie.TIMER}" trigger must have exactly one parameter`); let o = hi(n[0].expression); if (o === null)
    throw new Error(`Could not parse time value of trigger "${Ie.TIMER}"`); return new ja(o, e, t, s, r, i); }
function rC(n, e, t, s, r, i) { if (n.length > 0)
    throw new Error(`"${Ie.IMMEDIATE}" trigger cannot have parameters`); return new Wa(e, t, s, r, i); }
function iC(n, e, t, s, r, i, o) { return o(Ie.HOVER, n), new ho(n[0]?.expression ?? null, e, t, s, r, i); }
function oC(n, e, t, s, r, i, o) { return o(Ie.INTERACTION, n), new fo(n[0]?.expression ?? null, e, t, s, r, i); }
function aC(n, e, t, s, r, i, o, a, c, l) { l(Ie.VIEWPORT, s); let p, h; if (s.length === 0)
    p = h = null;
else if (!s[0].expression.startsWith("{"))
    p = s[0].expression, h = null;
else {
    let d = t.parseBinding(s[0].expression, !1, i, i.start.offset + n + s[0].start);
    if (d.ast instanceof Wn) {
        if (d.ast.keys.some(w => w.kind === "spread"))
            throw new Error("Spread operator are not allowed in this context");
        if (d.ast.keys.some(w => w.kind === "property" && w.key === "root"))
            throw new Error('The "root" option is not supported in the options parameter of the "viewport" trigger');
    }
    else
        throw new Error('Options parameter of the "viewport" trigger must be an object literal');
    let v = d.ast.keys.findIndex(w => w.kind === "property" && w.key === "trigger");
    if (v === -1)
        p = null, h = d.ast;
    else {
        let w = d.ast.values[v], y = (b, T) => T !== v;
        if (!(w instanceof kt) || !(w.receiver instanceof Pt))
            throw new Error('"trigger" option of the "viewport" trigger must be an identifier');
        p = w.name, h = new Wn(d.ast.span, d.ast.sourceSpan, d.ast.keys.filter(y), d.ast.values.filter(y));
    }
} if (e && p !== null)
    throw new Error('"viewport" hydration trigger cannot have a "trigger"'); if (h) {
    let d = jc.findDynamicNode(h);
    if (d !== null)
        throw new Error(`Options of the "viewport" trigger must be an object literal containing only literal values, but "${d.constructor.name}" was found`);
} return new $r(p, h, r, i, o, a, c); }
function cC(n, e) { if (e.length > 1)
    throw new Error(`"${n}" trigger can only have zero or one parameters`); }
function lC(n, e) { if (n === Ie.VIEWPORT) {
    if (e.length > 1)
        throw new Error(`Hydration trigger "${n}" cannot have more than one parameter`);
    return;
} if (e.length > 0)
    throw new Error(`Hydration trigger "${n}" cannot have parameters`); }
function pi(n, e = 0) { let t = !1; for (let s = e; s < n.length; s++)
    if (eC.test(n[s]))
        t = !0;
    else if (t)
        return s; return -1; }
function hi(n) { let e = n.match(Ky); if (!e)
    return null; let [t, s] = e; return parseFloat(t) * (s === "s" ? 1e3 : 1); }
var jc = class n extends As {
    dynamicNode = null;
    static findDynamicNode(e) { let t = new n; return t.visit(e), t.dynamicNode; }
    visit(e) { !(e instanceof Ue) && !(e instanceof Qe) && !(e instanceof kr) && !(e instanceof Wn) ? this.dynamicNode = e : super.visit(e); }
}, uC = /^prefetch\s+when\s/, pC = /^prefetch\s+on\s/, hC = /^hydrate\s+when\s/, fC = /^hydrate\s+on\s/, dC = /^hydrate\s+never(\s*)$/, Qh = /^minimum\s/, mC = /^after\s/, gC = /^when\s/, vC = /^on\s/;
function zc(n) { return n === "placeholder" || n === "loading" || n === "error"; }
function wC(n, e, t, s) { let r = [], { placeholder: i, loading: o, error: a } = SC(e, r, t), { triggers: c, prefetchTriggers: l, hydrateTriggers: p } = CC(n, s, r), h = n.endSourceSpan, d = n.sourceSpan.end; if (e.length > 0) {
    let y = e[e.length - 1];
    h = y.endSourceSpan, d = y.sourceSpan.end;
} let v = new D(n.sourceSpan.start, d); return { node: new zn(Z(t, n.children, n.children), c, l, p, i, o, a, n.nameSpan, v, n.sourceSpan, n.startSourceSpan, h, n.i18n), errors: r }; }
function SC(n, e, t) { let s = null, r = null, i = null; for (let o of n)
    try {
        if (!zc(o.name)) {
            e.push(new N(o.startSourceSpan, `Unrecognized block "@${o.name}"`));
            break;
        }
        switch (o.name) {
            case "placeholder":
                s !== null ? e.push(new N(o.startSourceSpan, "@defer block can only have one @placeholder block")) : s = EC(o, t);
                break;
            case "loading":
                r !== null ? e.push(new N(o.startSourceSpan, "@defer block can only have one @loading block")) : r = xC(o, t);
                break;
            case "error":
                i !== null ? e.push(new N(o.startSourceSpan, "@defer block can only have one @error block")) : i = yC(o, t);
                break;
        }
    }
    catch (a) {
        e.push(new N(o.startSourceSpan, a.message));
    } return { placeholder: s, loading: r, error: i }; }
function EC(n, e) { let t = null; for (let s of n.parameters)
    if (Qh.test(s.expression)) {
        if (t != null)
            throw new Error('@placeholder block can only have one "minimum" parameter');
        let r = hi(s.expression.slice(pi(s.expression)));
        if (r === null)
            throw new Error('Could not parse time value of parameter "minimum"');
        t = r;
    }
    else
        throw new Error(`Unrecognized parameter in @placeholder block: "${s.expression}"`); return new Mr(Z(e, n.children, n.children), t, n.nameSpan, n.sourceSpan, n.startSourceSpan, n.endSourceSpan, n.i18n); }
function xC(n, e) { let t = null, s = null; for (let r of n.parameters)
    if (mC.test(r.expression)) {
        if (t != null)
            throw new Error('@loading block can only have one "after" parameter');
        let i = hi(r.expression.slice(pi(r.expression)));
        if (i === null)
            throw new Error('Could not parse time value of parameter "after"');
        t = i;
    }
    else if (Qh.test(r.expression)) {
        if (s != null)
            throw new Error('@loading block can only have one "minimum" parameter');
        let i = hi(r.expression.slice(pi(r.expression)));
        if (i === null)
            throw new Error('Could not parse time value of parameter "minimum"');
        s = i;
    }
    else
        throw new Error(`Unrecognized parameter in @loading block: "${r.expression}"`); return new Rr(Z(e, n.children, n.children), t, s, n.nameSpan, n.sourceSpan, n.startSourceSpan, n.endSourceSpan, n.i18n); }
function yC(n, e) { if (n.parameters.length > 0)
    throw new Error("@error block cannot have parameters"); return new Fr(Z(e, n.children, n.children), n.nameSpan, n.sourceSpan, n.startSourceSpan, n.endSourceSpan, n.i18n); }
function CC(n, e, t, s) { let r = {}, i = {}, o = {}; for (let a of n.parameters)
    gC.test(a.expression) ? Sa(a, e, r, t) : vC.test(a.expression) ? Ea(a, e, r, t) : uC.test(a.expression) ? Sa(a, e, i, t) : pC.test(a.expression) ? Ea(a, e, i, t) : hC.test(a.expression) ? Sa(a, e, o, t) : fC.test(a.expression) ? Ea(a, e, o, t) : dC.test(a.expression) ? tC(a, o, t) : t.push(new N(a.sourceSpan, "Unrecognized trigger")); return o.never && Object.keys(o).length > 1 && t.push(new N(n.startSourceSpan, "Cannot specify additional `hydrate` triggers if `hydrate never` is present")), { triggers: r, prefetchTriggers: i, hydrateTriggers: o }; }
var bC = /^(?:(bind-)|(let-)|(ref-|#)|(on-)|(bindon-)|(@))(.*)$/, pp = 1, hp = 2, fp = 3, dp = 4, mp = 5, AC = 6, Qs = 7, Yt = { BANANA_BOX: { start: "[(", end: ")]" }, PROPERTY: { start: "[", end: "]" }, EVENT: { start: "(", end: ")" } }, xa = "*", kC = new Set(["link", "style", "script", "ng-template", "ng-container", "ng-content"]), TC = new Set(["ngProjectAs", "ngNonBindable"]);
function _C(n, e, t) { let s = new Gc(e, t), r = Z(s, n, n), i = e.errors.concat(s.errors), o = { nodes: r, errors: i, styleUrls: s.styleUrls, styles: s.styles, ngContentSelectors: s.ngContentSelectors }; return t.collectCommentNodes && (o.commentNodes = s.commentNodes), o; }
var Gc = class {
    bindingParser;
    options;
    errors = [];
    styles = [];
    styleUrls = [];
    ngContentSelectors = [];
    commentNodes = [];
    inI18nBlock = !1;
    processedNodes = new Set;
    constructor(e, t) { this.bindingParser = e, this.options = t; }
    visitElement(e) { let t = Oi(e.i18n); t && (this.inI18nBlock && this.reportError("Cannot mark an element as translatable inside of a translatable section. Please remove the nested i18n marker.", e.sourceSpan), this.inI18nBlock = !0); let s = Xh(e); if (s.type === Ze.SCRIPT)
        return null; if (s.type === Ze.STYLE) {
        let T = IC(e);
        return T !== null && this.styles.push(T), null;
    }
    else if (s.type === Ze.STYLESHEET && _y(s.hrefAttr))
        return this.styleUrls.push(s.hrefAttr), null; let r = Ed(e.name), { attributes: i, boundEvents: o, references: a, variables: c, templateVariables: l, elementHasInlineTemplate: p, parsedProperties: h, templateParsedProperties: d, i18nAttrsMeta: v } = this.prepareAttributes(e.attrs, r), w = this.extractDirectives(e), y; s.nonBindable ? y = Z(gp, e.children).flat(1 / 0) : y = Z(this, e.children, e.children); let b; if (s.type === Ze.NG_CONTENT) {
        let T = s.selectAttr, $ = e.attrs.map(W => this.visitAttribute(W));
        b = new Ns(T, $, y, e.isSelfClosing, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, e.i18n), this.ngContentSelectors.push(T);
    }
    else if (r) {
        let T = this.categorizePropertyAttributes(e.name, h, v);
        b = new et(e.name, i, T.bound, o, w, [], y, a, c, e.isSelfClosing, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, e.i18n);
    }
    else {
        let T = this.categorizePropertyAttributes(e.name, h, v);
        if (e.name === "ng-container")
            for (let $ of T.bound)
                $.type === U.Attribute && this.reportError("Attribute bindings are not supported on ng-container. Use property bindings instead.", $.sourceSpan);
        b = new wt(e.name, i, T.bound, o, w, y, a, e.isSelfClosing, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, e.isVoid, e.i18n);
    } return this.options.collectCommentNodes && e.comments.forEach(T => { this.commentNodes.push(new An(T.value || "", T.sourceSpan)); }), p && (b = this.wrapInTemplate(b, d, l, v, r, t)), t && (this.inI18nBlock = !1), b; }
    visitAttribute(e) { return new Ts(e.name, e.value, e.sourceSpan, e.keySpan, e.valueSpan, e.i18n); }
    visitText(e) { return this.processedNodes.has(e) ? null : this._visitTextWithInterpolation(e.value, e.sourceSpan, e.tokens, e.i18n); }
    visitExpansion(e) { if (!e.i18n)
        return null; if (!Oi(e.i18n))
        throw new Error(`Invalid type "${e.i18n.constructor}" for "i18n" property of ${e.sourceSpan.toString()}. Expected a "Message"`); let t = e.i18n, s = {}, r = {}; return Object.keys(t.placeholders).forEach(i => { let o = t.placeholders[i]; if (i.startsWith(bd)) {
        let a = i.trim(), c = this.bindingParser.parseInterpolationExpression(o.text, o.sourceSpan);
        s[a] = new ks(c, o.sourceSpan);
    }
    else
        r[i] = this._visitTextWithInterpolation(o.text, o.sourceSpan, null); }), new Fp(s, r, e.sourceSpan, t); }
    visitExpansionCase(e) { return null; }
    visitComment(e) { return this.options.collectCommentNodes && this.commentNodes.push(new An(e.value || "", e.sourceSpan)), null; }
    visitStartTagComment(e) { return this.options.collectCommentNodes && this.commentNodes.push(new An(e.value || "", e.sourceSpan)), null; }
    visitLetDeclaration(e, t) { let s = this.bindingParser.parseBinding(e.value, !1, e.valueSpan, e.valueSpan.start.offset); return s.errors.length === 0 && s.ast instanceof Te && this.reportError("@let declaration value cannot be empty", e.valueSpan), new ul(e.name, s, e.sourceSpan, e.nameSpan, e.valueSpan); }
    visitComponent(e) { let t = Oi(e.i18n); if (t && (this.inI18nBlock && this.reportError("Cannot mark a component as translatable inside of a translatable section. Please remove the nested i18n marker.", e.sourceSpan), this.inI18nBlock = !0), e.tagName !== null && kC.has(e.tagName))
        return this.reportError(`Tag name "${e.tagName}" cannot be used as a component tag`, e.startSourceSpan), null; let { attributes: s, boundEvents: r, references: i, templateVariables: o, elementHasInlineTemplate: a, parsedProperties: c, templateParsedProperties: l, i18nAttrsMeta: p } = this.prepareAttributes(e.attrs, !1); this.validateSelectorlessReferences(i); let h = this.extractDirectives(e), d; e.attrs.find(y => y.name === "ngNonBindable") ? d = Z(gp, e.children).flat(1 / 0) : d = Z(this, e.children, e.children); let v = this.categorizePropertyAttributes(e.tagName, c, p), w = new sr(e.componentName, e.tagName, e.fullName, s, v.bound, r, h, d, i, e.isSelfClosing, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, e.i18n); return this.options.collectCommentNodes && e.comments.forEach(y => { this.commentNodes.push(new An(y.value || "", y.sourceSpan)); }), a && (w = this.wrapInTemplate(w, l, o, p, !1, t)), t && (this.inI18nBlock = !1), w; }
    visitDirective() { return null; }
    visitBlockParameter() { return null; }
    visitBlock(e, t) { let s = Array.isArray(t) ? t.indexOf(e) : -1; if (s === -1)
        throw new Error("Visitor invoked incorrectly. Expecting visitBlock to be invoked siblings array as its context"); if (this.processedNodes.has(e))
        return null; let r = null; switch (e.name) {
        case "defer":
            r = wC(e, this.findConnectedBlocks(s, t, zc), this, this.bindingParser);
            break;
        case "switch":
            r = zy(e, this, this.bindingParser);
            break;
        case "content":
            r = Oy(e, this);
            break;
        case "for":
            r = jy(e, this.findConnectedBlocks(s, t, ap), this, this.bindingParser);
            break;
        case "if":
            r = Wy(e, this.findConnectedBlocks(s, t, cp), this, this.bindingParser);
            break;
        default:
            let i;
            zc(e.name) ? (i = `@${e.name} block can only be used after an @defer block.`, this.processedNodes.add(e)) : ap(e.name) ? (i = `@${e.name} block can only be used after an @for block.`, this.processedNodes.add(e)) : cp(e.name) ? (i = `@${e.name} block can only be used after an @if or @else if block.`, this.processedNodes.add(e)) : i = `Unrecognized block @${e.name}.`, r = { node: new vo(e.name, e.sourceSpan, e.nameSpan), errors: [new N(e.sourceSpan, i)] };
            break;
    } return this.errors.push(...r.errors), r.node; }
    findConnectedBlocks(e, t, s) { let r = []; for (let i = e + 1; i < t.length; i++) {
        let o = t[i];
        if (!(o instanceof ii)) {
            if (o instanceof Jn && o.value.trim().length === 0) {
                this.processedNodes.add(o);
                continue;
            }
            if (!(o instanceof ut) || !s(o.name))
                break;
            r.push(o), this.processedNodes.add(o);
        }
    } return r; }
    categorizePropertyAttributes(e, t, s) { let r = [], i = []; return t.forEach(o => { let a = s[o.name]; if (o.isLiteral)
        i.push(new Ts(o.name, o.expression.source || "", o.sourceSpan, o.keySpan, o.valueSpan, a));
    else {
        let c = o.name.toLowerCase().startsWith("attr.on"), l = this.bindingParser.createBoundElementProperty(e, o, !c, !1);
        r.push(Va.fromBoundElementProperty(l, a));
    } }), { bound: r, literal: i }; }
    prepareAttributes(e, t) { let s = [], r = [], i = [], o = [], a = [], c = {}, l = [], p = [], h = !1; for (let d of e) {
        let v = !1, w = !1;
        if (d.i18n && (c[d.name] = d.i18n), d.name.startsWith(xa)) {
            h && this.reportError("Can't have multiple template bindings on one element. Use only one attribute prefixed with *", d.sourceSpan), w = !0, h = !0;
            let y = d.value, b = d.name.substring(xa.length), T = [], $ = d.valueSpan ? d.valueSpan.fullStart.offset : d.sourceSpan.fullStart.offset + d.name.length;
            this.bindingParser.parseInlineTemplateBinding(b, y, d.sourceSpan, $, [], l, T, !0), p.push(...T.map(W => new Wt(W.name, W.value, W.sourceSpan, W.keySpan, W.valueSpan)));
        }
        else
            v = this.parseAttribute(t, d, [], s, r, i, o);
        !v && !w && a.push(this.visitAttribute(d));
    } return { attributes: a, boundEvents: r, references: o, variables: i, templateVariables: p, elementHasInlineTemplate: h, parsedProperties: s, templateParsedProperties: l, i18nAttrsMeta: c }; }
    parseAttribute(e, t, s, r, i, o, a) { let c = t.name, l = t.value, p = t.sourceSpan, h = t.valueSpan ? t.valueSpan.fullStart.offset : p.fullStart.offset; function d(T, $, W) { let J = T.start.moveBy($.length), Mt = J.moveBy(W.length); return new D(J, Mt, J, W); } let v = c.match(bC); if (v) {
        if (v[pp] != null) {
            let T = v[Qs], $ = d(p, v[pp], T);
            this.bindingParser.parsePropertyBinding(T, l, !1, !1, p, h, t.valueSpan, s, r, $);
        }
        else if (v[hp])
            if (e) {
                let T = v[Qs], $ = d(p, v[hp], T);
                this.parseVariable(T, l, p, $, t.valueSpan, o);
            }
            else
                this.reportError('"let-" is only supported on ng-template elements.', p);
        else if (v[fp]) {
            let T = v[Qs], $ = d(p, v[fp], T);
            this.parseReference(T, l, p, $, t.valueSpan, a);
        }
        else if (v[dp]) {
            let T = [], $ = v[Qs], W = d(p, v[dp], $);
            this.bindingParser.parseEvent($, l, !1, p, t.valueSpan || p, s, T, W), ya(T, i);
        }
        else if (v[mp]) {
            let T = v[Qs], $ = d(p, v[mp], T);
            this.bindingParser.parsePropertyBinding(T, l, !1, !0, p, h, t.valueSpan, s, r, $), this.parseAssignmentEvent(T, l, p, t.valueSpan, s, i, $, h);
        }
        else if (v[AC]) {
            let T = d(p, "", c);
            this.bindingParser.parseLiteralAttr(c, l, p, h, t.valueSpan, s, r, T);
        }
        return !0;
    } let w = null; if (c.startsWith(Yt.BANANA_BOX.start) ? w = Yt.BANANA_BOX : c.startsWith(Yt.PROPERTY.start) ? w = Yt.PROPERTY : c.startsWith(Yt.EVENT.start) && (w = Yt.EVENT), w !== null && c.endsWith(w.end) && c.length > w.start.length + w.end.length) {
        let T = c.substring(w.start.length, c.length - w.end.length), $ = d(p, w.start, T);
        if (w.start === Yt.BANANA_BOX.start)
            this.bindingParser.parsePropertyBinding(T, l, !1, !0, p, h, t.valueSpan, s, r, $), this.parseAssignmentEvent(T, l, p, t.valueSpan, s, i, $, h);
        else if (w.start === Yt.PROPERTY.start)
            this.bindingParser.parsePropertyBinding(T, l, !1, !1, p, h, t.valueSpan, s, r, $);
        else {
            let W = [];
            this.bindingParser.parseEvent(T, l, !1, p, t.valueSpan || p, s, W, $), ya(W, i);
        }
        return !0;
    } let y = d(p, "", c); return this.bindingParser.parsePropertyInterpolation(c, l, p, t.valueSpan, s, r, y, t.valueTokens ?? null); }
    extractDirectives(e) { let t = e instanceof Pe ? e.tagName : e.name, s = [], r = new Set; for (let i of e.directives) {
        let o = !1;
        for (let v of i.attrs)
            v.name.startsWith(xa) ? (o = !0, this.reportError(`Shorthand template syntax "${v.name}" is not supported inside a directive context`, v.sourceSpan)) : TC.has(v.name) && (o = !0, this.reportError(`Attribute "${v.name}" is not supported in a directive context`, v.sourceSpan));
        if (!o && r.has(i.name) && (o = !0, this.reportError(`Cannot apply directive "${i.name}" multiple times on the same element`, i.sourceSpan)), o)
            continue;
        let { attributes: a, parsedProperties: c, boundEvents: l, references: p, i18nAttrsMeta: h } = this.prepareAttributes(i.attrs, !1);
        this.validateSelectorlessReferences(p);
        let { bound: d } = this.categorizePropertyAttributes(t, c, h);
        for (let v of d)
            v.type !== U.Property && v.type !== U.TwoWay && (o = !0, this.reportError("Binding is not supported in a directive context", v.sourceSpan));
        o || (r.add(i.name), s.push(new Rp(i.name, a, d, l, p, i.sourceSpan, i.startSourceSpan, i.endSourceSpan, void 0)));
    } return s; }
    filterAnimationAttributes(e) { return e.filter(t => !t.name.startsWith("animate.")); }
    filterAnimationInputs(e) { return e.filter(t => t.type !== U.Animation); }
    wrapInTemplate(e, t, s, r, i, o) { let a = this.categorizePropertyAttributes("ng-template", t, r), c = []; a.literal.forEach(d => c.push(d)), a.bound.forEach(d => c.push(d)); let l = { attributes: [], inputs: [], outputs: [] }; (e instanceof wt || e instanceof sr) && (l.attributes.push(...this.filterAnimationAttributes(e.attributes)), l.inputs.push(...this.filterAnimationInputs(e.inputs)), l.outputs.push(...e.outputs)); let p = i && o ? void 0 : e.i18n, h; return e instanceof sr ? h = e.tagName : e instanceof et ? h = null : h = e.name, new et(h, l.attributes, l.inputs, l.outputs, [], c, [e], [], s, !1, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, p); }
    _visitTextWithInterpolation(e, t, s, r) { let i = kh(e), o = this.bindingParser.parseInterpolation(i, t, s); return o ? new ks(o, t, r) : new kn(i, t); }
    parseVariable(e, t, s, r, i, o) { e.indexOf("-") > -1 ? this.reportError('"-" is not allowed in variable names', s) : e.length === 0 && this.reportError("Variable does not have a name", s), o.push(new Wt(e, t, s, r, i)); }
    parseReference(e, t, s, r, i, o) { e.indexOf("-") > -1 ? this.reportError('"-" is not allowed in reference names', s) : e.length === 0 ? this.reportError("Reference does not have a name", s) : o.some(a => a.name === e) && this.reportError(`Reference "#${e}" is defined more than once`, s), o.push(new qr(e, t, s, r, i)); }
    parseAssignmentEvent(e, t, s, r, i, o, a, c) { let l = []; this.bindingParser.parseEvent(`${e}Change`, t, !0, s, r || s, i, l, a), ya(l, o); }
    validateSelectorlessReferences(e) { if (e.length === 0)
        return; let t = new Set; for (let s of e)
        s.value.length > 0 ? this.reportError("Cannot specify a value for a local reference in this context", s.valueSpan || s.sourceSpan) : t.has(s.name) ? this.reportError("Duplicate reference names are not allowed", s.sourceSpan) : t.add(s.name); }
    reportError(e, t, s = sn.ERROR) { this.errors.push(new N(t, e, s)); }
}, Xc = class {
    visitElement(e) { let t = Xh(e); if (t.type === Ze.SCRIPT || t.type === Ze.STYLE || t.type === Ze.STYLESHEET)
        return null; let s = Z(this, e.children, null); return new wt(e.name, Z(this, e.attrs), [], [], [], s, [], e.isSelfClosing, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, e.isVoid); }
    visitComment(e) { return null; }
    visitAttribute(e) { return new Ts(e.name, e.value, e.sourceSpan, e.keySpan, e.valueSpan, e.i18n); }
    visitText(e) { return new kn(e.value, e.sourceSpan); }
    visitExpansion(e) { return null; }
    visitExpansionCase(e) { return null; }
    visitBlock(e, t) { let s = [new kn(e.startSourceSpan.toString(), e.startSourceSpan), ...Z(this, e.children)]; return e.endSourceSpan !== null && s.push(new kn(e.endSourceSpan.toString(), e.endSourceSpan)), s; }
    visitBlockParameter(e, t) { return null; }
    visitLetDeclaration(e, t) { return new kn(`@let ${e.name} = ${e.value};`, e.sourceSpan); }
    visitComponent(e, t) { let s = Z(this, e.children, null); return new wt(e.fullName, Z(this, e.attrs), [], [], [], s, [], e.isSelfClosing, e.sourceSpan, e.startSourceSpan, e.endSourceSpan, !1); }
    visitDirective(e, t) { return null; }
}, gp = new Xc;
function ya(n, e) { e.push(...n.map(t => qa.fromParsedEvent(t))); }
function IC(n) { return n.children.length !== 1 || !(n.children[0] instanceof Jn) ? null : n.children[0].value; }
var NC = [" ", `
`, "\r", "	"];
function DC(n, e, t = {}) { let { preserveWhitespaces: s, enableI18nLegacyMessageIdFormat: r } = t, i = t.enableSelectorless ?? !1, o = zo(i), c = new qc().parse(n, e, se(E({ leadingTriviaChars: NC }, t), { tokenizeExpansionForms: !0, tokenizeBlocks: t.enableBlockSyntax ?? !0, tokenizeLet: t.enableLetSyntax ?? !0, selectorlessEnabled: i })); if (!t.alwaysAttemptHtmlToR3AstConversion && c.errors && c.errors.length > 0) {
    let J = { preserveWhitespaces: s, errors: c.errors, nodes: [], styleUrls: [], styles: [], ngContentSelectors: [] };
    return t.collectCommentNodes && (J.commentNodes = []), J;
} let l = c.rootNodes, p = !(t.preserveSignificantWhitespace ?? !0), h = new qo(!s, r, t.preserveSignificantWhitespace, p), d = h.visitAllWithErrors(l); if (!t.alwaysAttemptHtmlToR3AstConversion && d.errors && d.errors.length > 0) {
    let J = { preserveWhitespaces: s, errors: d.errors, nodes: [], styleUrls: [], styles: [], ngContentSelectors: [] };
    return t.collectCommentNodes && (J.commentNodes = []), J;
} l = d.rootNodes, s || (l = Z(new Oo(!0, void 0, !1), l), h.hasI18nMeta && (l = Z(new qo(!1, void 0, !0, p), l))); let { nodes: v, errors: w, styleUrls: y, styles: b, ngContentSelectors: T, commentNodes: $ } = _C(l, o, { collectCommentNodes: !!t.collectCommentNodes }); w.push(...c.errors, ...d.errors); let W = { preserveWhitespaces: s, errors: w.length > 0 ? w : null, nodes: v, styleUrls: y, styles: b, ngContentSelectors: T }; return t.collectCommentNodes && (W.commentNodes = $), W; }
var PC = new mn;
function zo(n = !1) { return new Fc(new Vo(new ci, n), PC, []); }
var Yh = "%COMP%", LC = `_nghost-${Yh}`, BC = `_ngcontent-${Yh}`;
function Zh(n, e, t) { let s = new jt, r = rl(n.selector); return s.set("type", n.type.value), r.length > 0 && s.set("selectors", ps(r)), n.queries.length > 0 && s.set("contentQueries", Ty(n.queries, e, n.name)), n.viewQueries.length && s.set("viewQuery", ky(n.viewQueries, e, n.name)), s.set("hostBindings", HC(n.host, n.typeSourceSpan, t, e, n.selector || "", n.name, s, n.legacyOptionalChaining)), s.set("inputs", Ql(n.inputs, !0)), s.set("outputs", Ql(n.outputs)), n.exportAs !== null && s.set("exportAs", X(n.exportAs.map(i => g(i)))), n.isStandalone === !1 && s.set("standalone", g(!1)), n.isSignal && s.set("signals", g(!0)), s; }
function Jh(n, e) { let t = [], s = e.providers, r = e.viewProviders; if (s || r) {
    let i = [s || new Dt([])];
    r && i.push(r), t.push(A(f.ProvidersFeature).callFn(i));
} if (e.hostDirectives?.length && t.push(A(f.HostDirectivesFeature).callFn([GC(e.hostDirectives)])), e.usesInheritance && t.push(A(f.InheritDefinitionFeature)), e.lifecycle.usesOnChanges && t.push(A(f.NgOnChangesFeature)), e.controlCreate !== null && t.push(A(f.ControlFeature).callFn([g(e.controlCreate.passThroughInput)])), "externalStyles" in e && e.externalStyles?.length) {
    let i = e.externalStyles.map(o => g(o));
    t.push(A(f.ExternalStylesFeature).callFn([X(i)]));
} t.length && n.set("features", X(t)); }
function $C(n, e, t) { let s = Zh(n, e, t); Jh(s, n); let r = A(f.defineDirective).callFn([s.toLiteralMap()], void 0, !0), i = qC(n); return { expression: r, type: i, statements: [] }; }
function MC(n, e, t) { let s = Zh(n, e, t); Jh(s, n); let r = n.name, i = null; if (n.defer.mode === 1 && n.defer.dependenciesFn !== null) {
    let d = `${r}_DeferFn`;
    e.statements.push(new ve(d, n.defer.dependenciesFn, void 0, xe.Final)), i = F(d);
} let o = n.isStandalone && !n.hasDirectiveDependencies ? Ve.DomOnly : Ve.Full, a = ty(n.name, n.template.nodes, e, o, n.relativeContextFilePath, n.i18nUseExternalIds, n.defer, i, n.relativeTemplatePath, n.enableTemplateSourceLocations || Cy, n.legacyOptionalChaining, n.foreignImports); Fh(a, C.Tmpl); let c = Gx(a, e); if (a.contentSelectors !== null && s.set("ngContentSelectors", a.contentSelectors), s.set("decls", g(a.root.decls)), s.set("vars", g(a.root.vars)), a.consts.length > 0 && (a.constsInitializers.length > 0 ? s.set("consts", je([], [...a.constsInitializers, new fe(X(a.consts))])) : s.set("consts", X(a.consts))), s.set("template", c), n.declarationListEmitMode !== 3 && n.declarations.length > 0)
    s.set("dependencies", FC(X(n.declarations.map(d => d.type)), n.declarationListEmitMode));
else if (n.declarationListEmitMode === 3) {
    let d = [n.type.value];
    n.rawImports && d.push(n.rawImports), s.set("dependencies", A(f.getComponentDepsFactory).callFn(d));
} n.encapsulation === null && (n.encapsulation = en.Emulated); let l = !!n.externalStyles?.length; if (n.styles && n.styles.length) {
    let d = n.styles.map(y => Em(y)), w = (n.encapsulation == en.Emulated ? zC(d, BC, LC) : d).reduce((y, b) => (b.trim().length > 0 && y.push(e.getConstLiteral(g(b))), y), []);
    w.length > 0 && (l = !0, s.set("styles", X(w)));
} !l && n.encapsulation === en.Emulated && (n.encapsulation = en.None), n.encapsulation !== en.Emulated && s.set("encapsulation", g(n.encapsulation)), n.animations !== null && s.set("data", nt([{ key: "animation", value: n.animations, quoted: !1 }])), n.changeDetection !== null && (typeof n.changeDetection == "number" && n.changeDetection !== sl.OnPush ? s.set("changeDetection", g(n.changeDetection)) : typeof n.changeDetection == "object" && s.set("changeDetection", n.changeDetection)); let p = A(f.defineComponent).callFn([s.toLiteralMap()], void 0, !0), h = RC(n); return { expression: p, type: h, statements: [] }; }
function RC(n) { let e = Kh(n); return e.push(Yc(n.template.ngContentSelectors)), e.push(we(g(n.isStandalone))), e.push(ef(n)), n.isSignal && e.push(we(g(n.isSignal))), we(A(f.ComponentDeclaration, e)); }
function FC(n, e) { switch (e) {
    case 0: return n;
    case 1: return je([], n);
    case 2:
        let t = n.prop("map").callFn([A(f.resolveForwardRef)]);
        return je([], t);
    case 3: throw new Error("Unsupported with an array of pre-resolved dependencies");
} }
function OC(n) { return we(g(n)); }
function Qc(n) { let e = Object.keys(n).map(t => { let s = Array.isArray(n[t]) ? n[t][0] : n[t]; return { key: t, value: g(s), quoted: !0 }; }); return nt(e); }
function Yc(n) { return n.length > 0 ? we(X(n.map(e => g(e)))) : Je; }
function Kh(n) { let e = n.selector !== null ? n.selector.replace(/\n/g, "") : null; return [Yo(n.type.type, n.typeArgumentCount), e !== null ? OC(e) : Je, n.exportAs !== null ? Yc(n.exportAs) : Je, we(VC(n)), we(Qc(n.outputs)), Yc(n.queries.map(t => t.propertyName))]; }
function VC(n) { return nt(Object.keys(n.inputs).map(e => { let t = n.inputs[e], s = [{ key: "alias", value: g(t.bindingPropertyName), quoted: !0 }, { key: "required", value: g(t.required), quoted: !0 }]; return t.isSignal && s.push({ key: "isSignal", value: g(t.isSignal), quoted: !0 }), { key: e, value: nt(s), quoted: !0 }; })); }
function qC(n) { let e = Kh(n); return e.push(Je), e.push(we(g(n.isStandalone))), e.push(ef(n)), n.isSignal && e.push(we(g(n.isSignal))), we(A(f.DirectiveDeclaration, e)); }
function HC(n, e, t, s, r, i, o, a) { let c = t.createBoundHostProperties(n.properties, e), l = t.createDirectiveHostEventAsts(n.listeners, e); n.specialAttributes.styleAttr && (n.attributes.style = g(n.specialAttributes.styleAttr)), n.specialAttributes.classAttr && (n.attributes.class = g(n.specialAttributes.classAttr)); let p = ny({ componentName: i, componentSelector: r, properties: c, events: l, attributes: n.attributes, legacyOptionalChaining: a }, t, s); Fh(p, C.Host), o.set("hostAttrs", p.root.attributes); let h = p.root.vars; return h !== null && h > 0 && o.set("hostVars", g(h)), Xx(p); }
function UC(n) { let e = {}, t = {}, s = {}, r = {}; for (let i of Object.keys(n)) {
    let o = n[i];
    if (i.startsWith("(") && i.endsWith(")")) {
        if (typeof o != "string")
            throw new Error("Event binding must be string");
        t[i.slice(1, -1)] = o;
    }
    else if (i.startsWith("[") && i.endsWith("]")) {
        if (typeof o != "string")
            throw new Error("Property binding must be string");
        s[i.slice(1, -1)] = o;
    }
    else
        switch (i) {
            case "class":
                if (typeof o != "string")
                    throw new Error("Class binding must be string");
                r.classAttr = o;
                break;
            case "style":
                if (typeof o != "string")
                    throw new Error("Style binding must be string");
                r.styleAttr = o;
                break;
            default: typeof o == "string" ? e[i] = g(o) : e[i] = o;
        }
} return { attributes: e, listeners: t, properties: s, specialAttributes: r }; }
function WC(n, e) { let t = zo(); return t.createDirectiveHostEventAsts(n.listeners, e), t.createBoundHostProperties(n.properties, e), jC(n, t, e), t.errors; }
function jC(n, e, t) {
    for (let s in n.properties) {
        let r = s.startsWith("attr."), i = r ? s.slice(5) : s;
        if (i.toLowerCase().startsWith("on")) {
            let o = r ? "attribute" : "property", a = `(${i.slice(2)})=...`, c = `Binding to event ${o} '${i}' is disallowed for security reasons, please use ${a}`;
            r || (c += `
If '${s}' is a directive input, make sure the directive is imported by the current module.`), e.errors.push(new N(t, c));
        }
    }
}
function zC(n, e, t) { let s = new rc; return n.map(r => s.shimCssText(r, e, t)); }
function ef(n) { return n.hostDirectives?.length ? we(X(n.hostDirectives.map(e => nt([{ key: "directive", value: di(e.directive.type), quoted: !1 }, { key: "inputs", value: Qc(e.inputs || {}), quoted: !1 }, { key: "outputs", value: Qc(e.outputs || {}), quoted: !1 }])))) : Je; }
function GC(n) { let e = [], t = !1; for (let s of n) {
    if (!s.inputs && !s.outputs)
        e.push(s.directive.type);
    else {
        let r = [{ key: "directive", value: s.directive.type, quoted: !1 }];
        if (s.inputs) {
            let i = vp(s.inputs);
            i && r.push({ key: "inputs", value: i, quoted: !1 });
        }
        if (s.outputs) {
            let i = vp(s.outputs);
            i && r.push({ key: "outputs", value: i, quoted: !1 });
        }
        e.push(nt(r));
    }
    s.isForwardReference && (t = !0);
} return t ? new Vt([], [new fe(X(e))]) : X(e); }
function vp(n) { let e = []; for (let t in n)
    Object.hasOwn(n, t) && e.push(g(t), g(n[t])); return e.length > 0 ? X(e) : null; }
var Zc = class extends As {
    visit(e) { e instanceof Ue ? this.visit(e.ast) : e.visit(this); }
    visitElement(e) { this.visitAllTemplateNodes(e.attributes), this.visitAllTemplateNodes(e.inputs), this.visitAllTemplateNodes(e.outputs), this.visitAllTemplateNodes(e.directives), this.visitAllTemplateNodes(e.references), this.visitAllTemplateNodes(e.children); }
    visitTemplate(e) { this.visitAllTemplateNodes(e.attributes), this.visitAllTemplateNodes(e.inputs), this.visitAllTemplateNodes(e.outputs), this.visitAllTemplateNodes(e.directives), this.visitAllTemplateNodes(e.templateAttrs), this.visitAllTemplateNodes(e.variables), this.visitAllTemplateNodes(e.references), this.visitAllTemplateNodes(e.children); }
    visitContent(e) { this.visitAllTemplateNodes(e.children); }
    visitContentBlock(e) { this.visitAllTemplateNodes(e.children); }
    visitBoundAttribute(e) { this.visit(e.value); }
    visitBoundEvent(e) { this.visit(e.handler); }
    visitBoundText(e) { this.visit(e.value); }
    visitIcu(e) { Object.keys(e.vars).forEach(t => this.visit(e.vars[t])), Object.keys(e.placeholders).forEach(t => this.visit(e.placeholders[t])); }
    visitDeferredBlock(e) { e.visitAll(this); }
    visitDeferredTrigger(e) { e instanceof po ? this.visit(e.value) : e instanceof $r && e.options !== null && this.visit(e.options); }
    visitDeferredBlockPlaceholder(e) { this.visitAllTemplateNodes(e.children); }
    visitDeferredBlockError(e) { this.visitAllTemplateNodes(e.children); }
    visitDeferredBlockLoading(e) { this.visitAllTemplateNodes(e.children); }
    visitSwitchBlock(e) { this.visit(e.expression), this.visitAllTemplateNodes(e.groups), e.exhaustiveCheck?.visit(this); }
    visitSwitchBlockCase(e) { e.expression && this.visit(e.expression); }
    visitSwitchBlockCaseGroup(e) { this.visitAllTemplateNodes(e.cases), this.visitAllTemplateNodes(e.children); }
    visitSwitchExhaustiveCheck(e) { }
    visitForLoopBlock(e) { e.item.visit(this), this.visitAllTemplateNodes(e.contextVariables), this.visit(e.expression), this.visitAllTemplateNodes(e.children), e.empty?.visit(this); }
    visitForLoopBlockEmpty(e) { this.visitAllTemplateNodes(e.children); }
    visitIfBlock(e) { this.visitAllTemplateNodes(e.branches); }
    visitIfBlockBranch(e) { e.expression && this.visit(e.expression), e.expressionAlias?.visit(this), this.visitAllTemplateNodes(e.children); }
    visitLetDeclaration(e) { this.visit(e.value); }
    visitComponent(e) { this.visitAllTemplateNodes(e.attributes), this.visitAllTemplateNodes(e.inputs), this.visitAllTemplateNodes(e.outputs), this.visitAllTemplateNodes(e.directives), this.visitAllTemplateNodes(e.references), this.visitAllTemplateNodes(e.children); }
    visitDirective(e) { this.visitAllTemplateNodes(e.attributes), this.visitAllTemplateNodes(e.inputs), this.visitAllTemplateNodes(e.outputs), this.visitAllTemplateNodes(e.references); }
    visitVariable(e) { }
    visitReference(e) { }
    visitTextAttribute(e) { }
    visitText(e) { }
    visitUnknownBlock(e) { }
    visitAllTemplateNodes(e) { for (let t of e)
        this.visit(t); }
}, Vi = (function (n) { return n[n.Selector = 0] = "Selector", n[n.HostDirective = 1] = "HostDirective", n; })(Vi || {}), Go = class n {
    forwardMap;
    reverseMap;
    constructor(e) { this.forwardMap = e, this.reverseMap = XC(e); }
    static empty() { return new n(new Map); }
    static fromMappedObject(e) { let t = new Map; for (let s of Object.keys(e)) {
        let r = e[s], i;
        typeof r == "string" ? i = { classPropertyName: s, bindingPropertyName: r, isSignal: !1 } : i = r, t.set(s, i);
    } return new n(t); }
    static merge(e, t) { let s = new Map(e.forwardMap.entries()); for (let [r, i] of t.forwardMap)
        s.set(r, i); return new n(s); }
    get classPropertyNames() { return Array.from(this.forwardMap.keys()); }
    get propertyNames() { return Array.from(this.reverseMap.keys()); }
    hasBindingPropertyName(e) { return this.reverseMap.has(e); }
    getByBindingPropertyName(e) { return this.reverseMap.has(e) ? this.reverseMap.get(e) : null; }
    getByClassPropertyName(e) { return this.forwardMap.has(e) ? this.forwardMap.get(e) : null; }
    toDirectMappedObject() { let e = {}; for (let [t, s] of this.forwardMap)
        e[t] = s.bindingPropertyName; return e; }
    toJointMappedObject(e) { let t = {}; for (let [s, r] of this.forwardMap)
        t[s] = e(r); return t; }
    *[Symbol.iterator]() { for (let e of this.forwardMap.values())
        yield e; }
};
function XC(n) { let e = new Map; for (let [t, s] of n)
    e.has(s.bindingPropertyName) || e.set(s.bindingPropertyName, []), e.get(s.bindingPropertyName).push(s); return e; }
var Jc = class {
    directiveMatcher;
    foreignComponentMatcher;
    constructor(e, t = null) { this.directiveMatcher = e, this.foreignComponentMatcher = t; }
    bind(e) { if (!e.template && !e.host)
        throw new Error("Empty bound targets are not supported"); let t = new Map, s = new Map, r = [], i = new Set, o = new Map, a = new Map, c = new Map, l = new Map, p = new Map, h = new Map, d = new Set, v = new Set, w = [], y = new Map; if (e.template) {
        let b = wp.apply(e.template);
        QC(b, c), Kc.apply(e.template, this.directiveMatcher, this.foreignComponentMatcher, t, s, r, i, o, a, y), Xo.applyWithScope(e.template, b, l, p, h, d, v, w);
    } return e.host && (t.set(e.host.node, e.host.directives), Xo.applyWithScope(e.host.node, wp.apply(e.host.node), l, p, h, d, v, w)), new el(e, t, s, r, i, o, a, l, p, h, c, d, v, w, y); }
}, wp = class qi {
    parentScope;
    rootNode;
    namedEntities = new Map;
    elementLikeInScope = new Set;
    childScopes = new Map;
    isDeferred;
    constructor(e, t) { this.parentScope = e, this.rootNode = t, this.isDeferred = e !== null && e.isDeferred ? !0 : t instanceof zn; }
    static newRootScope() { return new qi(null, null); }
    static apply(e) { let t = qi.newRootScope(); return t.ingest(e), t; }
    ingest(e) { e instanceof et ? (e.variables.forEach(t => this.visitVariable(t)), e.children.forEach(t => t.visit(this))) : e instanceof In ? (e.expressionAlias !== null && this.visitVariable(e.expressionAlias), e.children.forEach(t => t.visit(this))) : e instanceof Is ? (this.visitVariable(e.item), e.contextVariables.forEach(t => this.visitVariable(t)), e.children.forEach(t => t.visit(this))) : e instanceof Or || e instanceof Vr || e instanceof zn || e instanceof Fr || e instanceof Mr || e instanceof Rr || e instanceof _s || e instanceof Ns ? e.children.forEach(t => t.visit(this)) : e instanceof Hr || e.forEach(t => t.visit(this)); }
    visitElement(e) { this.visitElementLike(e); }
    visitTemplate(e) { e.directives.forEach(t => t.visit(this)), e.references.forEach(t => this.visitReference(t)), this.ingestScopedNode(e); }
    visitVariable(e) { this.maybeDeclare(e); }
    visitReference(e) { this.maybeDeclare(e); }
    visitDeferredBlock(e) { this.ingestScopedNode(e), e.placeholder?.visit(this), e.loading?.visit(this), e.error?.visit(this); }
    visitDeferredBlockPlaceholder(e) { this.ingestScopedNode(e); }
    visitDeferredBlockError(e) { this.ingestScopedNode(e); }
    visitDeferredBlockLoading(e) { this.ingestScopedNode(e); }
    visitSwitchBlock(e) { e.groups.forEach(t => t.visit(this)); }
    visitSwitchBlockCase(e) { }
    visitSwitchBlockCaseGroup(e) { this.ingestScopedNode(e); }
    visitSwitchExhaustiveCheck(e) { }
    visitForLoopBlock(e) { this.ingestScopedNode(e), e.empty?.visit(this); }
    visitForLoopBlockEmpty(e) { this.ingestScopedNode(e); }
    visitIfBlock(e) { e.branches.forEach(t => t.visit(this)); }
    visitIfBlockBranch(e) { this.ingestScopedNode(e); }
    visitContent(e) { this.ingestScopedNode(e); }
    visitContentBlock(e) { this.ingestScopedNode(e); }
    visitLetDeclaration(e) { this.maybeDeclare(e); }
    visitComponent(e) { this.visitElementLike(e); }
    visitDirective(e) { e.references.forEach(t => this.visitReference(t)); }
    visitBoundAttribute(e) { }
    visitBoundEvent(e) { }
    visitBoundText(e) { }
    visitText(e) { }
    visitTextAttribute(e) { }
    visitIcu(e) { }
    visitDeferredTrigger(e) { }
    visitUnknownBlock(e) { }
    visitElementLike(e) { e.directives.forEach(t => t.visit(this)), e.references.forEach(t => this.visitReference(t)), e.children.forEach(t => t.visit(this)), this.elementLikeInScope.add(e); }
    maybeDeclare(e) { this.namedEntities.has(e.name) || this.namedEntities.set(e.name, e); }
    lookup(e) { return this.namedEntities.has(e) ? this.namedEntities.get(e) : this.parentScope !== null ? this.parentScope.lookup(e) : null; }
    getChildScope(e) { let t = this.childScopes.get(e); if (t === void 0)
        throw new Error(`Assertion error: child scope for ${e} not found`); return t; }
    ingestScopedNode(e) { let t = new qi(this, e); t.ingest(e), this.childScopes.set(e, t); }
}, Kc = class n {
    directiveMatcher;
    foreignMatcher;
    directives;
    foreignComponents;
    eagerDirectives;
    missingDirectives;
    bindings;
    references;
    conflictingHostDirectiveBindings;
    isInDeferBlock = !1;
    constructor(e, t, s, r, i, o, a, c, l) { this.directiveMatcher = e, this.foreignMatcher = t, this.directives = s, this.foreignComponents = r, this.eagerDirectives = i, this.missingDirectives = o, this.bindings = a, this.references = c, this.conflictingHostDirectiveBindings = l; }
    static apply(e, t, s, r, i, o, a, c, l, p) { new n(t, s, r, i, o, a, c, l, p).ingest(e); }
    ingest(e) { e.forEach(t => t.visit(this)); }
    visitElement(e) { this.visitElementOrTemplate(e); }
    visitTemplate(e) { this.visitElementOrTemplate(e); }
    visitDeferredBlock(e) { let t = this.isInDeferBlock; this.isInDeferBlock = !0, e.children.forEach(s => s.visit(this)), this.isInDeferBlock = t, e.placeholder?.visit(this), e.loading?.visit(this), e.error?.visit(this); }
    visitDeferredBlockPlaceholder(e) { e.children.forEach(t => t.visit(this)); }
    visitDeferredBlockError(e) { e.children.forEach(t => t.visit(this)); }
    visitDeferredBlockLoading(e) { e.children.forEach(t => t.visit(this)); }
    visitSwitchBlock(e) { e.groups.forEach(t => t.visit(this)); }
    visitSwitchBlockCase(e) { }
    visitSwitchBlockCaseGroup(e) { e.children.forEach(t => t.visit(this)); }
    visitSwitchExhaustiveCheck(e) { }
    visitForLoopBlock(e) { e.item.visit(this), e.contextVariables.forEach(t => t.visit(this)), e.children.forEach(t => t.visit(this)), e.empty?.visit(this); }
    visitForLoopBlockEmpty(e) { e.children.forEach(t => t.visit(this)); }
    visitIfBlock(e) { e.branches.forEach(t => t.visit(this)); }
    visitIfBlockBranch(e) { e.expressionAlias?.visit(this), e.children.forEach(t => t.visit(this)); }
    visitContent(e) { e.children.forEach(t => t.visit(this)); }
    visitContentBlock(e) { e.children.forEach(t => t.visit(this)); }
    visitComponent(e) { if (this.directiveMatcher instanceof fr) {
        let t = this.directiveMatcher.match(e.componentName);
        t.length > 0 ? this.trackSelectorlessMatchesAndDirectives(e, t) : this.missingDirectives.add(e.componentName);
    } e.directives.forEach(t => t.visit(this)), e.children.forEach(t => t.visit(this)); }
    visitDirective(e) { if (this.directiveMatcher instanceof fr) {
        let t = this.directiveMatcher.match(e.name);
        t.length > 0 ? this.trackSelectorlessMatchesAndDirectives(e, t) : this.missingDirectives.add(e.name);
    } }
    visitElementOrTemplate(e) { let t = []; if (this.directiveMatcher instanceof Hi) {
        let s = kd(e);
        this.directiveMatcher.match(s, (r, i) => t.push(...i)), this.trackSelectorBasedBindingsAndDirectives(e, t);
    }
    else
        e.references.forEach(s => { s.value.trim() === "" && this.references.set(s, e); }); if (this.foreignMatcher && e instanceof wt) {
        let s = this.foreignMatcher.match(e.name);
        if (s.length > 0) {
            if (t.length > 0)
                throw new Error(`Conflict: Element '${e.name}' matches both an Angular directive and a foreign component.`);
            this.foreignComponents.set(e, s[0]);
        }
    } e.directives.forEach(s => s.visit(this)), e.children.forEach(s => s.visit(this)); }
    trackMatchedDirectives(e, t) { if (t.length > 0) {
        let s = this.dedupeAndMergeDirectives(e, t);
        this.directives.set(e, s), this.isInDeferBlock || this.eagerDirectives.push(...s);
    } }
    dedupeAndMergeDirectives(e, t) { if (t.length === 0 || t.every(o => o.matchSource === Vi.Selector))
        return t; let s = new Set, r = new Map, i = new Map; for (let o of t)
        o.matchSource === Vi.Selector ? s.add(o.ref.key) : (r.has(o.ref.key) || r.set(o.ref.key, []), r.get(o.ref.key).push(o)); for (let [o, a] of r.entries()) {
        if (s.has(o))
            continue;
        if (a.length === 1) {
            i.set(o, a[0]);
            continue;
        }
        let c = {}, l = {};
        for (let p of a)
            this.mergeMapping(e, p, "input", c, p.inputs), this.mergeMapping(e, p, "output", l, p.outputs);
        i.set(o, se(E({}, a[0]), { inputs: Go.fromMappedObject(c), outputs: Go.fromMappedObject(l) }));
    } return t.reduce((o, a) => (a.matchSource === Vi.Selector ? o.push(a) : i.has(a.ref.key) && (o.push(i.get(a.ref.key)), i.delete(a.ref.key)), o), []); }
    mergeMapping(e, t, s, r, i) { for (let o of i) {
        let a = r[o.classPropertyName];
        if (!a) {
            r[o.classPropertyName] = o;
            continue;
        }
        if (a.bindingPropertyName === o.bindingPropertyName && a.classPropertyName === o.classPropertyName && a.isSignal === o.isSignal)
            continue;
        this.conflictingHostDirectiveBindings.has(e) || this.conflictingHostDirectiveBindings.set(e, []);
        let c = this.conflictingHostDirectiveBindings.get(e), l = c.find(p => p.directive.ref.key === t.ref.key && p.kind === s && p.classPropertyName === o.classPropertyName);
        l || (l = { directive: t, kind: s, classPropertyName: a.classPropertyName, conflictingAliases: new Set([a.bindingPropertyName]) }, c.push(l)), l.conflictingAliases.add(o.bindingPropertyName);
    } }
    trackSelectorlessMatchesAndDirectives(e, t) { if (t.length === 0)
        return; this.trackMatchedDirectives(e, t); let s = (r, i, o) => { r[o].hasBindingPropertyName(i.name) && this.bindings.set(i, r); }; for (let r of t)
        e.inputs.forEach(i => s(r, i, "inputs")), e.attributes.forEach(i => s(r, i, "inputs")), e.outputs.forEach(i => s(r, i, "outputs")); e.references.forEach(r => this.references.set(r, { directive: t[0], node: e })); }
    trackSelectorBasedBindingsAndDirectives(e, t) { this.trackMatchedDirectives(e, t), e.references.forEach(r => { let i = null; if (r.value.trim() === "")
        i = t.find(o => o.isComponent) || null;
    else if (i = t.find(o => o.exportAs !== null && o.exportAs.some(a => a === r.value)) || null, i === null)
        return; i !== null ? this.references.set(r, { directive: i, node: e }) : this.references.set(r, e); }); let s = (r, i) => { let o = t.find(c => c[i].hasBindingPropertyName(r.name)), a = o !== void 0 ? o : e; this.bindings.set(r, a); }; e.inputs.forEach(r => s(r, "inputs")), e.attributes.forEach(r => s(r, "inputs")), e instanceof et && e.templateAttrs.forEach(r => s(r, "inputs")), e.outputs.forEach(r => s(r, "outputs")); }
    visitVariable(e) { }
    visitReference(e) { }
    visitTextAttribute(e) { }
    visitBoundAttribute(e) { }
    visitBoundEvent(e) { }
    visitBoundAttributeOrEvent(e) { }
    visitText(e) { }
    visitBoundText(e) { }
    visitIcu(e) { }
    visitDeferredTrigger(e) { }
    visitUnknownBlock(e) { }
    visitLetDeclaration(e) { }
}, Xo = class n extends Zc {
    bindings;
    symbols;
    usedPipes;
    eagerPipes;
    deferBlocks;
    nestingLevel;
    scope;
    rootNode;
    level;
    visitNode = e => e.visit(this);
    constructor(e, t, s, r, i, o, a, c, l) { super(), this.bindings = e, this.symbols = t, this.usedPipes = s, this.eagerPipes = r, this.deferBlocks = i, this.nestingLevel = o, this.scope = a, this.rootNode = c, this.level = l; }
    static applyWithScope(e, t, s, r, i, o, a, c) { let l = e instanceof et ? e : null; new n(s, r, o, a, c, i, t, l, 0).ingest(e); }
    ingest(e) { if (e instanceof et)
        e.variables.forEach(this.visitNode), e.children.forEach(this.visitNode), this.nestingLevel.set(e, this.level);
    else if (e instanceof In)
        e.expressionAlias !== null && this.visitNode(e.expressionAlias), e.children.forEach(this.visitNode), this.nestingLevel.set(e, this.level);
    else if (e instanceof Is)
        this.visitNode(e.item), e.contextVariables.forEach(t => this.visitNode(t)), e.trackBy?.visit(this), e.children.forEach(this.visitNode), this.nestingLevel.set(e, this.level);
    else if (e instanceof zn) {
        if (this.scope.rootNode !== e)
            throw new Error(`Assertion error: resolved incorrect scope for deferred block ${e}`);
        this.deferBlocks.push([e, this.scope]), e.children.forEach(t => t.visit(this)), this.nestingLevel.set(e, this.level);
    }
    else
        e instanceof Or || e instanceof Vr || e instanceof Fr || e instanceof Mr || e instanceof Rr || e instanceof _s || e instanceof Ns ? (e.children.forEach(t => t.visit(this)), this.nestingLevel.set(e, this.level)) : e instanceof Hr ? this.nestingLevel.set(e, 0) : e.forEach(this.visitNode); }
    visitTemplate(e) { e.inputs.forEach(this.visitNode), e.outputs.forEach(this.visitNode), e.directives.forEach(this.visitNode), e.templateAttrs.forEach(this.visitNode), e.references.forEach(this.visitNode), this.ingestScopedNode(e); }
    visitVariable(e) { this.rootNode !== null && this.symbols.set(e, this.rootNode); }
    visitReference(e) { this.rootNode !== null && this.symbols.set(e, this.rootNode); }
    visitDeferredBlock(e) { this.ingestScopedNode(e), e.triggers.when?.value.visit(this), e.prefetchTriggers.when?.value.visit(this), e.hydrateTriggers.when?.value.visit(this), e.hydrateTriggers.never?.visit(this), e.placeholder && this.visitNode(e.placeholder), e.loading && this.visitNode(e.loading), e.error && this.visitNode(e.error); }
    visitDeferredBlockPlaceholder(e) { this.ingestScopedNode(e); }
    visitDeferredBlockError(e) { this.ingestScopedNode(e); }
    visitDeferredBlockLoading(e) { this.ingestScopedNode(e); }
    visitSwitchBlockCase(e) { e.expression?.visit(this); }
    visitSwitchBlockCaseGroup(e) { e.cases.forEach(t => t.visit(this)), this.ingestScopedNode(e); }
    visitSwitchExhaustiveCheck(e) { e.expression?.visit(this); }
    visitForLoopBlock(e) { e.expression.visit(this), this.ingestScopedNode(e), e.empty?.visit(this); }
    visitForLoopBlockEmpty(e) { this.ingestScopedNode(e); }
    visitIfBlockBranch(e) { e.expression?.visit(this), this.ingestScopedNode(e); }
    visitContent(e) { this.ingestScopedNode(e); }
    visitContentBlock(e) { this.ingestScopedNode(e); }
    visitLetDeclaration(e) { super.visitLetDeclaration(e), this.rootNode !== null && this.symbols.set(e, this.rootNode); }
    visitPipe(e, t) { return this.usedPipes.add(e.name), this.scope.isDeferred || this.eagerPipes.add(e.name), super.visitPipe(e, t); }
    visitPropertyRead(e, t) { return this.maybeMap(e, e.name), super.visitPropertyRead(e, t); }
    visitSafePropertyRead(e, t) { return this.maybeMap(e, e.name), super.visitSafePropertyRead(e, t); }
    ingestScopedNode(e) { let t = this.scope.getChildScope(e); new n(this.bindings, this.symbols, this.usedPipes, this.eagerPipes, this.deferBlocks, this.nestingLevel, t, e, this.level + 1).ingest(e); }
    maybeMap(e, t) { if (!(e.receiver instanceof Pt))
        return; let s = this.scope.lookup(t); s !== null && this.bindings.set(e, s); }
}, el = class {
    target;
    directives;
    foreignComponents;
    eagerDirectives;
    missingDirectives;
    bindings;
    references;
    exprTargets;
    symbols;
    nestingLevel;
    scopedNodeEntities;
    usedPipes;
    eagerPipes;
    conflictingHostDirectiveBindings;
    deferredBlocks;
    deferredScopes;
    constructor(e, t, s, r, i, o, a, c, l, p, h, d, v, w, y) { this.target = e, this.directives = t, this.foreignComponents = s, this.eagerDirectives = r, this.missingDirectives = i, this.bindings = o, this.references = a, this.exprTargets = c, this.symbols = l, this.nestingLevel = p, this.scopedNodeEntities = h, this.usedPipes = d, this.eagerPipes = v, this.conflictingHostDirectiveBindings = y, this.deferredBlocks = w.map(b => b[0]), this.deferredScopes = new Map(w); }
    getEntitiesInScope(e) { return this.scopedNodeEntities.get(e) ?? new Set; }
    getDirectivesOfNode(e) { return this.directives.get(e) || null; }
    getForeignComponent(e) { return this.foreignComponents.get(e) || null; }
    getReferenceTarget(e) { return this.references.get(e) || null; }
    getConsumerOfBinding(e) { return this.bindings.get(e) || null; }
    getExpressionTarget(e) { return this.exprTargets.get(e) || null; }
    getDefinitionNodeOfSymbol(e) { return this.symbols.get(e) || null; }
    getNestingLevel(e) { return this.nestingLevel.get(e) || 0; }
    getUsedDirectives() { let e = new Set; return this.directives.forEach(t => t.forEach(s => e.add(s))), Array.from(e.values()); }
    getEagerlyUsedDirectives() { let e = new Set(this.eagerDirectives); return Array.from(e.values()); }
    getUsedPipes() { return Array.from(this.usedPipes); }
    getEagerlyUsedPipes() { return Array.from(this.eagerPipes); }
    getDeferBlocks() { return this.deferredBlocks; }
    getDeferredTriggerTarget(e, t) { if (!(t instanceof fo) && !(t instanceof $r) && !(t instanceof ho))
        return null; let s = t.reference; if (s === null) {
        let i = null;
        if (e.placeholder !== null) {
            for (let o of e.placeholder.children)
                if (!(o instanceof An)) {
                    if (i !== null)
                        return null;
                    o instanceof wt && (i = o);
                }
        }
        return i;
    } let r = this.findEntityInScope(e, s); if (r instanceof qr && this.getDefinitionNodeOfSymbol(r) !== e) {
        let i = this.getReferenceTarget(r);
        if (i !== null)
            return this.referenceTargetToElement(i);
    } if (e.placeholder !== null) {
        let i = this.findEntityInScope(e.placeholder, s), o = i instanceof qr ? this.getReferenceTarget(i) : null;
        if (o !== null)
            return this.referenceTargetToElement(o);
    } return null; }
    isDeferred(e) { for (let t of this.deferredBlocks) {
        if (!this.deferredScopes.has(t))
            continue;
        let s = [this.deferredScopes.get(t)];
        for (; s.length > 0;) {
            let r = s.pop();
            if (r.elementLikeInScope.has(e))
                return !0;
            s.push(...r.childScopes.values());
        }
    } return !1; }
    referencedDirectiveExists(e) { return !this.missingDirectives.has(e); }
    getConflictingHostDirectiveBindings(e) { return this.conflictingHostDirectiveBindings.get(e) || null; }
    findEntityInScope(e, t) { let s = this.getEntitiesInScope(e); for (let r of s)
        if (r.name === t)
            return r; return null; }
    referenceTargetToElement(e) { return e instanceof wt ? e : e instanceof et || e.node instanceof sr || e.node instanceof Rp || e.node instanceof Hr ? null : this.referenceTargetToElement(e.node); }
};
function QC(n, e) { let t = new Map; function s(i) { if (t.has(i.rootNode))
    return t.get(i.rootNode); let o = i.namedEntities, a; return i.parentScope !== null ? a = new Map([...s(i.parentScope), ...o]) : a = new Map(o), t.set(i.rootNode, a), a; } let r = [n]; for (; r.length > 0;) {
    let i = r.pop();
    for (let o of i.childScopes.values())
        r.push(o);
    s(i);
} for (let [i, o] of t)
    e.set(i, new Set(o.values())); }
var $s = class {
};
function Sp(n, e) { let t = new jt; return t.set("token", n.type.value), t.set("factory", n.factory === void 0 ? Ya(n.type.value, n.type.value, e) : je([], n.factory.callFn([]))), n.autoProvided === !1 && t.set("autoProvided", g(!1)), { expression: A(f.defineService).callFn([t.toLiteralMap()], void 0, !0), type: Up(n.type.type, n.typeArgumentCount), statements: [] }; }
var tl = class {
    jitEvaluator;
    FactoryTarget = Rt;
    ResourceLoader = $s;
    elementSchemaRegistry = new mn;
    constructor(e = new tc) { this.jitEvaluator = e; }
    compilePipe(e, t, s) { let r = { name: s.name, type: ie(s.type), typeArgumentCount: 0, pipeName: s.pipeName, pure: s.pure, isStandalone: s.isStandalone }, i = su(r); return this.jitExpression(i.expression, e, t, []); }
    compilePipeDeclaration(e, t, s) { let r = f2(s), i = su(r); return this.jitExpression(i.expression, e, t, []); }
    compileInjectable(e, t, s) { let { expression: r, statements: i } = Yl({ name: s.name, type: ie(s.type), typeArgumentCount: s.typeArgumentCount, providedIn: bp(s.providedIn), useClass: os(s, "useClass"), useFactory: Bi(s, "useFactory"), useValue: os(s, "useValue"), useExisting: os(s, "useExisting"), deps: s.deps?.map(rf) }, !0); return this.jitExpression(r, e, t, i); }
    compileInjectableDeclaration(e, t, s) { let { expression: r, statements: i } = Yl({ name: s.type.name, type: ie(s.type), typeArgumentCount: 0, providedIn: bp(s.providedIn), useClass: os(s, "useClass"), useFactory: Bi(s, "useFactory"), useValue: os(s, "useValue"), useExisting: os(s, "useExisting"), deps: s.deps?.map(Ap) }, !0); return this.jitExpression(r, e, t, i); }
    compileInjector(e, t, s) { let r = { type: ie(s.type), providers: s.providers && s.providers.length > 0 ? new q(s.providers) : null, imports: s.imports.map(o => new q(o)) }, i = nu(r); return this.jitExpression(i.expression, e, t, []); }
    compileInjectorDeclaration(e, t, s) { let r = d2(s), i = nu(r); return this.jitExpression(i.expression, e, t, []); }
    compileNgModule(e, t, s) { let r = { kind: at.Global, type: ie(s.type), bootstrap: s.bootstrap.map(ie), declarations: s.declarations.map(ie), publicDeclarationTypes: null, imports: s.imports.map(ie), includeImportTypes: !0, exports: s.exports.map(ie), selectorScopeMode: yo.Inline, containsForwardDecls: !1, schemas: s.schemas ? s.schemas.map(ie) : null, id: s.id ? new q(s.id) : null }, i = jd(r); return this.jitExpression(i.expression, e, t, []); }
    compileNgModuleDeclaration(e, t, s) { let r = zd(s); return this.jitExpression(r, e, t, []); }
    compileDirective(e, t, s) { let r = yp(s); return this.compileDirectiveFromMeta(e, t, r); }
    compileDirectiveDeclaration(e, t, s) { let r = this.createParseSourceSpan("Directive", s.type.name, t), i = nf(s, r); return this.compileDirectiveFromMeta(e, t, i); }
    compileService(e, t, s) { let { expression: r, statements: i } = Sp({ type: ie(s.type), typeArgumentCount: s.typeArgumentCount, autoProvided: s.autoProvided, factory: s.factory ? Bi(s, "factory") : void 0 }, !0); return this.jitExpression(r, e, t, i); }
    compileServiceDeclaration(e, t, s) { let { expression: r, statements: i } = Sp({ type: ie(s.type), typeArgumentCount: 0, autoProvided: s.autoProvided, factory: s.factory ? Bi(s, "factory") : void 0 }, !0); return this.jitExpression(r, e, t, i); }
    compileDirectiveFromMeta(e, t, s) { let r = new Ki, i = zo(), o = $C(s, r, i); return this.jitExpression(o.expression, e, t, r.statements); }
    compileComponent(e, t, s) { let { template: r, defer: i } = sf(s.template, s.name, t, s.preserveWhitespaces, void 0), o = se(E(E({}, s), yp(s)), { selector: s.selector || this.elementSchemaRegistry.getDefaultComponentElementName(), template: r, declarations: s.declarations.map(KC), declarationListEmitMode: 0, defer: i, styles: [...s.styles, ...r.styles], encapsulation: s.encapsulation, changeDetection: s.changeDetection ?? null, animations: s.animations != null ? new q(s.animations) : null, viewProviders: s.viewProviders != null ? new q(s.viewProviders) : null, relativeContextFilePath: "", i18nUseExternalIds: !0, relativeTemplatePath: null, foreignImports: null, enableTemplateSourceLocations: !1 }), a = `ng:///${s.name}.js`; return this.compileComponentFromMeta(e, a, o); }
    compileComponentDeclaration(e, t, s) { let r = this.createParseSourceSpan("Component", s.type.name, t), i = JC(s, r, t); return this.compileComponentFromMeta(e, t, i); }
    compileComponentFromMeta(e, t, s) { let r = new Ki, i = zo(), o = MC(s, r, i); return this.jitExpression(o.expression, e, t, r.statements); }
    compileFactory(e, t, s) { let r = xn({ name: s.name, type: ie(s.type), typeArgumentCount: s.typeArgumentCount, deps: s2(s.deps), target: s.target }); return this.jitExpression(r.expression, e, t, r.statements); }
    compileFactoryDeclaration(e, t, s) { let r = xn({ name: s.type.name, type: ie(s.type), typeArgumentCount: 0, deps: Array.isArray(s.deps) ? s.deps.map(Ap) : s.deps, target: s.target }); return this.jitExpression(r.expression, e, t, r.statements); }
    createParseSourceSpan(e, t, s) { return Fd(e, t, s); }
    jitExpression(e, t, s, r) { let i = [...r, new ve("$def", e, void 0, xe.Exported)]; return this.jitEvaluator.evaluateStatements(s, i, new sc(t), !0).$def; }
};
function Ep(n) { return se(E({}, n), { isSignal: n.isSignal, predicate: tf(n.predicate), read: n.read ? new q(n.read) : null, static: n.static, emitDistinctChangesOnly: n.emitDistinctChangesOnly }); }
function xp(n) { return { propertyName: n.propertyName, first: n.first ?? !1, predicate: tf(n.predicate), descendants: n.descendants ?? !1, read: n.read ? new q(n.read) : null, static: n.static ?? !1, emitDistinctChangesOnly: n.emitDistinctChangesOnly ?? !0, isSignal: !!n.isSignal }; }
function tf(n) { return Array.isArray(n) ? n : ll(new q(n), 1); }
function yp(n) { let e = h2(n.inputs || []), t = ba(n.outputs || []), s = n.propMetadata, r = {}, i = {}; for (let a in s)
    Object.hasOwn(s, a) && s[a].forEach(c => { c2(c) ? r[a] = { bindingPropertyName: c.alias || a, classPropertyName: a, required: c.required || !1, isSignal: !!c.isSignal, transformFunction: c.transform != null ? new q(c.transform) : null } : l2(c) && (i[a] = c.alias || a); }); let o = n.hostDirectives?.length ? n.hostDirectives.map(a => typeof a == "function" ? { directive: ie(a), inputs: null, outputs: null, isForwardReference: !1 } : { directive: ie(a.directive), isForwardReference: !1, inputs: a.inputs ? ba(a.inputs) : null, outputs: a.outputs ? ba(a.outputs) : null }) : null; return se(E({}, n), { typeArgumentCount: 0, typeSourceSpan: n.typeSourceSpan, type: ie(n.type), deps: null, host: E({}, i2(n.propMetadata, n.typeSourceSpan, n.host)), inputs: E(E({}, e), r), outputs: E(E({}, t), i), queries: n.queries.map(Ep), providers: n.providers != null ? new q(n.providers) : null, viewQueries: n.viewQueries.map(Ep), hostDirectives: o }); }
function nf(n, e) { let t = n.hostDirectives?.length ? n.hostDirectives.map(s => ({ directive: ie(s.directive), isForwardReference: !1, inputs: s.inputs ? Cp(s.inputs) : null, outputs: s.outputs ? Cp(s.outputs) : null })) : null; return { name: n.type.name, type: ie(n.type), typeSourceSpan: e, selector: n.selector ?? null, inputs: n.inputs ? u2(n.inputs) : {}, outputs: n.outputs ?? {}, host: YC(n.host), queries: (n.queries ?? []).map(xp), viewQueries: (n.viewQueries ?? []).map(xp), providers: n.providers !== void 0 ? new q(n.providers) : null, exportAs: n.exportAs ?? null, usesInheritance: n.usesInheritance ?? !1, controlCreate: n.controlCreate ?? null, lifecycle: { usesOnChanges: n.usesOnChanges ?? !1 }, deps: null, typeArgumentCount: 0, isStandalone: n.isStandalone ?? Bp(n.version), isSignal: n.isSignal ?? !1, hostDirectives: t, legacyOptionalChaining: n.legacyOptionalChaining ?? Wp }; }
function YC(n = {}) { return { attributes: ZC(n.attributes ?? {}), listeners: n.listeners ?? {}, properties: n.properties ?? {}, specialAttributes: { classAttr: n.classAttribute, styleAttr: n.styleAttribute } }; }
function Cp(n) { let e = null; for (let t = 1; t < n.length; t += 2)
    e = e || {}, e[n[t - 1]] = n[t]; return e; }
function ZC(n) { let e = {}; for (let t of Object.keys(n))
    e[t] = new q(n[t]); return e; }
function JC(n, e, t) { let { template: s, defer: r } = sf(n.template, n.type.name, t, n.preserveWhitespaces ?? !1, n.deferBlockDependencies), i = []; if (n.dependencies)
    for (let a of n.dependencies)
        switch (a.kind) {
            case "directive":
            case "component":
                i.push(Ca(a));
                break;
            case "pipe":
                i.push(t2(a));
                break;
            case "ngmodule":
                i.push(n2(a));
                break;
        }
else
    (n.components || n.directives || n.pipes) && (n.components && i.push(...n.components.map(a => Ca(a, !0))), n.directives && i.push(...n.directives.map(a => Ca(a))), n.pipes && i.push(...e2(n.pipes))); let o = i.some(({ kind: a }) => a === Xn.Directive || a === Xn.NgModule); return se(E({}, nf(n, e)), { template: s, styles: n.styles ?? [], declarations: i, viewProviders: n.viewProviders !== void 0 ? new q(n.viewProviders) : null, animations: n.animations !== void 0 ? new q(n.animations) : null, defer: r, changeDetection: n.changeDetection ?? sl.OnPush, encapsulation: n.encapsulation ?? en.Emulated, declarationListEmitMode: 2, relativeContextFilePath: "", i18nUseExternalIds: !0, relativeTemplatePath: null, hasDirectiveDependencies: o, legacyOptionalChaining: n.legacyOptionalChaining ?? Wp, foreignImports: null, enableTemplateSourceLocations: !1 }); }
function KC(n) { return se(E({}, n), { type: new q(n.type) }); }
function Ca(n, e = null) { return { kind: Xn.Directive, isComponent: e || n.kind === "component", selector: n.selector, type: new q(n.type), inputs: n.inputs ?? [], outputs: n.outputs ?? [], exportAs: n.exportAs ?? null }; }
function e2(n) { return n ? Object.keys(n).map(e => ({ kind: Xn.Pipe, name: e, type: new q(n[e]) })) : []; }
function t2(n) { return { kind: Xn.Pipe, name: n.name, type: new q(n.type) }; }
function n2(n) { return { kind: Xn.NgModule, type: new q(n.type) }; }
function sf(n, e, t, s, r) { let i = DC(n, t, { preserveWhitespaces: s }); if (i.errors !== null) {
    let c = i.errors.map(l => l.toString()).join(", ");
    throw new Error(`Errors during JIT compilation of template for ${e}: ${c}`);
} let a = new Jc(null).bind({ template: i.nodes }); return { template: i, defer: r2(a, r) }; }
function os(n, e) { if (Object.hasOwn(n, e))
    return ll(new q(n[e]), 0); }
function Bi(n, e) { if (Object.hasOwn(n, e))
    return new q(n[e]); }
function bp(n) { let e = typeof n == "function" ? new q(n) : new Ae(n ?? null); return ll(e, 0); }
function s2(n) { return n == null ? null : n.map(rf); }
function rf(n) { let e = n.attribute != null, t = n.token === null ? null : new q(n.token), s = e ? new q(n.attribute) : t; return of(s, e, n.host, n.optional, n.self, n.skipSelf); }
function Ap(n) { let e = n.attribute ?? !1, t = n.token === null ? null : new q(n.token); return of(t, e, n.host ?? !1, n.optional ?? !1, n.self ?? !1, n.skipSelf ?? !1); }
function of(n, e, t, s, r, i) { let o = e ? g("unknown") : null; return { token: n, attributeNameType: o, host: t, optional: s, self: r, skipSelf: i }; }
function r2(n, e) { let t = n.getDeferBlocks(), s = new Map; for (let r = 0; r < t.length; r++) {
    let i = e?.[r];
    s.set(t[r], i ? new q(i) : null);
} return { mode: 0, blocks: s }; }
function i2(n, e, t) {
    let s = UC(t || {});
    for (let i in n)
        Object.hasOwn(n, i) && n[i].forEach(o => { o2(o) ? s.properties[o.hostPropertyName || i] = ld("this", i) : a2(o) && (s.listeners[o.eventName || i] = `${i}(${(o.args || []).join(",")})`); });
    let r = WC(s, e);
    if (r.length)
        throw new Error(r.map(i => i.msg).join(`
`));
    return s;
}
function o2(n) { return n.ngMetadataName === "HostBinding"; }
function a2(n) { return n.ngMetadataName === "HostListener"; }
function c2(n) { return n.ngMetadataName === "Input"; }
function l2(n) { return n.ngMetadataName === "Output"; }
function u2(n) { return Object.keys(n).reduce((e, t) => { let s = n[t]; return typeof s == "string" || Array.isArray(s) ? e[t] = p2(s) : e[t] = { bindingPropertyName: s.publicName, classPropertyName: t, transformFunction: s.transformFunction !== null ? new q(s.transformFunction) : null, required: s.isRequired, isSignal: s.isSignal }, e; }, {}); }
function p2(n) { return typeof n == "string" ? { bindingPropertyName: n, classPropertyName: n, transformFunction: null, required: !1, isSignal: !1 } : { bindingPropertyName: n[0], classPropertyName: n[1], transformFunction: n[2] ? new q(n[2]) : null, required: !1, isSignal: !1 }; }
function h2(n) { return n.reduce((e, t) => { if (typeof t == "string") {
    let [s, r] = af(t);
    e[r] = { bindingPropertyName: s, classPropertyName: r, required: !1, isSignal: !1, transformFunction: null };
}
else
    e[t.name] = { bindingPropertyName: t.alias || t.name, classPropertyName: t.name, required: t.required || !1, isSignal: !1, transformFunction: t.transform != null ? new q(t.transform) : null }; return e; }, {}); }
function ba(n) { return n.reduce((e, t) => { let [s, r] = af(t); return e[r] = s, e; }, {}); }
function af(n) { let [e, t] = n.split(":", 2).map(s => s.trim()); return [t ?? e, e]; }
function f2(n) { return { name: n.type.name, type: ie(n.type), typeArgumentCount: 0, pipeName: n.name, deps: null, pure: n.pure ?? !0, isStandalone: n.isStandalone ?? Bp(n.version) }; }
function d2(n) { return { name: n.type.name, type: ie(n.type), providers: n.providers !== void 0 && n.providers.length > 0 ? new q(n.providers) : null, imports: n.imports !== void 0 ? n.imports.map(e => new q(e)) : [] }; }
function m2(n) { let e = n.ng || (n.ng = {}); e.\u0275compilerFacade = new tl; }
var fi = class {
    defaultEncapsulation;
    preserveWhitespaces;
    strictInjectionParameters;
    constructor({ defaultEncapsulation: e = en.Emulated, preserveWhitespaces: t, strictInjectionParameters: s } = {}) { this.defaultEncapsulation = e, this.preserveWhitespaces = g2(Jf(t)), this.strictInjectionParameters = s === !0; }
};
function g2(n, e = !1) { return n === null ? e : n; }
var nl = class {
    closedByParent = !1;
    implicitNamespacePrefix = null;
    isVoid = !1;
    ignoreFirstLf = !1;
    canSelfClose = !0;
    preventNamespaceInheritance = !1;
    requireExtraParent(e) { return !1; }
    isClosedByChild(e) { return !1; }
    getContentType() { return Ct.PARSABLE_DATA; }
}, z2 = new nl;
var G2 = new Da("22.1.4");
var kp = class n {
    static SINGLETON = new n;
    static veWillInferAnyFor(e) { let t = n.SINGLETON; return e instanceof jn ? e.visit(t) : e.receiver.visit(t); }
    visitUnary(e) { return e.expr.visit(this); }
    visitBinary(e) { return e.left.visit(this) || e.right.visit(this); }
    visitChain() { return !1; }
    visitConditional(e) { return e.condition.visit(this) || e.trueExp.visit(this) || e.falseExp.visit(this); }
    visitCall() { return !0; }
    visitSafeCall() { return !1; }
    visitImplicitReceiver() { return !1; }
    visitThisReceiver() { return !1; }
    visitInterpolation(e) { return e.expressions.some(t => t.visit(this)); }
    visitKeyedRead() { return !1; }
    visitLiteralArray() { return !0; }
    visitLiteralMap() { return !0; }
    visitLiteralPrimitive() { return !1; }
    visitPipe() { return !0; }
    visitPrefixNot(e) { return e.expression.visit(this); }
    visitTypeofExpression(e) { return e.expression.visit(this); }
    visitVoidExpression(e) { return e.expression.visit(this); }
    visitNonNullAssert(e) { return e.expression.visit(this); }
    visitPropertyRead() { return !1; }
    visitSafePropertyRead() { return !1; }
    visitSafeKeyedRead() { return !1; }
    visitTemplateLiteral() { return !1; }
    visitTemplateLiteralElement() { return !1; }
    visitTaggedTemplateLiteral() { return !1; }
    visitParenthesizedExpression(e) { return e.expression.visit(this); }
    visitRegularExpressionLiteral() { return !1; }
    visitSpreadElement(e) { return e.expression.visit(this); }
    visitArrowFunction(e, t) { return !1; }
};
var v2 = ["errors", "dirty", "disabled", "disabledReasons", "hidden", "invalid", "name", "pending", "readonly", "touched", "max", "maxLength", "min", "minLength", "pattern", "required"], X2 = new Set([...v2, "value", "checked"]);
var Q2 = new mn;
var Y2 = new mn;
m2(nr);
import { platformBrowser as C2 } from "@angular/platform-browser";
var sb = new w2("22.1.4"), b2 = [{ provide: Il, useFactory: () => new Il }], Nl = class {
    _defaultOptions;
    constructor(e) { let t = { defaultEncapsulation: S2.Emulated }; this._defaultOptions = [t, ...e]; }
    createCompiler(e = []) { let t = A2(this._defaultOptions.concat(e)); return E2.create({ providers: [b2, { provide: fi, useFactory: () => new fi({ defaultEncapsulation: t.defaultEncapsulation, preserveWhitespaces: t.preserveWhitespaces }), deps: [] }, t.providers] }).get(Il); }
};
function A2(n) { return { defaultEncapsulation: lf(n.map(e => e.defaultEncapsulation)), providers: k2(n.map(e => e.providers)), preserveWhitespaces: lf(n.map(e => e.preserveWhitespaces)) }; }
function lf(n) { for (let e = n.length - 1; e >= 0; e--)
    if (n[e] !== void 0)
        return n[e]; }
function k2(n) { let e = []; return n.forEach(t => t && e.push(...t)), e; }
var T2 = (() => { class n extends $s {
    get(t) { let s, r, i = new Promise((a, c) => { s = a, r = c; }), o = new XMLHttpRequest; return o.open("GET", t, !0), o.responseType = "text", o.onload = function () { let a = o.response, c = o.status; c === 0 && (c = a ? 200 : 0), 200 <= c && c <= 300 ? s(a) : r(`Failed to load ${t}`); }, o.onerror = function () { r(`Failed to load ${t}`); }, o.send(), i; }
    static \u0275fac = (() => { let t; return function (r) { return (t || (t = sa.\u0275\u0275getInheritedFactory(n)))(r || n); }; })();
    static \u0275prov = sa.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac });
} return n; })(), _2 = [{ provide: cf, useValue: { providers: [{ provide: $s, useClass: T2, deps: [] }] }, multi: !0 }, { provide: y2, useClass: Nl, deps: [cf] }], rb = x2(C2, "browserDynamic", _2);
export { Nl as JitCompilerFactory, sb as VERSION, rb as platformBrowserDynamic };
/*! Bundled license information:

@angular/compiler/fesm2022/compiler.mjs:
@angular/platform-browser-dynamic/fesm2022/platform-browser-dynamic.mjs:
  (**
   * @license Angular v22.1.4
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)

@angular/compiler/fesm2022/compiler.mjs:
  (**
   *
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.dev/license
   *)
*/
