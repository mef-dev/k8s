import * as i from "@angular/core";
import { inject as s, PLATFORM_ID as o } from "@angular/core";
import { isPlatformBrowser as n } from "@angular/common";
var e;
try {
    e = typeof Intl < "u" && Intl.v8BreakIterator;
}
catch {
    e = !1;
}
var I = (() => { class t {
    _platformId = s(o);
    isBrowser = this._platformId ? n(this._platformId) : typeof document == "object" && !!document;
    EDGE = this.isBrowser && /(edge)/i.test(navigator.userAgent);
    TRIDENT = this.isBrowser && /(msie|trident)/i.test(navigator.userAgent);
    BLINK = this.isBrowser && !!(window.chrome || e) && typeof CSS < "u" && !this.EDGE && !this.TRIDENT;
    WEBKIT = this.isBrowser && /AppleWebKit/i.test(navigator.userAgent) && !this.BLINK && !this.EDGE && !this.TRIDENT;
    IOS = this.isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent) && !("MSStream" in window);
    FIREFOX = this.isBrowser && /(firefox|minefield)/i.test(navigator.userAgent);
    ANDROID = this.isBrowser && /android/i.test(navigator.userAgent) && !this.TRIDENT;
    SAFARI = this.isBrowser && /safari/i.test(navigator.userAgent) && this.WEBKIT;
    static \u0275fac = function (r) { return new (r || t); };
    static \u0275prov = i.\u0275\u0275defineService({ token: t, factory: t.\u0275fac });
} return t; })();
export { I as a };
