function s(r) { return typeof r == "function"; }
function v(r) { let e = r(i => { Error.call(i), i.stack = new Error().stack; }); return e.prototype = Object.create(Error.prototype), e.prototype.constructor = e, e; }
var m = v(r => function (e) {
    r(this), this.message = e ? `${e.length} errors occurred during unsubscription:
${e.map((i, o) => `${o + 1}) ${i.toString()}`).join(`
  `)}` : "", this.name = "UnsubscriptionError", this.errors = e;
});
function _(r, t) { if (r) {
    let e = r.indexOf(t);
    0 <= e && r.splice(e, 1);
} }
var l = class r {
    constructor(t) { this.initialTeardown = t, this.closed = !1, this._parentage = null, this._finalizers = null; }
    unsubscribe() { let t; if (!this.closed) {
        this.closed = !0;
        let { _parentage: e } = this;
        if (e)
            if (this._parentage = null, Array.isArray(e))
                for (let n of e)
                    n.remove(this);
            else
                e.remove(this);
        let { initialTeardown: i } = this;
        if (s(i))
            try {
                i();
            }
            catch (n) {
                t = n instanceof m ? n.errors : [n];
            }
        let { _finalizers: o } = this;
        if (o) {
            this._finalizers = null;
            for (let n of o)
                try {
                    w(n);
                }
                catch (u) {
                    t = t ?? [], u instanceof m ? t = [...t, ...u.errors] : t.push(u);
                }
        }
        if (t)
            throw new m(t);
    } }
    add(t) { var e; if (t && t !== this)
        if (this.closed)
            w(t);
        else {
            if (t instanceof r) {
                if (t.closed || t._hasParent(this))
                    return;
                t._addParent(this);
            }
            (this._finalizers = (e = this._finalizers) !== null && e !== void 0 ? e : []).push(t);
        } }
    _hasParent(t) { let { _parentage: e } = this; return e === t || Array.isArray(e) && e.includes(t); }
    _addParent(t) { let { _parentage: e } = this; this._parentage = Array.isArray(e) ? (e.push(t), e) : e ? [e, t] : t; }
    _removeParent(t) { let { _parentage: e } = this; e === t ? this._parentage = null : Array.isArray(e) && _(e, t); }
    remove(t) { let { _finalizers: e } = this; e && _(e, t), t instanceof r && t._removeParent(this); }
};
l.EMPTY = (() => { let r = new l; return r.closed = !0, r; })();
var Q = l.EMPTY;
function b(r) { return r instanceof l || r && "closed" in r && s(r.remove) && s(r.add) && s(r.unsubscribe); }
function w(r) { s(r) ? r() : r.unsubscribe(); }
var c = { onUnhandledError: null, onStoppedNotification: null, Promise: void 0, useDeprecatedSynchronousErrorHandling: !1, useDeprecatedNextContext: !1 };
var f = { setTimeout(r, t, ...e) { let { delegate: i } = f; return i?.setTimeout ? i.setTimeout(r, t, ...e) : setTimeout(r, t, ...e); }, clearTimeout(r) { let { delegate: t } = f; return (t?.clearTimeout || clearTimeout)(r); }, delegate: void 0 };
function A(r) { f.setTimeout(() => { let { onUnhandledError: t } = c; if (t)
    t(r);
else
    throw r; }); }
function y() { }
var F = E("C", void 0, void 0);
function U(r) { return E("E", void 0, r); }
function I(r) { return E("N", r, void 0); }
function E(r, t, e) { return { kind: r, value: t, error: e }; }
var p = null;
function z(r) { if (c.useDeprecatedSynchronousErrorHandling) {
    let t = !p;
    if (t && (p = { errorThrown: !1, error: null }), r(), t) {
        let { errorThrown: e, error: i } = p;
        if (p = null, e)
            throw i;
    }
}
else
    r(); }
function C(r) { c.useDeprecatedSynchronousErrorHandling && p && (p.errorThrown = !0, p.error = r); }
var d = class extends l {
    constructor(t) { super(), this.isStopped = !1, t ? (this.destination = t, b(t) && t.add(this)) : this.destination = j; }
    static create(t, e, i) { return new a(t, e, i); }
    next(t) { this.isStopped ? g(I(t), this) : this._next(t); }
    error(t) { this.isStopped ? g(U(t), this) : (this.isStopped = !0, this._error(t)); }
    complete() { this.isStopped ? g(F, this) : (this.isStopped = !0, this._complete()); }
    unsubscribe() { this.closed || (this.isStopped = !0, super.unsubscribe(), this.destination = null); }
    _next(t) { this.destination.next(t); }
    _error(t) { try {
        this.destination.error(t);
    }
    finally {
        this.unsubscribe();
    } }
    _complete() { try {
        this.destination.complete();
    }
    finally {
        this.unsubscribe();
    } }
}, Y = Function.prototype.bind;
function S(r, t) { return Y.call(r, t); }
var T = class {
    constructor(t) { this.partialObserver = t; }
    next(t) { let { partialObserver: e } = this; if (e.next)
        try {
            e.next(t);
        }
        catch (i) {
            x(i);
        } }
    error(t) { let { partialObserver: e } = this; if (e.error)
        try {
            e.error(t);
        }
        catch (i) {
            x(i);
        }
    else
        x(t); }
    complete() { let { partialObserver: t } = this; if (t.complete)
        try {
            t.complete();
        }
        catch (e) {
            x(e);
        } }
}, a = class extends d {
    constructor(t, e, i) { super(); let o; if (s(t) || !t)
        o = { next: t ?? void 0, error: e ?? void 0, complete: i ?? void 0 };
    else {
        let n;
        this && c.useDeprecatedNextContext ? (n = Object.create(t), n.unsubscribe = () => this.unsubscribe(), o = { next: t.next && S(t.next, n), error: t.error && S(t.error, n), complete: t.complete && S(t.complete, n) }) : o = t;
    } this.destination = new T(o); }
};
function x(r) { c.useDeprecatedSynchronousErrorHandling ? C(r) : A(r); }
function $(r) { throw r; }
function g(r, t) { let { onStoppedNotification: e } = c; e && f.setTimeout(() => e(r, t)); }
var j = { closed: !0, next: y, error: $, complete: y };
var D = typeof Symbol == "function" && Symbol.observable || "@@observable";
function M(r) { return r; }
function yt(...r) { return P(r); }
function P(r) { return r.length === 0 ? M : r.length === 1 ? r[0] : function (e) { return r.reduce((i, o) => o(i), e); }; }
var h = class r {
    constructor(t) { t && (this._subscribe = t); }
    lift(t) { let e = new r; return e.source = this, e.operator = t, e; }
    subscribe(t, e, i) { let o = L(t) ? t : new a(t, e, i); return z(() => { let { operator: n, source: u } = this; o.add(n ? n.call(o, u) : u ? this._subscribe(o) : this._trySubscribe(o)); }), o; }
    _trySubscribe(t) { try {
        return this._subscribe(t);
    }
    catch (e) {
        t.error(e);
    } }
    forEach(t, e) { return e = R(e), new e((i, o) => { let n = new a({ next: u => { try {
            t(u);
        }
        catch (H) {
            o(H), n.unsubscribe();
        } }, error: o, complete: i }); this.subscribe(n); }); }
    _subscribe(t) { var e; return (e = this.source) === null || e === void 0 ? void 0 : e.subscribe(t); }
    [D]() { return this; }
    pipe(...t) { return P(t)(this); }
    toPromise(t) { return t = R(t), new t((e, i) => { let o; this.subscribe(n => o = n, n => i(n), () => e(o)); }); }
};
h.create = r => new h(r);
function R(r) { var t; return (t = r ?? c.Promise) !== null && t !== void 0 ? t : Promise; }
function B(r) { return r && s(r.next) && s(r.error) && s(r.complete); }
function L(r) { return r && r instanceof d || B(r) && b(r); }
function zt(r, t) { let e = s(r) ? r : () => r, i = o => o.error(e()); return new h(t ? o => t.schedule(i, 0, o) : i); }
export { s as a, v as b, m as c, _ as d, l as e, Q as f, c as g, A as h, y as i, z as j, d as k, a as l, D as m, M as n, yt as o, h as p, zt as q };
