import { a as F, b as m, c as ee } from "@nf-internal/chunk-LHGMZEPY";
import { a as L, b as B, c as K, d as U, e as j, f as Y, g as $, h as A, i as z, j as E, k as C, l as G, m as V, n as H, o as Z, p as q, q as Q, r as X, s as J, t as W } from "@nf-internal/chunk-N333EIGN";
import "@nf-internal/chunk-7NZLVDTY";
import "@nf-internal/chunk-FZNAMQAG";
import "@nf-internal/chunk-PACPXHXL";
import { a as P, b as w } from "@nf-internal/chunk-TT7XXVKE";
import { a as b } from "@nf-internal/chunk-P7VGBIY2";
import { a as y } from "@nf-internal/chunk-DQ6Z6NC4";
import "@nf-internal/chunk-PGIYYMTQ";
import { a as N } from "@nf-internal/chunk-DG2NPXAW";
import "@nf-internal/chunk-XID2BBVI";
import "@nf-internal/chunk-MQ6KVUBG";
import "@nf-internal/chunk-VJYBASWG";
import "@nf-internal/chunk-2NFLSA4Y";
var l = class extends m {
    setActiveItem(i) { this.activeItem && this.activeItem.setInactiveStyles(), super.setActiveItem(i), this.activeItem && this.activeItem.setActiveStyles(); }
};
import * as h from "@angular/core";
import { inject as a, DOCUMENT as T, APP_ID as de, InjectionToken as _e, NgZone as he, Injector as me } from "@angular/core";
import { Subject as le } from "rxjs";
import { InjectionToken as se, QueryList as re } from "@angular/core";
import { Subscription as ne, isObservable as ae, Subject as oe, of as ce } from "rxjs";
import { take as k } from "rxjs/operators";
import { isObservable as te, of as ie } from "rxjs";
function u(r) { return te(r) ? r : ie(r); }
var c = class {
    _activeItemIndex = -1;
    _activeItem = null;
    _shouldActivationFollowFocus = !1;
    _horizontalOrientation = "ltr";
    _skipPredicateFn = i => !1;
    _trackByFn = i => i;
    _items = [];
    _typeahead;
    _typeaheadSubscription = ne.EMPTY;
    _hasInitialFocused = !1;
    _initializeFocus() { if (this._hasInitialFocused || this._items.length === 0)
        return; let i = 0; for (let t = 0; t < this._items.length; t++)
        if (!this._skipPredicateFn(this._items[t]) && !this._isItemDisabled(this._items[t])) {
            i = t;
            break;
        } let e = this._items[i]; e.makeFocusable ? (this._activeItem?.unfocus(), this._activeItemIndex = i, this._activeItem = e, this._typeahead?.setCurrentSelectedItemIndex(i), e.makeFocusable()) : this.focusItem(i), this._hasInitialFocused = !0; }
    constructor(i, e) { i instanceof re ? (this._items = i.toArray(), i.changes.subscribe(t => this._itemsChanged(t.toArray()))) : ae(i) ? i.subscribe(t => this._itemsChanged(t)) : (this._items = i, this._initializeFocus()), typeof e.shouldActivationFollowFocus == "boolean" && (this._shouldActivationFollowFocus = e.shouldActivationFollowFocus), e.horizontalOrientation && (this._horizontalOrientation = e.horizontalOrientation), e.skipPredicate && (this._skipPredicateFn = e.skipPredicate), e.trackBy && (this._trackByFn = e.trackBy), typeof e.typeAheadDebounceInterval < "u" && this._setTypeAhead(e.typeAheadDebounceInterval); }
    change = new oe;
    destroy() { this._typeaheadSubscription.unsubscribe(), this._typeahead?.destroy(), this.change.complete(); }
    onKeydown(i) { switch (i.key) {
        case "Tab": return;
        case "ArrowDown":
            this._focusNextItem();
            break;
        case "ArrowUp":
            this._focusPreviousItem();
            break;
        case "ArrowRight":
            this._horizontalOrientation === "rtl" ? this._collapseCurrentItem() : this._expandCurrentItem();
            break;
        case "ArrowLeft":
            this._horizontalOrientation === "rtl" ? this._expandCurrentItem() : this._collapseCurrentItem();
            break;
        case "Home":
            this._focusFirstItem();
            break;
        case "End":
            this._focusLastItem();
            break;
        case "Enter":
        case " ":
            this._activateCurrentItem();
            break;
        default:
            if (i.key === "*") {
                this._expandAllItemsAtCurrentItemLevel();
                break;
            }
            this._typeahead?.handleKey(i);
            return;
    } this._typeahead?.reset(), i.preventDefault(); }
    getActiveItemIndex() { return this._activeItemIndex; }
    getActiveItem() { return this._activeItem; }
    _itemsChanged(i) { this._hasInitialFocused && this._activeItem && !i.includes(this._activeItem) && (this._activeItem = null, this._hasInitialFocused = !1), this._items = i, this._typeahead?.setItems(this._items), this._updateActiveItemIndex(this._items), this._initializeFocus(); }
    _focusFirstItem() { this.focusItem(this._findNextAvailableItemIndex(-1)); }
    _focusLastItem() { this.focusItem(this._findPreviousAvailableItemIndex(this._items.length)); }
    _focusNextItem() { this.focusItem(this._findNextAvailableItemIndex(this._activeItemIndex)); }
    _focusPreviousItem() { this.focusItem(this._findPreviousAvailableItemIndex(this._activeItemIndex)); }
    focusItem(i, e = {}) { e.emitChangeEvent ??= !0; let t = typeof i == "number" ? i : this._items.findIndex(o => this._trackByFn(o) === this._trackByFn(i)); if (t < 0 || t >= this._items.length)
        return; let s = this._items[t]; if (this._activeItem !== null && this._trackByFn(s) === this._trackByFn(this._activeItem))
        return; let n = this._activeItem; this._activeItem = s ?? null, this._activeItemIndex = t, this._typeahead?.setCurrentSelectedItemIndex(t), this._activeItem?.focus(), n?.unfocus(), e.emitChangeEvent && this.change.next(this._activeItem), this._shouldActivationFollowFocus && this._activateCurrentItem(); }
    _updateActiveItemIndex(i) { let e = this._activeItem; if (!e)
        return; let t = i.findIndex(s => this._trackByFn(s) === this._trackByFn(e)); t > -1 && t !== this._activeItemIndex && (this._activeItemIndex = t, this._typeahead?.setCurrentSelectedItemIndex(t)); }
    _setTypeAhead(i) { this._typeahead = new F(this._items, { debounceInterval: typeof i == "number" ? i : void 0, skipPredicate: e => this._skipPredicateFn(e) }), this._typeaheadSubscription = this._typeahead.selectedItem.subscribe(e => { this.focusItem(e); }); }
    _findNextAvailableItemIndex(i) { for (let e = i + 1; e < this._items.length; e++)
        if (!this._skipPredicateFn(this._items[e]))
            return e; return i; }
    _findPreviousAvailableItemIndex(i) { for (let e = i - 1; e >= 0; e--)
        if (!this._skipPredicateFn(this._items[e]))
            return e; return i; }
    _collapseCurrentItem() { if (this._activeItem)
        if (this._isCurrentItemExpanded())
            this._activeItem.collapse();
        else {
            let i = this._activeItem.getParent();
            if (!i || this._skipPredicateFn(i))
                return;
            this.focusItem(i);
        } }
    _expandCurrentItem() { this._activeItem && (this._isCurrentItemExpanded() ? u(this._activeItem.getChildren()).pipe(k(1)).subscribe(i => { let e = i.find(t => !this._skipPredicateFn(t)); e && this.focusItem(e); }) : this._activeItem.expand()); }
    _isCurrentItemExpanded() { return this._activeItem ? typeof this._activeItem.isExpanded == "boolean" ? this._activeItem.isExpanded : this._activeItem.isExpanded() : !1; }
    _isItemDisabled(i) { return typeof i.isDisabled == "boolean" ? i.isDisabled : i.isDisabled?.(); }
    _expandAllItemsAtCurrentItemLevel() { if (!this._activeItem)
        return; let i = this._activeItem.getParent(), e; i ? e = u(i.getChildren()) : e = ce(this._items.filter(t => t.getParent() === null)), e.pipe(k(1)).subscribe(t => { for (let s of t)
        s.expand(); }); }
    _activateCurrentItem() { this._activeItem?.activate(); }
}, x = new se("tree-key-manager", { providedIn: "root", factory: () => (r, i) => new c(r, i) });
import "rxjs/operators";
import "@angular/platform-browser";
import "@angular/common";
var R = " ";
function ue(r, i, e) { let t = _(r, i); e = e.trim(), !t.some(s => s.trim() === e) && (t.push(e), r.setAttribute(i, t.join(R))); }
function fe(r, i, e) { let t = _(r, i); e = e.trim(); let s = t.filter(n => n !== e); s.length ? r.setAttribute(i, s.join(R)) : r.removeAttribute(i); }
function _(r, i) { return r.getAttribute(i)?.match(/\S+/g) ?? []; }
var D = "cdk-describedby-message", d = "cdk-describedby-host", I = 0, Ke = (() => { class r {
    _platform = a(y);
    _document = a(T);
    _messageRegistry = new Map;
    _messagesContainer = null;
    _id = `${I++}`;
    constructor() { a(b).load(A), this._id = a(de) + "-" + I++; }
    describe(e, t, s) { if (!this._canBeDescribed(e, t))
        return; let n = f(t, s); typeof t != "string" ? (M(t, this._id), this._messageRegistry.set(n, { messageElement: t, referenceCount: 0 })) : this._messageRegistry.has(n) || this._createMessageElement(t, s), this._isElementDescribedByMessage(e, n) || this._addMessageReference(e, n); }
    removeDescription(e, t, s) { if (!t || !this._isElementNode(e))
        return; let n = f(t, s); if (this._isElementDescribedByMessage(e, n) && this._removeMessageReference(e, n), typeof t == "string") {
        let o = this._messageRegistry.get(n);
        o && o.referenceCount === 0 && this._deleteMessageElement(n);
    } this._messagesContainer?.childNodes.length === 0 && (this._messagesContainer.remove(), this._messagesContainer = null); }
    ngOnDestroy() { let e = this._document.querySelectorAll(`[${d}="${this._id}"]`); for (let t = 0; t < e.length; t++)
        this._removeCdkDescribedByReferenceIds(e[t]), e[t].removeAttribute(d); this._messagesContainer?.remove(), this._messagesContainer = null, this._messageRegistry.clear(); }
    _createMessageElement(e, t) { let s = this._document.createElement("div"); M(s, this._id), s.textContent = e, t && s.setAttribute("role", t), this._createMessagesContainer(), this._messagesContainer.appendChild(s), this._messageRegistry.set(f(e, t), { messageElement: s, referenceCount: 0 }); }
    _deleteMessageElement(e) { this._messageRegistry.get(e)?.messageElement?.remove(), this._messageRegistry.delete(e); }
    _createMessagesContainer() { if (this._messagesContainer)
        return; let e = "cdk-describedby-message-container", t = this._document.querySelectorAll(`.${e}[platform="server"]`); for (let n = 0; n < t.length; n++)
        t[n].remove(); let s = this._document.createElement("div"); s.style.visibility = "hidden", s.classList.add(e), s.classList.add("cdk-visually-hidden"), this._platform.isBrowser || s.setAttribute("platform", "server"), this._document.body.appendChild(s), this._messagesContainer = s; }
    _removeCdkDescribedByReferenceIds(e) { let t = _(e, "aria-describedby").filter(s => s.indexOf(D) != 0); e.setAttribute("aria-describedby", t.join(" ")); }
    _addMessageReference(e, t) { let s = this._messageRegistry.get(t); ue(e, "aria-describedby", s.messageElement.id), e.setAttribute(d, this._id), s.referenceCount++; }
    _removeMessageReference(e, t) { let s = this._messageRegistry.get(t); s.referenceCount--, fe(e, "aria-describedby", s.messageElement.id), e.removeAttribute(d); }
    _isElementDescribedByMessage(e, t) { let s = _(e, "aria-describedby"), n = this._messageRegistry.get(t), o = n && n.messageElement.id; return !!o && s.indexOf(o) != -1; }
    _canBeDescribed(e, t) { if (!this._isElementNode(e))
        return !1; if (t && typeof t == "object")
        return !0; let s = t == null ? "" : `${t}`.trim(), n = e.getAttribute("aria-label"); return s ? !n || n.trim() !== s : !1; }
    _isElementNode(e) { return e.nodeType === this._document.ELEMENT_NODE; }
    static \u0275fac = function (t) { return new (t || r); };
    static \u0275prov = h.\u0275\u0275defineService({ token: r, factory: r.\u0275fac });
} return r; })();
function f(r, i) { return typeof r == "string" ? `${i || ""}/${r}` : r; }
function M(r, i) { r.id || (r.id = `${D}-${i}-${I++}`); }
var p = class {
    _isNoopTreeKeyManager = !0;
    change = new le;
    destroy() { this.change.complete(); }
    onKeydown() { }
    getActiveItemIndex() { return null; }
    getActiveItem() { return null; }
    focusItem() { }
}, Ue = { provide: x, useFactory: () => () => new p }, g = class extends C {
    _focusTrapManager;
    _inertStrategy;
    get enabled() { return this._enabled; }
    set enabled(i) { this._enabled = i, this._enabled ? this._focusTrapManager.register(this) : this._focusTrapManager.deregister(this); }
    constructor(i, e, t, s, n, o, S, O) { super(i, e, t, s, S.defer, O), this._focusTrapManager = n, this._inertStrategy = o, this._focusTrapManager.register(this); }
    destroy() { this._focusTrapManager.deregister(this), super.destroy(); }
    _enable() { this._inertStrategy.preventFocus(this), this.toggleAnchors(!0); }
    _disable() { this._inertStrategy.allowFocus(this), this.toggleAnchors(!1); }
}, v = class {
    _listener = null;
    preventFocus(i) { this._listener && i._document.removeEventListener("focus", this._listener, !0), this._listener = e => this._trapFocus(i, e), i._ngZone.runOutsideAngular(() => { i._document.addEventListener("focus", this._listener, !0); }); }
    allowFocus(i) { this._listener && (i._document.removeEventListener("focus", this._listener, !0), this._listener = null); }
    _trapFocus(i, e) { let t = e.target, s = i._element; t && !s.contains(t) && !t.closest?.("div.cdk-overlay-pane") && setTimeout(() => { i.enabled && !s.contains(i._document.activeElement) && i.focusFirstTabbableElement(); }); }
}, Ie = new _e("FOCUS_TRAP_INERT_STRATEGY"), pe = (() => { class r {
    _focusTrapStack = [];
    register(e) { this._focusTrapStack = this._focusTrapStack.filter(s => s !== e); let t = this._focusTrapStack; t.length && t[t.length - 1]._disable(), t.push(e), e._enable(); }
    deregister(e) { e._disable(); let t = this._focusTrapStack, s = t.indexOf(e); s !== -1 && (t.splice(s, 1), t.length && t[t.length - 1]._enable()); }
    static \u0275fac = function (t) { return new (t || r); };
    static \u0275prov = h.\u0275\u0275defineService({ token: r, factory: r.\u0275fac });
} return r; })(), je = (() => { class r {
    _checker = a(E);
    _ngZone = a(he);
    _focusTrapManager = a(pe);
    _document = a(T);
    _inertStrategy;
    _injector = a(me);
    constructor() { let e = a(Ie, { optional: !0 }); this._inertStrategy = e || new v; }
    create(e, t = { defer: !1 }) { return new g(e, this._checker, this._ngZone, this._document, this._focusTrapManager, this._inertStrategy, t, this._injector); }
    static \u0275fac = function (t) { return new (t || r); };
    static \u0275prov = h.\u0275\u0275defineService({ token: r, factory: r.\u0275fac });
} return r; })();
export { W as A11yModule, l as ActiveDescendantKeyManager, Ke as AriaDescriber, Q as CdkAriaLive, $ as CdkMonitorFocus, V as CdkTrapFocus, g as ConfigurableFocusTrap, je as ConfigurableFocusTrapFactory, v as EventListenerFocusTrapInertStrategy, j as FOCUS_MONITOR_DEFAULT_OPTIONS, Ie as FOCUS_TRAP_INERT_STRATEGY, ee as FocusKeyManager, Y as FocusMonitor, U as FocusMonitorDetectionMode, C as FocusTrap, G as FocusTrapFactory, X as HighContrastMode, J as HighContrastModeDetector, B as INPUT_MODALITY_DETECTOR_DEFAULT_OPTIONS, L as INPUT_MODALITY_DETECTOR_OPTIONS, K as InputModalityDetector, E as InteractivityChecker, z as IsFocusableConfig, Z as LIVE_ANNOUNCER_DEFAULT_OPTIONS, H as LIVE_ANNOUNCER_ELEMENT_TOKEN, m as ListKeyManager, q as LiveAnnouncer, Ue as NOOP_TREE_KEY_MANAGER_FACTORY_PROVIDER, p as NoopTreeKeyManager, x as TREE_KEY_MANAGER, c as TreeKeyManager, N as _IdGenerator, ue as addAriaReferencedId, _ as getAriaReferenceIds, P as isFakeMousedownFromScreenReader, w as isFakeTouchstartFromScreenReader, fe as removeAriaReferencedId };
