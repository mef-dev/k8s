import { H as D, M as L, c as u, ja as M, lb as d, m as f, n as y, o as v, p as A, q as g, r as b, s as x, t as w, y as k } from "@nf-internal/chunk-VJYBASWG";
import { Subject as o } from "rxjs";
import { tap as P, debounceTime as E, filter as K, map as S } from "rxjs/operators";
var C = 200, n = class {
    _letterKeyStream = new o;
    _items = [];
    _selectedItemIndex = -1;
    _pressedLetters = [];
    _skipPredicateFn;
    _selectedItem = new o;
    selectedItem = this._selectedItem;
    constructor(e, t) { let i = typeof t?.debounceInterval == "number" ? t.debounceInterval : C; t?.skipPredicate && (this._skipPredicateFn = t.skipPredicate), this.setItems(e), this._setupKeyHandler(i); }
    destroy() { this._pressedLetters = [], this._letterKeyStream.complete(), this._selectedItem.complete(); }
    setCurrentSelectedItemIndex(e) { this._selectedItemIndex = e; }
    setItems(e) { this._items = e; }
    handleKey(e) { let t = e.keyCode; e.key && e.key.length === 1 ? this._letterKeyStream.next(e.key.toLocaleUpperCase()) : (t >= 65 && t <= 90 || t >= 48 && t <= 57) && this._letterKeyStream.next(String.fromCharCode(t)); }
    isTyping() { return this._pressedLetters.length > 0; }
    reset() { this._pressedLetters = []; }
    _setupKeyHandler(e) { this._letterKeyStream.pipe(P(t => this._pressedLetters.push(t)), E(e), K(() => this._pressedLetters.length > 0), S(() => this._pressedLetters.join("").toLocaleUpperCase())).subscribe(t => { for (let i = 1; i < this._items.length + 1; i++) {
        let s = (this._selectedItemIndex + i) % this._items.length, r = this._items[s];
        if (!this._skipPredicateFn?.(r) && r.getLabel?.().toLocaleUpperCase().trim().indexOf(t) === 0) {
            this._selectedItem.next(r);
            break;
        }
    } this._pressedLetters = []; }); }
};
import { signal as m, QueryList as _, isSignal as l, effect as O } from "@angular/core";
import { Subscription as R, Subject as I } from "rxjs";
var a = class {
    _items;
    _activeItemIndex = m(-1);
    _activeItem = m(null);
    _wrap = !1;
    _typeaheadSubscription = R.EMPTY;
    _itemChangesSubscription;
    _vertical = !0;
    _horizontal = null;
    _allowedModifierKeys = [];
    _homeAndEnd = !1;
    _pageUpAndDown = { enabled: !1, delta: 10 };
    _effectRef;
    _typeahead;
    _skipPredicateFn = e => e.disabled;
    constructor(e, t) { this._items = e, e instanceof _ ? this._itemChangesSubscription = e.changes.subscribe(i => this._itemsChanged(i.toArray())) : l(e) && (this._effectRef = O(() => this._itemsChanged(e()), { injector: t })); }
    tabOut = new I;
    change = new I;
    skipPredicate(e) { return this._skipPredicateFn = e, this; }
    withWrap(e = !0) { return this._wrap = e, this; }
    withVerticalOrientation(e = !0) { return this._vertical = e, this; }
    withHorizontalOrientation(e) { return this._horizontal = e, this; }
    withAllowedModifierKeys(e) { return this._allowedModifierKeys = e, this; }
    withTypeAhead(e = 200) { this._typeaheadSubscription.unsubscribe(); let t = this._getItemsArray(); return this._typeahead = new n(t, { debounceInterval: typeof e == "number" ? e : void 0, skipPredicate: i => this._skipPredicateFn(i) }), this._typeaheadSubscription = this._typeahead.selectedItem.subscribe(i => { this.setActiveItem(i); }), this; }
    cancelTypeahead() { return this._typeahead?.reset(), this; }
    withHomeAndEnd(e = !0) { return this._homeAndEnd = e, this; }
    withPageUpDown(e = !0, t = 10) { return this._pageUpAndDown = { enabled: e, delta: t }, this; }
    setActiveItem(e) { let t = this._activeItem(); this.updateActiveItem(e), this._activeItem() !== t && this.change.next(this._activeItemIndex()); }
    onKeydown(e) { let t = e.keyCode, s = ["altKey", "ctrlKey", "metaKey", "shiftKey"].every(r => !e[r] || this._allowedModifierKeys.indexOf(r) > -1); switch (t) {
        case 9:
            this.tabOut.next();
            return;
        case 40: if (this._vertical && s) {
            this.setNextItemActive();
            break;
        }
        else
            return;
        case 38: if (this._vertical && s) {
            this.setPreviousItemActive();
            break;
        }
        else
            return;
        case 39: if (this._horizontal && s) {
            this._horizontal === "rtl" ? this.setPreviousItemActive() : this.setNextItemActive();
            break;
        }
        else
            return;
        case 37: if (this._horizontal && s) {
            this._horizontal === "rtl" ? this.setNextItemActive() : this.setPreviousItemActive();
            break;
        }
        else
            return;
        case 36: if (this._homeAndEnd && s) {
            this.setFirstItemActive();
            break;
        }
        else
            return;
        case 35: if (this._homeAndEnd && s) {
            this.setLastItemActive();
            break;
        }
        else
            return;
        case 33: if (this._pageUpAndDown.enabled && s) {
            let r = this._activeItemIndex() - this._pageUpAndDown.delta;
            this._setActiveItemByIndex(r > 0 ? r : 0, 1);
            break;
        }
        else
            return;
        case 34: if (this._pageUpAndDown.enabled && s) {
            let r = this._activeItemIndex() + this._pageUpAndDown.delta, c = this._getItemsArray().length;
            this._setActiveItemByIndex(r < c ? r : c - 1, -1);
            break;
        }
        else
            return;
        default:
            (s || d(e, "shiftKey")) && this._typeahead?.handleKey(e);
            return;
    } this._typeahead?.reset(), e.preventDefault(); }
    get activeItemIndex() { return this._activeItemIndex(); }
    get activeItem() { return this._activeItem(); }
    isTyping() { return !!this._typeahead && this._typeahead.isTyping(); }
    setFirstItemActive() { this._setActiveItemByIndex(0, 1); }
    setLastItemActive() { this._setActiveItemByIndex(this._getItemsArray().length - 1, -1); }
    setNextItemActive() { this._activeItemIndex() < 0 ? this.setFirstItemActive() : this._setActiveItemByDelta(1); }
    setPreviousItemActive() { this._activeItemIndex() < 0 && this._wrap ? this.setLastItemActive() : this._setActiveItemByDelta(-1); }
    updateActiveItem(e) { let t = this._getItemsArray(), i = typeof e == "number" ? e : t.indexOf(e), s = t[i]; this._activeItem.set(s ?? null), this._activeItemIndex.set(i), this._typeahead?.setCurrentSelectedItemIndex(i); }
    destroy() { this._typeaheadSubscription.unsubscribe(), this._itemChangesSubscription?.unsubscribe(), this._effectRef?.destroy(), this._typeahead?.destroy(), this.tabOut.complete(), this.change.complete(); }
    _setActiveItemByDelta(e) { this._wrap ? this._setActiveInWrapMode(e) : this._setActiveInDefaultMode(e); }
    _setActiveInWrapMode(e) { let t = this._getItemsArray(); for (let i = 1; i <= t.length; i++) {
        let s = (this._activeItemIndex() + e * i + t.length) % t.length, r = t[s];
        if (!this._skipPredicateFn(r)) {
            this.setActiveItem(s);
            return;
        }
    } }
    _setActiveInDefaultMode(e) { this._setActiveItemByIndex(this._activeItemIndex() + e, e); }
    _setActiveItemByIndex(e, t) { let i = this._getItemsArray(); if (i[e]) {
        for (; this._skipPredicateFn(i[e]);)
            if (e += t, !i[e])
                return;
        this.setActiveItem(e);
    } }
    _getItemsArray() { return l(this._items) ? this._items() : this._items instanceof _ ? this._items.toArray() : this._items; }
    _itemsChanged(e) { this._typeahead?.setItems(e); let t = this._activeItem(); if (t) {
        let i = e.indexOf(t);
        i > -1 && i !== this._activeItemIndex() && (this._activeItemIndex.set(i), this._typeahead?.setCurrentSelectedItemIndex(i));
    } }
};
var p = class extends a {
    _origin = "program";
    setFocusOrigin(e) { return this._origin = e, this; }
    setActiveItem(e) { super.setActiveItem(e), this.activeItem && this.activeItem.focus(this._origin); }
};
export { n as a, a as b, p as c };
