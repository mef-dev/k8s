import { A as W, B as j, C as B, D as G, E as K, F as U, G as Y, a as f, b as C, c as _, d as y, e as E, f as O, g, h, i as F, j as v, k as N, l as k, m as D, n as b, o as P, p as V, q as R, r as l, s as A, t as w, u as x, v as L, w as T, x as z, y as I, z as M } from "@nf-internal/chunk-L7XPOLJ6";
import "@nf-internal/chunk-RECHUXGF";
import "@nf-internal/chunk-ALR2ABW3";
import "@nf-internal/chunk-JE6VEUSL";
import { d as i, f as a, g as c, i as s, m as u, n as m, o as S, p as d, q as p } from "@nf-internal/chunk-JP7U7NO6";
import "@nf-internal/chunk-FVDLKYOC";
import "@nf-internal/chunk-P7VGBIY2";
import "@nf-internal/chunk-DQ6Z6NC4";
import "@nf-internal/chunk-PGIYYMTQ";
import "@nf-internal/chunk-DG2NPXAW";
import { c as o } from "@nf-internal/chunk-T23P62JN";
import "@nf-internal/chunk-XID2BBVI";
import "@nf-internal/chunk-MQ6KVUBG";
import "@nf-internal/chunk-BZLND6O7";
import "@nf-internal/chunk-VJYBASWG";
import "@nf-internal/chunk-2NFLSA4Y";
import * as n from "@angular/core";
import { inject as H, RendererFactory2 as J } from "@angular/core";
import "@angular/common";
import "rxjs";
import "rxjs/operators";
var te = (() => { class t extends l {
    _renderer = H(J).createRenderer(null, null);
    _fullScreenEventName;
    _cleanupFullScreenListener;
    ngOnDestroy() { super.ngOnDestroy(), this._cleanupFullScreenListener?.(); }
    _createContainer() { let e = this._getEventName(); super._createContainer(), this._adjustParentForFullscreenChange(), e && (this._cleanupFullScreenListener?.(), this._cleanupFullScreenListener = this._renderer.listen("document", e, () => { this._adjustParentForFullscreenChange(); })); }
    _adjustParentForFullscreenChange() { this._containerElement && (this.getFullscreenElement() || this._document.body).appendChild(this._containerElement); }
    _getEventName() { if (!this._fullScreenEventName) {
        let e = this._document;
        e.fullscreenEnabled ? this._fullScreenEventName = "fullscreenchange" : e.webkitFullscreenEnabled ? this._fullScreenEventName = "webkitfullscreenchange" : e.mozFullScreenEnabled ? this._fullScreenEventName = "mozfullscreenchange" : e.msFullscreenEnabled && (this._fullScreenEventName = "MSFullscreenChange");
    } return this._fullScreenEventName; }
    getFullscreenElement() { let e = this._document; return e.fullscreenElement || e.webkitFullscreenElement || e.mozFullScreenElement || e.msFullscreenElement || null; }
    static \u0275fac = function (r) { return new (r || t); };
    static \u0275prov = n.\u0275\u0275defineService({ token: t, factory: t.\u0275fac });
} return t; })();
export { C as BlockScrollStrategy, K as CDK_CONNECTED_OVERLAY_DEFAULT_CONFIG, U as CdkConnectedOverlay, G as CdkOverlayOrigin, c as CdkScrollable, y as CloseScrollStrategy, D as ConnectedOverlayPositionChange, N as ConnectionPositionPair, x as FlexibleConnectedPositionStrategy, te as FullscreenOverlayContainer, I as GlobalPositionStrategy, O as NoopScrollStrategy, W as OVERLAY_DEFAULT_CONFIG, B as Overlay, v as OverlayConfig, l as OverlayContainer, V as OverlayKeyboardDispatcher, Y as OverlayModule, R as OverlayOutsideClickDispatcher, M as OverlayPositionBuilder, A as OverlayRef, h as RepositionScrollStrategy, T as STANDARD_DROPDOWN_ADJACENT_POSITIONS, L as STANDARD_DROPDOWN_BELOW_POSITIONS, a as ScrollDispatcher, F as ScrollStrategyOptions, k as ScrollingVisibility, s as ViewportRuler, f as createBlockScrollStrategy, _ as createCloseScrollStrategy, w as createFlexibleConnectedPositionStrategy, z as createGlobalPositionStrategy, E as createNoopScrollStrategy, j as createOverlayRef, g as createRepositionScrollStrategy, P as validateHorizontalPosition, b as validateVerticalPosition, i as \u0275\u0275CdkFixedSizeVirtualScroll, p as \u0275\u0275CdkScrollableModule, m as \u0275\u0275CdkVirtualForOf, u as \u0275\u0275CdkVirtualScrollViewport, S as \u0275\u0275CdkVirtualScrollableElement, d as \u0275\u0275CdkVirtualScrollableWindow, o as \u0275\u0275Dir };
