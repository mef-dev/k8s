import { c as l, d as h, e as p, f as _, g as y, h as c, i as f, j as A, k as g, l as v, m as M, n as D, o as P, p as w, q as T, r as E, s as I, t as b } from "@nf-internal/chunk-UITF4DDK";
import * as r from "@angular/core";
import { inject as u, ANIMATION_MODULE_TYPE as j, ViewEncapsulation as x, \u0275RuntimeError as R, DOCUMENT as S } from "@angular/core";
var N = (() => { class t {
    static \u0275fac = function (i) { return new (i || t); };
    static \u0275prov = r.\u0275\u0275defineService({ token: t, factory: () => u(k) });
} return t; })(), o = class {
}, k = (() => { class t extends N {
    animationModuleType = u(j, { optional: !0 });
    _nextAnimationId = 0;
    _renderer;
    constructor(n, i) { super(); let s = { id: "0", encapsulation: x.None, styles: [], data: { animation: [] } }; if (this._renderer = n.createRenderer(i.body, s), this.animationModuleType === null && !$(this._renderer))
        throw new R(3600, !1); }
    build(n) { let i = this._nextAnimationId; this._nextAnimationId++; let s = Array.isArray(n) ? c(n) : n; return m(this._renderer, null, i, "register", [s]), new a(i, this._renderer); }
    static \u0275fac = function (i) { return new (i || t)(r.\u0275\u0275inject(r.RendererFactory2), r.\u0275\u0275inject(S)); };
    static \u0275prov = r.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac, providedIn: "root" });
} return t; })(), a = class extends o {
    _id;
    _renderer;
    constructor(e, n) { super(), this._id = e, this._renderer = n; }
    create(e, n) { return new d(this._id, e, n || {}, this._renderer); }
}, d = class {
    id;
    element;
    _renderer;
    parentPlayer = null;
    _started = !1;
    constructor(e, n, i, s) { this.id = e, this.element = n, this._renderer = s, this._command("create", i); }
    _listen(e, n) { return this._renderer.listen(this.element, `@@${this.id}:${e}`, n); }
    _command(e, ...n) { m(this._renderer, this.element, this.id, e, n); }
    onDone(e) { this._listen("done", e); }
    onStart(e) { this._listen("start", e); }
    onDestroy(e) { this._listen("destroy", e); }
    init() { this._command("init"); }
    hasStarted() { return this._started; }
    play() { this._command("play"), this._started = !0; }
    pause() { this._command("pause"); }
    restart() { this._command("restart"); }
    finish() { this._command("finish"); }
    destroy() { this._command("destroy"); }
    reset() { this._command("reset"), this._started = !1; }
    setPosition(e) { this._command("setPosition", e); }
    getPosition() { return O(this._renderer)?.engine?.players[this.id]?.getPosition() ?? 0; }
    totalTime = 0;
};
function m(t, e, n, i, s) { t.setProperty(e, `@@${n}:${i}`, s); }
function O(t) { let e = t.\u0275type; return e === 0 ? t : e === 1 ? t.animationRenderer : null; }
function $(t) { let e = t.\u0275type; return e === 0 || e === 1; }
export { h as AUTO_STYLE, N as AnimationBuilder, o as AnimationFactory, l as AnimationMetadataType, E as NoopAnimationPlayer, _ as animate, D as animateChild, M as animation, y as group, g as keyframes, w as query, c as sequence, T as stagger, A as state, f as style, v as transition, p as trigger, P as useAnimation, I as \u0275AnimationGroupPlayer, k as \u0275BrowserAnimationBuilder, b as \u0275PRE_STYLE };
/*! Bundled license information:

@angular/animations/fesm2022/animations.mjs:
  (**
   * @license Angular v22.1.4
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
