import"./chunk-OSQMNGTH.js";import{DOCUMENT as a}from"@angular/common";import{inject as d}from"@angular/core";import*as r from"@angular/core";var m=(()=>{class o{constructor(){this.document=d(a)}success(t,e){this.show("success",t,e)}error(t,e){this.show("error",t,e)}warning(t,e){this.show("warning",t,e)}info(t,e){this.show("info",t,e)}show(t,e,s){let i=[s,e].filter(Boolean).join(" ");if(!i)return;let c=this.getContainer(),n=this.document.createElement("div");n.className=`bpmn-toast bpmn-toast-${t}`,n.textContent=i,c.appendChild(n),window.setTimeout(()=>{n.remove()},5e3)}getContainer(){let t=this.document.querySelector(".bpmn-toast-container");if(t)return t;t=this.document.createElement("div"),t.className="bpmn-toast-container",t.style.cssText=["position:fixed","top:16px","right:16px","z-index:10000","display:flex","flex-direction:column","gap:8px","pointer-events:none"].join(";");let e=this.document.createElement("style");return e.textContent=`
            .bpmn-toast {
                min-width: 220px;
                max-width: 420px;
                padding: 12px 16px;
                border-radius: 4px;
                box-shadow: 0 8px 24px color-mix(in srgb, var(--bpmn-shadow-color, #000) 24%, transparent);
                color: var(--md-color-text, #373737);
                font: 500 14px/1.4 Arial, sans-serif;
                pointer-events: auto;
            }

            /* Status accents inherit the current plugin theme. */
            .bpmn-toast-success { background: var(--md-color-surface-muted, #f3f3f3); border-left: 4px solid var(--md-color-success, #198754); }
            .bpmn-toast-error { background: var(--md-color-surface-muted, #f3f3f3); border-left: 4px solid var(--md-color-danger, #dc3545); }
            .bpmn-toast-warning { background: var(--md-color-surface-muted, #f3f3f3); border-left: 4px solid var(--md-color-warning, #f59f00); }
            .bpmn-toast-info { background: var(--md-color-surface-muted, #f3f3f3); border-left: 4px solid var(--md-color-info, #0dcaf0); }
        `,this.document.head.appendChild(e),(this.document.querySelector(".bpmn-modeler, bpmn-modeler")??this.document.querySelector("bpmn-designer")??this.document.body).appendChild(t),t}static{this.\u0275fac=function(e){return new(e||o)}}static{this.\u0275prov=r.\u0275\u0275defineInjectable({token:o,factory:o.\u0275fac,providedIn:"root"})}}return o})(),h=(()=>{class o{static forRoot(){return{ngModule:o,providers:[m]}}static{this.\u0275fac=function(e){return new(e||o)}}static{this.\u0275mod=r.\u0275\u0275defineNgModule({type:o})}static{this.\u0275inj=r.\u0275\u0275defineInjector({})}}return o})();export{h as ToastrModule,m as ToastrService};
