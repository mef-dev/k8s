import { a, b, c, d } from "@nf-internal/chunk-T23P62JN";
import "@nf-internal/chunk-2NFLSA4Y";
export { d as BidiModule, a as DIR_DOCUMENT, c as Dir, b as Directionality };
