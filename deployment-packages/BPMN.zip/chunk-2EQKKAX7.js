var fe = Object.defineProperty, he = Object.defineProperties;
var pe = Object.getOwnPropertyDescriptors;
var G = Object.getOwnPropertySymbols;
var me = Object.prototype.hasOwnProperty, ge = Object.prototype.propertyIsEnumerable;
var Y = (o, n, e) => n in o ? fe(o, n, { enumerable: !0, configurable: !0, writable: !0, value: e }) : o[n] = e, w = (o, n) => { for (var e in n ||= {})
    me.call(n, e) && Y(o, e, n[e]); if (G)
    for (var e of G(n))
        ge.call(n, e) && Y(o, e, n[e]); return o; }, Z = (o, n) => he(o, pe(n));
var b = (o, n, e) => new Promise((t, r) => { var s = c => { try {
    a(e.next(c));
}
catch (d) {
    r(d);
} }, i = c => { try {
    a(e.throw(c));
}
catch (d) {
    r(d);
} }, a = c => c.done ? t(c.value) : Promise.resolve(c.value).then(s, i); a((e = e.apply(o, n)).next()); });
import { DOCUMENT as P, \u0275getDOM as ve } from "@angular/common";
import * as l from "@angular/core";
import { InjectionToken as L, \u0275RuntimeError as R, APP_ID as k, CSP_NONCE as J, PLATFORM_ID as Ee, makeEnvironmentProviders as ye, ViewEncapsulation as v, \u0275SHARED_STYLES_HOST as Se, \u0275TracingService as Me, RendererStyleFlags2 as D, \u0275allLeavingAnimations as we } from "@angular/core";
var E = class {
    _doc;
    constructor(n) { this._doc = n; }
    manager;
}, T = (() => { class o extends E {
    constructor(e) { super(e); }
    supports(e) { return !0; }
    addEventListener(e, t, r, s) { return e.addEventListener(t, r, s), () => this.removeEventListener(e, t, r, s); }
    removeEventListener(e, t, r, s) { return e.removeEventListener(t, r, s); }
    static \u0275fac = function (t) { return new (t || o)(l.\u0275\u0275inject(P)); };
    static \u0275prov = l.\u0275\u0275defineInjectable({ token: o, factory: o.\u0275fac });
} return o; })(), O = new L(""), x = (() => { class o {
    _zone;
    _plugins;
    _eventNameToPlugin = new Map;
    constructor(e, t) { this._zone = t, e.forEach(i => { i.manager = this; }); let r = e.filter(i => !(i instanceof T)); this._plugins = r.slice().reverse(); let s = e.find(i => i instanceof T); s && this._plugins.push(s); }
    addEventListener(e, t, r, s) { return this._findPluginFor(t).addEventListener(e, t, r, s); }
    getZone() { return this._zone; }
    _findPluginFor(e) { let t = this._eventNameToPlugin.get(e); if (t)
        return t; if (t = this._plugins.find(s => s.supports(e)), !t)
        throw new R(-5101, !1); return this._eventNameToPlugin.set(e, t), t; }
    static \u0275fac = function (t) { return new (t || o)(l.\u0275\u0275inject(O), l.\u0275\u0275inject(l.NgZone)); };
    static \u0275prov = l.\u0275\u0275defineInjectable({ token: o, factory: o.\u0275fac });
} return o; })(), A = "ng-app-id";
function K(o) { for (let n of o)
    n.remove(); }
function W(o, n) { let e = n.createElement("style"); return e.textContent = o, e; }
function De(o, n, e, t) { let r = o.head?.querySelectorAll(`style[${A}="${n}"],link[${A}="${n}"]`); if (!r || r.length === 0)
    return !1; for (let s of r)
    s.removeAttribute(A), s instanceof HTMLLinkElement ? t.set(s.href.slice(s.href.lastIndexOf("/") + 1), { usage: 0, elements: [s] }) : s.textContent && e.set(s.textContent, { usage: 0, elements: [s] }); return !0; }
function I(o, n) { let e = n.createElement("link"); return e.setAttribute("rel", "stylesheet"), e.setAttribute("href", o), e; }
var H = (() => { class o {
    doc;
    appId;
    nonce;
    inline = new Map;
    external = new Map;
    hosts = new Set;
    constructor(e, t, r, s = {}) { this.doc = e, this.appId = t, this.nonce = r, De(e, t, this.inline, this.external) && this.hosts.add(e.head); }
    addStyles(e, t) { for (let r of e)
        this.addUsage(r, this.inline, W); t?.forEach(r => this.addUsage(r, this.external, I)); }
    removeStyles(e, t) { for (let r of e)
        this.removeUsage(r, this.inline); t?.forEach(r => this.removeUsage(r, this.external)); }
    addUsage(e, t, r) { let s = t.get(e); s ? s.usage++ : t.set(e, { usage: 1, elements: [...this.hosts].map(i => this.addElement(i, r(e, this.doc))) }); }
    removeUsage(e, t) { let r = t.get(e); r && (r.usage--, r.usage <= 0 && (K(r.elements), t.delete(e))); }
    ngOnDestroy() { for (let [, { elements: e }] of [...this.inline, ...this.external])
        K(e); this.hosts.clear(); }
    addHost(e) { if (!this.hosts.has(e)) {
        this.hosts.add(e);
        for (let [t, { elements: r }] of this.inline)
            r.push(this.addElement(e, W(t, this.doc)));
        for (let [t, { elements: r }] of this.external)
            r.push(this.addElement(e, I(t, this.doc)));
    } }
    removeHost(e) { this.hosts.delete(e); for (let t of [...this.inline.values(), ...this.external.values()]) {
        let r = [];
        for (let s of t.elements)
            s.parentNode === e ? s.remove() : r.push(s);
        t.elements = r;
    } }
    addElement(e, t) { return this.nonce && t.setAttribute("nonce", this.nonce), typeof ngServerMode < "u" && ngServerMode && t.setAttribute(A, this.appId), e.appendChild(t); }
    static \u0275fac = function (t) { return new (t || o)(l.\u0275\u0275inject(P), l.\u0275\u0275inject(k), l.\u0275\u0275inject(J, 8), l.\u0275\u0275inject(Ee)); };
    static \u0275prov = l.\u0275\u0275defineInjectable({ token: o, factory: o.\u0275fac });
} return o; })(), N = { svg: "http://www.w3.org/2000/svg", xhtml: "http://www.w3.org/1999/xhtml", xlink: "http://www.w3.org/1999/xlink", xml: "http://www.w3.org/XML/1998/namespace", xmlns: "http://www.w3.org/2000/xmlns/", math: "http://www.w3.org/1998/Math/MathML" }, U = /%COMP%/g;
var X = "%COMP%", Re = `_nghost-${X}`, Ae = `_ngcontent-${X}`, Te = !0, _e = new L("", { factory: () => Te }), q = new L("");
function at(o) { return ye([{ provide: q, useFactory: n => `${o ?? n}_`, deps: [k] }]); }
function Ce(o) { return Ae.replace(U, o); }
function Oe(o) { return Re.replace(U, o); }
function Q(o, n) { return n.map(e => e.replace(U, o)); }
var B = (() => { class o {
    eventManager;
    sharedStylesHost;
    appId;
    removeStylesOnCompDestroy;
    doc;
    ngZone;
    nonce;
    tracingService;
    rendererByCompId = new Map;
    defaultRenderer;
    cssVarNamespace;
    constructor(e, t, r, s, i, a, c = null, d = null, u = null) { this.eventManager = e, this.sharedStylesHost = t, this.appId = r, this.removeStylesOnCompDestroy = s, this.doc = i, this.ngZone = a, this.nonce = c, this.tracingService = d, this.cssVarNamespace = u ?? "", this.defaultRenderer = new y(e, i, a, this.tracingService, this.cssVarNamespace); }
    createRenderer(e, t) { if (!e || !t)
        return this.defaultRenderer; typeof ngServerMode < "u" && ngServerMode && (t.encapsulation === v.ShadowDom || t.encapsulation === v.ExperimentalIsolatedShadowDom) && (t = Z(w({}, t), { encapsulation: v.Emulated })); let r = this.getOrCreateRenderer(e, t); return r instanceof C ? r.applyToHost(e) : r instanceof S && r.applyStyles(), r; }
    getOrCreateRenderer(e, t) { let r = this.rendererByCompId, s = r.get(t.id); if (!s) {
        let i = this.doc, a = this.ngZone, c = this.eventManager, d = this.sharedStylesHost, u = this.removeStylesOnCompDestroy, f = this.tracingService;
        switch (t.encapsulation) {
            case v.Emulated:
                s = new C(c, d, t, this.appId, u, i, a, f, this.cssVarNamespace);
                break;
            case v.ShadowDom: return new _(c, e, t, i, a, this.nonce, f, this.cssVarNamespace, d);
            case v.ExperimentalIsolatedShadowDom: return new _(c, e, t, i, a, this.nonce, f, this.cssVarNamespace);
            default:
                s = new S(c, d, t, u, i, a, f, this.cssVarNamespace);
                break;
        }
        r.set(t.id, s);
    } return s; }
    ngOnDestroy() { this.rendererByCompId.clear(); }
    componentReplaced(e) { this.rendererByCompId.delete(e); }
    static \u0275fac = function (t) { return new (t || o)(l.\u0275\u0275inject(x), l.\u0275\u0275inject(Se), l.\u0275\u0275inject(k), l.\u0275\u0275inject(_e), l.\u0275\u0275inject(P), l.\u0275\u0275inject(l.NgZone), l.\u0275\u0275inject(J), l.\u0275\u0275inject(Me, 8), l.\u0275\u0275inject(q, 8)); };
    static \u0275prov = l.\u0275\u0275defineInjectable({ token: o, factory: o.\u0275fac });
} return o; })(), y = class {
    eventManager;
    doc;
    ngZone;
    tracingService;
    cssVarNamespace;
    data = Object.create(null);
    throwOnSyntheticProps = !0;
    constructor(n, e, t, r, s = "") { this.eventManager = n, this.doc = e, this.ngZone = t, this.tracingService = r, this.cssVarNamespace = s; }
    destroy() { }
    destroyNode = null;
    createElement(n, e) { return e ? this.doc.createElementNS(N[e] || e, n) : this.doc.createElement(n); }
    createComment(n) { return this.doc.createComment(n); }
    createText(n) { return this.doc.createTextNode(n); }
    appendChild(n, e) { (z(n) ? n.content : n).appendChild(e); }
    insertBefore(n, e, t) { if (n) {
        let r = z(n) ? n.content : n;
        if (t != null && t.parentNode !== r)
            throw new R(-5106, !1);
        r.insertBefore(e, t);
    } }
    removeChild(n, e) { e.remove(); }
    selectRootElement(n, e) { let t = typeof n == "string" ? this.doc.querySelector(n) : n; if (!t)
        throw new R(-5104, !1); return e || (t.textContent = ""), t; }
    parentNode(n) { return n.parentNode; }
    nextSibling(n) { return n.nextSibling; }
    setAttribute(n, e, t, r) { if (r) {
        e = r + ":" + e;
        let s = N[r];
        s ? n.setAttributeNS(s, e, t) : n.setAttribute(e, t);
    }
    else
        n.setAttribute(e, t); }
    removeAttribute(n, e, t) { if (t) {
        let r = N[t];
        r ? n.removeAttributeNS(r, e) : n.removeAttribute(`${t}:${e}`);
    }
    else
        n.removeAttribute(e); }
    addClass(n, e) { n.classList.add(e); }
    removeClass(n, e) { n.classList.remove(e); }
    setStyle(n, e, t, r) { let s = e.startsWith("--"); s && (e = e.replace("%NS%", this.cssVarNamespace)), s || r & (D.DashCase | D.Important) ? n.style.setProperty(e, t, r & D.Important ? "important" : "") : n.style[e] = t; }
    removeStyle(n, e, t) { let r = e.startsWith("--"); r && (e = e.replace("%NS%", this.cssVarNamespace)), r || t & D.DashCase ? n.style.removeProperty(e) : n.style[e] = ""; }
    setProperty(n, e, t) { n != null && (n[e] = t); }
    setValue(n, e) { n.nodeValue = e; }
    listen(n, e, t, r) { if (typeof n == "string" && (n = ve().getGlobalEventTarget(this.doc, n), !n))
        throw new R(-5102, !1); let s = this.decoratePreventDefault(t); return this.tracingService?.wrapEventListener && (s = this.tracingService.wrapEventListener(n, e, s)), this.eventManager.addEventListener(n, e, s, r); }
    decoratePreventDefault(n) { return e => { if (e === "__ngUnwrap__")
        return n; (typeof ngServerMode < "u" && ngServerMode ? this.ngZone.runGuarded(() => n(e)) : n(e)) === !1 && e.preventDefault(); }; }
};
function z(o) { return o.tagName === "TEMPLATE" && o.content !== void 0; }
var _ = class extends y {
    hostEl;
    sharedStylesHost;
    shadowRoot;
    constructor(n, e, t, r, s, i, a, c, d) { super(n, r, s, a, c), this.hostEl = e, this.sharedStylesHost = d, this.shadowRoot = e.attachShadow({ mode: "open" }), this.sharedStylesHost && this.sharedStylesHost.addHost(this.shadowRoot); let u = t.styles; u = Q(t.id, u).map(h => h.replace(/%NS%/g, c)); for (let h of u) {
        let g = document.createElement("style");
        i && g.setAttribute("nonce", i), g.textContent = h, this.shadowRoot.appendChild(g);
    } let f = t.getExternalStyles?.(); if (f)
        for (let h of f) {
            let g = I(h, r);
            i && g.setAttribute("nonce", i), this.shadowRoot.appendChild(g);
        } }
    nodeOrShadowRoot(n) { return n === this.hostEl ? this.shadowRoot : n; }
    appendChild(n, e) { return super.appendChild(this.nodeOrShadowRoot(n), e); }
    insertBefore(n, e, t) { return super.insertBefore(this.nodeOrShadowRoot(n), e, t); }
    removeChild(n, e) { return super.removeChild(null, e); }
    parentNode(n) { return this.nodeOrShadowRoot(super.parentNode(this.nodeOrShadowRoot(n))); }
    destroy() { this.sharedStylesHost && this.sharedStylesHost.removeHost(this.shadowRoot); }
}, S = class extends y {
    sharedStylesHost;
    removeStylesOnCompDestroy;
    styles;
    styleUrls;
    constructor(n, e, t, r, s, i, a, c, d) { super(n, s, i, a, c), this.sharedStylesHost = e, this.removeStylesOnCompDestroy = r; let u = t.styles, f = d ? Q(d, u) : u; this.styles = f.map(h => h.replace(/%NS%/g, c)), this.styleUrls = t.getExternalStyles?.(d); }
    applyStyles() { this.sharedStylesHost.addStyles(this.styles, this.styleUrls); }
    destroy() { this.removeStylesOnCompDestroy && we.size === 0 && this.sharedStylesHost.removeStyles(this.styles, this.styleUrls); }
}, C = class extends S {
    contentAttr;
    hostAttr;
    constructor(n, e, t, r, s, i, a, c, d) { let u = r + "-" + t.id; super(n, e, t, s, i, a, c, d, u), this.contentAttr = Ce(u), this.hostAttr = Oe(u); }
    applyToHost(n) { this.applyStyles(), this.setAttribute(n, this.hostAttr, ""); }
    createElement(n, e) { let t = super.createElement(n, e); return super.setAttribute(t, this.contentAttr, ""), t; }
};
import { \u0275DomAdapter as be, \u0275setRootDomAdapter as Ne, \u0275parseCookieValue as Ie, \u0275getDOM as oe, DOCUMENT as se, CommonModule as Pe, \u0275PLATFORM_BROWSER_ID as Le } from "@angular/common";
import * as p from "@angular/core";
import { \u0275global as m, \u0275RuntimeError as ke, InjectionToken as mt, ApplicationModule as xe, \u0275INJECTOR_SCOPE as He, ErrorHandler as ie, \u0275SHARED_STYLES_HOST as ee, RendererFactory2 as Ue, \u0275TESTABILITY_GETTER as V, NgZone as te, TestabilityRegistry as ne, Testability as j, \u0275TESTABILITY as Be, \u0275internalCreateApplication as ae, createPlatformFactory as Ve, platformCore as je, PLATFORM_ID as Fe, PLATFORM_INITIALIZER as $e, \u0275USE_PENDING_TASKS as Ge, \u0275resolveComponentResources as gt, \u0275setDocument as Ye } from "@angular/core";
var F = class o extends be {
    supportsDOMEvents = !0;
    static makeCurrent() { Ne(new o); }
    onAndCancel(n, e, t, r) { return n.addEventListener(e, t, r), () => { n.removeEventListener(e, t, r); }; }
    dispatchEvent(n, e) { n.dispatchEvent(e); }
    remove(n) { n.remove(); }
    createElement(n, e) { return e = e || this.getDefaultDocument(), e.createElement(n); }
    createHtmlDocument() { return document.implementation.createHTMLDocument("fakeTitle"); }
    getDefaultDocument() { return document; }
    isElementNode(n) { return n.nodeType === Node.ELEMENT_NODE; }
    isShadowRoot(n) { return n instanceof DocumentFragment; }
    getGlobalEventTarget(n, e) { return e === "window" ? window : e === "document" ? n : e === "body" ? n.body : null; }
    getBaseHref(n) { let e = Ze(); return e == null ? null : Ke(e); }
    resetBaseElement() { M = null; }
    getUserAgent() { return window.navigator.userAgent; }
    getCookie(n) { return Ie(document.cookie, n); }
}, M = null;
function Ze() { return M = M || document.head.querySelector("base"), M ? M.getAttribute("href") : null; }
function Ke(o) { return new URL(o, document.baseURI).pathname; }
var $ = class {
    addToWindow(n) { m.getAngularTestability = (t, r = !0) => { let s = n.findTestabilityInTree(t, r); if (s == null)
        throw new ke(5103, !1); return s; }, m.getAllAngularTestabilities = () => n.getAllTestabilities(), m.getAllAngularRootElements = () => n.getAllRootElements(); let e = t => { let r = m.getAllAngularTestabilities(), s = r.length, i = function () { s--, s == 0 && t(); }; r.forEach(a => { a.whenStable(i); }); }; m.frameworkStabilizers || (m.frameworkStabilizers = []), m.frameworkStabilizers.push(e); }
    findTestabilityInTree(n, e, t) { if (e == null)
        return null; let r = n.getTestability(e); return r ?? (t ? oe().isShadowRoot(e) ? this.findTestabilityInTree(n, e.host, !0) : this.findTestabilityInTree(n, e.parentElement, !0) : null); }
}, re = ["alt", "control", "meta", "shift"], We = { "\b": "Backspace", "	": "Tab", "\x7F": "Delete", "\x1B": "Escape", Del: "Delete", Esc: "Escape", Left: "ArrowLeft", Right: "ArrowRight", Up: "ArrowUp", Down: "ArrowDown", Menu: "ContextMenu", Scroll: "ScrollLock", Win: "OS" }, ze = { alt: o => o.altKey, control: o => o.ctrlKey, meta: o => o.metaKey, shift: o => o.shiftKey }, Je = (() => { class o extends E {
    constructor(e) { super(e); }
    supports(e) { return o.parseEventName(e) != null; }
    addEventListener(e, t, r, s) { let i = o.parseEventName(t), a = o.eventCallback(i.fullKey, r, this.manager.getZone()); return this.manager.getZone().runOutsideAngular(() => oe().onAndCancel(e, i.domEventName, a, s)); }
    static parseEventName(e) { let t = e.toLowerCase().split("."), r = t.shift(); if (t.length === 0 || !(r === "keydown" || r === "keyup"))
        return null; let s = o._normalizeKey(t.pop()), i = "", a = t.indexOf("code"); if (a > -1 && (t.splice(a, 1), i = "code."), re.forEach(d => { let u = t.indexOf(d); u > -1 && (t.splice(u, 1), i += d + "."); }), i += s, t.length != 0 || s.length === 0)
        return null; let c = {}; return c.domEventName = r, c.fullKey = i, c; }
    static matchEventFullKeyCode(e, t) { let r = We[e.key] || e.key, s = ""; return t.indexOf("code.") > -1 && (r = e.code, s = "code."), r == null || !r ? !1 : (r = r.toLowerCase(), r === " " ? r = "space" : r === "." && (r = "dot"), re.forEach(i => { if (i !== r) {
        let a = ze[i];
        a(e) && (s += i + ".");
    } }), s += r, s === t); }
    static eventCallback(e, t, r) { return s => { o.matchEventFullKeyCode(s, e) && r.runGuarded(() => t(s)); }; }
    static _normalizeKey(e) { return e === "esc" ? "escape" : e; }
    static \u0275fac = function (t) { return new (t || o)(p.\u0275\u0275inject(se)); };
    static \u0275prov = p.\u0275\u0275defineInjectable({ token: o, factory: o.\u0275fac });
} return o; })();
function yt(o, n, e) { return b(this, null, function* () { let t = w({ rootComponent: o }, ce(n, e)); return ae(t); }); }
function St(o, n) { return b(this, null, function* () { return ae(ce(o, n)); }); }
function ce(o, n) { return { platformRef: n?.platformRef, appProviders: [...ue, ...o?.providers ?? []], platformProviders: le }; }
function Mt(o = {}) { return [...de, o?.usePendingTasksForStability !== void 0 ? { provide: Ge, useValue: o.usePendingTasksForStability ?? !1 } : []]; }
function Xe() { F.makeCurrent(); }
function qe() { return new ie; }
function Qe() { return Ye(document), document; }
var le = [{ provide: Fe, useValue: Le }, { provide: $e, useValue: Xe, multi: !0 }, { provide: se, useFactory: Qe }], wt = Ve(je, "browser", le);
var de = [{ provide: V, useClass: $ }, { provide: Be, useClass: j, deps: [te, ne, V] }, { provide: j, useClass: j, deps: [te, ne, V] }], ue = [{ provide: He, useValue: "root" }, { provide: ie, useFactory: qe }, { provide: O, useClass: T, multi: !0 }, { provide: O, useClass: Je, multi: !0 }, B, { provide: ee, useClass: H }, { provide: H, useExisting: ee }, x, { provide: Ue, useExisting: B }, []], Dt = (() => { class o {
    constructor() { }
    static \u0275fac = function (t) { return new (t || o); };
    static \u0275mod = p.\u0275\u0275defineNgModule({ type: o });
    static \u0275inj = p.\u0275\u0275defineInjector({ providers: [...ue, ...de], imports: [Pe, xe] });
} return o; })();
export { E as a, T as b, O as c, x as d, H as e, _e as f, q as g, at as h, B as i, F as j, $ as k, Je as l, yt as m, St as n, Mt as o, wt as p, Dt as q };
/*! Bundled license information:

@angular/platform-browser/fesm2022/_dom_renderer-chunk.mjs:
@angular/platform-browser/fesm2022/_browser-chunk.mjs:
  (**
   * @license Angular v22.1.4
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
