import { q as a } from "@nf-internal/chunk-JHOL7CCD";
export { a as throwError };
