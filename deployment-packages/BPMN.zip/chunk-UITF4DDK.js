var F = Object.defineProperty;
var l = Object.getOwnPropertySymbols;
var f = Object.prototype.hasOwnProperty, _ = Object.prototype.propertyIsEnumerable;
var u = (s, t, e) => t in s ? F(s, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : s[t] = e, S = (s, t) => { for (var e in t ||= {})
    f.call(t, e) && u(s, e, t[e]); if (l)
    for (var e of l(t))
        _.call(t, e) && u(s, e, t[e]); return s; };
var g = (s, t) => { var e = {}; for (var n in s)
    f.call(s, n) && t.indexOf(n) < 0 && (e[n] = s[n]); if (s != null && l)
    for (var n of l(s))
        t.indexOf(n) < 0 && _.call(s, n) && (e[n] = s[n]); return e; };
var r = (function (s) { return s[s.State = 0] = "State", s[s.Transition = 1] = "Transition", s[s.Sequence = 2] = "Sequence", s[s.Group = 3] = "Group", s[s.Animate = 4] = "Animate", s[s.Keyframes = 5] = "Keyframes", s[s.Style = 6] = "Style", s[s.Trigger = 7] = "Trigger", s[s.Reference = 8] = "Reference", s[s.AnimateChild = 9] = "AnimateChild", s[s.AnimateRef = 10] = "AnimateRef", s[s.Query = 11] = "Query", s[s.Stagger = 12] = "Stagger", s; })(r || {}), d = "*";
function p(s, t) { return { type: r.Trigger, name: s, definitions: t, options: {} }; }
function E(s, t = null) { return { type: r.Animate, styles: t, timings: s }; }
function P(s, t = null) { return { type: r.Group, steps: s, options: t }; }
function m(s, t = null) { return { type: r.Sequence, steps: s, options: t }; }
function C(s) { return { type: r.Style, styles: s, offset: null }; }
function k(s, t, e) { return { type: r.State, name: s, styles: t, options: e }; }
function q(s) { return { type: r.Keyframes, steps: s }; }
function O(s, t, e = null) { return { type: r.Transition, expr: s, animation: t, options: e }; }
function R(s, t = null) { return { type: r.Reference, animation: s, options: t }; }
function b(s = null) { return { type: r.AnimateChild, options: s }; }
function L(s, t = null) { return { type: r.AnimateRef, animation: s, options: t }; }
function x(s, t, e = null) { return { type: r.Query, selector: s, animation: t, options: e }; }
function K(s, t) { return { type: r.Stagger, timings: s, animation: t }; }
var a = class {
    _onDoneFns = [];
    _onStartFns = [];
    _onDestroyFns = [];
    _originalOnDoneFns = [];
    _originalOnStartFns = [];
    _started = !1;
    _destroyed = !1;
    _finished = !1;
    _position = 0;
    parentPlayer = null;
    totalTime;
    constructor(t = 0, e = 0) { this.totalTime = t + e; }
    _onFinish() { this._finished || (this._finished = !0, this._onDoneFns.forEach(t => t()), this._onDoneFns = []); }
    onStart(t) { this._originalOnStartFns.push(t), this._onStartFns.push(t); }
    onDone(t) { this._originalOnDoneFns.push(t), this._onDoneFns.push(t); }
    onDestroy(t) { this._onDestroyFns.push(t); }
    hasStarted() { return this._started; }
    init() { }
    play() { this.hasStarted() || (this._onStart(), this.triggerMicrotask()), this._started = !0; }
    triggerMicrotask() { queueMicrotask(() => this._onFinish()); }
    _onStart() { this._onStartFns.forEach(t => t()), this._onStartFns = []; }
    pause() { }
    restart() { }
    finish() { this._onFinish(); }
    destroy() { this._destroyed || (this._destroyed = !0, this.hasStarted() || this._onStart(), this.finish(), this._onDestroyFns.forEach(t => t()), this._onDestroyFns = []); }
    reset() { this._started = !1, this._finished = !1, this._onStartFns = this._originalOnStartFns, this._onDoneFns = this._originalOnDoneFns; }
    setPosition(t) { this._position = this.totalTime ? t * this.totalTime : 1; }
    getPosition() { return this.totalTime ? this._position / this.totalTime : 1; }
    triggerCallback(t) { let e = t == "start" ? this._onStartFns : this._onDoneFns; e.forEach(n => n()), e.length = 0; }
}, c = class {
    _onDoneFns = [];
    _onStartFns = [];
    _finished = !1;
    _started = !1;
    _destroyed = !1;
    _onDestroyFns = [];
    parentPlayer = null;
    totalTime = 0;
    players;
    constructor(t) { this.players = t; let e = 0, n = 0, o = 0, h = this.players.length; h == 0 ? queueMicrotask(() => this._onFinish()) : this.players.forEach(i => { i.onDone(() => { ++e == h && this._onFinish(); }), i.onDestroy(() => { ++n == h && this._onDestroy(); }), i.onStart(() => { ++o == h && this._onStart(); }); }), this.totalTime = this.players.reduce((i, y) => Math.max(i, y.totalTime), 0); }
    _onFinish() { this._finished || (this._finished = !0, this._onDoneFns.forEach(t => t()), this._onDoneFns = []); }
    init() { this.players.forEach(t => t.init()); }
    onStart(t) { this._onStartFns.push(t); }
    _onStart() { this.hasStarted() || (this._started = !0, this._onStartFns.forEach(t => t()), this._onStartFns = []); }
    onDone(t) { this._onDoneFns.push(t); }
    onDestroy(t) { this._onDestroyFns.push(t); }
    hasStarted() { return this._started; }
    play() { this.parentPlayer || this.init(), this._onStart(), this.players.forEach(t => t.play()); }
    pause() { this.players.forEach(t => t.pause()); }
    restart() { this.players.forEach(t => t.restart()); }
    finish() { this._onFinish(), this.players.forEach(t => t.finish()); }
    destroy() { this._onDestroy(); }
    _onDestroy() { this._destroyed || (this._destroyed = !0, this._onFinish(), this.players.forEach(t => t.destroy()), this._onDestroyFns.forEach(t => t()), this._onDestroyFns = []); }
    reset() { this.players.forEach(t => t.reset()), this._destroyed = !1, this._finished = !1, this._started = !1; }
    setPosition(t) { let e = t * this.totalTime; this.players.forEach(n => { let o = n.totalTime ? Math.min(1, e / n.totalTime) : 1; n.setPosition(o); }); }
    getPosition() { let t = this.players.reduce((e, n) => e === null || n.totalTime > e.totalTime ? n : e, null); return t != null ? t.getPosition() : 0; }
    beforeDestroy() { this.players.forEach(t => { t.beforeDestroy && t.beforeDestroy(); }); }
    triggerCallback(t) { let e = t == "start" ? this._onStartFns : this._onDoneFns; e.forEach(n => n()), e.length = 0; }
}, Q = "!";
export { S as a, g as b, r as c, d, p as e, E as f, P as g, m as h, C as i, k as j, q as k, O as l, R as m, b as n, L as o, x as p, K as q, a as r, c as s, Q as t };
/*! Bundled license information:

@angular/animations/fesm2022/_private_export-chunk.mjs:
  (**
   * @license Angular v22.1.4
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
