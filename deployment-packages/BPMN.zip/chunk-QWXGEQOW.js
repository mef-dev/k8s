import { a as y, b as P, d as C, e as F, f as Me, h as Xe, i as g, j as ne, k as Qe, l as Ve, m as ie, n as E, o as ue, p as S, q as He } from "@nf-internal/chunk-JHOL7CCD";
function Le(t) { return y(t?.lift); }
function l(t) { return e => { if (Le(e))
    return e.lift(function (r) { try {
        return t(r, this);
    }
    catch (o) {
        this.error(o);
    } }); throw new TypeError("Unable to lift unknown Observable type"); }; }
function c(t, e, r, o, n) { return new Y(t, e, r, o, n); }
var Y = class extends Qe {
    constructor(e, r, o, n, i, u) { super(e), this.onFinalize = i, this.shouldUnsubscribe = u, this._next = r ? function (f) { try {
        r(f);
    }
    catch (s) {
        e.error(s);
    } } : super._next, this._error = n ? function (f) { try {
        n(f);
    }
    catch (s) {
        e.error(s);
    }
    finally {
        this.unsubscribe();
    } } : super._error, this._complete = o ? function () { try {
        o();
    }
    catch (f) {
        e.error(f);
    }
    finally {
        this.unsubscribe();
    } } : super._complete; }
    unsubscribe() { var e; if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
        let { closed: r } = this;
        super.unsubscribe(), !r && ((e = this.onFinalize) === null || e === void 0 || e.call(this));
    } }
};
function et() { return l((t, e) => { let r = null; t._refCount++; let o = c(e, void 0, void 0, void 0, () => { if (!t || t._refCount <= 0 || 0 < --t._refCount) {
    r = null;
    return;
} let n = t._connection, i = r; r = null, n && (!i || n === i) && n.unsubscribe(), e.unsubscribe(); }); t.subscribe(o), o.closed || (r = t.connect()); }); }
var W = class extends S {
    constructor(e, r) { super(), this.source = e, this.subjectFactory = r, this._subject = null, this._refCount = 0, this._connection = null, Le(e) && (this.lift = e.lift); }
    _subscribe(e) { return this.getSubject().subscribe(e); }
    getSubject() { let e = this._subject; return (!e || e.isStopped) && (this._subject = this.subjectFactory()), this._subject; }
    _teardown() { this._refCount = 0; let { _connection: e } = this; this._subject = this._connection = null, e?.unsubscribe(); }
    connect() { let e = this._connection; if (!e) {
        e = this._connection = new F;
        let r = this.getSubject();
        e.add(this.source.subscribe(c(r, void 0, () => { this._teardown(), r.complete(); }, o => { this._teardown(), r.error(o); }, () => this._teardown()))), e.closed && (this._connection = null, e = F.EMPTY);
    } return e; }
    refCount() { return et()(this); }
};
var tt = P(t => function () { t(this), this.name = "ObjectUnsubscribedError", this.message = "object unsubscribed"; });
var _ = class extends S {
    constructor() { super(), this.closed = !1, this.currentObservers = null, this.observers = [], this.isStopped = !1, this.hasError = !1, this.thrownError = null; }
    lift(e) { let r = new se(this, this); return r.operator = e, r; }
    _throwIfClosed() { if (this.closed)
        throw new tt; }
    next(e) { ne(() => { if (this._throwIfClosed(), !this.isStopped) {
        this.currentObservers || (this.currentObservers = Array.from(this.observers));
        for (let r of this.currentObservers)
            r.next(e);
    } }); }
    error(e) { ne(() => { if (this._throwIfClosed(), !this.isStopped) {
        this.hasError = this.isStopped = !0, this.thrownError = e;
        let { observers: r } = this;
        for (; r.length;)
            r.shift().error(e);
    } }); }
    complete() { ne(() => { if (this._throwIfClosed(), !this.isStopped) {
        this.isStopped = !0;
        let { observers: e } = this;
        for (; e.length;)
            e.shift().complete();
    } }); }
    unsubscribe() { this.isStopped = this.closed = !0, this.observers = this.currentObservers = null; }
    get observed() { var e; return ((e = this.observers) === null || e === void 0 ? void 0 : e.length) > 0; }
    _trySubscribe(e) { return this._throwIfClosed(), super._trySubscribe(e); }
    _subscribe(e) { return this._throwIfClosed(), this._checkFinalizedStatuses(e), this._innerSubscribe(e); }
    _innerSubscribe(e) { let { hasError: r, isStopped: o, observers: n } = this; return r || o ? Me : (this.currentObservers = null, n.push(e), new F(() => { this.currentObservers = null, C(n, e); })); }
    _checkFinalizedStatuses(e) { let { hasError: r, thrownError: o, isStopped: n } = this; r ? e.error(o) : n && e.complete(); }
    asObservable() { let e = new S; return e.source = this, e; }
};
_.create = (t, e) => new se(t, e);
var se = class extends _ {
    constructor(e, r) { super(), this.destination = e, this.source = r; }
    next(e) { var r, o; (o = (r = this.destination) === null || r === void 0 ? void 0 : r.next) === null || o === void 0 || o.call(r, e); }
    error(e) { var r, o; (o = (r = this.destination) === null || r === void 0 ? void 0 : r.error) === null || o === void 0 || o.call(r, e); }
    complete() { var e, r; (r = (e = this.destination) === null || e === void 0 ? void 0 : e.complete) === null || r === void 0 || r.call(e); }
    _subscribe(e) { var r, o; return (o = (r = this.source) === null || r === void 0 ? void 0 : r.subscribe(e)) !== null && o !== void 0 ? o : Me; }
};
var fe = class extends _ {
    constructor(e) { super(), this._value = e; }
    get value() { return this.getValue(); }
    _subscribe(e) { let r = super._subscribe(e); return !r.closed && e.next(this._value), r; }
    getValue() { let { hasError: e, thrownError: r, _value: o } = this; if (e)
        throw r; return this._throwIfClosed(), o; }
    next(e) { super.next(this._value = e); }
};
var $ = { now() { return ($.delegate || Date).now(); }, delegate: void 0 };
var X = class extends _ {
    constructor(e = 1 / 0, r = 1 / 0, o = $) { super(), this._bufferSize = e, this._windowTime = r, this._timestampProvider = o, this._buffer = [], this._infiniteTimeWindow = !0, this._infiniteTimeWindow = r === 1 / 0, this._bufferSize = Math.max(1, e), this._windowTime = Math.max(1, r); }
    next(e) { let { isStopped: r, _buffer: o, _infiniteTimeWindow: n, _timestampProvider: i, _windowTime: u } = this; r || (o.push(e), !n && o.push(i.now() + u)), this._trimBuffer(), super.next(e); }
    _subscribe(e) { this._throwIfClosed(), this._trimBuffer(); let r = this._innerSubscribe(e), { _infiniteTimeWindow: o, _buffer: n } = this, i = n.slice(); for (let u = 0; u < i.length && !e.closed; u += o ? 1 : 2)
        e.next(i[u]); return this._checkFinalizedStatuses(e), r; }
    _trimBuffer() { let { _bufferSize: e, _timestampProvider: r, _buffer: o, _infiniteTimeWindow: n } = this, i = (n ? 1 : 2) * e; if (e < 1 / 0 && i < o.length && o.splice(0, o.length - i), !n) {
        let u = r.now(), f = 0;
        for (let s = 1; s < o.length && o[s] <= u; s += 2)
            f = s;
        f && o.splice(0, f + 1);
    } }
};
var le = class extends _ {
    constructor() { super(...arguments), this._value = null, this._hasValue = !1, this._isComplete = !1; }
    _checkFinalizedStatuses(e) { let { hasError: r, _hasValue: o, _value: n, thrownError: i, isStopped: u, _isComplete: f } = this; r ? e.error(i) : (u || f) && (o && e.next(n), e.complete()); }
    next(e) { this.isStopped || (this._value = e, this._hasValue = !0); }
    complete() { let { _hasValue: e, _value: r, _isComplete: o } = this; o || (this._isComplete = !0, e && super.next(r), super.complete()); }
};
var Ne = (() => { class t {
    constructor(r, o = t.now) { this.schedulerActionCtor = r, this.now = o; }
    schedule(r, o = 0, n) { return new this.schedulerActionCtor(this, r).schedule(n, o); }
} return t.now = $.now, t; })();
var ce = class extends F {
    constructor(e, r) { super(); }
    schedule(e, r = 0) { return this; }
};
var oe = { setInterval(t, e, ...r) { let { delegate: o } = oe; return o?.setInterval ? o.setInterval(t, e, ...r) : setInterval(t, e, ...r); }, clearInterval(t) { let { delegate: e } = oe; return (e?.clearInterval || clearInterval)(t); }, delegate: void 0 };
var me = class extends ce {
    constructor(e, r) { super(e, r), this.scheduler = e, this.work = r, this.pending = !1; }
    schedule(e, r = 0) { var o; if (this.closed)
        return this; this.state = e; let n = this.id, i = this.scheduler; return n != null && (this.id = this.recycleAsyncId(i, n, r)), this.pending = !0, this.delay = r, this.id = (o = this.id) !== null && o !== void 0 ? o : this.requestAsyncId(i, this.id, r), this; }
    requestAsyncId(e, r, o = 0) { return oe.setInterval(e.flush.bind(e, this), o); }
    recycleAsyncId(e, r, o = 0) { if (o != null && this.delay === o && this.pending === !1)
        return r; r != null && oe.clearInterval(r); }
    execute(e, r) { if (this.closed)
        return new Error("executing a cancelled action"); this.pending = !1; let o = this._execute(e, r); if (o)
        return o; this.pending === !1 && this.id != null && (this.id = this.recycleAsyncId(this.scheduler, this.id, null)); }
    _execute(e, r) { let o = !1, n; try {
        this.work(e);
    }
    catch (i) {
        o = !0, n = i || new Error("Scheduled action threw falsy error");
    } if (o)
        return this.unsubscribe(), n; }
    unsubscribe() { if (!this.closed) {
        let { id: e, scheduler: r } = this, { actions: o } = r;
        this.work = this.state = this.scheduler = null, this.pending = !1, C(o, this), e != null && (this.id = this.recycleAsyncId(r, e, null)), this.delay = null, super.unsubscribe();
    } }
};
var pe = class extends Ne {
    constructor(e, r = Ne.now) { super(e, r), this.actions = [], this._active = !1; }
    flush(e) { let { actions: r } = this; if (this._active) {
        r.push(e);
        return;
    } let o; this._active = !0; do
        if (o = e.execute(e.state, e.delay))
            break;
    while (e = r.shift()); if (this._active = !1, o) {
        for (; e = r.shift();)
            e.unsubscribe();
        throw o;
    } }
};
var j = new pe(me), ae = j;
var V = new S(t => t.complete());
function eo(t) { return t ? Wt(t) : V; }
function Wt(t) { return new S(e => t.schedule(() => e.complete())); }
function I(t, e, r, o = 0, n = !1) { let i = e.schedule(function () { r(), n ? t.add(this.schedule(null, o)) : this.unsubscribe(); }, o); if (t.add(i), !n)
    return i; }
function de(t, e = 0) { return l((r, o) => { r.subscribe(c(o, n => I(o, t, () => o.next(n), e), () => I(o, t, () => o.complete(), e), n => I(o, t, () => o.error(n), e))); }); }
function he(t, e = 0) { return l((r, o) => { o.add(t.schedule(() => r.subscribe(o), e)); }); }
function ot(t, e, r, o) { function n(i) { return i instanceof r ? i : new r(function (u) { u(i); }); } return new (r || (r = Promise))(function (i, u) { function f(p) { try {
    m(o.next(p));
}
catch (b) {
    u(b);
} } function s(p) { try {
    m(o.throw(p));
}
catch (b) {
    u(b);
} } function m(p) { p.done ? i(p.value) : n(p.value).then(f, s); } m((o = o.apply(t, e || [])).next()); }); }
function rt(t) { var e = typeof Symbol == "function" && Symbol.iterator, r = e && t[e], o = 0; if (r)
    return r.call(t); if (t && typeof t.length == "number")
    return { next: function () { return t && o >= t.length && (t = void 0), { value: t && t[o++], done: !t }; } }; throw new TypeError(e ? "Object is not iterable." : "Symbol.iterator is not defined."); }
function K(t) { return this instanceof K ? (this.v = t, this) : new K(t); }
function nt(t, e, r) { if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined."); var o = r.apply(t, e || []), n, i = []; return n = Object.create((typeof AsyncIterator == "function" ? AsyncIterator : Object).prototype), f("next"), f("throw"), f("return", u), n[Symbol.asyncIterator] = function () { return this; }, n; function u(x) { return function (d) { return Promise.resolve(d).then(x, b); }; } function f(x, d) { o[x] && (n[x] = function (h) { return new Promise(function (v, O) { i.push([x, h, v, O]) > 1 || s(x, h); }); }, d && (n[x] = d(n[x]))); } function s(x, d) { try {
    m(o[x](d));
}
catch (h) {
    w(i[0][3], h);
} } function m(x) { x.value instanceof K ? Promise.resolve(x.value.v).then(p, b) : w(i[0][2], x); } function p(x) { s("next", x); } function b(x) { s("throw", x); } function w(x, d) { x(d), i.shift(), i.length && s(i[0][0], i[0][1]); } }
function it(t) { if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined."); var e = t[Symbol.asyncIterator], r; return e ? e.call(t) : (t = typeof rt == "function" ? rt(t) : t[Symbol.iterator](), r = {}, o("next"), o("throw"), o("return"), r[Symbol.asyncIterator] = function () { return this; }, r); function o(i) { r[i] = t[i] && function (u) { return new Promise(function (f, s) { u = t[i](u), n(f, s, u.done, u.value); }); }; } function n(i, u, f, s) { Promise.resolve(s).then(function (m) { i({ value: m, done: f }); }, u); } }
var be = (t => t && typeof t.length == "number" && typeof t != "function");
function xe(t) { return y(t?.then); }
function ye(t) { return y(t[ie]); }
function ve(t) { return Symbol.asyncIterator && y(t?.[Symbol.asyncIterator]); }
function we(t) { return new TypeError(`You provided ${t !== null && typeof t == "object" ? "an invalid object" : `'${t}'`} where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.`); }
function Dt() { return typeof Symbol != "function" || !Symbol.iterator ? "@@iterator" : Symbol.iterator; }
var Se = Dt();
function _e(t) { return y(t?.[Se]); }
function ge(t) { return nt(this, arguments, function* () { let r = t.getReader(); try {
    for (;;) {
        let { value: o, done: n } = yield K(r.read());
        if (n)
            return yield K(void 0);
        yield yield K(o);
    }
}
finally {
    r.releaseLock();
} }); }
function Oe(t) { return y(t?.getReader); }
function a(t) { if (t instanceof S)
    return t; if (t != null) {
    if (ye(t))
        return Ut(t);
    if (be(t))
        return zt(t);
    if (xe(t))
        return qt(t);
    if (ve(t))
        return ut(t);
    if (_e(t))
        return Gt(t);
    if (Oe(t))
        return Yt(t);
} throw we(t); }
function Ut(t) { return new S(e => { let r = t[ie](); if (y(r.subscribe))
    return r.subscribe(e); throw new TypeError("Provided object does not correctly implement Symbol.observable"); }); }
function zt(t) { return new S(e => { for (let r = 0; r < t.length && !e.closed; r++)
    e.next(t[r]); e.complete(); }); }
function qt(t) { return new S(e => { t.then(r => { e.closed || (e.next(r), e.complete()); }, r => e.error(r)).then(null, Xe); }); }
function Gt(t) { return new S(e => { for (let r of t)
    if (e.next(r), e.closed)
        return; e.complete(); }); }
function ut(t) { return new S(e => { $t(t, e).catch(r => e.error(r)); }); }
function Yt(t) { return ut(ge(t)); }
function $t(t, e) { var r, o, n, i; return ot(this, void 0, void 0, function* () { try {
    for (r = it(t); o = yield r.next(), !o.done;) {
        let u = o.value;
        if (e.next(u), e.closed)
            return;
    }
}
catch (u) {
    n = { error: u };
}
finally {
    try {
        o && !o.done && (i = r.return) && (yield i.call(r));
    }
    finally {
        if (n)
            throw n.error;
    }
} e.complete(); }); }
function st(t, e) { return a(t).pipe(he(e), de(e)); }
function ft(t, e) { return a(t).pipe(he(e), de(e)); }
function lt(t, e) { return new S(r => { let o = 0; return e.schedule(function () { o === t.length ? r.complete() : (r.next(t[o++]), r.closed || this.schedule()); }); }); }
function ct(t, e) { return new S(r => { let o; return I(r, e, () => { o = t[Se](), I(r, e, () => { let n, i; try {
    ({ value: n, done: i } = o.next());
}
catch (u) {
    r.error(u);
    return;
} i ? r.complete() : r.next(n); }, 0, !0); }), () => y(o?.return) && o.return(); }); }
function Ee(t, e) { if (!t)
    throw new Error("Iterable cannot be null"); return new S(r => { I(r, e, () => { let o = t[Symbol.asyncIterator](); I(r, e, () => { o.next().then(n => { n.done ? r.complete() : r.next(n.value); }); }, 0, !0); }); }); }
function mt(t, e) { return Ee(ge(t), e); }
function pt(t, e) { if (t != null) {
    if (ye(t))
        return st(t, e);
    if (be(t))
        return lt(t, e);
    if (xe(t))
        return ft(t, e);
    if (ve(t))
        return Ee(t, e);
    if (_e(t))
        return ct(t, e);
    if (Oe(t))
        return mt(t, e);
} throw we(t); }
function L(t, e) { return e ? pt(t, e) : a(t); }
function Ie(t) { return t && y(t.schedule); }
function We(t) { return t[t.length - 1]; }
function D(t) { return y(We(t)) ? t.pop() : void 0; }
function A(t) { return Ie(We(t)) ? t.pop() : void 0; }
function at(t, e) { return typeof We(t) == "number" ? t.pop() : e; }
function je(...t) { let e = A(t); return L(t, e); }
var Kt = (function (t) { return t.NEXT = "N", t.ERROR = "E", t.COMPLETE = "C", t; })(Kt || {}), U = class t {
    constructor(e, r, o) { this.kind = e, this.value = r, this.error = o, this.hasValue = e === "N"; }
    observe(e) { return De(this, e); }
    do(e, r, o) { let { kind: n, value: i, error: u } = this; return n === "N" ? e?.(i) : n === "E" ? r?.(u) : o?.(); }
    accept(e, r, o) { var n; return y((n = e) === null || n === void 0 ? void 0 : n.next) ? this.observe(e) : this.do(e, r, o); }
    toObservable() { let { kind: e, value: r, error: o } = this, n = e === "N" ? je(r) : e === "E" ? He(() => o) : e === "C" ? V : 0; if (!n)
        throw new TypeError(`Unexpected notification kind ${e}`); return n; }
    static createNext(e) { return new t("N", e); }
    static createError(e) { return new t("E", void 0, e); }
    static createComplete() { return t.completeNotification; }
};
U.completeNotification = new U("C");
function De(t, e) { var r, o, n; let { kind: i, value: u, error: f } = t; if (typeof i != "string")
    throw new TypeError('Invalid notification, missing "kind"'); i === "N" ? (r = e.next) === null || r === void 0 || r.call(e, u) : i === "E" ? (o = e.error) === null || o === void 0 || o.call(e, f) : (n = e.complete) === null || n === void 0 || n.call(e); }
var z = P(t => function () { t(this), this.name = "EmptyError", this.message = "no elements in sequence"; });
var Ue = P(t => function () { t(this), this.name = "ArgumentOutOfRangeError", this.message = "argument out of range"; });
var dt = P(t => function (r) { t(this), this.name = "NotFoundError", this.message = r; });
var ht = P(t => function (r) { t(this), this.name = "SequenceError", this.message = r; });
function Q(t) { return t instanceof Date && !isNaN(t); }
var Bt = P(t => function (r = null) { t(this), this.message = "Timeout has occurred", this.name = "TimeoutError", this.info = r; });
function bt(t, e) { let { first: r, each: o, with: n = Zt, scheduler: i = e ?? j, meta: u = null } = Q(t) ? { first: t } : typeof t == "number" ? { each: t } : t; if (r == null && o == null)
    throw new TypeError("No timeout provided."); return l((f, s) => { let m, p, b = null, w = 0, x = d => { p = I(s, i, () => { try {
    m.unsubscribe(), a(n({ meta: u, lastValue: b, seen: w })).subscribe(s);
}
catch (h) {
    s.error(h);
} }, d); }; m = f.subscribe(c(s, d => { p?.unsubscribe(), w++, s.next(b = d), o > 0 && x(o); }, void 0, void 0, () => { p?.closed || p?.unsubscribe(), b = null; })), !w && x(r != null ? typeof r == "number" ? r : +r - i.now() : o); }); }
function Zt(t) { throw new Bt(t); }
function R(t, e) { return l((r, o) => { let n = 0; r.subscribe(c(o, i => { o.next(t.call(e, i, n++)); })); }); }
var { isArray: Jt } = Array, { getPrototypeOf: Xt, prototype: Qt, keys: Ht } = Object;
function xt(t) { if (t.length === 1) {
    let e = t[0];
    if (Jt(e))
        return { args: e, keys: null };
    if (er(e)) {
        let r = Ht(e);
        return { args: r.map(o => e[o]), keys: r };
    }
} return { args: t, keys: null }; }
function er(t) { return t && typeof t == "object" && Xt(t) === Qt; }
var { isArray: tr } = Array;
function rr(t, e) { return tr(e) ? t(...e) : t(e); }
function H(t) { return R(e => rr(t, e)); }
function yt(t, e) { return t.reduce((r, o, n) => (r[o] = e[n], r), {}); }
function wt(...t) { let e = A(t), r = D(t), { args: o, keys: n } = xt(t); if (o.length === 0)
    return L([], e); let i = new S(ze(o, e, n ? u => yt(n, u) : E)); return r ? i.pipe(H(r)) : i; }
function ze(t, e, r = E) { return o => { vt(e, () => { let { length: n } = t, i = new Array(n), u = n, f = n; for (let s = 0; s < n; s++)
    vt(e, () => { let m = L(t[s], e), p = !1; m.subscribe(c(o, b => { i[s] = b, p || (p = !0, f--), f || o.next(r(i.slice())); }, () => { --u || o.complete(); })); }, o); }, o); }; }
function vt(t, e, r) { t ? I(r, t, e) : e(); }
function ee(t, e, r, o, n, i, u, f) { let s = [], m = 0, p = 0, b = !1, w = () => { b && !s.length && !m && e.complete(); }, x = h => m < o ? d(h) : s.push(h), d = h => { i && e.next(h), m++; let v = !1; a(r(h, p++)).subscribe(c(e, O => { n?.(O), i ? x(O) : e.next(O); }, () => { v = !0; }, void 0, () => { if (v)
    try {
        for (m--; s.length && m < o;) {
            let O = s.shift();
            u ? I(e, u, () => d(O)) : d(O);
        }
        w();
    }
    catch (O) {
        e.error(O);
    } })); }; return t.subscribe(c(e, x, () => { b = !0, w(); })), () => { f?.(); }; }
function T(t, e, r = 1 / 0) { return y(e) ? T((o, n) => R((i, u) => e(o, i, n, u))(a(t(o, n))), r) : (typeof e == "number" && (r = e), l((o, n) => ee(o, n, t, r))); }
function Ae(t = 1 / 0) { return T(E, t); }
function Fe() { return Ae(1); }
function B(...t) { return Fe()(L(t, A(t))); }
function k(t = 0, e, r = ae) { let o = -1; return e != null && (Ie(e) ? r = e : o = e), new S(n => { let i = Q(t) ? +t - r.now() : t; i < 0 && (i = 0); let u = 0; return r.schedule(function () { n.closed || (n.next(u++), 0 <= o ? this.schedule(void 0, o) : n.complete()); }, i); }); }
function St(t = 0, e = j) { return t < 0 && (t = 0), k(t, t, e); }
var { isArray: or } = Array;
function N(t) { return t.length === 1 && or(t[0]) ? t[0] : t; }
function _t(...t) { let e = N(t); return new S(r => { let o = 0, n = () => { if (o < e.length) {
    let i;
    try {
        i = a(e[o++]);
    }
    catch {
        n();
        return;
    }
    let u = new Y(r, void 0, g, g);
    i.subscribe(u), u.add(n);
}
else
    r.complete(); }; n(); }); }
function q(t, e) { return l((r, o) => { let n = 0; r.subscribe(c(o, i => t.call(e, i, n++) && o.next(i))); }); }
function iu(...t) { return t = N(t), t.length === 1 ? a(t[0]) : new S(qe(t)); }
function qe(t) { return e => { let r = []; for (let o = 0; r && !e.closed && o < t.length; o++)
    r.push(a(t[o]).subscribe(c(e, n => { if (r) {
        for (let i = 0; i < r.length; i++)
            i !== o && r[i].unsubscribe();
        r = null;
    } e.next(n); }))); }; }
function Te(...t) { let e = D(t), r = N(t); return r.length ? new S(o => { let n = r.map(() => []), i = r.map(() => !1); o.add(() => { n = i = null; }); for (let u = 0; !o.closed && u < r.length; u++)
    a(r[u]).subscribe(c(o, f => { if (n[u].push(f), n.every(s => s.length)) {
        let s = n.map(m => m.shift());
        o.next(e ? e(...s) : s), n.some((m, p) => !m.length && i[p]) && o.complete();
    } }, () => { i[u] = !0, !n[u].length && o.complete(); })); return () => { n = i = null; }; }) : V; }
function gt(t) { return l((e, r) => { let o = !1, n = null, i = null, u = !1, f = () => { if (i?.unsubscribe(), i = null, o) {
    o = !1;
    let m = n;
    n = null, r.next(m);
} u && r.complete(); }, s = () => { i = null, u && r.complete(); }; e.subscribe(c(r, m => { o = !0, n = m, i || a(t(m)).subscribe(i = c(r, f, s)); }, () => { u = !0, (!o || !i || i.closed) && r.complete(); })); }); }
function Su(t, e = j) { return gt(() => k(t, e)); }
function ju(t) { return l((e, r) => { let o = []; return e.subscribe(c(r, n => o.push(n), () => { r.next(o), r.complete(); })), a(t).subscribe(c(r, () => { let n = o; o = [], r.next(n); }, g)), () => { o = null; }; }); }
function Pu(t, e = null) { return e = e ?? t, l((r, o) => { let n = [], i = 0; r.subscribe(c(o, u => { let f = null; i++ % e === 0 && n.push([]); for (let s of n)
    s.push(u), t <= s.length && (f = f ?? [], f.push(s)); if (f)
    for (let s of f)
        C(n, s), o.next(s); }, () => { for (let u of n)
    o.next(u); o.complete(); }, void 0, () => { n = null; })); }); }
function Uu(t, ...e) { var r, o; let n = (r = A(e)) !== null && r !== void 0 ? r : j, i = (o = e[0]) !== null && o !== void 0 ? o : null, u = e[1] || 1 / 0; return l((f, s) => { let m = [], p = !1, b = d => { let { buffer: h, subs: v } = d; v.unsubscribe(), C(m, d), s.next(h), p && w(); }, w = () => { if (m) {
    let d = new F;
    s.add(d);
    let v = { buffer: [], subs: d };
    m.push(v), I(d, n, () => b(v), t);
} }; i !== null && i >= 0 ? I(s, n, w, i, !0) : p = !0, w(); let x = c(s, d => { let h = m.slice(); for (let v of h) {
    let { buffer: O } = v;
    O.push(d), u <= O.length && b(v);
} }, () => { for (; m?.length;)
    s.next(m.shift().buffer); x?.unsubscribe(), s.complete(), s.unsubscribe(); }, void 0, () => m = null); f.subscribe(x); }); }
function Zu(t, e) { return l((r, o) => { let n = []; a(t).subscribe(c(o, i => { let u = []; n.push(u); let f = new F, s = () => { C(n, u), o.next(u), f.unsubscribe(); }; f.add(a(e(i)).subscribe(c(o, s, g))); }, g)), r.subscribe(c(o, i => { for (let u of n)
    u.push(i); }, () => { for (; n.length > 0;)
    o.next(n.shift()); o.complete(); })); }); }
function ts(t) { return l((e, r) => { let o = null, n = null, i = () => { n?.unsubscribe(); let u = o; o = [], u && r.next(u), a(t()).subscribe(n = c(r, i, g)); }; i(), e.subscribe(c(r, u => o?.push(u), () => { o && r.next(o), r.complete(); }, void 0, () => o = n = null)); }); }
function nr(t) { return l((e, r) => { let o = null, n = !1, i; o = e.subscribe(c(r, void 0, void 0, u => { i = a(t(u, nr(t)(e))), o ? (o.unsubscribe(), o = null, i.subscribe(r)) : n = !0; })), n && (o.unsubscribe(), o = null, i.subscribe(r)); }); }
function Ce(t, e, r, o, n) { return (i, u) => { let f = r, s = e, m = 0; i.subscribe(c(u, p => { let b = m++; s = f ? t(s, p, b) : (f = !0, p), o && u.next(s); }, n && (() => { f && u.next(s), u.complete(); }))); }; }
function G(t, e) { return l(Ce(t, e, arguments.length >= 2, !1, !0)); }
var ir = (t, e) => (t.push(e), t);
function Ot() { return l((t, e) => { G(ir, [])(t).subscribe(e); }); }
function Pe(t, e) { return ue(Ot(), T(r => t(r)), e ? H(e) : E); }
function Et(t) { return Pe(wt, t); }
var Es = Et;
function Ge(...t) { let e = D(t); return e ? ue(Ge(...t), H(e)) : l((r, o) => { ze([r, ...N(t)])(o); }); }
function Ms(...t) { return Ge(...t); }
function Ye(t, e) { return y(e) ? T(t, e, 1) : T(t, 1); }
function zs(t, e) { return y(e) ? Ye(() => t, e) : Ye(() => t); }
function It(...t) { let e = A(t); return l((r, o) => { Fe()(L([r, ...t], e)).subscribe(o); }); }
function Js(...t) { return It(...t); }
function jt(t) { return new S(e => t.subscribe(e)); }
var ur = { connector: () => new _ };
function Re(t, e = ur) { let { connector: r } = e; return l((o, n) => { let i = r(); a(t(jt(i))).subscribe(n), n.add(o.subscribe(i)); }); }
function sf(t) { return G((e, r, o) => !t || t(r, o) ? e + 1 : e, 0); }
function af(t) { return l((e, r) => { let o = !1, n = null, i = null, u = () => { if (i?.unsubscribe(), i = null, o) {
    o = !1;
    let f = n;
    n = null, r.next(f);
} }; e.subscribe(c(r, f => { i?.unsubscribe(), o = !0, n = f, i = c(r, u, g), a(t(f)).subscribe(i); }, () => { u(), r.complete(); }, void 0, () => { n = i = null; })); }); }
function yf(t, e = j) { return l((r, o) => { let n = null, i = null, u = null, f = () => { if (n) {
    n.unsubscribe(), n = null;
    let m = i;
    i = null, o.next(m);
} }; function s() { let m = u + t, p = e.now(); if (p < m) {
    n = this.schedule(void 0, m - p), o.add(n);
    return;
} f(); } r.subscribe(c(o, m => { i = m, u = e.now(), n || (n = e.schedule(s, t), o.add(n)); }, () => { f(), o.complete(); }, void 0, () => { i = n = null; })); }); }
function te(t) { return l((e, r) => { let o = !1; e.subscribe(c(r, n => { o = !0, r.next(n); }, () => { o || r.next(t), r.complete(); })); }); }
function Z(t) { return t <= 0 ? () => V : l((e, r) => { let o = 0; e.subscribe(c(r, n => { ++o <= t && (r.next(n), t <= o && r.complete()); })); }); }
function At() { return l((t, e) => { t.subscribe(c(e, g)); }); }
function Ft(t) { return R(() => t); }
function $e(t, e) { return e ? r => B(e.pipe(Z(1), At()), r.pipe($e(t))) : T((r, o) => a(t(r, o)).pipe(Z(1), Ft(r))); }
function qf(t, e = j) { let r = k(t, e); return $e(() => r); }
function Bf() { return l((t, e) => { t.subscribe(c(e, r => De(r, e))); }); }
function el(t, e) { return l((r, o) => { let n = new Set; r.subscribe(c(o, i => { let u = t ? t(i) : i; n.has(u) || (n.add(u), o.next(i)); })), e && a(e).subscribe(c(o, () => n.clear(), g)); }); }
function Tt(t, e = E) { return t = t ?? sr, l((r, o) => { let n, i = !0; r.subscribe(c(o, u => { let f = e(u); (i || !t(n, f)) && (i = !1, n = f, o.next(u)); })); }); }
function sr(t, e) { return t === e; }
function sl(t, e) { return Tt((r, o) => e ? e(r[t], o[t]) : r[t] === o[t]); }
function re(t = fr) { return l((e, r) => { let o = !1; e.subscribe(c(r, n => { o = !0, r.next(n); }, () => o ? r.complete() : r.error(t()))); }); }
function fr() { return new z; }
function yl(t, e) { if (t < 0)
    throw new Ue; let r = arguments.length >= 2; return o => o.pipe(q((n, i) => i === t), Z(1), r ? te(e) : re(() => new Ue)); }
function _l(...t) { return e => B(e, je(...t)); }
function Il(t, e) { return l((r, o) => { let n = 0; r.subscribe(c(o, i => { t.call(e, i, n++, r) || (o.next(!1), o.complete()); }, () => { o.next(!0), o.complete(); })); }); }
function Ke(t, e) { return e ? r => r.pipe(Ke((o, n) => a(t(o, n)).pipe(R((i, u) => e(o, i, n, u))))) : l((r, o) => { let n = 0, i = null, u = !1; r.subscribe(c(o, f => { i || (i = c(o, void 0, () => { i = null, u && o.complete(); }), a(t(f, n++)).subscribe(i)); }, () => { u = !0, !i && o.complete(); })); }); }
function Ct() { return Ke(E); }
var Ll = Ct;
function Ul(t, e = 1 / 0, r) { return e = (e || 0) < 1 ? 1 / 0 : e, l((o, n) => ee(o, n, t, e, void 0, !0, r)); }
function Gl(t) { return l((e, r) => { try {
    e.subscribe(r);
}
finally {
    r.add(t);
} }); }
function Bl(t, e) { return l(Be(t, e, "value")); }
function Be(t, e, r) { let o = r === "index"; return (n, i) => { let u = 0; n.subscribe(c(i, f => { let s = u++; t.call(e, f, s, n) && (i.next(o ? s : f), i.complete()); }, () => { i.next(o ? -1 : void 0), i.complete(); })); }; }
function Ql(t, e) { return l(Be(t, e, "index")); }
function uc(t, e) { let r = arguments.length >= 2; return o => o.pipe(t ? q((n, i) => t(n, i, o)) : E, Z(1), r ? te(e) : re(() => new z)); }
function ac(t, e, r, o) { return l((n, i) => { let u; !e || typeof e == "function" ? u = e : { duration: r, element: u, connector: o } = e; let f = new Map, s = d => { f.forEach(d), d(i); }, m = d => s(h => h.error(d)), p = 0, b = !1, w = new Y(i, d => { try {
    let h = t(d), v = f.get(h);
    if (!v) {
        f.set(h, v = o ? o() : new _);
        let O = x(h, v);
        if (i.next(O), r) {
            let M = c(v, () => { v.complete(), M?.unsubscribe(); }, void 0, void 0, () => f.delete(h));
            w.add(a(r(O)).subscribe(M));
        }
    }
    v.next(u ? u(d) : d);
}
catch (h) {
    m(h);
} }, () => s(d => d.complete()), m, () => f.clear(), () => (b = !0, p === 0)); n.subscribe(w); function x(d, h) { let v = new S(O => { p++; let M = h.subscribe(O); return () => { M.unsubscribe(), --p === 0 && b && w.unsubscribe(); }; }); return v.key = d, v; } }); }
function xc() { return l((t, e) => { t.subscribe(c(e, () => { e.next(!1), e.complete(); }, () => { e.next(!0), e.complete(); })); }); }
function Pt(t) { return t <= 0 ? () => V : l((e, r) => { let o = []; e.subscribe(c(r, n => { o.push(n), t < o.length && o.shift(); }, () => { for (let n of o)
    r.next(n); r.complete(); }, void 0, () => { o = null; })); }); }
function Fc(t, e) { let r = arguments.length >= 2; return o => o.pipe(t ? q((n, i) => t(n, i, o)) : E, Pt(1), r ? te(e) : re(() => new z)); }
function kc() { return l((t, e) => { t.subscribe(c(e, r => { e.next(U.createNext(r)); }, () => { e.next(U.createComplete()), e.complete(); }, r => { e.next(U.createError(r)), e.complete(); })); }); }
function Nc(t) { return G(y(t) ? (e, r) => t(e, r) > 0 ? e : r : (e, r) => e > r ? e : r); }
var Uc = T;
function Yc(t, e, r = 1 / 0) { return y(e) ? T(() => t, e, r) : (typeof e == "number" && (r = e), T(() => t, r)); }
function Zc(t, e, r = 1 / 0) { return l((o, n) => { let i = e; return ee(o, n, (u, f) => t(i, u, f), r, u => { i = u; }, !1, void 0, () => i = null); }); }
function Rt(...t) { let e = A(t), r = at(t, 1 / 0); return l((o, n) => { Ae(r)(L([o, ...t], e)).subscribe(n); }); }
function om(...t) { return Rt(...t); }
function sm(t) { return G(y(t) ? (e, r) => t(e, r) < 0 ? e : r : (e, r) => e < r ? e : r); }
function ke(t, e) { let r = y(t) ? t : () => t; return y(e) ? Re(e, { connector: r }) : o => new W(o, r); }
function lr(...t) { let e = N(t); return r => _t(r, ...e); }
var hm = lr;
function vm() { return l((t, e) => { let r, o = !1; t.subscribe(c(e, n => { let i = r; r = n, o && e.next([i, n]), o = !0; })); }); }
function _m(...t) { let e = t.length; if (e === 0)
    throw new Error("list of properties cannot be empty."); return R(r => { let o = r; for (let n = 0; n < e; n++) {
    let i = o?.[t[n]];
    if (typeof i < "u")
        o = i;
    else
        return;
} return o; }); }
function jm(t) { return t ? e => Re(t)(e) : e => ke(new _)(e); }
function Cm(t) { return e => { let r = new fe(t); return new W(e, () => r); }; }
function Mm() { return t => { let e = new le; return new W(t, () => e); }; }
function Dm(t, e, r, o) { r && !y(r) && (o = r); let n = y(r) ? r : void 0; return i => ke(new X(t, e, o), n)(i); }
function Ym(...t) { return t.length ? l((e, r) => { qe([e, ...t])(r); }) : E; }
function Qm(t) { let e = 1 / 0, r; return t != null && (typeof t == "object" ? { count: e = 1 / 0, delay: r } = t : e = t), e <= 0 ? () => V : l((o, n) => { let i = 0, u, f = () => { if (u?.unsubscribe(), u = null, r != null) {
    let m = typeof r == "number" ? k(r) : a(r(i)), p = c(n, () => { p.unsubscribe(), s(); });
    m.subscribe(p);
}
else
    s(); }, s = () => { let m = !1; u = o.subscribe(c(n, void 0, () => { ++i < e ? u ? f() : m = !0 : n.complete(); })), m && f(); }; s(); }); }
function np(t) { return l((e, r) => { let o, n = !1, i, u = !1, f = !1, s = () => f && u && (r.complete(), !0), m = () => (i || (i = new _, a(t(i)).subscribe(c(r, () => { o ? p() : n = !0; }, () => { u = !0, s(); }))), i), p = () => { f = !1, o = e.subscribe(c(r, void 0, () => { f = !0, !s() && m().next(); })), n && (o.unsubscribe(), o = null, n = !1, p()); }; p(); }); }
function mp(t = 1 / 0) { let e; t && typeof t == "object" ? e = t : e = { count: t }; let { count: r = 1 / 0, delay: o, resetOnSuccess: n = !1 } = e; return r <= 0 ? E : l((i, u) => { let f = 0, s, m = () => { let p = !1; s = i.subscribe(c(u, b => { n && (f = 0), u.next(b); }, void 0, b => { if (f++ < r) {
    let w = () => { s ? (s.unsubscribe(), s = null, m()) : p = !0; };
    if (o != null) {
        let x = typeof o == "number" ? k(o) : a(o(b, f)), d = c(u, () => { d.unsubscribe(), w(); }, () => { u.complete(); });
        x.subscribe(d);
    }
    else
        w();
}
else
    u.error(b); })), p && (s.unsubscribe(), s = null, m()); }; m(); }); }
function xp(t) { return l((e, r) => { let o, n = !1, i, u = () => { o = e.subscribe(c(r, void 0, void 0, f => { i || (i = new _, a(t(i)).subscribe(c(r, () => o ? u() : n = !0))), i && i.next(f); })), n && (o.unsubscribe(), o = null, n = !1, u()); }; u(); }); }
function kt(t) { return l((e, r) => { let o = !1, n = null; e.subscribe(c(r, i => { o = !0, n = i; })), a(t).subscribe(c(r, () => { if (o) {
    o = !1;
    let i = n;
    n = null, r.next(i);
} }, g)); }); }
function jp(t, e = j) { return kt(St(t, e)); }
function Cp(t, e) { return l(Ce(t, e, arguments.length >= 2, !0)); }
function Vp(t, e = (r, o) => r === o) { return l((r, o) => { let n = Mt(), i = Mt(), u = s => { o.next(s), o.complete(); }, f = (s, m) => { let p = c(o, b => { let { buffer: w, complete: x } = m; w.length === 0 ? x ? u(!1) : s.buffer.push(b) : !e(b, w.shift()) && u(!1); }, () => { s.complete = !0; let { complete: b, buffer: w } = m; b && u(w.length === 0), p?.unsubscribe(); }); return p; }; r.subscribe(f(n, i)), a(t).subscribe(f(i, n)); }); }
function Mt() { return { buffer: [], complete: !1 }; }
function Vt(t = {}) { let { connector: e = () => new _, resetOnError: r = !0, resetOnComplete: o = !0, resetOnRefCountZero: n = !0 } = t; return i => { let u, f, s, m = 0, p = !1, b = !1, w = () => { f?.unsubscribe(), f = void 0; }, x = () => { w(), u = s = void 0, p = b = !1; }, d = () => { let h = u; x(), h?.unsubscribe(); }; return l((h, v) => { m++, !b && !p && w(); let O = s = s ?? e(); v.add(() => { m--, m === 0 && !b && !p && (f = Ze(d, n)); }), O.subscribe(v), !u && m > 0 && (u = new Ve({ next: M => O.next(M), error: M => { b = !0, w(), f = Ze(x, r, M), O.error(M); }, complete: () => { p = !0, w(), f = Ze(x, o), O.complete(); } }), a(h).subscribe(u)); })(i); }; }
function Ze(t, e, ...r) { if (e === !0) {
    t();
    return;
} if (e === !1)
    return; let o = new Ve({ next: () => { o.unsubscribe(), t(); } }); return a(e(...r)).subscribe(o); }
function Yp(t, e, r) { let o, n = !1; return t && typeof t == "object" ? { bufferSize: o = 1 / 0, windowTime: e = 1 / 0, refCount: n = !1, scheduler: r } = t : o = t ?? 1 / 0, Vt({ connector: () => new X(o, e, r), resetOnError: !0, resetOnComplete: !1, resetOnRefCountZero: n }); }
function Qp(t) { return l((e, r) => { let o = !1, n, i = !1, u = 0; e.subscribe(c(r, f => { i = !0, (!t || t(f, u++, e)) && (o && r.error(new ht("Too many matching values")), o = !0, n = f); }, () => { o ? (r.next(n), r.complete()) : r.error(i ? new dt("No matching values") : new z); })); }); }
function ta(t) { return q((e, r) => t <= r); }
function ua(t) { return t <= 0 ? E : l((e, r) => { let o = new Array(t), n = 0; return e.subscribe(c(r, i => { let u = n++; if (u < t)
    o[u] = i;
else {
    let f = u % t, s = o[f];
    o[f] = i, r.next(s);
} })), () => { o = null; }; }); }
function pa(t) { return l((e, r) => { let o = !1, n = c(r, () => { n?.unsubscribe(), o = !0; }, g); a(t).subscribe(n), e.subscribe(c(r, i => o && r.next(i))); }); }
function ba(t) { return l((e, r) => { let o = !1, n = 0; e.subscribe(c(r, i => (o || (o = !t(i, n++))) && r.next(i))); }); }
function Sa(...t) { let e = A(t); return l((r, o) => { (e ? B(t, r, e) : B(t, r)).subscribe(o); }); }
function J(t, e) { return l((r, o) => { let n = null, i = 0, u = !1, f = () => u && !n && o.complete(); r.subscribe(c(o, s => { n?.unsubscribe(); let m = 0, p = i++; a(t(s, p)).subscribe(n = c(o, b => o.next(e ? e(s, b, p, m++) : b), () => { n = null, f(); })); }, () => { u = !0, f(); })); }); }
function Fa() { return J(E); }
function Ra(t, e) { return y(e) ? J(() => t, e) : J(() => t); }
function La(t, e) { return l((r, o) => { let n = e; return J((i, u) => t(n, i, u), (i, u) => (n = u, u))(r).subscribe(o), () => { n = null; }; }); }
function qa(t) { return l((e, r) => { a(t).subscribe(c(r, () => r.complete(), g)), !r.closed && e.subscribe(r); }); }
function Ka(t, e = !1) { return l((r, o) => { let n = 0; r.subscribe(c(o, i => { let u = t(i, n++); (u || e) && o.next(i), !u && o.complete(); })); }); }
function Ha(t, e, r) { let o = y(t) || e || r ? { next: t, error: e, complete: r } : t; return o ? l((n, i) => { var u; (u = o.subscribe) === null || u === void 0 || u.call(o); let f = !0; n.subscribe(c(i, s => { var m; (m = o.next) === null || m === void 0 || m.call(o, s), i.next(s); }, () => { var s; f = !1, (s = o.complete) === null || s === void 0 || s.call(o), i.complete(); }, s => { var m; f = !1, (m = o.error) === null || m === void 0 || m.call(o, s), i.error(s); }, () => { var s, m; f && ((s = o.unsubscribe) === null || s === void 0 || s.call(o)), (m = o.finalize) === null || m === void 0 || m.call(o); })); }) : E; }
function Lt(t, e) { return l((r, o) => { let { leading: n = !0, trailing: i = !1 } = e ?? {}, u = !1, f = null, s = null, m = !1, p = () => { s?.unsubscribe(), s = null, i && (x(), m && o.complete()); }, b = () => { s = null, m && o.complete(); }, w = d => s = a(t(d)).subscribe(c(o, p, b)), x = () => { if (u) {
    u = !1;
    let d = f;
    f = null, o.next(d), !m && w(d);
} }; r.subscribe(c(o, d => { u = !0, f = d, !(s && !s.closed) && (n ? x() : w(d)); }, () => { m = !0, !(i && u && s && !s.closed) && o.complete(); })); }); }
function fd(t, e = j, r) { let o = k(t, e); return Lt(() => o, r); }
function ad(t = j) { return l((e, r) => { let o = t.now(); e.subscribe(c(r, n => { let i = t.now(), u = i - o; o = i, r.next(new Je(n, u)); })); }); }
var Je = class {
    constructor(e, r) { this.value = e, this.interval = r; }
};
function yd(t, e, r) { let o, n, i; if (r = r ?? ae, Q(t) ? o = t : typeof t == "number" && (n = t), e)
    i = () => e;
else
    throw new TypeError("No observable provided to switch to"); if (o == null && n == null)
    throw new TypeError("No timeout provided."); return bt({ first: o, each: n, scheduler: r, with: i }); }
function _d(t = $) { return R(e => ({ value: e, timestamp: t.now() })); }
function Fd(t) { return l((e, r) => { let o = new _; r.next(o.asObservable()); let n = i => { o.error(i), r.error(i); }; return e.subscribe(c(r, i => o?.next(i), () => { o.complete(), r.complete(); }, n)), a(t).subscribe(c(r, () => { o.complete(), r.next(o = new _); }, g, n)), () => { o?.unsubscribe(), o = null; }; }); }
function kd(t, e = 0) { let r = e > 0 ? e : t; return l((o, n) => { let i = [new _], u = [], f = 0; n.next(i[0].asObservable()), o.subscribe(c(n, s => { for (let p of i)
    p.next(s); let m = f - t + 1; if (m >= 0 && m % r === 0 && i.shift().complete(), ++f % r === 0) {
    let p = new _;
    i.push(p), n.next(p.asObservable());
} }, () => { for (; i.length > 0;)
    i.shift().complete(); n.complete(); }, s => { for (; i.length > 0;)
    i.shift().error(s); n.error(s); }, () => { u = null, i = null; })); }); }
function Gd(t, ...e) { var r, o; let n = (r = A(e)) !== null && r !== void 0 ? r : j, i = (o = e[0]) !== null && o !== void 0 ? o : null, u = e[1] || 1 / 0; return l((f, s) => { let m = [], p = !1, b = h => { let { window: v, subs: O } = h; v.complete(), O.unsubscribe(), C(m, h), p && w(); }, w = () => { if (m) {
    let h = new F;
    s.add(h);
    let v = new _, O = { window: v, subs: h, seen: 0 };
    m.push(O), s.next(v.asObservable()), I(h, n, () => b(O), t);
} }; i !== null && i >= 0 ? I(s, n, w, i, !0) : p = !0, w(); let x = h => m.slice().forEach(h), d = h => { x(({ window: v }) => h(v)), h(s), s.unsubscribe(); }; return f.subscribe(c(s, h => { x(v => { v.window.next(h), u <= ++v.seen && b(v); }); }, () => d(h => h.complete()), h => d(v => v.error(h)))), () => { m = null; }; }); }
function Hd(t, e) { return l((r, o) => { let n = [], i = u => { for (; 0 < n.length;)
    n.shift().error(u); o.error(u); }; a(t).subscribe(c(o, u => { let f = new _; n.push(f); let s = new F, m = () => { C(n, f), f.complete(), s.unsubscribe(); }, p; try {
    p = a(e(u));
}
catch (b) {
    i(b);
    return;
} o.next(f.asObservable()), s.add(p.subscribe(c(o, m, g, i))); }, g)), r.subscribe(c(o, u => { let f = n.slice(); for (let s of f)
    s.next(u); }, () => { for (; 0 < n.length;)
    n.shift().complete(); o.complete(); }, i, () => { for (; 0 < n.length;)
    n.shift().unsubscribe(); })); }); }
function ih(t) { return l((e, r) => { let o, n, i = f => { o.error(f), r.error(f); }, u = () => { n?.unsubscribe(), o?.complete(), o = new _, r.next(o.asObservable()); let f; try {
    f = a(t());
}
catch (s) {
    i(s);
    return;
} f.subscribe(n = c(r, u, u, i)); }; u(), e.subscribe(c(r, f => o.next(f), () => { o.complete(), r.complete(); }, i, () => { n?.unsubscribe(), o = null; })); }); }
function ah(...t) { let e = D(t); return l((r, o) => { let n = t.length, i = new Array(n), u = t.map(() => !1), f = !1; for (let s = 0; s < n; s++)
    a(t[s]).subscribe(c(o, m => { i[s] = m, !f && !u[s] && (u[s] = !0, (f = u.every(E)) && (u = null)); }, g)); r.subscribe(c(o, s => { if (f) {
    let m = [s, ...i];
    o.next(e ? e(...m) : m);
} })); }); }
function xh(t) { return Pe(Te, t); }
function Nt(...t) { return l((e, r) => { Te(e, ...t).subscribe(r); }); }
function gh(...t) { return Nt(...t); }
function Eh(t, e) { return (r, o) => !t.call(e, r, o); }
export { c as a, et as b, W as c, tt as d, _ as e, fe as f, X as g, le as h, me as i, Ne as j, pe as k, j as l, ae as m, V as n, eo as o, Ie as p, D as q, A as r, at as s, be as t, a as u, de as v, he as w, ct as x, pt as y, L as z, je as A, Kt as B, U as C, z as D, Ue as E, dt as F, ht as G, Bt as H, bt as I, R as J, H as K, xt as L, yt as M, wt as N, T as O, Ae as P, Fe as Q, B as R, k as S, St as T, N as U, _t as V, Eh as W, q as X, iu as Y, Te as Z, gt as _, Su as $, ju as aa, Pu as ba, Uu as ca, Zu as da, ts as ea, nr as fa, G as ga, Ot as ha, Et as ia, Es as ja, Ge as ka, Ms as la, Ye as ma, zs as na, It as oa, Js as pa, Re as qa, sf as ra, af as sa, yf as ta, te as ua, Z as va, At as wa, Ft as xa, $e as ya, qf as za, Bf as Aa, el as Ba, Tt as Ca, sl as Da, re as Ea, yl as Fa, _l as Ga, Il as Ha, Ke as Ia, Ct as Ja, Ll as Ka, Ul as La, Gl as Ma, Bl as Na, Ql as Oa, uc as Pa, ac as Qa, xc as Ra, Pt as Sa, Fc as Ta, kc as Ua, Nc as Va, Uc as Wa, Yc as Xa, Zc as Ya, Rt as Za, om as _a, sm as $a, ke as ab, lr as bb, hm as cb, vm as db, _m as eb, jm as fb, Cm as gb, Mm as hb, Dm as ib, Ym as jb, Qm as kb, np as lb, mp as mb, xp as nb, kt as ob, jp as pb, Cp as qb, Vp as rb, Vt as sb, Yp as tb, Qp as ub, ta as vb, ua as wb, pa as xb, ba as yb, Sa as zb, J as Ab, Fa as Bb, Ra as Cb, La as Db, qa as Eb, Ka as Fb, Ha as Gb, Lt as Hb, fd as Ib, ad as Jb, yd as Kb, _d as Lb, Fd as Mb, kd as Nb, Gd as Ob, Hd as Pb, ih as Qb, ah as Rb, xh as Sb, Nt as Tb, gh as Ub };
