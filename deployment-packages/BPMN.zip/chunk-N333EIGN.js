import { b as N } from "@nf-internal/chunk-7NZLVDTY";
import { b as D, d as S } from "@nf-internal/chunk-FZNAMQAG";
import { b as M } from "@nf-internal/chunk-PACPXHXL";
import { a as L, b as k } from "@nf-internal/chunk-TT7XXVKE";
import { a as v } from "@nf-internal/chunk-P7VGBIY2";
import { a as d } from "@nf-internal/chunk-DQ6Z6NC4";
import { b as I, c as O, d as f } from "@nf-internal/chunk-PGIYYMTQ";
import { c as m } from "@nf-internal/chunk-MQ6KVUBG";
import { f as Y, g as J, h as Q, ka as ee, kb as te } from "@nf-internal/chunk-VJYBASWG";
import { a as T } from "@nf-internal/chunk-2NFLSA4Y";
import * as _ from "@angular/core";
import { InjectionToken as R, inject as u, NgZone as B, DOCUMENT as H, RendererFactory2 as ne, ElementRef as ie, EventEmitter as oe } from "@angular/core";
import { BehaviorSubject as se, Subject as x, of as re } from "rxjs";
import { skip as ce, distinctUntilChanged as ae, takeUntil as ue } from "rxjs/operators";
var le = new R("cdk-input-modality-detector-options"), de = { ignoreKeys: [18, 17, 224, 91, 16] }, P = 650, y = { passive: !0, capture: !0 }, he = (() => { class n {
    _platform = u(d);
    _listenerCleanups;
    modalityDetected;
    modalityChanged;
    get mostRecentModality() { return this._modality.value; }
    _mostRecentTarget = null;
    _modality = new se(null);
    _options;
    _lastTouchMs = 0;
    _onKeydown = e => { this._options?.ignoreKeys?.some(t => t === e.keyCode) || (this._modality.next("keyboard"), this._mostRecentTarget = f(e)); };
    _onMousedown = e => { Date.now() - this._lastTouchMs < P || (this._modality.next(L(e) ? "keyboard" : "mouse"), this._mostRecentTarget = f(e)); };
    _onTouchstart = e => { if (k(e)) {
        this._modality.next("keyboard");
        return;
    } this._lastTouchMs = Date.now(), this._modality.next("touch"), this._mostRecentTarget = f(e); };
    constructor() { let e = u(B), t = u(H), i = u(le, { optional: !0 }); if (this._options = T(T({}, de), i), this.modalityDetected = this._modality.pipe(ce(1)), this.modalityChanged = this.modalityDetected.pipe(ae()), this._platform.isBrowser) {
        let s = u(ne).createRenderer(null, null);
        this._listenerCleanups = e.runOutsideAngular(() => [s.listen(t, "keydown", this._onKeydown, y), s.listen(t, "mousedown", this._onMousedown, y), s.listen(t, "touchstart", this._onTouchstart, y)]);
    } }
    ngOnDestroy() { this._modality.complete(), this._listenerCleanups?.forEach(e => e()); }
    static \u0275fac = function (t) { return new (t || n); };
    static \u0275prov = _.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })(), b = (function (n) { return n[n.IMMEDIATE = 0] = "IMMEDIATE", n[n.EVENTUAL = 1] = "EVENTUAL", n; })(b || {}), fe = new R("cdk-focus-monitor-default-options"), p = M({ passive: !0, capture: !0 }), _e = (() => { class n {
    _ngZone = u(B);
    _platform = u(d);
    _inputModalityDetector = u(he);
    _origin = null;
    _lastFocusOrigin = null;
    _windowFocused = !1;
    _windowFocusTimeoutId;
    _originTimeoutId;
    _originFromTouchInteraction = !1;
    _elementInfo = new Map;
    _monitoredElementCount = 0;
    _rootNodeFocusListenerCount = new Map;
    _detectionMode;
    _windowFocusListener = () => { this._windowFocused = !0, this._windowFocusTimeoutId = setTimeout(() => this._windowFocused = !1); };
    _document = u(H);
    _stopInputModalityDetector = new x;
    constructor() { let e = u(fe, { optional: !0 }); this._detectionMode = e?.detectionMode || b.IMMEDIATE; }
    _rootNodeFocusAndBlurListener = e => { let t = f(e); for (let i = t; i; i = i.parentElement)
        e.type === "focus" ? this._onFocus(e, i) : this._onBlur(e, i); };
    monitor(e, t = !1) { let i = m(e); if (!this._platform.isBrowser || i.nodeType !== 1)
        return re(); let s = I(i) || this._document, c = this._elementInfo.get(i); if (c)
        return t && (c.checkChildren = !0), c.subject; let l = { checkChildren: t, subject: new x, rootNode: s }; return this._elementInfo.set(i, l), this._registerGlobalListeners(l), l.subject; }
    stopMonitoring(e) { let t = m(e), i = this._elementInfo.get(t); i && (i.subject.complete(), this._setClasses(t), this._elementInfo.delete(t), this._removeGlobalListeners(i)); }
    focusVia(e, t, i) { let s = m(e), c = this._document.activeElement; s === c ? this._getClosestElementsInfo(s).forEach(([l, X]) => this._originChanged(l, t, X)) : (this._setOrigin(t), typeof s.focus == "function" && s.focus(i)); }
    ngOnDestroy() { this._elementInfo.forEach((e, t) => this.stopMonitoring(t)); }
    _getWindow() { return this._document.defaultView || window; }
    _getFocusOrigin(e) { return this._origin ? this._originFromTouchInteraction ? this._shouldBeAttributedToTouch(e) ? "touch" : "program" : this._origin : this._windowFocused && this._lastFocusOrigin ? this._lastFocusOrigin : e && this._isLastInteractionFromInputLabel(e) ? "mouse" : "program"; }
    _shouldBeAttributedToTouch(e) { return this._detectionMode === b.EVENTUAL || !!e?.contains(this._inputModalityDetector._mostRecentTarget); }
    _setClasses(e, t) { e.classList.toggle("cdk-focused", !!t), e.classList.toggle("cdk-touch-focused", t === "touch"), e.classList.toggle("cdk-keyboard-focused", t === "keyboard"), e.classList.toggle("cdk-mouse-focused", t === "mouse"), e.classList.toggle("cdk-program-focused", t === "program"); }
    _setOrigin(e, t = !1) { this._ngZone.runOutsideAngular(() => { if (this._origin = e, this._originFromTouchInteraction = e === "touch" && t, this._detectionMode === b.IMMEDIATE) {
        clearTimeout(this._originTimeoutId);
        let i = this._originFromTouchInteraction ? P : 1;
        this._originTimeoutId = setTimeout(() => this._origin = null, i);
    } }); }
    _onFocus(e, t) { let i = this._elementInfo.get(t), s = f(e); !i || !i.checkChildren && t !== s || this._originChanged(t, this._getFocusOrigin(s), i); }
    _onBlur(e, t) { let i = this._elementInfo.get(t); !i || i.checkChildren && e.relatedTarget instanceof Node && t.contains(e.relatedTarget) || (this._setClasses(t), this._emitOrigin(i, null)); }
    _emitOrigin(e, t) { e.subject.observers.length && this._ngZone.run(() => e.subject.next(t)); }
    _registerGlobalListeners(e) { if (!this._platform.isBrowser)
        return; let t = e.rootNode, i = this._rootNodeFocusListenerCount.get(t) || 0; i || this._ngZone.runOutsideAngular(() => { t.addEventListener("focus", this._rootNodeFocusAndBlurListener, p), t.addEventListener("blur", this._rootNodeFocusAndBlurListener, p); }), this._rootNodeFocusListenerCount.set(t, i + 1), ++this._monitoredElementCount === 1 && (this._ngZone.runOutsideAngular(() => { this._getWindow().addEventListener("focus", this._windowFocusListener); }), this._inputModalityDetector.modalityDetected.pipe(ue(this._stopInputModalityDetector)).subscribe(s => { this._setOrigin(s, !0); })); }
    _removeGlobalListeners(e) { let t = e.rootNode; if (this._rootNodeFocusListenerCount.has(t)) {
        let i = this._rootNodeFocusListenerCount.get(t);
        i > 1 ? this._rootNodeFocusListenerCount.set(t, i - 1) : (t.removeEventListener("focus", this._rootNodeFocusAndBlurListener, p), t.removeEventListener("blur", this._rootNodeFocusAndBlurListener, p), this._rootNodeFocusListenerCount.delete(t));
    } --this._monitoredElementCount || (this._getWindow().removeEventListener("focus", this._windowFocusListener), this._stopInputModalityDetector.next(), clearTimeout(this._windowFocusTimeoutId), clearTimeout(this._originTimeoutId)); }
    _originChanged(e, t, i) { this._setClasses(e, t), this._emitOrigin(i, t), this._lastFocusOrigin = t; }
    _getClosestElementsInfo(e) { let t = []; return this._elementInfo.forEach((i, s) => { (s === e || i.checkChildren && s.contains(e)) && t.push([s, i]); }), t; }
    _isLastInteractionFromInputLabel(e) { let { _mostRecentTarget: t, mostRecentModality: i } = this._inputModalityDetector; if (i !== "mouse" || !t || t === e || e.nodeName !== "INPUT" && e.nodeName !== "TEXTAREA" || e.disabled)
        return !1; let s = e.labels; if (s) {
        for (let c = 0; c < s.length; c++)
            if (s[c].contains(t))
                return !0;
    } return !1; }
    static \u0275fac = function (t) { return new (t || n); };
    static \u0275prov = _.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })(), qe = (() => { class n {
    _elementRef = u(ie);
    _focusMonitor = u(_e);
    _monitorSubscription;
    _focusOrigin = null;
    cdkFocusChange = new oe;
    get focusOrigin() { return this._focusOrigin; }
    ngAfterViewInit() { let e = this._elementRef.nativeElement; this._monitorSubscription = this._focusMonitor.monitor(e, e.nodeType === 1 && e.hasAttribute("cdkMonitorSubtreeFocus")).subscribe(t => { this._focusOrigin = t, this.cdkFocusChange.emit(t); }); }
    ngOnDestroy() { this._focusMonitor.stopMonitoring(this._elementRef), this._monitorSubscription?.unsubscribe(); }
    static \u0275fac = function (t) { return new (t || n); };
    static \u0275dir = _.\u0275\u0275defineDirective({ type: n, selectors: [["", "cdkMonitorElementFocus", ""], ["", "cdkMonitorSubtreeFocus", ""]], outputs: { cdkFocusChange: "cdkFocusChange" }, exportAs: ["cdkMonitorFocus"] });
} return n; })();
import * as V from "@angular/core";
import { SecurityContext as me } from "@angular/core";
var E = (() => {
    class n {
        static \u0275fac = function (t) { return new (t || n); };
        static \u0275cmp = V.\u0275\u0275defineComponent({ type: n, selectors: [["ng-component"]], exportAs: ["cdkVisuallyHidden"], decls: 0, vars: 0, template: function (t, i) { }, styles: [`.cdk-visually-hidden {
  border: 0;
  clip: rect(0 0 0 0);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
  white-space: nowrap;
  outline: 0;
  -webkit-appearance: none;
  -moz-appearance: none;
  left: 0;
}
[dir=rtl] .cdk-visually-hidden {
  left: auto;
  right: 0;
}
`], encapsulation: 2 });
    }
    return n;
})(), g;
function pe() { if (g === void 0 && (g = null, typeof window < "u")) {
    let n = window;
    if (n.trustedTypes !== void 0)
        try {
            g = n.trustedTypes.createPolicy("angular#components", { createHTML: o => o });
        }
        catch (o) {
            console.error(o);
        }
} return g; }
function be(n) { return pe()?.createHTML(n) || n; }
function W(n, o, e) { let t = e.sanitize(me.HTML, o); n.innerHTML = be(t || ""); }
import * as a from "@angular/core";
import { inject as r, ElementRef as z, booleanAttribute as j, afterNextRender as ge, NgZone as w, DOCUMENT as F, Injector as Te, InjectionToken as G } from "@angular/core";
import { DomSanitizer as ve } from "@angular/platform-browser";
var U = class {
    ignoreVisibility = !1;
}, ye = (() => { class n {
    _platform = r(d);
    isDisabled(e) { return e.hasAttribute("disabled"); }
    isVisible(e) { return Ae(e) && getComputedStyle(e).visibility === "visible"; }
    isTabbable(e) { if (!this._platform.isBrowser)
        return !1; let t = Ee(Me(e)); if (t && (Z(t) === -1 || !this.isVisible(t)))
        return !1; let i = e.nodeName.toLowerCase(), s = Z(e); return e.hasAttribute("contenteditable") ? s !== -1 : i === "iframe" || i === "object" || this._platform.WEBKIT && this._platform.IOS && !Ie(e) ? !1 : i === "audio" ? e.hasAttribute("controls") ? s !== -1 : !1 : i === "video" ? s === -1 ? !1 : s !== null ? !0 : this._platform.FIREFOX || e.hasAttribute("controls") : e.tabIndex >= 0; }
    isFocusable(e, t) { return Oe(e) && !this.isDisabled(e) && (t?.ignoreVisibility || this.isVisible(e)); }
    static \u0275fac = function (t) { return new (t || n); };
    static \u0275prov = a.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })();
function Ee(n) { try {
    return n.frameElement;
}
catch {
    return null;
} }
function Ae(n) { return !!(n.offsetWidth || n.offsetHeight || typeof n.getClientRects == "function" && n.getClientRects().length); }
function Ce(n) { let o = n.nodeName.toLowerCase(); return o === "input" || o === "select" || o === "button" || o === "textarea"; }
function we(n) { return Le(n) && n.type == "hidden"; }
function Fe(n) { return ke(n) && n.hasAttribute("href"); }
function Le(n) { return n.nodeName.toLowerCase() == "input"; }
function ke(n) { return n.nodeName.toLowerCase() == "a"; }
function q(n) { if (!n.hasAttribute("tabindex") || n.tabIndex === void 0)
    return !1; let o = n.getAttribute("tabindex"); return !!(o && !isNaN(parseInt(o, 10))); }
function Z(n) { if (!q(n))
    return null; let o = parseInt(n.getAttribute("tabindex") || "", 10); return isNaN(o) ? -1 : o; }
function Ie(n) { let o = n.nodeName.toLowerCase(), e = o === "input" && n.type; return e === "text" || e === "password" || o === "select" || o === "textarea"; }
function Oe(n) { return we(n) ? !1 : Ce(n) || Fe(n) || n.hasAttribute("contenteditable") || q(n); }
function Me(n) { return n.ownerDocument && n.ownerDocument.defaultView || window; }
var C = class {
    _element;
    _checker;
    _ngZone;
    _document;
    _injector;
    _startAnchor = null;
    _endAnchor = null;
    _hasAttached = !1;
    startAnchorListener = () => { !this.focusLastTabbableElement() && this._checker.isFocusable(this._element) && this._element.focus(); };
    endAnchorListener = () => { !this.focusFirstTabbableElement() && this._checker.isFocusable(this._element) && this._element.focus(); };
    get enabled() { return this._enabled; }
    set enabled(o) { this._enabled = o, this._startAnchor && this._endAnchor && (this._toggleAnchorTabIndex(o, this._startAnchor), this._toggleAnchorTabIndex(o, this._endAnchor)); }
    _enabled = !0;
    constructor(o, e, t, i, s = !1, c) { this._element = o, this._checker = e, this._ngZone = t, this._document = i, this._injector = c, s || this.attachAnchors(); }
    destroy() { let o = this._startAnchor, e = this._endAnchor; o && (o.removeEventListener("focus", this.startAnchorListener), o.remove()), e && (e.removeEventListener("focus", this.endAnchorListener), e.remove()), this._startAnchor = this._endAnchor = null, this._hasAttached = !1; }
    attachAnchors() { return this._hasAttached ? !0 : (this._ngZone.runOutsideAngular(() => { this._startAnchor || (this._startAnchor = this._createAnchor(), this._startAnchor.addEventListener("focus", this.startAnchorListener)), this._endAnchor || (this._endAnchor = this._createAnchor(), this._endAnchor.addEventListener("focus", this.endAnchorListener)); }), this._element.parentNode && (this._element.parentNode.insertBefore(this._startAnchor, this._element), this._element.parentNode.insertBefore(this._endAnchor, this._element.nextSibling), this._hasAttached = !0), this._hasAttached); }
    focusInitialElementWhenReady(o) { return new Promise(e => { this._executeOnStable(() => e(this.focusInitialElement(o))); }); }
    focusFirstTabbableElementWhenReady(o) { return new Promise(e => { this._executeOnStable(() => e(this.focusFirstTabbableElement(o))); }); }
    focusLastTabbableElementWhenReady(o) { return new Promise(e => { this._executeOnStable(() => e(this.focusLastTabbableElement(o))); }); }
    _getRegionBoundary(o) { let e = this._element.querySelectorAll(`[cdk-focus-region-${o}], [cdkFocusRegion${o}], [cdk-focus-${o}]`); return o == "start" ? e.length ? e[0] : this._getFirstTabbableElement(this._element) : e.length ? e[e.length - 1] : this._getLastTabbableElement(this._element); }
    focusInitialElement(o) { let e = this._element.querySelector("[cdk-focus-initial], [cdkFocusInitial]"); if (e) {
        if (!this._checker.isFocusable(e)) {
            let t = this._getFirstTabbableElement(e);
            return t?.focus(o), !!t;
        }
        return e.focus(o), !0;
    } return this.focusFirstTabbableElement(o); }
    focusFirstTabbableElement(o) { let e = this._getRegionBoundary("start"); return e && e.focus(o), !!e; }
    focusLastTabbableElement(o) { let e = this._getRegionBoundary("end"); return e && e.focus(o), !!e; }
    hasAttached() { return this._hasAttached; }
    _getFirstTabbableElement(o) { if (this._checker.isFocusable(o) && this._checker.isTabbable(o))
        return o; let e = o.children; for (let t = 0; t < e.length; t++) {
        let i = e[t].nodeType === this._document.ELEMENT_NODE ? this._getFirstTabbableElement(e[t]) : null;
        if (i)
            return i;
    } return null; }
    _getLastTabbableElement(o) { if (this._checker.isFocusable(o) && this._checker.isTabbable(o))
        return o; let e = o.children; for (let t = e.length - 1; t >= 0; t--) {
        let i = e[t].nodeType === this._document.ELEMENT_NODE ? this._getLastTabbableElement(e[t]) : null;
        if (i)
            return i;
    } return null; }
    _createAnchor() { let o = this._document.createElement("div"); return this._toggleAnchorTabIndex(this._enabled, o), o.classList.add("cdk-visually-hidden"), o.classList.add("cdk-focus-trap-anchor"), o.setAttribute("aria-hidden", "true"), o; }
    _toggleAnchorTabIndex(o, e) { o ? e.setAttribute("tabindex", "0") : e.removeAttribute("tabindex"); }
    toggleAnchors(o) { this._startAnchor && this._endAnchor && (this._toggleAnchorTabIndex(o, this._startAnchor), this._toggleAnchorTabIndex(o, this._endAnchor)); }
    _executeOnStable(o) { ge(o, { injector: this._injector }); }
}, Ne = (() => { class n {
    _checker = r(ye);
    _ngZone = r(w);
    _document = r(F);
    _injector = r(Te);
    constructor() { r(v).load(E); }
    create(e, t = !1) { return new C(e, this._checker, this._ngZone, this._document, t, this._injector); }
    static \u0275fac = function (t) { return new (t || n); };
    static \u0275prov = a.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })(), _t = (() => { class n {
    _elementRef = r(z);
    _focusTrapFactory = r(Ne);
    focusTrap = void 0;
    _previouslyFocusedElement = null;
    get enabled() { return this.focusTrap?.enabled || !1; }
    set enabled(e) { this.focusTrap && (this.focusTrap.enabled = e); }
    autoCapture = !1;
    constructor() { r(d).isBrowser && (this.focusTrap = this._focusTrapFactory.create(this._elementRef.nativeElement, !0)); }
    ngOnDestroy() { this.focusTrap?.destroy(), this._previouslyFocusedElement && (this._previouslyFocusedElement.focus(), this._previouslyFocusedElement = null); }
    ngAfterContentInit() { this.focusTrap?.attachAnchors(), this.autoCapture && this._captureFocus(); }
    ngDoCheck() { this.focusTrap && !this.focusTrap.hasAttached() && this.focusTrap.attachAnchors(); }
    ngOnChanges(e) { let t = e.autoCapture; t && !t.firstChange && this.autoCapture && this.focusTrap?.hasAttached() && this._captureFocus(); }
    _captureFocus() { this._previouslyFocusedElement = O(), this.focusTrap?.focusInitialElementWhenReady(); }
    static \u0275fac = function (t) { return new (t || n); };
    static \u0275dir = a.\u0275\u0275defineDirective({ type: n, selectors: [["", "cdkTrapFocus", ""]], inputs: { enabled: [2, "cdkTrapFocus", "enabled", j], autoCapture: [2, "cdkTrapFocusAutoCapture", "autoCapture", j] }, exportAs: ["cdkTrapFocus"], features: [a.\u0275\u0275NgOnChangesFeature] });
} return n; })(), De = new G("liveAnnouncerElement", { providedIn: "root", factory: () => null }), Se = new G("LIVE_ANNOUNCER_DEFAULT_OPTIONS"), xe = 0, Re = (() => { class n {
    _ngZone = r(w);
    _defaultOptions = r(Se, { optional: !0 });
    _liveElement;
    _document = r(F);
    _sanitizer = r(ve);
    _previousTimeout;
    _currentPromise;
    _currentResolve;
    constructor() { let e = r(De, { optional: !0 }); this._liveElement = e || this._createLiveElement(); }
    announce(e, ...t) { let i = this._defaultOptions, s, c; return t.length === 1 && typeof t[0] == "number" ? c = t[0] : [s, c] = t, this.clear(), clearTimeout(this._previousTimeout), s || (s = i && i.politeness ? i.politeness : "polite"), c == null && i && (c = i.duration), this._liveElement.setAttribute("aria-live", s), this._liveElement.id && this._exposeAnnouncerToModals(this._liveElement.id), this._ngZone.runOutsideAngular(() => (this._currentPromise || (this._currentPromise = new Promise(l => this._currentResolve = l)), clearTimeout(this._previousTimeout), this._previousTimeout = setTimeout(() => { !e || typeof e == "string" ? this._liveElement.textContent = e : W(this._liveElement, e, this._sanitizer), typeof c == "number" && (this._previousTimeout = setTimeout(() => this.clear(), c)), this._currentResolve?.(), this._currentPromise = this._currentResolve = void 0; }, 100), this._currentPromise)); }
    clear() { this._liveElement && (this._liveElement.textContent = ""); }
    ngOnDestroy() { clearTimeout(this._previousTimeout), this._liveElement?.remove(), this._liveElement = null, this._currentResolve?.(), this._currentPromise = this._currentResolve = void 0; }
    _createLiveElement() { let e = "cdk-live-announcer-element", t = this._document.getElementsByClassName(e), i = this._document.createElement("div"); for (let s = 0; s < t.length; s++)
        t[s].remove(); return i.classList.add(e), i.classList.add("cdk-visually-hidden"), i.setAttribute("aria-atomic", "true"), i.setAttribute("aria-live", "polite"), i.id = `cdk-live-announcer-${xe++}`, this._document.body.appendChild(i), i; }
    _exposeAnnouncerToModals(e) { let t = this._document.querySelectorAll('body > .cdk-overlay-container [aria-modal="true"]'); for (let i = 0; i < t.length; i++) {
        let s = t[i], c = s.getAttribute("aria-owns");
        c ? c.indexOf(e) === -1 && s.setAttribute("aria-owns", c + " " + e) : s.setAttribute("aria-owns", e);
    } }
    static \u0275fac = function (t) { return new (t || n); };
    static \u0275prov = a.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })(), mt = (() => { class n {
    _elementRef = r(z);
    _liveAnnouncer = r(Re);
    _contentObserver = r(D);
    _ngZone = r(w);
    get politeness() { return this._politeness; }
    set politeness(e) { this._politeness = e === "off" || e === "assertive" ? e : "polite", this._politeness === "off" ? this._subscription && (this._subscription.unsubscribe(), this._subscription = void 0) : this._subscription || (this._subscription = this._ngZone.runOutsideAngular(() => this._contentObserver.observe(this._elementRef).subscribe(() => { let t = this._elementRef.nativeElement.textContent; t !== this._previousAnnouncedText && (this._liveAnnouncer.announce(t, this._politeness, this.duration), this._previousAnnouncedText = t); }))); }
    _politeness = "polite";
    duration;
    _previousAnnouncedText;
    _subscription;
    constructor() { r(v).load(E); }
    ngOnDestroy() { this._subscription?.unsubscribe(); }
    static \u0275fac = function (t) { return new (t || n); };
    static \u0275dir = a.\u0275\u0275defineDirective({ type: n, selectors: [["", "cdkAriaLive", ""]], inputs: { politeness: [0, "cdkAriaLive", "politeness"], duration: [0, "cdkAriaLiveDuration", "duration"] }, exportAs: ["cdkAriaLive"] });
} return n; })(), h = (function (n) { return n[n.NONE = 0] = "NONE", n[n.BLACK_ON_WHITE = 1] = "BLACK_ON_WHITE", n[n.WHITE_ON_BLACK = 2] = "WHITE_ON_BLACK", n; })(h || {}), K = "cdk-high-contrast-black-on-white", $ = "cdk-high-contrast-white-on-black", A = "cdk-high-contrast-active", Be = (() => { class n {
    _platform = r(d);
    _hasCheckedHighContrastMode = !1;
    _document = r(F);
    _breakpointSubscription;
    constructor() { this._breakpointSubscription = r(N).observe("(forced-colors: active)").subscribe(() => { this._hasCheckedHighContrastMode && (this._hasCheckedHighContrastMode = !1, this._applyBodyHighContrastModeCssClasses()); }); }
    getHighContrastMode() { if (!this._platform.isBrowser)
        return h.NONE; let e = this._document.createElement("div"); e.style.backgroundColor = "rgb(1,2,3)", e.style.position = "absolute", this._document.body.appendChild(e); let t = this._document.defaultView || window, i = t && t.getComputedStyle ? t.getComputedStyle(e) : null, s = (i && i.backgroundColor || "").replace(/ /g, ""); switch (e.remove(), s) {
        case "rgb(0,0,0)":
        case "rgb(45,50,54)":
        case "rgb(32,32,32)": return h.WHITE_ON_BLACK;
        case "rgb(255,255,255)":
        case "rgb(255,250,239)": return h.BLACK_ON_WHITE;
    } return h.NONE; }
    ngOnDestroy() { this._breakpointSubscription.unsubscribe(); }
    _applyBodyHighContrastModeCssClasses() { if (!this._hasCheckedHighContrastMode && this._platform.isBrowser && this._document.body) {
        let e = this._document.body.classList;
        e.remove(A, K, $), this._hasCheckedHighContrastMode = !0;
        let t = this.getHighContrastMode();
        t === h.BLACK_ON_WHITE ? e.add(A, K) : t === h.WHITE_ON_BLACK && e.add(A, $);
    } }
    static \u0275fac = function (t) { return new (t || n); };
    static \u0275prov = a.\u0275\u0275defineService({ token: n, factory: n.\u0275fac });
} return n; })(), pt = (() => { class n {
    constructor() { r(Be)._applyBodyHighContrastModeCssClasses(); }
    static \u0275fac = function (t) { return new (t || n); };
    static \u0275mod = a.\u0275\u0275defineNgModule({ type: n });
    static \u0275inj = a.\u0275\u0275defineInjector({ imports: [S] });
} return n; })();
export { le as a, de as b, he as c, b as d, fe as e, _e as f, qe as g, E as h, U as i, ye as j, C as k, Ne as l, _t as m, De as n, Se as o, Re as p, mt as q, h as r, Be as s, pt as t };
