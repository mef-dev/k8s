# Pipeline Insight

Pipeline Insight is the record of what the agents actually did. Every call — agent to agent, agent to tool, agent to a hosted model — is written down and tied back to the request that caused it, together with what authorised it and what it cost.

This is not sampled telemetry that may be dropped when the system is busy. It is the chain that answers *prove it did the right thing*, which is a different obligation from knowing that a service was slow.

## What it solves

- Answering a regulator or an internal audit: one request expands into the full sequence of calls made under it, with the authorisation for each.
- Explaining an outcome nobody expected: the trace shows which agent was selected, on what grounds, and what it was permitted to do.
- Knowing what autonomy costs: tokens, price and latency are recorded per call, so the cost of a process is a number rather than an estimate.
- Reviewing before widening autonomy: an operator can see how a step behaved across many runs before removing a human approval.

## What a trace carries

- The correlation tying one intent to every call made under it.
- The sign, verify and execute steps in the order they happened.
- The edge, policy and token that authorised the transition.
- Cost, token counts and latency per call.

## Dependencies

Deployed into namespace `ai`. It records what the fabric does, so it is installed alongside namespace `fabric` — but agents do not change behaviour because it is present, and the fabric runs without it.

- Namespace `ai` — required.
- Namespace `fabric` — expected in practice: without it there are no agent calls to record.
- **Pipeline Insight Console** — its pages; optional if the records are read through the API.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
