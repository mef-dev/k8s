# Agent Sessions

Agent Sessions holds the state of work that does not finish in one request. A telecom process runs for minutes, hours or weeks — it waits for a field visit, for an approval, for a batch window — and the agents driving it must be able to stop and pick up exactly where they left off.

The state is durable and scoped per tenant, so a restart, a deployment or a failure does not cost the work already done, and one organisation's sessions are never visible to another.

## What it solves

- Surviving restarts: a process that was mid-flight when a service was redeployed resumes from its last recorded point instead of starting over.
- Waiting without holding resources: a session parked on an approval or a maintenance window costs storage, not a live connection.
- Keeping context across a long process: what an agent established at step two is still available at step nine, days later.
- Isolating tenants: sessions carry their organisation, so a shared deployment cannot leak state between tenants.

## What a session carries

- The resume point: where execution stopped and what it was waiting for.
- The accumulated context the next step needs.
- The tenant the session belongs to.
- The correlation that ties the session to the calls made under it.

## Dependencies

Deployed into namespace `ai`, the base layer.

- Namespace `ai` — required; it depends on no namespace above it.
- **Fabric-T Runtime** — expected in practice: sessions exist because agents run long processes. The component itself does not require it.
- **Pipeline Insight** — optional: it correlates the calls made under a session with the session itself.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
