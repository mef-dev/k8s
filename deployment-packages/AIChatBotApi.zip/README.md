# Platform Assistant

Platform Assistant is the engine behind the chat. It takes the person's question, works out what to put in front of the model, calls the model, and streams the answer back with its sources.

Deciding what to send is the whole job. A model answers well when it is given the right entities and the right passages, and badly when it is given a wall of text or nothing at all. That selection — and the budget it has to fit into — is what this component does.

## What it solves

- Answers about the operator's environment instead of general knowledge: the question is first grounded against the entities in **Knowledge Graph**, so the answer is about *this* network, not about networks in general.
- Citable answers: document passages are retrieved with the offsets needed to point at them, so an answer can carry its evidence.
- Predictable cost: context is assembled inside a token budget, with the oldest conversation turns dropped first, instead of growing until a request is refused.
- One integration instead of many: the model provider is configured once at namespace level and changed without touching the assistant.

## How it works

The request is grounded against graph entities, relevant document chunks are retrieved, conversation history is added up to the budget, and the composed request goes to **Model Gateway**. The response is streamed back as it arrives.

## Dependencies

Deployed into namespace `ai`. The assistant composes an answer from other services of that namespace and cannot produce one alone.

- **Model Gateway** — required: the model call itself.
- **Knowledge Graph** — required: grounding the question in operator entities.
- **Conversations** — required: conversation history between turns.
- **Assistant Console** — the user interface; optional if the assistant is called from a process instead of by a person.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
