# Fabric-T Console

Fabric-T Console is the set of pages where a person manages the agent layer: registers an agent, reviews what it declares, tries a real request against it, and inspects the processes agents run within.

It is a working surface rather than a dashboard. Onboarding an agent, correcting its profile, binding a structured prompt to a process step and testing the result happen in the same place, without a deployment in between.

## What it solves

- Onboarding an agent without code: identity, skills, tags and tool bindings are entered and reviewed on screen.
- Seeing why an agent was or was not selected: state an intent in free form and watch grounding, filtering and ranking produce the candidate list.
- Checking a vendor's claims before trusting them: what the agent declares is visible next to what the operator permits.
- Keeping process and prompt together: the structured prompt bound to a step is edited where the step is defined.

## Dependencies

Fabric-T Console is a user interface and does nothing on its own. It requires namespace `fabric` with **Fabric-T Runtime** in it — and because `fabric` requires `ai`, the ai layer must be deployed underneath.

- Namespace `fabric` — required.
- **Fabric-T Runtime** — required.
- Namespace `ai` — required underneath, for grounding and model access.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
