# Assistant Console

Assistant Console is a chat window. A person opens it inside the platform, asks a question in plain language about the operator's own environment, and reads the answer with the sources it was built from shown alongside it.

It looks like any chat, and that is the point: no query language, no report builder, no ticket to the team that owns the data. The difference is underneath — the answer is assembled from the operator's entities and documents, not from what a model happens to remember.

## What it solves

- An engineer needs a fact that lives in three systems — the catalog, the inventory and a PDF of the last change window. Asking once beats opening three consoles and correlating by hand.
- An analyst wants to know *why* the answer says what it says. Every statement shows the entity or the passage it rests on, so the answer can be checked instead of trusted.
- Yesterday's investigation continues today. Threads and folders survive the session, so a line of questioning is not retyped from memory.
- A team needs to know whether the assistant is actually useful. Per-answer feedback is kept and can be reviewed, rather than being an impression.

## How it behaves

Answers stream: the text is readable while it is still being produced, and a long answer can be interrupted. Every conversation belongs to one organization — one deployment serves many tenants without their conversations meeting.

## Dependencies

Assistant Console is a user interface and does nothing on its own. It requires namespace `ai` to be deployed — without it the chat window has nothing to talk to and will not open.

- Namespace `ai` — required.
- **Platform Assistant** — required: it produces the answers.
- **Conversations** — required: it holds the threads the console displays.
- **Model Gateway** and **Knowledge Graph** — required indirectly, through Platform Assistant.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
