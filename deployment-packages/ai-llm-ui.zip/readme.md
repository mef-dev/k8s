# Model Console

Model Console is a set of developer pages for working with models directly: pick a model, send a prompt, upload a document, index it, and run a search over it — before any of that is wired into a process or an assistant.

It is a workbench inside the platform, using the platform's own models, documents and embeddings. A vendor playground shares none of those, so what is tried there does not tell you what will happen here.

## What it solves

- Choosing a model on evidence: the same prompt against several connected models, comparing answers and latency before committing one to a process.
- Checking retrieval before blaming the model: upload a document, see how it was chunked, and run the search that the assistant would run.
- Working with what production has: models, collections and embeddings are the platform's, not a sandbox's.
- Comparing interfaces: Chat Completions and the Responses API side by side, when their behaviour differs for the same request.

## Pages

- **Chat** and **Responses** — model calls with streaming.
- **LLM** — the registry of connected models.
- **Document** — collections and indexing.
- **Embeddings** and **Vector** — vector generation and semantic search.

## Dependencies

Model Console is a user interface and does nothing on its own. It requires namespace `ai` with **Model Gateway** in it — the console sends every request through the gateway and never calls a provider directly.

- Namespace `ai` — required.
- **Model Gateway** — required.
- Provider credentials — configured at namespace level, per consuming organization, not in this package.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
