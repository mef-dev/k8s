# Fabric-T Runtime

Fabric-T Runtime is the component that knows which AI agents exist, what each of them can do, and what each is allowed to reach — and that answers calls between them over one shared protocol.

An operator running agents from several vendors otherwise integrates each one with each other one. Ten agents mean forty-five point-to-point integrations, and every new vendor reopens all of them. A shared registry and a shared protocol replace that with one contract.

## What it solves

- Adding a vendor becomes configuration rather than a project: a new agent registers, declares its skills, and is discoverable — no bespoke integration per pair.
- Finding the right agent for a request: the intent is grounded in the knowledge graph, then filtered and ranked against the registry, and returned as one sorted list.
- Swapping a vendor without rewriting callers: consumers address skills through the registry, not the vendor's own endpoint.
- Knowing what an agent may touch before it acts: tools and resources are declared in the registry rather than discovered at runtime.

## What the registries hold

- **Agent Registry** — identity, declared skills with their tags, advertised profile, onboarding trust state.
- **Tool Registry** — the MCP tools an agent mounts, delivered as a self-contained set.
- **Resource Registry** — the addressable data and endpoints an agent refers to.
- **Prompt Registry** — structured prompt templates that carry exact intent instead of free-form text.

## Where it sits

Fabric-T Runtime answers *who can act*. The BPMN layer answers *what is allowed*, and **Trusted Gateway** answers *prove it*. No step relies on trust between agents — only on the platform signature and the operator's canonical process.

## Dependencies

Deployed into namespace `fabric`, which requires namespace `ai` to be deployed first. That is not a formality: Discovery grounds an intent in the knowledge graph before it filters the registry, and agents reach models through the ai layer.

- Namespace `ai` — required, with **Knowledge Graph** and **Model Gateway** in it.
- **Trusted Gateway** — required: it authorises dispatch between agents.
- **Fabric-T Console** — its pages; optional if the fabric is managed through the API.
- **Pipeline Insight** — optional: install it when the calls must leave a reviewable record.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
