cd bin
rd /s /q . 2>nul
cd ..
dotnet publish -o bin\Deploy --force
cd bin\Deploy
rmdir runtimes /s /q
rem powershell.exe -nologo -noprofile -command "Compress-Archive -Force -Path %~s1\*.* Natec.RFRating.zip"
rem powershell.exe -nologo -noprofile -command "Compress-Archive -Force -Path %~dp0\*.* Natec.RFRating.zip"
powershell.exe -nologo -noprofile -command "Compress-Archive -Force -Path *.* Natec.RFRating.zip"

pause