# -*- coding: utf-8 -*-
"""Перевірити теку core/ і перескласти її опис — core.ttl. БЕЗ МЕРЕЖІ І БЕЗ spec/.

Чому тут немає spec/
--------------------
Рішення власника 23.09: «забуваємо про spec, core — джерело правди для нас». Попередній
інструмент (sync_core.py) КОПІЮВАВ файли зі spec/ у core/ — тобто core/ був похідним, а джерелом
лишалась чужа тека. Тепер навпаки: чотири файли в core/ і є джерело, руками їх правлять тут, а
цей скрипт лише перевіряє їхню узгодженість і переписує опис.

Різниця не в словах: копіювач ЗАТИРАВ би будь-яку правку в core/ наступним запуском.

Чому посилань на mef.dev у core.ttl немає
----------------------------------------
Те саме рішення: «посилань не треба, або вони мають бути по типу нашого свагера — реальний хост,
неймспейс, плагін, контролер, ендпоінт».

Статичний файл не знає хоста: у репо, у збірці й на маршруті та сама тека доступна за різними
адресами. Тому тут ЛИШЕ відносні імена (`<ontology.ttl>`) — вони правда всюди. А резолвні адреси
віддає рантайм, який хост знає:

    GET {хост}/api/v2/ai/kgv2/spec.json      маніфест: версія, суми, реальні url
    GET {хост}/api/v2/ai/kgv2/core.ttl       цей опис теки
    GET {хост}/api/v2/ai/kgv2/ontology.ttl   будь-який файл теки — під власним іменем

★ І кожен файл окремим МАРШРУТОМ, а не одним `spec.ttl?file=…`. Причина не стилістична:
відносний IRI резолвиться проти адреси, з якої документ забрали, причому параметр запиту
відкидається разом з останнім сегментом шляху. Тобто `<ontology.ttl>` із цього файлу дає
`…/kgv2/ontology.ttl` — і лише за такої схеми там справді лежить той файл. Виходить, відносні
імена стають резолвними самі собою, без жодного посилання всередині.

⚠ Простір імен словника (`https://mef.dev/kg/core#`) — це НЕ посилання, а ідентифікатор, і він
зашитий у кожну трійку даних. Його не міняють: змінити його означає змінити всі дані.

Звідки беруться самі файли
--------------------------
Руками, окремим комітом, зі `spec/public/` цього ж репо — це та сама поставна форма, що й
опублікована на `https://platform.mef.dev/kg/`.
Це не суперечить «core/ — джерело правди»: джерелом воно є для ПЛАГІНА (що він вживає і що
віддає), а словник пише Сергій. Неправильним було інше — тягнути файли В РАНТАЙМІ або на
збірці: тоді мовчання сайту означало б, що ми не можемо ні перевірити субграф, ні сказати, з
чим порівнювали.

★ Саме поставна (`public`) форма, а не редакційна. Редакційна несе 124 зайві трійки, серед них
шість імен і шість адрес пошти живих людей (`kgp:assignee`, `kgp:assigneeEmail` на ролях). Ми
ці файли ВІДДАЄМО маршрутами — отже редакційна форма означала б публікацію персональних даних.
Поставна сама називає, що втримала (`kgp:withholds`).

Запуск:  py back/plugin/tools/check_core.py [--check]   (--check: не писати, лише перевірити)
"""
import argparse
import hashlib
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
CORE = os.path.join(ROOT, "core")

# Що саме лежить у core/ і чим воно є для рушія.
FILES = {
    "ontology.ttl":         ("vocabulary", "словник L1: класи, властивості, схеми понять"),
    "assertion.ttl":        ("vocabulary", "модуль довіри kga:: твердження як першокласна сутність"),
    "contract.shacl.ttl":   ("contract",   "методологія як дані: чого набір мусить дотримуватись"),
    "assertion.shapes.ttl": ("contract",   "методологія модуля довіри"),
}


def read(name):
    with open(os.path.join(CORE, name), "rb") as f:
        return f.read()


def versions(text):
    """Усе, чим файл називає свою версію: рядок і унікальний IRI.

    ★ Обидва, бо вони РОЗХОДЯТЬСЯ. Зміряно 23.09: підняли owl:versionInfo до 2.8.1.0, а
    owl:versionIRI лишився <…/assertion/1.3.0.0> — і файл суперечив сам собі. Саме versionIRI є
    унікальним ідентифікатором версії в OWL, тож споживач, який пінить за ним, отримав би не те,
    що написано в тексті.
    """
    info = re.findall(r'owl:versionInfo\s+"([^"]+)"', text)
    iri = [i.rsplit("/", 1)[-1] for i in re.findall(r'owl:versionIRI\s+<([^>]+)>', text)]
    return info, iri


def l1_versions(text):
    """Версії, оголошені САМОЮ онтологією L1 — суб'єктом <https://mef.dev/kg/core>.

    ★ Саме її називає набір у `void:vocabulary`, і саме з нею звіряється `kgp:ontologyPin`.
    «Перша версія, знайдена в тексті» для цього не годиться: у теці дві онтології з різними
    номерами, тож відповідь на «чи сумісний набір» залежала б від порядку файлів. Рушій читає
    її так само — `KgSpecBundle.VersionOf`.
    """
    block = re.search(r"<https://mef\.dev/kg/core>\s+a\s+owl:Ontology(.*?)\.\s*\n", text, re.S)
    if not block:
        return []
    return re.findall(r'owl:versionInfo\s+"([^"]+)"', block.group(1))


def l1_of(text):
    found = set(l1_versions(text))
    return found.pop() if len(found) == 1 else None


def main():
    sys.stdout.reconfigure(encoding="utf-8")

    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="лише перевірити, нічого не писати")
    args = ap.parse_args()

    bodies, problems, declared = {}, [], {}

    print("=== core/ ===")
    for name, (role, what) in FILES.items():
        path = os.path.join(CORE, name)
        if not os.path.isfile(path):
            problems.append(f"немає файлу {name}")
            print(f"  ВІДСУТНІЙ  {name}")
            continue

        body = read(name)
        bodies[name] = body
        text = body.decode("utf-8")
        info, iri = versions(text)
        declared[name] = sorted(set(info + iri))

        shown = "/".join(declared[name]) or "версії не оголошено"
        print(f"  {len(body):>7} Б  {hashlib.sha256(body).hexdigest()[:16]}  "
              f"{name:<22} {role:<11} {shown}")

        if info and iri and set(info) != set(iri):
            problems.append(f"{name}: versionInfo {info} ≠ versionIRI {iri}")

        if len(set(l1_versions(text))) > 1:
            problems.append(f"{name}: у mef.dev/kg/core кілька версій — пін звірявся б з випадковою")

    # ★ ВЕРСІЯ ТЕКИ = ВЕРСІЯ L1, а НЕ «одна на всі файли».
    #
    # Раніше тут вимагалась рівність, і файли під неї вирівнювали (рішення власника 22.09).
    # Це працювало, поки core/ був нашою копією. Щойно плагін почав ВІДДАВАТИ ці файли
    # маршрутами, ціна змінилась: вирівнювання означало б публікацію чужого документа з
    # власним номером. Вгорі за течією онтології версіонують окремо — на 23.09 core 2.11.0.0
    # і assertion 1.3.0.0, — і це нормально. Важить лише, щоб версія L1 була однозначна.
    version = l1_of(bodies.get("ontology.ttl", b"").decode("utf-8")) or "?"
    if version == "?":
        problems.append("ontology.ttl не називає однієї версії mef.dev/kg/core — піну ні з чим звірятись")

    if problems:
        print("\n=== ПРОБЛЕМИ ===")
        for p in problems:
            print(f"  · {p}")
        return 1

    print(f"\nверсія L1 — з нею звіряється kgp:ontologyPin набору: {version}")
    others = {n: v for n, v in declared.items() if v and v != [version]}
    if others:
        print("інші оголошені версії (їх ведуть окремо вгорі за течією, і це не проблема):")
        for n, v in sorted(others.items()):
            print(f"  · {n}: {', '.join(v)}")

    if args.check:
        print("--check: нічого не записано")
        return 0

    with open(os.path.join(CORE, "core.ttl"), "w", encoding="utf-8", newline="\n") as f:
        f.write(as_turtle(bodies, version))
    print(f"переписано {os.path.join(CORE, 'core.ttl')}")
    return 0


def as_turtle(bodies, version):
    """Опис теки у Turtle — тією самою мовою, що й решта core/.

    ★ Тотожність — «<>», сам цей документ. Набір НЕ підписується IRI чужої онтології: та
    лишається простором імен даних, а не тим, чим є наш набір файлів.

    Унікальність, незалежна від адреси, — sha256 від СУМ усіх файлів: той самий вміст дає той
    самий рядок, де б тека не лежала, а будь-яка правка будь-якого файлу його змінює.
    """
    sums = {n: hashlib.sha256(b).hexdigest() for n, b in bodies.items()}
    bundle = hashlib.sha256("".join(sorted(sums.values())).encode("ascii")).hexdigest()

    lines = [
        "# Опис теки core/ — ЗГЕНЕРОВАНО, руками не редагується.",
        "# Перескласти й перевірити: py back/plugin/tools/check_core.py",
        "#",
        "# core/ — ДЖЕРЕЛО ПРАВДИ. Файли правлять тут; зі spec/ нічого не копіюється.",
        "#",
        "# Суб'єкт «<>» — сам цей документ. Адреси файлів ВІДНОСНІ: статичний файл не знає хоста.",
        "# Резолвляться вони самі собою, бо рантайм віддає кожен файл під тим самим іменем:",
        "#     GET {хост}/api/v2/ai/kgv2/core.ttl       ← цей документ",
        "#     GET {хост}/api/v2/ai/kgv2/ontology.ttl   ← <ontology.ttl> звідси",
        "#     GET {хост}/api/v2/ai/kgv2/spec.json      ← те саме в JSON, із реальними url",
        "",
        "@prefix void:    <http://rdfs.org/ns/void#> .",
        "@prefix dcterms: <http://purl.org/dc/terms/> .",
        "",
        "<> a void:Dataset ;",
        f'    dcterms:hasVersion "{version}" ;',
        f'    dcterms:identifier "sha256:{bundle}" ;',
        "    dcterms:description "
        '"словник і методологія для всіх субграфів; вшивається у збірку плагіна"@uk ;',
        "    void:dataDump " + ", ".join(f"<{n}>" for n in FILES if n in bodies) + " .",
        "",
    ]

    for name, (role, what) in FILES.items():
        if name not in bodies:
            continue
        lines += [
            f"<{name}> a void:Dataset ;",
            f'    dcterms:title "{what}"@uk ;',
            f'    dcterms:type "{role}" ;',
            f'    dcterms:extent "{len(bodies[name])} B" ;',
            # Стандартного терміна для контрольної суми в dcterms немає, а вводити свій заради
            # одного рядка не варто: алгоритм називаємо в самому значенні.
            f'    dcterms:identifier "sha256:{sums[name]}" .',
            "",
        ]

    return "\n".join(lines)


if __name__ == "__main__":
    sys.exit(main())
