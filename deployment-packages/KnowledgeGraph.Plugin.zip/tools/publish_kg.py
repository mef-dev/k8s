# -*- coding: utf-8 -*-
"""Збірка й публікація граф-плагіна на MEF.DEV.

Чому Python, а не .cmd: кирилиця в cmd/git-bash мангліться (CP1251/CP866) — грабля
з CLAUDE.md §4. Python з UTF-8 працює однаково скрізь. Обгортка: publish-kg.cmd.

На відміну від catalyst-.../agents/publish-agents.cmd тут НЕМАЄ залежності від
EvaluationMcp.Publisher — publish робиться прямим multipart-викликом
(docs/reference/plugin-tutorial/README.md, «Uploading Package Version»).

⚠ HOST — обов'язковий аргумент, дефолту немає свідомо: туторіал показує
preview.mef.dev, наш проєкт працює зі stage-api.mef.dev
(docs/reference/platform/README.md: «Live stage API»). Не публікуємо наосліп.

    python tools/publish_kg.py --auth user:pass --alias ai --url https://stage-api.mef.dev --dry-run
    python tools/publish_kg.py --auth user:pass --alias ai --url https://stage-api.mef.dev

★ ОТОЧЕННЯ (рішення власника 01.10: «оточення: прод, локал … будь обережний»). Конфіг тенанта
затирається лише з --update-configuration, і тоді ОБОВ'ЯЗКОВО каже, чиїм конфігом:

    --env prod    конфіг із KnowledgeGraph.Plugin/metadata.json — глобальний стенд; НЕ на localhost
    --env local   конфіг із environments/local.json — особистий стенд; ЛИШЕ на localhost

    py back/plugin/tools/publish_kg.py --auth user:pass --url http://localhost:9000 \
        --update-configuration --env local --skip-tests

Чому так суворо: платформа без питань запише в сервіс ту конфігурацію, яка лежить у пакеті.
Прод-конфіг на особистому стенді вів би плагін на stage-* (з docker їх не видно), а
локальний на проді — на http://autodoc, якого поза docker-мережею не існує.

Обгортка publish.cmd повторює сигнатуру publish-agents.cmd: <user:pass> <alias> <apiUrl>.
"""
from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from pathlib import Path

PLUGIN = "KnowledgeGraph.Plugin"
ROOT = Path(__file__).resolve().parent.parent          # back/plugin/
CSPROJ = ROOT / PLUGIN / f"{PLUGIN}.csproj"
ZIP = ROOT / PLUGIN / "bin" / "Release" / "net10.0" / "portable" / "publish.zip"

# Оточення, чий конфіг НЕ лежить у пакеті. prod — це сам metadata.json, тому його тут немає.
ENV_FILES = {"local": ROOT / "environments" / "local.json"}
LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}
# Той самий особистий стенд (сервіс 9), видний ззовні за Caddy з клієнтськими сертифікатами (09.10).
# ⚠ urllib сертифіката зі сховища Windows не бере — туди публікувати curl --ssl-auto-client-cert.
LOCAL_STAND_HOSTS = LOCAL_HOSTS | {"91.241.124.177"}

# Перед публікацією ганяємо ТІЛЬКИ V2.
#
# Рішення власника 22.09: «V0 ми вже не використовуємо, він деприкейтнутий, його
# треба буде видалити після презентації». Доти тут стояли обидва набори з доводом
# «збірка контролерів атомарна» — довід чинний, але V0 ми більше не правимо, тож його
# тести лише зупиняють публікацію через чужі причини (22.09 — через Windows Application
# Control, який заблокував KnowledgeGraph.V0.Core.dll: 99 зі 104 впало на завантаженні).
#
# Прогнати V0 вручну все ще можна — проєкт на місці, його ніхто не видаляв.
TESTS = [ROOT / "KnowledgeGraph.Tests" / "KnowledgeGraph.Tests.csproj"]


def run(step: str, cmd: list[str]) -> None:
    print(f"\n=== {step} ===\n$ {' '.join(cmd)}")
    proc = subprocess.run(cmd, cwd=ROOT)
    if proc.returncode != 0:
        sys.exit(f"\nПОМИЛКА на кроці «{step}» (exit {proc.returncode}) — публікацію скасовано.")


def multipart(file_path: Path, fields: dict[str, str]) -> tuple[bytes, str]:
    """Тіло multipart/form-data: текстові поля (updateVersion тощо) + файл.
    Прапорці updateVersion/updateTenantVersion/updateConfiguration — [FromForm] у
    PluginController.Publish: без них версія лише ЗАЛИВАЄТЬСЯ, але не активується."""
    boundary = f"----kgpublish{uuid.uuid4().hex}"
    ctype = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
    parts = []
    for name, value in fields.items():
        parts.append(
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode("utf-8"))
    head = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="file"; filename="{file_path.name}"\r\n'
        f"Content-Type: {ctype}\r\n\r\n"
    ).encode("utf-8")
    tail = f"\r\n--{boundary}--\r\n".encode("utf-8")
    return b"".join(parts) + head + file_path.read_bytes() + tail, f"multipart/form-data; boundary={boundary}"


def call(url: str, auth: str, body: bytes | None = None, content_type: str | None = None) -> str:
    req = urllib.request.Request(url, data=body, method="POST" if body else "GET")
    req.add_header("Authorization", "Basic " + base64.b64encode(auth.encode("utf-8")).decode("ascii"))
    if content_type:
        req.add_header("Content-Type", content_type)
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            return r.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")[:500]
        raise SystemExit(f"HTTP {e.code} {e.reason}\n{detail}")
    except urllib.error.URLError as e:
        raise SystemExit(f"Мережева помилка: {e.reason}")


def env_configuration(env: str) -> dict:
    """Конфіг оточення без коментарів (ключі з підкреслення — проза для людини, не налаштування)."""
    data = json.loads(ENV_FILES[env].read_text(encoding="utf-8"))
    return {k: v for k, v in data["configuration"].items() if not k.startswith("_")}


def package_for_env(zip_path: Path, env: str) -> Path:
    """Копія пакета, у якої в metadata.json стоїть конфіг оточення. Сам пакет НЕ змінюється:
    publish.zip у bin лишається прод-пакетом, а копія живе в тимчасовій теці."""
    cfg = env_configuration(env)
    out_dir = Path(tempfile.gettempdir()) / f"kg-publish-{env}"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / zip_path.name
    replaced = False
    with zipfile.ZipFile(zip_path) as src, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
        for item in src.infolist():
            data = src.read(item.filename)
            if item.filename.replace("\\", "/").split("/")[-1] == "metadata.json":
                meta = json.loads(data.decode("utf-8-sig"))
                meta["configuration"] = json.dumps(cfg, ensure_ascii=False)
                data = json.dumps(meta, ensure_ascii=False, indent=2).encode("utf-8")
                replaced = True
            dst.writestr(item, data)
    if not replaced:
        sys.exit(f"ПОМИЛКА: у {zip_path} немає metadata.json — конфіг оточення нікуди підставити")
    return out


def describe(cfg: dict) -> str:
    eps = cfg.get("KgV2EntryPoints") or []
    lines = [f"  ключів {len(cfg)}: {', '.join(cfg)}", f"  точок входу {len(eps)}:"]
    for e in eps:
        extra = f"  (дзеркало {e['mirrorOf']})" if e.get("mirrorOf") else ""
        lines.append(f"    · {e.get('url')}  index={e.get('index')}{extra}")
    return "\n".join(lines)


def main() -> None:
    p = argparse.ArgumentParser(description="Публікація граф-плагіна на MEF.DEV")
    p.add_argument("--auth", required=True, metavar="user:pass",
                   help="Basic-креди (SETTINGS \\ CREDENTIALS у профілі платформи)")
    p.add_argument("--alias", default="ai", metavar="ALIAS",
                   help="alias реєстрації (за замовч. ai)")
    p.add_argument("--url", required=True, metavar="APIURL",
                   help="повний базовий URL зі схемою, напр. https://stage-api.mef.dev")
    p.add_argument("--dry-run", action="store_true", help="показати запит, нічого не надсилати")
    p.add_argument("--skip-tests", action="store_true", help="не ганяти dotnet test перед публікацією")
    p.add_argument("--update-configuration", action="store_true",
                   help="перезаписати живий Configuration конфігом оточення (обережно; потребує --env)")
    p.add_argument("--env", choices=["prod", "local"],
                   help="чиїм конфігом затирати тенанта: prod — metadata.json, local — environments/local.json")
    args = p.parse_args()

    host = (urllib.parse.urlparse(args.url).hostname or "").lower()
    if args.update_configuration and not args.env:
        sys.exit("--update-configuration потребує --env prod|local: без нього незрозуміло, ЧИЇМ конфігом "
                 "затирати тенанта.")
    if args.env and not args.update_configuration:
        sys.exit(f"--env {args.env} задає конфіг, а без --update-configuration платформа його не застосує.")
    if args.env == "local" and host not in LOCAL_STAND_HOSTS:
        sys.exit(f"--env local лише для особистого стенда ({', '.join(sorted(LOCAL_STAND_HOSTS))}), а адреса — {args.url}.")
    if args.env == "prod" and host in LOCAL_STAND_HOSTS:
        sys.exit("--env prod на localhost: прод-конфіг вів би плагін на stage-*, яких із docker не видно. "
                 "Для особистого стенда — --env local.")

    base = args.url.rstrip("/")
    publish_url = f"{base}/api/v2/plugins/{args.alias}/{PLUGIN}/publish"

    if not args.skip_tests:
        for t in TESTS:
            run("[1/4] dotnet test %s" % t.stem, ["dotnet", "test", str(t), "--nologo", "-v", "q"])

    run("[2/4] dotnet publish -c Release -r portable --no-self-contained",
        ["dotnet", "publish", str(CSPROJ), "-c", "Release", "-r", "portable",
         "--no-self-contained", "--nologo", "-v", "q"])

    if not ZIP.exists():
        sys.exit(f"ПОМИЛКА: не знайдено {ZIP}")
    package = ZIP
    if args.env in ENV_FILES:
        package = package_for_env(ZIP, args.env)
        print(f"\n★ ОТОЧЕННЯ {args.env}: конфіг із {ENV_FILES[args.env].relative_to(ROOT)} підставлено в копію пакета")
        print(describe(env_configuration(args.env)))
    elif args.env == "prod":
        meta = json.loads((ROOT / PLUGIN / "metadata.json").read_text(encoding="utf-8"))
        print(f"\n★ ОТОЧЕННЯ prod: конфіг із {PLUGIN}/metadata.json")
        print(describe(json.loads(meta["configuration"])))
    print(f"Пакет: {package} ({package.stat().st_size:,} байт)")

    # активуємо залиту версію: без цих [FromForm]-прапорців вона лише завантажується
    # updateConfiguration ЗА ЗАМОВЧУВАННЯМ ВИМКНЕНО. Живий Configuration сервісу — джерело правди,
    # і metadata.json його не знає: увімкнути це означає мовчки відкотити налаштування тенанта до
    # значень із репозиторію. Вмикати лише свідомо, першою публікацією нового ключа.
    fields = {"updateVersion": "true", "updateTenantVersion": "true",
              "updateConfiguration": "true" if args.update_configuration else "false"}

    if args.dry_run:
        print(f"\n[DRY-RUN] POST {publish_url}")
        print(f"[DRY-RUN]   Authorization: Basic <base64 {args.auth.split(':')[0]}:***>")
        print(f"[DRY-RUN]   multipart form-data: file=@{package}, {fields}")
        print(f"[DRY-RUN] перевірка: GET {base}/api/v2/{args.alias}/kgv2/health → build.version")
        print("\nНічого не надіслано. Прибери --dry-run, щоб опублікувати.")
        return

    print(f"\n=== [3/4] POST {publish_url} ===")
    body, ctype = multipart(package, fields)
    print(call(publish_url, args.auth, body, ctype)[:500] or "(порожня відповідь)")

    # ★ Перевірка — /health → build.version, а не version.json (CLAUDE.md §4). Той стабільно віддає
    # 404 і доти ВИКИДАВ скрипт ПІСЛЯ успішної публікації: deployed: true, а людина бачила «HTTP 404» і
    # не бачила підсумку. Тут нефатально: публікація вже сталась, а жива версія може доїхати пізніше.
    pulse = f"{base}/api/v2/{args.alias}/kgv2/health"
    print(f"\n=== [4/4] GET {pulse} ===")
    try:
        h = json.loads(call(pulse, args.auth))
        b = h.get("build") or {}
        print(f"  збірка {b.get('version')} | {h.get('status')} — {h.get('summary')}")
        ep = h.get("entryPoints") or {}
        print(f"  точок входу {ep.get('total')}, живих {ep.get('ok')}")
    except SystemExit as e:
        print(f"  пульс не відповів ({e}) — версія може доїхати із затримкою; перевірити пізніше тим самим /health")

    # ⚠ Банер вів на /kg/meta — маршрут V0, якого немає з 22.09.
    print(f"\n✓ Опубліковано: {PLUGIN} → {base}/api/v2/{args.alias}/kgv2/health")
    print("  Живою версія стає із затримкою; перевірка одна — /health → build.version (CLAUDE.md §4).")
    print("  Якщо publish відмовив «версія вже існує» — підніми <Version> у back/plugin/Directory.Build.props.")


if __name__ == "__main__":
    main()
