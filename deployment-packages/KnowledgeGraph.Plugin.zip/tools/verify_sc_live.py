# -*- coding: utf-8 -*-
"""Жива верифікація StorageControl-графа на платформі після републішу.
Плагін у document-режимі форвардить Authorization викликача в Document API, тож read-кред
має бачити колекцію kg-storagecontrol-v1. Вивід у UTF-8 (кирилиця)."""
import base64, json, sys, urllib.request, urllib.error, io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
AUTH = sys.argv[1] if len(sys.argv) > 1 else "vtymbcread1234:vtymbcread1234"
URL = (sys.argv[2] if len(sys.argv) > 2 else "https://stage-api.mef.dev").rstrip("/")
HDR = {"Authorization": "Basic " + base64.b64encode(AUTH.encode()).decode(),
       "Content-Type": "application/json; charset=utf-8"}


def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(URL + path, data=data, method=method, headers=HDR)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")[:400]


def main():
    st, meta = call("GET", "/api/v2/ai/kg/meta")
    print(f"# /meta → HTTP {st}\n{meta}\n")
    if st != 200:
        return

    # картка сутності Клієнт: тип, eTOM, зв'язки
    st, node = call("GET", "/api/v2/ai/kg/node?id=pilot/sc-customer")
    print(f"# /node?id=pilot/sc-customer → HTTP {st}")
    if st == 200:
        d = json.loads(node)
        n = d.get("node", {})
        print(f"  label={n.get('label')!r} meta={n.get('meta')}")
        print(f"  ребра: {[(e['predicate'], e['target']) for e in d.get('edges', [])][:12]}")
    print()

    # SPARQL: скільки сутностей на кожній вертикалі eTOM.
    #
    # Питається `dcterms:subject` із фільтром за простором etom: — саме так
    # прив'язку записує експорт набору. Доти тут стояв `an:alignsToEtomProcess`
    # із простору чужої онтології, яку видалили ще у 2.1.0.0: у жодному .ttl
    # обох репозиторіїв цього предиката немає ЖОДНОГО разу, тож запит із
    # коментарем «доводить, що eTOM у графі» повертав порожньо — і порожній
    # результат виглядав як відповідь. Рядки з'являлися лише тоді, коли рушій
    # читав сховище нот напряму: той шлях an:-предикат і породжує.
    q = ("PREFIX dcterms: <http://purl.org/dc/terms/> "
         "SELECT ?area (COUNT(?s) AS ?n) WHERE { "
         "?s dcterms:subject ?area . "
         "FILTER(STRSTARTS(STR(?area), \"https://mef.dev/ontology/etom#\")) } "
         "GROUP BY ?area ORDER BY DESC(?n)")
    st, res = call("POST", "/api/v2/ai/kg/sparql", {"query": q})
    print(f"# SPARQL eTOM-розподіл → HTTP {st}")
    if st == 200:
        for b in json.loads(res).get("results", {}).get("bindings", []):
            area = b["area"]["value"].split("#")[-1]
            print(f"  {area}: {b['n']['value']}")
    else:
        print(f"  {res}")
    print()

    # заземлення NL-запиту (uk) — доводить лексичний конвеєр на SC-даних
    st, gr = call("POST", "/api/v2/ai/kg/ground", {"query": "хто такий абонент і кому він належить?"})
    print(f"# /ground 'хто такий абонент…' → HTTP {st}")
    if st == 200:
        d = json.loads(gr)
        print(f"  entities={[e.get('id') or e.get('label') for e in d.get('entities', [])][:6]}")


if __name__ == "__main__":
    main()
