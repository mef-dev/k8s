"""Залити vault-нотатки у Document-RAG як ЗВИЧАЙНИЙ ТЕКСТ (для чату), не як base64.

Навіщо окремий скрипт:
- `kg-vault-v1` тримає нотатки у **base64** — це байт-стор для KG-плагіна (він декодує сам).
  Платформа ж чанкить і ембедить те, що отримала → семантичний пошук по base64 = сміття
  (перевірено наживо: будь-який запит дає ~0.40 і base64 у content).
- `kg-pilot-fields-v1` — це ЛЕКСИКОН полів (назва + синоніми + `descriptions[0][:400]`), а не корпус:
  саме тому «повний документ» у чаті обривався на півслові.

Ця колекція — корпус для чату: повний текст .md, plain UTF-8, title = ім'я поля (= label вузла графа),
source = відносний шлях (= `meta.file` вузла) → документ і вузол графа зіставляються 1:1.

  python upload_vault_plain.py --auth user:pass --url https://stage-api.mef.dev \
      --collection kg-vault-md-v1 --vault ../fixtures/pilot-vault
"""
from __future__ import annotations

import argparse
import re
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

TAG = "kg-md"


def api(base: str, auth: str):
    import base64 as b64
    token = b64.b64encode(auth.encode()).decode()

    def call(method: str, path: str, body: dict | None = None, timeout: int = 300):
        url = f"{base.rstrip('/')}/api/v2/ai/document{path}"
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Authorization", f"Basic {token}")
        if data:
            req.add_header("Content-Type", "application/json; charset=utf-8")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read().decode("utf-8", "replace")
                return r.status, (json.loads(raw) if raw.strip().startswith(("{", "[")) else raw)
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")[:300]
    return call


FRONT = re.compile(r"^---\n(.*?)\n---\n", re.S)
MATCH = re.compile(r"^match:\s*\[(.*?)\]\s*$", re.M)


def sanitize(text: str) -> str:
    """⚠️ БАГ ПЛАТФОРМИ: документ, у вмісті якого є ПРЯМА ПОДВІЙНА ЛАПКА («"»), не заливається взагалі —
    `POST /documents/batch` повертає success=false з «After parsing a value an unexpected character was
    encountered». Ізольовано мінімальним тестом (2026-07-14): текст із `"` падає, з «ялинками»/`[`/`{` — проходить.
    Тобто десь у їхньому конвеєрі JSON збирається конкатенацією без екранування. Питання до Ігоря.

    Обхід: прямі лапки → парні «ялинки» (для української це навіть природніше; для ембедингів текст той самий).
    """
    out, open_q = [], True
    for ch in text:
        if ch == '"':
            out.append("«" if open_q else "»")
            open_q = not open_q
        else:
            out.append(ch)
    return "".join(out)


def notes(vault: Path):
    """(title, content, source) — ПОВНИЙ текст нотатки; title = ім'я файлу без .md (== label вузла графа).

    ⚠️ YAML-фронтматер ВИРІЗАЄМО: платформа намагається розпарсити content як JSON і давиться на
    `match: [a, b]` («After parsing a value an unexpected character was encountered: [»). Саме через це
    KG-заливка кодувала нотатки в base64 — і тим самим убила семантичний пошук по цій колекції.
    Синоніми з `match:` не втрачаємо — переносимо звичайним рядком, щоб пошук їх бачив.
    """
    out = []
    for p in sorted(vault.rglob("*.md")):
        rel = p.relative_to(vault).as_posix()
        md = p.read_text(encoding="utf-8-sig").replace("\r\n", "\n").strip()
        if not md:
            continue
        fm = FRONT.match(md)
        body = FRONT.sub("", md).strip()
        aliases = ""
        if fm and (m := MATCH.search(fm.group(1))):
            terms = [t.strip().strip("'\"") for t in m.group(1).split(",") if t.strip()]
            if terms:
                aliases = "Синоніми: " + ", ".join(terms) + "\n\n"
        if body:
            out.append((p.stem, sanitize(aliases + body), rel))
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--auth", required=True, metavar="user:pass")
    ap.add_argument("--url", required=True)
    ap.add_argument("--collection", default="kg-vault-md-v1")
    ap.add_argument("--vault", required=True)
    ap.add_argument("--batch", type=int, default=10)
    ap.add_argument("--recreate", action="store_true")
    a = ap.parse_args()
    call = api(a.url, a.auth)
    coll = a.collection

    if a.recreate:
        st, _ = call("DELETE", f"/collection/{coll}")
        print(f"delete {coll}: HTTP {st}")
        time.sleep(2)

    st, r = call("POST", "/collection", {
        "name": coll,
        "description": "vault-нотатки повним текстом (корпус для чату; 1:1 з вузлами графа)",
        "model": "BAAI/bge-m3", "chunkLength": 512, "chunkOverlap": 50, "provider": "Pgvector",
    })
    print(f"create {coll}: HTTP {st} {r if st not in (200, 201) else ''}")

    st, lst = call("GET", f"/{coll}/documents?page=1&pageSize=1000")
    existing = {d.get("source") for d in (lst.get("items", []) if isinstance(lst, dict) else [])}
    docs = [d for d in notes(Path(a.vault)) if d[2] not in existing]
    print(f"уже залито: {len(existing)} · лишилось: {len(docs)}")

    ok = 0
    for i in range(0, len(docs), a.batch):
        part = docs[i:i + a.batch]
        try:
            st, r = call("POST", f"/{coll}/documents/batch", {
                "documents": [{"title": t, "content": c, "source": s, "tags": [TAG]} for t, c, s in part],
                "chunkLength": 512, "chunkOverlap": 50,
            })
            n = r.get("successCount", 0) if isinstance(r, dict) else 0
            ok += n
            print(f"  батч {i // a.batch + 1}: HTTP {st} +{n}", flush=True)
        except Exception as e:  # таймаут: сервер дообробить, повторний запуск пропустить залите
            print(f"  батч {i // a.batch + 1}: {str(e)[:60]} — продовжую", flush=True)
    print(f"залито {ok} з {len(docs)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
