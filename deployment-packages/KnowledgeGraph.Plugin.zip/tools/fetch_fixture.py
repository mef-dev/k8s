# -*- coding: utf-8 -*-
"""Знімок ЖИВИХ даних платформи у теку тестів.

Навіщо
------
Тести перевіряють рушій — чи SPARQL відмовляє в DROP, чи заземлення знаходить вузол, чи обхід не
залазить у схему. Графом для них була тека back/plugin/datasets/ з пілотними нотами; її видалено
(рішення власника 22.09), і 83 тести стали вмирати на відкритті файлу, не дійшовши до того, що
власне перевіряють.

Рішення власника 23.09: «зробіть нам дані з платформи MEF.DEV справжніми оцими всіма даними,
загрузи їх собі в папку тести і все, і проходи з ними».

Тобто пісочницею стає те саме, що крутиться на стенді. Це строго краще за пілотні дані: тест на
справжньому графі ловить те, чого синтетичний не ловить ніколи.

Як це працює
------------
Адрес не вигадуємо — питаємо дескриптор, рівно як рушій: /.well-known/void називає набори, кожен
називає свій void:dataDump. Що назвали, те й забираємо.

Знімок ДАТОВАНИЙ: нова тека на кожен прогін. Старі лишаються — тест, який упав на новому знімку,
має бути порівнянний зі старим, інакше «зламалось у нас» від «змінилось у них» не відрізнити.

Запуск:  py back/plugin/tools/fetch_fixture.py [--date 2026-09-23] [--void URL]
"""
import argparse
import hashlib
import os
import re
import sys
import urllib.request

DEFAULT_VOID = "https://platform.mef.dev/.well-known/void"

# ★ Явний підпис обов'язковий: Cloudflare відкидає дефолтний рядок Python 403-ю (CLAUDE.md §4).
UA = "KnowledgeGraph/1.0 (+https://mef.dev)"

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
FIXTURES = os.path.join(ROOT, "back", "plugin", "KnowledgeGraph.Tests",
                        "fixtures", "platform-mef-dev")


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=60) as f:
        return f.read()


def main():
    sys.stdout.reconfigure(encoding="utf-8")

    ap = argparse.ArgumentParser()
    ap.add_argument("--void", default=DEFAULT_VOID)
    ap.add_argument("--date", required=True, help="дата знімка, напр. 2026-09-23")
    args = ap.parse_args()

    out = os.path.join(FIXTURES, args.date)
    os.makedirs(out, exist_ok=True)

    print(f"=== {args.void} ===")
    void_bytes = get(args.void)
    with open(os.path.join(out, "void.ttl"), "wb") as f:
        f.write(void_bytes)
    print(f"  {len(void_bytes):>7} Б  void.ttl")

    void_text = void_bytes.decode("utf-8")
    dumps = re.findall(r"void:dataDump\s+<([^>]+)>", void_text)
    if not dumps:
        print("дескриптор не назвав жодного void:dataDump", file=sys.stderr)
        return 2

    for url in dumps:
        name = url.rsplit("/", 1)[-1]
        body = get(url)
        with open(os.path.join(out, name), "wb") as f:
            f.write(body)
        print(f"  {len(body):>7} Б  {hashlib.sha256(body).hexdigest()[:16]}  {name}  ← {url}")

    print(f"\nзаписано в {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
