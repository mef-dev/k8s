#!/usr/bin/env bash
# Само-кермуючий добір колекції Document API до цілі (ембединг повільний + 502 → ідемпотентні проходи).
# Використання: fill_collection.sh <collection> <datasetDir> <writeAuth> <readAuth> <url> <target>
set -u
COLL="$1"; DIR="$2"; WAUTH="$3"; RAUTH="$4"; URL="$5"; TARGET="${6:-178}"
cd "$(dirname "$0")/.."
prev=-1
for i in $(seq 1 12); do
  python tools/documents.py upload "$COLL" "$DIR" --auth "$WAUTH" --url "$URL" --batch 4 >/dev/null 2>&1
  cnt=$(python tools/documents.py list-docs "$COLL" --auth "$RAUTH" --url "$URL" 2>/dev/null | grep -oE '[0-9]+$' | tail -1)
  cnt=${cnt:-0}
  echo "iter $i: count=$cnt / $TARGET"
  if [ "$cnt" -ge "$TARGET" ]; then echo "DONE: reached $cnt"; break; fi
  if [ "$cnt" -le "$prev" ]; then echo "STALLED at $cnt (no progress)"; fi
  prev=$cnt
done
echo "FINAL count=$(python tools/documents.py list-docs "$COLL" --auth "$RAUTH" --url "$URL" 2>/dev/null | grep -oE '[0-9]+$' | tail -1)"
