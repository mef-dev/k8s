# -*- coding: utf-8 -*-
"""CLI керування колекціями Document API (ai-llm) — джерело контенту графа в document-режимі.

Чому Python: кирилиця в нотах; cmd/curl з git-bash її мангліть (CLAUDE.md §4).

Підкоманди:
  list                         — усі колекції
  list-docs   <collection>     — документи колекції (title/source)
  create      <collection> [опис]
  delete      <collection>
  upload      <collection> <vaultDir>   — залити всі *.md як документи (source=relPath, content=повний .md)
  probe       <collection> <vaultDir>   — залити 1 ноту, прочитати назад, звірити round-trip (де-ризик)

Спільні прапорці: --auth user:pass  --url https://stage-api.mef.dev
Приклади:
  python tools/documents.py list --auth u:p --url https://stage-api.mef.dev
  python tools/documents.py probe kg-probe ../pilot/vault --auth u:p --url https://stage-api.mef.dev
  python tools/documents.py create kg-vault-v1 "offering тарифи (граф)" --auth u:p --url ...
  python tools/documents.py upload kg-vault-v1 ../pilot/vault --auth u:p --url ...
"""
from __future__ import annotations

import argparse
import base64
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

# ★ Контент кодуємо base64 + тег KGMD_TAG. Причина: Document API завжди чанкує+ембедить
# контент, а ембединг-пайплайн давиться на '[' (YAML-масиви, [[wikilinks]]) — сирий .md
# дає successCount:0. base64 не має '[', заходить чисто й round-trip'иться байт-у-байт.
# DocumentContentSource декодує за наявністю тега. Компроміс: такі документи НЕ придатні
# для RAG-пошуку (embeddings base64 — сміття), але вони — джерело ГРАФА, не RAG.
KGMD_TAG = "kgmd-b64"


def encode(md: str) -> str:
    return base64.b64encode(md.encode("utf-8")).decode("ascii")


def api(url_base: str, auth: str):
    b = url_base.rstrip("/") + "/api/v2/ai/document"
    hdr = "Basic " + base64.b64encode(auth.encode("utf-8")).decode("ascii")

    def call(method: str, path: str, payload=None, timeout=90):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(b + path, data=data, method=method, headers={
            "Authorization": hdr, "Content-Type": "application/json; charset=utf-8"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read().decode("utf-8", "replace")
                return r.status, (json.loads(raw) if raw.strip() else None)
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")[:300]
    return call


def notes(vault_dir: Path):
    """(title, content_b64, source) для кожної .md ТА .ttl-онтології; source=relPath, content=base64.
    .ttl їде як онтологія-документ: DocumentContentSource пропускає її в Notes() і доклеює у SchemaTurtle()."""
    out = []
    for p in sorted(vault_dir.rglob("*.md")) + sorted(vault_dir.rglob("*.ttl")):
        rel = p.relative_to(vault_dir).as_posix()
        md = p.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
        out.append((rel, encode(md), rel))
    return out


def main():
    ap = argparse.ArgumentParser(description="Керування колекціями Document API")
    ap.add_argument("cmd", choices=["list", "list-docs", "create", "delete", "upload", "probe"])
    ap.add_argument("args", nargs="*")
    ap.add_argument("--auth", required=True, metavar="user:pass")
    ap.add_argument("--url", required=True, metavar="APIURL")
    ap.add_argument("--batch", type=int, default=20)
    a = ap.parse_args()
    call = api(a.url, a.auth)

    if a.cmd == "list":
        st, r = call("GET", "/collection")
        if st != 200:
            sys.exit(f"HTTP {st}: {r}")
        for c in r.get("items", []):
            print(f"  {c['name']:24} docs? | {c.get('description','')[:60]}")
        print(f"всього: {r.get('totalCount')}")
        return

    if a.cmd == "list-docs":
        coll = a.args[0]
        st, r = call("GET", f"/{coll}/documents?page=1&pageSize=500")
        if st != 200:
            sys.exit(f"HTTP {st}: {r}")
        for d in r.get("items", []):
            print(f"  {d.get('source') or d.get('title')}")
        print(f"всього: {r.get('totalCount')}")
        return

    if a.cmd == "create":
        coll = a.args[0]
        desc = a.args[1] if len(a.args) > 1 else "kg graph source"
        payload = {"name": coll, "description": desc, "model": "BAAI/bge-m3",
                   "chunkLength": 512, "chunkOverlap": 50, "provider": "Pgvector",
                   "vectorSearch": {"algorithms": [{"name": "h", "kind": "hnsw", "hnswParameters": {
                       "m": 16, "efConstruction": 200, "efSearch": 100, "metric": "cosine"}}],
                       "profiles": [{"name": "default_profile", "algorithm": "h"}]}}
        st, r = call("POST", "/collection", payload)
        print(f"create {coll}: HTTP {st}", "" if st in (200, 201) else r)
        return

    if a.cmd == "delete":
        coll = a.args[0]
        st, r = call("DELETE", f"/collection/{coll}")
        print(f"delete {coll}: HTTP {st}", "" if st in (200, 204) else r)
        return

    if a.cmd == "probe":
        coll, vault = a.args[0], Path(a.args[1])
        # свіжа колекція, 1 нота, читання назад, побайтова звірка content
        call("DELETE", f"/collection/{coll}")
        call("POST", "/collection", {"name": coll, "description": "kg round-trip probe",
             "model": "BAAI/bge-m3", "chunkLength": 512, "chunkOverlap": 50, "provider": "Pgvector",
             "vectorSearch": {"algorithms": [{"name": "h", "kind": "hnsw", "hnswParameters": {
                 "m": 16, "efConstruction": 200, "efSearch": 100, "metric": "cosine"}}],
                 "profiles": [{"name": "default_profile", "algorithm": "h"}]}})
        import time
        title, content, source = notes(vault)[0]
        md = base64.b64decode(content).decode("utf-8")
        st, r = call("POST", f"/{coll}/documents/batch",
                     {"documents": [{"title": title, "content": content, "source": source, "tags": [KGMD_TAG]}],
                      "chunkLength": 512, "chunkOverlap": 50})
        print(f"upload 1: HTTP {st}", "" if isinstance(r, dict) and r.get("successCount") else r)
        for _ in range(6):
            st, lst = call("GET", f"/{coll}/documents?page=1&pageSize=5")
            if isinstance(lst, dict) and lst.get("items"):
                break
            time.sleep(12)
        did = lst["items"][0]["documentId"]
        st, doc = call("GET", f"/{coll}/documents/{did}")
        back = doc.get("content", "")
        decoded = base64.b64decode(back).decode("utf-8") if back else ""
        print(f"\nsource: {doc.get('source')!r} | tags: {doc.get('tags')}")
        print(f"round-trip декодований == оригінал .md: {decoded == md} ({len(md)} симв)")
        return

    if a.cmd == "upload":
        coll, vault = a.args[0], Path(a.args[1])
        # ідемпотентність: пропускаємо вже залиті source (ембединг повільний → таймаути;
        # сервер продовжує обробку після клієнтського таймауту, тож просто добігаємо повторним запуском)
        st, lst = call("GET", f"/{coll}/documents?page=1&pageSize=1000")
        existing = {d.get("source") for d in (lst.get("items", []) if isinstance(lst, dict) else [])}
        docs = [d for d in notes(vault) if d[2] not in existing]
        print(f"уже в колекції: {len(existing)}; лишилось залити: {len(docs)}")
        total = 0
        for i in range(0, len(docs), a.batch):
            chunk = docs[i:i + a.batch]
            try:
                st, r = call("POST", f"/{coll}/documents/batch",
                             {"documents": [{"title": t, "content": c, "source": s, "tags": [KGMD_TAG]}
                                            for t, c, s in chunk],
                              "chunkLength": 512, "chunkOverlap": 50})
                n = r.get("successCount", 0) if isinstance(r, dict) else 0
                total += n
                print(f"  батч {i//a.batch+1}: HTTP {st}, +{n}", flush=True)
            except Exception as e:
                # таймаут — сервер, найпевніше, все одно обробить; продовжуємо (наступний запуск пропустить)
                print(f"  батч {i//a.batch+1}: таймаут/помилка ({str(e)[:60]}) — продовжую", flush=True)
        print(f"надіслано успішно {total} з {len(docs)}; перезапусти для добору решти")
        return


if __name__ == "__main__":
    main()
