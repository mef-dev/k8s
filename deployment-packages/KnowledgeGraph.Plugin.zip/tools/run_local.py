#!/usr/bin/env py
# -*- coding: utf-8 -*-
"""Підняти граф-плагін ЛОКАЛЬНО, без платформи.

Привід — 25.09.2026: стенд `stage-api.mef.dev` перестав відповідати (мережа), а чат без графа
сенсу не має. Виявилось, що єдиний спосіб підняти плагін без платформи —
`KnowledgeGraph.MockApi` — не збирався з 22.09, бо посилався на видалений контролер V0.

★ ДВА ОКРЕМІ ОТОЧЕННЯ, і в цьому файлі немає ЖОДНОГО значення ні з одного:

  прод     back/plugin/KnowledgeGraph.Plugin/metadata.json      (їде в пакет)
  локальне back/plugin/KnowledgeGraph.MockApi/config.local.json (в пакет не потрапляє фізично:
           пакет — це publish проєкту Plugin, а MockApi на нього лише посилається)

Небезпека, від якої це й розведено, — не в тому, що локальний файл поїде на прод, а в тому, що
хтось полагодить локальний запуск, поправивши `metadata.json`, а `publish_kg.py
--update-configuration` затре живий Configuration тенанта його значеннями. Цю дорогу стереже
`ConfigIsolationTests`.

★ ЦЕЙ СКРИПТ ЛИШЕ НАЗИВАЄ ПРОФІЛЬ (28.09). Що за профілем стоїть, читає сам хост
(`KnowledgeGraph.MockApi/LocalProfile.cs`) — тим самим шляхом, що й F5 у Visual Studio
(`Properties/launchSettings.json`) і `graph-local*.cmd` у корені. Доти скрипт носив власну копію
розбору файлу, тобто способів запуску було три, а копій налаштувань — дві.

ЗАПУСК:

  py back/plugin/tools/run_local.py                 # профіль web: набори з platform.mef.dev
  py back/plugin/tools/run_local.py --offline       # профіль offline: зі знімка, без мережі
  py back/plugin/tools/run_local.py --no-bodies     # не читати сторінок; тоді пульс каже ok

Далі: http://127.0.0.1:8766/api/v2/ai/kgv2/health

Стандартна бібліотека, як і решта tools/ — на Windows `python` перехоплений заглушкою Store,
тож запускати через `py`.
"""

import argparse
import json
import os
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

# ★ Рядковий буфер і UTF-8 — ОБОВ'ЯЗКОВО, і обидві причини зміряні, не вигадані:
#   · без line_buffering звіт про підняття не з'являвся ЗОВСІМ. Хост пише у той самий fd
#     напряму, а наш власний print лежав у буфері до виходу процесу — тобто до Ctrl+C.
#     Виглядало це як «скрипт нічого не друкує», хоч він друкував;
#   · без encoding кирилиця в git-bash перетворюється на кашу (CP866) — та сама грабля,
#     через яку весь tools/ на Python, а не на .cmd.
try:
    sys.stdout.reconfigure(line_buffering=True, encoding="utf-8", errors="replace")
except Exception:
    pass

HOST = "http://127.0.0.1:8766"
BASE = HOST + "/api/v2/ai/kgv2"

# Локальне оточення живе В ПРОЄКТІ МОК-ХОСТА, і це структурна гарантія, не домовленість.
LOCAL_CONFIG = os.path.join("back", "plugin", "KnowledgeGraph.MockApi", "config.local.json")
PROFILE_ENV, SNAPSHOT_ENV = "KG_LOCAL_PROFILE", "KG_LOCAL_SNAPSHOT"


def repo_root():
    """Корінь — за маркером, який СПРАВДІ існує. Той самий, що в Pilot.FindRepoRoot():
    раніше маркером була тека datasets, і коли її видалили, пошук кореня перестав працювати."""
    d = os.path.dirname(os.path.abspath(__file__))
    while d:
        if os.path.isfile(os.path.join(d, "core", "ontology.ttl")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    sys.exit("не знайдено core/ontology.ttl вище від " + os.path.dirname(os.path.abspath(__file__)))


def build(root, quiet):
    proj = os.path.join(root, "back", "plugin", "KnowledgeGraph.MockApi", "KnowledgeGraph.MockApi.csproj")
    print("збираю " + os.path.relpath(proj, root) + " …")
    r = subprocess.run(["dotnet", "build", proj, "-c", "Debug", "--nologo", "-v", "q"],
                       cwd=root, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        tail = [ln for ln in (r.stdout or "").splitlines() if "error" in ln.lower()]
        print("\n".join(tail[:10] or [(r.stdout or "")[-1500:]]))
        sys.exit("збірка впала")
    if not quiet:
        print("  зібрано")


def get(path, timeout=90):
    with urllib.request.urlopen(BASE + path, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def post(path, body, timeout=120):
    req = urllib.request.Request(
        BASE + path, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def report(bodies):
    """Дочекатись і сказати, що САМЕ піднялось. Без цього перший рядок після старту — це
    «Now listening», з якого не видно ні графа, ні того, звідки він."""
    for _ in range(90):
        try:
            h = get("/health", timeout=30)
            break
        except Exception:
            time.sleep(1)
    else:
        print("\n  ⚠ пульс не відповів — дивись вивід хоста вище")
        return

    ds = h.get("datasets") or {}
    ep = h.get("entryPoints") or {}
    print("\n" + "─" * 78)
    print("  пульс     : %s — %s" % (h.get("status"), h.get("summary")))
    print("  граф      : %s вузлів, %s ребер | точок входу %s, наборів %s | перевірка %s мс"
          % (h.get("nodes"), h.get("edges"), ep.get("total"), ds.get("total"), h.get("checkedMs")))
    b = h.get("build") or {}
    print("  збірка    : %s, рантайм %s" % (b.get("version"), b.get("runtime")))

    v = h.get("vectors") or {}
    if v.get("requested"):
        print("  ⚠ вектори : просять %s, є %s — векторний ярус живе в Document API платформи,"
              % (v.get("requested"), v.get("current")))
        print("              тож без неї пульс каже `degraded`. Заземлення від цього не страждає:")
        print("              воно лексичне й обхід графом робить (`via: graph`).")

    try:
        g = post("/ground", {"query": "граф знань", "depth": "medium"})
        ents = g.get("entities") or []
        print("  заземлення: %s, сутностей %d%s" % (
            g.get("grounder"), len(ents),
            (" | якір " + ents[0]["nodeId"].split("#")[-1]) if ents else ""))
    except Exception as ex:
        print("  ⚠ заземлення не відповіло: %s" % ex)

    if bodies:
        try:
            nodes = get("/graph", timeout=180).get("nodes") or []
            withaddr = [n for n in nodes if (n.get("meta") or {}).get("адреса")]
            if withaddr:
                nid = withaddr[0]["id"]
                nd = get("/node?id=%s&text=true" % urllib.parse.quote(nid, safe=""), timeout=180)
                body = (nd.get("node") or {}).get("body") or ""
                print("  тіла      : адрес %d, прочитано %d символів з %s"
                      % (len(withaddr), len(body), nid.split("#")[-1]))
        except Exception as ex:
            print("  ⚠ тіло не прочиталось: %s" % ex)
    else:
        print("  тіла      : вимкнено — /node?text=true віддасть картку без body")

    print("─" * 78)
    print("  %s/api/v2/ai/kgv2/health   ·   Ctrl+C щоб зупинити" % HOST)
    print("─" * 78 + "\n")


def main():
    ap = argparse.ArgumentParser(description="Підняти граф-плагін локально, без платформи.")
    ap.add_argument("--profile", default=None, help="яке оточення брати: web (дефолт) або offline")
    ap.add_argument("--offline", action="store_true", help="те саме, що --profile offline")
    ap.add_argument("--snapshot", metavar="ДАТА",
                    help="який знімок брати в offline (дефолт — найсвіжіший)")
    ap.add_argument("--no-bodies", action="store_true",
                    help="не читати сторінки сайту; тоді пульс каже ok, а не degraded")
    ap.add_argument("--no-build", action="store_true", help="не перезбирати")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    if a.profile and a.offline and a.profile != "offline":
        sys.exit("--profile %s і --offline суперечать одне одному" % a.profile)
    profile = a.profile or ("offline" if a.offline else "web")

    root = repo_root()
    if not os.path.isfile(os.path.join(root, LOCAL_CONFIG)):
        sys.exit("немає локального оточення: " + os.path.join(root, LOCAL_CONFIG))

    if profile == "offline" and a.snapshot:
        snap = os.path.join(root, "back", "plugin", "KnowledgeGraph.Tests",
                            "fixtures", "platform-mef-dev", a.snapshot, "graph.ttl")
        if not os.path.isfile(snap):
            sys.exit("немає знімка: " + snap)

    if not a.no_build:
        build(root, a.quiet)

    extra = {PROFILE_ENV: profile}
    if a.snapshot:
        extra[SNAPSHOT_ENV] = a.snapshot
    if a.no_bodies:
        # Явна змінна виграє над профілем (LocalProfile.Apply) — так і вимикаються тіла.
        extra["KgV2EntryPoints__0__index"] = "false"
    bodies = profile == "web" and not a.no_bodies

    print("оточення : %s, профіль «%s»" % (LOCAL_CONFIG, profile))

    env = dict(os.environ)
    env.update(extra)
    binder = os.path.join(root, "back", "plugin", "KnowledgeGraph.MockApi",
                          "bin", "Debug", "net10.0", "KnowledgeGraph.MockApi.dll")
    if not os.path.isfile(binder):
        sys.exit("немає " + binder + " — зніми --no-build")

    threading.Thread(target=report, args=(bodies,), daemon=True).start()
    try:
        # Робоча тека — поруч зі збіркою: metadata.json читається відносно неї.
        return subprocess.call(["dotnet", binder], cwd=os.path.dirname(binder), env=env)
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
