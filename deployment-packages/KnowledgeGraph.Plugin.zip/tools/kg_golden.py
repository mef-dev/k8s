"""Золотий знімок відповідей контролера графа — доказ, що V0 не змінився.

Навіщо. Розділення на V0/V2 має лишити поведінку V0 незмінною, але на master немає ані тестів, ані
фікстур: доводити нічим. Цей скрипт знімає ВСІ 11 маршрутів зі стенда до першої правки і звіряє їх
після. Порівняння побайтове по нормалізованому JSON — тобто ловить і зміну значень, і зміну форми.

    python tools/kg_golden.py snap                 зняти еталон (v0-baseline/)
    python tools/kg_golden.py check                звірити поточний стенд з еталоном
    python tools/kg_golden.py snap --export kgv2   те саме для другого контролера
    python tools/kg_golden.py check --base http://localhost:5080

Волатильні маршрути (usage/last несе лічильники ходу) звіряються за СТРУКТУРОЮ, не за значеннями:
ключі й типи мають збігтися, числа — ні. Це названо в звіті окремо, щоб різниця не читалась як успіх.
"""
import argparse
import base64
import io
import json
import os
import sys
import urllib.error
import urllib.request

sys.stdout.reconfigure(encoding='utf-8')

HERE = os.path.dirname(os.path.abspath(__file__))
BASELINE = os.path.join(os.path.dirname(HERE), 'v0-baseline')

DEFAULT_BASE = 'https://stage-api.mef.dev'
DEFAULT_AUTH = 'vtymbcread1234:vtymbcread1234'

# Вузол для /node береться сталий і заздалегідь відомий: інакше знімок залежав би від того, що саме
# сьогодні повернув пошук, і різниця читалась би як регресія там, де змінилися лише дані.
NODE_ID = 'pilot/sc-tariff-package'
GROUND_QUERY = 'тарифний план'
SPARQL_QUERY = 'SELECT (COUNT(*) AS ?n) WHERE { ?s ?p ?o }'

# (ім'я файла, метод, шлях, тіло). Порядок — як у контролері.
ROUTES = [
    ('sources', 'GET', 'sources', None),
    ('graph', 'GET', 'graph', None),
    ('ground', 'POST', 'ground', {'query': GROUND_QUERY}),
    ('meta', 'GET', 'meta', None),
    ('usage-last', 'GET', 'usage/last', None),
    ('node', 'GET', 'node?id=' + urllib.request.quote(NODE_ID, safe=''), None),
    ('query-canonical', 'GET', 'query/canonical', None),
    ('areas', 'GET', 'areas', None),
    ('seams', 'GET', 'seams', None),
    ('graph-ttl', 'GET', 'graph.ttl', None),
    ('sparql', 'POST', 'sparql', {'query': SPARQL_QUERY}),
]

# Маршрути, де значення законно змінюються від ходу до ходу: звіряємо форму, не вміст.
VOLATILE = {'usage-last'}


def call(base, auth, export, method, path, body):
    url = '%s/api/v2/ai/%s/%s' % (base.rstrip('/'), export, path)
    data = json.dumps(body, ensure_ascii=False).encode('utf-8') if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header('Authorization', 'Basic ' + base64.b64encode(auth.encode()).decode())
    if data is not None:
        req.add_header('Content-Type', 'application/json; charset=utf-8')
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, r.read().decode('utf-8', 'replace')
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode('utf-8', 'replace')
    except Exception as e:
        return 0, 'ПОМИЛКА ВИКЛИКУ: %s' % e


def normalize(text):
    """JSON — у канонічну форму, щоб порядок ключів і пробіли не давали хибної різниці."""
    try:
        return json.dumps(json.loads(text), ensure_ascii=False, sort_keys=True, indent=2)
    except Exception:
        return text  # graph.ttl і текстові відповіді лишаються як є


def shape(value):
    """Форма значення: ключі й типи без самих значень."""
    if isinstance(value, dict):
        return {k: shape(v) for k, v in sorted(value.items())}
    if isinstance(value, list):
        return [shape(value[0])] if value else []
    return type(value).__name__


def snap(args):
    out = os.path.join(BASELINE, args.export)
    os.makedirs(out, exist_ok=True)
    print('знімаю %s → %s' % (args.export, out))
    for name, method, path, body in ROUTES:
        status, text = call(args.base, args.auth, args.export, method, path, body)
        io.open(os.path.join(out, name + '.json'), 'w', encoding='utf-8').write(normalize(text))
        io.open(os.path.join(out, name + '.status'), 'w', encoding='utf-8').write(str(status))
        print('  %-16s %s  %d символів' % (name, status, len(text)))
    print('готово: %d маршрутів' % len(ROUTES))


def check(args):
    out = os.path.join(BASELINE, args.export)
    if not os.path.isdir(out):
        print('еталону немає: %s — спершу snap' % out)
        return 2
    same = diff = missing = 0
    notes = []
    for name, method, path, body in ROUTES:
        want_file = os.path.join(out, name + '.json')
        if not os.path.exists(want_file):
            print('  %-16s ЕТАЛОНУ НЕМАЄ' % name)
            missing += 1
            continue
        want = io.open(want_file, encoding='utf-8').read()
        want_status = io.open(os.path.join(out, name + '.status'), encoding='utf-8').read().strip()
        status, text = call(args.base, args.auth, args.export, method, path, body)
        got = normalize(text)

        if str(status) != want_status:
            print('  %-16s СТАТУС %s замість %s' % (name, status, want_status))
            diff += 1
            continue

        if name in VOLATILE:
            try:
                ok = shape(json.loads(got)) == shape(json.loads(want))
            except Exception:
                ok = got == want
            if ok:
                same += 1
                notes.append('%s — форма збігається, значення волатильні' % name)
            else:
                print('  %-16s ФОРМА ЗМІНИЛАСЬ' % name)
                diff += 1
            continue

        if got == want:
            same += 1
        else:
            diff += 1
            print('  %-16s РІЗНИЦЯ (%d проти %d символів)' % (name, len(got), len(want)))
            io.open(os.path.join(out, name + '.actual.json'), 'w', encoding='utf-8').write(got)

    print()
    for n in notes:
        print('  примітка: ' + n)
    print('%d із %d збігаються, різниць %d, без еталона %d' % (same, len(ROUTES), diff, missing))
    return 0 if diff == 0 and missing == 0 else 1


def main():
    p = argparse.ArgumentParser()
    p.add_argument('mode', choices=['snap', 'check'])
    p.add_argument('--base', default=DEFAULT_BASE)
    p.add_argument('--auth', default=DEFAULT_AUTH)
    p.add_argument('--export', default='kg')
    args = p.parse_args()
    sys.exit(snap(args) if args.mode == 'snap' else check(args))


if __name__ == '__main__':
    main()
