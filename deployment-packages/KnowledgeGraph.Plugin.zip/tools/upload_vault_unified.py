"""Залити vault у Document API у ЄДИНОМУ форматі — один документ = і граф, і RAG.

  • content  = ЧИСТА проза нотатки (+ рядок «Синоніми: …») → добрий bge-m3 ембединг для RAG;
               прямі лапки → «ялинки» (баг платформи на " у content).
  • metadata = frontmatter як структурований JSON → ТРИПЛЕТИ для графа (KG-плагін читає metadata,
               а не декодує base64). Читабельно, без дублювання, одне джерело правди.
  • title    = ім'я файлу (== label вузла графа);  source = relPath (== meta.file вузла) → 1:1 з вузлом.

Замінює documents.py (base64-байтстор) + upload_vault_plain.py (strip-проза): жодного base64.
Метадата імунна до багів платформи з `[` та `"` (перевірено: їдуть як JSON-обʼєкт, не як рядок для JSON-парсингу).

Запуск — з теки back/plugin (шлях --vault рахується від ПОТОЧНОЇ теки, не від теки скрипта):

  cd back/plugin
  python tools/upload_vault_unified.py --auth user:pass --url https://stage-api.mef.dev \
      --collection kg-vault-uni-v1 --vault fixtures/pilot-vault [--recreate]

⚠ Не «../fixtures/...»: якщо запускати з кореня back/plugin, «..» вийде на рівень вище й тека
не знайдеться. За сумнівів — абсолютний шлях. Скрипт друкує, куди саме він дивився.
"""
from __future__ import annotations
import argparse, base64, json, re, sys, time, urllib.error, urllib.request
from pathlib import Path

import yaml

TAG = "kg-uni"
B64_TAG = "kgmd-b64"  # legacy: .ttl-онтологія їде base64 (turtle має [ і "; це СХЕМА датасету, не нота)
FRONT = re.compile(r"^---\n(.*?)\n---\n", re.S)


def api(base: str, auth: str):
    token = base64.b64encode(auth.encode()).decode()

    def call(method: str, path: str, body: dict | None = None, timeout: int = 300):
        url = f"{base.rstrip('/')}/api/v2/ai/document{path}"
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Authorization", f"Basic {token}")
        if data:
            req.add_header("Content-Type", "application/json; charset=utf-8")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read().decode("utf-8", "replace")
                return r.status, (json.loads(raw) if raw.strip().startswith(("{", "[")) else raw)
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")[:300]
    return call


def sanitize(text: str) -> str:
    """Прямі подвійні лапки → парні «ялинки»: content, що містить «"», платформа не заливає взагалі
    (баг /documents/batch). Для ембедингів текст той самий. Метадати це НЕ стосується — вона імунна."""
    out, open_q = [], True
    for ch in text:
        if ch == '"':
            out.append("«" if open_q else "»")
            open_q = not open_q
        else:
            out.append(ch)
    return "".join(out)


def synonyms_line(fm: dict) -> str:
    """match/aliases у прозу окремим рядком, щоб RAG-ембединг бачив синоніми (метадату він не ембедить)."""
    terms: list[str] = []
    for key in ("match", "aliases"):
        v = fm.get(key)
        if isinstance(v, list):
            terms += [str(t) for t in v]
        elif v:
            terms.append(str(v))
    terms = list(dict.fromkeys(t.strip() for t in terms if str(t).strip()))
    return "Синоніми: " + ", ".join(terms) + "\n\n" if terms else ""


def build_docs(vault: Path):
    out, skipped = [], 0
    for p in sorted(vault.rglob("*.md")):
        rel = p.relative_to(vault).as_posix()
        md = p.read_text(encoding="utf-8-sig").replace("\r\n", "\n").strip()
        if not md:
            continue
        m = FRONT.match(md)
        if not m:
            print(f"  ! {rel}: немає frontmatter — пропущено (як і парсер графа)")
            skipped += 1
            continue
        fm = yaml.safe_load(m.group(1)) or {}
        body = FRONT.sub("", md).strip()
        content = sanitize(synonyms_line(fm) + body)
        # metadata = сам frontmatter (JSON). KG-плагін відновить триплети з нього; конвертер зводить
        # число/булеве до рядка (лексична форма як у YAML-скаляра) — доведено тестом парсер-еквівалентності.
        out.append({"title": p.stem, "content": content, "source": rel, "tags": [TAG], "metadata": fm})
    # .ttl-онтологія датасету (напр. storage-control/_ontology.ttl): не нота, а схема — base64-legacy,
    # DocumentContentSource впізнає її за source.endswith('.ttl') і доклеює у SchemaTurtle().
    for p in sorted(vault.rglob("*.ttl")):
        rel = p.relative_to(vault).as_posix()
        ttl = p.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
        out.append({"title": p.stem, "content": base64.b64encode(ttl.encode("utf-8")).decode("ascii"),
                    "source": rel, "tags": [B64_TAG]})
        print(f"  + онтологія (base64): {rel}")
    return out, skipped


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--auth", required=True, metavar="user:pass")
    ap.add_argument("--url", required=True)
    ap.add_argument("--collection", default="kg-vault-uni-v1")
    ap.add_argument("--vault", required=True)
    ap.add_argument("--batch", type=int, default=10)
    ap.add_argument("--recreate", action="store_true")
    a = ap.parse_args()
    call = api(a.url, a.auth)
    coll = a.collection

    # ★ Гучний провал замість мовчазного «залито 0 з 0» (інакше CI/девопс бачить успіх на порожній
    # заливці). Path.rglob() на неіснуючій теці НЕ кидає — просто дає порожньо, тож перевіряємо самі.
    vault = Path(a.vault)
    print(f"vault: {vault.resolve()}")
    if not vault.exists():
        print(f"ПОМИЛКА: теки не існує: {vault.resolve()}\n"
              f"  (шлях рахується від поточної теки: {Path.cwd()})\n"
              f"  запускай з back/plugin і став --vault fixtures/<назва>, або дай абсолютний шлях",
              file=sys.stderr)
        return 2
    if not vault.is_dir():
        print(f"ПОМИЛКА: це не тека: {vault.resolve()}", file=sys.stderr)
        return 2

    docs, skipped = build_docs(vault)
    print(f"нот зібрано: {len(docs)} (пропущено без frontmatter: {skipped})")
    if not docs:
        print(f"ПОМИЛКА: у {vault.resolve()} не знайдено жодної ноти (*.md з frontmatter) "
              f"чи онтології (*.ttl) — нічого заливати, колекцію не чіпаю", file=sys.stderr)
        return 3

    if a.recreate:
        st, _ = call("DELETE", f"/collection/{coll}")
        print(f"delete {coll}: HTTP {st}")
        time.sleep(2)

    st, r = call("POST", "/collection", {
        "name": coll,
        "description": "vault: content=проза (RAG), metadata=frontmatter (граф). Єдине джерело правди.",
        "model": "BAAI/bge-m3", "chunkLength": 512, "chunkOverlap": 50, "provider": "Pgvector",
        "vectorSearch": {"algorithms": [{"name": "h", "kind": "hnsw", "hnswParameters": {
            "m": 16, "efConstruction": 200, "efSearch": 100, "metric": "cosine"}}],
            "profiles": [{"name": "default_profile", "algorithm": "h"}]}})
    print(f"create {coll}: HTTP {st} {r if st not in (200, 201) else ''}")

    st, lst = call("GET", f"/{coll}/documents?page=1&pageSize=1000")
    existing = {d.get("source") for d in (lst.get("items", []) if isinstance(lst, dict) else [])}
    todo = [d for d in docs if d["source"] not in existing]
    print(f"уже залито: {len(existing)} · лишилось: {len(todo)}")

    ok = 0
    for i in range(0, len(todo), a.batch):
        part = todo[i:i + a.batch]
        try:
            st, r = call("POST", f"/{coll}/documents/batch",
                         {"documents": part, "chunkLength": 512, "chunkOverlap": 50})
            n = r.get("successCount", 0) if isinstance(r, dict) else 0
            ok += n
            print(f"  батч {i // a.batch + 1}: HTTP {st} +{n}"
                  + ("" if st in (200, 201) and n == len(part) else f"  ⚠ {str(r)[:160]}"), flush=True)
        except Exception as e:  # таймаут ембедингу: сервер дообробить, повторний запуск пропустить залите
            print(f"  батч {i // a.batch + 1}: {str(e)[:60]} — продовжую", flush=True)
    print(f"залито {ok} з {len(todo)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
