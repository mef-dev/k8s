# Knowledge Graph

Knowledge Graph holds the operator's own things and how they relate: services, products, sites, networks, customers, incidents — as typed entities with named relations between them, not as text somebody has to interpret.

This is what lets a question in plain language reach real data. The words in the question are matched against entities in the graph first; only what the graph confirms goes further. Without that step an assistant produces a plausible sentence, and an agent picks a plausible target.

## What it solves

- Grounding: a request is anchored to entities that exist, so answers and agent selection are about the operator's environment rather than about a guess.
- Questions that cross domains: which services a site carries, and which of them are under contract, is one traversal instead of a join across systems.
- Evidence: every fact returned carries provenance — which entity it came from, by which relation — so it can be checked.
- Cost control on large graphs: a query declares how far it may walk and what it may cross, so a broad question cannot turn into an unbounded traversal.

## Interfaces

- Entity and relation management for the operator's domains.
- Bounded traversal queries, with provenance on each result.
- `SPARQL` for graph queries that do not fit the traversal API.
- Lexical grounding, used by the assistant and by Discovery.

## Dependencies

Deployed into namespace `ai`. It stands on its own: entities and traversals do not require another component.

- Namespace `ai` — required.
- Used by **Platform Assistant** for grounding, and by **Fabric-T Runtime** for Discovery — which is one reason namespace `fabric` requires `ai`.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
