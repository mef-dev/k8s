# Model Gateway

Model Gateway is the single path from the platform to a language model. Chat, responses and embeddings all go through it, so which model answered, under whose credentials and at what cost is recorded in one place instead of being spread across every plugin that happened to call a provider.

The fabric is not tied to one provider. A model may run locally — an ONNX runtime on the operator's own compute, called with no external hop — or be an external managed service reached by endpoint. Both are described by the same locator record, so moving between them is configuration.

## What it solves

- Keeping data inside the perimeter: a locator in direct mode calls a locally deployed model, so prompts and documents never leave the operator's compute.
- Changing provider without touching agents: the model is referenced by locator, not by a hard-coded endpoint, so a swap is a profile change.
- Knowing what inference costs: every call goes through one path, so token counts and price attach to a request rather than being estimated per team.
- Stopping credential sprawl: the provider key lives in the locator record and is masked in the profile; no plugin carries its own copy.

## What a locator carries

- The model identity and the access mode — direct, or external service.
- The endpoint and the masked credential for an external service.
- Runtime parameters: device, version, quantisation, request headers.
- Whether the model is required: an agent that generates text must have at least one locator marked required.

## Dependencies

Deployed into namespace `ai`, the base layer.

- Namespace `ai` — required; it depends on no namespace above it.
- **Model Console** — optional: the pages that manage models, documents and vector search. The gateway is fully usable through the API without it.
- **Pipeline Insight** — optional: it records model calls alongside agent and tool calls, which is what makes cost per process a number rather than an estimate.
- Agents in namespaces `fabric` and `agent` reach models through this component — that is why the namespace chain points downward and never the other way.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
