# Trusted Gateway

Trusted Gateway is the component that decides whether one agent may call another, one call at a time. Before a cross-vendor dispatch leaves, the calling agent asks the gateway to authorise that exact exchange; the gateway checks it against the operator's rules and returns a one-time authorisation together with a Secure Passport carrying verified context.

It authorises. It does not orchestrate: it never decides which agents interact or in what order, and it runs no business logic. That separation is what lets agents act autonomously without the operator losing the ability to say what each call was allowed to do.

## What it solves

- Proving a specific call was permitted: the authorisation is bound to that request, so "the agent was authenticated" is replaced by "this exact transition was allowed".
- Containing a compromised or misconfigured agent: claims are issued by the platform, never by the caller, so an agent cannot grant itself a scope it was never given.
- Making multi-vendor autonomy reviewable: every signature, verification and execution is emitted as a correlated event, so an operator can reconstruct one interaction end to end.
- Enforcing the operator's process at runtime: the transition must exist in the compiled process graph and satisfy the policy for that pair of agents, or the dispatch is refused.

## What an authorisation carries

- A one-time, request-bound authorisation — it does not work for a second call.
- A Secure Passport with tenant, site, incident and the access scope granted for this interaction.
- The evidence chain the Token Authority checked before admitting the step.
- The process binding: the edge, the prompt template and the version the signature was issued against.

## Dependencies

Deployed into namespace `fabric`, which requires namespace `ai`.

- Namespace `ai` — required, through the `fabric` chain.
- Namespace `fabric` — this is where the component lives.
- **Fabric-T Runtime** — required: the gateway checks that both parties of a call exist in the registry and are enabled, and resolves the prompt template it binds into the signature.
- **Pipeline Insight** — optional: it records the sign, verify and execute events this component emits. Without it the gateway still authorises; there is simply no durable record to review.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
