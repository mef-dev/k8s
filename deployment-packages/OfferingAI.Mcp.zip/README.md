# OfferingAI.Mcp — агент A1 offering.ai як плагін MEF.DEV

Логіка чотирьох BPMN-процесів offering.ai, перенесена в C#. Плагін має дві поверхні:

- **MCP-сервер** з MCP App тарифного гриду (`offeringapp/rpc`). Чат ai-chat підключає його як звичайний конектор.
- **A2A-агент** для фабрики агентів (`offering-agent`), зареєстрований як InternalHosted.

Старий BPMN-проєкт і `UI_plugin` не змінювались, вони працюють поруч.

| що | значення на сервері 91 |
| --- | --- |
| сервіс | 10017, `OfferingAI.Mcp`, категорія System |
| простір | `product-catalog-ai` (namespace 5) |
| MCP | `POST /api/v2/product-catalog-ai/offeringapp/rpc` (анонімний маршрут) |
| адреса для конектора | `http://api:5000/api/v2/product-catalog-ai/offeringapp/rpc` |
| A2A напряму | `POST /api/v2/product-catalog-ai/offering-agent/message:send` |
| A2A через фабрику | `POST /api/v2/fabric/a2a/offering-agent/message:send`, `agentKey` = `offering-agent` |
| health | `GET /api/v2/product-catalog-ai/offeringapp/health` |

## Що куди переїхало

| BPMN | тут |
| --- | --- |
| `get_config` | `OfferingOptions`: простір сховища, модель, доповнення з графа платформи. Кредиток немає: LLM кличеться маршрутом `ai/chat/completions` усередині процесу. |
| `get_rag` | `Knowledge/OfferingVault`: заземлення на графі offering-ai (`graph/vault`, вбудовано ресурсами). Синоніми колонок — `match`, допустимі значення — вузли значень, правила — тіла нот. Каталог усіх 45 колонок іде в кожен хід. |
| `send_msg` | `Agent/OfferingAgent.ChatAsync`: один структурований хід моделі (answer, change, clarify, unsupported). Зміни — типізовані операції (`set`, `multiply`, `add`, `clear`, `deleteRows`, `duplicateRow`), їх виконує й перевіряє `Tariff/TariffEditor`. Невдалий план отримує одну спробу виправлення. |
| `get_description` | `OfferingAgent.ExplainAsync`: опис пакета, зміни від закоміченої версії, кроки. |

## Пакети

Пакет — тред сховища розмов (ProductCatalogAI · Conversations, простір `product-catalog-ai`):

- `productOfferingRef` = `offering-ai/package`; за цією позначкою ai-chat не показує тред серед розмов (ai-chat `docs/159`).
- Кожна версія таблиці — повідомлення з `additionalData.xmlValue`. Робоча версія — найновіше таке повідомлення.
- Закомічена версія — `additionalData` треда: `LastCommitedXmlValue` і `committedMessageId`. Ключі ті самі, що в легасі UI.
- Розмова з агентом іде в тому ж треді, тож кожна зміна прив'язана до репліки, з якої виникла.

## Файли

Людина починає зі свого файла: xlsx (перший аркуш) або CSV шаблону імпорту тарифних умов. Старий формат .xls не читається, його треба зберегти як .xlsx. Грид завантажує файл кнопкою або перетягуванням (`import_tariff_package`). Завантажене стає першою закоміченою версією, оригінал лягає в персональний Storage людини (`ILocalFileStoreProvider.Get("personal")`, як вкладення чату).

Вивантаження (`export_tariff_package`) — повний пакет одним аркушем із заголовками шаблону, робоча або закомічена версія. Файл іде в Storage, а грид передає його хосту запитом `ui/download-file` (ai-chat `docs/160`): sandbox-iframe сам файли не зберігає. Посилання Storage віддає файл лише автентифікованому власнику. Цей файл людина імпортує в BSS: «Тарифні умови», «Імпорт», режим «Додавання тарифів» або «Re-Price тарифів».

xlsx читається й пишеться без зовнішніх бібліотек (`Tariff/Xlsx.cs`). Числа беруться сирим текстом, тож безліміт 999999999999999999 не стає 1E+18. Перевірено: `big_with_trafic.xlsx` читається точно як його CSV, а вивантаження `iot_pool` збігається з оригіналом клітинка в клітинку.

Без пакетів `show_tariff_package` відкриває екран завантаження: демо-пакет із шаблону сам більше не створюється.

## Ідентичність

Платформа бере організацію з claims запиту. Тому виклик `rpc` має нести авторизацію людини. Без неї інструменти відповідають, що запит прийшов без організації. ai-chat передає креду людини конекторам на адресу самої платформи.

## Інструменти MCP

| інструмент | хто бачить | що робить |
| --- | --- | --- |
| `show_tariff_package` | модель, грид | відкриває редактор пакета (без `packageId` — останній; без пакетів — екран завантаження) |
| `offering_chat` | модель, грид | хід агента: відповідь або зміна з новою версією |
| `list_tariff_packages`, `create_tariff_package` | модель, грид | перелік і створення (з шаблону або копією) |
| `explain_tariff_package` | модель, грид | `describe`, `diff`, `steps` |
| `commit_tariff_package`, `revert_tariff_package` | модель, грид | коміт робочої версії і відкат до закоміченої |
| `update_tariff_cell` | модель, грид | пряма правка клітинки з перевіркою і `baseVersion` |
| `lookup_tariff_knowledge` | модель, грид | картки колонок і понять з графа |
| `export_tariff_package` | модель, грид | xlsx повного пакета для BSS, копія в Storage |
| `delete_tariff_package` | модель, грид | видалення пакета з історією, лише на явне прохання |
| `import_tariff_package` | лише грид | новий пакет з файла людини |
| `get_tariff_package`, `restore_tariff_version`, `rename_tariff_package` | лише грид | службові дії гриду |

Грид (`poc/mcp-app/view`, Angular 20) — редактор пакета: робоча й закомічена версії з підсвіткою змін, коміт, відкат, відновлення будь-якої версії, завантаження й вивантаження xlsx, копія й видалення пакета. Вигляд колонок: ключові, «Підписки й нарахування», «Послуги споживання», усі або свій набір; людські назви колонок з легасі UI; порожні колонки сховано за замовчуванням; позначка, якщо пакетні колонки (TemplateParentID, TemplatePriority, Labels, PolicyCode, Currency) мають різні значення. Внутрішній чат агента — бічна панель, згорнута за замовчуванням.

## A2A

`message:send` повертає `{"task": …}` зі станами `TASK_STATE_*` і ролями `ROLE_*`. Контекст розмови прив'язується до пакета: відповідь повертає `contextId` вигляду `offering-package-{id}`. Пакет і дію можна задати в `metadata` або data-частиною:

```json
{"message":{"role":"ROLE_USER","messageId":"m1","parts":[{"text":"Підніми ціну абонплати на 10%"}],"metadata":{"packageId":"9"}}}
```

```json
{"message":{"role":"ROLE_USER","messageId":"m2","parts":[{"data":{"action":"explain","mode":"diff","packageId":9}}]}}
```

Дії: `chat` (за замовчуванням), `show`, `list`, `create`, `explain`, `commit`, `revert`. Уточнення агента повертається станом `TASK_STATE_INPUT_REQUIRED`.

## Налаштування

Конфігурація плагіна (`configuration` сервісу), усе необов'язкове:

```json
{"StorageAlias": "product-catalog-ai", "Model": "gpt-5-mini", "PlatformGraph": false, "GraphVectors": "auto", "GraphTimeoutMs": 15000}
```

`PlatformGraph: true` додає до заземлення граф платформи (`ai/kgv2/ground`, граф ≥ 1.0.0.73) двома рівнями
(docs/34 §3): робочий — лише набір offering-ai, іде в ЗНАННЯ зі «збігами (вузол ← чому)»; контекст — решта наборів,
окремим блоком «КОНТЕКСТ ПРОЦЕСУ», лише для пояснень. Основа — вбудована копія графа; за замовчуванням вимкнено,
бо додає ~3 с на хід (стеля вектора 2 с).

`GraphVectors` — як граф платформи заземлює: `auto` (вектор, якщо колекція готова), `always` (вимагати вектор),
`never` (лише лексика: ~0,2 с замість ~2 с, детерміновано). На 43 кейсах замовника лексика дала 43 з 43, вектор —
42 з 43 (docs/35 §8). `GraphTimeoutMs` — таймаут виклику графа з вектором (15 с; стеля вектора на графі на 3 с менша); не відповів —
той самий запит лексикою. Що сталося в ході — `turn.graph`: `mode`, `grounder`, `degradedFrom`, `ms`, `error`,
`fallback`.

## Збірка

Спершу грид, бо він вбудовується в збірку ресурсом:

```bash
cd poc/mcp-app/view && npm install && npm run build
```

```bash
cd mcp_plugin/OfferingAI.Mcp.Tests && dotnet test
```

```bash
cd mcp_plugin/OfferingAI.Mcp && dotnet publish -c Release -r portable --no-self-contained
```

Zip ляже в `OfferingAI.Mcp/bin/Release/net10.0/portable/publish.zip`.

## Викладка

Перед викладкою підняти `<Version>` у csproj: платформа відповідає 409 на вже наявну версію.

1. `POST /api/v0/Services/10017/upload` — zip у полі `file`; відповідь містить `id` нової версії.
2. `POST /api/v0/Services/10017` — multipart, поле `model` з JSON сервісу і `VersionId` нової версії. Без поточної версії сервіс лишається Draft, а маршрут — 404.
3. `POST /api/v0/Services/10017/reload`.
4. `POST /api/v0/Namespaces/5/service/10017` з `{"versionId": <id>}`, потім `POST /api/v0/Namespaces/5/approve`.
5. Перевірка: `GET /api/v2/product-catalog-ai/offeringapp/health` показує нову версію.

Після зміни переліку інструментів конектор у чаті треба перевірити наново (кнопка «Перевірити» в налаштуваннях): реєстр зберігає інструменти, побачені під час перевірки.

## Реєстрація у фабриці

Агент зареєстрований на 91 запитом `POST /api/v2/fabric/agents` з `hostingType: InternalHosted`, `agentKey: offering-agent`, `deployment.url: plugin://product-catalog-ai/offering-agent` і трьома навичками (`offering-chat`, `offering-explain`, `offering-versions`).

## Відомі обмеження

- Відповідь приходить одним шматком, без стріму: хід агента триває 7–25 секунд.
- Історія пакета читається останніми 60 повідомленнями.
- Задачі A2A живуть у пам'яті процесу і зникають після перезавантаження сервісу. Пакети зберігаються.
- Node-сервер PoC (`poc/mcp-app/server`) віддає стару форму даних без пакетів. Грид з ним відкривається, але без версій і панелі агента.
