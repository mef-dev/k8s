# Document Parser

Document Parser is the agent that turns the operator's documents into content the rest of the platform can actually use. Specifications, contracts, runbooks and vendor manuals arrive as PDFs and office files; what the knowledge layer needs is structured text with its headings, tables and boundaries intact.

It is registered in the fabric like any other agent, which means it is discovered, authorised and recorded the same way — parsing an operator document is not a side channel outside governance.

## What it solves

- Getting existing documents into the knowledge layer without re-keying them by hand.
- Preserving structure: a table that becomes a wall of text cannot be cited precisely, so headings, tables and section boundaries are kept.
- Feeding both indexes: the extracted content is what document search embeds and what the knowledge graph draws typed entities from.
- Keeping answers traceable: content keeps its offsets in the source file, so an answer can quote the passage it came from.

## What the output carries

- Structured text with the document's own headings and sections.
- Tables kept as tables rather than flattened into prose.
- Offsets back into the source file, so a quotation can be located.
- The document identity the knowledge layer indexes it under.

## Dependencies

Deployed into namespace `agent`, which requires both `ai` and `fabric`.

- Namespace `ai` — required: the extracted content is indexed by the knowledge layer, and the agent reaches models through this layer.
- Namespace `fabric` — required: the agent is registered in the Fabric-T registry, and its calls are authorised by the Trusted Layer.
- Namespace `agent` — this is where the component lives.
- **Fabric-T Runtime** — required: registration and discovery.
- **Knowledge Graph** — optional: needed only if parsed documents are meant to populate typed entities as well as document search.

The namespaces install in order: `ai` is the base layer and depends on no other; `fabric` requires `ai`; `agent` requires both.
